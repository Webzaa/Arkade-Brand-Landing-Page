

$(document).ready(function () {
    function sendLog(actionType, dataPayload) {
        dataPayload.action_type = actionType;
        // ===m=== Capture the exact page they are on ===m===
        dataPayload.current_url = window.location.pathname + window.location.search;
        $.ajax({
            url: 'leads/ajax_log_activity.php',
            type: 'POST',
            data: dataPayload,
            error: function () {
                console.log("Background log failed");
            }
        });
    }
    // ===m=== Track logout specifically ===m===
    $(document).on('click', 'a[href*="logout.php"]', function (e) {
        e.preventDefault(); // stop immediate redirect
        e.stopImmediatePropagation();
        let logoutUrl = $(this).attr('href');
        sendLog('logout', {
            clicked_element: 'Logout'

        });
        setTimeout(function () {
            window.location.href = logoutUrl;
        }, 400);
        return;
    });
    // ===m=== Track clicks ===m===
    $(document).on('click', 'a, button, input[type="button"], input[type="submit"], [role="button"], .nav-link, .dropdown-item,[data-bs-toggle], [data-toggle]', function (e) {
        let $el = $(this);
        // ===m=== Extract element text/label ===m===
        let text = $el.text().trim() || $el.val() || $el.attr('title') || $el.attr('aria-label') || 'Icon/Element';
        let href = $el.attr('href') || '';
        let id = $el.attr('id') || '';
        let textLower = text.toLowerCase();
        // ===m=== Limit text length ===m===
        if (text.length > 50) text = text.substring(0, 50) + '...';
        // ===m=== Ignore useless javascript-only icon clicks ===m===
        if (href.toLowerCase().includes('javascript:') && text === 'Icon/Element') return;
        // ===m=== Detect report export/download actions ===m===
        if (textLower.includes('export') || textLower.includes('download') || href.toLowerCase().includes('export.php')) {
            sendLog('report_download', {
                report_name: text || 'Export Data'
            });
            return;
        }
        if (textLower.includes('search') || $el.attr('id') === 'search-btn' || $el.hasClass('search')) {
            let searchTerm = $el.closest('form, div, .row').find('input[type="text"], input[type="search"]').val();
            if (searchTerm && searchTerm.trim() !== '') {
                sendLog('search', {
                    search_term: searchTerm.trim()
                });
                return;
            }
        }
        // ===m=== Prepare element details for logging ===m===
        let elementDetails = text;
        if (href && href !== '#' && !href.toLowerCase().includes('javascript:')) {
            elementDetails += ' (' + href + ')';
        } else if (id) {
            elementDetails += ' (#' + id + ')';
        }
        sendLog('click', {
            clicked_element: elementDetails
        });
    });
    // ===m=== Track search via Enter key in input fields ===m===
    $(document).on('keypress', 'input', function (e) {
        if (e.which == 13) {
            let inputAttributes = ($(this).attr('id') || '') + ($(this).attr('name') || '') + ($(this).attr('placeholder') || '');
            if (inputAttributes.toLowerCase().includes('search')) {
                let searchTerm = $(this).val().trim();
                if (searchTerm !== '') {
                    sendLog('search', {
                        search_term: searchTerm
                    });
                }
            }
        }
    });
    // ===m=== Track dropdown/select value changes ===m===
    $(document).on('change', 'select', function () {
        let selectIdentifier = $(this).attr('name') || $(this).attr('id') || 'Dropdown';
        let selectedText = $(this).find('option:selected').text().trim();
        sendLog('change', {
            changed_element: selectIdentifier,
            new_value: selectedText
        });
    });

});

// ===m=== Time Spent Tracking Started ===m===
const _sessionStart = Date.now();

function _sendTimeSpent() {
    const seconds = Math.round((Date.now() - _sessionStart) / 1000);
    if (seconds < 2) return; // ignore accidental closes
    navigator.sendBeacon("datalog.php", JSON.stringify({
        event: "time_spent",
        label: "session_duration",
        tag: "",
        id: "",
        class: "",
        href: "",
        page: location.pathname,
        session_id: localStorage.session_id,
        campaignsource: campaignsource,
        campaignsubsource: campaignsubsource,
        client_os: accurateOS,
        client_model: accurateModel,
        time_spent: seconds
    }));
}

// Covers tab close, browser close, navigation away
window.addEventListener("beforeunload", _sendTimeSpent);

// Covers tab switch, phone lock screen, swipe away on mobile
document.addEventListener("visibilitychange", function () {
    if (document.visibilityState === "hidden") _sendTimeSpent();
});

// Covers iOS Safari which doesn't fire beforeunload reliably
window.addEventListener("pagehide", _sendTimeSpent);
// ===m=== Time Spent Tracking Ended ===m===

