<!--
=========================================================
* Paper Dashboard 2 - v2.0.1
=========================================================

* Product Page: https://www.creative-tim.com/product/paper-dashboard-2
* Copyright 2020 Creative Tim (https://www.creative-tim.com)

Coded by www.creative-tim.com

 =========================================================

* The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
-->

<?php
session_start();
include __DIR__ . '/core/db_controller/db.php';
require_once __DIR__ . '/leads/header.php';
require_once __DIR__ . '/core/config.php';

if (!isset($_SESSION["user_logged"]) || $_SESSION["user_logged"] != "Y")
{
  header("Location: login.php");
  exit;
}

$username = $_SESSION['username'] ?? 'Admin';
$role = $_SESSION['role'] ?? 'admin';

?>

<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <link rel="apple-touch-icon" sizes="76x76" href="./assets/img/apple-icon.png">

  <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css" />
  <link rel="icon" type="image/png" href="./assets/img/favicon.png">

  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <title>
    Webzaa Admin | <?php echo PROJECT_NAME; ?>
  </title>
  <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no'
    name='viewport' />
  <!--     Fonts and icons     -->
  <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
  <link href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
  <!-- CSS Files -->
  <link href="./assets/css/bootstrap.min.css" rel="stylesheet" />
  <link href="./assets/css/paper-dashboard.css?v=2.0.1" rel="stylesheet" />
  <!-- CSS Just for demo purpose, don't include it in your project -->
  <link href="./assets/demo/demo.css" rel="stylesheet" />
  <link href="./assets/css/style.css" rel="stylesheet" />
  <style type="text/css">
    /* Style the tab */
    .tab {
      overflow: hidden;
      border: 1px solid #ccc;
      background-color: #f1f1f1;
    }

    /* Style the buttons inside the tab */
    .tab button {
      background-color: inherit;
      float: left;
      border: none;
      outline: none;
      cursor: pointer;
      padding: 14px 16px;
      transition: 0.3s;
      font-size: 17px;
    }

    /* Change background color of buttons on hover */
    .tab button:hover {
      background-color: #ddd;
    }

    /* Create an active/current tablink class */
    .tab button.active {
      background-color: #ccc;
    }

    /* Style the tab content */
    .tabcontent {
      display: none;
      padding: 6px 12px;
      border: 1px solid #ccc;
      border-top: none;
    }
  </style>
  <style>
    .ui-accordion .ui-accordion-header {
      display: block;
      cursor: pointer;
      position: relative;
      margin: 2px 0 0 0;

      min-height: 0;
      /* support: IE7 */
      font-size: 100%;
      border: 1px solid #FDF8E4;
      background: #846733;
      color: #fff;
    }

    .error {
      border-color: red;
    }
  </style>
</head>


<body class="">
  <form action="./leads/export.php" id="export_form" method="POST">
    <input type="hidden" id="till_date_form" name="till_date">
    <input type="hidden" id="from_date_form" name="from_date">
    <input type="hidden" id="to_date_form" name="to_date">
    <input type="hidden" id="camp_source_form" name="camp_source">
    <input type="hidden" id="Campaign_sub_source_form" name="Campaign_sub_source">
    <input type="hidden" id="keyword_form" name="keyword">

  </form>

  <form action="./leads/add-lead.php" id="edit_form" method="POST">
    <input type="hidden" id="mobile_edit" name="mobile">
  </form>

  <div class="wrapper ">
    <!-- ===m=== Sidebar code started ===m=== -->
    <div class="sidebar" data-color="white" data-active-color="danger">
      <div class="logo">
        <a href="index.php" class="simple-text logo-normal">
          <div class="logo-image-big pl-5">
            <img src="./assets/images/webzaa-logo.png">
          </div>
        </a>
      </div>
      <div class="sidebar-wrapper">
        <ul class="nav">
          <li class="active ">
            <a href="index.php">
              <span class="iconify" data-icon="ri:dashboard-fill"
                style="font-size:24px;float:left;margin-right:12px;line-height:30px;width:34px;text-align:center;position:relative;"></span>
              <p>Dashboard</p>
            </a>
          </li>
          <li class="">
            <a href="analytics.php">
              <i class="nc-icon nc-chart-pie-36"></i>
              <p>Analytics</p>
            </a>
          </li>
          <li class="">
            <a href="restricted_ips.php">
              <i class="nc-icon nc-lock-circle-open"></i>
              <p>Restricted IP'S</p>
            </a>
          </li>
          <li class="">
            <a href="meta_capi.php">
              <span class="iconify" data-icon="ri:meta-fill"
                style="font-size:24px;float:left;margin-right:12px;line-height:30px;width:34px;text-align:center;position:relative;"></span>
              <p>Meta CAPI</p>
            </a>
          </li>
          <li class="">
            <a href="import.php">
              <i class="nc-icon nc-cloud-upload-94"></i>
              <p>Import</p>
            </a>
          </li>
          <!--  <li>
            <a href="javascript:;">
              <i class="nc-icon nc-diamond"></i>
              <p>Users</p>
            </a>
          </li> -->
          <!-- <li>
            <a href="javascript:;">
              <i class="nc-icon nc-pin-3"></i>
              <p>Facebook Leads Form</p>
            </a>
          </li> -->
        </ul>
      </div>
    </div>
    <div class="main-panel" style="height: 100vh;">
      <!-- ===m=== Sidebar code started ===m=== -->
      <!-- Navbar -->
      <nav class="navbar navbar-expand-lg navbar-absolute fixed-top navbar-transparent">
        <div class="container-fluid">
          <div class="navbar-wrapper">
            <div class="navbar-toggle">
              <button type="button" class="navbar-toggler">
                <span class="navbar-toggler-bar bar1"></span>
                <span class="navbar-toggler-bar bar2"></span>
                <span class="navbar-toggler-bar bar3"></span>
              </button>
            </div>
            <a class="navbar-brand"
              href="javascript:;"><?php echo $greeting . ', ' . htmlspecialchars($username); ?></a>
          </div>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navigation"
            aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-bar navbar-kebab"></span>
            <span class="navbar-toggler-bar navbar-kebab"></span>
            <span class="navbar-toggler-bar navbar-kebab"></span>
          </button>
          <div class="collapse navbar-collapse justify-content-end" id="navigation">
            <form>
              <div class="input-group no-border">
                <!--   <input type="text" value="" class="form-control" placeholder="Search...">
                <div class="input-group-append">
                  <div class="input-group-text">
                    <i class="nc-icon nc-zoom-split"></i>
                  </div>
                </div>
              </div> -->
            </form>
            <ul class="navbar-nav">
              <li class="nav-item btn-rotate dropdown">
                <a class="nav-link dropdown-toggle" href="" id="navbarDropdownMenuLink" data-toggle="dropdown"
                  aria-haspopup="true" aria-expanded="false">
                  <p>
                    <span class="d-lg-none d-md-block">Actions</span>
                  </p>
                </a>
                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownMenuLink">
                  <!-- <a class="dropdown-item" href="#">Action</a>
                  <a class="dropdown-item" href="#">Another action</a> -->
                  <a class="dropdown-item" href="./leads/logout.php">Logout</a>
                  <?php if (isset($_SESSION['role']) && $_SESSION['role'] == 'superadmin')
                  { ?>
                    <a class="dropdown-item" href="./leads/users.php">Add Users</a>
                  <?php } ?>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </nav>
      <!-- End Navbar -->
      <div class="content">
        <div class="row">
          <div class="col-md-12">
            <h3 class="description">Dashboard</h3>
          </div>
          <div class="col-md-12 row">
            <div class="form-group col-md-3">
              <label for="from_date">Date:</label>
              <input type="text" class="form-control" placeholder="dd-mm-yyyy" id="from_date">
              <input type="checkbox" style="margin-left: 2px;margin-top: 5px;" id="till_date" value="1"> <label>Till
                Date</label>
            </div>
            <!--    <div class="form-group col-md-3">
                <label for="to_date">To date:</label>
                <input type="text" class="form-control" placeholder="dd-mm-yyyy" id="to_date">
              </div> -->
            <div class="form-group col-md-3">
              <label for="camp_source">Campaign Source:</label>
              <select class="form-control" id="camp_source">
                <option value="">All</option>
                <?php
                $res = mysqli_query($conn, "SELECT DISTINCT campaignsource FROM `lead`");
                while ($row = mysqli_fetch_array($res))
                {
                  ?>
                  <option value="<?php echo $row['campaignsource'] ?>">
                    <?php
                    echo $row["campaignsource"]
                      ?>

                  </option>
                <?php } ?>
              </select>
            </div>
            <div class="form-group col-md-3">
              <label for="Campaign_sub_source">Campaign Subsource:</label>
              <select class="form-control" id="Campaign_sub_source">
                <option value="">All</option>

                <?php
                $res = mysqli_query($conn, "SELECT DISTINCT campaignsubsource FROM `lead`");
                while ($row = mysqli_fetch_array($res))
                {
                  ?>
                  <option value="<?php echo $row['campaignsubsource'] ?>">
                    <?php
                    echo $row["campaignsubsource"]
                      ?>

                  </option>
                <?php } ?>
              </select>
            </div>

            <div class="form-group col-md-3">
              <label for="keyword">Search By:</label>
              <input type="text" class="form-control" id="keyword" placeholder="Name/Mobile/Email/keyword">
            </div>

            <div class="form-group col-md-12">
              <label for="Search"></label>
              <button class="btn btn-primary" id="reset" style="color: white;background: #424240;float:right;"> Reset
              </button>
              <button class="btn btn-primary" id="search" style="color: white;background: #424240;float:right;"><i
                  class="fa fa-search"></i>&nbsp Search </button>
            </div>

            <!--  <div class="form-group col-md-3">
                <label for="Reset"></label>
                
              </div>  -->

            <!--     <div class="form-group col-md-3">
                <label for="Reset"></label>
                <button class="btn btn-primary form-control" id="export"  style="color: white;background: #424240;"> export </button>
              </div>  -->
          </div>

          <div class="col-md-12">
            <div class="tab">
              <button class="tablinks active" onclick="openCity(event, 'Visualization')">Visualization</button>
              <button class="tablinks" onclick="openCity(event, 'Leads')">Leads</button>
              <button class="tablinks" id="follow_up" onclick="openCity(event, 'followup')">Todays Followup</button>
            </div>

            <div id="Visualization" class="tabcontent" style="display: block;">
              <h3>Visualization</h3>

              <div class="col-lg-12 row">
                <div class="col-lg-6" id="container" style="height: 400px;width: 100%;"></div>
                <div class="col-lg-6" id="container_2" style="height: 400px;width: 100%;"></div>
                <div class="col-lg-12" id="container_3" style="height: 300px;width: 100%;margin-top: 10px;"></div>
              </div>
            </div>
            <div id="Leads" class="tabcontent">
              <div class="row col-md-12">
                <div class="col-md-6">
                  <h3>Leads</h3>
                </div>
                <div class="col-md-6">
                  <button class="btn btn-primary" id="export" style="color: white;background: #424240;float:right;">
                    export </button>
                  <a class="btn btn-primary" style="color: white;background: #424240;float:right;"
                    href="./leads/add-lead.php">Add Lead</a>
                </div>
              </div>

              <table class="display table" id="showRecords">
                <thead>
                  <tr>

                    <th data-priority="1">Sr.No.</th>
                    <th data-priority="2">Date</th>
                    <th data-priority="3">Name</th>
                    <th data-priority="4">Email</th>
                    <th data-priority="6">Mobile</th>
                    <th data-priority="7">CRUD</th>

                    <!-- <th data-priority="1">Sr.No.</th>
                                      <th data-priority="2">Date</th>
                                      <th data-priority="3">Name</th>
                                      <th data-priority="4">Email</th>
                                      <th data-priority="5">Country code</th>
                                      <th data-priority="6">Mobile</th>
                                      <th data-priority="7">Campaign source</th>
                                      <th data-priority="8">Campaign subsource</th>
                                      <th data-priority="9">Keyword</th>
                                      <th data-priority="10">Capture from name</th>
                                      <th data-priority="11">Website name</th>
                                      <th data-priority="12">Created date</th>
                                      <th data-priority="13">UTMM</th>
                                      <th data-priority="14">UTMC</th>
                                      <th data-priority="15">Duplicate</th>
                                      <th data-priority="16">Reason</th>
                                      <th data-priority="17">CRUD</th> -->
                  </tr>
                </thead>
                <tbody class="body-data">

                </tbody>
              </table>

              <!-- <div class="body-data"></div> -->
              <div class="pagination-div"></div>
            </div>

            <div id="followup" class="tabcontent">
              <h3>Todays Folllowup</h3>
              <table class="display table" id="showRecords">
                <thead>
                  <tr>

                    <th data-priority="1">Sr.No.</th>
                    <th data-priority="2">Date</th>
                    <th data-priority="3">Name</th>
                    <th data-priority="4">Email</th>
                    <th data-priority="6">Mobile</th>
                    <th data-priority="7">CRUD</th>
                    <!-- <th data-priority="1">Sr.No.</th>
                                      <th data-priority="2">Date</th>
                                      <th data-priority="3">Name</th>
                                      <th data-priority="4">Email</th>
                                      <th data-priority="5">Countrycode</th>
                                      <th data-priority="6">Mobile</th>
                                      <th data-priority="7">Campaignsource</th>
                                      <th data-priority="8">Campaignsubsource</th>
                                      <th data-priority="9">Keyword</th>
                                      <th data-priority="10">Capturefromname</th>
                                      <th data-priority="11">Websitename</th>
                                      <th data-priority="12">Createddate</th>
                                      <th data-priority="13">UTMM</th>
                                      <th data-priority="14">UTMC</th>
                                      <th data-priority="15">Duplicate</th>
                                      <th data-priority="16">Reason</th>
                                      <th data-priority="17">CRUD</th> -->
                  </tr>
                </thead>
                <tbody class="body-data-followup">

                </tbody>
              </table>

              <!-- <div class="body-data"></div> -->
              <!--  <div class="pagination-div"></div> -->
            </div>


          </div>
        </div>
      </div>

    </div>
  </div>

  <!-- The Modal -->
  <div class="modal" id="myModal">
    <div class="modal-dialog">
      <div class="modal-content">

        <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-title">Curd</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>

        <!-- Modal body -->
        <div class="modal-body">
          <div class="col-md-12 row">
            <div class="form-group col-md-12">
              <label for="result">Result:</label>
              <select class="form-control" id="result">
                <option>Select Reason</option>
                <option>Call Back</option>
                <option>Call Not Answer</option>
                <option>Interested</option>
                <option>Wrong Number</option>
                <option>Not Interested</option>
              </select>
            </div>
            <div class="form-group col-md-12">
              <label for="comment">Comments:</label>
              <textarea class="form-control" rows="4" cols="50" placeholder="Add Comments..." id="comment">  </textarea>
            </div>
            <div class="form-group col-md-12">
              <label for="followup_date">Followup Date:</label>
              <input class="form-control" type="datetime-local" id="followup_date" name="followup_date">
              <input type="hidden" id="id" value="0">
            </div>

            <div class="form-group col-md-12">
              <button class="btn btn-primary form-control" id="add_result" style="color: white;background: #424240;">
                ADD</button>
            </div>

          </div>
        </div>

        <!-- Modal footer -->
        <div class="modal-footer">
          <!-- <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button> -->
        </div>

      </div>
    </div>
  </div>



  <!-- The Modal -->
  <div class="modal" id="modal_history">
    <div class="modal-dialog">
      <div class="modal-content">

        <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-title">Curd</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>

        <!-- Modal body -->
        <div class="modal-body">
          <div class="col-md-12 row">
            <table class="">
              <thead>
                <th>Sr No</th>
                <th>Result</th>
                <th>Comments</th>
                <th>Followup date</th>
                <th>Created date</th>
              </thead>
              <tbody class="body-logs">

              </tbody>
            </table>

          </div>
        </div>

        <!-- Modal footer -->
        <div class="modal-footer">
          <!-- <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button> -->
        </div>

      </div>
    </div>
  </div>






  <!--   Core JS Files   -->
  <link rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/css/bootstrap-datepicker.css"
    integrity="sha512-Fppbdpv9QhevzDE+UHmdxL4HoW8HantO+rC8oQB2hCofV+dWV2hePnP5SgiWR1Y1vbJeYONZfzQc5iII6sID2Q=="
    crossorigin="anonymous" referrerpolicy="no-referrer" />

  <script src="./assets/js/core/jquery.min.js"></script>
  <script src="https://code.jquery.com/ui/1.13.2/jquery-ui.min.js"></script>
  <script type="text/javascript" src="https://cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>
  <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js"></script>
  <script src="assets/js/highcharts/highcharts.js"></script>
  <script src="assets/js/highcharts/data.js"></script>
  <script src="assets/js/highcharts/drilldown.js"></script>
  <script src="assets/js/highcharts/exporting.js"></script>
  <script src="assets/js/highcharts/export-data.js"></script>
  <script src="assets/js/highcharts/accessibility.js"></script>
  <script src="https://code.iconify.design/3/3.1.1/iconify.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/js/bootstrap-datepicker.min.js"
    integrity="sha512-T/tUfKSV1bihCnd+MxKD0Hm1uBBroVYBOYSk1knyvQ9VyZJpc/ALb4P0r6ubwVPSGB2GvjeoMAJJImBG12TiaQ=="
    crossorigin="anonymous" referrerpolicy="no-referrer"></script>
  <script src="https://cdn.datatables.net/v/dt/dt-1.10.20/datatables.min.js"></script>
  <script src="https://cdn.datatables.net/buttons/1.6.1/js/dataTables.buttons.min.js"></script>
  <script src="https://cdn.datatables.net/buttons/1.6.1/js/buttons.flash.min.js"></script>
  <script src="https://cdn.datatables.net/buttons/1.6.1/js/buttons.html5.min.js"></script>
  <script src="https://cdn.datatables.net/buttons/1.6.1/js/buttons.print.min.js"></script>
  <script src="https://cdn.datatables.net/fixedcolumns/3.3.0/js/dataTables.fixedColumns.min.js"></script>
  <script src="https://cdn.datatables.net/colreorder/1.5.2/js/dataTables.colReorder.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/paginationjs/2.1.5/pagination.min.js"
    integrity="sha512-1zzZ0ynR2KXnFskJ1C2s+7TIEewmkB2y+5o/+ahF7mwNj9n3PnzARpqalvtjSbUETwx6yuxP5AJXZCpnjEJkQw=="
    crossorigin="anonymous" referrerpolicy="no-referrer"></script>
  <script src="./assets/js/core/popper.min.js"></script>
  <script src="./assets/js/core/bootstrap.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.perfect-scrollbar/1.5.5/perfect-scrollbar.min.js"
    integrity="sha512-X41/A5OSxoi5uqtS6Krhqz8QyyD8E/ZbN7B4IaBSgqPLRbWVuXJXr9UwOujstj71SoVxh5vxgy7kmtd17xrJRw=="
    crossorigin="anonymous" referrerpolicy="no-referrer"></script>
  <!--  Google Maps Plugin    -->
  <!-- <script src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script> -->
  <!-- Chart JS -->
  <script src="./assets/js/plugins/chartjs.min.js"></script>
  <!--  Notifications Plugin    -->
  <script src="./assets/js/plugins/bootstrap-notify.js"></script>
  <!-- Control Center for Now Ui Dashboard: parallax effects, scripts for the example pages etc -->
  <script src="./assets/js/paper-dashboard.min.js?v=2.0.1" type="text/javascript"></script>
  <script type="text/javascript">
    //   $('#from_date').datepicker({
    //     changeMonth: true,
    //     changeYear: true,
    //     showButtonPanel: true,
    //     autoclose:true,
    //     format: 'dd-mm-yyyy'
    // });
    //    $('#to_date').datepicker({
    //     changeMonth: true,
    //     changeYear: true,
    //     showButtonPanel: true,
    //     autoclose:true,
    //     format: 'dd-mm-yyyy'
    // });
    // $('#followup_date').datetimepicker();

    var start = moment().subtract(6, 'days');
    var end = moment();

    function cb(start, end) {
      $('#from_date span').html(start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'));
    }

    $('#from_date').daterangepicker({
      startDate: start,
      endDate: end,

      locale: {
        format: 'DD/MM/YYYY'
      },
      ranges: {
        'Today': [moment(), moment()],
        'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
        'Last 7 Days': [moment().subtract(6, 'days'), moment()],
        'Last 30 Days': [moment().subtract(29, 'days'), moment()],
        'This Month': [moment().startOf('month'), moment().endOf('month')],
        'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
      }
    }, cb);

    cb(start, end);


    $(document).on('click', '#reset', function () {

      $('input').val('');

    })

    $(document).on('click', '#follow_up', function () {

      get_todays_followup();

    })
    get_data('', '', '', '', '1', '');
    pagination('', '', '', '', '');
    get_records('1');

    $(document).on('click', '#search', function () {

      var from_date = $("#from_date").val();
      var camp_source = $("#camp_source").val();
      var Campaign_sub_source = $("#Campaign_sub_source").val();
      var keyword = $("#keyword").val();
      var id = '1';
      var till_date = '';
      if ($('#till_date').is(':checked')) {
        till_date = 1;
      }
      get_data(from_date, camp_source, Campaign_sub_source, keyword, id, till_date);
      pagination(from_date, camp_source, Campaign_sub_source, keyword, till_date);
      get_records(id);

    })

    function pagination(from_date, camp_source, Campaign_sub_source, keyword, till_date) {
      $.ajax({
        url: 'leads/pagination.php',
        type: 'POST',
        cache: false,
        data: {
          from_date: from_date,
          camp_source: camp_source,
          Campaign_sub_source: Campaign_sub_source,
          keyword: keyword,
          till_date: till_date

        },
        success: function (returnhtml) {

          $(".pagination-div").html(returnhtml);



        }
      })
    }

    // $( ".body-data" ).accordion({
    //   collapsible: true
    // });


    function get_data(from_date, camp_source, Campaign_sub_source, keyword, page, till_date) {

      $.ajax({
        url: 'leads/get_data.php',
        type: 'POST',
        dataType: "json",
        data: {
          from_date: from_date,
          camp_source: camp_source,
          Campaign_sub_source: Campaign_sub_source,
          keyword: keyword,
          page: page,
          till_date: till_date

        },
        cache: false,
        beforeSend: function () {
          $("#container").html('<img src="assets/loader.gif" style="width:100px;text-align:center;">');
        },
        success: function (returnhtml) {
          //$("#container").html('');  
          //console.log(returnhtml.rowsChartDrilldown6) ;   
          let total = 0;
          let total_form = 0;
          $.each(returnhtml.rowsChart6, function (arr, i) {
            total = parseInt(total) + parseInt(i.y);
          })
          $.each(returnhtml.rowschart5, function (arr, i) {
            total_form = parseInt(total_form) + parseInt(i.y);
          })
          console.log(returnhtml.rowsChart6.length);

          //PieChartCombined(returnhtml,total); 
          if (returnhtml.rowsChart6.length > 0) {
            PieChartCombined(returnhtml, total);
          } else {
            $("#container").html('<span style="text-align: center;padding-top: 15%;">No record found.</span>');
          }


          if (returnhtml.rowsChart13.length > 0) {
            get_column_by_date(returnhtml.rowsChart13);
          } else {
            $("#container_3").html('<span style="text-align: center;padding-top: 15%;">No record found.</span>');
          }


          if (returnhtml.rowschart5.length > 0) {
            PieChartForms(returnhtml.rowschart5, total_form);
          } else {
            $("#container_2").html('<span style="text-align: center;padding-top: 15%;">No record found.</span>');
          }
          get_records('1');

        }
      });
      // body...
    }

    function transformEntry(item, type) {
      switch (type) {
        case 'email':
          var parts = item.split("@"),
            len = parts[0].length;
          return email.replace(parts[0].slice(1, -1), "*".repeat(len - 2));
        case 'phone':
          return "*".repeat(item.length - 4) + item.slice(-5);
        default:
          throw new Error("Undefined type: " + type);
      }
    }

    function get_records(id) {
      var from_date = $("#from_date").val();
      var camp_source = $("#camp_source").val();
      var Campaign_sub_source = $("#Campaign_sub_source").val();
      var keyword = $("#keyword").val();
      var till_date = '';
      if ($('#till_date').is(':checked')) {
        till_date = 1;
      }

      $.ajax({
        url: 'leads/get_records.php',
        type: 'POST',
        dataType: "json",
        data: {
          from_date: from_date,
          camp_source: camp_source,
          Campaign_sub_source: Campaign_sub_source,
          keyword: keyword,
          page: id,
          till_date: till_date
        },
        cache: false,
        success: function (returnhtml) {
          //console.log(returnhtml) ;   
          var html = '';
          var cnt = (parseInt(id) - parseInt(1)) * parseInt(50) + parseInt(1);
          $.each(returnhtml, function (arr, i) {


            var maskid = "";
            var myemailId = i.email;
            var prefix = myemailId.substring(0, myemailId.lastIndexOf("@"));
            var postfix = myemailId.substring(myemailId.lastIndexOf("@"));

            for (var j = 0; j < prefix.length; j++) {
              if (j == 0 || j == prefix.length - 1) { ////////
                maskid = maskid + prefix[j].toString();
              } else {
                maskid = maskid + "*";
              }
            }
            maskid = maskid + postfix;

            //console.log(i.mobile);
            var mobile = '';
            if (i.mobile != '' && i.mobile.length >= 7) {
              mobile = transformEntry(i.mobile, 'phone')
            }

            var finalEmail = (i.allow_email === 'Y') ? i.email : maskid;
            var finalMobile = (i.allow_mobile === 'Y') ? i.mobile : mobile;

            html += ' <tr data-toggle="collapse" data-target="#demo' + i.id + '" class="accordion-toggle">';
            html += ' <td>' + cnt + '</td>';
            html += ' <td>' + i.createddate + '</td>';
            html += ' <td>' + i.name + '</td>';
            html += ' <td>' + finalEmail + '</td>';
            html += ' <td>' + finalMobile + '</td>';
            html += ' <td><button data-id="' + i.mobile + '" class="btn btn-primary btn-sm" style="color: white;background: #424240;margin-right: 5px;" id="edit_lead" data-toggle="tooltip" data-html="true" title="Edit Lead"><i class="fa fa-edit"></i></button><button data-id="' + i.mobile + '" class="btn btn-primary btn-sm" style="color: white;background: #424240;margin-right: 5px;"  data-toggle="modal" data-target="#myModal" id="add" data-toggle="tooltip" data-html="true" title="Add Response"><i class="fa fa-plus"> </i></button><button  data-id="' + i.mobile + '" data-toggle="modal" data-target="#modal_history" style="color: white;background: #424240;" class="btn btn-primary btn-sm" id="history" data-toggle="tooltip" data-html="true" title="View History"><i class="fa fa-history"></i></button></td> ';
            html += '</tr>';
            html += '<tr class="p">';
            html += '  <td colspan="6" class="hiddenRow" style="text-align: left;">';
            html += '     <div class="accordian-body collapse" id="demo' + i.id + '">';
            html += '      <p class="col-lg-4" style="float: left;"><strong>Campaign Source : </strong><span>' + i.campaignsource + '</span></p>';
            html += '      <p class="col-lg-4" style="float: left;"><strong>Campaign Sub Source : </strong><span>' + i.campaignsubsource + '</span> </p>';
            html += '      <p class="col-lg-4" style="float: left;"><strong>Keyword : </strong><span>' + i.keyword + '</span> </p>';
            html += '      <p class="col-lg-4" style="float: left;"><strong>Placement : </strong><span>' + i.placement + '</span> </p>';
            html += '      <p class="col-lg-4" style="float: left;"><strong>IP Address : </strong><span>' + i.ip_address + '</span> </p>';
            html += '      <p class="col-lg-4" style="float: left;"><strong>MF Medium : </strong><span>' + i.mf_medium + '</span> </p>';
            html += '      <p class="col-lg-4" style="float: left;"><strong>MF Campaign ID : </strong><span>' + i.mf_campaignid + '</span> </p>';
            html += '      <p class="col-lg-4" style="float: left;"><strong>Ad Set : </strong><span>' + i.adset + '</span> </p>';
            html += '      <p class="col-lg-4" style="float: left;"><strong>Ad Creative : </strong><span>' + i.adcreative + '</span> </p>';
            html += '      <p class="col-lg-4" style="float: left;"><strong>Device : </strong><span>' + i.device + '</span> </p>';
            html += '      <p class="col-lg-4" style="float: left;"><strong>Capture Form Name : </strong><span>' + i.capturefromname + '</span> </p>'
            html += '      <p class="col-lg-4" style="float: left;"><strong>Website Name : </strong><span>' + i.websitename + '</span></p>';
            html += '      <p class="col-lg-4" style="float: left;"><strong>utmM : </strong><span>' + i.utmM + '</span></p>';
            html += '      <p class="col-lg-4" style="float: left;"><strong>utmC : </strong><span>' + i.utmC + '</span></p>';
            html += '      <p class="col-lg-4" style="float: left;"><strong>Duplicate : </strong><span>' + i.duplicate + '</span></p>';
            html += '      <p class="col-lg-4" style="float: left;"><strong>Reason : </strong><span>' + i.reason + '</span></p>';
            html += '      <p class="col-lg-4" style="float: left;"><strong>Bhk Type : </strong><span>' + i.bhktype + '</span></p>';
            html += '      <p class="col-lg-4" style="float: left;"><strong>Purpose : </strong><span>' + i.purpose + '</span></p>';
            html += '      <p class="col-lg-4" style="float: left;"><strong>Visit Possible On : </strong><span>' + i.visitpossibleon + '</span></p>';
            html += '      <p class="col-lg-4" style="float: left;"><strong>Fav. Destination : </strong><span>' + i.favdestination + '</span></p>';
            html += '      <p class="col-lg-4" style="float: left;"><strong>Villa Type : </strong><span>' + i.villatype + '</span></p>';
            html += '      <p class="col-lg-4" style="float: left;"><strong>Project  Interest : </strong><span>' + i.projinterest + '</span></p>';
            html += '      <p class="col-lg-4" style="float: left;"><strong>Form Id : </strong><span>' + i.form_id + '</span></p>';
            html += '      <p class="col-lg-4" style="float: left;"><strong>Ad Id : </strong><span>' + i.ad_id + '</span></p>';
            html += '      <p class="col-lg-4" style="float: left;"><strong>Leadgen Id : </strong><span>' + i.leadgen_id + '</span></p>';
            html += '      <p class="col-lg-4" style="float: left;"><strong>Page Id : </strong><span>' + i.page_id + '</span></p>';
            //html+= '      <p class="col-lg-4" style="float: left;"><strong>Ad Id : </strong><span>'+i.ad_id+'</span></p>';
            html += '     </div>';
            html += '  </td>';
            html += '</tr>';

            // html+= ' <tr>';
            // html+= ' <td>'+cnt+'</td>';
            // html+= ' <td>'+i.createddate+'</td>';
            // html+= ' <td>'+i.name+'</td>';
            // html+= ' <td>'+i.email+'</td>';
            // html+= ' <td>'+i.countrycode+'</td>';
            // html+= ' <td>'+i.mobile+'</td>';
            // html+= ' <td>'+i.campaignsource+'</td>';
            // html+= ' <td>'+i.campaignsubsource+'</td>';
            // html+= ' <td>'+i.keyword+'</td>';
            // html+= ' <td>'+i.capturefromname+'</td>';
            // html+= ' <td>'+i.websitename+'</td>';
            // html+= ' <td>'+i.createddate+'</td>';
            // html+= ' <td>'+i.utmM+'</td>';
            // html+= ' <td>'+i.utmC+'</td>';
            // html+= ' <td>'+i.duplicate+'</td>'; 
            // html+= ' <td>'+i.reason+'</td>';
            // html+= ' <td><button data-id="'+i.mobile+'" class="btn btn-primary btn-sm" style="color: white;background: #424240;margin-right: 5px;"  data-toggle="modal" data-target="#myModal" id="add"><i class="fa fa-plus"> </i></button><button  data-id="'+i.mobile+'" data-toggle="modal" data-target="#modal_history" style="color: white;background: #424240;" class="btn btn-primary btn-sm" id="history"><i class="fa fa-history"></i></button></td> ';
            // html+= '</tr>';
            cnt++;
          })

          html += '</tr>';
          $(".body-data").html(html);


        }
      });
    }

    get_todays_followup();

    function get_todays_followup() {

      $.ajax({
        url: 'leads/get_followups.php',
        type: 'POST',
        dataType: "json",
        cache: false,
        success: function (returnhtml) {
          //console.log(returnhtml) ;   
          var html = '';
          var cnt = 0;
          $.each(returnhtml, function (arr, i) {
            cnt++;
            html += ' <tr data-toggle="collapse" data-target="#followup' + i.id + '" class="accordion-toggle">';
            html += ' <td>' + cnt + '</td>';
            html += ' <td>' + i.createddate + '</td>';
            html += ' <td>' + i.name + '</td>';
            html += ' <td>' + i.email + '</td>';
            html += ' <td>' + i.mobile + '</td>';
            html += ' <td><button data-id="' + i.mobile + '" class="btn btn-primary btn-sm" style="color: white;background: #424240;margin-right: 5px;"  data-toggle="modal" data-target="#myModal" id="add" data-toggle="tooltip" data-html="true" title="Add Response"><i class="fa fa-plus"> </i></button><button  data-id="' + i.mobile + '" data-toggle="modal" data-target="#modal_history" style="color: white;background: #424240;" class="btn btn-primary btn-sm" id="history" data-toggle="tooltip" data-html="true" title="View History"><i class="fa fa-history"></i></button></td> ';
            html += '</tr>';
            html += '<tr class="p">'
            html += '  <td colspan="6" class="hiddenRow" style="text-align: left;">'
            html += '     <div class="accordian-body collapse" id="followup' + i.id + '">'

            html += '      <p class="col-lg-4" style="float: left;"><strong>Reason : </strong><span>' + i.reason + '</span></p>'
            html += '      <p class="col-lg-4" style="float: left;"><strong>comment : </strong><span>' + i.comment + '</span></p>'
            html += '     </div>'
            html += '  </td>'
            html += '</tr>';
            // html+= ' <tr>';
            // html+= ' <td>'+cnt+'</td>';
            // html+= ' <td>'+i.createddate+'</td>';
            // html+= ' <td>'+i.name+'</td>';
            // html+= ' <td>'+i.email+'</td>';
            // html+= ' <td>'+i.countrycode+'</td>';
            // html+= ' <td>'+i.mobile+'</td>';
            // html+= ' <td>'+i.campaignsource+'</td>';
            // html+= ' <td>'+i.campaignsubsource+'</td>';
            // html+= ' <td>'+i.keyword+'</td>';
            // html+= ' <td>'+i.capturefromname+'</td>';
            // html+= ' <td>'+i.websitename+'</td>';
            // html+= ' <td>'+i.createddate+'</td>';
            // html+= ' <td>'+i.utmM+'</td>';
            // html+= ' <td>'+i.utmC+'</td>';
            // html+= ' <td>'+i.duplicate+'</td>'; 
            // html+= ' <td>'+i.reason+'</td>';
            // html+= ' <td><button data-id="'+i.mobile+'" class="btn btn-primary btn-sm" style="color: white;background: #424240;margin-right: 5px;"  data-toggle="modal" data-target="#myModal" id="add"><i class="fa fa-plus"> </i></button><button  data-id="'+i.mobile+'" data-toggle="modal" data-target="#modal_history" style="color: white;background: #424240;" class="btn btn-primary btn-sm" id="history"><i class="fa fa-history"></i></button></td> ';
            // html+= '</tr>';
          })

          html += '</tr>';
          $(".body-data-followup").html(html);


        }
      });
    }

    ////=====A=======As Per analytics=====
    function PieChartCombined(returnhtml, total) {
      var rowsChart6 = returnhtml.rowsChart6;
      var rowsChartDrilldown6 = returnhtml.rowsChartDrilldown6;

      // Build orange shades like analytics.php
      var values = rowsChart6.map(p => p.y);
      var minVal = Math.min(...values);
      var maxVal = Math.max(...values);

      function getOrangeShade(value, min, max) {
        if (max === min) return 'rgba(232,78,36,0.7)';
        var ratio = (value - min) / (max - min);
        var opacity = 0.25 + (ratio * 0.75);
        return 'rgba(232,78,36,' + opacity + ')';
      }

      var dataWithColors = rowsChart6.map(function (point) {
        return {
          name: point.name,
          y: point.y,
          drilldown: point.drilldown,
          color: getOrangeShade(point.y, minVal, maxVal)
        };
      });

      Highcharts.chart('container', {
        chart: {
          type: 'pie'
        },
        title: {
          text: 'Leads'
        },
        tooltip: {
          pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
        },
        accessibility: {
          announceNewData: {
            enabled: true
          },
          point: {
            valueSuffix: '%'
          }
        },
        plotOptions: {
          pie: {
            allowPointSelect: true,
            cursor: 'pointer',
            dataLabels: {
              enabled: false,
              format: '<b>{point.name}</b><br>{point.percentage:.1f} %',
              distance: -50,
              filter: {
                property: 'percentage',
                operator: '>',
                value: 4
              }
            },
            showInLegend: true
          }
        },
        legend: {
          labelFormatter: function () {
            return this.name + ' (' + (this.y / total * 100).toFixed(2) + '%)';
          }
        },
        series: [{
          name: 'Leads',
          colorByPoint: false,
          data: dataWithColors
        }],
        drilldown: {
          series: rowsChartDrilldown6
        },
        credits: {
          enabled: false
        }
      });
    }

    function PieChartForms(data, total) {
      var values = data.map(p => p.y);
      var minVal = Math.min(...values);
      var maxVal = Math.max(...values);

      function getOrangeShade(value, min, max) {
        if (max === min) return 'rgba(232,78,36,0.7)';
        var ratio = (value - min) / (max - min);
        var opacity = 0.25 + (ratio * 0.75);
        return 'rgba(232,78,36,' + opacity + ')';
      }

      var dataWithColors = data.map(function (point) {
        return {
          name: point.name,
          y: point.y,
          color: getOrangeShade(point.y, minVal, maxVal)
        };
      });

      Highcharts.chart('container_2', {
        chart: {
          type: 'pie'
        },
        title: {
          text: 'Leads by forms'
        },
        tooltip: {
          pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
        },
        accessibility: {
          announceNewData: {
            enabled: true
          },
          point: {
            valueSuffix: '%'
          }
        },
        plotOptions: {
          pie: {
            allowPointSelect: true,
            cursor: 'pointer',
            dataLabels: {
              enabled: false,
              format: '<b>{point.name}</b><br>{point.percentage:.1f} %',
              distance: -50,
              filter: {
                property: 'percentage',
                operator: '>',
                value: 4
              }
            },
            showInLegend: true
          }
        },
        legend: {
          labelFormatter: function () {
            return this.name + ' (' + (this.y / total * 100).toFixed(2) + '%)';
          }
        },
        series: [{
          name: 'Leads',
          colorByPoint: false,
          data: dataWithColors
        }],
        credits: {
          enabled: false
        }
      });
    }
    //////====As Per Analytics Ended=====////

    function openCity(evt, cityName) {
      var i, tabcontent, tablinks;
      tabcontent = document.getElementsByClassName("tabcontent");
      for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
      }
      tablinks = document.getElementsByClassName("tablinks");
      for (i = 0; i < tablinks.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(" active", "");
      }
      document.getElementById(cityName).style.display = "block";
      evt.currentTarget.className += " active";
    }

    $(document).on("click", ".page-link", function () {
      var id = $(this).attr("data-id");
      var select_id = $(this).parent().attr("id");
      get_records(id);
      $(".pageitem").removeClass("active");
      $("#" + select_id).addClass("active");

    });

    $(document).on('click', "#add", function () {
      $('.modal input').val('');
      $("#id").val($(this).data('id'));
    })

    $(document).on('change', "#result", function () {
      if ($(this).val() != 'Select Reason') {
        $("#result").removeClass('error');
      } else {
        $("#result").addClass('error');
      }
    })

    $(document).on('click', "#till_date", function () {
      if ($('#till_date').is(':checked')) {
        $("#from_date").attr('disabled', true);
      } else {
        $("#from_date").attr('disabled', false);
      }
    })


    $(document).on('click', "#add_result", function () {
      var page_id = $('.pagination li.active').attr("id");
      console.log(id);
      var result = $("#result").val();

      if (result.trim() == 'Select Reason') {
        $("#result").addClass('error');
        return false;
      }
      var comment = $("#comment").val();
      var followup_date = $("#followup_date").val();
      var id = $("#id").val();

      $.ajax({
        url: 'leads/insert_curd.php',
        type: 'POST',
        dataType: "json",
        beforeSend: function () {
          $("#add_result").attr('disabled', true);
        },
        cache: false,
        data: {
          result: result,
          comment: comment,
          followup_date: followup_date,
          id: id

        },
        success: function (returnhtml) {
          $("#add_result").attr('disabled', false);
          if (returnhtml.message == 'success') {
            alert('Record Added successfully');
            $('#myModal').modal('toggle');
          } else {
            alert('Record not added');
          }
          get_records(page_id);



        }
      })
    })

    $(document).on('click', "#history", function () {
      var id = $(this).data('id');
      $.ajax({
        url: 'leads/get_logs.php',
        type: 'POST',
        dataType: "json",
        cache: false,
        data: {
          mobile: id

        },
        success: function (data) {
          var html = '';
          let cnt = 0;
          if (data.length > 0) {
            $.each(data, function (arr, i) {
              cnt++;
              html += '<tr>';
              html += '<td>' + cnt + '</td>';
              html += '<td>' + i.reason + '</td>';
              html += '<td>' + i.comment + '</td>';
              html += '<td>' + i.followup_date + '</td>';
              html += '<td>' + i.createddt + '</td>';
              html += '</tr>';

            })
          }

          $(".body-logs").html(html);



        }
      })
    })
    // Create the chart

    function get_column_by_date(series_data) {
      //console.log(data)
      Highcharts.chart('container_3', {
        chart: {
          type: 'column'
        },
        title: {
          align: 'center',
          text: 'leads By date'
        },
        // subtitle: {
        //     align: 'left',
        //     text: 'Click the columns to view versions. Source: <a href="http://statcounter.com" target="_blank">statcounter.com</a>'
        // },
        accessibility: {
          announceNewData: {
            enabled: true
          }
        },
        xAxis: {
          type: 'category'
        },
        yAxis: {
          title: {
            text: 'Total leads by date'
          }

        },
        legend: {
          enabled: false
        },
        plotOptions: {
          series: {
            borderWidth: 0,
            dataLabels: {
              enabled: true,
              format: '{y}'
            }
          }
        },

        tooltip: {
          headerFormat: '<span style="font-size:11px">{series.name}</span><br>',
          pointFormat: '<span style="color:{point.color}">{point.name}</span>: <b>{point.y:.2f}%</b> of total<br/>'
        },

        series: [{
          name: "Leads",
          colorByPoint: true,
          data: series_data
        }],

        credits: {
          enabled: false
        }
      });
    }

    $(document).on('click', "#export", function () {
      var from_date = $("#from_date").val();
      var camp_source = $("#camp_source").val();
      var Campaign_sub_source = $("#Campaign_sub_source").val();
      var keyword = $("#keyword").val();



      var till_date = '';
      if ($('#till_date').is(':checked')) {
        till_date = 1;
      }
      $("#from_date_form").val(from_date);
      $("#camp_source_form").val(camp_source);
      $("#Campaign_sub_source_form").val(Campaign_sub_source);
      $("#keyword_form").val(keyword);
      $("#till_date_form").val(till_date);

      $("#export_form").submit();
    });


    $(document).on('click', "#edit_lead", function () {
      var mobile = $(this).data('id');

      $("#mobile_edit").val(mobile);

      $("#edit_form").submit();
    });


    $('.accordion-toggle').click(function () {
      $('.hiddenRow').hide();
      $(this).next('tr').find('.hiddenRow').show();
    });
  </script>

  <!-- ===m=== Analytics Script Code ===m=== -->
  <script>
    $(document).ready(function () {
      function sendLog(actionType, dataPayload) {
        dataPayload.action_type = actionType;
        // ===m=== Capture the exact page they are on ===m===
        dataPayload.current_url = window.location.pathname + window.location.search;
        $.ajax({
          url: 'leads/ajax_log_activity.php',
          type: 'POST',
          data: dataPayload,
          error: function () {
            console.log("Background log failed");
          }
        });
      }
      // ===m=== Track logout specifically ===m===
      $(document).on('click', 'a[href*="logout.php"]', function (e) {
        e.preventDefault(); // stop immediate redirect
        e.stopImmediatePropagation();
        let logoutUrl = $(this).attr('href');
        sendLog('logout', {
          clicked_element: 'Logout'

        });
        setTimeout(function () {
          window.location.href = logoutUrl;
        }, 400);
        return;
      });
      // ===m=== Track clicks ===m===
      $(document).on('click', 'a, button, input[type="button"], input[type="submit"], [role="button"], .nav-link, .dropdown-item,[data-bs-toggle], [data-toggle]', function (e) {
        let $el = $(this);
        // ===m=== Extract element text/label ===m===
        let text = $el.text().trim() || $el.val() || $el.attr('title') || $el.attr('aria-label') || 'Icon/Element';
        let href = $el.attr('href') || '';
        let id = $el.attr('id') || '';
        let textLower = text.toLowerCase();
        // ===m=== Limit text length ===m===
        if (text.length > 50) text = text.substring(0, 50) + '...';
        // ===m=== Ignore useless javascript-only icon clicks ===m===
        if (href.toLowerCase().includes('javascript:') && text === 'Icon/Element') return;
        // ===m=== Detect report export/download actions ===m===
        if (textLower.includes('export') || textLower.includes('download') || href.toLowerCase().includes('export.php')) {
          sendLog('report_download', {
            report_name: text || 'Export Data'
          });
          return;
        }
        if (textLower.includes('search') || $el.attr('id') === 'search-btn' || $el.hasClass('search')) {
          let searchTerm = $el.closest('form, div, .row').find('input[type="text"], input[type="search"]').val();
          if (searchTerm && searchTerm.trim() !== '') {
            sendLog('search', {
              search_term: searchTerm.trim()
            });
            return;
          }
        }
        // ===m=== Prepare element details for logging ===m===
        let elementDetails = text;
        if (href && href !== '#' && !href.toLowerCase().includes('javascript:')) {
          elementDetails += ' (' + href + ')';
        } else if (id) {
          elementDetails += ' (#' + id + ')';
        }
        sendLog('click', {
          clicked_element: elementDetails
        });
      });
      // ===m=== Track search via Enter key in input fields ===m===
      $(document).on('keypress', 'input', function (e) {
        if (e.which == 13) {
          let inputAttributes = ($(this).attr('id') || '') + ($(this).attr('name') || '') + ($(this).attr('placeholder') || '');
          if (inputAttributes.toLowerCase().includes('search')) {
            let searchTerm = $(this).val().trim();
            if (searchTerm !== '') {
              sendLog('search', {
                search_term: searchTerm
              });
            }
          }
        }
      });
      // ===m=== Track dropdown/select value changes ===m===
      $(document).on('change', 'select', function () {
        let selectIdentifier = $(this).attr('name') || $(this).attr('id') || 'Dropdown';
        let selectedText = $(this).find('option:selected').text().trim();
        sendLog('change', {
          changed_element: selectIdentifier,
          new_value: selectedText
        });
      });

    });

    // ===m=== Time Spent Tracking Started ===m===
    const _sessionStart = Date.now();

    function _sendTimeSpent() {
      const seconds = Math.round((Date.now() - _sessionStart) / 1000);
      if (seconds < 2) return; // ignore accidental closes
      navigator.sendBeacon("datalog.php", JSON.stringify({
        event: "time_spent",
        label: "session_duration",
        tag: "",
        id: "",
        class: "",
        href: "",
        page: location.pathname,
        session_id: localStorage.session_id,
        campaignsource: campaignsource,
        campaignsubsource: campaignsubsource,
        client_os: accurateOS,
        client_model: accurateModel,
        time_spent: seconds
      }));
    }

    // Covers tab close, browser close, navigation away
    window.addEventListener("beforeunload", _sendTimeSpent);

    // Covers tab switch, phone lock screen, swipe away on mobile
    document.addEventListener("visibilitychange", function () {
      if (document.visibilityState === "hidden") _sendTimeSpent();
    });

    // Covers iOS Safari which doesn't fire beforeunload reliably
    window.addEventListener("pagehide", _sendTimeSpent);
    // ===m=== Time Spent Tracking Ended ===m===
  </script>
  <!-- ===m=== Analytics Script Code ===m=== -->

  <section id="footer">
    <footer class="footer" style="position: absolute; bottom: 0; width: -webkit-fill-available;">
      <div class="container-fluid">
        <div class="row">
          <nav class="footer-nav">
            <ul>
              <!-- <li><a href="https://www.creative-tim.com" target="_blank">Creative Tim</a></li>
                <li><a href="https://www.creative-tim.com/blog" target="_blank">Blog</a></li>
                <li><a href="https://www.creative-tim.com/license" target="_blank">Licenses</a></li> -->
            </ul>
          </nav>
          <div class="credits ml-auto">
            <span class="copyright">
              © Copyrights @ all rights reserved under SSV Technologies.
            </span>
          </div>
        </div>
      </div>
    </footer>
  </section>
</body>

</html>