<?php
include __DIR__ . '/../core/db_controller/db.php';
$rowsChart6 = array();
$rowsChartDrilldown6 = array();

$from_date = $_POST['from_date'];
//$to_date = $_POST['to_date'];
$camp_source = $_POST['camp_source'];
$Campaign_sub_source = $_POST['Campaign_sub_source'];
$keyword = $_POST['keyword'];
$till_date = $_POST['till_date'];

$date_search = 'DATE_FORMAT(createddate,"%Y-%m-%d") >= DATE(NOW() - INTERVAL 6 DAY)';
$camp_source_search = '1';
$Campaign_sub_source_search = '1';
$keyword_search = '1';

if ($till_date == '1') {


  $date_search = '1';
} else if ($from_date != '') {

  $date = explode('-', $from_date);
  $FromDate = str_replace('/', '-', $date[0]);
  $ToDate = str_replace('/', '-', $date[1]);


  $date_search = 'DATE_FORMAT(createddate,"%Y-%m-%d") >= "' . date('Y-m-d', strtotime($FromDate)) . '" and DATE_FORMAT(createddate,"%Y-%m-%d") <= "' . date('Y-m-d', strtotime($ToDate)) . '"';
}

if ($camp_source != '') {
  $camp_source_search = 'campaignsource = "' . $camp_source . '"';
}


if ($Campaign_sub_source != '') {
  $Campaign_sub_source_search = 'campaignsubsource = "' . $Campaign_sub_source . '"';
}


if ($keyword != '') {
  $keyword_search = 'keyword like "%' . $keyword . '%" or name  like "%' . $keyword . '%" or email  like "%' . $keyword . '%" or mobile  like "%' . $keyword . '%"';
}

## Get pie chart Data
$pchart6 = "SELECT  campaignsource as campaignsource,count(campaignsource) as count from `lead` where $date_search and $camp_source_search and $Campaign_sub_source_search and $keyword_search group by campaignsource";

//echo $pchart6;
$result = $conn->query($pchart6);

if ($result->num_rows > 0) {
  while ($row = $result->fetch_assoc()) {
    if ($row["campaignsource"] != '') {

      ## make data for pie chart
      array_push($rowsChart6, array('name' => $row["campaignsource"], 'drilldown' => $row["campaignsource"], 'y' => (int)$row["count"]));

      ## Get pie Drilldown chart Data
      $pdrilldown_rowchart6 = "SELECT  last_reson as reason,count(last_reson) as count from `lead` where $date_search and campaignsource = '" . $row["campaignsource"] . "' and " . $Campaign_sub_source_search . " and " . $keyword_search . " group by reason";
      $drilldown_rowresult = $conn->query($pdrilldown_rowchart6);
      $rowsDrilldown6 = array();
      if ($result->num_rows > 0) {
        while ($drilldown_row = $drilldown_rowresult->fetch_assoc()) {
          ## make data for drilldown pie chart
          array_push($rowsDrilldown6, array($drilldown_row["reason"], (int)$drilldown_row["count"]));
        }


        array_push($rowsChartDrilldown6, array('id' => $row["campaignsource"], 'name' => $row["campaignsource"], 'data' => $rowsDrilldown6));
      }
    }
  }
}

## by date column charts
$pchart13 = "SELECT date(createddate) as createddate,count(createddate) as count from `lead` where $date_search and $camp_source_search and $Campaign_sub_source_search and $keyword_search GROUP BY date(createddate)";
$pchart13_result = $conn->query($pchart13);
$rowsChart13 = array();
if ($pchart13_result->num_rows > 0) {
  while ($pchart13_row = $pchart13_result->fetch_assoc()) {
    array_push($rowsChart13, array('name' => $pchart13_row["createddate"], 'drilldown' => $pchart13_row["createddate"], 'y' => (int)$pchart13_row["count"]));
  }
}


## by form name column charts
$pchart5 = "SELECT capturefromname as capturefromname,count(capturefromname) as count from `lead` where capturefromname != '' and $date_search and $camp_source_search and $Campaign_sub_source_search and $keyword_search GROUP BY capturefromname";
$pchart5_result = $conn->query($pchart5);
$rowschart5 = array();
if ($pchart5_result->num_rows > 0) {
  while ($pchart5_row = $pchart5_result->fetch_assoc()) {
    array_push($rowschart5, array('name' => $pchart5_row["capturefromname"], 'drilldown' => $pchart5_row["capturefromname"], 'y' => (int)$pchart5_row["count"]));
  }
}


$data_result = array(
  'rowsChart6' => $rowsChart6,
  'rowsChartDrilldown6' => $rowsChartDrilldown6,
  'rowsChart13' => $rowsChart13,
  'rowschart5' => $rowschart5
);

echo json_encode($data_result);
