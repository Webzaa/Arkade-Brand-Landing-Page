<?php
include __DIR__ . '/../core/db_controller/db.php';
$limit = 50;

$from_date = $_POST['from_date'];
//$to_date = $_POST['to_date'];
$camp_source = $_POST['camp_source'];
$Campaign_sub_source = $_POST['Campaign_sub_source'];
$keyword = $_POST['keyword'];
$till_date = $_POST['till_date'];

$date_search = 'DATE_FORMAT(createddate,"%Y-%m-%d") >= DATE(NOW() - INTERVAL 6 DAY)';
$camp_source_search = '1';
$Campaign_sub_source_search = '1';
$keyword_search = '1';

if ($till_date == '1') {


  $date_search = '1';
} else if ($from_date != '') {

  $date = explode('-', $from_date);
  $FromDate = str_replace('/', '-', $date[0]);
  $ToDate = str_replace('/', '-', $date[1]);


  $date_search = 'DATE_FORMAT(createddate,"%Y-%m-%d") >= "' . date('Y-m-d', strtotime($FromDate)) . '" and DATE_FORMAT(createddate,"%Y-%m-%d") <= "' . date('Y-m-d', strtotime($ToDate)) . '"';
}

if ($camp_source != '') {
  $camp_source_search = 'campaignsource = "' . $camp_source . '"';
}


if ($Campaign_sub_source != '') {
  $Campaign_sub_source_search = 'campaignsubsource = "' . $Campaign_sub_source . '"';
}


if ($keyword != '') {
  $keyword_search = 'keyword like "%' . $keyword . '%" or name  like "%' . $keyword . '%" or email  like "%' . $keyword . '%" or mobile  like "%' . $keyword . '%"';
}

$sql = "SELECT COUNT(id) FROM `lead` where $date_search and $camp_source_search and $Campaign_sub_source_search and $keyword_search";
$rs_result = mysqli_query($conn, $sql);
$row = mysqli_fetch_row($rs_result);
$total_records = $row[0];
$total_pages = ceil($total_records / $limit);
?>

<ul class="pagination">
  <?php
  if (!empty($total_pages)) {
    for ($i = 1; $i <= $total_pages; $i++) {
      if ($i == 1) {
  ?>
        <li class="pageitem active" id="<?php echo $i; ?>"><a href="JavaScript:Void(0);" data-id="<?php echo $i; ?>" class="page-link"><?php echo $i; ?></a></li>

      <?php
      } else {
      ?>
        <li class="pageitem" id="<?php echo $i; ?>"><a href="JavaScript:Void(0);" class="page-link" data-id="<?php echo $i; ?>"><?php echo $i; ?></a></li>
  <?php
      }
    }
  }
  ?>
</ul>