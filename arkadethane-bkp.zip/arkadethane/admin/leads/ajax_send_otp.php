<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
include __DIR__ . '/../core/db_controller/db.php';
require __DIR__ . '/../core/mailer/sendMail.php';
require_once __DIR__ . '/../core/config.php';

$email = trim($_POST['email'] ?? '');

// --------------------
// Basic validation
// --------------------
if ($email == '') {
    echo "Email is required";
    exit;
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo "Invalid email format";
    exit;
}

// --------------------
// Check user exists
// --------------------
$stmt = $conn->prepare("SELECT uid,status FROM users WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    echo "Email not registered";
    exit;
}

$user = $result->fetch_assoc();

// Optional: block inactive users
if ($user['status'] == 'N') {
    echo "Account blocked";
    exit;
}

// --------------------
// Generate OTP
// --------------------
$otp = random_int(100000, 999999);
$expiry = date("Y-m-d H:i:s", strtotime("+5 minutes"));

// --------------------
// Save OTP
// --------------------
$update = $conn->prepare(
    "UPDATE users SET otp=?, otp_expiry=? WHERE email=?"
);
$update->bind_param("sss", $otp, $expiry, $email);
$update->execute();

// --------------------
// Send OTP Email
// --------------------
try {

    if (sendOTP($email, $otp)) {
        echo "sent";
    } else {
        echo "Failed to send OTP";
    }
    //echo "sent";

} catch (Exception $e) {

    echo "Failed to send OTP" . $e;
}
