<?php
session_start();
require_once __DIR__ . '/../core/db_controller/db.php';
require_once __DIR__ . '/../core/config.php';
// require_once __DIR__ . '/../core/logger.php';

if (isset($_SESSION['uid']) && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $action_type = $_POST['action_type'] ?? '';
    $current_url = $_POST['current_url'] ?? 'Unknown URL';

    // 1. Handle Regular Clicks (Buttons, Links, Subtabs)
    if ($action_type === 'click') {
        $element = $_POST['clicked_element'] ?? 'Unknown Element';
        logTeamActivity($conn, $_SESSION['uid'], PROJECT_NAME, 'click', [
            'element' => $element,
            'page_url' => $current_url
        ]);
        echo json_encode(['status' => 'success']);
        exit;
    }

    // 2. Handle Dropdown Changes
    if ($action_type === 'change') {
        $element = $_POST['changed_element'] ?? 'Unknown Dropdown';
        $new_value = $_POST['new_value'] ?? '';
        logTeamActivity($conn, $_SESSION['uid'], PROJECT_NAME, 'change', [
            'dropdown' => $element,
            'selected' => $new_value,
            'page_url' => $current_url
        ]);
        echo json_encode(['status' => 'success']);
        exit;
    }

    // 3. Handle Tab Clicks (Legacy Fallback from your old script)
    if ($action_type === 'tab_click') {
        $tab_name = $_POST['tab_name'] ?? 'Unknown Tab';
        logTeamActivity($conn, $_SESSION['uid'], PROJECT_NAME, 'tab_click', [
            'tab_name' => $tab_name,
            'page_url' => $current_url
        ]);
        echo json_encode(['status' => 'success']);
        exit;
    }

    // 4. Handle Search
    if ($action_type === 'search') {
        $search_term = $_POST['search_term'] ?? '';
        logTeamActivity($conn, $_SESSION['uid'], PROJECT_NAME, 'search', [
            'search_term' => $search_term,
            'page_url' => $current_url
        ]);
        echo json_encode(['status' => 'success']);
        exit;
    }

    // 5. Handle Report Download
    if ($action_type === 'report_download') {
        $report_name = $_POST['report_name'] ?? '';
        logTeamActivity($conn, $_SESSION['uid'], PROJECT_NAME, 'report_download', [
            'file_name' => $report_name,
            'page_url' => $current_url
        ]);
        echo json_encode(['status' => 'success']);
        exit;
    }
}

echo json_encode(['status' => 'error']);
