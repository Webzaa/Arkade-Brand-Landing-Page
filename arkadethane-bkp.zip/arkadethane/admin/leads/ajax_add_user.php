<?php
session_start();
include __DIR__ . '/../core/db_controller/db.php';

if (!isset($_SESSION["user_logged"]) || $_SESSION["role"] != "superadmin") {
    echo "Unauthorized";
    exit;
}

$fullname = trim($_POST['fullname'] ?? '');
$email    = trim($_POST['email'] ?? '');
$role     = $_POST['role'] ?? 'admin';
$status   = $_POST['status'] ?? 'Y';

if ($fullname == "" || $email == "") {
    echo "Missing fields";
    exit;
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo "Invalid email";
    exit;
}

// Check duplicate
$check = $conn->prepare("SELECT uid FROM users WHERE email=?");
$check->bind_param("s", $email);
$check->execute();
$res = $check->get_result();

if ($res->num_rows > 0) {
    echo "User already exists";
    exit;
}

// Insert
$stmt = $conn->prepare("
INSERT INTO users (username,email,role,status,createdon)
VALUES (?,?,?,?,NOW())
");

$stmt->bind_param("ssss", $fullname, $email, $role, $status);
$stmt->execute();

/* ===m=== Activity Log Start ===m=== */
$admin_uid = $_SESSION['uid'] ?? 0;
$project   = $_SESSION['project_name'] ?? '';

$details = json_encode([
    "action" => "add_user",
    "added_email" => $email,
    "role" => $role
]);

$log = $conn->prepare("INSERT INTO team_activity_logs (uid, project_name, action_type, action_details) VALUES (?, ?, 'click', ?)");
$log->bind_param("iss", $admin_uid, $project, $details);
$log->execute();
/* ===m=== Activity Log End ===m=== */

echo "success";
