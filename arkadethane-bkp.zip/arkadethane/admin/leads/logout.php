<?php
session_start();
include __DIR__ . '/../core/db_controller/db.php';

$uid = $_SESSION['uid'] ?? 0;
$project = $_SESSION['project_name'] ?? '';

if ($uid != 0) {

	$details = json_encode([
		"Module" => "Logout",
		"Route" => "logout.php"
	]);

	$stmt = $conn->prepare("INSERT INTO team_activity_logs (uid, project_name, action_type, action_details) VALUES (?, ?, 'logout', ?)");
	$stmt->bind_param("iss", $uid, $project, $details);
	$stmt->execute();
}

session_unset();
session_destroy();

header("Location: ../login.php");
exit;
