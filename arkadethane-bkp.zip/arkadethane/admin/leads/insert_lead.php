<?php
include __DIR__ . '/../core/db_controller/db.php';
// echo '<pre>';print_r($_POST);

$data = $_POST['from_data'];

$name = $data[0]['value'];

$countrycode  = $data[1]['value'];

$mobile = $data[2]['value'];

$email = $data[3]['value'];

$campaignsource = $data[4]['value'];

$campaignsubsource = $data[5]['value'];

$bhktype = $data[6]['value'];

$purpose = $data[7]['value'];

$visitpossibleon = $data[8]['value'];

$favdestination = $data[9]['value'];

$villatype = $data[10]['value'];

$projinterest = $data[11]['value'];



$existing_mobile = '';
$sql = "SELECT * FROM lead l where mobile = '" . $mobile . "'";
$result = $conn->query($sql);
$edit_result = array();
if ($result->num_rows > 0) {
  while ($row = $result->fetch_assoc()) {
    $existing_mobile = $row['mobile'];
  }
}

if ($existing_mobile == '') {
  $sql = "INSERT INTO lead (name, email, countrycode, mobile, campaignsource, campaignsubsource, bhktype, purpose, visitpossibleon, favdestination, villatype, projinterest,createddate )
          VALUES ('$name', '$email', '$countrycode','$mobile','$campaignsource','$campaignsubsource','$bhktype','$purpose','$visitpossibleon','$favdestination','$villatype','$projinterest','" . date('Y-m-d H:i:s') . "')";
  // echo $sql;

  if ($conn->query($sql) === TRUE) {
    $data_result = array("message" => "success");
  } else {
    $data_result = array("message" => "failure", "error" => $conn->error);
  }
} else {
  $sql = "update lead set name = '$name', email = '$email', campaignsource = '$campaignsource', campaignsubsource = '$campaignsubsource', bhktype = '$bhktype', purpose = '$purpose', visitpossibleon = '$visitpossibleon', favdestination = '$favdestination',villatype = '$villatype', projinterest = '$projinterest'  where mobile = '$mobile';";
  //echo  $sql;
  if ($conn->query($sql) === TRUE) {
    $data_result = array("message" => "success");
  } else {
    $data_result = array("message" => "failure", "error" => $conn->error);
  }
}



$conn->close();


echo json_encode($data_result);
