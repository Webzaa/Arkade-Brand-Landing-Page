<?php
include __DIR__ . '/../core/db_controller/db.php';

$mobile = $_POST['mobile'];


$data_result = array();

$sql = "SELECT * FROM map_lead where mobile = '" . $mobile . "'";
//echo $pchart6;
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  while ($row = $result->fetch_assoc()) {
    if ($row["followup_date"] == '0000-00-00 00:00:00') {
      $followup_date = '';
    } else {
      $followup_date = date('d-m-Y h:i a', strtotime($row["followup_date"]));
    }
    array_push(
      $data_result,
      array(
        'id_map' => $row["id_map"],
        'mobile' => $row["mobile"],
        'reason' => $row["reason"],
        'comment' => $row["comment"],
        'followup_date' => $followup_date,
        'createddt' => date('d-m-Y h:i a', strtotime($row["createddt"])),
      )
    );
  }
}

echo json_encode($data_result);
