<?php

/*
 * Example PHP implementation used for the index.html example
 */

// DataTables PHP library
include( "../lib/DataTables.php" );

// Alias Editor classes so they are easy to use
use
	DataTables\Editor,
	DataTables\Editor\Field,
	DataTables\Editor\Format,
	DataTables\Editor\Mjoin,
	DataTables\Editor\Options,
	DataTables\Editor\Upload,
	DataTables\Editor\Validate,
	DataTables\Editor\ValidateOptions;

// Build our Editor instance and process the data coming from _POST
Editor::inst( $db, 'lead' )
	->fields(
		Field::inst( 'name' )
			->validator( Validate::notEmpty( ValidateOptions::inst()
				->message( 'A first name is required' )	
			) ),
		Field::inst( 'email' )
			->validator( Validate::email( ValidateOptions::inst()
				->message( 'Please enter an e-mail address' )	
			) ),
		Field::inst( 'mobile' )
			->validator( Validate::numeric() )
			->setFormatter( Format::ifEmpty(null) ),
		Field::inst( 'keyword' ),
		Field::inst( 'campaignplacement' ),
		Field::inst( 'campaignname' ),
		Field::inst( 'pagesource' ),
		Field::inst( 'pageurl' ),
		Field::inst( 'websitename' ),
		Field::inst( 'capturefromname' ),
		Field::inst( 'comments' ),
		Field::inst( 'createddate' ),
		Field::inst( 'otpverified' ),
		Field::inst( 'duplicate' ),
		Field::inst( 'reason' )
	)
	->process( $_POST )
	->json();
