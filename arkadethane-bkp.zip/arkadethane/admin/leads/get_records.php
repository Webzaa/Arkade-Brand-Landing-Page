<?php
session_start(); 
include __DIR__ . '/../core/db_controller/db.php';

$limit = 50;

if (isset($_POST["page"])) {
  $page  = $_POST["page"];
} else {
  $page = 1;
};

$from_date = $_POST['from_date'];
//$to_date = $_POST['to_date'];
$camp_source = $_POST['camp_source'];
$Campaign_sub_source = $_POST['Campaign_sub_source'];
$keyword = $_POST['keyword'];
$till_date = $_POST['till_date'];

$date_search = 'DATE_FORMAT(createddate,"%Y-%m-%d") >= DATE(NOW() - INTERVAL 6 DAY)';
$camp_source_search = '1';
$Campaign_sub_source_search = '1';
$keyword_search = '1';

if ($till_date == '1') {
  $date_search = '1';
} 
else if ($from_date != '') {
  $date = explode('-', $from_date);
  $FromDate = str_replace('/', '-', $date[0]);
  $ToDate = str_replace('/', '-', $date[1]);
  $date_search = 'DATE_FORMAT(createddate,"%Y-%m-%d") >= "' . date('Y-m-d', strtotime($FromDate)) . '" and DATE_FORMAT(createddate,"%Y-%m-%d") <= "' . date('Y-m-d', strtotime($ToDate)) . '"';
}

if ($camp_source != '') {
  $camp_source_search = 'campaignsource = "' . $camp_source . '"';
}


if ($Campaign_sub_source != '') {
  $Campaign_sub_source_search = 'campaignsubsource = "' . $Campaign_sub_source . '"';
}


if ($keyword != '') {
  $keyword_search = 'keyword like "%' . $keyword . '%" or name  like "%' . $keyword . '%" or email  like "%' . $keyword . '%" or mobile  like "%' . $keyword . '%"';
}

$start_from = ($page - 1) * $limit;

// --- GET SESSIONS ONCE ---
$perm_unmask_email = isset($_SESSION['unmask_email']) ? $_SESSION['unmask_email'] : 'N';
$perm_unmask_mobile = isset($_SESSION['unmask_mobile']) ? $_SESSION['unmask_mobile'] : 'N';
// -------------------------

$sql = "SELECT l.*,ifnull((select reason from map_lead where mobile = l.mobile order by createddt desc limit 1),'') as reason FROM `lead` l where $date_search and $camp_source_search and $Campaign_sub_source_search and $keyword_search ORDER BY createddate desc LIMIT $start_from, $limit";
$result = $conn->query($sql);
$data_result = array();

if ($result->num_rows > 0) {
  while ($row = $result->fetch_assoc()) {
      
    // ===m=== ATTACH PERMISSIONS TO EVERY ROW ===m===
    $row['allow_email'] = $perm_unmask_email;
    $row['allow_mobile'] = $perm_unmask_mobile;
    
    
    array_push($data_result, $row);
  }
}
echo json_encode($data_result);
?>
