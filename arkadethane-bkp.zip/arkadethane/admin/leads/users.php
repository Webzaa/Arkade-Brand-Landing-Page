<?php
session_start();

if (!isset($_SESSION["user_logged"]) || $_SESSION["role"] != "superadmin") {
    echo "Access Denied";
    exit;
}
?>

<!DOCTYPE html>
<html>

<head>
    <title>Manage Users</title>

    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>

    <!-- <link rel="icon" type="image/png" href="./assets/img/favicon.png"> -->
    <link rel="icon" type="image/png" href="../assets/img/favicon.png">
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/style.css?v=1.0">
    <style>
        .container {
            max-width: 1100px;
            margin-top: 40px
        }

        .table td,
        .table th {
            text-align: center
        }

        .perm-checkbox {
            accent-color: #6a6968;
        }

        table.dataTable thead .sorting:before,
        table.dataTable thead .sorting:after,
        table.dataTable thead .sorting_asc:before,
        table.dataTable thead .sorting_asc:after,
        table.dataTable thead .sorting_desc:before,
        table.dataTable thead .sorting_desc:after {
            display: none !important;
        }
    </style>
</head>

<body>


    <div class="container">

        <div class="d-flex justify-content-between align-items-center mb-4">
            <h4>Add Admin User</h4>
            <a href="../index.php" class="btn actionBtn">Back</a>
        </div>


        <div class="row mb-3">

            <div class="col-md-3">
                <input type="text" id="fullname" class="form-control " placeholder="Full Name">
            </div>

            <div class="col-md-3">
                <input type="email" id="email" class="form-control " placeholder="Email">
            </div>

            <div class="col-md-2">
                <select id="role" class="form-control ">
                    <option value="admin">Admin</option>
                    <option value="superadmin">Super Admin</option>
                </select>
            </div>

            <div class="col-md-2">
                <select id="status" class="form-control ">
                    <option value="Y">Active</option>
                    <option value="N">Blocked</option>
                </select>
            </div>

            <div class="col-md-2">
                <button class="btn w-100 actionBtn" id="addUserBtn">Add</button>
            </div>

        </div>

        <div id="msg"></div>

        <hr>

        <h5>Users List</h5>

        <table class="table table-bordered" id="usersTable">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Full Name</th>
                    <th>Email</th>
                    <th>Role</th>
                    <th>Status</th>
                    <th>Created</th>
                    <th>Email Masking</th>
                    <th>Mobile Masking</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody></tbody>
        </table>

    </div>

    <!-- ================= EDIT MODAL ================= -->
    <div class="modal fade" id="editUserModal">
        <div class="modal-dialog">
            <div class="modal-content">

                <div class="modal-header">
                    <h5>Edit User</h5>
                    <button class="close" data-dismiss="modal">&times;</button>
                </div>

                <div class="modal-body">

                    <input type="hidden" id="edit_uid">

                    <div class="form-group">
                        <label>Full Name</label>
                        <input type="text" id="edit_fullname" class="form-control">
                    </div>

                    <div class="form-group">
                        <label>Email</label>
                        <input type="email" id="edit_email" class="form-control">
                    </div>

                    <div class="form-group">
                        <label>Role</label>
                        <select id="edit_role" class="form-control">
                            <option value="admin">Admin</option>
                            <option value="superadmin">Super Admin</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>Status</label>
                        <select id="edit_status" class="form-control">
                            <option value="Y">Active</option>
                            <option value="N">Blocked</option>
                        </select>
                    </div>

                    <button class="btn w-100 actionBtn" id="updateUserBtn">Update</button>

                </div>
            </div>
        </div>
    </div>

    <script>
        let table;

        // ================= LOAD USERS =================

        function loadUsers() {

            $.get("ajax_get_users.php", function(data) {

                if (table) {
                    table.destroy();
                }

                $("#usersTable tbody").html(data);

                table = $("#usersTable").DataTable({
                    pageLength: 10,
                    columnDefs: [{
                        orderable: false,
                        targets: [0, 6, 7, 8]
                    }]
                });

                table.on('order.dt search.dt', function() {
                    table.column(0, {
                            search: 'applied',
                            order: 'applied'
                        })
                        .nodes().each(function(cell, i) {
                            cell.innerHTML = i + 1;
                        });
                }).draw();
            });
        }

        loadUsers();

        // ================= ADD USER =================

        $("#addUserBtn").click(function() {

            let fullname = $("#fullname").val().trim();
            let email = $("#email").val().trim();
            let role = $("#role").val();
            let status = $("#status").val();

            if (fullname == "" || email == "") {
                showMsg("All fields required", "danger");
                return;
            }

            $.post("ajax_add_user.php", {
                fullname: fullname,
                email: email,
                role: role,
                status: status
            }, function(res) {

                if (res === "success") {
                    showMsg("User added", "success");
                    $("#fullname,#email").val("");
                    loadUsers();
                } else {
                    showMsg(res, "danger");
                }
            });
        });

        // ================= EDIT =================

        $(document).on("click", ".editBtn", function() {

            $("#edit_uid").val($(this).data("uid"));
            $("#edit_fullname").val($(this).data("name"));
            $("#edit_email").val($(this).data("email"));
            $("#edit_role").val($(this).data("role"));
            $("#edit_status").val($(this).data("status"));

            $("#editUserModal").modal("show");
        });

        // ================= UPDATE =================

        $("#updateUserBtn").click(function() {

            $.post("ajax_update_user.php", {
                uid: $("#edit_uid").val(),
                fullname: $("#edit_fullname").val(),
                email: $("#edit_email").val(),
                role: $("#edit_role").val(),
                status: $("#edit_status").val()
            }, function(res) {

                if (res === "success") {
                    $("#editUserModal").modal("hide");
                    loadUsers();
                    showMsg("User updated", "success");
                } else {
                    showMsg(res, "danger");
                }
            });
        });

        // =======m========== Toggle Permissions Started ========m=========
        $(document).on("change", ".perm-checkbox", function() {
            let uid = $(this).data("uid");
            let type = $(this).data("type");
            let val = $(this).is(":checked") ? "Y" : "N";
            let checkbox = $(this);

            $.post("ajax_update_permissions.php", {
                uid: uid,
                column: type,
                value: val
            }, function(res) {
                if (res === "success") {
                    showMsg("Permission updated successfully", "success");
                } else {
                    showMsg("Error updating permission", "danger");
                    checkbox.prop('checked', !checkbox.prop('checked')); // ===m=== Revert checkbox if failed ===m===
                }
            });
        });
        // =======m========== Toggle Permissions Ended ========m=========
        // ================= MESSAGE =================

        function showMsg(msg, type) {
            $("#msg").html(`<div class="alert alert-${type}">${msg}</div>`);
        }
    </script>

    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>

</body>

</html>