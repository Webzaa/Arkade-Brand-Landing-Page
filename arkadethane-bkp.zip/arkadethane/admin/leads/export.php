<?php

// ini_set('display_errors', '1');
// ini_set('display_startup_errors', '1');
// error_reporting(E_ALL);

session_start();
include __DIR__ . '/../core/db_controller/db.php';
require_once __DIR__ . '/../core/config.php';

if (!isset($_SESSION["user_logged"]) || $_SESSION["user_logged"] != "Y") {
  header("Location: login.php");
  exit;
}

$username = $_SESSION['username'] ?? 'Admin';
$role = $_SESSION['role'] ?? 'admin';


$from_date = (isset($_POST['from_date'])) ? $_POST['from_date'] : '';
$to_date = (isset($_POST['to_date'])) ? $_POST['to_date'] : '';
$camp_source = (isset($_POST['camp_source'])) ? $_POST['camp_source'] : '';
$Campaign_sub_source = (isset($_POST['Campaign_sub_source'])) ? $_POST['Campaign_sub_source'] : '';
$keyword = (isset($_POST['keyword'])) ? $_POST['keyword'] : '';

$till_date = $_POST['till_date'];

$date_search = 'DATE_FORMAT(createddate,"%Y-%m-%d") >= DATE(NOW() - INTERVAL 7 DAY)';
$camp_source_search = '1';
$Campaign_sub_source_search = '1';
$keyword_search = '1';

//if($from_date != '' && $to_date != ''){
// $date_search = 'DATE_FORMAT(createddate,"%Y-%m-%d") >= "'.date('Y-m-d',strtotime($from_date)).'" and DATE_FORMAT(createddate,"%Y-%m-%d") <= "'.date('Y-m-d',strtotime($to_date)).'"';
//}
if ($till_date == '1') {


  $date_search = '1';
} else if ($from_date != '') {

  $date = explode('-', $from_date);
  $FromDate = str_replace('/', '-', $date[0]);
  $ToDate = str_replace('/', '-', $date[1]);


  $date_search = 'DATE_FORMAT(createddate,"%Y-%m-%d") >= "' . date('Y-m-d', strtotime($FromDate)) . '" and DATE_FORMAT(createddate,"%Y-%m-%d") <= "' . date('Y-m-d', strtotime($ToDate)) . '"';
}

if ($camp_source != '') {
  $camp_source_search = 'campaignsource = "' . $camp_source . '"';
}


if ($Campaign_sub_source != '') {
  $Campaign_sub_source_search = 'campaignsubsource = "' . $Campaign_sub_source . '"';
}


if ($keyword != '') {
  $keyword_search = 'keyword like "%' . $keyword . '%"';
}


// Filter the excel data 
function filterData(&$str)
{
  $str = preg_replace("/\t/", "\\t", $str);
  $str = preg_replace("/\r?\n/", "\\n", $str);
  if (preg_match('/["\t\n,]/', $str)) {
    $str = '"' . str_replace('"', '""', $str) . '"';
  }
}


// Excel file name for download 
// $fileName = "Leads_" . date('YmdHis') . ".xls";
$fileName = "Leads_" . PROJECT_NAME . "_" . date('YmdHis') . ".xls";

// Column names 
$fields = array('ID', 'Date', 'Time', 'Name', 'Email', 'Country code', 'Mobile', 'Campaign Source', 'Campaign Sub Source', 'Placement', 'IP Address', 'Ad Set', 'Ad Creative', 'Device', 'Keyword', 'BHK Type', 'Purpose', 'Visit Possible On', 'Fav Destination', 'Villa Type', 'Project Interested', 'Ad Name', 'Adset Name', 'Campaign Name', 'Form ID', 'Ad ID', 'Unique ID', 'Page ID', 'Capture From Name', 'Website Name', 'Keyword', 'UTMM', 'UTMC', 'UTM Campaign ID', 'UTM Campaign Name', 'UTM AD Group ID', 'UTM AD Group Name', 'UTM AD ID', 'UTM AD Name', 'Duplicate', 'Reason', 'Response');

// Display column names as first row 
$excelData = implode("\t", array_values($fields)) . "\n";


//insert LOG
//$insert_sql = "insert into admin_log (user,activity) values ('".$_SESSION["user"]."','Export Reports')";
//$conn->query($insert_sql);


// Fetch records from database 
$query = "SELECT l.*,ifnull((select reason from map_lead where mobile = l.mobile order by createddt desc limit 1),'') as reason FROM `lead` l where $date_search and $camp_source_search and $Campaign_sub_source_search and $keyword_search ORDER BY createddate DESC";
$result = $conn->query($query);
//$data_result = array();
$cnt = 0;
if ($result->num_rows > 0) {
  while ($row = $result->fetch_assoc()) {
    $parts = explode("@", $row['email']);
    $name = $parts[0];

    $censored = substr($name, 0, 1) . "*******" . substr($name, -1);

    $email = $censored . "@" . $parts[1];
    $cnt++;
    if (strlen((string)$row['mobile']) > 7) {
      $mobile =  str_repeat('*', (strlen($row['mobile']) - 5)) . substr($row['mobile'], -5);
    } else {
      $mobile = $row['mobile'];
    }

    if ($row['campaignsubsource'] == 'Facebook Lead Form') {
      $unique_id = $row['leadgen_id'];
    } else {
      $unique_id = $row['uniqueid'];
    }

    $lineData = array($cnt, date('d-M-Y', strtotime($row['createddate'])), date("H:i:s", strtotime($row['createddate'])), $row['name'], $row['email'], $row['countrycode'], $row['mobile'], $row['campaignsource'], $row['campaignsubsource'], $row['placement'], $row['ip_address'], $row['adset'], $row['adcreative'], $row['device'], $row['keyword'], $row['bhktype'], $row['purpose'], $row['visitpossibleon'], $row['favdestination'], $row['villatype'], $row['projinterest'], $row['ad_name'], $row['adset_name'], $row['campaign_name'], $row['form_id'], $row['ad_id'], $unique_id, $row['page_id'], $row['capturefromname'], $row['websitename'], $row['keyword'], $row['utmM'], $row['utmC'], $row['utm_campaignid'], $row['utm_campaignname'], $row['utm_adgroupid'], $row['utm_adgroupname'], $row['utm_adid'], $row['utm_adname'], $row['duplicate'], $row['reason'], $row['curlresponse']);
    array_walk($lineData, 'filterData');
    $excelData .= implode("\t", array_values($lineData)) . "\n";
  }
} else {
  $excelData .= 'No records found...' . "\n";
}

// Headers for download 
header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=\"$fileName\"");

// Render excel data 
echo $excelData;

exit;
