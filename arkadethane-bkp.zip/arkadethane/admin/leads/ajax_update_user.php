<?php
session_start();
include __DIR__ . '/../core/db_controller/db.php';

if (!isset($_SESSION["user_logged"]) || $_SESSION["role"] != "superadmin") {
    echo "Unauthorized";
    exit;
}

$uid      = $_POST['uid'];
$fullname = trim($_POST['fullname']);
$email    = trim($_POST['email']);
$role     = $_POST['role'];
$status   = $_POST['status'];

if ($fullname == "" || $email == "") {
    echo "Missing fields";
    exit;
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo "Invalid email";
    exit;
}

// Check email duplicate (ignore current user)
$check = $conn->prepare("
SELECT uid FROM users WHERE email=? AND uid!=?
");
$check->bind_param("si", $email, $uid);
$check->execute();
$res = $check->get_result();

if ($res->num_rows > 0) {
    echo "Email already exists";
    exit;
}

// Update
$stmt = $conn->prepare("
UPDATE users SET username=?, email=?, role=?, status=? WHERE uid=?
");

$stmt->bind_param("ssssi", $fullname, $email, $role, $status, $uid);
$stmt->execute();

/* ===m=== Activity Log Start ===m=== */
$admin_uid = $_SESSION['uid'] ?? 0;
$project   = $_SESSION['project_name'] ?? '';
$readable_status = ($status == 'Y') ? 'Active' : 'Blocked';

$details = json_encode([
    "action" => "edit_user",
    "edited_uid" => $uid,
    "email" => $email,
    "role" => $role,
    "status" => $readable_status
]);

$log = $conn->prepare("INSERT INTO team_activity_logs (uid, project_name, action_type, action_details) VALUES (?, ?, 'click', ?)");
$log->bind_param("iss", $admin_uid, $project, $details);
$log->execute();
/* ===m=== Activity Log End ===m=== */

echo "success";
