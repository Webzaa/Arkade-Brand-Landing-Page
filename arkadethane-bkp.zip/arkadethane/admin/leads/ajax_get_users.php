<?php
session_start();
include __DIR__ . '/../core/db_controller/db.php';

if (!isset($_SESSION["user_logged"]) || $_SESSION["role"] != "superadmin") {
    exit;
}

// ===m=== Added masking for email and mobile to the query ===m===
$res = $conn->query("SELECT uid, username, email, role, status, createdon, unmask_email, unmask_mobile FROM users ORDER BY uid DESC");

while ($row = $res->fetch_assoc()) {
?>
    <tr>
        <td></td> <!-- JS serial number -->
        <td><?php echo htmlspecialchars($row['username']); ?></td>
        <td><?php echo htmlspecialchars($row['email']); ?></td>
        <td><?php echo $row['role']; ?></td>
        <td><?php echo $row['status'] == 'Y' ? 'Active' : 'Blocked'; ?></td>
        <td><?php echo date('d/m/Y H:i', strtotime($row['createdon'])); ?></td>

        <!-- ===m=== NEW: Masking Checkbox ===m=== -->
        <td>
            <input type="checkbox" class="perm-checkbox" data-uid="<?php echo $row['uid']; ?>" data-type="unmask_email" <?php echo $row['unmask_email'] == 'Y' ? 'checked' : ''; ?>>
        </td>

        <!-- ===m=== NEW: Unmasking Checkbox ===m=== -->
        <td>
            <input type="checkbox" class="perm-checkbox" data-uid="<?php echo $row['uid']; ?>" data-type="unmask_mobile" <?php echo $row['unmask_mobile'] == 'Y' ? 'checked' : ''; ?>>
        </td>

        <td>
            <button class="btn btn-sm editBtn"
                data-uid="<?php echo $row['uid']; ?>"
                data-name="<?php echo htmlspecialchars($row['username']); ?>"
                data-email="<?php echo htmlspecialchars($row['email']); ?>"
                data-role="<?php echo $row['role']; ?>"
                data-status="<?php echo $row['status']; ?>"
                style="color: #fff; background-color: #6a6968; border-color: #6a6968;">
                Edit
            </button>
        </td>
    </tr>
<?php } ?>