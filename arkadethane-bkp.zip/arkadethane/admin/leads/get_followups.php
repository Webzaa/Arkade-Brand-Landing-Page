<?php
include __DIR__ . '/../core/db_controller/db.php';

$sql = "SELECT ml.*, l.* FROM map_lead ml left join `lead` l on ml.mobile = l.mobile where DATE(followup_date) = CURDATE() ORDER BY createddt ASC";
//echo $sql;
$result = $conn->query($sql);
$data_result = array();
if ($result->num_rows > 0) {
  while ($row = $result->fetch_assoc()) {
    array_push($data_result, $row);
  }
}


echo json_encode($data_result);
