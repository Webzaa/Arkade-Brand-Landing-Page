<?php
include __DIR__ . '/../core/db_controller/db.php';

$result = $_POST['result'];
$comment = $_POST['comment'];
if ($_POST['followup_date']  != '') {
  $followup_date = date('Y-m-d H:i:s', strtotime($_POST['followup_date']));
} else {
  $followup_date = '';
}
$id = $_POST['id'];



$sql = "INSERT INTO map_lead (mobile, reason, comment, followup_date)
      VALUES ('$id', '$result', '$comment','$followup_date')";

if ($conn->query($sql) === TRUE) {

  $update_sql =  "update lead set last_reson = '$result' where mobile = '$id'";
  //$conn->query($update_sql);
  if ($conn->query($update_sql) === TRUE) {
    $data_result = array("message" => "success");
  } else {
    $data_result = array("message" => "failure", "error" => $conn->error);
  }
} else {
  $data_result = array("message" => "failure", "error" => $conn->error);
}

$conn->close();


echo json_encode($data_result);
