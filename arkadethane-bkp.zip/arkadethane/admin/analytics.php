<?php
session_start();
include __DIR__ . '/core/db_controller/db.php';
require_once __DIR__ . '/leads/header.php';

if (!isset($_SESSION["user_logged"]))
{
    header("Location: login.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <link rel="apple-touch-icon" sizes="76x76" href="./assets/img/apple-icon.png">
    <link rel="icon" type="image/png" href="./assets/img/favicon.png">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title> Webzaa's Analytics Dashboard | <?php echo PROJECT_NAME; ?></title>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
    <!-- ===A=== Data Ranger ===A=== -->
    <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css" />
    <!--  ===m=== Fonts and icons Started ===m===  -->
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <!--  ===m=== Fonts and icons Ended ===m===  -->
    <!-- ===m=== CSS Started ===m=== -->
    <link href="./assets/css/bootstrap.min.css" rel="stylesheet" />
    <link href="./assets/css/paper-dashboard.css?v=2.0.1" rel="stylesheet" />
    <link href="./assets/demo/demo.css" rel="stylesheet" />
    <link href="./assets/css/style.css" rel="stylesheet" />
    <link href="./assets/css/style.css?v=1.0" rel="stylesheet" />
    <!-- ===m=== CSS Ended ===m=== -->

    <style>
        body {
            background: #f4f6f9
        }

        .card-ui {
            background: #fff;
            border-radius: 12px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, .06);
            height: 100%;
            display: flex;
            flex-direction: column;
        }

        .col-lg-6 {
            margin-bottom: 25px;
        }

        #clickChart {
            margin-top: 5rem !important;
        }

        #deviceTable_info {
            padding-top: 3.2rem !important;
        }

        #deviceTable_paginate {
            padding-top: 2.8rem !important;
        }

        .card-ui h5 {
            margin-bottom: 15px;
        }

        .kpi {
            background: #fff;
            border-radius: 12px;
            padding: 18px;
            text-align: center;
            box-shadow: 0 2px 8px rgba(0, 0, 0, .06);
            height: 120px;
            /* ← ADD fixed height */
            display: flex;
            flex-direction: column;
            justify-content: center;
            /* ← centers content vertically */
            align-items: center;
        }

        @media (max-width: 576px) {
            .kpi {
                height: auto;
                min-height: 90px;
                padding: 14px 10px;
            }

            .kpi h2 {
                font-size: 22px;
            }

            .kpi h6 {
                font-size: 11px;
            }
        }

        .kpi h2 {
            font-weight: 700;
            margin: 0
        }

        .url-cell {
            max-width: 350px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap
        }

        .heatbar {
            height: 12px;
            border-radius: 4px;
            min-width: 60px;
        }

        @media (max-width: 767px) {
            .heatbar {
                min-width: 40px;
                height: 10px;
            }
        }

        .table-scroll-mobile {
            overflow-x: auto;
            -webkit-overflow-scrolling: touch;
        }

        @media (min-width: 768px) {
            .table-scroll-mobile {
                overflow-x: visible;
            }
        }

        /* ===A=== Filter Section ===A=== */
        .analytics-filter-card {
            background: #fff;
            border-radius: 12px;
            padding: 20px 25px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, .06);
            margin-bottom: 25px;
        }

        .analytics-filter-card .form-group label {
            font-weight: 600;
            font-size: 13px;
            color: #444;
            margin-bottom: 5px;
        }

        .analytics-filter-card .form-control {
            border-radius: 6px;
            border: 1px solid #ddd;
            font-size: 13px;
            height: 38px;
        }

        .analytics-filter-card select.form-control {
            height: 38px;
        }

        .btn-filter-search {
            color: white !important;
            background: #424240 !important;
            border: none !important;
            border-radius: 6px;
            padding: 8px 20px;
            font-size: 13px;
            cursor: pointer;
            transition: background 0.2s ease;
        }

        .btn-filter-search:hover,
        .btn-filter-search:focus,
        .btn-filter-search:active {
            background: #e84e24 !important;
            color: white !important;
            border: none !important;
        }

        .btn-filter-reset {
            color: white !important;
            background: #424240 !important;
            border: none !important;
            border-radius: 6px;
            padding: 8px 20px;
            font-size: 13px;
            cursor: pointer;
            margin-left: 8px;
            transition: background 0.2s ease;
        }

        .btn-filter-reset:hover,
        .btn-filter-reset:focus,
        .btn-filter-reset:active {
            background: #e84e24 !important;
            color: white !important;
            border: none !important;
        }

        /* ===A=== Button Ended ===A=== */

        /* ===m=== Heatmap Specific UI ===m=== */
        .hourly-heatmap-card {
            background: #fff;
            border-radius: 12px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, .06);
            margin-bottom: 25px;
            overflow: hidden;
            border: 1px solid #e0e0e0;
        }

        .hourly-heatmap-header {
            background-color: #fce6e0;
            color: #2c2c2c;
            padding: 16px 25px;
            font-size: 21.98px;
        }

        .hourly-heatmap-body {
            padding: 15px;
        }

        /* ===m=== Heatmap Ended ===m=== */
        /* ===m=== Responsive Styles ===m=== */
        @media (max-width: 1199px) {
            .card-ui h5 {
                font-size: 1rem;
            }
        }

        @media (max-width: 991px) {
            .sidebar {
                transform: translate3d(-260px, 0, 0) !important;
                position: fixed !important;
                left: 0 !important;
                right: auto !important;
                z-index: 9999;
                height: 100vh;
            }

            .sidebar.active {
                transform: translate3d(0, 0, 0) !important;
            }

            .nav-open .sidebar {
                transform: translate3d(0, 0, 0) !important;
            }

            .main-panel {
                width: 100% !important;
            }

            .analytics_head {
                flex-direction: row;
                align-items: center !important;
                justify-content: space-between;
                gap: 10px;
                margin-top: 4rem !important;
                display: flex !important;
                flex-wrap: nowrap;
                position: relative;
            }

            .analytics_head .btn.actionBtn {
                width: auto;
                text-align: center;
                padding: 6px 16px;
                font-size: 12px;
                margin: 0;
                flex-shrink: 0;
            }

            .analytics-filter-card {
                padding: 15px;
            }

            .analytics-filter-card .form-group {
                margin-bottom: 12px;
            }

            .analytics-filter-card .btn-filter-search,
            .analytics-filter-card .btn-filter-reset {
                width: auto;
                margin: 5px 5px 5px 0;
                display: inline-block;
            }

            .analytics-filter-card .filter-actions {
                text-align: right;
                display: flex;
                flex-wrap: wrap;
                gap: 8px;
                align-items: center;
                justify-content: flex-end;
            }

            .card-ui {
                margin-bottom: 20px;
            }

            .card-ui h5 {
                font-size: 0.95rem;
            }

            .kpi h2 {
                font-size: 24px;
            }

            .hourly-heatmap-header {
                font-size: 16px;
                padding: 12px 15px;
            }

            .session-table-info {
                font-size: 11px;
            }
        }

        @media (max-width: 767px) {
            .main-panel {
                width: 100% !important;
            }

            .analytics_head {
                margin-top: 4rem !important;
            }

            .analytics-filter-card .col-md-3 {
                flex: 0 0 100%;
                max-width: 100%;
            }

            .analytics-filter-card .col-md-12:last-child {
                display: flex;
                justify-content: space-between;
                gap: 10px;
            }

            .analytics-filter-card .btn-filter-search,
            .analytics-filter-card .btn-filter-reset {
                flex: 1;
                margin: 0;
            }

            .kpi {
                height: auto;
                min-height: 85px;
                padding: 12px 8px;
            }

            .kpi h2 {
                font-size: 20px;
            }

            .kpi h6 {
                font-size: 10px;
            }

            .col-6.col-lg-3 {
                flex: 0 0 50%;
                max-width: 50%;
            }

            .col-lg-6 {
                flex: 0 0 100%;
                max-width: 100%;
            }

            .table-responsive-sm {
                display: block;
                width: 100%;
                overflow-x: auto;
                -webkit-overflow-scrolling: touch;
            }

            .table {
                font-size: 12px;
            }

            .table th,
            .table td {
                padding: 8px 4px;
                white-space: nowrap;
            }

            .url-cell {
                max-width: 150px;
            }

            #pageTable,
            #heatTable,
            #sessionTable {
                font-size: 11px;
            }

            .card-ui h5 {
                font-size: 14px;
            }

            .card-ui h5 span {
                display: block;
                margin-left: 0 !important;
                margin-top: 8px;
                font-size: 10px !important;
            }

            #clickChart,
            #funnelChart,
            #convertedLeadsChart {
                height: 280px !important;
            }

            #deviceChart,
            #osChart {
                height: 250px !important;
            }

            #hourlyDistributionChart,
            #leadsHourlyDistributionChart {
                height: 300px !important;
            }

            .highcharts-container {
                width: 100% !important;
            }

            .modal-dialog.modal-xl {
                max-width: 95%;
                margin: 10px auto;
            }

            .modal-header {
                padding: 12px 15px;
            }

            .modal-body {
                padding: 10px;
            }

            .modal-body .table {
                font-size: 11px;
            }

            .modal-body .table th,
            .modal-body .table td {
                padding: 6px 4px;
            }
        }

        @media (max-width: 575px) {
            .container-fluid.py-4 {
                padding-left: 10px;
                padding-right: 10px;
            }

            .analytics_head {
                margin-top: 3.5rem !important;
            }

            .analytics_head h3 {
                font-size: 18px;
            }

            .analytics-filter-card {
                padding: 12px;
            }

            .analytics-filter-card .form-group label {
                font-size: 12px;
            }

            .analytics-filter-card .form-control {
                height: 34px;
                font-size: 12px;
            }

            .analytics-filter-card select.form-control {
                height: 34px;
            }

            .btn-filter-search,
            .btn-filter-reset {
                padding: 7px 12px;
                font-size: 12px;
            }

            .kpi h2 {
                font-size: 18px;
            }

            .kpi h6 {
                font-size: 9px;
            }

            .col-6.col-lg-3 {
                padding-left: 6px;
                padding-right: 6px;
            }

            .card-ui {
                padding: 15px;
            }

            #deviceTable_info,
            #deviceTable_paginate,
            #osTable_info,
            #osTable_paginate,
            #pageTable_info,
            #pageTable_paginate,
            #sessionTable_info,
            #sessionTable_paginate,
            #heatTable_info,
            #heatTable_paginate {
                padding-top: 0 !important;
                font-size: 10px;
            }

            .dataTables_wrapper .dataTables_paginate .paginate_button .page-link {
                padding: 4px 8px;
                font-size: 11px;
            }

            .hourly-heatmap-header {
                font-size: 13px;
                padding: 10px 12px;
            }

            #hourlyDistributionChart,
            #leadsHourlyDistributionChart {
                height: 250px !important;
            }

            .highcharts-axis-labels text,
            .highcharts-axis-title {
                font-size: 9px !important;
            }

            .highcharts-data-label text {
                font-size: 8px !important;
            }
        }

        @media (max-width: 400px) {
            .kpi {
                min-height: 75px;
                padding: 10px 5px;
            }

            .kpi h2 {
                font-size: 16px;
            }

            .kpi h6 {
                font-size: 8px;
            }

            .analytics-filter-card .btn-filter-search,
            .analytics-filter-card .btn-filter-reset {
                font-size: 11px;
                padding: 6px 10px;
            }

            .col-6.col-lg-3 {
                flex: 0 0 50%;
                max-width: 50%;
                padding-left: 4px;
                padding-right: 4px;
            }

            .card-ui h5 span {
                font-size: 10px !important;
            }

            .session-bounce-hint {
                display: none !important;
            }
        }
    </style>

</head>

<body>
    <div class="wrapper">
        <!-- ===m=== Sidebar Code Started ===m=== -->
        <div class="sidebar" data-color="white" data-active-color="danger">
            <div class="logo">
                <a href="index.php" class="simple-text logo-normal">
                    <div class="logo-image-big pl-5">
                        <img src="./assets/images/webzaa-logo.png">
                    </div>
                </a>
            </div>
            <div class="sidebar-wrapper">
                <ul class="nav">
                    <li class="">
                        <a href="index.php">
                            <span class="iconify" data-icon="ri:dashboard-fill"
                                style="font-size:24px;float:left;margin-right:12px;line-height:30px;width:34px;text-align:center;position:relative;"></span>
                            <p>Dashboard</p>
                        </a>
                    </li>
                    <li class="active">
                        <a href="analytics.php">
                            <i class="nc-icon nc-chart-pie-36"></i>
                            <p>Analytics</p>
                        </a>
                    </li>
                    <li class="">
                        <a href="restricted_ips.php">
                            <i class="nc-icon nc-lock-circle-open"></i>
                            <p>Restricted IP'S</p>
                        </a>
                    </li>
                    <li class="">
                        <a href="meta_capi.php">
                            <span class="iconify" data-icon="ri:meta-fill"
                                style="font-size:24px;float:left;margin-right:12px;line-height:30px;width:34px;text-align:center;position:relative;"></span>
                            <p>Meta CAPI</p>
                        </a>
                    </li>
                    <li class="">
                        <a href="import.php">
                            <i class="nc-icon nc-cloud-upload-94"></i>
                            <p>Import</p>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
        <!-- ===m=== Sidebar Code Ended ===m=== -->

        <div class="main-panel">
            <!-- ===m=== Navbar Code Started ===m=== -->
            <nav class="navbar navbar-expand-lg navbar-absolute fixed-top navbar-transparent">
                <div class="container-fluid">
                    <div class="navbar-wrapper analytics-offset">
                        <div class="navbar-toggle">
                            <button type="button" class="navbar-toggler">
                                <span class="navbar-toggler-bar bar1"></span>
                                <span class="navbar-toggler-bar bar2"></span>
                                <span class="navbar-toggler-bar bar3"></span>
                            </button>
                        </div>
                        <a class="analytics_greeting navbar-brand"
                            href="javascript:;"><?php echo $greeting . ', ' . htmlspecialchars($username); ?></a>
                    </div>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navigation"
                        aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-bar navbar-kebab"></span>
                        <span class="navbar-toggler-bar navbar-kebab"></span>
                        <span class="navbar-toggler-bar navbar-kebab"></span>
                    </button>
                    <div class="collapse navbar-collapse justify-content-end" id="navigation">
                        <form>
                            <div class="input-group no-border"></div>
                        </form>
                        <ul class="navbar-nav">
                            <li class="nav-item btn-rotate dropdown">
                                <a class="nav-link dropdown-toggle" href="" id="navbarDropdownMenuLink"
                                    data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <p><span class="d-lg-none d-md-block">Actions</span></p>
                                </a>
                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownMenuLink">
                                    <a class="dropdown-item" href="./leads/logout.php">Logout</a>
                                    <?php if (isset($_SESSION['role']) && $_SESSION['role'] == 'superadmin')
                                    { ?>
                                        <a class="dropdown-item" href="./leads/users.php">Add Users</a>
                                    <?php } ?>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>
            <!-- ===m=== Navbar Code Ended ===m=== -->

            <div class="container-fluid py-4">

                <!-- HEADER -->
                <div class="analytics_head d-flex justify-content-between align-items-center mb-4">
                    <h3 class="analytics_description">Analytics Dashboard</h3>
                    <a href="index.php" class="btn actionBtn">Back</a>
                </div>

                <!-- ===A=== FILTER SECTION (matching index.php style) ===A=== -->
                <div class="analytics-filter-card">
                    <div class="row">
                        <div class="form-group col-md-3">
                            <label for="analytics_from_date">Date:</label>
                            <input type="text" class="form-control" placeholder="dd-mm-yyyy" id="analytics_from_date">
                            <input type="checkbox" style="margin-left: 2px; margin-top: 5px;" id="analytics_till_date"
                                value="1">
                            <label for="analytics_till_date"> Till Date</label>
                        </div>
                        <div class="form-group col-md-3">
                            <label for="analytics_camp_source">Campaign Source:</label>
                            <select class="form-control" id="analytics_camp_source">
                                <option value="">All</option>
                                <?php
                                $res = mysqli_query($conn, "SELECT DISTINCT campaignsource FROM `lead`");
                                while ($row = mysqli_fetch_array($res))
                                { ?>
                                    <option value="<?php echo $row['campaignsource'] ?>">


                                        <?php echo $row['campaignsource'] ?>
                                    </option>
                                <?php } ?>
                            </select>
                        </div>
                        <div class="form-group col-md-3">
                            <label for="analytics_camp_subsource">Campaign Subsource:</label>
                            <select class="form-control" id="analytics_camp_subsource">
                                <option value="">All</option>
                                <?php
                                $res = mysqli_query($conn, "SELECT DISTINCT campaignsubsource FROM `lead`");
                                while ($row = mysqli_fetch_array($res))
                                { ?>


                                    <option value="<?php echo $row['campaignsubsource'] ?>">
                                        <?php echo $row['campaignsubsource'] ?>
                                    </option>
                                <?php } ?>
                            </select>
                        </div>
                        <div class="form-group col-md-3">
                            <label for="analytics_keyword">Search By:</label>
                            <input type="text" class="form-control" id="analytics_keyword"
                                placeholder="Name/Mobile/Email/keyword">
                        </div>
                        <div class="form-group col-md-12" style="text-align: right; margin-bottom: 0;">
                            <button class="btn btn-filter-search" id="analytics_search">
                                <i class="fa fa-search"></i>&nbsp; Search
                            </button>
                            <button class="btn btn-filter-reset" id="analytics_reset">Reset</button>
                        </div>
                    </div>
                </div>
                <!-- ===A=== FILTER SECTION END ===A=== -->

                <!-- KPI -->
                <div class="row g-3 mb-4">
                    <div class="col-6 col-lg-3 mb-3">
                        <div class="kpi">
                            <h6>Visitors</h6>
                            <h2 id="visitors">0</h2>
                        </div>
                    </div>
                    <div class="col-6 col-lg-3 mb-3">
                        <div class="kpi">
                            <h6>Avg Time on Site</h6>
                            <h2 id="avgtimespent">0</h2>
                        </div>
                    </div>
                    <div class="col-6 col-lg-3 mb-3">
                        <div class="kpi">
                            <h6>Avg Clicks / Visitor</h6>
                            <h2 id="avgclicks">0</h2>
                        </div>
                    </div>
                    <div class="col-6 col-lg-3 mb-3">
                        <div class="kpi">
                            <h6>Avg Clicks / Converted</h6>
                            <h2 id="avgconv">0</h2>
                        </div>
                    </div>
                    <div class="col-6 col-lg-3 mb-3">
                        <div class="kpi">
                            <h6>Converted Leads</h6>
                            <h2 id="conversion">0</h2>
                        </div>
                    </div>
                    <div class="col-6 col-lg-3 mb-3">
                        <div class="kpi">
                            <h6>Bounce Rate</h6>
                            <h2 id="bounceRate" style="color: #d9534f;">0%</h2>
                        </div>
                    </div>
                </div>

                <!-- ===A=== FUNNEL + CONVERTED LEADS side by side ===A=== -->
                <div class="row g-3">
                    <div class="col-lg-6">
                        <div class="card-ui h-100">
                            <h5 class="mb-3">Conversion Funnel</h5>
                            <div id="funnelChart" style="height:350px"></div>
                        </div>
                    </div>
                    <!-- ===m=== Converted Leads Highchart Started ===m=== -->
                    <div class="col-lg-6">
                        <div class="card-ui h-100">
                            <h5 class="mb-3">Converted Leads</h5>
                            <div id="convertedLeadsChart" style="height:350px; width: 100%;"></div>
                        </div>
                    </div>
                    <!-- ===m=== Converted Leads Highchart Ended ===m=== -->
                </div>
                <!-- TOP ELEMENTS + PAGES -->
                <div class="row g-3">
                    <div class="col-lg-6">
                        <div class="card-ui h-100">
                            <h5 class="mb-3">Top Clicked Elements</h5>
                            <div id="clickChart" style="height:350px"></div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="card-ui h-100">
                            <h5 class="mb-3">Top Pages</h5>
                            <div class="table-responsive">
                                <table id="pageTable" class="table table-bordered table-sm">
                                    <thead>
                                        <tr>
                                            <th>Page</th>
                                            <th>Visits</th>
                                        </tr>
                                    </thead>
                                    <tbody></tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- DEVICE + OS -->
                <div class="row g-3">
                    <div class="col-lg-6">
                        <div class="card-ui h-100">
                            <h5>Device Distribution</h5>
                            <div id="deviceChart" style="height:300px"></div>
                            <table id="deviceTable" class="table table-bordered table-sm mt-3">
                                <thead>
                                    <tr>
                                        <th>Device</th>
                                        <th>Clicks</th>
                                        <th>Users</th>
                                    </tr>
                                </thead>
                                <tbody></tbody>
                            </table>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="card-ui h-100">
                            <h5>OS Distribution</h5>
                            <div id="osChart" style="height:300px"></div>
                            <table id="osTable" class="table table-bordered table-sm mt-3">
                                <thead>
                                    <tr>
                                        <th>OS</th>
                                        <th>Clicks</th>
                                        <th>Users</th>
                                    </tr>
                                </thead>
                                <tbody></tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- HEATMAP -->
                <div class="card-ui">
                    <h5 class="mb-3">Click Heatmap</h5>
                    <div class="table-responsive">
                        <table id="heatTable" class="table table-bordered table-sm">
                            <thead>
                                <tr>
                                    <th>Element</th>
                                    <th>Clicks</th>
                                    <th>Users</th>
                                    <th>Heat</th>
                                </tr>
                            </thead>
                            <tbody></tbody>
                        </table>
                    </div>
                </div>

                <!-- ===m=== Visitors Leads Code Started ===m=== -->
                <div class="row g-3 mt-4">
                    <div class="col-12">
                        <div class="hourly-heatmap-card">
                            <div class="hourly-heatmap-header">
                                Visitor Leads: Hourly Distribution Analysis by Day
                            </div>
                            <div class="hourly-heatmap-body">
                                <div id="hourlyDistributionChart" style="height: 400px; width: 100%;"></div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- ===m=== Visitors Leads Code Ended ===m=== -->

                <!-- ===A=== Leads Hourly Heatmap Started ===A=== -->
                <div class="row g-3 mt-4">
                    <div class="col-12">
                        <div class="hourly-heatmap-card">
                            <div class="hourly-heatmap-header">
                                Leads: Hourly Distribution Analysis by Day
                            </div>
                            <div class="hourly-heatmap-body">
                                <div id="leadsHourlyDistributionChart" style="height: 400px; width: 100%;"></div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- ===A=== Leads Hourly Heatmap Ended ===A=== -->

                <!-- SESSIONS -->
                <div class="card-ui">
                    <h5 class="mb-3">Visitor Sessions
                        <span style="font-size:13px; color:#d9534f; margin-left:15px; font-weight:normal;">
                            <i class="fa fa-square"></i> Red rows indicate Bounced Users [Left under 5 seconds]
                        </span>
                    </h5>
                    <div class="table-responsive">
                        <table id="sessionTable" class="table table-bordered table-sm">
                            <thead>
                                <tr>
                                    <th>User</th>
                                    <th>IP Address</th>
                                    <th>Clicks</th>
                                    <th>Time Spent</th>
                                    <th>Source</th>
                                    <th>Sub Source</th>
                                    <th>Last Activity</th>
                                    <th>Interactions</th>
                                </tr>
                            </thead>
                            <tbody></tbody>
                        </table>
                    </div>
                </div>

            </div>
        </div>
    </div>

    <!-- MODAL -->
    <div class="modal fade" id="sessionModal">
        <div class="modal-dialog modal-xl modal-dialog-scrollable">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="sessionTitle"></h5>
                    <button class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <table class="table table-bordered table-sm">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Element</th>
                                <th>Page</th>
                                <th>Time</th>
                            </tr>
                        </thead>
                        <tbody id="sessionRows"></tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- ===m=== Scripts Started ===m=== -->
    <script src="./assets/js/core/jquery.min.js"></script>
    <script src="assets/js/highcharts/highcharts.js"></script>
    <script src="./assets/js/highcharts/heatmap.js"></script>
    <script src="./assets/js/highcharts/exporting.js"></script>
    <script src="./assets/js/highcharts/export-data.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script src="./assets/js/core/popper.min.js"></script>
    <script src="./assets/js/core/bootstrap.min.js"></script>
    <script src="https://code.iconify.design/3/3.1.1/iconify.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.6.1/js/dataTables.buttons.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.6.1/js/buttons.flash.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.6.1/js/buttons.html5.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.6.1/js/buttons.print.min.js"></script>
    <script src="https://cdn.datatables.net/fixedcolumns/3.3.0/js/dataTables.fixedColumns.min.js"></script>
    <script src="https://cdn.datatables.net/colreorder/1.5.2/js/dataTables.colReorder.min.js"></script>
    <script
        src="https://cdnjs.cloudflare.com/ajax/libs/jquery.perfect-scrollbar/1.5.5/perfect-scrollbar.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/paginationjs/2.1.5/pagination.min.js"></script>
    <script src="https://code.jquery.com/ui/1.13.2/jquery-ui.min.js"></script>
    <script type="text/javascript" src="https://cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>
    <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js"></script>
    <script
        src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/js/bootstrap-datepicker.min.js"></script>
    <script src="./assets/js/plugins/bootstrap-notify.js"></script>
    <script src="./assets/js/paper-dashboard.min.js?v=2.0.1" type="text/javascript"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://unpkg.com/heatmap.js@2.0.5/build/heatmap.min.js"></script>
    <!-- ===m=== Scripts Ended ===m=== -->

    <script>
        let modal = new bootstrap.Modal(document.getElementById('sessionModal'));

        // ===A=== Date Range Picker init ===A===
        var start = moment().subtract(6, 'days');
        var end = moment();

        $('#analytics_from_date').daterangepicker({
            startDate: start,
            endDate: end,
            locale: {
                format: 'DD/MM/YYYY'
            },
            ranges: {
                'Today': [moment(), moment()],
                'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
                'Last 7 Days': [moment().subtract(6, 'days'), moment()],
                'Last 30 Days': [moment().subtract(29, 'days'), moment()],
                'This Month': [moment().startOf('month'), moment().endOf('month')],
                'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
            }
        });

        // ===A=== Disable date picker when "Till Date" is checked ===A===
        $(document).on('click', '#analytics_till_date', function () {
            if ($('#analytics_till_date').is(':checked')) {
                $('#analytics_from_date').attr('disabled', true);
            } else {
                $('#analytics_from_date').attr('disabled', false);
            }
        });

        // ===A=== Helper: get current filter values ===A===
        function getFilters() {
            return {
                from_date: $('#analytics_from_date').val(),
                camp_source: $('#analytics_camp_source').val(),
                camp_subsource: $('#analytics_camp_subsource').val(),
                keyword: $('#analytics_keyword').val(),
                till_date: $('#analytics_till_date').is(':checked') ? 1 : ''
            };
        }

        // ===A=== Search button ===A===
        $(document).on('click', '#analytics_search', function () {
            loadDashboard();
            loadHeatmap();
            loadHourlyDistribution();
            loadLeadsHourlyDistribution();
        });

        // ===A=== Reset button ===A===
        $(document).on('click', '#analytics_reset', function () {
            $('#analytics_from_date').val('');
            $('#analytics_camp_source').val('');
            $('#analytics_camp_subsource').val('');
            $('#analytics_keyword').val('');
            $('#analytics_till_date').prop('checked', false);
            $('#analytics_from_date').attr('disabled', false);
            loadDashboard();
            loadHeatmap();
            loadHourlyDistribution();
            loadLeadsHourlyDistribution();
        });

        // ===A=== FIXED: loadDashboard now passes filters ===A===
        function loadDashboard() {
            var filters = getFilters();
            $.getJSON("analytics/get_analytics.php", filters, function (d) {
                $("#visitors").text(d.visitors);
                $("#avgclicks").text(d.avg_clicks);
                $("#avgconv").text(d.avg_conv_clicks);
                $("#conversion").text(d.converted_sessions);

                let t = d.avg_time_spent;
                let timeLabel = t >= 60 ? Math.floor(t / 60) + 'm ' + (t % 60) + 's' : t + 's';
                $("#avgtimespent").text(timeLabel);

                /* ===A=== FUNNEL - fixed: now column chart like Top Clicked Elements ===A=== */
                Highcharts.chart('funnelChart', {
                    chart: {
                        type: 'column'
                    },
                    title: {
                        text: null
                    },
                    exporting: {
                        enabled: false
                    },
                    xAxis: {
                        categories: ["Visitors", "Clicks", "Leads"]
                    },
                    yAxis: {
                        title: {
                            text: null
                        }
                    },
                    legend: {
                        enabled: false
                    },
                    plotOptions: {
                        column: {
                            borderRadius: 4,
                            dataLabels: {
                                enabled: true,
                                style: {
                                    fontWeight: 'bold',
                                    fontSize: '13px'
                                }
                            }
                        }
                    },
                    series: [{
                        name: 'Count',
                        color: '#e84e24',
                        data: [d.visitors, d.clicks, d.converted_sessions]
                    }],
                    credits: {
                        enabled: false
                    }
                });

                // ===m=== Converted Leads Highchart Started ===m===
                Highcharts.chart('convertedLeadsChart', {
                    chart: {
                        type: 'column',
                        backgroundColor: 'transparent'
                    },
                    title: {
                        text: null
                    },
                    exporting: {
                        enabled: false
                    },
                    xAxis: {
                        categories: ["Converted Lead Clicks", "Converted Leads"]
                    },
                    yAxis: {
                        min: 0,
                        title: {
                            text: 'Count'
                        },
                        allowDecimals: false
                    },
                    legend: {
                        enabled: false
                    },
                    plotOptions: {
                        column: {
                            dataLabels: {
                                enabled: true,
                                style: {
                                    fontWeight: 'bold',
                                    fontSize: '13px'
                                }
                            }
                        }
                    },
                    tooltip: {
                        formatter: function () {
                            return `<b>${this.key}</b><br/>Count: <b>${this.y}</b>`;
                        }
                    },
                    series: [{
                        name: 'Count',
                        color: '#e84e24',
                        data: [d.converted_clicks, d.converted_sessions]
                    }],
                    credits: {
                        enabled: false
                    }
                });
                // ===m=== Converted Leads Highchart Ended ===m===

                /* ELEMENTS */
                let topElements = d.elements.sort((a, b) => parseInt(b.total) - parseInt(a.total)).slice(0, 5);
                Highcharts.chart('clickChart', {
                    chart: {
                        type: 'column'
                    },
                    title: {
                        text: null
                    },
                    exporting: {
                        enabled: false
                    },
                    xAxis: {
                        categories: topElements.map(e => e.element_name)
                    },
                    series: [{
                        name: 'Clicks',
                        color: '#e84e24',
                        data: topElements.map(e => parseInt(e.total))
                    }],
                    credits: {
                        enabled: false
                    }
                });

                /* PAGES */
                let p = "";
                d.pages.forEach(r => {
                    p += `<tr><td class="url-cell">${r.page}</td><td>${r.total}</td></tr>`;
                });
                initTable("#pageTable", p);

                // ===m=== Device Pie Chart Started ===m===
                let devRows = "";
                let deviceValues = d.devices.map(o => o.users);
                let minDevice = Math.min(...deviceValues);
                let maxDevice = Math.max(...deviceValues);
                d.devices.forEach(r => {
                    devRows += `<tr><td>${r.device}</td><td>${r.clicks}</td><td>${r.users}</td></tr>`;
                });
                initTable("#deviceTable", devRows);
                Highcharts.chart('deviceChart', {
                    chart: {
                        type: 'pie'
                    },
                    title: {
                        text: null
                    },
                    exporting: {
                        enabled: false
                    },
                    series: [{
                        data: d.devices.map(o => ({
                            name: o.device,
                            y: o.users,
                            color: getOrangeShade(o.users, minDevice, maxDevice)
                        }))
                    }],
                    credits: {
                        enabled: false
                    }
                });
                // ===m=== Device Pie Chart Ended ===m===

                // ===m=== OS Pie Chart Started ===m===
                let osRows = "";
                let osValues = d.os.map(o => o.users);
                let minOS = Math.min(...osValues);
                let maxOS = Math.max(...osValues);
                d.os.forEach(r => {
                    osRows += `<tr><td>${r.os}</td><td>${r.clicks}</td><td>${r.users}</td></tr>`;
                });
                initTable("#osTable", osRows);
                Highcharts.chart('osChart', {
                    chart: {
                        type: 'pie'
                    },
                    title: {
                        text: null
                    },
                    exporting: {
                        enabled: false
                    },
                    series: [{
                        data: d.os.map(o => ({
                            name: o.os,
                            y: o.users,
                            color: getOrangeShade(o.users, minOS, maxOS)
                        }))
                    }],
                    credits: {
                        enabled: false
                    }
                });
                // ===m=== OS Pie Chart Ended ===m===

                // ===m=== Pie Charts Color Helper Started ===m===
                function getOrangeShade(value, min, max) {
                    if (max === min) return '#e84e24a7';
                    let ratio = (value - min) / (max - min);
                    let opacity = 0.25 + (ratio * 0.75);
                    return `rgba(232,78,36,${opacity})`;
                }
                // ===m=== Pie Charts Color Helper Ended ===m===

                // ===m=== Visitor Sessions Started ===m===
                $("#bounceRate").text(d.bounce_rate);

                // ===m=== Visitor Sessions Started ===m===
                let s = "";
                d.sessions.forEach(r => {
                    let dur = r.session_duration;

                    // Identify if it's a bounce (Time is null, or time is <= 5 seconds)
                    let isBounced = (dur === null || dur <= 5);
                    let rowStyle = isBounced ? 'style="background-color: #ffeef0;"' : '';
                    let textStyle = isBounced ? 'color: #d9534f; font-weight: 500;' : '';

                    let timeStr = dur ? (dur >= 60 ? Math.floor(dur / 60) + 'm ' + (dur % 60) + 's' : dur + 's') : '-';

                    let label = r.lead_name ?
                        `<span class="badge" style="background:${isBounced ? '#d9534f' : '#6a6968'};">${r.lead_name}</span>` :
                        `<span class="badge" style="background:${isBounced ? '#d9534f' : '#6a6968'};">${r.session_id}</span>`;

                    s += `<tr ${rowStyle}>
                        <td>${label}</td>
                        <td style="${textStyle}">${r.ip_address}</td>
                        <td style="${textStyle}">${r.clicks}</td>
                        <td style="${textStyle}">${timeStr}</td>
                        <td style="${textStyle}">${r.source}</td>
                        <td style="${textStyle}">${r.subsource}</td>
                        <td style="${textStyle}">${r.last_activity}</td>
                        <td><button class="btn btn-sm view" style="background:#6a6968;color:#fff;" data-id="${r.session_id}">View</button></td>
                    </tr>`;
                });
                // initTable("#sessionTable", s);
                if ($.fn.DataTable.isDataTable("#sessionTable")) {
                    $("#sessionTable").DataTable().destroy();
                }
                $("#sessionTable tbody").html(s);
                $("#sessionTable").DataTable({
                    "order": [
                        [6, "desc"]
                    ], 
                    "pageLength": 10
                });
                // ===m=== Visitor Sessions Ended ===m===
            });
        }

        // ===A=== FIXED: loadHeatmap now passes filters ===A===
        function loadHeatmap() {
            var filters = getFilters();
            $.getJSON("analytics/get_heatmap.php", filters, function (data) {
                let h = "";
                data.forEach(r => {
                    let pct = Math.min(r.clicks * 5, 100);
                    h += `<tr>
                        <td>${r.element_name}</td>
                        <td>${r.clicks}</td>
                        <td>${r.users}</td>
                        <td><div class="heatbar" style="background:linear-gradient(90deg,#ff4d4d ${pct}%,#eee ${pct}%);"></div></td>
                    </tr>`;
                });
                initTable("#heatTable", h);
            });
        }

        // ===A=== FIXED: only one definition of loadHourlyDistribution, passes filters ===A===
        function loadHourlyDistribution() {
            var filters = getFilters();
            $.getJSON("analytics/get_hourly_distribution.php", filters, function (data) {
                Highcharts.chart('hourlyDistributionChart', {
                    chart: {
                        type: 'heatmap',
                        marginTop: 40,
                        marginBottom: 110,
                        plotBorderWidth: 1
                    },
                    title: {
                        text: null
                    },
                    exporting: {
                        enabled: true // ← ADD THIS
                    },
                    xAxis: {
                        categories: ['00:00 - 04:00', '04:00 - 08:00', '08:00 - 12:00', '12:00 - 16:00', '16:00 - 20:00', '20:00 - 00:00'],
                        lineWidth: 0,
                        tickLength: 0,
                        gridLineWidth: 0,
                        title: {
                            text: '4-Hour Intervals',
                            style: {
                                fontSize: '15px',
                                color: '#666',
                                fontWeight: 'bold'
                            }
                        }
                    },
                    yAxis: {
                        categories: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'],
                        title: {
                            text: 'Days of the Week',
                            style: {
                                fontSize: '15px',
                                color: '#666',
                                fontWeight: 'bold'
                            }
                        },
                        reversed: true
                    },
                    colorAxis: {
                        min: 0,
                        max: Math.max(...data.map(p => Array.isArray(p) ? p[2] : p.value), 1),
                        stops: [
                            [0, '#e84e2441'],
                            [0.5, '#e84e24a7'],
                            [1, '#e84e24']
                        ]
                    },
                    legend: {
                        align: 'center',
                        layout: 'horizontal',
                        margin: 0,
                        verticalAlign: 'bottom',
                        y: 20,
                        symbolWidth: 280
                    },
                    tooltip: {
                        formatter: function () {
                            return '<b>' + this.series.yAxis.categories[this.point.y] + '</b><br>' +
                                this.series.xAxis.categories[this.point.x] + '<br>' +
                                'Visitors: <b>' + this.point.value + '</b>';
                        }
                    },
                    series: [{
                        name: 'Visitors',
                        borderWidth: 1,
                        borderColor: '#dee2e6',
                        data: data,
                        dataLabels: {
                            enabled: true,
                            color: '#000000',
                            style: {
                                textOutline: 'none',
                                fontWeight: 'normal',
                                fontSize: '12px'
                            }
                        }
                    }],
                    credits: {
                        enabled: false
                    }
                });
            });
        }

        /* TABLE INIT */
        function initTable(id, html) {
            if ($.fn.DataTable.isDataTable(id)) {
                $(id).DataTable().destroy();
            }
            $(id + " tbody").html(html);
            $(id).DataTable({
                "order": [
                    [1, "desc"]
                ],
                "pageLength": 10
            });
        }

        /* SESSION DETAILS */
        $(document).on("click", ".view", function () {
            let id = $(this).data("id");
            $.post("analytics/get_session_journey.php", {
                session: id
            }, function (res) {
                $("#sessionTitle").text(res.lead ? "Lead: " + res.lead : "Session: " + res.session);
                let rows = "";
                let i = 1;
                res.clicks.forEach(c => {
                    rows += `<tr><td>${i++}</td><td>${c.element_name}</td><td>${c.page}</td><td>${c.created_at}</td></tr>`;
                });
                $("#sessionRows").html(rows);
                modal.show();
            }, "json");
        });

        // ===A=== Leads Hourly Heatmap Function Started ===A===
        function loadLeadsHourlyDistribution() {
            var filters = getFilters();
            $.ajax({
                url: "analytics/get_leads_hourly_distribution.php",
                data: filters,
                success: function (raw) {
                    var data;
                    try {
                        data = typeof raw === 'string' ? JSON.parse(raw) : raw;
                    } catch (e) {
                        $('#leadsHourlyDistributionChart').html(
                            '<pre style="padding:15px;color:red;font-size:12px;"><b>JSON Error:</b><br>' + raw + '</pre>'
                        );
                        return;
                    }

                    // Build full 7×6 grid defaulting to 0
                    var grid = {};
                    for (var day = 0; day < 7; day++) {
                        for (var hour = 0; hour < 6; hour++) {
                            grid[day + '_' + hour] = 0;
                        }
                    }
                    // Overlay real data onto grid
                    data.forEach(function (point) {
                        var x = Array.isArray(point) ? point[0] : point.x;
                        var y = Array.isArray(point) ? point[1] : point.y;
                        var v = Array.isArray(point) ? point[2] : point.value;
                        grid[y + '_' + x] = v;
                    });
                    // Flatten to [x, y, value] — all 42 slots guaranteed
                    var fullData = [];
                    for (var day = 0; day < 7; day++) {
                        for (var hour = 0; hour < 6; hour++) {
                            fullData.push([hour, day, grid[day + '_' + hour]]);
                        }
                    }

                    Highcharts.chart('leadsHourlyDistributionChart', {
                        chart: {
                            type: 'heatmap',
                            marginTop: 40,
                            marginBottom: 110,
                            plotBorderWidth: 1
                        },
                        title: {
                            text: null
                        },
                        exporting: {
                            enabled: true
                        },
                        xAxis: {
                            categories: ['00:00 - 04:00', '04:00 - 08:00', '08:00 - 12:00', '12:00 - 16:00', '16:00 - 20:00', '20:00 - 00:00'],
                            lineWidth: 0,
                            tickLength: 0,
                            gridLineWidth: 0,
                            title: {
                                text: '4-Hour Intervals',
                                style: {
                                    fontSize: '15px',
                                    color: '#666',
                                    fontWeight: 'bold'
                                }
                            }
                        },
                        yAxis: {
                            categories: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'],
                            title: {
                                text: 'Days of the Week',
                                style: {
                                    fontSize: '15px',
                                    color: '#666',
                                    fontWeight: 'bold'
                                }
                            },
                            reversed: true
                        },
                        colorAxis: {
                            min: 0,
                            max: Math.max(...data.map(p => Array.isArray(p) ? p[2] : p.value), 1),
                            stops: [
                                [0, '#e84e2441'],
                                [0.5, '#e84e24a7'],
                                [1, '#e84e24']
                            ]
                        },
                        legend: {
                            align: 'center',
                            layout: 'horizontal',
                            margin: 0,
                            verticalAlign: 'bottom',
                            y: 20,
                            symbolWidth: 280
                        },
                        tooltip: {
                            formatter: function () {
                                return '<b>' + this.series.yAxis.categories[this.point.y] + '</b><br>' +
                                    this.series.xAxis.categories[this.point.x] + '<br>' +
                                    'Leads: <b>' + this.point.value + '</b>';
                            }
                        },
                        series: [{
                            name: 'Leads',
                            borderWidth: 1,
                            borderColor: '#dee2e6',
                            data: fullData,
                            dataLabels: {
                                enabled: true,
                                color: '#000000',
                                style: {
                                    textOutline: 'none',
                                    fontWeight: 'normal',
                                    fontSize: '12px'
                                }
                            }
                        }],
                        credits: {
                            enabled: false
                        }
                    });
                },
                error: function (xhr) {
                    $('#leadsHourlyDistributionChart').html(
                        '<pre style="padding:15px;color:red;font-size:12px;"><b>API Error ' + xhr.status + ':</b><br>' + xhr.responseText + '</pre>'
                    );
                }
            });
        }
        // ===A=== Leads Hourly Heatmap Function Ended ===A===

        // ===m=== Calling the functions ===m===
        loadDashboard();
        loadHeatmap();
        loadHourlyDistribution();
        loadLeadsHourlyDistribution();
    </script>

    <!-- ===m=== Analytics Script Code ===m=== -->
    <script>
        $(document).ready(function () {
            function sendLog(actionType, dataPayload) {
                dataPayload.action_type = actionType;
                dataPayload.current_url = window.location.pathname + window.location.search;
                $.ajax({
                    url: 'leads/ajax_log_activity.php',
                    type: 'POST',
                    data: dataPayload,
                    error: function () {
                        console.log("Background log failed");
                    }
                });
            }
            $(document).on('click', 'a[href*="logout.php"]', function (e) {
                e.preventDefault();
                e.stopImmediatePropagation();
                let logoutUrl = $(this).attr('href');
                sendLog('logout', {
                    clicked_element: 'Logout'
                });
                setTimeout(function () {
                    window.location.href = logoutUrl;
                }, 400);
                return;
            });
            $(document).on('click', 'a, button, input[type="button"], input[type="submit"], [role="button"], .nav-link, .dropdown-item,[data-bs-toggle], [data-toggle]', function (e) {
                let $el = $(this);
                let text = $el.text().trim() || $el.val() || $el.attr('title') || $el.attr('aria-label') || 'Icon/Element';
                let href = $el.attr('href') || '';
                let id = $el.attr('id') || '';
                let textLower = text.toLowerCase();
                if (text.length > 50) text = text.substring(0, 50) + '...';
                if (href.toLowerCase().includes('javascript:') && text === 'Icon/Element') return;
                if (textLower.includes('export') || textLower.includes('download') || href.toLowerCase().includes('export.php')) {
                    sendLog('report_download', {
                        report_name: text || 'Export Data'
                    });
                    return;
                }
                if (textLower.includes('search') || $el.attr('id') === 'search-btn' || $el.hasClass('search')) {
                    let searchTerm = $el.closest('form, div, .row').find('input[type="text"], input[type="search"]').val();
                    if (searchTerm && searchTerm.trim() !== '') {
                        sendLog('search', {
                            search_term: searchTerm.trim()
                        });
                        return;
                    }
                }
                let elementDetails = text;
                if (href && href !== '#' && !href.toLowerCase().includes('javascript:')) {
                    elementDetails += ' (' + href + ')';
                } else if (id) {
                    elementDetails += ' (#' + id + ')';
                }
                sendLog('click', {
                    clicked_element: elementDetails
                });
            });
            $(document).on('keypress', 'input', function (e) {
                if (e.which == 13) {
                    let inputAttributes = ($(this).attr('id') || '') + ($(this).attr('name') || '') + ($(this).attr('placeholder') || '');
                    if (inputAttributes.toLowerCase().includes('search')) {
                        let searchTerm = $(this).val().trim();
                        if (searchTerm !== '') {
                            sendLog('search', {
                                search_term: searchTerm
                            });
                        }
                    }
                }
            });

            // ===m=== Toggle Scroll To Top Button ===m===
            $(document).on('change', 'select', function () {
                let selectIdentifier = $(this).attr('name') || $(this).attr('id') || 'Dropdown';
                let selectedText = $(this).find('option:selected').text().trim();
                sendLog('change', {
                    changed_element: selectIdentifier,
                    new_value: selectedText
                });
            });
            $('.main-panel').scroll(function () {
                if ($(this).scrollTop() > 300) {
                    $('#scrollToTopBtn').fadeIn();
                } else {
                    $('#scrollToTopBtn').fadeOut();
                }
            });
            $('#scrollToTopBtn').click(function () {
                $('.main-panel').animate({
                    scrollTop: 0
                }, 500);
                return false;
            });
        });
    </script>
    <!-- ===m=== Analytics Script Code ===m=== -->

    <button id="scrollToTopBtn" title="Go to top">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#ffffff" stroke-width="2.5"
            stroke-linecap="round" stroke-linejoin="round">
            <line x1="12" y1="19" x2="12" y2="5"></line>
            <polyline points="5 12 12 5 19 12"></polyline>
        </svg>
    </button>

</body>

</html>