<?php
session_start();

if (isset($_SESSION["user_logged"]) && $_SESSION["user_logged"] == "Y") {
    header("Location: index.php");
    exit;
}
?>

<!DOCTYPE html>
<html>

<head>
    <title>Webzaa | Admin Login</title>

    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="./assets/css/style.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <link rel="icon" type="image/png" href="./assets/img/favicon.png">

    <style>
        body {
            margin: 0;
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #ffffff 0%, #f2f2f2 100%);
            overflow: hidden;
        }

        /* Floating Icon Background */
        .bg-icons {
            position: fixed;
            width: 100%;
            height: 100%;
            top: 0;
            left: 0;
            z-index: 0;
            filter: blur(1px);
        }

        /* Orange icons */
        .bg-icons img {
            position: absolute;
            width: 70px;
            opacity: 1.0;
            filter: brightness(0) saturate(100%) invert(48%) sepia(96%) saturate(2100%) hue-rotate(355deg) brightness(95%) contrast(90%);
            animation: float 5s ease-in-out infinite alternate;
            transition: 0.3s;
        }

        /* Top Row */
        .bg-icons img:nth-child(1) {
            top: 5%;
            left: 8%;
            animation-duration: 8s;
        }

        .bg-icons img:nth-child(2) {
            top: 8%;
            left: 80%;
            animation-duration: 9s;
        }

        /* Upper Middle */
        .bg-icons img:nth-child(3) {
            top: 28%;
            left: 20%;
            animation-duration: 7s;
        }

        .bg-icons img:nth-child(4) {
            top: 25%;
            left: 70%;
            animation-duration: 10s;
        }

        /* Center */
        .bg-icons img:nth-child(5) {
            top: 85%;
            left: 65%;
            animation-duration: 6s;
        }

        /* Lower Middle */
        .bg-icons img:nth-child(6) {
            top: 65%;
            left: 10%;
            animation-duration: 9s;
        }

        .bg-icons img:nth-child(7) {
            top: 65%;
            left: 80%;
            animation-duration: 8s;
        }

        /* Bottom Area */
        .bg-icons img:nth-child(8) {
            top: 85%;
            left: 30%;
            animation-duration: 11s;
        }

        /* Floating effect */
        @keyframes float {
            from {
                transform: translateY(0px);
            }

            to {
                transform: translateY(-20px);
            }
        }

        /* Center wrapper */
        .wrapper {
            position: relative;
            z-index: 2;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        /* Premium Card */
        #formContent {
            background: #ffffff;
            width: 100%;
            max-width: 420px;
            border-radius: 18px;
            padding: 45px;
            text-align: center;
            box-shadow:
                0 20px 50px rgba(0, 0, 0, 0.08),
                0 0 40px rgba(232, 78, 36, 0.05);
            border: 1px dashed #e9532a;
        }

        /* Inputs */
        input {
            width: 100%;
            padding: 14px;
            border: 1px dashed #6a6968;
            border-radius: 8px;
            margin-bottom: 15px;
            transition: 0.3s;
        }

        input:hover {
            border-color: #e9532a;
            outline: none;
            box-shadow: 0 0 0 3px rgba(232, 78, 36, 0.15);
            transform: translateY(-2px);
        }

        input:focus {
            border-color: #e84e24;
            outline: none;
            box-shadow: 0 0 0 3px rgba(232, 78, 36, 0.15);
        }

        /* Button */
        button {
            background: #e9532a;
            border: 1px dashed #ffffff !important;
            padding: 12px;
            width: 100%;
            color: #ffffff;
            border-radius: 8px;
            font-weight: 600;
            transition: 0.3s;
        }

        button:hover {
            background: #fff5f2;
            color: #e9532a;
            border: 1px dashed #e9532a !important;
            transform: translateY(-2px);
        }

        button:focus {
            /* background: #e84e24 !important; */
            outline: none;
            transform: translateY(-2px);
        }

        /* Message */
        .msg {
            margin-top: 15px;
        }

        #otpBox {
            display: none;
        }

        #icon {
            width: 150px;
            margin-bottom: 25px;
        }

        /* Google Button */
        .google-btn {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            background: #ffffff;
            color: #6a6968;
            border: 1.5px dashed #6a6968;
            padding: 12px;
            width: 100%;
            border-radius: 8px;
            font-weight: 600;
            font-size: 14px;
            cursor: pointer;
            transition: 0.3s;
            /* margin-top: 12px; */
            margin: 1rem 0rem;
            text-decoration: none;
        }

        .google-btn:hover {
            border-color: #e84e24;
            background: #fff5f2;
            color: #e84e24;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(232, 78, 36, 0.15);
            text-decoration: none;
        }

        .google-btn img {
            width: 20px;
            height: 20px;
            filter: none;
            /* override your global img filter */
            position: static;
            animation: none;
            opacity: 1;
        }

        .divider-text {
            display: flex;
            align-items: center;
            gap: 10px;
            margin: 15px 0 5px;
            color: #aaa;
            font-size: 13px;
        }

        .divider-text::before,
        .divider-text::after {
            content: '';
            flex: 1;
            height: 1px;
            background: #e0e0e0;
        }

        /* ===m=== Responsive Styles ===m=== */
        @media (max-width: 767px) {
            body {
                overflow: auto;
            }

            .bg-icons img {
                width: 45px;
                opacity: 1.0;
            }

            .bg-icons img:nth-child(1) {
                top: 5%;
                left: 10%;
            }

            .bg-icons img:nth-child(2) {
                top: 5%;
                left: 75%;
            }

            .bg-icons img:nth-child(3) {
                top: 22%;
                left: 8%;
            }

            .bg-icons img:nth-child(4) {
                top: 20%;
                left: 82%;
            }

            .bg-icons img:nth-child(5) {
                top: 75%;
                left: 50%;
            }

            .bg-icons img:nth-child(6) {
                top: 80%;
                left: 5%;
            }

            .bg-icons img:nth-child(7) {
                top: 82%;
                left: 88%;
            }

            .bg-icons img:nth-child(8) {
                top: 92%;
                left: 45%;
            }

            #formContent {
                max-width: 92%;
                padding: 30px 25px;
                border-radius: 14px;
                border: 1px dashed #e9532a;
            }

            #icon {
                width: 120px;
                margin-bottom: 20px;
            }

            input {
                padding: 12px;
                font-size: 14px;
                border: 1px dashed #6a6968;
            }

            input:hover {
                border-color: #e84e24;
                outline: none;
                box-shadow: 0 0 0 3px rgba(232, 78, 36, 0.15);
                transform: translateY(-2px);
            }

            input:focus {
                border-color: #e84e24;
                outline: none;
                box-shadow: 0 0 0 3px rgba(232, 78, 36, 0.15);
            }

            button {
                padding: 12px;
                font-size: 14px;
                border: 1px dashed #ffffff;
            }

            .wrapper {
                min-height: 100vh;
                height: auto;
                padding: 20px 0;
            }
        }

        @media (max-width: 400px) {
            .bg-icons img {
                width: 35px;
                opacity: 1.0;
            }

            .bg-icons img:nth-child(5) {
                display: none;
            }

            #formContent {
                max-width: 95%;
                padding: 25px 18px;
                border: 1px dashed #e9532a;
            }

            #icon {
                width: 100px;
                margin-bottom: 15px;
            }

            input {
                padding: 11px;
                font-size: 13px;
                margin-bottom: 12px;
                border: 1px dashed #6a6968;
            }

            input:hover {
                border-color: #e84e24;
                outline: none;
                box-shadow: 0 0 0 3px rgba(232, 78, 36, 0.15);
                transform: translateY(-2px);
            }

            input:focus {
                border-color: #e84e24;
                outline: none;
                box-shadow: 0 0 0 3px rgba(232, 78, 36, 0.15);
            }

            button {
                padding: 11px;
                font-size: 13px;
                border: 1px dashed #ffffff;
            }
        }

        @media (max-height: 580px) {
            body {
                overflow: auto;
            }

            .wrapper {
                min-height: 100vh;
                height: auto;
                padding: 15px 0;
            }
        }
    </style>
</head>

<body>

    <!-- Floating Background Icons -->
    <div class="bg-icons">
        <img src="https://cdn.jsdelivr.net/npm/heroicons@2.0.18/24/outline/chart-bar.svg">
        <img src="https://cdn.jsdelivr.net/npm/heroicons@2.0.18/24/outline/currency-dollar.svg">
        <img src="https://cdn.jsdelivr.net/npm/heroicons@2.0.18/24/outline/light-bulb.svg">
        <img src="https://cdn.jsdelivr.net/npm/heroicons@2.0.18/24/outline/chat-bubble-left-right.svg">
        <img src="https://cdn.jsdelivr.net/npm/heroicons@2.0.18/24/outline/shopping-cart.svg">
        <img src="https://cdn.jsdelivr.net/npm/heroicons@2.0.18/24/outline/rocket-launch.svg">
        <img src="https://cdn.jsdelivr.net/npm/heroicons@2.0.18/24/outline/trophy.svg">
        <img src="https://cdn.jsdelivr.net/npm/heroicons@2.0.18/24/outline/users.svg">
    </div>
    <div class="wrapper">

        <div id="formContent">

            <img src="./assets/images/webzaa-logo.png" id="icon">

            <!-- EMAIL STEP -->
            <!-- EMAIL STEP -->
            <div id="emailBox">
                <input type="email" id="email" placeholder="Enter your Email">
                <button id="sendOtpBtn">Send OTP</button>
            </div>

            <!-- DIVIDER -->
            <div class="divider-text">or</div>

            <!-- GOOGLE LOGIN BUTTON -->
            <a href="google_callback.php" class="google-btn">
                <img src="https://www.svgrepo.com/show/475656/google-color.svg" alt="Google">
                Login with Google
            </a>

            <!-- OTP STEP -->
            <div id="otpBox">

                <input type="text" id="otp" placeholder="Enter OTP">

                <button id="verifyOtpBtn">Verify & Login</button>

            </div>

            <div class="msg"></div>

            <!-- <div class="change-email-wrapper">
                <a href="#" id="changeEmail">Back</a>
            </div> -->

            <div class="otp-actions">
                <a href="#" id="backToEmail">← Back</a>
                <span class="divider">|</span>
                <a href="#" id="resendOtp">Resend OTP</a>
            </div>
        </div>

    </div>

    <script>
        $(document).ready(function() {
            const urlParams = new URLSearchParams(window.location.search);
            const googleError = urlParams.get('google_error');

            const errorMessages = {
                'not_registered': 'Your Google account is not registered.',
                'blocked': 'Your account is blocked. Contact admin.',
                'token_failed': 'Google login failed. Please try again.',
                'userinfo_failed': 'Could not fetch Google account info.',
                'no_email': 'No email found in your Google account.'
            };

            if (googleError && errorMessages[googleError]) {
                showMsg(errorMessages[googleError], "danger");
                history.replaceState(null, '', 'login.php');
            }
        });

        $("#sendOtpBtn").click(function() {

            let email = $("#email").val().trim();

            if (email == "") {
                showMsg("Enter email address", "danger");
                return;
            }

            let btn = $(this);

            $.ajax({
                url: "leads/ajax_send_otp.php",
                type: "POST",
                data: {
                    email: email
                },
                // beforeSend: function() {
                //     showMsg("Sending OTP...", "info");
                // },
                beforeSend: function() {
                    btn.prop("disabled", true);
                    btn.data("original-text", btn.text());
                    // btn.text("Sending...");
                    btn.html('<span class="spinner-border spinner-border-sm mr-2"></span> Sending OTP...');
                },
                success: function(res) {

                    btn.prop("disabled", false);
                    btn.text(btn.data("original-text"));

                    if (res == "sent") {
                        $("#emailBox").hide();
                        $(".divider-text").hide();
                        $(".google-btn").hide();
                        $("#otpBox").fadeIn();
                        $(".otp-actions").fadeIn();
                        showMsg(
                            'OTP sent successfully to <strong>' + email + '</strong>',
                            "success"
                        );
                    } else {
                        showMsg(res, "danger");
                    }
                }
            });

        });

        $("#verifyOtpBtn").click(function() {

            let email = $("#email").val();
            let otp = $("#otp").val().trim();

            if (otp == "") {
                showMsg("Enter OTP", "danger");
                return;
            }

            $.ajax({
                url: "leads/ajax_verify_otp.php",
                type: "POST",
                data: {
                    email: email,
                    otp: otp
                },
                beforeSend: function() {
                    showMsg("Verifying...", "info");
                },
                success: function(res) {

                    if (res == "success") {
                        window.location = "index.php";
                    } else {
                        showMsg(res, "danger");
                    }
                }
            });

        });


        function showMsg(msg, type) {
            $(".msg").html(`<div class="alert alert-${type}">${msg}</div>`);
        }

        // ===m=== Go Back to OTP ===m===
        $(document).on("click", "#backToEmail", function(e) {
            e.preventDefault();
            $("#otpBox").hide();
            $(".divider-text").show();
            $(".google-btn").show();
            $("#emailBox").fadeIn();
            $(".otp-actions").hide();
            $(".msg").html("");
            $("#otp").val("");
        });
        // ===m=== Go Back to OTP ===m===

        // ===m=== Resend OTP Started ===m===
        $(document).on("click", "#resendOtp", function(e) {
            e.preventDefault();

            let email = $("#email").val().trim();

            if (email == "") {
                showMsg("Email missing. Please go back.", "danger");
                return;
            }

            $.ajax({
                url: "leads/ajax_send_otp.php",
                type: "POST",
                data: {
                    email: email
                },
                beforeSend: function() {
                    showMsg("Resending OTP...", "info");
                },
                success: function(res) {
                    if (res == "sent") {
                        showMsg("OTP resent successfully", "success");
                    } else {
                        showMsg(res, "danger");
                    }
                }
            });
        });
        // ===m=== Resend OTP Ended ===m===
    </script>

</body>

</html>