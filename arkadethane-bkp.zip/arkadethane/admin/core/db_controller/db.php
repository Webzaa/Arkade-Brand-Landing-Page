<?php
$servername = "localhost";
$username = "root";
$password = "Webadmin@931!!";
$dbname = "test_arkadebrand";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// ===m=== Masking Logic Started ===m===
function renderMaskedData($data, $type = 'email')
{
    // ===m=== If unmasking is permitted in session, show real data immediately ===m===
    // ===m=== 1. For email, check 'unmask_email' session variable ===m===
    if ($type === 'email' && isset($_SESSION['unmask_email']) && $_SESSION['unmask_email'] === 'Y')
    {
        return htmlspecialchars($data);
    }
    // ===m=== 2. For mobile, check 'unmask_mobile' session variable ===m===
    if ($type === 'mobile' && isset($_SESSION['unmask_mobile']) && $_SESSION['unmask_mobile'] === 'Y')
    {
        return htmlspecialchars($data);
    }
    // ===m=== Otherwise, mask the data ===m===
    if (empty($data))
        return '';

    if ($type === 'email')
    {
        $parts = explode("@", $data);
        if (count($parts) < 2)
            return "*****"; // safe fallback
        // ===m=== Shows "ab******@gmail.com" ===m===
        return substr($parts[0], 0, 2) . str_repeat('*', 6) . "@" . $parts[1];
    } elseif ($type === 'mobile')
    {
        // ===m=== Shows "98******12" ===m===
        return substr($data, 0, 2) . str_repeat('*', 6) . substr($data, -2);
    }
    return "*****";
}
// ===m=== Masking Logic Ended ===m===

// ===m=== Activity Log Started ===m=== 
function logTeamActivity($conn, $uid, $project_name, $action_type, $details_array = [])
{
    // Convert array to JSON string, or keep NULL if empty
    $details_json = empty($details_array) ? null : json_encode($details_array);
    $ip = $_SERVER['REMOTE_ADDR'] ?? null;

    // Use MySQLi prepare statement
    $stmt = $conn->prepare("
        INSERT INTO team_activity_logs (uid, project_name, action_type, action_details, ip_address) 
        VALUES (?, ?, ?, ?, ?)
    ");

    if ($stmt)
    {
        // i = integer, s = string
        $stmt->bind_param("issss", $uid, $project_name, $action_type, $details_json, $ip);
        $stmt->execute();
        $stmt->close();
    } else
    {
        // Log silently to PHP error log if something fails (don't break the app)
        error_log("Logging failed for project {$project_name}: " . $conn->error);
    }
}
// ===m=== Activity Log Ended ===m=== 

// Check connection
// if ($conn->connect_error) {
//   die("Connection failed: " . $conn->connect_error);
// }

// $dbnamefb = "facebooklead";
// // Create connection
// $connfb = new mysqli($servername, $username, $password,$dbnamefb);

// // Check connection
// if ($connfb->connect_error) {
//   die("Connection failed: " . $connfb->connect_error);
// }

//echo "Connected successfully";
