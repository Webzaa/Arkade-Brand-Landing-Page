<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require __DIR__ . '/../../vendor/autoload.php';   // Composer path
require_once __DIR__ . '/../config.php';

// -------------------------------------------------
// Create base mailer (reusable)
// -------------------------------------------------

function getMailer()
{

  $mail = new PHPMailer(true);

  // SMTP Settings
  $mail->isSMTP();
  $mail->Host = 'smtp.gmail.com';
  $mail->SMTPAuth = true;
  $mail->Username = 'info@webzaa.co.in';
  $mail->Password = 'oyfo jtaa dvkf tqhw';
  $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
  $mail->Port = 587;


  // General
  $mail->isHTML(true);
  $mail->CharSet = "UTF-8";

  $mail->setFrom('info@webzaa.co.in', 'Webzaa Admin');

  return $mail;
}


// -------------------------------------------------
// Send OTP Email
// -------------------------------------------------

function sendOTP($email, $otp)
{

  try {

    $mail = getMailer();

    $mail->addAddress($email);

    $mail->Subject = "Your Webzaa Login OTP for - " . PROJECT_NAME;

    $mail->Body = "

        <div style='font-family:Arial;background:#f4f6f8;padding:30px'>
          <div style='max-width:420px;margin:auto;background:#ffffff;border-radius:8px;padding:25px'>

            <h2 style='color:#e84e24;text-align:center'>Webzaa Admin Login</h2>

            <p>Your one-time password for <strong>" . PROJECT_NAME . "</strong> Project is:</p>

            <h1 style='letter-spacing:4px;text-align:center'>$otp</h1>

            <p style='color:#666'>This OTP is valid for 5 minutes.</p>

            <hr>

            <p style='font-size:12px;color:#999'>
              If you did not request this login, please ignore this email.
            </p>

          </div>
        </div>
        ";

    $mail->send();
    return true;
  } catch (Exception $e) {

    return false;
  }
}
