<?php

define('PROJECT_NAME', 'Arkade Thane');
define('META_PIXEL_ID', '');
define('META_ACCESS_TOKEN', 'EAAFi6rjzjmUBO4ZANwI5ZBvpCWCMoEb6kIzFSKsWAQlFBfqf2ee7OGo6zu8NVhX7vAZCeVJK3KulX9JZAZAjvoZAEonP5Rgzix0ZAOLqKTwqOe99M4AAlVqddw4OyzivJBH7xZBNCDNC0SHH0HvZCNhaiVcQnbqOrgRv2Ky6zSxcWDdNieuD5OHyUPFfh');

// ===s=== Google OAuth Config Started ===s===
define('GOOGLE_CLIENT_ID', '536569090665-2njos6bl8gdg8052co2inithaufq52rf.apps.googleusercontent.com');
define('GOOGLE_CLIENT_SECRET', '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');
define('GOOGLE_REDIRECT_URI', '');
// ===s=== Google OAuth Config Ended ===s===    
