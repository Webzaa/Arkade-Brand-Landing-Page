<?php
session_start();
// ini_set('display_errors', '1');
// ini_set('display_startup_errors', '1');
// error_reporting(E_ALL);

include __DIR__ . '/core/db_controller/db.php';

$message = "";
$row = 0;
if (isset($_FILES["file"]))
{
    $filename = $_FILES["file"]["tmp_name"];
    if ($_FILES["file"]["size"] > 0)
    {
        $file = fopen($filename, "r");

        while (($data = fgetcsv($file, 10000, ",")) !== FALSE)
        {
            $row++;
            if ($row > 1)
            {

                //print_r($data);exit;

                if ($data[6] != '')
                {
                    $d = str_replace("/", "-", $data[6]);
                    $date = date('Y-m-d H:i:s', strtotime($d));
                    //echo $d;exit;
                } else
                {
                    $date = date('Y-m-d H:i:s');
                }
                $existing_mobile = '';

                $_REQUEST['uuqid'] = $_SESSION['uuqid_sec'] ?? '';
                $_REQUEST['name'] = $data[0] ?? '';
                $_REQUEST['email'] = $data[1] ?? '';
                $_REQUEST['countrycode'] = $data[2] ?? '';
                $_REQUEST['mobile'] = $data[3] ?? '';
                $_REQUEST['campaignsource'] = $data[7] ?? '';
                $_REQUEST['campaignsubsource'] = $data[8] ?? '';
                $_REQUEST['bhktype'] = '';
                $_REQUEST['purpose'] = '';
                $_REQUEST['visitpossibleon'] = '';
                $_REQUEST['favdestination'] = '';
                $_REQUEST['villatype'] = '';
                $_REQUEST['projinterest'] = '';
                $_REQUEST['createddt'] = $date;
                $_REQUEST['utmM'] = $data[9] ?? '';
                $_REQUEST['utmC'] = $data[10] ?? '';
                $_REQUEST['form_id'] = $data[4] ?? '';
                $_REQUEST['page_id'] = $data[5] ?? '';
                $_REQUEST['ad_id'] = $data[12] ?? '';
                $_REQUEST['leadgen_id'] = $data[13] ?? '';
                $_REQUEST['keyword'] = $data[14] ?? '';
                $_REQUEST['capturefromname'] = $data[15] ?? '';
                $_REQUEST['websitename'] = $data[16] ?? '';
                $_REQUEST['adset_id'] = $data[17] ?? '';
                $_REQUEST['adset_name'] = $data[18] ?? '';
                $_REQUEST['campaign_name'] = $data[19] ?? '';
                $campaigncode = "FY25_26_NRI_SG";
                $campaignname = "FY25_26 NRI SG SSV";


                //echo'<pre>';print_r($_REQUEST);exit;
                $sql = "SELECT * FROM `lead` l where mobile = '" . $_REQUEST['mobile'] . "' and email='" . $_REQUEST['email'] . "'";

                $result = $conn->query($sql);
                $edit_result = array();
                if ($result->num_rows > 0)
                {
                    while ($row = $result->fetch_assoc())
                    {
                        $existing_mobile = $row['mobile'];
                    }
                }
                if ($data[7] != '' && $existing_mobile == '')
                {
                    $insertsql = "INSERT INTO `lead` (`name`, `email`, `countrycode`,  `mobile`, `campaignsource`, `campaignsubsource`,  `bhktype`, `purpose`, `visitpossibleon`, `favdestination`, `villatype`, `projinterest`, `form_id`, `ad_id`, `leadgen_id`, `page_id`, `keyword`, `capturefromname`,  `websitename`, `createddate`, `utmM`, `utmC`) VALUES ('" . $_REQUEST['name'] . "',  '" . $_REQUEST['email'] . "',  '" . $_REQUEST['countrycode'] . "',  '" . $_REQUEST['mobile'] . "',  '" . $_REQUEST['campaignsource'] . "',  '" . $_REQUEST['campaignsubsource'] . "', '" . $_REQUEST['bhktype'] . "', '" . $_REQUEST['purpose'] . "', '" . $_REQUEST['visitpossibleon'] . "', '" . $_REQUEST['favdestination'] . "', '" . $_REQUEST['villatype'] . "', '" . $_REQUEST['projinterest'] . "', '" . $_REQUEST['form_id'] . "', '" . $_REQUEST['ad_id'] . "', '" . $_REQUEST['leadgen_id'] . "', '" . $_REQUEST['page_id'] . "', '" . $_REQUEST['keyword'] . "',  '" . $_REQUEST['capturefromname'] . "', '" . $_REQUEST['websitename'] . "', '" . $date . "', '" . $_REQUEST['utmM'] . "', '" . $_REQUEST['utmC'] . "')";

                    $insertresult = $conn->query($insertsql);

                    // store curl code response===========
                    $curlresponse = json_encode($response2);
                    $update = $conn->prepare("UPDATE `lead` SET  curlresponse = ? WHERE  id = ?");
                    $update->bind_param("ss", $curlresponse, $last_insertid);
                    $uqry = $update->execute();
                    // store curl code response===========

                }
                $message = "success";
            }
        }
        // echo '<pre>';
        // print_r($_REQUEST);
        // //fclose($handle);
        // exit;
    }
}
if ($message == "success")
{
    header("refresh:3;url=index.php");
}
?>

<!--
=========================================================
* Paper Dashboard 2 - v2.0.1
=========================================================

* Product Page: https://www.creative-tim.com/product/paper-dashboard-2
* Copyright 2020 Creative Tim (https://www.creative-tim.com)

Coded by www.creative-tim.com

 =========================================================

* The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
-->

<?php
// include __DIR__ . '/core/db_controller/db.php';
require_once __DIR__ . '/leads/header.php';
require_once __DIR__ . '/core/config.php';

//print_r($_SESSION);exit;
if (!isset($_SESSION["user_logged"]) || $_SESSION["user_logged"] != "Y")
{
    header("Location: login.php");
    exit;
}

$username = $_SESSION['username'] ?? 'Admin';
$role = $_SESSION['role'] ?? 'admin';

$mobile = '';
if (isset($_POST['mobile']))
{
    $mobile = $_POST['mobile'];

    $sql = "SELECT * FROM lead l where mobile = '" . $_POST['mobile'] . "'";
    $result = $conn->query($sql);
    $data_result = array();
    if ($result->num_rows > 0)
    {
        while ($row = $result->fetch_assoc())
        {
            array_push($data_result, $row);
        }
    }
}
?>

<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <link rel="apple-touch-icon" sizes="76x76" href="./assets/img/apple-icon.png">

    <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css" />
    <link rel="icon" type="image/png" href="./assets/img/favicon.png">

    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <title>
        Webzaa Admin | <?php echo PROJECT_NAME; ?>
    </title>
    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no'
        name='viewport' />
    <!--     Fonts and icons     -->
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <!-- CSS Files -->
    <link href="./assets/css/bootstrap.min.css" rel="stylesheet" />
    <link href="./assets/css/paper-dashboard.css?v=2.0.1" rel="stylesheet" />
    <!-- CSS Just for demo purpose, don't include it in your project -->
    <link href="./assets/demo/demo.css" rel="stylesheet" />
    <link href="assets/css/style.css" rel="stylesheet" />

    <style type="text/css">
        /* Style the tab */
        .tab {
            overflow: hidden;
            border: 1px solid #ccc;
            background-color: #f1f1f1;
        }

        /* Style the buttons inside the tab */
        .tab button {
            background-color: inherit;
            float: left;
            border: none;
            outline: none;
            cursor: pointer;
            padding: 14px 16px;
            transition: 0.3s;
            font-size: 17px;
        }

        /* Change background color of buttons on hover */
        .tab button:hover {
            background-color: #ddd;
        }

        /* Create an active/current tablink class */
        .tab button.active {
            background-color: #ccc;
        }

        /* Style the tab content */
        .tabcontent {
            display: none;
            padding: 6px 12px;
            border: 1px solid #ccc;
            border-top: none;
        }
    </style>
    <style>
        .ui-accordion .ui-accordion-header {
            display: block;
            cursor: pointer;
            position: relative;
            margin: 2px 0 0 0;

            min-height: 0;
            /* support: IE7 */
            font-size: 100%;
            border: 1px solid #FDF8E4;
            background: #846733;
            color: #fff;
        }

        .error {
            border-color: red;
        }
    </style>
</head>

<body class="">
    <div class="wrapper ">
        <div class="sidebar" data-color="white" data-active-color="danger">
            <div class="logo">

                <a href="index.php" class="simple-text logo-normal">

                    <div class="logo-image-big pl-5">
                        <img src="./assets/images/webzaa-logo.png">
                    </div>
                </a>
            </div>
            <div class="sidebar-wrapper">
                <ul class="nav">
                    <li class="">
                        <a href="index.php">
                            <span class="iconify" data-icon="ri:dashboard-fill"
                                style="font-size:24px;float:left;margin-right:12px;line-height:30px;width:34px;text-align:center;position:relative;"></span>
                            <p>Dashboard</p>
                        </a>
                    </li>
                    <li class="">
                        <a href="analytics.php">
                            <i class="nc-icon nc-chart-pie-36"></i>
                            <p>Analytics</p>
                        </a>
                    </li>
                    <li class="">
                        <a href="restricted_ips.php">
                            <i class="nc-icon nc-lock-circle-open"></i>
                            <p>Restricted IP'S</p>
                        </a>
                    </li>
                    <li class="">
                        <a href="meta_capi.php">
                            <span class="iconify" data-icon="ri:meta-fill"
                                style="font-size:24px;float:left;margin-right:12px;line-height:30px;width:34px;text-align:center;position:relative;"></span>
                            <p>Meta CAPI</p>
                        </a>
                    </li>
                    <li class="active">
                        <a href="import.php">
                            <i class="nc-icon nc-cloud-upload-94"></i>
                            <p>Import</p>
                        </a>
                    </li>
                    <!--  <li>
            <a href="javascript:;">
              <i class="nc-icon nc-diamond"></i>
              <p>Users</p>
            </a>
          </li> -->
                    <!-- <li>
            <a href="javascript:;">
              <i class="nc-icon nc-pin-3"></i>
              <p>Facebook Leads Form</p>
            </a>
          </li> -->
                </ul>
            </div>
        </div>
        <div class="main-panel" style="height: 100vh;">
            <!-- Navbar -->
            <nav class="navbar navbar-expand-lg navbar-absolute fixed-top navbar-transparent">
                <div class="container-fluid">
                    <div class="navbar-wrapper">
                        <div class="navbar-toggle">
                            <button type="button" class="navbar-toggler">
                                <span class="navbar-toggler-bar bar1"></span>
                                <span class="navbar-toggler-bar bar2"></span>
                                <span class="navbar-toggler-bar bar3"></span>
                            </button>
                        </div>
                        <a class="navbar-brand"
                            href="javascript:;"><?php echo $greeting . ', ' . htmlspecialchars($username); ?></a>
                    </div>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navigation"
                        aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-bar navbar-kebab"></span>
                        <span class="navbar-toggler-bar navbar-kebab"></span>
                        <span class="navbar-toggler-bar navbar-kebab"></span>
                    </button>
                    <div class="collapse navbar-collapse justify-content-end" id="navigation">

                        <div class="no-border">
                            <!--   <input type="text" value="" class="form-control" placeholder="Search...">
                <div class="input-group-append">
                  <div class="input-group-text">
                    <i class="nc-icon nc-zoom-split"></i>
                  </div>
                </div>
              </div> -->
                            <ul class="navbar-nav">
                                <li class="nav-item btn-rotate dropdown">
                                    <a class="nav-link dropdown-toggle" href="" id="navbarDropdownMenuLink"
                                        data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        <!-- <i class="nc-icon nc-bell-55"></i> -->
                                        <p>
                                            <span class="d-lg-none d-md-block">Actions</span>
                                        </p>
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-right"
                                        aria-labelledby="navbarDropdownMenuLink">
                                        <!-- <a class="dropdown-item" href="#">Action</a>
                  <a class="dropdown-item" href="#">Another action</a> -->
                                        <a class="dropdown-item" href="./leads/logout.php">Logout</a>

                                        <?php if (isset($_SESSION['role']) && $_SESSION['role'] == 'superadmin')
                                        { ?>
                                            <a class="dropdown-item" href="./leads/users.php">Add Users</a>
                                        <?php } ?>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
            </nav>
            <!-- End Navbar -->
            <div class="content">
                <div class="row">
                    <div class="col-md-12 row">
                        <div class="col-md-9">
                            <h3 class="description">Imoprt Lead</h3>
                        </div>
                        <div class="col-md-3">
                            <h3 class="description"><a class="btn btn-primary form-control"
                                    style="color: white;background: #424240;float:right;" href="./index.php">Back</a>
                        </div>

                    </div>
                    <div class="col-md-12 row" id="msg">

                        <?php if ($message == 'success')
                        { ?>

                            <span class="alert alert-success">File imported successfully.</span>
                        <?php } ?>
                    </div>

                    <div class="col-md-12 row">
                        <form id="import_form" class="form-horizontal" action="" method="post" name="upload_excel"
                            enctype="multipart/form-data">
                            <div class="col-md-9">
                                <label for="myfile">Select a file:</label>
                                <input type="file" id="myfile" name="file">
                                <br>
                                <a href="./docs/import.csv" style="color:#f35a01;" download>Click here to download the
                                    sample format for uploading a csv.</a>
                            </div>
                        </form>
                        <div class="form-group col-md-3">
                            <button class="btn btn-primary form-control" id="import"
                                style="color: white;background: #424240;float:right;">Import</button>

                        </div>

                    </div>
                </div>
                <footer class="footer" style="position: absolute; bottom: 0; width: -webkit-fill-available;">
                    <div class="container-fluid">
                        <div class="row">
                            <nav class="footer-nav">
                                <ul>
                                    <!-- <li><a href="https://www.creative-tim.com" target="_blank">Creative Tim</a></li>
                <li><a href="https://www.creative-tim.com/blog" target="_blank">Blog</a></li>
                <li><a href="https://www.creative-tim.com/license" target="_blank">Licenses</a></li> -->
                                </ul>
                            </nav>
                            <div class="credits ml-auto">
                                <!-- <span class="copyright">
                © 2017, made with <i class="fa fa-heart heart"></i> by Webzaa
              </span> -->
                            </div>
                        </div>
                    </div>
                </footer>
            </div>
        </div>

        <!--   Core JS Files   -->
        <link rel="stylesheet"
            href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/css/bootstrap-datepicker.css"
            integrity="sha512-Fppbdpv9QhevzDE+UHmdxL4HoW8HantO+rC8oQB2hCofV+dWV2hePnP5SgiWR1Y1vbJeYONZfzQc5iII6sID2Q=="
            crossorigin="anonymous" referrerpolicy="no-referrer" />
        <script src="./assets/js/core/jquery.min.js"></script>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
        <script src="https://code.jquery.com/ui/1.13.2/jquery-ui.min.js"></script>
        <script type="text/javascript" src="https://cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>
        <script type="text/javascript"
            src="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js"></script>
        <script src="assets/js/highcharts/highcharts.js"></script>
        <script src="assets/js/highcharts/data.js"></script>
        <script src="assets/js/highcharts/drilldown.js"></script>
        <script src="assets/js/highcharts/exporting.js"></script>
        <script src="assets/js/highcharts/export-data.js"></script>
        <script src="assets/js/highcharts/accessibility.js"></script>
        <script src="https://code.iconify.design/3/3.1.1/iconify.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/js/bootstrap-datepicker.min.js"
            integrity="sha512-T/tUfKSV1bihCnd+MxKD0Hm1uBBroVYBOYSk1knyvQ9VyZJpc/ALb4P0r6ubwVPSGB2GvjeoMAJJImBG12TiaQ=="
            crossorigin="anonymous" referrerpolicy="no-referrer"></script>
        <script src="https://cdn.datatables.net/v/dt/dt-1.10.20/datatables.min.js"></script>
        <script src="https://cdn.datatables.net/buttons/1.6.1/js/dataTables.buttons.min.js"></script>
        <script src="https://cdn.datatables.net/buttons/1.6.1/js/buttons.flash.min.js"></script>
        <script src="https://cdn.datatables.net/buttons/1.6.1/js/buttons.html5.min.js"></script>
        <script src="https://cdn.datatables.net/buttons/1.6.1/js/buttons.print.min.js"></script>
        <script src="https://cdn.datatables.net/fixedcolumns/3.3.0/js/dataTables.fixedColumns.min.js"></script>
        <script src="https://cdn.datatables.net/colreorder/1.5.2/js/dataTables.colReorder.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/paginationjs/2.1.5/pagination.min.js"
            integrity="sha512-1zzZ0ynR2KXnFskJ1C2s+7TIEewmkB2y+5o/+ahF7mwNj9n3PnzARpqalvtjSbUETwx6yuxP5AJXZCpnjEJkQw=="
            crossorigin="anonymous" referrerpolicy="no-referrer"></script>
        <script src="./assets/js/core/popper.min.js"></script>
        <script src="./assets/js/core/bootstrap.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.perfect-scrollbar/1.5.5/perfect-scrollbar.min.js"
            integrity="sha512-X41/A5OSxoi5uqtS6Krhqz8QyyD8E/ZbN7B4IaBSgqPLRbWVuXJXr9UwOujstj71SoVxh5vxgy7kmtd17xrJRw=="
            crossorigin="anonymous" referrerpolicy="no-referrer"></script>
        <!--  Google Maps Plugin    -->
        <!-- <script src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script> -->
        <!-- Chart JS -->
        <script src="./assets/js/plugins/chartjs.min.js"></script>
        <!--  Notifications Plugin    -->
        <script src="./assets/js/plugins/bootstrap-notify.js"></script>
        <!-- Control Center for Now Ui Dashboard: parallax effects, scripts for the example pages etc -->
        <script src="./assets/js/paper-dashboard.min.js?v=2.0.1" type="text/javascript"></script>
        <script type="text/javascript">
            $(document).on('click', "#import", function (e) {
                e.preventDefault();
                $("#import_form").submit();

            })
        </script>

        <!-- ===m=== Analytics Script Code ===m=== -->
        <script>
            $(document).ready(function () {
                function sendLog(actionType, dataPayload) {
                    dataPayload.action_type = actionType;
                    // ===m=== Capture the exact page they are on ===m===
                    dataPayload.current_url = window.location.pathname + window.location.search;
                    $.ajax({
                        url: 'leads/ajax_log_activity.php',
                        type: 'POST',
                        data: dataPayload,
                        error: function () {
                            console.log("Background log failed");
                        }
                    });
                }
                // ===m=== Track logout specifically ===m===
                $(document).on('click', 'a[href*="logout.php"]', function (e) {
                    e.preventDefault(); // stop immediate redirect
                    e.stopImmediatePropagation();
                    let logoutUrl = $(this).attr('href');
                    sendLog('logout', {
                        clicked_element: 'Logout'

                    });
                    setTimeout(function () {
                        window.location.href = logoutUrl;
                    }, 400);
                    return;
                });
                // ===m=== Track clicks ===m===
                $(document).on('click', 'a, button, input[type="button"], input[type="submit"], [role="button"], .nav-link, .dropdown-item,[data-bs-toggle], [data-toggle]', function (e) {
                    let $el = $(this);
                    // ===m=== Extract element text/label ===m===
                    let text = $el.text().trim() || $el.val() || $el.attr('title') || $el.attr('aria-label') || 'Icon/Element';
                    let href = $el.attr('href') || '';
                    let id = $el.attr('id') || '';
                    let textLower = text.toLowerCase();
                    // ===m=== Limit text length ===m===
                    if (text.length > 50) text = text.substring(0, 50) + '...';
                    // ===m=== Ignore useless javascript-only icon clicks ===m===
                    if (href.toLowerCase().includes('javascript:') && text === 'Icon/Element') return;
                    // ===m=== Detect report export/download actions ===m===
                    if (textLower.includes('export') || textLower.includes('download') || href.toLowerCase().includes('export.php')) {
                        sendLog('report_download', {
                            report_name: text || 'Export Data'
                        });
                        return;
                    }
                    if (textLower.includes('search') || $el.attr('id') === 'search-btn' || $el.hasClass('search')) {
                        let searchTerm = $el.closest('form, div, .row').find('input[type="text"], input[type="search"]').val();
                        if (searchTerm && searchTerm.trim() !== '') {
                            sendLog('search', {
                                search_term: searchTerm.trim()
                            });
                            return;
                        }
                    }
                    // ===m=== Prepare element details for logging ===m===
                    let elementDetails = text;
                    if (href && href !== '#' && !href.toLowerCase().includes('javascript:')) {
                        elementDetails += ' (' + href + ')';
                    } else if (id) {
                        elementDetails += ' (#' + id + ')';
                    }
                    sendLog('click', {
                        clicked_element: elementDetails
                    });
                });
                // ===m=== Track search via Enter key in input fields ===m===
                $(document).on('keypress', 'input', function (e) {
                    if (e.which == 13) {
                        let inputAttributes = ($(this).attr('id') || '') + ($(this).attr('name') || '') + ($(this).attr('placeholder') || '');
                        if (inputAttributes.toLowerCase().includes('search')) {
                            let searchTerm = $(this).val().trim();
                            if (searchTerm !== '') {
                                sendLog('search', {
                                    search_term: searchTerm
                                });
                            }
                        }
                    }
                });
                // ===m=== Track dropdown/select value changes ===m===
                $(document).on('change', 'select', function () {
                    let selectIdentifier = $(this).attr('name') || $(this).attr('id') || 'Dropdown';
                    let selectedText = $(this).find('option:selected').text().trim();
                    sendLog('change', {
                        changed_element: selectIdentifier,
                        new_value: selectedText
                    });
                });

            });
        </script>
        <!-- ===m=== Analytics Script Code ===m=== -->

</body>

</html>