<?php
//ini_set('display_errors', 1);
//ini_set('display_startup_errors', 1);
//error_reporting(E_ALL);
session_start();

require __DIR__ . '/../core/db_controller/db.php';
require __DIR__ . '/../core/config.php';

// ===m=== Pixel Id will get change according to Project ===m===
$pixel_id = $_SESSION['active_pixel_id'] ?? META_PIXEL_ID;
if (empty($pixel_id)) {
    die(json_encode(["status" => "failed", "reason" => "No Pixel ID provided"]));
}
$access_token = META_ACCESS_TOKEN;

$data = json_decode(file_get_contents(__DIR__ . "/../temp.json"), true);
$index = $_GET['index'] ?? 0;

if (!isset($data[$index])) {
    die(json_encode(["status" => "done"]));
}

$leadgen_id = $conn->real_escape_string($data[$index][0]);
$status = strtolower(trim($data[$index][1]));
$db_exists = $data[$index]['db_exists'] ?? false;
// $is_duplicate = $data[$index]['is_duplicate'] ?? false;
$is_csv_duplicate = $data[$index]['is_csv_duplicate'] ?? false;


if (!$db_exists) {
    die(json_encode([
        "status" => "skipped",
        "leadgen_id" => $leadgen_id,
        "reason" => "Not present in DB"
    ]));
}

// ===m=== Check for duplicate based on capi_sent flag in DB ===m===
// if ($is_duplicate) {
//     die(json_encode([
//         "status" => "duplicate",
//         "leadgen_id" => $leadgen_id,
//         "reason" => "Duplicate (Already Sent)"
//     ]));
// }

// ===m=== Check for duplicate within CSV file ===m===
if ($is_csv_duplicate) {
    die(json_encode([
        "status" => "csv_duplicate",
        "leadgen_id" => $leadgen_id,
        "reason" => "Duplicate within CSV file"
    ]));
}

$res = $conn->query("SELECT email, mobile, countrycode FROM `lead` WHERE leadgen_id='$leadgen_id' LIMIT 1");
$lead = $res->fetch_assoc() ?? [
    'email' => "user" . rand(100, 999) . "@test.com",
    'mobile' => rand(7000000000, 9999999999),
    'countrycode' => '91'
];

$db_country_code = trim($lead['countrycode']);
$db_mobile = trim($lead['mobile']);

if (empty($db_country_code)) {
    $db_country_code = "91";
}

$safe_country_code = '+' . ltrim($db_country_code, '+');
$raw_phone = $safe_country_code . $db_mobile;
$clean_phone = preg_replace('/[^0-9]/', '', $raw_phone);

$map = ["qualified" => "Lead", "visited" => "ViewContent", "booked" => "Schedule", "sold" => "Purchase", "lost" => "Lost"];

$event_name = $map[$status] ?? "Lead";

$payload = ["data" => [[
    "event_name" => $event_name,
    "event_time" => time(),
    "action_source" => "system_generated",
    "user_data" => [
        "em" => [hash('sha256', strtolower(trim($lead['email'])))],
        "ph" => [hash('sha256', $clean_phone)],
        "external_id" => [hash('sha256', $leadgen_id)]
    ],
    "custom_data" => ["status" => $status],
    "event_id" => $event_name . "_" . $leadgen_id
]]];
// ===m=== sent to capi and get response
$ch = curl_init("https://graph.facebook.com/v25.0/$pixel_id/events?access_token=$access_token");
curl_setopt_array($ch, [
    CURLOPT_POST => 1,
    CURLOPT_POSTFIELDS => json_encode($payload),
    CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_TIMEOUT => 20
]);
$curl_res = curl_exec($ch);
curl_close($ch);

// ===m=== Mock CAPI Response for Testing ===m===
// $curl_res = '{"events_received":1, "is_mock_test": true}';

$capi_sent = strpos($curl_res, '"events_received":1') !== false ? 1 : 0;
$stage = $capi_sent ? 'SUCCESS' : 'FAILED';
$meta_res = $conn->real_escape_string($curl_res);

$conn->query("UPDATE `lead` SET lead_status='$status', capi_sent='$capi_sent', capi_sent_stage='$stage', meta_curlresponse='$meta_res' WHERE leadgen_id='$leadgen_id'");

if ($capi_sent) {
    echo json_encode(["status" => "success", "leadgen_id" => $leadgen_id]);
} else {
    echo json_encode(["status" => "failed", "leadgen_id" => $leadgen_id]);
}
