<?php
session_start();
require __DIR__ . '/../core/config.php';
require __DIR__ . '/../core/db_controller/db.php';

header('Content-Type: application/json');

$pixel_id = trim($_POST['pixel_id'] ?? '');

// ===m=== Handle session reset request ===m===
if ($pixel_id === 'reset') {
    unset($_SESSION['active_pixel_id']);
    unset($_SESSION['active_pixel_name']);
    echo json_encode(['status' => 'reset']);
    exit;
}

if (empty($pixel_id) || !is_numeric($pixel_id)) {
    echo json_encode(['status' => 'error', 'message' => 'Invalid Pixel ID format.']);
    exit;
}

$access_token = META_ACCESS_TOKEN;

// ===m=== Call Meta Graph API to validate the Pixel ===m===
$url = "https://graph.facebook.com/v25.0/{$pixel_id}?fields=id,name&access_token={$access_token}";

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_TIMEOUT, 15);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); // Add this for local environments
$response = curl_exec($ch);
$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$curl_error = curl_error($ch);
curl_close($ch);

// ===m=== Debug: log raw response (remove after fixing) ===m===
error_log("PIXEL VERIFY | HTTP: $http_code | Response: $response | cURL Error: $curl_error");

if ($curl_error) {
    echo json_encode(['status' => 'error', 'message' => 'cURL error: ' . $curl_error]);
    exit;
}

$data = json_decode($response, true);

if ($http_code == 200 && isset($data['id'])) {
    // ===m=== Check if pixel already exists in history ===m===
    $is_reactivation = $_POST['reactivate'] ?? false;
    if (!$is_reactivation && isset($_SESSION['pixel_history'])) {
        foreach ($_SESSION['pixel_history'] as $p) {
            if ($p['id'] === $pixel_id) {
                echo json_encode([
                    'status'  => 'error',
                    'message' => "Pixel ID {$pixel_id} already exists. Click below \"Use\" button to activate it."
                ]);
                exit;
            }
        }
    }
    $_SESSION['active_pixel_id'] = $pixel_id;
    $_SESSION['active_pixel_name'] = $data['name'] ?? 'Verified Pixel';
    // ===m=== Save to pixel history ===m===
    if (!isset($_SESSION['pixel_history'])) {
        $_SESSION['pixel_history'] = [];
    }
    // ===m=== Add only if not already in history ===m===
    $exists = false;
    foreach ($_SESSION['pixel_history'] as $p) {
        if ($p['id'] === $pixel_id) {
            $exists = true;
            break;
        }
    }
    if (!$exists) {
        $_SESSION['pixel_history'][] = [
            'id'   => $pixel_id,
            'name' => $data['name'] ?? 'Verified Pixel'
        ];
        $pid   = $conn->real_escape_string($pixel_id);
        $pname = $conn->real_escape_string($data['name'] ?? 'Verified Pixel');
        $conn->query("INSERT IGNORE INTO `meta_pixel_history` (`id`, `name`) VALUES ('$pid', '$pname')");
    }
    echo json_encode([
        'status'   => 'success',
        'pixel_id' => $data['id'],
        'name'     => $data['name'] ?? 'Verified Pixel'
    ]);
} else {
    $error_msg = $data['error']['message'] ?? 'Invalid Pixel ID or insufficient token permissions.';
    $error_code = $data['error']['code'] ?? '';
    echo json_encode([
        'status'  => 'error',
        'message' => "[$error_code] $error_msg"
    ]);
}
