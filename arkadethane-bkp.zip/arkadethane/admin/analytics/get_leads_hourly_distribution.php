<?php
session_start();
include __DIR__ . '/../core/db_controller/db.php';

// ===A=== Read filter params sent from analytics.php frontend ===A===
$from_date      = isset($_GET['from_date'])      ? trim($_GET['from_date'])      : '';
$camp_source    = isset($_GET['camp_source'])     ? trim($_GET['camp_source'])     : '';
$camp_subsource = isset($_GET['camp_subsource'])  ? trim($_GET['camp_subsource'])  : '';
$till_date      = isset($_GET['till_date'])       ? trim($_GET['till_date'])       : '';

// ===A=== Auto-detect the correct date column from the lead table ===A===
$colCheck = $conn->query("SHOW COLUMNS FROM `lead`");
$cols = [];
while ($c = $colCheck->fetch_assoc()) $cols[] = $c['Field'];
$dateCol = 'createddate'; // default fallback
if (in_array('created_at', $cols))  $dateCol = 'created_at';
if (in_array('createddate', $cols)) $dateCol = 'createddate';
if (in_array('createddt', $cols))   $dateCol = 'createddt';

// ===A=== Detect if filter is today or yesterday (single-day mode) ===A===
$singleDayIndex = null; // null = full week mode, 0-6 = single day mode (Mon=0, Sun=6)
$whereConditions = ["$dateCol IS NOT NULL"];

if ($from_date != '') {
    $dates = explode(' - ', $from_date);

    if (count($dates) == 2) {
        $d1obj = DateTime::createFromFormat('d/m/Y', trim($dates[0]));
        $d2obj = DateTime::createFromFormat('d/m/Y', trim($dates[1]));

        if ($d1obj && $d2obj) {
            $d1 = $d1obj->format('Y-m-d');
            $d2 = $d2obj->format('Y-m-d');

            $today     = (new DateTime())->format('Y-m-d');
            $yesterday = (new DateTime('yesterday'))->format('Y-m-d');

            if ($d1 === $d2 && $d1 === $today) {
                // ===A=== TODAY: filter to today only, record which weekday it is ===A===
                $whereConditions[] = "DATE($dateCol) = '$today'";
                $singleDayIndex = (int)(new DateTime($today))->format('N') - 1; // Mon=0, Sun=6

            } elseif ($d1 === $d2 && $d1 === $yesterday) {
                // ===A=== YESTERDAY: filter to yesterday only, record which weekday it is ===A===
                $whereConditions[] = "DATE($dateCol) = '$yesterday'";
                $singleDayIndex = (int)(new DateTime($yesterday))->format('N') - 1;
            } else {
                // ===A=== RANGE MODE: full date range, show all matching days ===A===
                $whereConditions[] = "DATE($dateCol) >= '$d1'";
                $whereConditions[] = "DATE($dateCol) <= '$d2'";
            }
        }
    }
}

// ===A=== Auto-detect campaign columns and apply source/subsource filters ===A===
$srcCol    = in_array('campaignsource', $cols)    ? 'campaignsource'    : null;
$subSrcCol = in_array('campaignsubsource', $cols) ? 'campaignsubsource' : null;
if ($camp_source != '' && $srcCol)       $whereConditions[] = "$srcCol = '" . $conn->real_escape_string($camp_source) . "'";
if ($camp_subsource != '' && $subSrcCol) $whereConditions[] = "$subSrcCol = '" . $conn->real_escape_string($camp_subsource) . "'";

$whereSQL = "WHERE " . implode(" AND ", $whereConditions);

// ===A=== Fill grid with 0 first — all 42 cells default to zero ===A===
$heatmapData = [];
for ($y = 0; $y < 7; $y++) {
    for ($x = 0; $x < 6; $x++) {
        $heatmapData["$x-$y"] = [$x, $y, 0];
    }
}

// ===A=== Fetch lead counts grouped by day and 4-hour interval ===A===
$sql = "SELECT
            FLOOR(HOUR($dateCol) / 4) AS interval_idx,
            WEEKDAY($dateCol) AS day_idx,
            COUNT(*) AS leads
        FROM `lead`
        $whereSQL
        GROUP BY interval_idx, day_idx";

$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $x   = (int)$row['interval_idx'];
        $y   = (int)$row['day_idx'];
        $val = (int)$row['leads'];

        // ===A=== In single-day mode, only accept data for the target day ===A===
        if ($singleDayIndex !== null && $y !== $singleDayIndex) {
            continue; // skip any data that doesn't belong to today/yesterday
        }

        $heatmapData["$x-$y"] = [$x, $y, $val];
    }
}

// ===A=== Return JSON array format required by Highcharts: [[x, y, value], ...] ===A===
echo json_encode(array_values($heatmapData));
