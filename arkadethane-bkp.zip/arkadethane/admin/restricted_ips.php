<?php
session_start();
include __DIR__ . '/core/db_controller/db.php';
require_once __DIR__ . '/leads/header.php';

if (!isset($_SESSION["user_logged"]))
{
    header("Location: login.php");
    exit;
}

// ===m=== Add New IP'S ===m====
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_ip']))
{
    $new_ip = trim($_POST['ip_address']);
    if (filter_var($new_ip, FILTER_VALIDATE_IP))
    {
        $check_stmt = $conn->prepare("SELECT id FROM blocked_ips WHERE ip_address = ?");
        $check_stmt->bind_param("s", $new_ip);
        $check_stmt->execute();
        $check_res = $check_stmt->get_result();

        $new_ip_safe = htmlspecialchars($new_ip, ENT_QUOTES, 'UTF-8');

        if ($check_res->num_rows > 0)
        {
            $_SESSION['flash_msg'] = "The IP <strong>{$new_ip_safe}</strong> is already present in the list.";
            $_SESSION['flash_type'] = "warning";
        } else
        {
            $stmt = $conn->prepare("INSERT INTO ip_blocks (ip_address, block_type, status) VALUES (?, 'manual_block', 1)");
            $stmt->bind_param("s", $new_ip);
            if ($stmt->execute())
            {
                $_SESSION['flash_msg'] = "Access blocked for this <strong>{$new_ip_safe}</strong> IP.";
                $_SESSION['flash_type'] = "danger"; // Red theme for block
            }
        }
    } else
    {
        $_SESSION['flash_msg'] = "Invalid IP Address format.";
        $_SESSION['flash_type'] = "warning";
    }
    // Redirect immediately to clear POST data
    header("Location: restricted_ips.php");
    exit;
}

// ===m=== Toggle Block/Unblock IPs ===m====
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['toggle_ip']))
{
    $toggle_id = (int) $_POST['ip_id'];
    $new_status = (int) $_POST['new_status'];
    $stmt = $conn->prepare("UPDATE blocked_ips SET status = ? WHERE id = ?");
    $stmt->bind_param("ii", $new_status, $toggle_id);
    if ($stmt->execute())
    {
        $action = $new_status == 1 ? "Blocked" : "Unblocked";
        $_SESSION['flash_msg'] = "IP successfully <strong>{$action}</strong>.";
        $_SESSION['flash_type'] = $new_status == 1 ? "danger" : "success";
    }
    header("Location: restricted_ips.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <link rel="apple-touch-icon" sizes="76x76" href="./assets/img/apple-icon.png">
    <link rel="icon" type="image/png" href="./assets/img/favicon.png">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title> Webzaa's IP Blocking System | <?php echo PROJECT_NAME; ?></title>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
    <!-- ===A=== Data Ranger ===A=== -->
    <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css" />
    <!--  ===m=== Fonts and icons Started ===m===  -->
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <!--  ===m=== Fonts and icons Ended ===m===  -->
    <!-- ===m=== CSS Started ===m=== -->
    <link href="./assets/css/bootstrap.min.css" rel="stylesheet" />
    <link href="./assets/css/paper-dashboard.css?v=2.0.1" rel="stylesheet" />
    <link href="./assets/demo/demo.css" rel="stylesheet" />
    <link href="./assets/css/style.css" rel="stylesheet" />
    <link href="./assets/css/style.css?v=1.0" rel="stylesheet" />
    <!-- ===m=== CSS Ended ===m=== -->
    <style>
        body {
            background: #f4f6f9;
        }

        .card-ui {
            background: #fff;
            border-radius: 12px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, .06);
            margin-bottom: 25px;
        }

        .badge-blocked {
            background: #d9534f;
            color: white;
            padding: 5px 10px;
            border-radius: 4px;
            font-size: 12px;
        }

        .badge-active {
            background: #5cb85c;
            color: white;
            padding: 5px 10px;
            border-radius: 4px;
            font-size: 12px;
        }

        .ip_button {
            margin: 0 !important;
            padding: 0.6rem 1.5rem !important;
            background: #e84e24;
            color: white;
        }
    </style>
</head>

<body>
    <div class="wrapper">
        <!-- ===m=== Sidebar Code Started ===m=== -->
        <div class="sidebar" data-color="white" data-active-color="danger">
            <div class="logo">
                <a href="index.php" class="simple-text logo-normal">
                    <div class="logo-image-big pl-5"><img src="./assets/images/webzaa-logo.png"></div>
                </a>
            </div>
            <div class="sidebar-wrapper">
                <ul class="nav">
                    <li class="">
                        <a href="index.php">
                            <span class="iconify" data-icon="ri:dashboard-fill"
                                style="font-size:24px;float:left;margin-right:12px;line-height:30px;width:34px;text-align:center;position:relative;"></span>
                            <p>Dashboard</p>
                        </a>
                    </li>
                    <li class="">
                        <a href="analytics.php">
                            <i class="nc-icon nc-chart-pie-36"></i>
                            <p>Analytics</p>
                        </a>
                    </li>
                    <li class="active">
                        <a href="restricted_ips.php">
                            <i class="nc-icon nc-lock-circle-open"></i>
                            <p>Restricted IPs</p>
                        </a>
                    </li>
                    <li class="">
                        <a href="meta_capi.php">
                            <span class="iconify" data-icon="ri:meta-fill"
                                style="font-size:24px;float:left;margin-right:12px;line-height:30px;width:34px;text-align:center;position:relative;"></span>
                            <p>Meta CAPI</p>
                        </a>
                    </li>
                    <li class="">
                        <a href="import.php">
                            <i class="nc-icon nc-cloud-upload-94"></i>
                            <p>Import</p>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
        <!-- ===m=== Sidebar Code Ended ===m=== -->
        <div class="main-panel">
            <!-- ===m=== Navbar Code Started ===m=== -->
            <nav class="navbar navbar-expand-lg navbar-absolute fixed-top navbar-transparent">
                <div class="container-fluid">
                    <div class="navbar-wrapper analytics-offset">
                        <div class="navbar-toggle">
                            <button type="button" class="navbar-toggler">
                                <span class="navbar-toggler-bar bar1"></span>
                                <span class="navbar-toggler-bar bar2"></span>
                                <span class="navbar-toggler-bar bar3"></span>
                            </button>
                        </div>
                        <a class="analytics_greeting navbar-brand"
                            href="javascript:;"><?php echo $greeting . ', ' . htmlspecialchars($username); ?></a>
                    </div>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navigation"
                        aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-bar navbar-kebab"></span>
                        <span class="navbar-toggler-bar navbar-kebab"></span>
                        <span class="navbar-toggler-bar navbar-kebab"></span>
                    </button>
                    <div class="collapse navbar-collapse justify-content-end" id="navigation">
                        <form>
                            <div class="input-group no-border"></div>
                        </form>
                        <ul class="navbar-nav">
                            <li class="nav-item btn-rotate dropdown">
                                <a class="nav-link dropdown-toggle" href="" id="navbarDropdownMenuLink"
                                    data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <p><span class="d-lg-none d-md-block">Actions</span></p>
                                </a>
                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownMenuLink">
                                    <a class="dropdown-item" href="./leads/logout.php">Logout</a>
                                    <?php if (isset($_SESSION['role']) && $_SESSION['role'] == 'superadmin')
                                    { ?>
                                        <a class="dropdown-item" href="./leads/users.php">Add Users</a>
                                    <?php } ?>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>
            <!-- ===m=== Navbar Code Ended ===m=== -->
            <!-- <nav class="navbar navbar-expand-lg navbar-absolute fixed-top navbar-transparent">
                <div class="container-fluid">
                    <div class="navbar-wrapper"><a class="navbar-brand" href="javascript:;">Restricted IP'S</a></div>
                </div>
            </nav> -->

            <div class="container-fluid py-4">
                <div class="analytics_head d-flex justify-content-between align-items-center mb-4">
                    <h3 class="analytics_description">IP Blocking System</h3>
                    <a href="index.php" class="btn actionBtn">Back</a>
                </div>

                <!-- ===m=== Bootstrap Flash Message Started ===m=== -->
                <?php if (isset($_SESSION['flash_msg'])): ?>
                    <div class="alert alert-<?php echo $_SESSION['flash_type']; ?> alert-dismissible fade show" role="alert"
                        style="border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.06);">
                        <?php echo $_SESSION['flash_msg']; ?>
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close"
                            style="cursor: pointer;">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <?php
                    // Destroy message so it doesn't show again on refresh
                    unset($_SESSION['flash_msg']);
                    unset($_SESSION['flash_type']);
                    ?>
                <?php endif; ?>
                <!-- ===m=== Bootstrap Flash Message Ended ===m=== -->


                <div class="card-ui">
                    <!-- <h5 class="mb-3">Add IP'S that you wish to Block</h5> -->
                    <form method="POST" class="row align-items-end">
                        <div class="col-md-4">
                            <label>Enter IP Address</label>
                            <input type="text" name="ip_address" class="form-control" placeholder="e.g. 192.168.1.100"
                                required>
                        </div>
                        <div class="col-md-3">
                            <button type="submit" name="add_ip" class="btn ip_button">Block IP</button>
                        </div>
                    </form>
                </div>

                <!-- IP Table List -->
                <div class="card-ui">
                    <h5 class="mb-3">Blocked IP'S</h5>
                    <div class="table-responsive">
                        <table id="ipTable" class="table table-bordered table-sm">
                            <thead>
                                <tr>
                                    <th>IP Address</th>
                                    <th>Source</th>
                                    <th>Last Activity</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $q = $conn->query("SELECT * FROM blocked_ips ORDER BY created_at DESC");
                                while ($row = $q->fetch_assoc())
                                {
                                    $statusBadge = $row['status'] == 1 ? "<span class='badge-blocked'>Blocked</span>" : "<span class='badge-active'>Allowed</span>";
                                    $btnText = $row['status'] == 1 ? "Unblock" : "Block";
                                    $newStatus = $row['status'] == 1 ? 0 : 1;
                                    $btnClass = $row['status'] == 1 ? "btn-success" : "btn-danger";

                                    $reason = $row['block_type'] == 'auto_submitted' ? 'Auto: Form Submitted' : 'Manual Block';

                                    echo "<tr>
                                        <td><strong>{$row['ip_address']}</strong></td>
                                        <td>{$reason}</td>
                                        <td>{$row['created_at']}</td>
                                        <td>{$statusBadge}</td>
                                        <td>
                                            <form method='POST' style='margin:0;'>
                                                <input type='hidden' name='ip_id' value='{$row['id']}'>
                                                <input type='hidden' name='new_status' value='{$newStatus}'>
                                                <button type='submit' name='toggle_ip' class='btn btn-sm {$btnClass}'>{$btnText}</button>
                                            </form>
                                        </td>
                                    </tr>";
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- ===m=== Scripts Started ===m=== -->
    <script src="./assets/js/core/jquery.min.js"></script>
    <script src="assets/js/highcharts/highcharts.js"></script>
    <script src="./assets/js/highcharts/heatmap.js"></script>
    <script src="./assets/js/highcharts/exporting.js"></script>
    <script src="./assets/js/highcharts/export-data.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script src="./assets/js/core/popper.min.js"></script>
    <script src="./assets/js/core/bootstrap.min.js"></script>
    <script src="https://code.iconify.design/3/3.1.1/iconify.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.6.1/js/dataTables.buttons.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.6.1/js/buttons.flash.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.6.1/js/buttons.html5.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.6.1/js/buttons.print.min.js"></script>
    <script src="https://cdn.datatables.net/fixedcolumns/3.3.0/js/dataTables.fixedColumns.min.js"></script>
    <script src="https://cdn.datatables.net/colreorder/1.5.2/js/dataTables.colReorder.min.js"></script>
    <script
        src="https://cdnjs.cloudflare.com/ajax/libs/jquery.perfect-scrollbar/1.5.5/perfect-scrollbar.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/paginationjs/2.1.5/pagination.min.js"></script>
    <script src="https://code.jquery.com/ui/1.13.2/jquery-ui.min.js"></script>
    <script type="text/javascript" src="https://cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>
    <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js"></script>
    <script
        src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/js/bootstrap-datepicker.min.js"></script>
    <script src="./assets/js/plugins/bootstrap-notify.js"></script>
    <script src="./assets/js/paper-dashboard.min.js?v=2.0.1" type="text/javascript"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://unpkg.com/heatmap.js@2.0.5/build/heatmap.min.js"></script>
    <!-- ===m=== Scripts Ended ===m=== -->

    <script>
        $(document).ready(function () {
            $('#ipTable').DataTable({ "order": [[2, "desc"]] });
        });
    </script>
</body>

</html>