<?php
session_start();
require_once __DIR__ . '/core/db_controller/db.php';
require_once __DIR__ . '/core/config.php';

if (!isset($_SESSION["user_logged"]) || $_SESSION["role"] != "superadmin") {
    echo "Access Denied";
    exit;
}

$db_name = [$dbname];

$sql_parts = [];
foreach ($db_name as $db) {
    $sql_parts[] = "SELECT 
            l.log_id, u.username, u.email, l.project_name, l.action_type, 
            l.action_details, l.created_at, l.ip_address 
        FROM {$db}.team_activity_logs l
        JOIN {$db}.users u ON l.uid = u.uid
    ";
}
$final_query = implode(" UNION ALL ", $sql_parts) . " ORDER BY created_at DESC LIMIT 500";

$result = $conn->query($final_query);
?>

<!DOCTYPE html>
<html>

<head>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet">
    <link href="./assets/css/style.css" rel="stylesheet" />
    <link rel="icon" type="image/png" href="./assets/img/favicon.png">

    <title>Users Activity Log</title>
    <!-- Add your Bootstrap CSS or admin stylesheet here -->
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background: #ffffff;
        }

        /* TABLE */

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            font-size: 14px;
        }

        th,
        td {
            border: 1px solid #eee;
            padding: 12px;
            border: 2px solid #6a6968;
        }

        th {
            background: #fce6e0;
            border-right: 2px solid #6a6968;
            color: #6a6968;
            text-align: center;
            font-weight: 600;
        }

        /* ROW HOVER */
        tbody tr:hover {
            background: #fafafa;
        }

        /* USER COLUMN */
        .user-name {
            font-weight: 600;
        }

        .user-email {
            font-size: 12px;
            color: #6a6968;
        }

        /* ACTIVITY BADGE */

        .badge-activity {
            background: #6a6968;
            color: #ffffff;
            padding: 5px 10px;
            border-radius: 4px;
            font-size: 11px;
            font-weight: 600;
        }

        /* METADATA */

        .meta {
            text-align: left;
            line-height: 1.6;
        }

        .meta strong {
            color: #6a6968;
        }

        .user_back_button {
            background: #e9532a;
            color: white;
        }

        .user_back_button:hover {
            background: #cf4320;
            color: white;
        }
    </style>
</head>

<body>

    <div class="d-flex justify-content-between align-items-center mb-4">
        <h4>Users Activity Dashboard</h4>
        <a href="index.php" class="btn user_back_button">Back</a>
    </div>

    <!-- <p>Viewing activity across <?php echo count($db_name); ?> databases.</p> -->

    <table>
        <thead>
            <tr>
                <th>Timestamp</th>
                <!-- <th>Project Name</th> -->
                <th>User</th>
                <th>Activity</th>
                <th>Metadata</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if ($result && $result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {

                    // Decode JSON details nicely
                    $details = json_decode($row['action_details'] ?? '', true);
                    $detail_text = "-";
                    if (is_array($details)) {
                        $detail_text = "";
                        foreach ($details as $k => $v) {
                            $clean_key = ucwords(str_replace('_', ' ', $k));
                            if ($clean_key == "Element") {
                                $clean_key = "Module";
                            }
                            if ($k == "page_url") {
                                $clean_key = "Route";
                            }
                            $detail_text .= "<div><strong>{$clean_key}:</strong> " . htmlspecialchars($v) . "</div>";
                        }
                    }

                    // <td><span class='badge bg-blue'>{$row['project_name']}</span></td>
                    echo "<tr>
                        <td>" . date('d M Y, h:i A', strtotime($row['created_at'])) . "</td>
                        <td><div class='user-name'>{$row['username']}</div><div class='user-email'>{$row['email']}</div></td>
                        <td><span class='badge-activity'>" . strtoupper($row['action_type']) . "</span></td>
                        <td class='meta'>{$detail_text}</td>
                    </tr>";
                }
            } else {
                echo "<tr><td colspan='5'>No logs found or error in query.</td></tr>";
            }
            ?>
        </tbody>
    </table>

    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>

</body>

</html>