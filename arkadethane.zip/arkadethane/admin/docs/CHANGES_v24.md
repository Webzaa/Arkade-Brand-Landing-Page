# 1.0.24 Beta — UI / CSS clean-up and phone / tablet layouts

Checked every page at phone (390 px), tablet (820 px) and desktop (1440 px), in dark and light theme.

- **Top bar on phones:** the page title gets the room — no subtitle, no "open in new tab", avatar only.
- **Date bar on phones:** all seven choices (Today … Custom) on two rows instead of a hidden side-scroll.
- **Targets:** month switcher and settings no longer run off the screen; buttons stack on phones.
- **Meta / Google / Taboola dashboards:** side-by-side panels (insight cards, charts, comparisons) stack on phones;
  tighter page padding.
- **Sync with Meta / Google window:** each campaign on two lines on phones (name + spend, then Performance /
  Awareness + status); the Save button stays visible.
- **CRM Push:** "Why leads failed" shows each reason as a block on phones and tablets instead of a squeezed table.
- **Unmapped Leads:** long campaign names in the warning wrap instead of running out of the box.
- **Web Analytics, Meta CAPI, Import Leads:** proper dark theme (they showed white cards with faint text); their own
  Back buttons and duplicate titles are hidden inside the dashboard; Meta CAPI's Pixel ID box and button stack on phones.
- **CRM Settings, Targets:** text boxes without a type (and password boxes) now match the theme (were grey in dark).
- Pages that had no mobile viewport tag (Web Analytics, Logs, Meta / Google unmapped) now scale on phones.

Files: app/Ui/embed_head.php, public/dashboard.php, public/targets.php, public/crm_push.php, public/crm_settings.php,
public/unmapped_leads.php, public/meta_capi.php, public/analytics.php, public/logs.php,
public/ads/metadashboard.php, public/ads/googledashboard.php, public/ads/tabooladashboard.php,
public/ads/unmapped.php, public/ads/unmapped_meta.php, public/ads/js/project_sync.js. No database change.
