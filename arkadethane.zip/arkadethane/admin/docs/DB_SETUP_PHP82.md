# Dual Database Setup - PHP 8.2

The Admin application now supports two MySQL connections from the same PHP process:

- `$conn` -> local `test_beliciacp` database on the Admin server.
- `$conn2` -> remote `test_belicia` database on the second server.

## 1. Configure PHP/Apache environment variables

Set these variables in the Apache/PHP service environment. Do not put real passwords in `db.php` or commit them to Git.

```text
DB1_SERV=127.0.0.1
DB1_PORT=3306
DB1_USER=<local-db-user>
DB1_PASS=<local-db-password>
DB1_NAME=test_beliciacp

DB2_SERV=<remote-db-host>
DB2_PORT=3306
DB2_USER=<remote-db-user>
DB2_PASS=<remote-db-password>
DB2_NAME=test_belicia
```

An example file is available at:

`core/db_controller/.env.example`

That file is a template only; PHP does not automatically load `.env` files without a dotenv library.

## 2. Apache environment

For Apache, configure the variables in the Apache service/environment mechanism used by the server. After changing them, restart Apache.

Verify from a PHP diagnostic page (temporarily and without printing passwords):

```php
var_dump((bool) getenv('DB1_USER'));
var_dump((bool) getenv('DB2_USER'));
```

Remove the diagnostic immediately after testing.

## 3. Remote MySQL firewall

The remote MySQL server must allow TCP/3306 only from the Admin server's private/public source IP as appropriate for the infrastructure.

Do not open MySQL 3306 to `0.0.0.0/0`.

## 4. Application usage

Existing code should continue using:

```php
$conn
```

for the primary/local database.

Use:

```php
$conn2
```

when a query must read/write the remote `test_belicia` database.

Example:

```php
$stmt = $conn2->prepare('SELECT id, name FROM lead WHERE id = ?');
$stmt->bind_param('i', $leadId);
$stmt->execute();
$result = $stmt->get_result();
```

## 5. PHP version

The connection layer is compatible with PHP 8.2 and uses typed functions supported by PHP 8.2.
