-- =====================================================================
-- PerformIQ admin — 07 · update for Targets (Target vs Achieved on every dashboard), October 2026
-- Run on the MAIN database (APP_DB) of a live project, after 06:
--   mysql -u root -p MAIN_DB < 07_update_targets.sql
-- Safe to run twice. New projects get the same from 01.
-- =====================================================================
SET NAMES utf8mb4;
-- Targets (Targets page): plan per month / quarter, Overall and per platform; also bookings / revenue achieved (entered by hand)
CREATE TABLE IF NOT EXISTS `pq_targets` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `period_type` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `period_key` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `platform` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `kind` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `metric` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` decimal(18,4) NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_target` (`period_type`,`period_key`,`platform`,`kind`,`metric`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Give the built-in roles the new Targets permission (Super Admin always has everything).
-- Other roles: Users & Roles → edit the role → Targets → tick View / Edit targets.
UPDATE `pq_roles` SET permissions = JSON_SET(permissions, '$.targets', JSON_ARRAY('view', 'edit')), updated_at = NOW()
 WHERE role_key = 'admin' AND JSON_VALID(permissions);
UPDATE `pq_roles` SET permissions = JSON_SET(permissions, '$.targets', JSON_ARRAY('view')), updated_at = NOW()
 WHERE role_key = 'viewer' AND JSON_VALID(permissions);

-- Check
SELECT role_key, JSON_EXTRACT(permissions, '$.targets') AS targets_rights FROM `pq_roles`;
SELECT COUNT(*) AS target_values FROM `pq_targets`;
