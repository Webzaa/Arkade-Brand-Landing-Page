# 1.0.19 Beta — changes

No SQL to run. Upload over v18 and keep your live `config/config.php`.
Thresholds are saved in `pq_settings` (key `insights`), created automatically.

## Creatives & Insights (new page: dashboard → Ad Platforms → Creatives & Insights)
- Every Meta / Google ad with spend or leads in the selected dates (the dashboard's date bar):
  image or video thumbnail, spend, leads, CPL, qualified, CPQL, site visits, CPSV, CTR, frequency (Meta),
  CPL change vs the period before, status. Click a creative for the full image / video / ad text.
  - Meta: image / video / carousel / multi-asset, "See it on Facebook" preview link; video plays when the token can see the Page's videos.
  - Google: Search ads shown as a search result (headlines + description), Display / Demand Gen images, YouTube videos.
  - Thumbnails are cached on the server (storage/cache/creatives) because Meta image links expire.
- Numbers are the same as the dashboards and the PDF report (pfPeriod): leads placed under their ad by ID, then by name.
- Campaigns & daily budgets table: daily / lifetime budget, average daily spend, budget use %.
- Insights & Actions: fixed rules decide (winner on CPQL, good CPL, cheap-but-junk, losing, fatigue, CPL rising,
  best site-visit ad, under-spending budget, limited by budget, pace vs Targets). Groq (GROQ_API_KEY) only writes the
  sentences; any Groq sentence with a number not in the finding is replaced by the rules' own wording.
  Benchmark = target CPL / CPQL from Targets, else the platform average for the dates.
  Super Admin → "Rules" button to change the thresholds.
- Access: anyone with Meta Ads or Google Ads view (each platform only for its own permission). Hidden numbers
  (Users & Roles → Hide numbers) are removed on the server and the rules that use them are skipped.
- Google per-ad CPL / CPQL needs the ad ID on the lead: tracking template
  `utm_campaignid={campaignid}&utm_adgroupid={adgroupid}&utm_adid={creative}` saved in lead.utm_adid. The page says how many leads are missing it.

## Daily budget on the Meta and Google dashboards
- New column "Daily budget" (and "Lifetime budget" in ▥ Columns) on both campaign tables, on by default (remove it in ▥ Columns).
  Meta: campaign budget, else the sum of its active ad sets' budgets. Google: campaign budget.

## Report emails (daily / weekly / monthly)
- "Insights & actions" box under the summary (per platform in the combined email), with a link to the page.
  Turn off with define('REPORT_INSIGHTS', false).

## Fixes
- ▥ Columns: "Apply" failed with an error once a layout had been saved (a variable used before it was declared).
