# 1.0.34 Beta — Upload Lead Status: a repeated person keeps their site visit

When the same mobile (or the chosen ID) is in the feedback file more than once — one person with two enquiries —
only one row is used for that lead. Before, the lower row always won, so

    row 50  …27133  Site Visit Done
    row 54  …27133  Lost              ← used: the site visit was lost

Now the row with the best outcome is used: site visit > qualified > anything else; on a tie, the lower row (as before).
The other row is listed as "Same mobile number again in row 50 — that row is used (it has the site visit)".

Feedback file of 30 Oct (Arvind Sensora): 15 people appear twice; 3 of them have a "Site Visit Done" row. With the
old rule 2 of those 3 site visits were dropped (7 instead of 9 new site visits on the test database).

File: app/Leads/status_upload.php. No SQL needed.
