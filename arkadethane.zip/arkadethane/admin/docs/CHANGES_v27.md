# 1.0.27 Beta — All / Performance / Awareness tabs + campaign-type rights

## Tabs instead of the "Include awareness campaigns" switch
All Platforms, Meta Ads, Google Ads, every manual platform, Creatives & Insights and Keyword Analysis have three tabs:

| Tab | Shows |
|---|---|
| All | every campaign |
| Performance | only performance campaigns (everything not tagged Awareness) |
| Awareness | only campaigns tagged Awareness in ⟳ Sync, and the awareness share of manual platforms (✎ Awareness) |

- Spend, impressions, clicks, leads, qualified, site visits, CPL / CPQL / CPSV, the daily chart, campaign tables, lead pop-ups and Excel / pivot exports all follow the tab.
- The tab is remembered per browser (cookie `pq_view`) and shared by all pages: switching on one dashboard switches the others that are open.
- Reports follow the tab you are on: the campaign report, the pivot export, the portfolio PDF, the daily / weekly / monthly PDF, and the "Select campaigns" list before a download. Scheduled email reports (cron) keep every campaign.
- Targets → "achieved" follows the tab.
- Manual platforms:
  - Performance tab = spend minus the awareness part.
  - Awareness tab = the awareness part only. Impressions, clicks, reach and views are split in the same proportion.
  - Leads count as performance, unless the whole platform is awareness.
  - A row that is part awareness shows its share; **Edit** still opens the numbers as saved.
- Website / Direct, unmapped leads and Taboola count as performance.
- `assets/js/awareness_toggle.js` is replaced by `assets/js/campaign_view.js`; the old file can be deleted.

## Users & Roles → Campaign types
Two new switches per role: **Show performance** and **Show awareness** (both on for existing roles; at least one must stay on).
- A type that is off is left out everywhere: dashboards, reports / PDFs, Creatives & Insights, Keyword Analysis, Targets, lead pop-ups.
- The tabs then show only the remaining type ("Awareness campaigns only").
- Manual platforms that are all awareness (✎ Awareness → All of it) are hidden from the menu, All Platforms and Targets for roles without "Show awareness".
- Platforms that are all performance (✎ Awareness → None), and Taboola, are hidden for roles without "Show performance". Their pages answer 403.
- Changing a platform's awareness split (✎ Awareness) needs both types.
- Not filtered: Leads & CRM, Unmapped Leads, CRM Push (lead lists), and the ⟳ Sync window (it must list every campaign so links are not lost).

Stored as `permissions.hide_types` in `pq_roles`; no SQL needed.
