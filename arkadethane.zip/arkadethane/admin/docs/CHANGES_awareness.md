# Awareness campaigns + optional OTT Video

## Performance / Awareness campaigns
- Master `campaigns` table: new column `campaign_type` (performance | awareness), added automatically
  (or run docs/09_update_campaign_type.sql).
- Execution team: Meta Ads / Google Ads → ⟳ Sync → each ticked campaign has **Performance | Awareness**.
  "Looks like awareness" is shown from the platform (Meta objective Awareness / Reach / Video views / Engagement;
  Google bidding Target CPM / CPV / Impression share) — a hint only, the team decides. New campaigns start from the hint.
  "Awareness" filter shows the tagged ones.
- Dashboards (All Platforms, Meta Ads, Google Ads): switch **Include awareness campaigns** (off by default).
  Off: awareness campaigns' spend, impressions and clicks are left out (KPIs, CPL / CPQL / CPSV, platform comparison,
  daily trend). Leads, qualified and site visits do not change (campaigns that brought leads stay with zero spend).
  The note next to the switch says how many campaigns and how much spend is left out.
  The switch is shared by all three dashboards (cookie pq_aw) and remembered.
- Not changed: report emails / PDF, Targets (Target vs Achieved), Creatives & Insights — they keep all spend.

## OTT Video is optional
- No platform is added automatically any more ("Add platform" adds OTT Video, Display, …).
- An OTT Video that was created automatically and never got a number is removed once. One that has numbers stays
  (remove it on its page → Remove platform).
- Overview legend no longer lists manual platforms without numbers in the selected dates.

## Manual platforms (OTT Video, Display, MyGate, …) — awareness spend

Each manual platform page has a **✎ Awareness** button. It asks how much of that platform's spend is awareness:

- **All of it** — every rupee is awareness.
- **A specific amount** — a ₹ amount per month (e.g. October 2026: ₹1,00,000). It is spread over that month's days by
  their spend, so a part of a month gets its share; it is never more than the month's spend.
- **Only some campaigns** — the full spend of the ticked campaigns.
- **None** — all performance (default).

The awareness part is left out of All Platforms (spend, CPL, CPQL, trend) unless **Include awareness campaigns** is on
(same switch / cookie `pq_aw` as Meta and Google). Leads never change. On the platform's own page the tiles follow the
switch; the table and chart keep the numbers as entered.

Stored in `ad_platforms.awareness_json` (column added automatically; `docs/10_update_manual_awareness.sql` if you prefer
to add it by hand). Targets and report emails are not changed by the switch (same as Meta / Google).
Files: app/Ads/ott.php, public/ads/ott_api.php, public/ads/ottdashboard.php, public/assets/js/awareness_toggle.js,
public/dashboard.php (+ v=2 of the switch script in metadashboard.php / googledashboard.php).
