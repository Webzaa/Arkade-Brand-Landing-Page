-- =====================================================================
-- PerformIQ admin — 06 · update for Send to CRM, CRM Settings (Salesforce) and Meta CAPI with uploads, October 2026
-- Run on every LIVE lead database (Embassy: test_embassysudo). pq_settings is only used in the MAIN database:
--   mysql -u root -p test_embassysudo < 06_update_crm_send.sql
-- Safe to run twice. New projects get the same from 01 / 02.
-- =====================================================================
SET NAMES utf8mb4;
-- CRM Push → "Send to CRM": every attempt (who, when, request, Salesforce reply)
CREATE TABLE IF NOT EXISTS `crm_push_log` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `lead_id` int NOT NULL,
  `sent_at` datetime NOT NULL,
  `sent_by` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `platform` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `http_code` int DEFAULT NULL,
  `result` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `crm_id` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `request` text COLLATE utf8mb4_unicode_ci,
  `response` mediumtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `lead_id` (`lead_id`),
  KEY `sent_at` (`sent_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- Settings saved from the admin (Admin → CRM Settings: Salesforce sign-in, endpoint, fields; secrets encrypted)
CREATE TABLE IF NOT EXISTS `pq_settings` (
  `setting_key` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` mediumtext COLLATE utf8mb4_unicode_ci,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`setting_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Upload Lead Status → Meta Conversions API: every event sent (each lead + stage is sent once)
CREATE TABLE IF NOT EXISTS `meta_capi_events` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `lead_id` int NOT NULL,
  `stage` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `event_name` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `event_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `leadgen_id` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sent_at` datetime NOT NULL,
  `sent_by` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `source` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `result` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `response` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `lead_stage` (`lead_id`,`stage`),
  KEY `sent_at` (`sent_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Optional: let the Admin role send leads too (Super Admin always can; other roles: Users & Roles →
-- edit the role → CRM Push → tick "Send leads to the CRM"). Run on the MAIN database only.
UPDATE `pq_roles`
   SET permissions = JSON_SET(permissions, '$.crm', JSON_ARRAY('view', 'send')), updated_at = NOW()
 WHERE role_key = 'admin' AND JSON_VALID(permissions);

-- Check
SELECT COUNT(*) AS crm_push_log_rows FROM `crm_push_log`;
SELECT setting_key, updated_at, updated_by FROM `pq_settings`;
SELECT COUNT(*) AS meta_capi_events_rows FROM `meta_capi_events`;
SELECT role_key, JSON_EXTRACT(permissions, '$.crm') AS crm_rights FROM `pq_roles`;
