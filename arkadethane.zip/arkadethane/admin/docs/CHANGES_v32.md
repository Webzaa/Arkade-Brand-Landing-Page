# 1.0.32 Beta — MQL removed from Upload Lead Status

- Step 3 ("Pick the columns to import") no longer has the MQL box. Lead status, site visit and platform work as before.
- The server ignores an MQL column too, so no upload can set QUALIFIED from MQL.
- To bring it back for a project: `define('STATUS_UPLOAD_MQL', true);` in config/config.php.
- A lead status *value* "MQL" in the status column is still read as QUALIFIED by default (you can change it in the
  value mapping, as before).

Files: app/Leads/status_upload.php, public/status_upload.php. No SQL needed.
