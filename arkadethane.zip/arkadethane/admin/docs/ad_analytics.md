# Meta Ads Dashboard — Setup Guide

## ✅ You only need to do 2 things

### Step 1 — Open config.php and add your credentials

```php
define('META_ACCESS_TOKEN',  'paste your token here');
define('META_AD_ACCOUNT_ID', 'paste your account ID here');
```

### Step 2 — Upload to your server
Upload all files to your PHP hosting (cPanel, DigitalOcean, etc.)
Open dashboard.php in your browser. Done!

---

## 📁 File Structure

```
meta-ads-dashboard/
├── config.php       ← ★ ADD YOUR CREDENTIALS HERE
├── fetch_meta.php   ← fetches data from Meta API (don't edit)
├── dashboard.php    ← open this in your browser
├── cache/           ← auto-created, stores data for 30 mins
└── README.md
```

---

## 🔑 Where to find your Ad Account ID

1. Go to business.facebook.com
2. Click your Ad Account name
3. Look at the URL: /act_XXXXXXXXXX/
4. The numbers after act_ = your Account ID

---

## ⚠️ Requirements

- PHP 7.4 or higher
- `allow_url_fopen = On` in php.ini (usually on by default)
- Internet access from server to graph.facebook.com

---

## 🔄 Data Refresh

- Dashboard auto-refreshes every 30 minutes
- Meta data has a 2–3 hour delay (Google's limitation)
- To force refresh: click "Refresh Now" button in the footer
- To change refresh time: edit CACHE_MINUTES in config.php
