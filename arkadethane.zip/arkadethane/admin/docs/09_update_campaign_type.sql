-- Campaign type for the master campaigns table: performance (default) | awareness.
-- The admin adds this column by itself the first time it opens; run it by hand only if the database user can't ALTER.
-- Run on the database that holds the `campaigns` table (MASTER_TABLES_DB, default: the first LEAD_DATABASES entry).
ALTER TABLE `campaigns` ADD COLUMN `campaign_type` VARCHAR(20) NOT NULL DEFAULT 'performance';

-- Tag a campaign as awareness by hand (normally done in ⟳ Sync with Meta / Google → Awareness):
-- UPDATE `campaigns` SET campaign_type = 'awareness' WHERE campaign_id = '1202…';
