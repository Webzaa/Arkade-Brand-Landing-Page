# 1.0.22 Beta — Targets: import, paste from Excel, template

On the Targets page (Targets → Edit targets), next to Save targets:

- **⤓ Import file** — .csv, .xlsx or .xls laid out like the page: Particulars down the first column (Spends,
  Leads (Workable), CPL, Qualified Leads, … Revenue), platforms across the first row (Overall, Meta, Google, OTT Video …).
  Rows under an "Achieved" heading (or named "Achieved Bookings") fill the Achieved boxes. The other way round
  (platforms down, particulars across) also works. Title rows above the headings, ₹ / commas / % in numbers and
  common names (Spend, QL, Site visits, Total…) are understood. Rows or columns not on the page are listed as skipped.
- **⧉ Paste from Excel** — paste a copied block with its headings; same rules as Import.
- **Paste into any box** — copy a block of cells and paste into a box: it fills from that box to the right and down.
- **↓ Download template** — the import format: this period's table as .csv, with the values already entered.

Import and paste only fill the boxes for the period on screen — check them and click **Save targets**. Empty cells
change nothing. .xlsx is read on the server (targets_api.php?action=parse, same reader as Upload Lead Status);
.xls is converted in the browser. No database change.
