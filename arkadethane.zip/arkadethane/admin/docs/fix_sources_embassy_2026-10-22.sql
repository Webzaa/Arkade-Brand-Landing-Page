-- Embassy: put 24 leads back on the platform their own ad tracking proves
-- (Upload Lead Status had moved them using the CRM's "Sub Source Category").

-- Meta lead form id → Meta (16 leads)
UPDATE `lead` SET campaignsource = 'Facebook Lead Form'
WHERE id IN (96,121,154,174,181,204,237,283,349,356,501,518,564,609,757,868)
  AND leadgen_id IS NOT NULL AND TRIM(leadgen_id) <> '';

-- Google click id / Google campaign id → Google (8 leads)
UPDATE `lead` SET campaignsource = 'google'
WHERE id IN (282,330,405,625,627,729,885,939)
  AND (leadgen_id IS NULL OR TRIM(leadgen_id) = '')
  AND ((gclid IS NOT NULL AND TRIM(gclid) <> '') OR (utm_campaignid IS NOT NULL AND TRIM(utm_campaignid) <> ''));

-- check: should return 0 rows
SELECT id, name, campaignsource FROM `lead`
WHERE (TRIM(COALESCE(leadgen_id,'')) <> '' AND LOWER(TRIM(campaignsource)) IN ('google','googledg','website','google ads','adwords'))
   OR (TRIM(COALESCE(leadgen_id,'')) = '' AND (TRIM(COALESCE(gclid,'')) <> '' OR TRIM(COALESCE(utm_campaignid,'')) <> '')
       AND LOWER(TRIM(campaignsource)) IN ('facebook lead form','facebook','fb','ig','instagram','meta','whatsapp'));
