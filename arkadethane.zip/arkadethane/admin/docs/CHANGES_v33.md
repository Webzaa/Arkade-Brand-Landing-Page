# 1.0.33 Beta — Import Leads: only missing leads, exact date & time, Meta names from the API

Import Leads (import.php):
- Only missing leads are added.
  - Meta rows with a lead ID are matched on the lead ID (leadgen_id) only. A person who filled the form twice is a new
    lead; the result says "same mobile as lead #… (different lead ID)" so you can see it.
  - Google / other rows: same lead ID or same mobile (last 10 digits), as before.
  - Rows repeated in the file are added once.
- Created date & time are saved exactly as in the file (Meta "Download leads" times are already IST, e.g.
  2026-10-28T22:14:50.000 → 2026-10-28 22:14:50). A row with no date / time is skipped, never saved as "now".
- Meta: campaign, ad set and ad names (and their ids) come from the Meta Graph API by ad ID (by lead ID when a row has
  no ad ID), 50 per request, with META_ACCESS_TOKEN. If Meta has no answer the file's names are kept; the result says
  how many were found and Meta's message.
- Meta: leads already in the database (same lead ID) get their **empty** campaign / ad set / ad columns filled from
  the API. A value that is already there is never overwritten. Both options are tick boxes on the page (on by default).
- Preview shows what would be added and which columns would be filled, without saving.
- Meta CSV ids like "l:123" / "ag:456" are saved as plain numbers.

Columns filled: campaign_name, utm_campaignname, mf_campaignid, utm_campaignid, adset_name, utm_adgroupname, adset,
mf_adsetid, utm_adgroupid, ad_name, utm_adname, adcreative, ad_id, mf_adcreativeid, utm_adid.

File: public/import.php. No SQL needed.
