# 1.0.35 Beta — Upload Lead Status: a site visit is always Qualified

- Every row whose site visit is Yes (e.g. "Site Visit Done") sets the lead status to QUALIFIED, whatever the lead
  status column says. A lead that already counts as qualified (QUALIFIED / LOST POST QUALIFIED) keeps its value.
- Works even when only a site visit column is chosen (no status column).
- Same for "Add missing leads": a not-found row with a site visit is added as QUALIFIED + Visited.
- Same person twice in the file (v34): the row with the site visit is used, so that person is Qualified + Visited.
- The review shows "N row(s) with a site visit are marked QUALIFIED", and the repeated-rows note now says which row
  is used (site visit, else qualified, else the lower row) instead of "the last row wins".

Feedback file of 30 Oct (Arvind Sensora): all 44 "Site Visit Done" rows → QUALIFIED + Visited.

Files: app/Leads/status_upload.php, public/status_upload.php. No SQL needed.
