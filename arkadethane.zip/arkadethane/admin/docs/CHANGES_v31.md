# 1.0.31 Beta — "All time" on Meta + readable error messages

## What went wrong
On All Platforms → All time (e.g. 1 Oct 2023 – 30 Oct 2026) Meta was left out with "Not included: Meta ([object Object])".
- Meta keeps ad results for 37 months, counted in the ad account's time zone. "All time" started exactly 37 months
  back, so Meta refused the request (error #3018). The daily chart request (one row per campaign per day for
  3 years) is also too big for one request.
- The dashboard printed Meta's error object as text, hence "[object Object]".

## Fixes
- Meta requests start at most 37 months less two days back (`metaSafeSince()` in app/Ads/fetch_meta.php): dashboard,
  ad sets, pivot export, ⟳ Sync and the Meta performance report. Leads from the CRM still use the dates as chosen.
  The API answer has `meta_since` when the start was moved.
- "All time" on every date filter starts there too (`pqAllTimeSince()`).
- Meta's daily chart is fetched in windows (up to 92 days in one request, else 180-day windows; a window Meta says
  is too big is split in half). If a window still fails, only the chart has a gap: the totals and campaigns stay,
  and the API answer has `api_warning` instead of `api_error`.
- Error messages now show Meta's own text, e.g. "Not included: Meta ((#3018) The start date of the time range …)".
- Target vs Achieved: long ranges show "October 2023 – October 2026 (37 months)" instead of every month's name.

No SQL needed.

Files: app/Ads/fetch_meta.php, app/Ads/meta_sync.php, app/Core/access.php, public/dashboard.php,
public/ads/meta_performance_report.php, public/assets/js/target_report.js, public/assets/js/date_presets.js (comment).
