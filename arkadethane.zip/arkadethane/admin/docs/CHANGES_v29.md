# 1.0.29 Beta — Add missing leads from the feedback report (Upload Lead Status)

Rows of the CRM feedback file that are not in the lead table can now be added as new leads.

## Where
- **Step 4 (review):** **＋ Add N missing leads…**, next to "Download rows not found".
- **After "Update leads":** a note "N rows are not in the database" with **＋ Add missing leads…**.
  - This also works when nothing needed updating.
- **Step 1:** **Import a saved missing-leads file**. It reads the CSV from "Download CSV" (or the same columns in XLSX / XLS), any time later.

## The editor (nothing is saved until "Add")
- **Every row is editable:** Name, Mobile, Email, Campaign source, Campaign, Lead status, Site visit, Created date, Unique ID. Each field is pre-filled from the file:
  - **Name, mobile, email, campaign, created date:** the file's own columns.
  - **Lead status, site visit, campaign source:** read the same way as in step 3.
  - **Unique ID:** the ID the rows were matched on.
- **Campaign source for all rows:** choose from the sources already in the database, or type another; "Set for all rows" / "Only where empty".
- **Rows:** untick rows to leave them out, 🗑 to remove; search; 100 rows per page.
- **Check rows:** says per row what will be added, what is skipped and what needs fixing.
  - Skipped: already in the database (same mobile, email or unique ID), or repeated in the list.
  - Needs fixing: no mobile / email, no campaign source, a date that can't be read.
- **Add leads:** checks again, then inserts in one go (all or nothing) into the chosen database (when there are several).
- **Download CSV:** the table as it is now (with your edits), to add later via "Import a saved missing-leads file".
- **Undo:** right after adding, and in "Missing leads added" under Recent uploads. Deletes exactly those leads, unless CRM Push has sent them since.

## Notes
- New leads are marked "imported from the CRM feedback report — already in the CRM", so CRM Push shows them as sent and never pushes them back to the CRM.
- Google sources also get `utm_campaignname`, so the leads land under their Google campaign on the dashboards.
- Dates: DD/MM/YYYY, YYYY-MM-DD, "12 Oct 2026" and Excel dates are read; empty = the time of adding.
- New right: Users & Roles → Upload Lead Status → **Add missing leads**. Roles that could upload get it automatically (permissions version 6). Without it, the rows can be checked and downloaded, not added.
- Table `lead_missing_imports` (the log for Undo) is created automatically in each lead database that gets leads added.

Files:
- New: `app/Leads/missing_leads.php`, `public/assets/js/missing_leads.js`.
- Changed: `public/status_upload.php`, `public/status_upload_api.php`, `app/Core/access.php`.

## 1.0.30 Beta — database per row (several lead databases)
- **Database column:** with more than one lead database (e.g. Official + Pseudo), every row has its own **Database**. It's pre-selected in this order:
  1. The database whose leads already use that row's campaign.
  2. Otherwise, the database whose name is in the campaign ("Pseudo", "Official"…).
  3. Otherwise, the database chosen in step 1 ("All databases" → the main one).
- **Changing it:** per row, or for every ticked row with **Database for the rows → Set for all rows**.
- **Check / Add:** run database by database. The confirmation and the result say how many go to each database (e.g. "2 to Pseudo Campaign, 1 to Official Campaign"). Undo removes all of them.
- **Duplicates:** "already in the database" is checked in the row's own database.
- **CSV:** the download has a **Database** column. Importing it later keeps each row's database (by name or key).

Files: `public/assets/js/missing_leads.js`, `app/Leads/missing_leads.php`, `public/status_upload_api.php`.
