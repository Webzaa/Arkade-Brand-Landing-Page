# 1.0.20 Beta — creative pictures and previews

No SQL. Upload the 3 files (or the full build) over v19 and keep your live config.php.

- Pictures could show as broken images. Now:
  - the image is sent on its own (any PHP notice or compression setting can no longer corrupt it);
  - every picture of an ad is tried (thumbnail, image, video thumbnails, all images of a multi-asset ad);
  - when this server can't download a picture (outbound blocked / CDN refused), the browser is sent to load it
    straight from Meta / Google;
  - pictures work even if storage/cache can't be written (the link carries a signed picture address);
  - a picture that still fails shows "Image not available" instead of the broken-image icon.
- Multi-asset (dynamic / Advantage+) and carousel ads: the preview shows all their images and videos;
  images known only by hash are looked up in the ad account.
- Super Admin check: creatives_api.php?action=thumb_check&platform=meta&id=AD_ID shows whether the server
  can download that ad's picture (HTTP code, error, cache folder writable).
