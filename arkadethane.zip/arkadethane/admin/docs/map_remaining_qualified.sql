-- Embassy: get every qualified lead (1 Sep – 21 Oct) onto the dashboard.

-- 1. (safe to run again) put leads back on the platform their own tracking proves — Raj #282, Vinayak #405 …
UPDATE `lead` SET campaignsource = 'Facebook Lead Form'
WHERE id IN (96,121,154,174,181,204,237,283,349,356,501,518,564,609,757,868)
  AND leadgen_id IS NOT NULL AND TRIM(leadgen_id) <> '';
UPDATE `lead` SET campaignsource = 'google'
WHERE id IN (282,330,405,625,627,729,885,939)
  AND (leadgen_id IS NULL OR TRIM(leadgen_id) = '')
  AND ((gclid IS NOT NULL AND TRIM(gclid) <> '') OR (utm_campaignid IS NOT NULL AND TRIM(utm_campaignid) <> ''));

-- 2. Facebook qualified leads with NO campaign (Ummai #953, Sanjaya #979, …) -> a project Meta campaign
UPDATE `lead`
SET campaign_name = 'Wz Embassy South Reserve - 16/09/26'
WHERE LOWER(TRIM(campaignsource)) IN ('facebook lead form','facebook','fb','ig','instagram','meta')
  AND (campaign_name IS NULL OR TRIM(campaign_name) = '')
  AND (utm_campaignname IS NULL OR TRIM(utm_campaignname) = '')
  AND (ad_id IS NULL OR TRIM(ad_id) = '')
  AND lead_status = 'QUALIFIED'
  AND createddate BETWEEN '2026-09-01 00:00:00' AND '2026-10-21 23:59:59';

-- 3. what is still left: qualified Facebook leads whose campaign is not one of the project's campaigns
--    (Google ones are now counted as "Website / Direct" by the new code)
SELECT l.id, l.name, l.campaignsource, l.campaign_name, l.utm_campaignname, l.createddate
FROM `lead` l
WHERE l.lead_status = 'QUALIFIED'
  AND l.createddate BETWEEN '2026-09-01 00:00:00' AND '2026-10-21 23:59:59'
  AND LOWER(TRIM(l.campaignsource)) IN ('facebook lead form','facebook','fb','ig','instagram','meta')
  AND NOT EXISTS (SELECT 1 FROM campaigns c WHERE c.platform = 'meta'
                  AND LOWER(TRIM(c.campaign_name)) = LOWER(TRIM(COALESCE(NULLIF(l.campaign_name, ''), l.utm_campaignname))))
  AND NOT EXISTS (SELECT 1 FROM ads a WHERE a.ad_id = l.ad_id);
