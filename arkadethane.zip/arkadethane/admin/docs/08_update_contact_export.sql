-- =====================================================================
-- PerformIQ admin — 08 · separate "full email / mobile IN EXPORTS" switches per user, October 2026
-- Run on the MAIN database (APP_DB):  mysql -u root -p MAIN_DB < 08_update_contact_export.sql
-- (The admin also adds these columns by itself if its database user may ALTER tables.)
-- unmask_email / unmask_mobile = on screen · export_email / export_mobile = in Excel / CSV exports
-- =====================================================================
SET NAMES utf8mb4;

-- Run the ALTER only once (it fails with "Duplicate column name" if the columns already exist — that is fine).
ALTER TABLE `users`
  ADD COLUMN `export_email` ENUM('Y','N') NOT NULL DEFAULT 'N',
  ADD COLUMN `export_mobile` ENUM('Y','N') NOT NULL DEFAULT 'N';

-- Start exports the same as the on-screen switches; change them per user in Users & Roles.
UPDATE `users` SET export_email = unmask_email, export_mobile = unmask_mobile;

-- Check
SELECT uid, username, unmask_email, export_email, unmask_mobile, export_mobile FROM `users`;
