# 1.0.28 Beta — "1 year" and "All time" on every date filter

| Where | Added |
|---|---|
| Main date bar (All Platforms, Meta, Google, Taboola, manual platforms, Creatives & Insights, Keyword Analysis) | **1 year** · **All time** (between Last month and Custom) |
| Meta / Google / Taboola own date pickers (opened on their own) | Last 1 Year · All Time |
| Creatives & Insights, Keyword Analysis opened on their own | 1 year · All time buttons |
| Manual platforms, CRM Push, Unmapped Leads | Last 1 year (All time was already there) |
| Leads & CRM, Unmapped (Google / Meta), Web Analytics date pickers | Last 1 Year · All Time |

- **1 year**: the last 12 months, till today (e.g. 30 Oct 2025 – 29 Oct 2026).
- **All time**: from the date of the project's oldest lead, till today.
  - The start date is found automatically and checked again every 12 hours.
  - To set it yourself, add `define('PROJECT_START_DATE', 'YYYY-MM-DD');` to config.php.
  - It never goes back more than 37 months, because Meta only keeps ad results that long.
- The new ranges are sent to Meta and Google as dates, never as preset names.
- Creatives & Insights, Keyword Analysis and the portfolio PDF now accept up to 37 months (before: 12 / 12 / 24).
- As before, Frequency and Reach (unique users) come back empty from Google for ranges over 92 days.

Files:
- New: `public/assets/js/date_presets.js`
- Changed: `app/Core/access.php` (pqAllTimeSince, pqDatesTag); `public/dashboard.php`, `public/ads/metadashboard.php`, `googledashboard.php`, `tabooladashboard.php`, `ottdashboard.php`, `unmapped.php`, `portfolio_report_api.php`; `public/creatives.php`, `creatives_api.php`, `keywords.php`, `keywords_api.php`, `crm_push.php`, `unmapped_leads.php`, `index.php`, `analytics.php`.
- No database change.
