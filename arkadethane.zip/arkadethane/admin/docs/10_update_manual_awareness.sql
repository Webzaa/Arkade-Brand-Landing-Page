-- 10_update_manual_awareness.sql — awareness setting for manual platforms (OTT Video, Display, MyGate, …)
-- Optional: the admin adds this column by itself the first time a manual platform page or All Platforms loads.
-- Run it in the master-tables database (MASTER_TABLES_DB, the one with ad_platforms). Safe to run once.
ALTER TABLE `ad_platforms` ADD COLUMN `awareness_json` TEXT NULL AFTER `sort_order`;
