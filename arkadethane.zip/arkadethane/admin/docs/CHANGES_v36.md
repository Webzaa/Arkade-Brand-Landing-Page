# 1.0.36 Beta — About PerformIQ

- New page **About PerformIQ** (dashboard.php#about, or public/about.php): version, release date, what is new, what the
  app includes (with "You have access" per module for the signed-in user) and the release history since 1.0.18, with
  search and a filter by area.
- The version and date are shown at the bottom of the menu ("PerformIQ 1.0.36 Beta · 31 Oct 2026") and in the user menu
  ("About PerformIQ"). Both open the About page.
- Every signed-in user can open it. Super Admin also sees a System card (project, lead databases, Meta API version,
  Taboola / manual platforms on or off, PageSpeed key set or not, PHP, server time — never keys or passwords) and a
  "Technical notes" button per release that shows docs/CHANGES_vNN.md.

Shipping a new patch: add it at the top of PQ_RELEASES in app/Core/version.php and update PQ_VERSION / PQ_RELEASED (PQ_CHANNEL = "Beta" is shown after the number).

Files: app/Core/version.php (new), public/about.php (new), public/dashboard.php, app/Core/access.php, docs/. No SQL needed.
