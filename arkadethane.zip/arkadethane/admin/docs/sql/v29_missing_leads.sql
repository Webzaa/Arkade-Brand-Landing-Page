-- Optional: created automatically the first time leads are added (each lead database that gets leads).
CREATE TABLE IF NOT EXISTS `lead_missing_imports` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `created_at` DATETIME NULL,
  `created_by` VARCHAR(100) NULL,
  `file_name` VARCHAR(255) NULL,
  `rows_added` INT NOT NULL DEFAULT 0,
  `lead_ids` MEDIUMTEXT NULL,
  `undone_at` DATETIME NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
