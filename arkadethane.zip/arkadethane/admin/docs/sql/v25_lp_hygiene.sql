-- Optional: LP Hygiene creates these itself on first use (main database).
CREATE TABLE IF NOT EXISTS `pq_lp_pages` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(120) NOT NULL,
  `url` VARCHAR(500) NOT NULL,
  `form_json` TEXT NULL,
  `created_at` DATETIME NULL,
  `updated_at` DATETIME NULL,
  `updated_by` VARCHAR(100) NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS `pq_lp_runs` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `page_id` INT UNSIGNED NOT NULL DEFAULT 0,
  `kind` VARCHAR(20) NOT NULL,
  `ok` TINYINT NOT NULL DEFAULT 0,
  `summary` VARCHAR(255) NULL,
  `result` MEDIUMTEXT NULL,
  `created_at` DATETIME NULL,
  `created_by` VARCHAR(100) NULL,
  KEY `page_kind` (`page_id`, `kind`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
