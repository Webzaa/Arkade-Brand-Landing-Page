# 1.0.37 Beta — About page for the execution team + FAQs

- About PerformIQ rewritten in plain language: every update says what changed, why it helps and where to find it
  (menu path). No code words; version numbers stay small.
- New FAQs (26 questions in 5 topics: Numbers & dates, CRM feedback upload, Importing leads, Tools, Access & help),
  with topic filters.
- One search box looks through the FAQs and the updates (matching questions open automatically).
- "What PerformIQ includes" in the team's words, with "You have access" / "Ask your admin" per feature and a count
  ("You can open 17 of 19 features").
- The first 5 updates are shown; "Show all updates" opens the rest.
- Super Admin: system details folded at the bottom; "Technical notes (admin)" small under each update.

Content lives in app/Core/version.php (PQ_RELEASES, PQ_FAQS) — edit the text there, no HTML needed (**bold** allowed in FAQ answers).

Files: app/Core/version.php, public/about.php, public/dashboard.php (subtitle). No SQL needed.
