# BeliciaAdmin — folder structure

```
BeliciaAdmin/
├── public/                 ← the ONLY folder the web server serves
│   ├── index.php, login.php, analytics.php, import.php, meta_capi.php, logs.php, google_callback.php
│   ├── leads/              lead pages + AJAX endpoints
│   ├── analytics/          analytics AJAX endpoints
│   ├── meta_capi/          CAPI upload / process / pixel check
│   ├── ads/                ad dashboards + their APIs (was ad_analytics/)
│   │   ├── js/performance_reports.js
│   │   └── images/webzaa-logo.png
│   ├── samples/            downloadable sample CSVs (were in docs/)
│   └── assets/             CSS, JS, fonts, images
├── app/                    shared PHP code, never served directly
│   ├── bootstrap.php       loaded first everywhere: folder constants + config
│   ├── Core/db.php         $conn (DB1) and $conn2 (DB2)
│   ├── Core/mailer.php     getMailer(), sendOTP()
│   ├── Leads/header.php    logged-in user + greeting
│   ├── Ads/                fetch_meta.php, meta_report.php
│   └── Reports/            report_access.php, report_mailer.php
├── config/
│   ├── config.php          THE settings file (DB, SMTP, Meta, Google, Groq, reports)
│   └── config.example.php  same with secrets blanked
├── cron/                   run from the command line only
│   ├── send_performance_reports.php
│   ├── sync_meta_structure.php
│   └── sync_google_structure.php   (was ad_analytics/google_sync.php)
├── database/create_campaigns_master.php
├── storage/                writable: cache/, logs/, meta_capi/temp.json
├── docs/
└── vendor/, composer.json, composer.lock
```

## Rules for new code

| Writing…                         | Put it in        | First line after `<?php`                                        |
|----------------------------------|------------------|-----------------------------------------------------------------|
| a page or AJAX URL               | `public/…`       | `require_once dirname(__DIR__) . '/app/Core/db.php';` (adjust depth) |
| a page that needs no DB          | `public/…`       | `require_once dirname(__DIR__) . '/app/bootstrap.php';`         |
| shared functions                 | `app/<Module>/`  | `require_once dirname(__DIR__) . '/bootstrap.php';`             |
| a scheduled / CLI script         | `cron/`          | `require_once dirname(__DIR__) . '/app/Core/db.php';`           |
| a setting, key or password       | `config/config.php` | `define('NAME', 'value');`                                   |

Use the constants instead of `__DIR__` paths: `BASE_PATH`, `APP_PATH`, `PUBLIC_PATH`,
`STORAGE_PATH`, `CACHE_PATH`, `LOG_PATH`, and `APP_URL` for links in emails.

## What changed besides moving

- One config: `core/config.php`, `ad_analytics/config.php`, `ai_insights_config.php`, the DB
  passwords in `db.php` and the Gmail password in `sendMail.php` are now all in `config/config.php`.
- Google **login** constants renamed to `GOOGLE_LOGIN_CLIENT_ID / _SECRET / _REDIRECT_URI`
  (they clashed with the Google **Ads** API `GOOGLE_CLIENT_ID / _SECRET`).
- Cache and log files go to `storage/` instead of next to the code.
- Old URLs `/admin/ad_analytics/...` redirect to `/admin/ads/...` (root `.htaccess`).
- Fixed links that were already broken: Add Lead save (`leads/insert_lead.php` → `insert_lead.php`),
  its Back/logo links, import sample CSV links, Google dashboard favicon, `logs.php` `$dbname`.

## One dashboard (PerformIQ shell) — Oct 2026

`public/dashboard.php` is the single entry point after login. It is an app shell:

| Sidebar section | What loads | File |
|---|---|---|
| Overview → All Platforms | native page: Meta + Google + Taboola combined (KPIs, comparison, funnel, daily trend, breakdown table) | `dashboard.php` (calls `ads/api.php`, `ads/googleapi.php`, `ads/taboolaapi.php`) |
| Ad Platforms → Meta / Google / Taboola | the platform dashboards, embedded | `ads/metadashboard.php`, `ads/googledashboard.php`, `ads/tabooladashboard.php` (`?embed=1`) |
| CRM → Leads & CRM | leads from every source (not tied to one platform) | `index.php?embed=1` |
| Tools | Web Analytics, Meta CAPI, Import Leads | `analytics.php`, `meta_capi.php`, `import.php` (`?embed=1`) |
| User menu | Add Users (superadmin only), Logout | `leads/users.php?embed=1`, `leads/logout.php` |

- Sections are addressed by hash: `dashboard.php#overview`, `#meta`, `#google`, `#taboola`, `#leads`, `#analytics`, `#capi`, `#import`, `#users`.
- Opening a platform dashboard directly redirects into the shell (`../dashboard.php#google`); add `?standalone=1` to open it on its own. `ads/dashboard.php` (old Meta URL) redirects to `dashboard.php#meta`.
- Theme: the shell's ☀/☾ button stores `performiq-theme` in localStorage; every embedded page follows it live. CRM/tool pages get theme + embed support from `app/Ui/embed_head.php`.
- `login.php` breaks out of the shell's frame, so an expired session shows the login full-window.

## Databases — any number (1, 2, 5 …)

All lead databases are listed once, in `config/config.php`:

```php
define('LEAD_DATABASES', [
    'pseudo'   => ['label' => 'Pseudo Campaign',   'host' => '…', 'port' => 3306, 'user' => '…', 'pass' => '…', 'name' => 'test_beliciacp'],
    'official' => ['label' => 'Official Campaign', 'host' => '…', 'port' => 3306, 'user' => '…', 'pass' => '…', 'name' => 'test_belicia'],
    // 'westgate' => [...],   ← add a line, nothing else to change
]);
define('APP_DB', 'pseudo');   // holds users / sessions / activity logs ($conn)
```

- **Key** (`pseudo`, `westgate` …): a-z, 0-9, `_`. It is what the "Campaign Database" filter sends. `all` is reserved.
- **One entry** → the filter hides itself. **More entries** → they appear in the filter, lead list, KPIs, export, pagination, dashboards, report emails and cron automatically.
- A database that can't be reached is skipped with a warning ("Westgate database connection is not available.") instead of breaking the page. Only `APP_DB` is required.
- Old configs with just `DB1_*` / `DB2_*` still work (they become `pseudo` / `official`).

Helpers in `app/Core/db.php` (use these in new code; `$conn2` is kept only for old code):

| Helper | Returns |
|---|---|
| `leadDbs('all')` / `leadDbs($key)` | `[key => mysqli]` for every reachable selected database |
| `leadDb($key)` | one connection, or `null` if unreachable |
| `leadDbKeys()`, `leadDbLabels()`, `leadDbLabel($key)`, `leadDbNames()` | keys, display names, MySQL database names |
| `isLeadDbChoice($v)` | `true` for `all` or a configured key |
| `appDbKey()`, `masterTablesDbKey()`, `reportLeadDb()` | users DB, campaigns/adgroups/ads DB (`MASTER_TABLES_DB`), portfolio PDF DB (`PORTFOLIO_REPORT_DB`) |

Where each part reads/writes:

| Part | Databases |
|---|---|
| Leads & CRM list, KPIs, pagination, export | all, or the one picked in the filter |
| Meta / Google / Taboola dashboards + Overview, report emails | all (Taboola merged by mobile) |
| Add / Edit Lead | edits in the lead's own database; new leads go to `APP_DB` |
| Offline upload (Meta, Taboola) | updates the lead where it exists; Taboola inserts new mobiles into `APP_DB` |
| Meta CAPI sender | finds the lead in any database, writes status back there |
| Unmapped leads tools | one database at a time — "Database" picker on the page (`?db=key`) |
| Portfolio PDF report | one database: `PORTFOLIO_REPORT_DB` (default: 2nd entry, else 1st) |
| Web Analytics, users, activity logs | `APP_DB` |

## Project campaigns (Meta + Google) — only data saved in the database

The ad accounts are shared between projects, so the Meta and Google dashboards show **only the campaigns, ad sets / ad groups and ads saved for this project** in the `campaigns`, `adgroups` and `ads` tables (`platform = 'meta'` or `'google'`, in `MASTER_TABLES_DB`), **with the names saved there**. Nothing linked yet → the dashboard is empty with a "No campaigns linked" banner.

- **⟳ Sync with Meta / ⟳ Sync with Google** (Campaigns tab, or "Manage campaigns" on the banner) lists every campaign in the account with its spend. Campaigns with leads in this project are suggested (Meta: lead `campaign_name` and `ad_id`; Google: `utm_campaignid` / `utm_campaignname`). Tick / untick, then **Save & sync**:
  - adds the ticked campaigns with their ad sets / ad groups and ads, removes unticked ones (with their ad sets / ads);
  - fills blank lead names (Meta: `campaign_name` / `adset_name` / `ad_name` from `ad_id`; Google: `utm_campaignname` from `utm_campaignid`) — never overwrites;
  - creates the three tables if they don't exist.
- **↻ Refresh details** re-reads names, statuses, ad sets and ads from the ad platform for the linked campaigns (this replaces names you edited by hand in the tables).
- Leads are matched to a saved campaign by ID first (ad ID / campaign ID), then by name, so a campaign renamed in the table keeps its leads.
- Applies to: dashboard tables, totals and daily trend, drill-downs (ad sets → ads), lead pop-ups, pivot / Excel exports, daily / weekly / monthly reports, the PDF portfolio report, the Overview and the Unmapped-leads dropdowns.
- **Taboola is not filtered** (for now) — it shows the whole Taboola account as before.
- Code: `app/Ads/master_tables.php` (shared filter + save), `app/Ads/meta_sync.php`, `app/Ads/google_sync.php`, `public/ads/project_sync_api.php` (button backend; `meta_sync_api.php` is an alias), `public/ads/js/project_sync.js` (the window).
- Crons: `cron/sync_meta_structure.php` links every Meta campaign that has an `ad_id` in the lead table; `cron/sync_google_structure.php` refreshes the linked Google campaigns only.

## Upload Lead Status (CPQL / CPSV data)

Sidebar → CRM → **Upload Lead Status** (`public/status_upload.php`, backend `public/status_upload_api.php`, logic `app/Leads/status_upload.php`). Separate from the platform dashboards; it updates the lead table that every dashboard reads.

1. **Upload** a CRM export — `.csv` (comma / semicolon / tab), `.xlsx` (read on the server), or `.xls` (converted in the browser). First non-empty row = headers. Up to 50,000 rows.
2. **Unique ID** — match leads on any column of the `lead` table: **mobile** (last 10 digits, so +91 / spaces / dashes don't matter), **email** (ignoring capitals and spaces), **uniqueid**, **leadgen_id**, **gclid**, or any other column under "Another column" (exact, case-insensitive). Each choice shows how many leads have a value. In step 3 the page checks the chosen file column straight away ("460 of 549 rows find a lead") and warns about emails that look cut off (e.g. `…@gmail.c`). The column list comes from `SHOW COLUMNS FROM lead` (text/date/status columns are left out) and is checked again on the server, so only real columns can be used. History stores the column name in `id_type`.
3. **Map columns** — pick the file column for each of the four:

   | Review column | Lead column | Allowed values → written as |
   |---|---|---|
   | Unique ID | the column chosen in step 2 (`mobile`, `email`, `uniqueid`, …) | used only to find the lead |
   | Lead status | `lead_status` | QUALIFIED / NON-QUALIFIED / TO BE QUALIFIED (QUALIFIED counts for CPQL) |
   | Site visit | `sitevisit_status` | Yes → `Visited`, No → `Not Visited` (Visited counts for CPSV) |
   | Platform | `campaignsource` | Google → `Google`, Meta → `Facebook Lead Form` |

   Every distinct value in the file gets a dropdown with only the allowed values (or "leave as it is"); sensible defaults are pre-selected (e.g. Unqualified / DND → NON-QUALIFIED, Contacted → TO BE QUALIFIED, 1 → Yes, Facebook → Meta, Google Search Campaign → Google). Values with no choice are left alone. Status, site visit and platform can each be skipped.
4. **Review** — every row shows the four columns: file value → choice, and the database value old → new; plus totals (will update, not found, newly Qualified, site visits set back to No, platform changes…). Nothing is written until **Update N leads** is confirmed. "Download rows not found" exports the misses.

- Only existing leads are updated (never inserted). If a mobile matches several leads, all of them are updated; if an ID appears twice in the file, the last row wins.
- Platform is only changed when a lead moves between Google and Meta (e.g. Instagram stays Instagram). A lead moved to Meta still needs a `leadgen_id` to be counted on the Meta dashboard.
- The write runs in one transaction and only if the leads still match the review.
- Every upload is logged in `lead_status_uploads` / `lead_status_upload_rows` (created automatically in the lead database). **Undo** in "Recent uploads" puts the old values back on leads that still hold the uploaded value.
- Temp copies of uploaded files: `storage/cache/status_upload/` (deleted after the update, or after a day).

## Server health check (`tools/check_server.sh`)

    cd /var/www/<site>/admin
    sudo bash tools/check_server.sh          # report only
    sudo bash tools/check_server.sh --fix    # also gives storage/ to the web user (chown + chmod 775)

Checks PHP version + extensions and upload limits, which user PHP runs as, storage/ and config.php permissions (tested as that user), every lead database and its columns, whether the DB user can create tables, the campaigns linked on Meta / Google, the Meta token + ad accounts, Google OAuth + Ads account, Taboola login, that config/ and storage/ are not reachable from the web, and recent PHP errors. Secrets are never printed.

## Unmapped Leads (Meta + Google)

Sidebar → CRM → **Unmapped Leads** (`public/unmapped_leads.php`, backend `public/unmapped_leads_api.php`, logic `app/Leads/unmapped.php`). The red badge is the all-time count. The "Unmapped Leads" buttons on the Meta and Google dashboards open this page on their tab; the old `ads/unmapped_meta.php` and `ads/unmapped.php` redirect here (`ads/unmapped.php?platform=taboola` is still the Taboola page).

- A lead is unmapped when no dashboard can put it under a campaign saved for this project:
  - **Meta** (leadgen_id, or source Facebook / Instagram / fb / ig / WhatsApp): its `ad_id` isn't a saved ad and its `campaign_name` isn't a saved campaign name;
  - **Google** (source Google / googledg, or a gclid / utm_campaignid): its `utm_campaignid` isn't a saved campaign ID and its `utm_campaignname` isn't a saved name. Google leads with no campaign at all are shown as "Website / Direct" on the Google dashboard and in the PDF until mapped;
  - **No source** (empty campaignsource): choose Meta or Google when mapping.
  Website, Taboola, other sources (referral, walk-in…), TEST / JUNK and obvious test leads are not listed.
- One row per person and platform (newest lead shown; mapping applies to all that person's unmapped leads on that platform).
- **Map** only offers saved campaigns → ad sets / ad groups → ads, and writes their saved names (Meta: campaign_name, adset_name, ad_name, and ad_id when empty; Google: utm_campaignname / utm_campaignid / utm_adgroupname / utm_adgroupid / utm_adname / utm_adid). Bulk: tick rows → Map to… / Mark Test / Mark Junk. **Import CSV** (columns mobile / leadgen_id / gclid, platform, campaign, adset_or_adgroup, ad — names as saved) shows a dry run before writing.
- Campaigns found on leads that aren't linked are listed at the top — linking them with ⟳ Sync maps those leads without editing them.
- Every change is logged to `storage/logs/unmapped_actions.log` and clears the dashboard / PDF caches.

## Portfolio PDF (Meta + Google)

**Export PDF** on the Overview (uses the Overview's date filter; detail: campaigns / + ad sets / + ads) and "Export PDF (Meta + Google)" in each dashboard's Export menu. Builder: `public/ads/js/portfolio_pdf.js`; data: `public/ads/portfolio_report_api.php` → `app/Ads/portfolio_data.php`.

- Per calendar month: spend / impressions / clicks from Meta insights and the Google pivot report (saved campaigns only), and leads / qualified / site visits from the lead table(s), each lead under its saved campaign → ad set / group → ad (by ID first, then by name). Numbers match the dashboards; leads that can't be placed are shown as "unmapped" in the header, not added in.
- Reads all lead databases (or only `PORTFOLIO_REPORT_DB` when set). Taboola only with `define('PORTFOLIO_INCLUDE_TABOOLA', true);`.
- Cached 15 minutes; cleared whenever leads are mapped, uploaded (Upload Lead Status) or campaigns are synced.

## CRM Push (leads that did not reach the CRM)
- Page: `public/crm_push.php` (sidebar → CRM → CRM Push, badge = failed + not sent, all time). API: `public/crm_push_api.php` (list / counts).
- Logic: `app/Leads/crm_push.php` — `crmPushResult()` reads `lead.curlresponse` (the CRM reply the website saves):
  sent (status 200 + Lead ID), existing (Account ID 001…, no new lead), failed (400 / error list, reason in plain words), not sent (empty).
- Read-only: the website sends leads to the CRM; failed leads are exported (CSV) and added in the CRM by hand.
- The Unmapped Leads page shows a "CRM failed / not sent" pill on each lead and has a lead status filter.

## Upload Lead Status — MQL column
- Optional MQL column: MQL = 1 / Yes / True → QUALIFIED (wins over the lead status column).
  MQL = 0 → the lead status column decides; with no lead status column, MQL = 0 → NON-QUALIFIED.

## Taboola (hidden)
- Hidden from the sidebar, All Platforms and the Meta / Google platform switchers unless config sets `define('SHOW_TABOOLA', true);`.
  The PDF has its own switch (`PORTFOLIO_INCLUDE_TABOOLA`). Taboola pages/APIs are kept as they are.

## Leads counted as people (All Platforms + PDF)
- Leads / Qualified / Site visits = unique people: one per mobile (last 10 digits) per platform in the period.
  A repeat form entry counts once (under the campaign of the first entry); the person is Qualified / visited if any entry is.
- Logic: `pfPeriod()` in `app/Ads/portfolio_data.php`; the Overview reads `public/ads/people_counts_api.php` (no spend calls)
  and shows "N form entries" under Leads. The Meta / Google dashboards still list every entry.

## Leads & CRM — Lead Status filter
- Dropdown in the filters (Qualified / To be qualified / Non-qualified / No status / Site visit done / Test / Junk); applies to the
  list, the charts and the Excel export (`app/Leads/status_filter.php`). The export now has Lead Status and Site Visit columns.

## Reports menu (All Platforms)
- "↓ Reports" replaces "Export PDF": Campaign report (the date filter, detail from the list — the existing portfolio PDF) +
  Daily / Weekly / Monthly report = the combined Meta + Google email as a PDF (yesterday / last Mon–Sun week / last full month).
- Email HTML is built by `app/Reports/email_builder.php` (moved out of cron/send_performance_reports.php — the cron job
  requires it, output unchanged). `public/ads/email_report_api.php` turns the two platform reports into that HTML;
  `public/ads/js/email_report_pdf.js` draws it and cuts A4 pages between table rows.

## Manual platforms (OTT Video, Display, MyGate, TOI Interstitial, …)
- Sidebar → Ad Platforms → one item per manual platform + "Add platform". Page `public/ads/ottdashboard.php?p=<key>`
  (OTT Video = p=ott; ?new=1 = add a platform), API `public/ads/ott_api.php`, logic `app/Ads/ott.php`.
- No ad API: daily numbers are added by hand (+ Add day / Edit) or pasted from a sheet (Paste / import: tab or comma
  separated, header row, dates like "1 Oct" / "01/10/2026" / "2026-10-01"). A "Total" / "Grand Total" row checks the sums;
  when spend is only in that row (e.g. MyGate) it is spread over the days by impressions. A header written on the
  title line above the header row (e.g. "MyGates … spend") is picked up too.
- ✎ Platform: rename, colour, lead sources (CRM campaignsource values counted as that platform's leads), remove
  (deletes its rows; type the name to confirm).
- Two tables for ALL manual platforms (no table per platform), in the master-tables database, created automatically:
  `ad_platforms` (id, platform_key, name, color, lead_sources JSON, columns_json = the page's column layout, sort_order)
  and `ad_platform_daily` (platform_id → ad_platforms.id, stat_date, campaign, impressions, clicks, reach, views, spend,
  extra JSON; unique on platform_id + stat_date + campaign; rows are deleted with their platform).
  Data in the first version's `ott_daily` / `ott_settings` is copied in once, automatically (those tables are then unused).
- ⚙ Columns: show / hide, reorder, add custom columns — "typed in" or "formula" (spend / views * 1000).
- All Platforms adds each manual platform for periods that have its numbers. Hide all with `define('SHOW_OTT', false);`.

## ▥ Columns on the Meta / Google campaign tables
- "▥ Columns" next to "Show [n] entries" opens "Modify columns" (like Google Ads): tick columns, drag to reorder, ✕ to
  remove, extra metrics (Avg. CPC, Reach, Cost per 1,000 reached, Lead rate, Qualified rate, Site-visit rate,
  Lead → site visit %, Google lead-status counts), "+ Custom column" = a formula over spend, impressions, clicks, reach,
  leads, qualified, sitevisits … (totals use the summed numbers). Status + Campaign stay first. Reset to default.
- `public/ads/js/column_picker.js` rearranges the table each dashboard already draws (campaign, ad set and ad levels);
  layouts are saved per user in `pq_user_prefs` (created automatically) via `public/ads/column_prefs_api.php`.
- Platform metrics (`app/Ads/platform_metrics.php`): a SEPARATE, optional request next to each dashboard's own one adds
  `pm` to every row — Meta Insights (unique / link / outbound clicks, video plays 25–100 %, ThruPlays, 3-sec views,
  landing page views, post engagements, reactions, comments, shares, Meta-reported leads, messaging conversations) at
  campaign / ad set / ad level; Google Ads (interactions, engagements, conversions, all conversions, conversion value,
  view-through conversions, TrueView views, reach = unique users (campaigns, ranges ≤ 92 days), invalid clicks, video quartile rates) for campaigns and ads (ad groups are
  added up in the browser). A field the platform rejects is dropped and the request retried (field names change between
  API versions); on failure the row simply has no `pm`. Shown under "From Meta" / "From Google" + "Calculated from
  platform metrics" (cost per ThruPlay, cost per landing page view, hook rate, Avg. CPV, interaction rate, cost / conv. …);
  custom formulas can use the pm_… names.

## Login page and login code email

- `public/login.php` — two steps: email → 6-digit code (boxes accept paste / phone autofill, resend after 30 s), or Google login. Shows `PROJECT_NAME`. Endpoints unchanged: `leads/ajax_send_otp.php` (answers `sent`) and `leads/ajax_verify_otp.php` (answers `success`).
- `app/Core/otp_mail.php` — the code email (`otpEmailHtml`) and `sendLoginOtpMail()`: sends through this admin's SMTP (same as the report emails); if that fails it falls back to the old mailer API (`wzpocs.in/.../sendMail.php`). `OTP_MAIL_VIA = 'api'` uses only the old API.
- Report emails: subject starts with the project name (`REPORT_PROJECT_NAME`, else `PROJECT_NAME`), the header shows it as a badge, and the sender name is "<project> · Webzaa" unless `REPORT_FROM_NAME` is set.

## Users, roles & permissions

- **Users & Roles** page: `public/leads/users.php` (sidebar → Admin → Users & Roles, Super Admin only), backend `public/leads/users_api.php`.
  Users tab: add / edit / block / **delete** users, role per user, show full emails / mobiles. Roles tab: create roles and tick what each may open and do.
- **Super Admin** is built in: full access, the only one who sees Users & Roles and Logs; it can't be edited or deleted. You can't delete, block or demote yourself, and the last active Super Admin is protected.
- **Admin** (built in, editable, not deletable) starts with everything except Users & Roles — same as before. **Viewer** is an example read-only role.
- Permissions live in `app/Core/access.php`: `PQ_MODULES` (modules and actions: View, Sync campaigns, Export, Add / edit…), `PQ_ROUTES` (which page / API belongs to which module). `pqAccessGuard()` runs at the end of `app/Core/db.php` on every web request: not signed in → login; blocked or deleted user → signed out; role changes apply on the next click; no permission → "no access" page or 403 JSON. Scripts not in `PQ_ROUTES` (login, OTP, Google callback, signed report links, webhooks, cron) are not touched.
  **Adding a new page or API: add it to `PQ_ROUTES`**, or it is only protected by its own login check.
- Tables: `pq_roles` (role_key, name, description, permissions JSON, is_system) is created on the first visit to Users & Roles. `users.role` is widened from ENUM('superadmin','admin') to VARCHAR(50) at the same time; if the database user has no ALTER right, run `docs/roles_setup.sql`.
- `users.lastlogin` is now filled on login (email code and Google).

## Counting rules (All Platforms, PDF report, Meta tab, Google tab)

- **Leads** = every form entry (non-test). **Qualified leads** and **site visits** = unique people (last 10 digits of the mobile).
- Meta leads not under one of the project's campaigns → one row **"Unmapped leads (no campaign)"** (Meta tab + reports); clicking it opens Unmapped Leads.
- Google leads with no campaign, or a campaign not linked to the project → **"Website / Direct"** (`pqGoogleCampaignIsWebsite`).
- Leads with no source at all are not counted anywhere until a platform is chosen in Unmapped Leads.
- Switches in config.php: `DASHBOARD_COUNT_UNMAPPED`, `DASHBOARD_LEADS_AS_PEOPLE`, `GOOGLE_UNMAPPED_TO_WEBSITE`.

## Hide numbers per role (Users & Roles → Roles → "Numbers on the dashboards")

- Each role can hide **Qualified leads**, **CPQL**, **Site visits** and **CPSV** (stored as `permissions.hide_metrics` in `pq_roles`; Super Admin always sees everything).
- `pqMetricGuardTag()` (app/Core/access.php) puts the list + `public/assets/js/metric_guard.js` on All Platforms, Meta, Google and the manual platform pages.
- metric_guard.js hides: KPI cards (`renderKpiCardHTML` / overview tiles), funnel stages, table columns whose header matches (also after re-draw), and elements marked `data-pq-metric="…"` (e.g. the Meta walk-in chart).
- **Reports follow the same setting** for a logged-in user:
  - Campaign report PDF (`portfolio_pdf.js` + `portfolio_report_api.php`): columns / cards dropped; the API blanks the numbers and drops insight sentences that mention them (`pqStripHiddenMetrics`, applied after the shared cache).
  - Daily / weekly / monthly report PDFs from the Reports menu (`email_report_api.php` → `email_builder.php`, `srHidden()`): cards, tables, comparison rows and summary sentences left out.
  - Meta / Google performance reports, monthly decks and their Excel (`performance_reports.js`, `meta|google_performance_report.php`): metrics removed from cards, tables (`deckTable` drops columns by header), funnel, takeaways, watchlist and notes; the APIs blank the numbers for web users.
  - Every other Excel export on those pages: `metric_guard.js` wraps `XLSX.utils.aoa_to_sheet` / `json_to_sheet` and drops hidden columns by header.
- The **scheduled emails** (cron → fixed recipients) are not tied to a user and stay complete.

## CRM Push → Send to CRM (October 2026)

- `public/crm_push.php` lists failed / not-sent leads; Meta and Google ones get **Send to CRM** (per row, or select several → *Send N to CRM*).
- Logic: `app/Leads/crm_send.php` (sending, safety rules, log) on top of `app/Leads/crm_sfdc.php` (settings, sign-in with a 30-minute token cache in `storage/cache/`, field values). JSON built with `json_encode`.
- Settings: **Admin → CRM Settings** (`public/crm_settings.php` + `crm_settings_api.php`, Super Admin only; logic `app/Leads/crm_sfdc.php`).
  Sign-in (client credentials or username + password, optional backup), lead endpoint (full URL or a path added to the
  instance URL), which leads may be sent (Meta / Google / other sources) and the field list. Values are text with
  placeholders: `{lead_column}`, `{a|b}` first with a value, `{col|'fixed'}`, specials `{enquiry_date}` `{countrycode}` `{mobile_10}` …
  “Test sign-in” and “Preview” never create anything. Stored in `pq_settings` (main DB), secrets AES-256-GCM encrypted
  with `PQ_APP_KEY` (else `REPORT_LINK_SECRET`). Nothing saved there → the older `CRM_SFDC` block in config.php is used.
- Saved: Salesforce reply → `lead.curlresponse` (wrapper `{"success","stage","http_code","response","via":"admin","sent_by","sent_at"}`); every attempt → `crm_push_log`.
- Rules: only leads still failed / not sent (re-checked before each send), never test leads, max 25 per request, one batch per database at a time, a batch stops at the first Salesforce limit error.
- Permission: Users & Roles → CRM Push → "Send leads to the CRM" (Super Admin always). SQL for live projects: `docs/06_update_crm_send.sql`.

## Upload Lead Status → Meta Conversions API (October 2026)

- After a feedback upload is saved, Meta leads that **become Qualified** or **get a site visit** in that upload are sent to Meta
  (Conversions API for CRM: `action_source = system_generated`, `user_data.lead_id` = lead form ID + hashed email / phone,
  `custom_data.event_source = crm`). The preview shows how many events will go; a tick box can skip them for one upload.
- Logic: `app/Leads/meta_capi_send.php`; wired in `public/status_upload_api.php` (preview / commit / `capi_retry`) and `public/status_upload.php`.
- Settings: Admin → CRM Settings → "Meta Conversions API" (dataset / pixel ID, token — or `META_ACCESS_TOKEN` from config.php —,
  event names, CRM name, optional test event code). Stored in `pq_settings` key `meta_capi`, token encrypted.
- Each (lead, stage) is sent once (`meta_capi_events`, also sets `lead.capi_sent` / `capi_sent_stage`). Test leads and non-Meta leads are skipped.
  If Meta fails, the leads are still saved and "Try sending to Meta again" re-sends only that upload's failed events. Undo does not recall events.
- Note: `public/meta_capi/process_capi_lead.php` (the separate Meta CAPI page) still has its real Graph call commented out and a mock reply.

## Targets — Target vs Achieved (October 2026)

- **Targets page** (`public/targets.php` + `targets_api.php`, logic `app/Ads/targets.php`; sidebar → Overview → Targets).
  Targets per **month or quarter** (setting on the page) for Overall and each platform (Meta, Google, Taboola, manual platforms):
  Spends, Leads, Qualified leads, SV, Bookings, Clash bookings, Revenue, and optional fixed rates (CPL, Lead→QL %, CPQL, QL→SV %,
  CPSV, SV→Booking %, Cost to sales %). Empty rate = worked out from the numbers; empty Overall = sum of the platforms.
  Bookings / clash / revenue **achieved** are entered there too (the admin has no booking data).
- **Card on every dashboard** (`public/assets/js/target_report.js`): All Platforms (with a platform picker), Meta, Google, Taboola,
  manual platforms. Achieved Spends / Leads / QL / SV = `pfPeriod()` (same as the PDF report), cached 10 min (2 min when a spend
  API failed; unknown spend shows “—”, not 0). Full period target or pro-rated to the days in the range (toggle on the card).
  Roles' hidden numbers (CPQL, site visits…) remove the matching rows.
- **Permission**: Users & Roles → Targets → View / Edit targets. SQL for live projects: `docs/07_update_targets.sql`.
- **One date filter**: the bar under the top bar of `dashboard.php` (7 days / 30 days / This month / Last month / Custom) drives
  All Platforms and every embedded dashboard (`postMessage {type:'pq-range', since, until}` + `?since=&until=` on first load);
  the embedded pages hide their own date picker. The choice is remembered in the browser. Opened on their own (new tab) the
  platform pages keep their own date picker.

## Full email / mobile — on screen and in exports, separately (October 2026)

- Users & Roles → per user, four switches: `unmask_email` / `unmask_mobile` (on screen) and `export_email` / `export_mobile`
  (Excel / CSV exports). Rule in `app/Core/db.php`: `pqContact($value, 'email'|'mobile', 'screen'|'export')`, `pqContactRows()`
  for list APIs (adds `mobile_export` / `email_export`), `pqContactJs()` → `window.PQ_CONTACT` for pages that mask in the browser.
- Exports: Leads & CRM (`leads/export.php`, was always masked), Unmapped Leads CSV, CRM Push CSV, Taboola leads Excel.
  Screens: Unmapped Leads and CRM Push now mask on the server (they sent full numbers to everyone before); Taboola masks in the page.
- Columns `users.export_email` / `export_mobile`: added by the admin itself (first filled from the on-screen switches) or by
  `docs/08_update_contact_export.sql`. Switch changes apply on the user's next click (access guard re-reads them).

## Upload Lead Status → "All databases" (October 2026)

- With more than one lead database the page defaults to **All databases** (`db=all`): each row is matched in every database
  (`app/Leads/status_upload_multi.php`, `suPlanAll()`). Found in one → updated there. Found in several → the file's campaign
  column (step 3, "Campaign — to tell the databases apart") is compared with the lead's campaign in each database and with the
  database names ("Pseudo", "Official"); the best clear match wins. Still unclear → update everywhere (default) or skip.
- Saving writes one upload record per database (history shows the database; Undo / Meta retry are per database).
  Picking one database ("Pseudo Campaign only") works exactly as before.
