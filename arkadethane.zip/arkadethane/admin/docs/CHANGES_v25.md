# 1.0.25 Beta — LP Hygiene

New sidebar item **Tools → LP Hygiene** (`public/lp_hygiene.php`, API `public/lp_hygiene_api.php`, logic `app/Tools/lp_hygiene.php`).

## What it does
- **Landing pages**: add each page the ads send people to (name + URL). The first time, the site of this admin is added.
- **PageSpeed Insights** (mobile + desktop): Performance, Accessibility, Best Practices, SEO (and any other category Google returns, e.g. Agentic Browsing), FCP, LCP, TBT, CLS, Speed Index, real-user rating, biggest fixes, page screenshot.
- **Page checks**: page opens, HTTPS + SSL expiry, server response, title, meta description, viewport, indexing, Meta Pixel, GTM / Google Ads / GA4 tags, lead form (name / email / phone), UTM capture, gclid / keyword capture, call / WhatsApp links, privacy policy, image alt text, favicon, Open Graph. The lead form found is saved for the landing-page test lead.
- **Meta test lead (Graph API)**: lead forms come from the project's leads (form_id / page_id) with names from Meta. Steps: page token → read the form's questions → find the form's old test leads → DELETE each → POST /{form_id}/test_leads → read the new lead back. Every step's request, HTTP code and response is shown (tokens hidden).
- **Landing page test lead (Google)**: posts the page's form like a Google ad visitor (utm_source=google, utm_medium=cpc, a test gclid / keyword into hidden fields the form has).
- **Name and email must contain "test"** (checked in the browser and on the server); mobile = 10-digit number, remembered.
- **Did it arrive?** After sending, the lead table is checked every few seconds (by leadgen ID / email, else the test mobile) and the CRM's answer on the lead is shown.
- **Download PDF**: scores, metrics, checks, both test leads with values and responses.
- History of every run (last 100 per page).

## Roles & permissions
Users & Roles → Tools → **LP Hygiene**, with six rights (each one is checked on the server, and buttons the role can't use are hidden):

| Right | Allows |
|---|---|
| View | Open the page, see results, history and Meta lead forms |
| Run PageSpeed & page checks | Run PageSpeed (mobile / desktop), Check page, Run all checks |
| Add / edit / delete pages & form settings | + Add page, Edit, Delete page, Save form settings |
| Send Meta test leads (Graph API) | Delete old & send Meta test lead |
| Send landing page test leads | Send landing page test lead |
| Download PDF report | Download PDF |

Existing roles: roles that can sync Meta or Google campaigns get all six until the role is saved again (permissions version 5). The default Viewer role gets View.
The role editor now wraps long lists of rights instead of squeezing the module name.

## Config (optional)
```php
define('PAGESPEED_API_KEY', '…');        // free key: Google Cloud → APIs & Services → PageSpeed Insights API
// define('META_PAGE_ACCESS_TOKEN', '…'); // only if the page token can't be read with META_ACCESS_TOKEN
```
META_ACCESS_TOKEN needs pages_show_list, pages_manage_ads, leads_retrieval, pages_read_engagement for the page (the same token the lead webhook uses usually has them).

## Database
Created automatically in the main database: `pq_lp_pages`, `pq_lp_runs` (see docs/sql/v25_lp_hygiene.sql to create them by hand).

## Server requests
Only public addresses are fetched (no localhost / private IPs).

## Mobile masking — last 5 digits
Users without **Full mobile numbers on screen / in exports** (Users & Roles → user) now see only the last 5 digits of a
mobile, the rest as stars: `9876543210 → *****43210`, `+91 98765 43210 → *******43210` (before: `98******10`).
One rule, `pqMaskMobile()` in app/Core/db.php, used everywhere:
- Leads list, lead detail, edit lead, follow-ups, Leads Excel export
- Google dashboard lead lists (qualified / walk-in) and their Excel, Taboola leads, Unmapped (Google / Meta), Unmapped Leads, CRM Push (+ CSVs)
- Upload Lead Status (file preview and "not found" examples), Import Leads summary
- LP Hygiene (test values, Graph API requests / responses, form data, CRM replies, history, PDF); the remembered test number is only pre-filled for users who may see full mobiles
Unique-people counts on the dashboards no longer depend on the visible number (`mkey`, a keyed hash of the last 10 digits).
