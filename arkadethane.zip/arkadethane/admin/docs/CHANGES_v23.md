# 1.0.23 Beta — Today and Yesterday on every date filter

- Main date bar (All Platforms, Meta, Google, Taboola, manual platforms, Creatives & Insights, Keyword Analysis):
  **Today · Yesterday** · 7 days · 30 days · This month · Last month · Custom. The choice is remembered and sent to every
  embedded page; a one-day range shows as one date ("28 Oct 2026").
- Manual platform page (OTT Video …), Unmapped Leads: Today and Yesterday added to the period list.
- CRM Push: Yesterday added (Today was there).
- Creatives & Insights and Keyword Analysis opened on their own: Today / Yesterday buttons next to the date boxes.
- Already had both: Meta / Google / Taboola own date pickers, Leads & CRM, Unmapped (Meta / Google), Web Analytics.

"Today" is the day so far — Meta and Google can take a few hours to report today's spend.
Files: public/dashboard.php, public/ads/ottdashboard.php, public/unmapped_leads.php, public/crm_push.php,
public/creatives.php, public/keywords.php. No database change.
