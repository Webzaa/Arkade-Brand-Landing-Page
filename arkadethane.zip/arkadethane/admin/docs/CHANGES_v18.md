# 1.0.18 Beta — changes

No SQL to run. Upload over the existing admin and keep your live `config/config.php`.

- **Opening /admin/ or index.php goes to dashboard.php.** The Leads page still opens inside the dashboard (index.php?embed=1). `index.php?leads=1` opens dashboard.php#leads.
- **Email / mobile masking is done on the server** (Users & Roles switches), so full values no longer reach users who may only see them masked:
  Leads list (`leads/get_records.php`), today's follow-ups, Edit Lead page, old Unmapped page (`ads/unmapped_api.php`, `ads/unmapped_meta_api.php`) and Taboola (`ads/taboolaapi.php`).
  Exports keep using the separate export switches (`mobile_export` / `email_export`).
- Rows now carry an encrypted lead reference (`ref`) instead of the mobile number for Edit / Add Response / History / Test / Junk / Save. Plain mobiles are still accepted.
- **`ads/meta_update_leads.php` needs a signed-in user with Meta access** (it was open to anyone with the URL).
- Fixes:
  - Edit Lead could not be saved (a leftover `return false;` stopped the save).
  - Edit Lead's login redirect went to a page that does not exist (leads/login.php).
  - Name field was `type="email"`; edit values are now HTML-escaped.
  - Unchanged masked email on Edit Lead keeps the saved email.
  - Add Response / History used unsafe SQL (injection); now prepared statements. Add Response updates the lead in its own database.
  - Follow-ups / history text is escaped in the page.
  - index.php and add-lead.php printed HTML before `session_start()` (could cause "headers already sent").
  - Unmapped APIs no longer return SQL text / database errors to the browser.
