# 1.0.21 Beta — campaign choice on every download, roles for the new modules, Keyword Analysis

## 1. "All campaigns or select campaigns?" before every report download
Asked each time (the last choice is pre-filled, never applied silently) — `public/ads/js/report_picker.js`,
campaign list from `public/ads/report_campaigns_api.php` (the project's saved Meta / Google campaigns).

| Where | Download | How the choice is applied |
|---|---|---|
| All Platforms → Reports | Daily / Weekly / Monthly PDF | `email_report_api.php` keeps the chosen campaigns and adds their numbers up again |
| All Platforms → Reports, any dashboard → Export PDF (Meta + Google) | Campaign report PDF | `portfolio_report_api.php?campaigns=meta:ID,google:ID` → `pfPeriod(..., $only)` |
| Meta / Google → Export | Daily / Weekly / Monthly report, Monthly deck (last month / month to date) | `meta|google_performance_report.php?campaigns=ID,ID` (spend + leads of only those campaigns) |
| Meta / Google → Export | Campaign Report (Excel), Analysis Report (Excel) | rows filtered in the page |

The file name and the report header say "Selected campaigns only (n): …". Signed report links (report_view.php) and the
scheduled emails are unchanged (always all campaigns).

## 2. Users & Roles
New modules / rights: **Creatives & Insights** (View, Edit insight rules — was Super Admin only), **Keyword Analysis** (View, Export CSV),
**Taboola** (View — was part of All Platforms; All Platforms still adds Taboola's totals),
**Manual platforms → Set awareness spend**, Meta / Google **Sync campaigns & tag awareness**. The sidebar group is now
"Insights" (Creatives & Insights, Keyword Analysis). Roles saved before this version keep what they could do
(Creatives with Meta or Google view, Keywords with Google view, awareness with manual-platform edit, Taboola with All Platforms view) until they are
saved again in Users & Roles. Without the Reports right the Export menu is hidden and the campaign list API answers 403.

## 3. Keyword Analysis (Google) — `public/keywords.php`, `keywords_api.php`, `app/Ads/keywords.php`
Keywords (keyword_view: impressions, clicks, CTR, CPC, cost, conversions, quality score, running / paused) with CRM leads,
qualified and site visits per keyword (the lead's `keyword` column = Google's {keyword}), and search terms
(search_term_view) marked Keyword / New / Excluded. Insights & Actions: keywords spending without leads, keywords to push,
leads that never qualify, low quality score, search terms to add as negatives / as keywords, leads arriving without a
keyword. Filters, sorting, search, first 50 rows then more on scroll, Export CSV (with the Export right). Cached 10 minutes;
Refresh reads again. Needs the Google Ads API (same config as the Google dashboard). No database change.
