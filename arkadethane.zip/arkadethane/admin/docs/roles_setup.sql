-- Roles & permissions — only needed if the admin's database user can't CREATE / ALTER tables
-- (Users & Roles normally does this by itself on the first visit). Run on the APP_DB database.

ALTER TABLE `users` MODIFY `role` VARCHAR(50) NOT NULL DEFAULT 'admin';

CREATE TABLE IF NOT EXISTS `pq_roles` (
  `role_key`    VARCHAR(50)  NOT NULL,
  `name`        VARCHAR(100) NOT NULL,
  `description` VARCHAR(255) NULL,
  `permissions` TEXT         NULL,
  `is_system`   TINYINT(1)   NOT NULL DEFAULT 0,
  `created_at`  DATETIME     NULL,
  `updated_at`  DATETIME     NULL,
  PRIMARY KEY (`role_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO `pq_roles` (role_key, name, description, permissions, is_system, created_at, updated_at) VALUES
('admin', 'Admin', 'Everything except Users & Roles',
 '{"overview":["view"],"reports":["view"],"meta":["view","sync"],"google":["view","sync"],"manual":["view","edit"],"leads":["view","export","edit"],"unmapped":["view","edit"],"crm":["view"],"status":["view"],"analytics":["view"],"capi":["view"],"import":["view"]}',
 1, NOW(), NOW()),
('viewer', 'Viewer', 'Can see dashboards and leads, cannot change or export anything',
 '{"overview":["view"],"reports":["view"],"meta":["view"],"google":["view"],"manual":["view"],"leads":["view"],"unmapped":["view"],"crm":["view"],"analytics":["view"]}',
 0, NOW(), NOW());
