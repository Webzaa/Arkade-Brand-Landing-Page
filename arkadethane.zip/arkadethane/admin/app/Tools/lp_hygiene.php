<?php
/**
 * app/Tools/lp_hygiene.php — LP Hygiene: is every landing page fast, tracked and actually delivering leads?
 *
 *   PageSpeed   Google PageSpeed Insights (mobile + desktop): Performance / Accessibility / Best Practices / SEO
 *               scores, FCP, LCP, TBT, CLS, Speed Index, the biggest savings and a screenshot.
 *               Optional config: define('PAGESPEED_API_KEY', '…') — without a key Google allows only a few runs.
 *   Page checks The page itself: HTTPS + certificate expiry, load time, title / description / viewport, Meta Pixel,
 *               Google tag / GTM, a lead form with name / email / phone, UTM / gclid / keyword capture, phone and
 *               WhatsApp links, privacy policy, images without alt text.
 *   Test leads  Meta: through the Graph API on a lead form of this project — the form's old test lead is deleted
 *               first (Meta keeps one per form), a new one is created and read back.
 *               Landing page: the page's form is posted the way a visitor would (Google ad source).
 *               Name and email always contain "test" (the dashboards leave such leads out). Then the lead table is
 *               watched: did the lead arrive, and what did the CRM answer?
 *
 * Landing pages and runs are stored in the main database: pq_lp_pages, pq_lp_runs.
 * Server-side requests only go to public addresses (no 127.0.0.1 / 10.x / 192.168.x …) unless LPH_ALLOW_PRIVATE.
 */

require_once dirname(__DIR__) . '/Core/db.php';
require_once dirname(__DIR__) . '/Leads/crm_push.php';   // crmPushResult(): the CRM's answer on a lead
require_once dirname(__DIR__) . '/Leads/crm_sfdc.php';   // pqSettingGet / pqSettingPut (pq_settings)

const LPH_PSI_URL = 'https://www.googleapis.com/pagespeedonline/v5/runPagespeed';
const LPH_GRAPH = 'https://graph.facebook.com';
const LPH_UA = 'Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Mobile Safari/537.36 PerformIQ-LP-Check';

/* ======================================================================
 * Storage
 * ====================================================================== */

function lphDb(): mysqli
{
    static $ready = false;
    $db = leadDb(appDbKey());
    if (!$db) {
        throw new RuntimeException('The main database is not reachable.');
    }
    if (!$ready) {
        $ready = true;
        $db->query("CREATE TABLE IF NOT EXISTS `pq_lp_pages` (
            `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            `name` VARCHAR(120) NOT NULL,
            `url` VARCHAR(500) NOT NULL,
            `form_json` TEXT NULL,
            `created_at` DATETIME NULL,
            `updated_at` DATETIME NULL,
            `updated_by` VARCHAR(100) NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
        $db->query("CREATE TABLE IF NOT EXISTS `pq_lp_runs` (
            `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            `page_id` INT UNSIGNED NOT NULL DEFAULT 0,
            `kind` VARCHAR(20) NOT NULL,
            `ok` TINYINT NOT NULL DEFAULT 0,
            `summary` VARCHAR(255) NULL,
            `result` MEDIUMTEXT NULL,
            `created_at` DATETIME NULL,
            `created_by` VARCHAR(100) NULL,
            KEY `page_kind` (`page_id`, `kind`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    }
    return $db;
}

/** The test mobile number last used (so the team doesn't type it every time). */
function lphTestMobile(?string $set = null, string $user = ''): string
{
    $db = lphDb();
    if ($set !== null) {
        pqSettingPut($db, 'lph_test', ['mobile' => $set], $user);
        return $set;
    }
    return (string) (pqSettingGet($db, 'lph_test')['mobile'] ?? '');
}

/** The project's landing pages; the first time, the site this admin runs on. */
function lphPages(): array
{
    $db = lphDb();
    $out = [];
    $r = $db->query('SELECT id, name, url, form_json, updated_at FROM `pq_lp_pages` ORDER BY id');
    while ($r && ($p = $r->fetch_assoc())) {
        $out[] = ['id' => (int) $p['id'], 'name' => (string) $p['name'], 'url' => (string) $p['url'],
                  'form' => json_decode((string) ($p['form_json'] ?? ''), true) ?: null, 'updated_at' => (string) ($p['updated_at'] ?? '')];
    }
    if (!$out && defined('APP_URL')) {
        $site = preg_replace('#/admin/?$#i', '/', rtrim((string) APP_URL, '/') . '/');
        if (preg_match('#^https?://#i', $site)) {
            lphSavePage(['name' => defined('PROJECT_NAME') ? (string) PROJECT_NAME : 'Landing page', 'url' => $site], 'system');
            return lphPages();
        }
    }
    return $out;
}

function lphPage(int $id): array
{
    foreach (lphPages() as $p) {
        if ($p['id'] === $id) {
            return $p;
        }
    }
    throw new InvalidArgumentException('Unknown landing page.');
}

/** Add (no id) or edit a landing page. $in = {id?, name, url, form?: {endpoint, method, fields: {name, email, mobile}, extra: {k: v}}} */
function lphSavePage(array $in, string $user): array
{
    $name = trim(mb_substr((string) ($in['name'] ?? ''), 0, 120));
    $url = trim((string) ($in['url'] ?? ''));
    if (!preg_match('#^https?://[^\s/]+#i', $url)) {
        throw new InvalidArgumentException('Enter the full page address, starting with https://');
    }
    if ($name === '') {
        $name = (string) parse_url($url, PHP_URL_HOST);
    }
    $form = null;
    if (isset($in['form']) && is_array($in['form'])) {
        $f = $in['form'];
        $form = [
            'endpoint' => trim((string) ($f['endpoint'] ?? '')),
            'method' => strtoupper((string) ($f['method'] ?? 'POST')) === 'GET' ? 'GET' : 'POST',
            'fields' => array_map(fn($v) => trim(mb_substr((string) $v, 0, 80)), array_intersect_key((array) ($f['fields'] ?? []), array_flip(['name', 'email', 'mobile']))),
            'extra' => array_slice(array_map(fn($v) => mb_substr((string) $v, 0, 300), array_filter((array) ($f['extra'] ?? []), fn($k) => is_string($k) && $k !== '', ARRAY_FILTER_USE_KEY)), 0, 40, true),
        ];
        if ($form['endpoint'] !== '' && !preg_match('#^https?://#i', $form['endpoint'])) {
            throw new InvalidArgumentException('The form address must start with https://');
        }
    }
    $db = lphDb();
    $now = date('Y-m-d H:i:s');
    $fj = $form ? json_encode($form, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) : null;
    $id = (int) ($in['id'] ?? 0);
    if ($id > 0) {
        lphPage($id);
        $st = $db->prepare('UPDATE `pq_lp_pages` SET name = ?, url = ?, form_json = COALESCE(?, form_json), updated_at = ?, updated_by = ? WHERE id = ?');
        $st->bind_param('sssssi', $name, $url, $fj, $now, $user, $id);
    } else {
        $st = $db->prepare('INSERT INTO `pq_lp_pages` (name, url, form_json, created_at, updated_at, updated_by) VALUES (?, ?, ?, ?, ?, ?)');
        $st->bind_param('ssssss', $name, $url, $fj, $now, $now, $user);
    }
    if (!$st->execute()) {
        throw new RuntimeException('Could not save the page: ' . $st->error);
    }
    $id = $id ?: lphInsertId($db, $st, 'pq_lp_pages');
    $st->close();
    return ['id' => $id];
}

function lphDeletePage(int $id): void
{
    $db = lphDb();
    $st = $db->prepare('DELETE FROM `pq_lp_pages` WHERE id = ?');
    $st->bind_param('i', $id);
    $st->execute();
    $st = $db->prepare('DELETE FROM `pq_lp_runs` WHERE page_id = ?');
    $st->bind_param('i', $id);
    $st->execute();
}

function lphSaveRun(int $pageId, string $kind, bool $ok, string $summary, array $result, string $user): int
{
    $db = lphDb();
    $json = json_encode($result, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PARTIAL_OUTPUT_ON_ERROR);
    $now = date('Y-m-d H:i:s');
    $okI = $ok ? 1 : 0;
    $summary = mb_substr($summary, 0, 250);
    $st = $db->prepare('INSERT INTO `pq_lp_runs` (page_id, kind, ok, summary, result, created_at, created_by) VALUES (?, ?, ?, ?, ?, ?, ?)');
    if (!$st) {
        throw new RuntimeException('Could not save the result (pq_lp_runs).');
    }
    $st->bind_param('isissss', $pageId, $kind, $okI, $summary, $json, $now, $user);
    if (!$st->execute()) {
        throw new RuntimeException('Could not save the result: ' . $st->error);
    }
    $id = lphInsertId($db, $st, 'pq_lp_runs');
    // keep the last 100 runs per page (PageSpeed results carry a screenshot)
    $q = $db->prepare('SELECT id FROM `pq_lp_runs` WHERE page_id = ? ORDER BY id DESC LIMIT 1 OFFSET 100');
    if ($q) {
        $q->bind_param('i', $pageId);
        $q->execute();
        $old = (int) ($q->get_result()->fetch_assoc()['id'] ?? 0);
        if ($old > 0) {
            $d = $db->prepare('DELETE FROM `pq_lp_runs` WHERE page_id = ? AND id <= ?');
            $d->bind_param('ii', $pageId, $old);
            $d->execute();
        }
    }
    return $id;
}

/** The new row's id (statement first; some drivers only answer through MAX(id)). */
function lphInsertId(mysqli $db, $st, string $table): int
{
    $id = 0;
    try {
        $id = (int) $st->insert_id;
    } catch (Throwable $e) {
    }
    if ($id <= 0) {
        $r = $db->query('SELECT MAX(id) AS id FROM `' . $table . '`');
        $id = (int) ($r ? ($r->fetch_assoc()['id'] ?? 0) : 0);
    }
    return $id;
}

/** Latest run of each kind for a page (+ the last 30 runs as a list). */
function lphRuns(int $pageId): array
{
    $db = lphDb();
    $latest = [];
    $list = [];
    $st = $db->prepare('SELECT id, kind, ok, summary, result, created_at, created_by FROM `pq_lp_runs` WHERE page_id = ? ORDER BY id DESC LIMIT 60');
    $st->bind_param('i', $pageId);
    $st->execute();
    $res = $st->get_result();
    while ($r = $res->fetch_assoc()) {
        $k = (string) $r['kind'];
        if (!isset($latest[$k])) {
            $latest[$k] = ['id' => (int) $r['id'], 'at' => (string) $r['created_at'], 'by' => (string) $r['created_by'],
                           'result' => json_decode((string) $r['result'], true)];
        }
        if (count($list) < 30) {
            $list[] = ['id' => (int) $r['id'], 'kind' => $k, 'ok' => (bool) $r['ok'], 'summary' => (string) $r['summary'],
                       'at' => (string) $r['created_at'], 'by' => (string) $r['created_by']];
        }
    }
    return ['latest' => $latest, 'history' => $list];
}

/* ======================================================================
 * HTTP (public addresses only)
 * ====================================================================== */

function lphPublicUrl(string $url): void
{
    $p = parse_url($url);
    if (!$p || !in_array(strtolower($p['scheme'] ?? ''), ['http', 'https'], true) || empty($p['host'])) {
        throw new InvalidArgumentException('Not a web address: ' . $url);
    }
    if (defined('LPH_ALLOW_PRIVATE') && LPH_ALLOW_PRIVATE) {
        return;
    }
    $host = trim($p['host'], '[]');
    $ips = filter_var($host, FILTER_VALIDATE_IP) ? [$host] : (gethostbynamel($host) ?: []);
    if (!$ips) {
        throw new InvalidArgumentException("The address {$host} could not be found (DNS).");
    }
    foreach ($ips as $ip) {
        if (!filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
            throw new InvalidArgumentException('Only public web addresses can be checked.');
        }
    }
}

/** One request. Returns {code, body, headers (lower-case), time_ms, ttfb_ms, final_url, size, error}. */
function lphHttp(string $method, string $url, array $opt = []): array
{
    lphPublicUrl($url);
    $ch = curl_init();
    $headers = [];
    $o = [
        CURLOPT_URL            => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => $opt['follow'] ?? true,
        CURLOPT_MAXREDIRS      => 5,
        CURLOPT_CONNECTTIMEOUT => 10,
        CURLOPT_TIMEOUT        => $opt['timeout'] ?? 30,
        CURLOPT_USERAGENT      => $opt['ua'] ?? LPH_UA,
        CURLOPT_ENCODING       => '',
        CURLOPT_HTTPHEADER     => $opt['headers'] ?? [],
        CURLOPT_HEADERFUNCTION => function ($ch, $line) use (&$headers) {
            $p = strpos($line, ':');
            if ($p !== false) {
                $headers[strtolower(trim(substr($line, 0, $p)))] = trim(substr($line, $p + 1));
            }
            return strlen($line);
        },
    ];
    if ($method === 'POST') {
        $o[CURLOPT_POST] = true;
        $o[CURLOPT_POSTFIELDS] = $opt['body'] ?? '';
    } elseif ($method !== 'GET') {
        $o[CURLOPT_CUSTOMREQUEST] = $method;
        if (isset($opt['body'])) {
            $o[CURLOPT_POSTFIELDS] = $opt['body'];
        }
    }
    curl_setopt_array($ch, $o);
    $body = curl_exec($ch);
    $out = [
        'code' => (int) curl_getinfo($ch, CURLINFO_HTTP_CODE),
        'body' => $body === false ? '' : (string) $body,
        'headers' => $headers,
        'time_ms' => (int) round(curl_getinfo($ch, CURLINFO_TOTAL_TIME) * 1000),
        'ttfb_ms' => (int) round(curl_getinfo($ch, CURLINFO_STARTTRANSFER_TIME) * 1000),
        'final_url' => (string) curl_getinfo($ch, CURLINFO_EFFECTIVE_URL),
        'redirects' => (int) curl_getinfo($ch, CURLINFO_REDIRECT_COUNT),
        'size' => $body === false ? 0 : strlen((string) $body),
        'error' => $body === false ? curl_error($ch) : '',
    ];
    unset($ch);
    return $out;
}

/* ======================================================================
 * PageSpeed Insights
 * ====================================================================== */

/** One PageSpeed run: {strategy, scores: {performance, accessibility, best-practices, seo, …}, metrics, opportunities, screenshot}. */
function lphPageSpeed(string $url, string $strategy): array
{
    $strategy = $strategy === 'desktop' ? 'desktop' : 'mobile';
    lphPublicUrl($url);
    $q = 'url=' . rawurlencode($url) . '&strategy=' . $strategy;
    foreach (['performance', 'accessibility', 'best-practices', 'seo'] as $c) {
        $q .= '&category=' . $c;
    }
    if (defined('PAGESPEED_API_KEY') && trim((string) PAGESPEED_API_KEY) !== '') {
        $q .= '&key=' . rawurlencode(trim((string) PAGESPEED_API_KEY));
    }
    $ch = curl_init(LPH_PSI_URL . '?' . $q);
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_CONNECTTIMEOUT => 10, CURLOPT_TIMEOUT => 150]);
    $body = curl_exec($ch);
    $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $err = curl_error($ch);
    unset($ch);
    if ($body === false) {
        throw new RuntimeException('PageSpeed could not be reached: ' . $err);
    }
    $j = json_decode((string) $body, true);
    if (!is_array($j) || isset($j['error'])) {
        $m = (string) ($j['error']['message'] ?? "HTTP {$code}");
        if ($code === 429 || stripos($m, 'quota') !== false) {
            $m .= ' — add a free PageSpeed API key in config.php: define(\'PAGESPEED_API_KEY\', \'…\') (Google Cloud → APIs → PageSpeed Insights API).';
        }
        throw new RuntimeException('PageSpeed: ' . $m);
    }
    $lh = $j['lighthouseResult'] ?? [];
    $scores = [];
    foreach ($lh['categories'] ?? [] as $k => $c) {
        $scores[$k] = ['title' => (string) ($c['title'] ?? $k), 'score' => isset($c['score']) ? (int) round($c['score'] * 100) : null];
    }
    $a = $lh['audits'] ?? [];
    $metric = function (string $id) use ($a) {
        $x = $a[$id] ?? null;
        return $x ? ['value' => (string) ($x['displayValue'] ?? ''), 'numeric' => $x['numericValue'] ?? null,
                     'score' => isset($x['score']) ? (float) $x['score'] : null] : null;
    };
    $metrics = [
        'fcp' => ['label' => 'First Contentful Paint'] + ($metric('first-contentful-paint') ?? []),
        'lcp' => ['label' => 'Largest Contentful Paint'] + ($metric('largest-contentful-paint') ?? []),
        'tbt' => ['label' => 'Total Blocking Time'] + ($metric('total-blocking-time') ?? []),
        'cls' => ['label' => 'Cumulative Layout Shift'] + ($metric('cumulative-layout-shift') ?? []),
        'si'  => ['label' => 'Speed Index'] + ($metric('speed-index') ?? []),
    ];
    // biggest savings first: opportunities (ms) and failed diagnostics
    $opps = [];
    foreach ($a as $id => $x) {
        $sav = $x['details']['overallSavingsMs'] ?? ($x['metricSavings']['LCP'] ?? null);
        if (($x['score'] ?? 1) !== null && ($x['score'] ?? 1) < 0.9 && in_array($x['scoreDisplayMode'] ?? '', ['metricSavings', 'numeric', 'binary'], true)
            && !isset($metrics[str_replace(['first-contentful-paint', 'largest-contentful-paint', 'total-blocking-time', 'cumulative-layout-shift', 'speed-index'], ['fcp', 'lcp', 'tbt', 'cls', 'si'], $id)])) {
            $opps[] = ['id' => $id, 'title' => (string) ($x['title'] ?? $id), 'value' => (string) ($x['displayValue'] ?? ''), 'savings_ms' => $sav !== null ? (int) $sav : null];
        }
    }
    usort($opps, fn($p, $q) => ($q['savings_ms'] ?? -1) <=> ($p['savings_ms'] ?? -1));
    $field = $j['loadingExperience']['overall_category'] ?? null;   // real-user data (Chrome UX report), when Google has it
    return [
        'strategy' => $strategy, 'url' => (string) ($lh['finalUrl'] ?? $lh['finalDisplayedUrl'] ?? $url),
        'fetched_at' => (string) ($lh['fetchTime'] ?? date('c')), 'lighthouse' => (string) ($lh['lighthouseVersion'] ?? ''),
        'scores' => $scores, 'metrics' => $metrics, 'opportunities' => array_slice($opps, 0, 8),
        'field' => $field, 'screenshot' => (string) ($a['final-screenshot']['details']['data'] ?? ''),
    ];
}

/* ======================================================================
 * Page checks + form detection
 * ====================================================================== */

function lphSslExpiry(string $host): ?array
{
    $ctx = stream_context_create(['ssl' => ['capture_peer_cert' => true, 'verify_peer' => false, 'verify_peer_name' => false, 'SNI_enabled' => true, 'peer_name' => $host]]);
    $c = @stream_socket_client('ssl://' . $host . ':443', $en, $es, 8, STREAM_CLIENT_CONNECT, $ctx);
    if (!$c) {
        return null;
    }
    $cert = stream_context_get_params($c)['options']['ssl']['peer_certificate'] ?? null;
    fclose($c);
    $info = $cert ? openssl_x509_parse($cert) : null;
    if (!$info || empty($info['validTo_time_t'])) {
        return null;
    }
    return ['expires' => date('Y-m-d', (int) $info['validTo_time_t']), 'days' => (int) floor(((int) $info['validTo_time_t'] - time()) / 86400),
            'issuer' => (string) ($info['issuer']['O'] ?? $info['issuer']['CN'] ?? '')];
}

/** The lead forms on a page: [{action, method, fields: [{name, type, value, label}], map: {name, email, mobile}, hidden: {…}}] */
function lphForms(string $html, string $baseUrl): array
{
    if (trim($html) === '') {
        return [];
    }
    $doc = new DOMDocument();
    libxml_use_internal_errors(true);
    $doc->loadHTML('<?xml encoding="utf-8"?>' . $html);
    libxml_clear_errors();
    $out = [];
    foreach ($doc->getElementsByTagName('form') as $form) {
        $fields = [];
        foreach (['input', 'select', 'textarea'] as $tag) {
            foreach ($form->getElementsByTagName($tag) as $el) {
                $name = trim($el->getAttribute('name'));
                if ($name === '') {
                    continue;
                }
                $type = $tag === 'input' ? strtolower($el->getAttribute('type') ?: 'text') : $tag;
                if (in_array($type, ['submit', 'button', 'image', 'reset', 'file'], true)) {
                    continue;
                }
                $value = $el->getAttribute('value');
                if ($tag === 'select') {
                    foreach ($el->getElementsByTagName('option') as $op) {
                        $v = $op->hasAttribute('value') ? $op->getAttribute('value') : trim($op->textContent);
                        if ($v !== '') { $value = $v; break; }
                    }
                }
                $fields[] = ['name' => $name, 'type' => $type, 'value' => (string) $value,
                             'label' => trim($el->getAttribute('placeholder') ?: $el->getAttribute('aria-label') ?: $el->getAttribute('id'))];
            }
        }
        if (!$fields) {
            continue;
        }
        $pick = function (string $re, array $types = []) use ($fields) {
            foreach ($fields as $f) {
                if (($types && in_array($f['type'], $types, true)) || preg_match($re, $f['name'] . ' ' . $f['label'])) {
                    if (!in_array($f['type'], ['hidden', 'checkbox', 'radio'], true)) {
                        return $f['name'];
                    }
                }
            }
            return '';
        };
        $map = [
            'email' => $pick('/e-?mail/i', ['email']),
            'mobile' => $pick('/phone|mobile|contact|number|\btel\b/i', ['tel']),
        ];
        $map['name'] = $pick('/(^|[^a-z])(full_?name|name|fname|first_?name)([^a-z]|$)|your name/i');
        $hidden = [];
        foreach ($fields as $f) {
            if (!in_array($f['name'], $map, true)) {
                $hidden[$f['name']] = $f['value'];
            }
        }
        $action = trim($form->getAttribute('action'));
        $out[] = ['action' => $action === '' ? $baseUrl : lphAbsUrl($action, $baseUrl), 'action_empty' => $action === '',
                  'method' => strtoupper($form->getAttribute('method') ?: 'GET') === 'POST' ? 'POST' : 'GET',
                  'id' => $form->getAttribute('id'), 'fields' => $fields, 'map' => $map, 'hidden' => $hidden,
                  'is_lead_form' => $map['mobile'] !== '' || $map['email'] !== ''];
    }
    usort($out, fn($a, $b) => $b['is_lead_form'] <=> $a['is_lead_form']);
    return $out;
}

function lphAbsUrl(string $href, string $base): string
{
    if (preg_match('#^https?://#i', $href)) {
        return $href;
    }
    $b = parse_url($base);
    $root = ($b['scheme'] ?? 'https') . '://' . ($b['host'] ?? '') . (isset($b['port']) ? ':' . $b['port'] : '');
    if (str_starts_with($href, '//')) {
        return ($b['scheme'] ?? 'https') . ':' . $href;
    }
    if (str_starts_with($href, '/')) {
        return $root . $href;
    }
    $dir = preg_replace('#/[^/]*$#', '/', $b['path'] ?? '/');
    return $root . $dir . $href;
}

/** Form handlers named in the page's scripts (AJAX forms): ['https://…/mail.php', …] */
function lphScriptEndpoints(string $html, string $base): array
{
    $out = [];
    if (preg_match_all('#(?:url\s*:\s*|fetch\(\s*|\.post\(\s*|action\s*=\s*|open\(\s*["\']POST["\']\s*,\s*)["\']([^"\']+\.(?:php|aspx?|jsp)[^"\']*)["\']#i', $html, $m)) {
        foreach ($m[1] as $u) {
            $out[lphAbsUrl($u, $base)] = true;
        }
    }
    return array_keys(array_slice($out, 0, 6, true));
}

/** Page checks: [{key, label, status: pass|warn|fail|info, detail}], plus the detected forms. */
function lphScan(string $url): array
{
    $r = lphHttp('GET', $url, ['timeout' => 30]);
    $checks = [];
    $add = function (string $key, string $label, string $status, string $detail) use (&$checks) {
        $checks[] = compact('key', 'label', 'status', 'detail');
    };
    if ($r['error'] !== '' || $r['code'] === 0) {
        $add('reach', 'Page opens', 'fail', 'The page did not answer: ' . ($r['error'] ?: 'no response') . '.');
        return ['checks' => $checks, 'forms' => [], 'endpoints' => [], 'http' => ['code' => 0, 'final_url' => $url]];
    }
    $final = $r['final_url'] ?: $url;
    $html = $r['body'];
    $add('reach', 'Page opens', $r['code'] >= 200 && $r['code'] < 300 ? 'pass' : 'fail',
         "HTTP {$r['code']}" . ($r['redirects'] ? " after {$r['redirects']} redirect(s) → {$final}" : '') . '.');
    $https = str_starts_with(strtolower($final), 'https://');
    $add('https', 'HTTPS', $https ? 'pass' : 'fail', $https ? 'The page is served over HTTPS.' : 'The page is not on HTTPS — browsers mark the form "Not secure".');
    if ($https) {
        $ssl = lphSslExpiry((string) parse_url($final, PHP_URL_HOST));
        if ($ssl) {
            $add('ssl', 'SSL certificate', $ssl['days'] < 0 ? 'fail' : ($ssl['days'] < 15 ? 'warn' : 'pass'),
                 ($ssl['days'] < 0 ? 'Expired on ' : 'Valid until ') . $ssl['expires'] . " ({$ssl['days']} days" . ($ssl['issuer'] ? ', ' . $ssl['issuer'] : '') . ').');
        }
    }
    $add('speed', 'Server response', $r['ttfb_ms'] <= 800 ? 'pass' : ($r['ttfb_ms'] <= 1800 ? 'warn' : 'fail'),
         "First byte in {$r['ttfb_ms']} ms, full HTML in {$r['time_ms']} ms (" . round($r['size'] / 1024) . ' KB).');

    $has = fn(string $re) => (bool) preg_match($re, $html);
    $grab = function (string $re) use ($html) { return preg_match($re, $html, $m) ? html_entity_decode(trim($m[1]), ENT_QUOTES) : ''; };
    $title = $grab('#<title[^>]*>(.*?)</title>#is');
    $add('title', 'Page title', $title === '' ? 'fail' : (mb_strlen($title) > 65 ? 'warn' : 'pass'), $title === '' ? 'No <title>.' : '“' . mb_substr($title, 0, 90) . '” (' . mb_strlen($title) . ' characters).');
    $desc = $grab('#<meta[^>]+name=["\']description["\'][^>]*content=["\']([^"\']*)#i') ?: $grab('#<meta[^>]+content=["\']([^"\']*)["\'][^>]*name=["\']description#i');
    $add('desc', 'Meta description', $desc === '' ? 'warn' : 'pass', $desc === '' ? 'No meta description.' : mb_substr($desc, 0, 140));
    $add('viewport', 'Mobile viewport', $has('#<meta[^>]+name=["\']viewport#i') ? 'pass' : 'fail', $has('#<meta[^>]+name=["\']viewport#i') ? 'Set — the page scales on phones.' : 'Missing — the page shows tiny on phones.');
    $noindex = $has('#<meta[^>]+name=["\']robots["\'][^>]*noindex#i') || stripos((string) ($r['headers']['x-robots-tag'] ?? ''), 'noindex') !== false;
    $add('robots', 'Search indexing', 'info', $noindex ? 'noindex — the page is kept out of Google search (normal for ad landing pages).' : 'Indexable by search engines.');

    // tracking
    preg_match_all("#fbq\(\s*['\"]init['\"]\s*,\s*['\"]?(\d{8,20})#", $html, $px);
    $pixels = array_values(array_unique($px[1] ?? []));
    $add('pixel', 'Meta Pixel', $pixels ? 'pass' : 'warn', $pixels ? 'Pixel ' . implode(', ', $pixels) . ' on the page.' : 'No Meta Pixel found in the HTML (it may come through Google Tag Manager).');
    preg_match_all('#\b(GTM-[A-Z0-9]{4,9})\b#', $html, $gtm);
    preg_match_all('#\b(AW-\d{6,12})\b#', $html, $aw);
    preg_match_all('#\b(G-[A-Z0-9]{6,12})\b#', $html, $ga);
    $tags = array_values(array_unique(array_merge($gtm[1] ?? [], $aw[1] ?? [], $ga[1] ?? [])));
    $add('gtag', 'Google tag / Tag Manager', $tags ? 'pass' : 'warn', $tags ? implode(', ', $tags) : 'No GTM, Google Ads (AW-) or GA4 (G-) tag found in the HTML.');
    $add('conv', 'Google Ads conversion', ($aw[1] ?? []) || ($gtm[1] ?? []) ? 'pass' : 'warn',
         ($aw[1] ?? []) ? 'Google Ads tag ' . implode(', ', array_unique($aw[1])) . ' found.' : (($gtm[1] ?? []) ? 'Through Google Tag Manager (check the conversion tag fires on submit).' : 'No Google Ads conversion tag found.'));

    // forms
    $forms = lphForms($html, $final);
    $lead = array_values(array_filter($forms, fn($f) => $f['is_lead_form']));
    if (!$lead) {
        $add('form', 'Lead form', 'fail', $forms ? 'Forms found, but none with an email or phone field.' : 'No form found in the HTML (it may be loaded by JavaScript or in a pop-up).');
    } else {
        $f = $lead[0];
        $miss = array_keys(array_filter($f['map'], fn($v) => $v === ''));
        $add('form', 'Lead form', $miss ? 'warn' : 'pass', count($lead) . ' lead form(s). First: name “' . ($f['map']['name'] ?: '—') . '”, email “' . ($f['map']['email'] ?: '—') . '”, phone “' . ($f['map']['mobile'] ?: '—') . '”'
            . ($miss ? ' — no ' . implode(' / ', $miss) . ' field found.' : '.'));
        $names = strtolower(implode(' ', array_column($f['fields'], 'name')));
        $utm = array_values(array_filter(['utm_source', 'utm_medium', 'utm_campaign', 'utm_term', 'utm_content'], fn($k) => str_contains($names, $k)));
        $add('utm', 'UTM capture', count($utm) >= 3 ? 'pass' : (count($utm) ? 'warn' : 'fail'), $utm ? 'Form carries ' . implode(', ', $utm) . '.' : 'No utm_* fields in the form — leads lose their campaign (they end up in Unmapped Leads).');
        $add('gclid', 'gclid / keyword capture', str_contains($names, 'gclid') ? (str_contains($names, 'keyword') || str_contains($names, 'utm_term') ? 'pass' : 'warn') : 'warn',
             (str_contains($names, 'gclid') ? 'gclid captured' : 'No gclid field') . ' · ' . (str_contains($names, 'keyword') || str_contains($names, 'utm_term') ? 'keyword captured.' : 'no keyword / utm_term field (Keyword Analysis needs it).'));
    }
    $endpoints = lphScriptEndpoints($html, $final);

    // contact + trust
    $tel = $has('#href=["\']tel:#i');
    $wa = $has('#(wa\.me/|api\.whatsapp\.com/|whatsapp://)#i');
    $add('contact', 'Call / WhatsApp buttons', $tel || $wa ? 'pass' : 'warn', ($tel ? 'Click-to-call link' : 'No click-to-call link') . ' · ' . ($wa ? 'WhatsApp link.' : 'no WhatsApp link.'));
    $add('privacy', 'Privacy policy', $has('#privacy#i') ? 'pass' : 'warn', $has('#privacy#i') ? 'A privacy policy is linked (Meta and Google ask for one).' : 'No privacy policy link found — ad platforms can reject the ads.');
    preg_match_all('#<img\b[^>]*>#i', $html, $imgs);
    $noAlt = count(array_filter($imgs[0] ?? [], fn($t) => !preg_match('#\salt=["\'][^"\']+#i', $t)));
    $add('alt', 'Image alt text', $noAlt === 0 ? 'pass' : ($noAlt <= 3 ? 'warn' : 'fail'), count($imgs[0] ?? []) . ' images, ' . $noAlt . ' without alt text.');
    $add('favicon', 'Favicon', $has('#rel=["\'][^"\']*icon#i') ? 'pass' : 'warn', $has('#rel=["\'][^"\']*icon#i') ? 'Set.' : 'No favicon — the browser tab shows a blank icon.');
    $add('og', 'Share preview (Open Graph)', $has('#property=["\']og:image#i') ? 'pass' : 'info', $has('#property=["\']og:image#i') ? 'og:image set — WhatsApp / social shares show a preview.' : 'No og:image — a shared link shows no picture.');

    return ['checks' => $checks, 'forms' => array_slice($forms, 0, 4), 'endpoints' => $endpoints,
            'http' => ['code' => $r['code'], 'final_url' => $final, 'ttfb_ms' => $r['ttfb_ms'], 'time_ms' => $r['time_ms'], 'size' => $r['size']]];
}

/* ======================================================================
 * Test leads
 * ====================================================================== */

/** Default test values. Name and email always contain "test" (the dashboards and reports leave such leads out). */
function lphTestValues(string $who, string $mobile): array
{
    $stamp = date('dHi');
    $who = 'PerformIQ';   // one recognisable name for every test lead
    $mobile = preg_replace('/\D+/', '', $mobile);
    if (strlen($mobile) > 10) {
        $mobile = substr($mobile, -10);
    }
    return ['name' => 'Test ' . trim($who) . ' ' . $stamp, 'email' => 'test.performiq.' . date('YmdHis') . '@webzaa.in', 'mobile' => $mobile];
}

/** Name / email must contain "test"; mobile 10 digits. */
function lphCheckValues(array $v): array
{
    $name = trim((string) ($v['name'] ?? ''));
    $email = trim((string) ($v['email'] ?? ''));
    $mobile = preg_replace('/\D+/', '', (string) ($v['mobile'] ?? ''));
    if (strlen($mobile) > 10) {
        $mobile = substr($mobile, -10);
    }
    if (stripos($name, 'test') === false) {
        throw new InvalidArgumentException('The name must contain “test”, so the lead is not counted as a real one.');
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL) || stripos($email, 'test') === false) {
        throw new InvalidArgumentException('Enter an email that contains “test”, e.g. test.team@webzaa.in.');
    }
    if (!preg_match('/^[6-9]\d{9}$/', $mobile)) {
        throw new InvalidArgumentException('Enter a 10-digit Indian mobile number (a team member\'s — the CRM may call or SMS it).');
    }
    return ['name' => mb_substr($name, 0, 80), 'email' => $email, 'mobile' => $mobile];
}

/* ---------- Meta Graph API ---------- */

function lphGraphVersion(): string
{
    $v = trim((string) (defined('META_API_VERSION') ? META_API_VERSION : 'v23.0'));
    return ($v !== '' && $v[0] !== 'v') ? 'v' . $v : $v;
}

/** A Graph call; the access token is never part of what is returned. */
function lphGraph(string $method, string $path, array $params, string $token): array
{
    $url = LPH_GRAPH . '/' . lphGraphVersion() . '/' . ltrim($path, '/');
    $shown = $params;
    $params['access_token'] = $token;
    $ch = curl_init();
    $opt = [CURLOPT_RETURNTRANSFER => true, CURLOPT_CONNECTTIMEOUT => 10, CURLOPT_TIMEOUT => 45];
    if ($method === 'GET') {
        $opt[CURLOPT_URL] = $url . '?' . http_build_query($params);
    } else {
        $opt[CURLOPT_URL] = $url;
        $opt[CURLOPT_CUSTOMREQUEST] = $method;
        $opt[CURLOPT_POSTFIELDS] = http_build_query($params);
    }
    curl_setopt_array($ch, $opt);
    $body = curl_exec($ch);
    $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $err = curl_error($ch);
    unset($ch);
    $json = json_decode((string) $body, true);
    $ok = $body !== false && $code >= 200 && $code < 300 && is_array($json) && !isset($json['error']);
    return ['ok' => $ok, 'method' => $method, 'path' => '/' . lphGraphVersion() . '/' . ltrim($path, '/'), 'params' => $shown,
            'http' => $code, 'response' => is_array($json) ? $json : ($body === false ? ['network_error' => $err] : ['raw' => mb_substr((string) $body, 0, 500)]),
            'error' => $ok ? '' : (string) ($json['error']['message'] ?? ($err ?: "HTTP {$code}"))];
}

function lphMetaToken(): string
{
    return trim((string) (defined('META_ACCESS_TOKEN') ? META_ACCESS_TOKEN : ''));
}

/** Page access token (lead forms and test leads need one). */
function lphPageToken(string $pageId, array &$steps): string
{
    static $cache = [];
    if (isset($cache[$pageId])) {
        return $cache[$pageId];
    }
    if (defined('META_PAGE_ACCESS_TOKEN') && trim((string) META_PAGE_ACCESS_TOKEN) !== '') {
        return $cache[$pageId] = trim((string) META_PAGE_ACCESS_TOKEN);
    }
    $r = lphGraph('GET', $pageId, ['fields' => 'id,name,access_token'], lphMetaToken());
    $tok = (string) ($r['response']['access_token'] ?? '');
    unset($r['response']['access_token']);
    $r['note'] = $tok !== '' ? 'Page access token received (not shown).' : 'No page token — using the account token.';
    $steps[] = ['step' => 'Page token', 'call' => $r];
    return $cache[$pageId] = ($tok !== '' ? $tok : lphMetaToken());
}

/** This project's Meta lead forms: from the leads in the lead table (+ name / status from Meta, cached a day). */
function lphMetaForms(): array
{
    $forms = [];
    foreach (leadDbs('all') as $key => $db) {
        $r = $db->query("SELECT TRIM(form_id) AS form_id, TRIM(page_id) AS page_id, COUNT(*) AS n, MAX(createddate) AS last
                         FROM `lead` WHERE form_id IS NOT NULL AND TRIM(form_id) <> '' AND TRIM(form_id) REGEXP '^[0-9]+$'
                         GROUP BY TRIM(form_id), TRIM(page_id)");
        if (!$r) {   // databases without REGEXP: filter in PHP
            $r = $db->query("SELECT TRIM(form_id) AS form_id, TRIM(page_id) AS page_id, COUNT(*) AS n, MAX(createddate) AS last
                             FROM `lead` WHERE form_id IS NOT NULL AND TRIM(form_id) <> '' GROUP BY TRIM(form_id), TRIM(page_id)");
        }
        while ($r && ($x = $r->fetch_assoc())) {
            $fid = (string) $x['form_id'];
            if (!ctype_digit($fid)) {
                continue;
            }
            $f = &$forms[$fid];
            $f ??= ['id' => $fid, 'page_id' => '', 'leads' => 0, 'last' => '', 'name' => '', 'status' => ''];
            $f['page_id'] = $f['page_id'] ?: (ctype_digit((string) $x['page_id']) ? (string) $x['page_id'] : '');
            $f['leads'] += (int) $x['n'];
            $f['last'] = max($f['last'], (string) $x['last']);
            unset($f);
        }
    }
    uasort($forms, fn($a, $b) => strcmp($b['last'], $a['last']));
    $forms = array_slice($forms, 0, 40, true);
    // names from Meta (one call per page, cached)
    $cacheFile = (defined('CACHE_PATH') ? CACHE_PATH : sys_get_temp_dir()) . '/lph_forms_' . md5(implode(',', array_keys($forms))) . '.json';
    $names = is_file($cacheFile) && filemtime($cacheFile) > time() - 86400 ? (json_decode((string) file_get_contents($cacheFile), true) ?: []) : null;
    if ($names === null && lphMetaToken() !== '') {
        $names = [];
        $steps = [];
        foreach (array_unique(array_filter(array_column($forms, 'page_id'))) as $pid) {
            $tok = lphPageToken($pid, $steps);
            $r = lphGraph('GET', $pid . '/leadgen_forms', ['fields' => 'id,name,status,leads_count', 'limit' => 100], $tok);
            foreach ($r['response']['data'] ?? [] as $x) {
                $names[(string) $x['id']] = ['name' => (string) ($x['name'] ?? ''), 'status' => (string) ($x['status'] ?? '')];
            }
        }
        @file_put_contents($cacheFile, json_encode($names));
    }
    foreach ($forms as $id => &$f) {
        $f['name'] = $names[$id]['name'] ?? '';
        $f['status'] = $names[$id]['status'] ?? '';
    }
    unset($f);
    return array_values($forms);
}

/** field_data for a test lead from the form's questions. */
function lphFieldData(array $questions, array $v): array
{
    [$first, $last] = array_pad(explode(' ', $v['name'], 2), 2, 'Lead');
    $out = [];
    foreach ($questions as $q) {
        $key = (string) ($q['key'] ?? '');
        if ($key === '') {
            continue;
        }
        $type = strtoupper((string) ($q['type'] ?? 'CUSTOM'));
        $val = match ($type) {
            'FULL_NAME' => $v['name'],
            'FIRST_NAME' => $first,
            'LAST_NAME' => $last,
            'EMAIL', 'WORK_EMAIL' => $v['email'],
            'PHONE', 'WORK_PHONE_NUMBER' => '+91' . $v['mobile'],
            'CITY' => 'Test City',
            'ZIP', 'POST_CODE' => '560001',
            'COMPANY_NAME' => 'Test Company',
            default => null,
        };
        if ($val === null) {
            $opts = $q['options'] ?? [];
            $val = $opts ? (string) ($opts[0]['value'] ?? $opts[0]['key'] ?? 'test') : 'test';
        }
        $out[] = ['name' => $key, 'values' => [$val]];
    }
    if (!$out) {   // form questions not readable: the standard three
        $out = [['name' => 'full_name', 'values' => [$v['name']]], ['name' => 'email', 'values' => [$v['email']]], ['name' => 'phone_number', 'values' => ['+91' . $v['mobile']]]];
    }
    return $out;
}

/**
 * Meta test lead: 1. page token 2. form questions 3. delete the form's existing test lead(s) 4. create one 5. read it back.
 * Returns {ok, values, lead_id, steps: [{step, call}], lead}.
 */
function lphMetaTest(string $formId, string $pageId, array $values): array
{
    if (!ctype_digit($formId)) {
        throw new InvalidArgumentException('Choose a lead form.');
    }
    if (lphMetaToken() === '') {
        throw new RuntimeException('META_ACCESS_TOKEN is not set in config.php.');
    }
    $v = lphCheckValues($values);
    $steps = [];
    $tok = $pageId !== '' && ctype_digit($pageId) ? lphPageToken($pageId, $steps) : lphMetaToken();

    $q = lphGraph('GET', $formId, ['fields' => 'id,name,status,questions{key,label,type,options}'], $tok);
    $steps[] = ['step' => 'Read the form', 'call' => $q];
    $form = $q['ok'] ? $q['response'] : [];

    $old = lphGraph('GET', $formId . '/test_leads', ['fields' => 'id,created_time'], $tok);
    $steps[] = ['step' => 'Find old test leads', 'call' => $old];
    $deleted = 0;
    foreach ($old['response']['data'] ?? [] as $x) {
        $d = lphGraph('DELETE', (string) $x['id'], [], $tok);
        $steps[] = ['step' => 'Delete old test lead ' . $x['id'], 'call' => $d];
        $deleted += $d['ok'] ? 1 : 0;
    }

    $fd = lphFieldData($form['questions'] ?? [], $v);
    $c = lphGraph('POST', $formId . '/test_leads', ['field_data' => json_encode($fd, JSON_UNESCAPED_UNICODE)], $tok);
    $steps[] = ['step' => 'Create test lead', 'call' => $c];
    $leadId = (string) ($c['response']['id'] ?? '');
    $lead = null;
    if ($leadId !== '') {
        $g = lphGraph('GET', $leadId, ['fields' => 'id,created_time,form_id,field_data,is_organic,platform'], $tok);
        $steps[] = ['step' => 'Read the test lead back', 'call' => $g];
        $lead = $g['ok'] ? $g['response'] : null;
    }
    return ['ok' => $leadId !== '', 'form' => ['id' => $formId, 'name' => (string) ($form['name'] ?? ''), 'status' => (string) ($form['status'] ?? ''), 'page_id' => $pageId],
            'values' => $v, 'lead_id' => $leadId, 'deleted' => $deleted, 'lead' => $lead, 'steps' => $steps, 'sent_at' => date('Y-m-d H:i:s'),
            'error' => $leadId === '' ? ($c['error'] ?: 'Meta did not return a lead ID.') : ''];
}

/* ---------- Landing page form ---------- */

/** Posts the landing page's form with the test values (as a Google ad visitor). */
function lphLpTest(array $page, array $values, array $formIn): array
{
    $v = lphCheckValues($values);
    $f = $formIn + ($page['form'] ?? []);
    $endpoint = trim((string) ($f['endpoint'] ?? ''));
    $map = (array) ($f['fields'] ?? []);
    if ($endpoint === '' || empty($map['mobile'])) {
        throw new InvalidArgumentException('Detect the form first (Page checks), or enter the form address and the phone field name.');
    }
    $data = [];
    foreach ((array) ($f['extra'] ?? []) as $k => $val) {
        $data[(string) $k] = (string) $val;
    }
    // a Google ad visit: UTMs, gclid, keyword — only into fields the form has
    $sim = ['utm_source' => 'google', 'utm_medium' => 'cpc', 'utm_campaign' => 'PerformIQ test', 'utm_term' => 'test keyword', 'utm_content' => 'test',
            'gclid' => 'TEST-' . date('YmdHis'), 'keyword' => 'test keyword', 'campaignsource' => 'Google'];
    foreach ($sim as $k => $val) {
        foreach (array_keys($data) as $have) {
            if (strcasecmp($have, $k) === 0 && trim($data[$have]) === '') {
                $data[$have] = $val;
            }
        }
    }
    if (!empty($map['name'])) {
        $data[$map['name']] = $v['name'];
    }
    if (!empty($map['email'])) {
        $data[$map['email']] = $v['email'];
    }
    $data[$map['mobile']] = $v['mobile'];
    $method = strtoupper((string) ($f['method'] ?? 'POST')) === 'GET' ? 'GET' : 'POST';
    $url = $endpoint;
    $body = http_build_query($data);
    if ($method === 'GET') {
        $url .= (str_contains($url, '?') ? '&' : '?') . $body;
    }
    $r = lphHttp($method, $url, ['body' => $body, 'timeout' => 45, 'follow' => true,
        'headers' => ['Content-Type: application/x-www-form-urlencoded', 'Referer: ' . $page['url'], 'Origin: ' . preg_replace('#^(https?://[^/]+).*$#', '$1', $page['url']), 'X-Requested-With: XMLHttpRequest']]);
    $text = trim(preg_replace('/\s+/', ' ', strip_tags($r['body'])));
    return ['ok' => $r['code'] >= 200 && $r['code'] < 400 && $r['error'] === '', 'values' => $v, 'endpoint' => $endpoint, 'method' => $method,
            'sent' => $data, 'http' => $r['code'], 'time_ms' => $r['time_ms'], 'final_url' => $r['final_url'],
            'response' => mb_substr($r['body'], 0, 3000), 'response_text' => mb_substr($text, 0, 400), 'sent_at' => date('Y-m-d H:i:s'),
            'error' => $r['error']];
}

/* ---------- did it arrive? ---------- */

/** Leads with this email / mobile / leadgen ID created since $since, in every lead database, with the CRM's answer. */
function lphFindLead(string $since, string $email, string $mobile, string $leadgenId): array
{
    $out = lphFindLeadBy($since, $email, '', $leadgenId);   // the exact test lead first
    if ($out || strlen(preg_replace('/\D+/', '', $mobile)) < 10) {
        return $out;
    }
    return lphFindLeadBy($since, '', $mobile, '');            // the handler saved no email: by the team's number
}

function lphFindLeadBy(string $since, string $email, string $mobile, string $leadgenId): array
{
    $out = [];
    $mobile = preg_replace('/\D+/', '', $mobile);
    foreach (leadDbs('all') as $key => $db) {
        $where = [];
        $types = 's';
        $args = [$since];
        if ($leadgenId !== '') {
            $where[] = 'leadgen_id = ?';
            $types .= 's';
            $args[] = $leadgenId;
        }
        if ($email !== '') {
            $where[] = 'email = ?';
            $types .= 's';
            $args[] = $email;
        }
        if (strlen($mobile) >= 10) {   // the team's number: only on leads that are marked as tests
            $where[] = "(mobile LIKE ? AND (name LIKE '%test%' OR email LIKE '%test%'))";
            $types .= 's';
            $args[] = '%' . substr($mobile, -10);
        }
        if (!$where) {
            continue;
        }
        $st = $db->prepare('SELECT id, name, email, mobile, campaignsource, campaign_name, utm_campaignname, leadgen_id, form_id, gclid, keyword, createddate, curlresponse
                            FROM `lead` WHERE createddate >= ? AND (' . implode(' OR ', $where) . ') ORDER BY id DESC LIMIT 5');
        if (!$st) {
            continue;
        }
        $st->bind_param($types, ...$args);
        $st->execute();
        $res = $st->get_result();
        while ($l = $res->fetch_assoc()) {
            $crm = crmPushResult($l['curlresponse'] ?? null);
            $out[] = ['db' => leadDbLabel($key), 'id' => (int) $l['id'], 'name' => (string) $l['name'], 'email' => pqContact($l['email'], 'email'), 'mobile' => pqContact($l['mobile'], 'mobile'),   // Users & Roles on-screen rule
                     
                      'source' => (string) $l['campaignsource'], 'campaign' => (string) ($l['campaign_name'] ?: $l['utm_campaignname']),
                      'leadgen_id' => (string) $l['leadgen_id'], 'form_id' => (string) $l['form_id'], 'gclid' => (string) $l['gclid'], 'keyword' => (string) $l['keyword'],
                      'created' => (string) $l['createddate'], 'crm' => $crm, 'crm_raw' => mb_substr((string) ($l['curlresponse'] ?? ''), 0, 600)];
        }
        $st->close();
    }
    return $out;
}
