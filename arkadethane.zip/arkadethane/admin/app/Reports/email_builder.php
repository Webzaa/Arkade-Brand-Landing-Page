<?php
declare(strict_types=1);
/**
 * app/Reports/email_builder.php — builds the daily / weekly / monthly report emails (HTML).
 *
 * Shared by cron/send_performance_reports.php (sends them) and public/ads/email_report_api.php
 * (Reports → Daily / Weekly / Monthly PDF on All Platforms), so the PDF is exactly the email.
 * Data comes from public/ads/meta_performance_report.php and google_performance_report.php.
 */

const SR_ENDPOINTS = [
    'meta' => 'meta_performance_report.php',
    'google' => 'google_performance_report.php',
];
const SR_PLATFORM_NAME = ['meta' => 'Meta Ads', 'google' => 'Google Ads', 'combined' => 'Meta + Google Ads'];
const SR_DAILY_CAMPAIGN_LIMIT = 20;

/* ======================================================================
 * Helpers
 * ====================================================================== */
function srLog(string $msg): void
{
    if (PHP_SAPI === 'cli' && defined('STDERR')) {
        fwrite(STDERR, '[' . date('Y-m-d H:i:s') . '] ' . $msg . PHP_EOL);
    } else {
        error_log('[reports] ' . $msg);
    }
}

function srEsc(string $s): string
{
    return htmlspecialchars($s, ENT_QUOTES | ENT_HTML5, 'UTF-8');
}

/** Indian digit grouping: 12,34,567 */
function srIndian(float $n, int $dp = 0): string
{
    $neg = $n < 0;
    $s = number_format(abs($n), $dp, '.', '');
    [$int, $dec] = array_pad(explode('.', $s), 2, '');
    if (strlen($int) > 3) {
        $last3 = substr($int, -3);
        $rest = substr($int, 0, -3);
        $rest = preg_replace('/\B(?=(\d{2})+(?!\d))/', ',', $rest) ?? $rest;
        $int = $rest . ',' . $last3;
    }
    return ($neg ? '-' : '') . $int . ($dp > 0 ? '.' . $dec : '');
}

function srFmt(string $metric, $v): string
{
    if ($v === null || $v === '') {
        return '—';
    }
    $v = (float) $v;
    return match ($metric) {
        'spend', 'cpl', 'cpql', 'cpsv' => '₹' . srIndian($v, 0),
        'cpc' => '₹' . srIndian($v, 2),
        'ctr' => number_format($v, 2) . '%',
        default => srIndian($v, 0),
    };
}

/** [text, colour] for a % change; $better = up|down|neutral */
function srChange($pct, string $better): array
{
    if ($pct === null) {
        return ['n/a', '#64748b'];
    }
    $p = (float) $pct;
    $arrow = $p > 0 ? '▲' : ($p < 0 ? '▼' : '■');
    $text = $arrow . ' ' . number_format(abs($p), 1) . '%';
    if ($p == 0.0 || $better === 'neutral') {
        return [$text, '#64748b'];
    }
    $good = $better === 'up' ? $p > 0 : $p < 0;
    return [$text, $good ? '#047857' : '#b91c1c'];
}

/** Runs the report endpoint in a separate PHP process and returns its JSON. */
function srFetchReport(string $platform, string $period, string $asOf): array
{
    $file = PUBLIC_PATH . '/ads/' . SR_ENDPOINTS[$platform];
    $cmd = escapeshellarg(PHP_BINARY) . ' -d display_errors=stderr -d log_errors=1 '
        . escapeshellarg($file) . ' ' . escapeshellarg('period=' . $period) . ' ' . escapeshellarg('as_of=' . $asOf) . ' debug=1';

    $lastError = '';
    for ($attempt = 1; $attempt <= 2; $attempt++) {
        $proc = proc_open($cmd, [1 => ['pipe', 'w'], 2 => ['pipe', 'w']], $pipes, dirname($file));
        if (!is_resource($proc)) {
            throw new RuntimeException('Could not start PHP to build the report.');
        }
        $out = stream_get_contents($pipes[1]);
        $err = stream_get_contents($pipes[2]);
        fclose($pipes[1]);
        fclose($pipes[2]);
        proc_close($proc);

        $data = json_decode((string) $out, true);
        if (is_array($data) && !empty($data['success'])) {
            return $data;
        }
        $lastError = is_array($data)
            ? (string) (($data['debug']['message'] ?? null) ?: ($data['error'] ?? 'Unknown error'))
            : 'Endpoint did not return JSON. ' . trim(substr((string) $out . ' ' . (string) $err, 0, 500));
        srLog("{$platform} {$period} attempt {$attempt} failed: {$lastError}");
        if ($attempt === 1) {
            sleep(30);
        }
    }
    throw new RuntimeException($lastError);
}

/** Webzaa brand colours (from the logo). */
const SR_ORANGE = '#E84E24';
const SR_GREY = '#6B6B6B';
const SR_INK = '#2F2F2F';

/** Public URL of the logo (email clients need a full https URL, not a file path). */
function srLogoUrl(): string
{
    if (defined('REPORT_LOGO_URL') && trim((string) REPORT_LOGO_URL) !== '') {
        return (string) REPORT_LOGO_URL;
    }
    if (defined('REPORT_BASE_URL') && trim((string) REPORT_BASE_URL) !== '') {
        return rtrim((string) REPORT_BASE_URL, '/') . '/images/webzaa-logo.png';
    }
    return '';
}

/** Project shown on every report email (subject, header, footer): REPORT_PROJECT_NAME, else PROJECT_NAME. */
function srProjectName(): string
{
    foreach (['REPORT_PROJECT_NAME', 'PROJECT_NAME'] as $c) {
        if (defined($c) && trim((string) constant($c)) !== '') {
            return trim((string) constant($c));
        }
    }
    return '';
}

/** "Embassy Northyelahanka · " in front of a subject, so the inbox shows which project it is. */
function srSubjectPrefix(): string
{
    $p = srProjectName();
    return $p !== '' ? $p . ' · ' : '';
}

function srEmailShell(string $platform, string $eyebrow, string $title, string $inner): string
{
    $project = srProjectName();
    $logo = srLogoUrl();
    $logoHtml = $logo !== ''
        ? '<img src="' . srEsc($logo) . '" width="77" height="56" alt="Webzaa" style="display:block;border:0;width:77px;height:56px;">'
        : '<span style="font-size:22px;font-weight:700;color:' . SR_GREY . ';">Web<span style="color:' . SR_ORANGE . ';">zaa</span></span>';

    return '<!doctype html><html><body style="margin:0;padding:0;background:#f4f4f5;">'
        . '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#f4f4f5;padding:24px 0;"><tr><td align="center">'
        . '<table role="presentation" width="680" cellpadding="0" cellspacing="0" style="max-width:680px;width:100%;background:#ffffff;border-radius:12px;overflow:hidden;font-family:Arial,Helvetica,sans-serif;color:' . SR_INK . ';border:1px solid #e4e4e7;">'
        . '<tr><td style="height:5px;background:' . SR_ORANGE . ';font-size:0;line-height:0;">&nbsp;</td></tr>'
        . '<tr><td style="padding:18px 28px;border-bottom:1px solid #ededed;">'
        . '<table role="presentation" width="100%" cellpadding="0" cellspacing="0"><tr>'
        . '<td valign="middle" width="90">' . $logoHtml . '</td>'
        . '<td valign="middle" align="right">'
        . ($project !== '' ? '<div style="display:inline-block;background:' . SR_INK . ';color:#ffffff;font-size:12px;font-weight:700;padding:4px 10px;border-radius:999px;margin-bottom:6px;">' . srEsc($project) . '</div>' : '')
        . '<div style="color:' . SR_ORANGE . ';font-size:11px;font-weight:700;letter-spacing:2px;text-transform:uppercase;">' . srEsc($eyebrow) . '</div>'
        . '<div style="color:' . SR_INK . ';font-size:22px;font-weight:700;margin-top:4px;">' . srEsc($title) . '</div>'
        . '</td></tr></table>'
        . '</td></tr>'
        . '<tr><td style="padding:24px 28px;">' . $inner . '</td></tr>'
        . '<tr><td style="padding:14px 28px;background:#fafafa;border-top:1px solid #ededed;color:#9a9a9a;font-size:11px;">'
        . 'Automated ' . srEsc(SR_PLATFORM_NAME[$platform]) . ' report' . ($project !== '' ? ' for <b style="color:#6b6b6b;">' . srEsc($project) . '</b>' : '') . ' by <span style="color:' . SR_ORANGE . ';font-weight:700;">Webzaa</span> · Asia/Kolkata</td></tr>'
        . '</table></td></tr></table></body></html>';
}

/* ---------- Report emails (full report in the body, any period) ---------- */
const SR_PERIOD_WORD = ['daily' => 'day', 'weekly' => 'week', 'monthly' => 'month'];
const SR_PERIOD_TITLE = ['daily' => 'Daily', 'weekly' => 'Weekly', 'monthly' => 'Monthly'];

/** Weekly / monthly: spend & cost plus lead quality (qualified leads, site visits). */
const SR_EXTENDED_METRICS = [
    ['spend', 'Spend', 'neutral'],
    ['leads', 'Leads', 'up'],
    ['cpl', 'CPL', 'down'],
    ['qualified', 'Qualified Leads', 'up'],
    ['cpql', 'CPQL', 'down'],
    ['site_visits', 'Site Visits', 'up'],
    ['cpsv', 'CPSV', 'down'],
    ['cpc', 'CPC', 'down'],
    ['ctr', 'CTR', 'up'],
];
const SR_DAILY_METRICS = [
    ['spend', 'Spend', 'neutral'],
    ['leads', 'Leads', 'up'],
    ['cpl', 'CPL', 'down'],
    ['cpc', 'CPC', 'down'],
    ['impressions', 'Impressions', 'up'],
    ['ctr', 'CTR', 'up'],
];

/**
 * Metrics hidden by the viewer's role (Users & Roles → "Hide numbers"). Set by email_report_api.php for the
 * logged-in user: $GLOBALS['SR_HIDE_METRICS'] = pqHiddenMetrics(). The scheduled emails never set it.
 * Keys here: qualified, cpql, site_visits, cpsv.
 */
function srHidden(string $key): bool
{
    $hide = (array) ($GLOBALS['SR_HIDE_METRICS'] ?? []);
    $k = $key === 'site_visits' ? 'sitevisits' : $key;
    return in_array($k, $hide, true);
}

/** Drop hidden metrics from a [[key, label, better], …] list. */
function srKeep(array $list): array
{
    return array_values(array_filter($list, static fn($m) => !srHidden((string) $m[0])));
}

/** Headline cards for a period. */
function srMetrics(string $period): array
{
    return srKeep($period === 'daily' ? SR_DAILY_METRICS : SR_EXTENDED_METRICS);
}

/** Columns for campaign / platform tables. */
function srTableCols(string $period): array
{
    return srKeep($period === 'daily'
        ? [['spend', 'Spend', 'neutral'], ['leads', 'Leads', 'up'], ['cpl', 'CPL', 'down'], ['cpc', 'CPC', 'down'], ['impressions', 'Impr.', 'up'], ['ctr', 'CTR', 'up']]
        : [['spend', 'Spend', 'neutral'], ['leads', 'Leads', 'up'], ['cpl', 'CPL', 'down'], ['qualified', 'QL', 'up'], ['cpql', 'CPQL', 'down'], ['site_visits', 'SV', 'up'], ['cpsv', 'CPSV', 'down']]);
}

/** Rows for the metric | previous | current | change table. */
function srCompareRows(string $period): array
{
    return srKeep($period === 'daily'
        ? array_merge(SR_DAILY_METRICS, [['clicks', 'Clicks', 'up']])
        : array_merge(SR_EXTENDED_METRICS, [['impressions', 'Impressions', 'up'], ['clicks', 'Clicks', 'up']]));
}

function srNote(string $period): string
{
    $word = SR_PERIOD_WORD[$period] ?? 'period';
    $extra = ($period === 'daily' || srHidden('qualified') || srHidden('site_visits')) ? '' : ' Qualified leads and site visits are counted by the date the lead was created, so recent leads may still progress.';
    return '<div style="margin-top:18px;font-size:11px;color:#94a3b8;">Small grey figure = previous ' . $word
        . '. Green = better, red = worse. Leads are CRM records by lead created date.' . $extra . '</div>';
}

function srTh(string $align = 'right'): string
{
    return 'style="background:' . SR_ORANGE . ';color:#ffffff;padding:9px 10px;font-size:11px;letter-spacing:.5px;text-transform:uppercase;text-align:' . $align . ';"';
}

function srTd(string $align = 'right', string $extra = ''): string
{
    return 'style="padding:8px 10px;border-bottom:1px solid #ececec;font-size:13px;text-align:' . $align . ';' . ($align === 'right' ? 'white-space:nowrap;' : '') . $extra . '"';
}

/** Six headline tiles (3 per row) for a set of totals. */
function srTiles(array $cur, array $prev, array $ch, string $period = 'daily'): string
{
    $html = '<table role="presentation" width="100%" cellpadding="0" cellspacing="0">';
    foreach (array_chunk(srMetrics($period), 3) as $row) {
        $html .= '<tr>';
        foreach ($row as [$k, $label, $better]) {
            [$txt, $col] = srChange($ch[$k] ?? null, $better);
            $html .= '<td width="33%" style="padding:6px;">'
                . '<div style="border:1px solid #ececec;border-top:3px solid ' . SR_ORANGE . ';border-radius:10px;padding:12px 14px;background:#fafafa;">'
                . '<div style="font-size:11px;color:' . SR_GREY . ';text-transform:uppercase;letter-spacing:1px;">' . $label . '</div>'
                . '<div style="font-size:20px;font-weight:700;margin:6px 0 4px;">' . srFmt($k, $cur[$k] ?? null) . '</div>'
                . '<div style="font-size:12px;"><span style="color:#94a3b8;">' . srFmt($k, $prev[$k] ?? null) . '</span> &nbsp;<span style="color:' . $col . ';font-weight:700;">' . $txt . '</span></div>'
                . '</div></td>';
        }
        $html .= '</tr>';
    }
    return $html . '</table>';
}

/** Metric | previous | current | change table. */
function srCompareTable(array $data, string $period = 'daily'): string
{
    $cur = $data['current']['totals'];
    $prev = $data['previous']['totals'];
    $ch = $data['changes'];
    $html = '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="border-collapse:collapse;margin-top:18px;">'
        . '<tr><th ' . srTh('left') . '>Metric</th><th ' . srTh() . '>' . srEsc($data['previous']['label']) . '</th><th ' . srTh() . '>' . srEsc($data['current']['label']) . '</th><th ' . srTh() . '>Change</th></tr>';
    foreach (srCompareRows($period) as [$k, $label, $better]) {
        [$txt, $col] = srChange($ch[$k] ?? null, $better);
        $html .= '<tr><td ' . srTd('left') . '>' . $label . '</td><td ' . srTd() . '>' . srFmt($k, $prev[$k] ?? null) . '</td><td ' . srTd() . '><strong>' . srFmt($k, $cur[$k] ?? null) . '</strong></td><td ' . srTd() . '><span style="color:' . $col . ';font-weight:700;">' . $txt . '</span></td></tr>';
    }
    return $html . '</table>';
}

/** Campaign table (top N by spend). */
function srCampaignTable(array $data, string $heading, string $period = 'daily'): string
{
    $camps = array_values(array_filter($data['campaigns'] ?? [], static fn($c) => ($c['current']['spend'] ?? 0) > 0 || ($c['previous']['spend'] ?? 0) > 0));
    $shown = array_slice($camps, 0, SR_DAILY_CAMPAIGN_LIMIT);
    if (!$shown) {
        return '';
    }
    $cols = srTableCols($period);
    $html = '<div style="font-size:15px;font-weight:700;margin:26px 0 8px;color:' . SR_ORANGE . ';">' . srEsc($heading) . '</div>'
        . '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="border-collapse:collapse;">'
        . '<tr><th ' . srTh('left') . '>Campaign</th>';
    foreach ($cols as [, $label]) {
        $html .= '<th ' . srTh() . '>' . $label . '</th>';
    }
    $html .= '</tr>';
    foreach ($shown as $c) {
        $html .= '<tr><td ' . srTd('left') . '>' . srEsc((string) $c['campaign_name']) . '</td>';
        foreach ($cols as [$k, , $better]) {
            [$txt, $col] = srChange($c['changes'][$k] ?? null, $better);
            $html .= '<td ' . srTd() . '>' . srFmt($k, $c['current'][$k] ?? null) . '<div style="font-size:10px;color:' . $col . ';">' . $txt . '</div></td>';
        }
        $html .= '</tr>';
    }
    $html .= '</table>';
    if (count($camps) > count($shown)) {
        $html .= '<div style="font-size:12px;color:#64748b;margin-top:8px;">Showing the top ' . count($shown) . ' of ' . count($camps) . ' campaigns by spend. See the dashboard for the rest.</div>';
    }
    return $html;
}

function srWarnings(array $warnings): string
{
    if (!$warnings) {
        return '';
    }
    return '<div style="margin-top:18px;padding:10px 12px;border:1px solid #fcd34d;background:#fffbeb;border-radius:8px;font-size:12px;color:#92400e;">'
        . implode('<br>', array_map('srEsc', $warnings)) . '</div>';
}


/* ---------- Written summary (rule-based, from the numbers only) ---------- */

/** "rose 12.2%" / "fell 6.5%" / "held steady" / "" (no comparison). */
function srMove($pct): string
{
    if ($pct === null) {
        return '';
    }
    $p = (float) $pct;
    if (abs($p) < 0.05) {
        return 'held steady';
    }
    return ($p > 0 ? 'rose ' : 'fell ') . number_format(abs($p), 1) . '%';
}

/** Coloured "▲ 12.2%" for use inside summary sentences. */
function srMoveHtml($pct, string $better): string
{
    if ($pct === null) {
        return '';
    }
    [$txt, $col] = srChange($pct, $better);
    return ' <span style="color:' . $col . ';font-weight:700;white-space:nowrap;">(' . $txt . ')</span>';
}

/**
 * 3–7 short, factual sentences about one platform's day: overall movement, where the money went,
 * the most efficient campaign, and anything worth checking. HTML-safe.
 */
function srSummaryLines(array $data, string $label = '', string $period = 'daily'): array
{
    $cur = $data['current']['totals'];
    $prev = $data['previous']['totals'];
    $ch = $data['changes'];
    $prevL = $data['previous']['label'];
    $who = $label !== '' ? srEsc($label) . ' ' : '';
    $lines = [];

    // 1. Overall
    if ((float) ($cur['spend'] ?? 0) <= 0 && (int) ($cur['leads'] ?? 0) === 0) {
        $lines[] = $who . 'had no spend and no leads.';
        return $lines;
    }
    $line = $who . 'spent <strong>' . srFmt('spend', $cur['spend']) . '</strong>' . srMoveHtml($ch['spend'] ?? null, 'neutral')
        . ' and generated <strong>' . srFmt('leads', $cur['leads']) . ' lead' . ((int) $cur['leads'] === 1 ? '' : 's') . '</strong>' . srMoveHtml($ch['leads'] ?? null, 'up');
    if (isset($cur['cpl']) && $cur['cpl'] !== null) {
        $line .= ', at a CPL of <strong>' . srFmt('cpl', $cur['cpl']) . '</strong>' . srMoveHtml($ch['cpl'] ?? null, 'down');
    } elseif ((float) $cur['spend'] > 0) {
        $line .= ' — no leads came in, so there is no CPL';
    }
    $lines[] = $line . '.';

    // 2. Cost efficiency verdict
    $cplMove = $ch['cpl'] ?? null;
    if ($cplMove !== null && abs((float) $cplMove) >= 10) {
        $lines[] = (float) $cplMove < 0
            ? 'Leads got <strong>cheaper</strong>: CPL ' . srMove($cplMove) . ' versus ' . srEsc($prevL) . '.'
            : 'Leads got <strong>more expensive</strong>: CPL ' . srMove($cplMove) . ' versus ' . srEsc($prevL) . '.';
    }

    // 2b. Lead quality (weekly / monthly)
    if ($period !== 'daily' && array_key_exists('qualified', $cur)) {
        $parts = [];
        if (!srHidden('qualified')) {
            $q = '<strong>' . srFmt('qualified', $cur['qualified']) . ' qualified lead' . ((int) $cur['qualified'] === 1 ? '' : 's') . '</strong>' . srMoveHtml($ch['qualified'] ?? null, 'up');
            $q .= (!srHidden('cpql') && ($cur['cpql'] ?? null) !== null) ? ' at a CPQL of <strong>' . srFmt('cpql', $cur['cpql']) . '</strong>' . srMoveHtml($ch['cpql'] ?? null, 'down') : '';
            $parts[] = $q;
        } elseif (!srHidden('cpql') && ($cur['cpql'] ?? null) !== null) {
            $parts[] = 'CPQL <strong>' . srFmt('cpql', $cur['cpql']) . '</strong>' . srMoveHtml($ch['cpql'] ?? null, 'down');
        }
        if (!srHidden('site_visits')) {
            $sv = '<strong>' . srFmt('site_visits', $cur['site_visits'] ?? 0) . ' site visit' . ((int) ($cur['site_visits'] ?? 0) === 1 ? '' : 's') . '</strong>' . srMoveHtml($ch['site_visits'] ?? null, 'up');
            $sv .= (!srHidden('cpsv') && ($cur['cpsv'] ?? null) !== null) ? ' at a CPSV of <strong>' . srFmt('cpsv', $cur['cpsv']) . '</strong>' . srMoveHtml($ch['cpsv'] ?? null, 'down') : '';
            $parts[] = $sv;
        } elseif (!srHidden('cpsv') && ($cur['cpsv'] ?? null) !== null) {
            $parts[] = 'CPSV <strong>' . srFmt('cpsv', $cur['cpsv']) . '</strong>' . srMoveHtml($ch['cpsv'] ?? null, 'down');
        }
        $rate = (!srHidden('qualified') && ((int) ($cur['leads'] ?? 0)) > 0) ? ' — ' . number_format((float) $cur['qualified'] / (float) $cur['leads'] * 100, 0) . '% of leads qualified' : '';
        if ($parts) {
            $lines[] = 'Lead quality: ' . implode('; ', $parts) . $rate . '.';
        }
    }

    // 3. Traffic quality
    if (isset($cur['ctr'], $cur['cpc']) && $cur['ctr'] !== null && $cur['cpc'] !== null) {
        $lines[] = 'CTR was ' . srFmt('ctr', $cur['ctr']) . srMoveHtml($ch['ctr'] ?? null, 'up')
            . ' with a CPC of ' . srFmt('cpc', $cur['cpc']) . srMoveHtml($ch['cpc'] ?? null, 'down') . '.';
    }

    $camps = array_values(array_filter($data['campaigns'] ?? [], static fn($c) => (float) ($c['current']['spend'] ?? 0) > 0 || (int) ($c['current']['leads'] ?? 0) > 0));
    $totalSpend = max(0.01, (float) $cur['spend']);

    // 4. Where the money went
    usort($camps, static fn($a, $b) => (float) $b['current']['spend'] <=> (float) $a['current']['spend']);
    if ($camps && (float) $camps[0]['current']['spend'] > 0 && count($camps) > 1) {
        $top = $camps[0];
        $share = round((float) $top['current']['spend'] / $totalSpend * 100);
        $lines[] = 'Biggest spend: “' . srEsc($top['campaign_name']) . '” with ' . srFmt('spend', $top['current']['spend'])
            . ' (' . $share . '% of the total) and ' . srFmt('leads', $top['current']['leads']) . ' lead' . ((int) $top['current']['leads'] === 1 ? '' : 's') . '.';
    }

    // 5a. Best on qualified leads (weekly / monthly)
    if ($period !== 'daily' && !srHidden('qualified') && !srHidden('cpql')) {
        $withQl = array_values(array_filter($camps, static fn($c) => (int) ($c['current']['qualified'] ?? 0) > 0 && (float) $c['current']['spend'] > 0));
        if (count($withQl) > 1) {
            usort($withQl, static fn($a, $b) => (float) $a['current']['cpql'] <=> (float) $b['current']['cpql']);
            $best = $withQl[0];
            $lines[] = 'Best on lead quality: “' . srEsc($best['campaign_name']) . '” — ' . srFmt('qualified', $best['current']['qualified'])
                . ' qualified lead' . ((int) $best['current']['qualified'] === 1 ? '' : 's') . ' at ' . srFmt('cpql', $best['current']['cpql']) . ' each.';
        }
    }

    // 5. Most efficient campaign (at least 2 leads, or 1 if nothing better)
    $withLeads = array_values(array_filter($camps, static fn($c) => (int) $c['current']['leads'] > 0 && (float) $c['current']['spend'] > 0));
    if (count($withLeads) > 1) {
        $pool = array_values(array_filter($withLeads, static fn($c) => (int) $c['current']['leads'] >= 2)) ?: $withLeads;
        usort($pool, static fn($a, $b) => (float) $a['current']['cpl'] <=> (float) $b['current']['cpl']);
        $best = $pool[0];
        $lines[] = 'Most efficient: “' . srEsc($best['campaign_name']) . '” — ' . srFmt('leads', $best['current']['leads'])
            . ' lead' . ((int) $best['current']['leads'] === 1 ? '' : 's') . ' at ' . srFmt('cpl', $best['current']['cpl']) . ' each.';
    }

    // 6. Things to check
    $checks = [];
    $noLeads = array_values(array_filter($camps, static fn($c) => (int) $c['current']['leads'] === 0 && (float) $c['current']['spend'] >= max(500, $totalSpend * 0.05)));
    foreach (array_slice($noLeads, 0, 2) as $c) {
        $checks[] = '“' . srEsc($c['campaign_name']) . '” spent ' . srFmt('spend', $c['current']['spend']) . ' with no leads';
    }
    $cplUp = array_values(array_filter($camps, static fn($c) => ($c['changes']['cpl'] ?? null) !== null && (float) $c['changes']['cpl'] > 30 && (int) $c['current']['leads'] > 0));
    usort($cplUp, static fn($a, $b) => (float) $b['changes']['cpl'] <=> (float) $a['changes']['cpl']);
    foreach (array_slice($cplUp, 0, 1) as $c) {
        $checks[] = '“' . srEsc($c['campaign_name']) . '” CPL rose ' . number_format((float) $c['changes']['cpl'], 0) . '% to ' . srFmt('cpl', $c['current']['cpl']);
    }
    if ($period !== 'daily' && !srHidden('qualified')) {
        $noQl = array_values(array_filter($camps, static fn($c) => (int) $c['current']['leads'] >= 5 && (int) ($c['current']['qualified'] ?? 0) === 0));
        foreach (array_slice($noQl, 0, 1) as $c) {
            $checks[] = '“' . srEsc($c['campaign_name']) . '” had ' . srFmt('leads', $c['current']['leads']) . ' leads but none qualified';
        }
    }
    if ($checks) {
        $lines[] = '<span style="color:#b45309;font-weight:700;">To check:</span> ' . implode('; ', $checks) . '.';
    }

    // 7. Leads not linked to a campaign
    $un = (int) ($data['unattributed']['current']['leads'] ?? 0);
    if ($un > 0) {
        $lines[] = $un . ' lead' . ($un === 1 ? '' : 's') . ' could not be linked to a campaign (no matching ad or campaign name); counted in totals only.';
    }

    return $lines;
}

/** The orange-edged summary box shown at the top of the daily emails. */
function srSummaryBox(array $lines, string $heading = 'Summary'): string
{
    if (!$lines) {
        return '';
    }
    $items = '';
    foreach ($lines as $l) {
        $items .= '<tr><td valign="top" style="padding:0 8px 8px 0;color:' . SR_ORANGE . ';font-size:14px;line-height:1.55;">&#9679;</td>'
            . '<td style="padding:0 0 8px 0;font-size:14px;line-height:1.55;color:' . SR_INK . ';">' . $l . '</td></tr>';
    }
    return '<div style="margin:0 0 18px;padding:16px 18px;background:#fff7f4;border:1px solid #f6d3c7;border-left:4px solid ' . SR_ORANGE . ';border-radius:8px;">'
        . '<div style="font-size:12px;font-weight:700;letter-spacing:1px;text-transform:uppercase;color:' . SR_ORANGE . ';margin-bottom:10px;">' . srEsc($heading) . '</div>'
        . '<table role="presentation" cellpadding="0" cellspacing="0">' . $items . '</table></div>';
}

/**
 * "Insights & Actions" for the execution team (app/Ads/creatives.php): which ads to scale, pause or refresh.
 * Same rules as the Creatives & Insights page; Groq writes the sentences when GROQ_API_KEY is set.
 * Turn off with define('REPORT_INSIGHTS', false) in config.php. Never stops a report: on any error it is left out.
 */
function srInsightsBox(string $platform, array $data, int $limit = 8, string $heading = 'Insights & actions'): string
{
    if (defined('REPORT_INSIGHTS') && !REPORT_INSIGHTS) {
        return '';
    }
    $since = (string) ($data['current']['since'] ?? '');
    $until = (string) ($data['current']['until'] ?? '');
    if ($since === '' || $until === '') {
        return '';
    }
    try {
        require_once dirname(__DIR__) . '/Ads/creatives.php';
        $ins = crInsights($platform, $since, $until, (array) ($GLOBALS['SR_HIDE_METRICS'] ?? []));
        $findings = array_slice($ins['findings'], 0, $limit);
        if (!$findings) {
            return '';
        }
        $txt = crInsightsText($platform, (string) ($data['current']['label'] ?? ''), $findings);
    } catch (Throwable $e) {
        srLog("insights {$platform}: " . $e->getMessage());
        return '';
    }
    $col = ['good' => '#059669', 'warn' => '#B45309', 'bad' => '#DC2626', 'info' => '#2563EB'];
    $items = '';
    foreach ($findings as $f) {
        $c = $col[$f['severity']] ?? SR_GREY;
        $items .= '<tr><td valign="top" style="padding:2px 10px 10px 0;color:' . $c . ';font-size:14px;line-height:1.5;">&#9679;</td>'
            . '<td style="padding:0 0 10px 0;font-size:14px;line-height:1.5;color:' . SR_INK . ';"><strong>' . srEsc((string) $f['title']) . '</strong><br>'
            . '<span style="color:#475569;">' . srEsc((string) ($txt['items'][$f['id']] ?? ($f['text'] . ' ' . $f['action']))) . '</span></td></tr>';
    }
    $link = defined('APP_URL') && APP_URL !== '' ? rtrim((string) APP_URL, '/') . '/dashboard.php#creatives' : '';
    return '<div style="margin:0 0 18px;padding:16px 18px;background:#ffffff;border:1px solid #e2e8f0;border-radius:8px;">'
        . '<div style="font-size:12px;font-weight:700;letter-spacing:1px;text-transform:uppercase;color:' . SR_ORANGE . ';margin-bottom:6px;">' . srEsc($heading) . '</div>'
        . ($txt['summary'] !== '' ? '<div style="font-size:14px;line-height:1.55;color:' . SR_INK . ';margin-bottom:10px;">' . srEsc($txt['summary']) . '</div>' : '')
        . '<table role="presentation" cellpadding="0" cellspacing="0">' . $items . '</table>'
        . ($link !== '' ? '<div style="font-size:12px;margin-top:4px;"><a href="' . srEsc($link) . '" style="color:' . SR_ORANGE . ';">See the creatives and their images in the admin &rarr;</a></div>' : '')
        . '</div>';
}

function srBuildReportEmail(string $platform, string $period, array $data): array
{
    $cur = $data['current']['totals'];
    $curL = $data['current']['label'];
    $name = SR_PLATFORM_NAME[$platform];
    $kind = SR_PERIOD_TITLE[$period] ?? 'Daily';

    $inner = '<div style="font-size:14px;color:#334155;margin-bottom:14px;">' . srEsc($curL) . ' compared with ' . srEsc($data['previous']['label']) . '.</div>'
        . srSummaryBox(srSummaryLines($data, $name, $period))
        . srInsightsBox($platform, $data)
        . srTiles($cur, $data['previous']['totals'], $data['changes'], $period)
        . srCompareTable($data, $period)
        . srCampaignTable($data, 'Campaigns · ' . $curL, $period)
        . srWarnings($data['warnings'] ?? [])
        . srNote($period);

    $subject = srSubjectPrefix() . "{$name} {$kind} Report · {$curL} · Spend " . srFmt('spend', $cur['spend'] ?? 0)
        . ' · Leads ' . srFmt('leads', $cur['leads'] ?? 0) . ' · CPL ' . srFmt('cpl', $cur['cpl'] ?? null)
        . (($period !== 'daily' && !srHidden('qualified')) ? ' · QL ' . srFmt('qualified', $cur['qualified'] ?? 0) : '');

    return [$subject, srEmailShell($platform, "{$name} · {$kind} report", $curL, $inner)];
}

function srBuildDailyEmail(string $platform, array $data): array
{
    return srBuildReportEmail($platform, 'daily', $data);
}

/* ---------- Combined Meta + Google ---------- */

/** Adds Meta and Google totals together and recomputes CPL / CPC / CTR and the % changes. */
function srCombineTotals(array $reports): array
{
    $out = [];
    foreach (['current', 'previous'] as $side) {
        $t = ['spend' => 0.0, 'impressions' => 0.0, 'clicks' => 0.0, 'leads' => 0.0, 'qualified' => 0.0, 'site_visits' => 0.0];
        foreach ($reports as $d) {
            foreach ($t as $k => $_) {
                $t[$k] += (float) ($d[$side]['totals'][$k] ?? 0);
            }
        }
        $t['cpl'] = $t['leads'] > 0 ? round($t['spend'] / $t['leads'], 2) : null;
        $t['cpc'] = $t['clicks'] > 0 ? round($t['spend'] / $t['clicks'], 2) : null;
        $t['ctr'] = $t['impressions'] > 0 ? round($t['clicks'] / $t['impressions'] * 100, 2) : null;
        $t['cpql'] = $t['qualified'] > 0 ? round($t['spend'] / $t['qualified'], 2) : null;
        $t['cpsv'] = $t['site_visits'] > 0 ? round($t['spend'] / $t['site_visits'], 2) : null;
        $out[$side] = $t;
    }
    $changes = [];
    foreach (['spend', 'impressions', 'clicks', 'leads', 'cpl', 'cpc', 'ctr', 'qualified', 'cpql', 'site_visits', 'cpsv'] as $k) {
        $c = $out['current'][$k];
        $p = $out['previous'][$k];
        $changes[$k] = ($c === null || $p === null) ? null
            : ((float) $p == 0.0 ? ((float) $c == 0.0 ? 0.0 : null) : round(($c - $p) / abs($p) * 100, 2));
    }
    return [$out['current'], $out['previous'], $changes];
}

/** One daily email with combined totals, a platform split, then each platform's detail. */
function srBuildCombinedDailyEmail(array $reports, array $missing, string $period = 'daily'): array
{
    $kind = SR_PERIOD_TITLE[$period] ?? 'Daily';
    $first = reset($reports);
    $curL = $first['current']['label'];
    $prevL = $first['previous']['label'];
    [$cur, $prev, $ch] = srCombineTotals($reports);

    // Platform split table
    $split = '<div style="font-size:15px;font-weight:700;margin:24px 0 8px;color:' . SR_ORANGE . ';">By platform · ' . srEsc($curL) . '</div>'
        . '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="border-collapse:collapse;">'
        . '<tr><th ' . srTh('left') . '>Platform</th>';
    foreach (srTableCols($period) as [, $label]) {
        $split .= '<th ' . srTh() . '>' . $label . '</th>';
    }
    $split .= '</tr>';
    $rows = [];
    foreach ($reports as $platform => $d) {
        $rows[] = [SR_PLATFORM_NAME[$platform], $d['current']['totals'], $d['changes'], false];
    }
    $rows[] = ['Total', $cur, $ch, true];
    foreach ($rows as [$label, $tot, $chg, $isTotal]) {
        $bg = $isTotal ? 'background:#fdeee9;font-weight:700;' : '';
        $split .= '<tr><td ' . srTd('left', $bg) . '>' . srEsc($label) . '</td>';
        foreach (srTableCols($period) as [$k, , $better]) {
            [$txt, $col] = srChange($chg[$k] ?? null, $better);
            $split .= '<td ' . srTd('right', $bg) . '>' . srFmt($k, $tot[$k] ?? null) . '<div style="font-size:10px;font-weight:400;color:' . $col . ';">' . $txt . '</div></td>';
        }
        $split .= '</tr>';
    }
    $split .= '</table>';

    $missingNote = $missing
        ? srWarnings(array_map(static fn($p) => SR_PLATFORM_NAME[$p] . ' data could not be loaded, so it is not included.', $missing))
        : '';

    $sections = '';
    foreach ($reports as $platform => $d) {
        $name = SR_PLATFORM_NAME[$platform];
        $sections .= '<div style="margin-top:34px;padding-top:18px;border-top:3px solid ' . SR_ORANGE . ';">'
            . '<div style="font-size:18px;font-weight:700;color:' . SR_INK . ';">' . srEsc($name) . '</div></div>'
            . srCompareTable($d, $period)
            . srCampaignTable($d, $name . ' campaigns · ' . $curL, $period)
            . srWarnings($d['warnings'] ?? []);
    }

    // Summary: combined picture, then one line per platform, then which platform was cheaper per lead.
    $combinedData = ['current' => ['totals' => $cur, 'label' => $curL], 'previous' => ['totals' => $prev, 'label' => $prevL], 'changes' => $ch, 'campaigns' => []];
    $summary = srSummaryLines($combinedData, 'Meta + Google together', $period);
    $cpls = [];
    foreach ($reports as $platform => $d) {
        $t = $d['current']['totals'];
        $summary[] = '<strong>' . srEsc(SR_PLATFORM_NAME[$platform]) . ':</strong> ' . srFmt('spend', $t['spend'] ?? 0) . ' spend, '
            . srFmt('leads', $t['leads'] ?? 0) . ' lead' . ((int) ($t['leads'] ?? 0) === 1 ? '' : 's')
            . (isset($t['cpl']) && $t['cpl'] !== null ? ', CPL ' . srFmt('cpl', $t['cpl']) . srMoveHtml($d['changes']['cpl'] ?? null, 'down') : '')
            . ($period !== 'daily'
                ? (!srHidden('qualified') ? ', ' . srFmt('qualified', $t['qualified'] ?? 0) . ' QL' : '')
                . ((!srHidden('cpql') && ($t['cpql'] ?? null) !== null) ? (srHidden('qualified') ? ', CPQL ' . srFmt('cpql', $t['cpql']) : ' (CPQL ' . srFmt('cpql', $t['cpql']) . ')') : '')
                . (!srHidden('site_visits') ? ', ' . srFmt('site_visits', $t['site_visits'] ?? 0) . ' SV' : '')
                : '') . '.';
        if (isset($t['cpl']) && $t['cpl'] !== null && (int) $t['leads'] > 0) {
            $cpls[$platform] = (float) $t['cpl'];
        }
    }
    if (count($cpls) === 2) {
        asort($cpls);
        [$cheap, $dear] = array_keys($cpls);
        if ($cpls[$dear] > 0 && $cpls[$cheap] < $cpls[$dear]) {
            $summary[] = srEsc(SR_PLATFORM_NAME[$cheap]) . ' delivered leads <strong>' . number_format((1 - $cpls[$cheap] / $cpls[$dear]) * 100, 0)
                . '% cheaper</strong> than ' . srEsc(SR_PLATFORM_NAME[$dear]) . '.';
        }
    }
    // Per-platform "to check" items (campaign-level), so they aren't lost in the combined view.
    foreach ($reports as $platform => $d) {
        foreach (srSummaryLines($d, '', $period) as $l) {
            if (str_contains($l, 'To check:')) {
                $summary[] = str_replace('To check:</span>', srEsc(SR_PLATFORM_NAME[$platform]) . ' – to check:</span>', $l);
            }
        }
    }

    $inner = '<div style="font-size:14px;color:#334155;margin-bottom:14px;">Meta and Google together · ' . srEsc($curL) . ' compared with ' . srEsc($prevL) . '.</div>'
        . srSummaryBox($summary)
        . implode('', array_map(static fn($p) => srInsightsBox($p, $reports[$p], 6, SR_PLATFORM_NAME[$p] . ' · insights & actions'), array_keys($reports)))
        . $missingNote
        . srTiles($cur, $prev, $ch, $period)
        . $split
        . $sections
        . srNote($period);

    $subject = srSubjectPrefix() . "Meta + Google {$kind} Report · " . $curL . ' · Spend ' . srFmt('spend', $cur['spend'])
        . ' · Leads ' . srFmt('leads', $cur['leads']) . ' · CPL ' . srFmt('cpl', $cur['cpl'])
        . (($period !== 'daily' && !srHidden('qualified')) ? ' · QL ' . srFmt('qualified', $cur['qualified']) : '');

    return [$subject, srEmailShell('combined', "Meta + Google Ads · {$kind} report", $curL, $inner)];
}
