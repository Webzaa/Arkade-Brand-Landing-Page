<?php
declare(strict_types=1);


require_once dirname(__DIR__) . '/bootstrap.php';
/**
 * report_mailer.php — sends the report emails and OTP codes.
 *
 * Uses your existing mailer file (the one with getMailer()), so the SMTP
 * login lives in one place. Point to it in config.php:
 *
 *   define('REPORT_MAILER_FILE', APP_PATH . '/Core/mailer.php');
 *
 * If REPORT_MAILER_FILE is not set, it falls back to SMTP_* constants in config.php.
 */

use PHPMailer\PHPMailer\Exception as MailException;
use PHPMailer\PHPMailer\PHPMailer;

/** Returns a ready-to-use PHPMailer (SMTP, from-address, HTML and UTF-8 already set). */
function reportGetMailer(): PHPMailer
{
    // 1. Your existing mailer file with getMailer()
    if (!function_exists('getMailer') && defined('REPORT_MAILER_FILE')) {
        $file = (string) REPORT_MAILER_FILE;
        if (!is_file($file)) {
            throw new RuntimeException('REPORT_MAILER_FILE not found: ' . $file);
        }
        // The mailer loads its own config.php, which repeats a few constants already
        // defined by this folder's config.php (e.g. META_ACCESS_TOKEN). The values loaded
        // first are kept; this only silences PHP's "already defined" warning while loading.
        set_error_handler(static function (int $no, string $msg): bool {
            return $no === E_WARNING && str_contains($msg, 'already defined');
        });
        try {
            require_once $file;
        } finally {
            restore_error_handler();
        }
    }
    if (function_exists('getMailer')) {
        $mail = getMailer();
        if (!$mail instanceof PHPMailer) {
            throw new RuntimeException('getMailer() did not return a PHPMailer object.');
        }
        return $mail;
    }

    // 2. Fallback: build one from SMTP_* constants
    if (!class_exists(PHPMailer::class)) {
        foreach ([BASE_PATH . '/vendor/autoload.php'] as $autoload) {
            if (is_file($autoload)) {
                require_once $autoload;
                break;
            }
        }
    }
    if (!class_exists(PHPMailer::class)) {
        throw new RuntimeException('No mailer found. Set REPORT_MAILER_FILE in config.php to the file that defines getMailer().');
    }
    foreach (['SMTP_HOST', 'SMTP_PORT', 'SMTP_USER', 'SMTP_PASS', 'MAIL_FROM'] as $c) {
        if (!defined($c) || trim((string) constant($c)) === '') {
            throw new RuntimeException("Missing mail setting in config.php: {$c} (or set REPORT_MAILER_FILE).");
        }
    }
    $mail = new PHPMailer(true);
    $mail->isSMTP();
    $mail->Host = (string) SMTP_HOST;
    $mail->Port = (int) SMTP_PORT;
    $mail->SMTPAuth = true;
    $mail->Username = (string) SMTP_USER;
    $mail->Password = (string) SMTP_PASS;
    $secure = defined('SMTP_SECURE') ? strtolower((string) SMTP_SECURE) : 'tls';
    $mail->SMTPSecure = $secure === 'ssl' ? PHPMailer::ENCRYPTION_SMTPS : PHPMailer::ENCRYPTION_STARTTLS;
    $mail->CharSet = 'UTF-8';
    $mail->isHTML(true);
    $mail->setFrom((string) MAIL_FROM, defined('MAIL_FROM_NAME') ? (string) MAIL_FROM_NAME : 'Performance Reports');
    return $mail;
}

/**
 * @param string[] $to
 * @param array<int,array{path:string,name?:string}> $attachments
 */
function reportSendMail(array $to, string $subject, string $html, string $text = '', array $attachments = []): void
{
    $to = array_values(array_filter(array_map('trim', $to), static fn($e) => filter_var($e, FILTER_VALIDATE_EMAIL)));
    if (!$to) {
        throw new RuntimeException('No valid recipient email address.');
    }

    $mail = reportGetMailer();
    try {
        $mail->Timeout = 30;
        $mail->isHTML(true);
        $mail->CharSet = 'UTF-8';
        // Optional: show a different sender name on report emails, same Gmail account.
        if (defined('REPORT_FROM_NAME') && trim((string) REPORT_FROM_NAME) !== '') {
            $mail->FromName = (string) REPORT_FROM_NAME;
        } elseif (defined('PROJECT_NAME') && trim((string) PROJECT_NAME) !== '') {
            // inbox shows "Embassy Northyelahanka · Webzaa" instead of the same name for every project
            $mail->FromName = trim((string) PROJECT_NAME) . ' · Webzaa';
        }
        foreach ($to as $address) {
            $mail->addAddress($address);
        }

        $mail->Subject = $subject;
        $mail->Body = $html;
        $mail->AltBody = $text !== '' ? $text : trim(html_entity_decode(strip_tags(preg_replace('/<(br|\/p|\/tr|\/h\d)>/i', "\n", $html) ?? $html)));

        foreach ($attachments as $a) {
            $mail->addAttachment($a['path'], $a['name'] ?? '');
        }

        $mail->send();
    } catch (MailException $e) {
        throw new RuntimeException('Email could not be sent: ' . $mail->ErrorInfo);
    }
}