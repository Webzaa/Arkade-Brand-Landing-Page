<?php
declare(strict_types=1);


require_once dirname(__DIR__) . '/bootstrap.php';
/**
 * report_access.php
 *
 * Shared helpers for the scheduled report emails:
 *  - who may call meta_performance_report.php / google_performance_report.php
 *    (logged-in dashboard users, OTP-verified link viewers, or the CLI cron runner)
 *  - signed report links (HMAC tokens)
 *  - OTP generation / checking for report_view.php
 *
 * Needs in config.php (only for links/OTP):  REPORT_LINK_SECRET  (random string, 32+ chars)
 */

const REPORT_ACCESS_TTL      = 7200;   // seconds a verified viewer can use the report page (2 hours)
const REPORT_OTP_TTL         = 600;    // OTP valid for 10 minutes
const REPORT_OTP_MAX_TRIES   = 5;      // wrong attempts allowed per code
const REPORT_OTP_RESEND_WAIT = 60;     // seconds between "send code" clicks
const REPORT_OTP_MAX_PER_HR  = 5;      // codes per link per hour (across all browsers)

/* ----------------------------------------------------------------------
 * Endpoint bootstrap
 * ---------------------------------------------------------------------- */

/**
 * Call at the top of a report endpoint (after headers, before config.php).
 *  - CLI: turns "period=weekly as_of=2026-10-19" arguments into $_GET and skips login.
 *  - Web: allows logged-in dashboard users, or a viewer who verified an OTP link for
 *    exactly this platform + period + as_of. Everyone else gets 401.
 */
function reportBootstrap(string $platform): void
{
    if (PHP_SAPI === 'cli') {
        global $argv;
        foreach (array_slice($argv ?? [], 1) as $arg) {
            if (preg_match('/^(period|as_of|debug)=(.*)$/', (string) $arg, $m)) {
                $_GET[$m[1]] = $m[2];
            }
        }
        return;
    }

    if (session_status() !== PHP_SESSION_ACTIVE) {
        session_start();
    }

    if (($_SESSION['user_logged'] ?? '') === 'Y') {
        return;
    }

    $period = (string) ($_GET['period'] ?? '');
    $asOf = (string) ($_GET['as_of'] ?? '');
    if (reportHasLinkAccess($platform, $period, $asOf)) {
        return;
    }

    http_response_code(401);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['success' => false, 'error' => 'Unauthorised. Please sign in or open the report link again.']);
    exit;
}

function reportAccessKey(string $platform, string $period, string $asOf): string
{
    return strtolower($platform) . '|' . strtolower($period) . '|' . $asOf;
}

function reportHasLinkAccess(string $platform, string $period, string $asOf): bool
{
    $grants = $_SESSION['report_access'] ?? [];
    $key = reportAccessKey($platform, $period, $asOf);
    return is_array($grants) && isset($grants[$key]) && (int) $grants[$key] > time();
}

function reportGrantLinkAccess(string $platform, string $period, string $asOf): void
{
    $grants = is_array($_SESSION['report_access'] ?? null) ? $_SESSION['report_access'] : [];
    foreach ($grants as $k => $exp) {
        if ((int) $exp <= time()) {
            unset($grants[$k]);
        }
    }
    $grants[reportAccessKey($platform, $period, $asOf)] = time() + REPORT_ACCESS_TTL;
    $_SESSION['report_access'] = $grants;
}

/* ----------------------------------------------------------------------
 * Signed links
 * ---------------------------------------------------------------------- */

function reportSecret(): string
{
    if (!defined('REPORT_LINK_SECRET') || strlen((string) REPORT_LINK_SECRET) < 32) {
        throw new RuntimeException('REPORT_LINK_SECRET must be defined in config.php (at least 32 random characters).');
    }
    return (string) REPORT_LINK_SECRET;
}

function reportB64Encode(string $data): string
{
    return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
}

function reportB64Decode(string $data): string|false
{
    return base64_decode(strtr($data, '-_', '+/') . str_repeat('=', (4 - strlen($data) % 4) % 4), true);
}

/** Token bound to one recipient email, platform, period and as_of date. */
function reportMakeToken(string $platform, string $period, string $asOf, string $email, int $validDays): string
{
    $claims = [
        'p' => strtolower($platform),
        'r' => strtolower($period),
        'a' => $asOf,
        'e' => strtolower(trim($email)),
        'x' => time() + $validDays * 86400,
    ];
    $payload = reportB64Encode(json_encode($claims, JSON_UNESCAPED_SLASHES));
    $sig = reportB64Encode(hash_hmac('sha256', $payload, reportSecret(), true));
    return $payload . '.' . $sig;
}

/** Returns the token's claims, or null when the token is invalid, tampered with or expired. */
function reportReadToken(string $token): ?array
{
    $parts = explode('.', $token);
    if (count($parts) !== 2) {
        return null;
    }
    [$payload, $sig] = $parts;
    $expected = reportB64Encode(hash_hmac('sha256', $payload, reportSecret(), true));
    if (!hash_equals($expected, $sig)) {
        return null;
    }
    $json = reportB64Decode($payload);
    $claims = $json === false ? null : json_decode($json, true);
    if (!is_array($claims)) {
        return null;
    }
    if (!in_array($claims['p'] ?? '', ['meta', 'google'], true)
        || !in_array($claims['r'] ?? '', ['daily', 'weekly', 'monthly'], true)
        || !preg_match('/^\d{4}-\d{2}-\d{2}$/', (string) ($claims['a'] ?? ''))
        || !filter_var($claims['e'] ?? '', FILTER_VALIDATE_EMAIL)) {
        return null;
    }
    $claims['expired'] = (int) ($claims['x'] ?? 0) < time();
    return $claims;
}

function reportLinkUrl(string $token): string
{
    if (!defined('REPORT_BASE_URL') || trim((string) REPORT_BASE_URL) === '') {
        throw new RuntimeException('REPORT_BASE_URL must be defined in config.php (the URL of the folder containing report_view.php).');
    }
    return rtrim((string) REPORT_BASE_URL, '/') . '/report_view.php?t=' . rawurlencode($token);
}

/* ----------------------------------------------------------------------
 * OTP
 * ---------------------------------------------------------------------- */

function reportOtpHash(string $code, string $tokenId): string
{
    return hash_hmac('sha256', $tokenId . '|' . $code, reportSecret());
}

/** Per-link send counter stored on disk, so opening new browsers can't bypass the limit. */
function reportOtpSendAllowed(string $tokenId): bool
{
    $dir = CACHE_PATH;
    if (!is_dir($dir)) {
        @mkdir($dir, 0750, true);
    }
    $file = $dir . '/report_otp_' . substr(hash('sha256', $tokenId), 0, 32) . '.json';
    $now = time();
    $times = [];
    if (is_file($file)) {
        $times = json_decode((string) @file_get_contents($file), true) ?: [];
    }
    $times = array_values(array_filter($times, static fn($t): bool => (int) $t > $now - 3600));
    if (count($times) >= REPORT_OTP_MAX_PER_HR) {
        return false;
    }
    $times[] = $now;
    @file_put_contents($file, json_encode($times), LOCK_EX);
    return true;
}

function reportMaskEmail(string $email): string
{
    [$user, $domain] = array_pad(explode('@', $email, 2), 2, '');
    $shown = mb_substr($user, 0, min(2, mb_strlen($user)));
    return $shown . str_repeat('•', max(3, mb_strlen($user) - 2)) . '@' . $domain;
}
