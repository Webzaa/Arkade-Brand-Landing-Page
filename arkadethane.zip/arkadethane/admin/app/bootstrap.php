<?php
/**
 * app/bootstrap.php — loaded first by every page, API, cron job and library.
 * Defines the folder constants and loads config/config.php once.
 */
if (defined('BASE_PATH')) {
    return;
}

define('BASE_PATH', dirname(__DIR__));            // BeliciaAdmin/
define('APP_PATH', BASE_PATH . '/app');            // shared PHP code
define('CONFIG_PATH', BASE_PATH . '/config');
define('PUBLIC_PATH', BASE_PATH . '/public');      // web root
define('STORAGE_PATH', BASE_PATH . '/storage');    // writable: cache, logs, uploads
define('CACHE_PATH', STORAGE_PATH . '/cache');
define('LOG_PATH', STORAGE_PATH . '/logs');

require_once CONFIG_PATH . '/config.php';

date_default_timezone_set(defined('APP_TIMEZONE') ? APP_TIMEZONE : 'Asia/Kolkata');

foreach ([CACHE_PATH, LOG_PATH, STORAGE_PATH . '/meta_capi'] as $__dir) {
    if (!is_dir($__dir)) {
        @mkdir($__dir, 0775, true);
    }
}
unset($__dir);
