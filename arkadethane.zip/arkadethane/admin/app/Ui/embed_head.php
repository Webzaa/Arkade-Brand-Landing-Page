<?php
/**
 * Shared <head> snippet for the CRM / tool pages (index.php, analytics.php, meta_capi.php,
 * import.php, leads/users.php) so they work inside the PerformIQ shell (dashboard.php):
 *
 *   - Theme: reads 'performiq-theme' from localStorage (set by the shell's toggle) and keeps
 *     following it live. Standalone default is light (these pages' original look).
 *   - Embed: ?embed=1 hides the page's own sidebar / top navbar / footer — the shell
 *     provides navigation, the user menu (Add Users / Logout) and the theme toggle.
 *
 * Usage, just before </head>:  <?php include dirname(__DIR__) . '/app/Ui/embed_head.php'; ?>
 */
?>
  <script>
    (function () {
      var root = document.documentElement, t = null;
      try { t = localStorage.getItem('performiq-theme'); } catch (e) {}
      root.setAttribute('data-theme', t === 'dark' ? 'dark' : 'light');
      if (/[?&]embed=1(&|$)/.test(window.location.search)) root.classList.add('pq-embed');
      window.addEventListener('storage', function (e) {
        if (e.key === 'performiq-theme') root.setAttribute('data-theme', e.newValue === 'dark' ? 'dark' : 'light');
      });
    })();
  </script>
  <style>
    /* ===== Dark theme for CRM / tool pages (html[data-theme="dark"]) ===== */
    html[data-theme="dark"] {
      --app-bg: #0B0F1A;
      --surface: #111827;
      --border: #1E2A42;
      --text: #E2E8F0;
      --muted: #94A3B8;
      --green: #34D399;
      --green-soft: #10B98122;
      --green-border: #10B98155;
      --shadow: 0 8px 28px rgba(0, 0, 0, .35);
      color-scheme: dark;
    }
    html[data-theme="dark"] body,
    html[data-theme="dark"] .wrapper,
    html[data-theme="dark"] .main-panel,
    html[data-theme="dark"] .content { background: var(--app-bg) !important; color: var(--text); }

    html[data-theme="dark"] .sidebar,
    html[data-theme="dark"] .main-panel>.navbar,
    html[data-theme="dark"] .card,
    html[data-theme="dark"] .chart-card,
    html[data-theme="dark"] .tab,
    html[data-theme="dark"] .tabcontent,
    html[data-theme="dark"] .action-menu,
    html[data-theme="dark"] .dropdown-menu,
    html[data-theme="dark"] .modal-content,
    html[data-theme="dark"] .daterangepicker,
    html[data-theme="dark"] .daterangepicker .calendar-table,
    html[data-theme="dark"] #showRecords,
    html[data-theme="dark"] #showRecordsFollowup,
    html[data-theme="dark"] #showRecords tbody td,
    html[data-theme="dark"] #showRecordsFollowup tbody td {
      background: var(--surface) !important;
      color: var(--text) !important;
      border-color: var(--border) !important;
    }
    html[data-theme="dark"] #showRecords thead th,
    html[data-theme="dark"] #showRecordsFollowup thead th,
    html[data-theme="dark"] #showRecords tbody tr.child td,
    html[data-theme="dark"] .lead-detail-grid,
    html[data-theme="dark"] .lead-detail-item span,
    html[data-theme="dark"] .modal-header,
    html[data-theme="dark"] .modal-footer {
      background: #161D2E !important;
      color: var(--text) !important;
      border-color: var(--border) !important;
    }
    html[data-theme="dark"] #showRecords tbody tr:hover td,
    html[data-theme="dark"] #showRecordsFollowup tbody tr:hover td,
    html[data-theme="dark"] .lead-row:hover>td,
    html[data-theme="dark"] .lead-row.shown>td,
    html[data-theme="dark"] #showRecords tbody tr.lead-row.shown,
    html[data-theme="dark"] .action-menu button:hover,
    html[data-theme="dark"] .dropdown-item:hover,
    html[data-theme="dark"] .tab button:hover,
    html[data-theme="dark"] .tab button.active,
    html[data-theme="dark"] .sidebar .nav li a:hover { background: #1E2A42 !important; color: var(--text) !important; }

    html[data-theme="dark"] .form-control,
    html[data-theme="dark"] select,
    html[data-theme="dark"] input,
    html[data-theme="dark"] textarea,
    html[data-theme="dark"] .filter-field .form-control,
    html[data-theme="dark"] .filter-field select,
    html[data-theme="dark"] .dataTables_wrapper .dataTables_length select,
    html[data-theme="dark"] .dataTables_wrapper .dataTables_filter input {
      background: #0F172A !important;
      color: var(--text) !important;
      border-color: var(--border) !important;
    }
    html[data-theme="dark"] .btn-reset,
    html[data-theme="dark"] .action-btn,
    html[data-theme="dark"] .action-menu button,
    html[data-theme="dark"] .mobile-menu-btn,
    html[data-theme="dark"] .navbar .dropdown-toggle,
    html[data-theme="dark"] .dataTables_wrapper .dataTables_paginate .paginate_button {
      background: #161D2E !important;
      color: var(--text) !important;
      border-color: var(--border) !important;
    }
    html[data-theme="dark"] .btn-reset:hover,
    html[data-theme="dark"] .action-btn:hover,
    html[data-theme="dark"] .dataTables_wrapper .dataTables_paginate .paginate_button:hover { background: #1E2A42 !important; }

    html[data-theme="dark"] h1, html[data-theme="dark"] h2, html[data-theme="dark"] h3,
    html[data-theme="dark"] h4, html[data-theme="dark"] h5, html[data-theme="dark"] h6,
    html[data-theme="dark"] .lead-name,
    html[data-theme="dark"] .navbar-brand,
    html[data-theme="dark"] .dropdown-item,
    html[data-theme="dark"] .close,
    html[data-theme="dark"] label,
    html[data-theme="dark"] .dataTables_wrapper .dataTables_info,
    html[data-theme="dark"] .dataTables_wrapper .dataTables_length,
    html[data-theme="dark"] .dataTables_wrapper .dataTables_filter { color: var(--text) !important; }

    /* Web Analytics, Meta CAPI, Import Leads: their own cards */
    html[data-theme="dark"] .card-ui,
    html[data-theme="dark"] .kpi,
    html[data-theme="dark"] .analytics-filter-card,
    html[data-theme="dark"] .hourly-heatmap-card,
    html[data-theme="dark"] .capi-card,
    html[data-theme="dark"] .imp-card { background: var(--surface) !important; color: var(--text) !important; border: 1px solid var(--border); box-shadow: none !important; }
    html[data-theme="dark"] .hourly-heatmap-header { background: #1E2A42 !important; color: var(--text) !important; }
    html[data-theme="dark"] .capi-icon-box { background: #E84E2422 !important; }
    html[data-theme="dark"] .capi-back-btn,
    html[data-theme="dark"] .capi-badge { background: #161D2E !important; color: var(--text) !important; border-color: #2A3957 !important; }
    html[data-theme="dark"] .capi-card h2, html[data-theme="dark"] .capi-card h5,
    html[data-theme="dark"] .imp-label, html[data-theme="dark"] .analytics-filter-card label { color: var(--muted) !important; }
    html[data-theme="dark"] .src-option span { border-color: #2A3957 !important; color: var(--text) !important; background: #161D2E !important; }
    html[data-theme="dark"] .src-option input:checked + span { border-color: #E84E24 !important; background: #E84E241F !important; }
    html[data-theme="dark"] .src-hint, html[data-theme="dark"] .imp-stat small { color: var(--muted) !important; }
    html[data-theme="dark"] .imp-stat { background: #161D2E !important; }
    html[data-theme="dark"] .imp-stat.ok { background: #10B9811A !important; }
    html[data-theme="dark"] .imp-stat.dup { background: #F59E0B1A !important; }
    html[data-theme="dark"] .imp-table th { background: #161D2E !important; color: var(--muted) !important; }
    html[data-theme="dark"] .table, html[data-theme="dark"] .table td, html[data-theme="dark"] .table th { color: var(--text); border-color: var(--border) !important; }
    html[data-theme="dark"] .badge-Skipped { background: #1E2A42 !important; color: var(--muted) !important; }
    html[data-theme="dark"] input[type=checkbox], html[data-theme="dark"] input[type=radio] { accent-color: #E8A820; }

    /* Highcharts text/grid in dark */
    html[data-theme="dark"] .highcharts-background { fill: transparent !important; }
    html[data-theme="dark"] .highcharts-title,
    html[data-theme="dark"] .highcharts-subtitle,
    html[data-theme="dark"] .highcharts-axis-title,
    html[data-theme="dark"] .highcharts-axis-labels text,
    html[data-theme="dark"] .highcharts-axis-labels a,
    html[data-theme="dark"] .highcharts-legend-item text,
    html[data-theme="dark"] .highcharts-data-label text { fill: #CBD5E1 !important; color: #CBD5E1 !important; }
    html[data-theme="dark"] .highcharts-grid-line { stroke: #1E2A42 !important; }
    html[data-theme="dark"] .highcharts-axis-line,
    html[data-theme="dark"] .highcharts-tick { stroke: #334155 !important; }
    html[data-theme="dark"] .highcharts-contextbutton .highcharts-button-box { fill: transparent !important; }
    html[data-theme="dark"] .highcharts-menu { background: #161D2E !important; border-color: #1E2A42 !important; }
    html[data-theme="dark"] .highcharts-menu-item { color: #E2E8F0 !important; }
    html[data-theme="dark"] .highcharts-menu-item:hover { background: #1E2A42 !important; }
  </style>
  <style>
    /* ===== Embedded inside the PerformIQ shell ===== */
    html.pq-embed .sidebar,
    html.pq-embed .sidebar-overlay,
    html.pq-embed .main-panel > .navbar,
    html.pq-embed #footer,
    html.pq-embed .footer { display: none !important; }
    html.pq-embed .main-panel {
      width: 100% !important;
      margin-left: 0 !important;
      height: auto !important;
      min-height: 100vh;
      float: none !important;
    }
    html.pq-embed .wrapper { min-height: 0; }
    /* the shell shows the page title; its own Back buttons lead out of the shell */
    html.pq-embed .analytics_description,
    html.pq-embed a.actionBtn[href="index.php"],
    html.pq-embed .content h3.description,
    html.pq-embed .capi-back-btn { display: none !important; }
    /* no navbar above the content any more, so drop the gap reserved for it */
    html.pq-embed .main-panel > .content { margin-top: 0 !important; min-height: 0 !important; padding-top: 20px !important; }
  </style>
