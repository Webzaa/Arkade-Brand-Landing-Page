<?php
/**
 * app/Ads/keywords.php — Keyword Analysis (Google): every keyword and search term of this project's Google campaigns
 * with Google's numbers (impressions, clicks, cost, conversions, quality score) and the CRM's (leads, qualified,
 * site visits), plus "Insights & Actions" for the execution team (what to push, cut, add as keyword or negative).
 *
 *   kwData($since, $until)  → keywords, search_terms, totals, no_keyword (leads without a usable keyword), warnings
 *   kwInsights($data)       → findings [{id, type, severity, title, text, action, ref}]
 *
 * Leads → keyword: the lead's `keyword` column (Google's {keyword} ValueTrack value = the keyword that matched, not
 * the search term). It is matched to the keyword in the same ad group when the lead has one, else the busiest
 * keyword with the same text. "{keyword}" (the tag was not filled in) and empty values are counted separately.
 * Only leads under a saved Google campaign of this project count (same as the dashboards). Cached 10 minutes.
 */

require_once __DIR__ . '/portfolio_data.php';   // lead databases, lead → project campaign, qualified / site-visit statuses
require_once __DIR__ . '/google_sync.php';      // googleSearch()

const KW_CACHE_TTL = 600;
const KW_PLACEHOLDERS = ['{keyword}', '{keywordtext}', '{keyword:}', '(not set)', 'not set', 'none', 'null', '-', 'keyword'];

function kwCacheDir(): string
{
    $d = CACHE_PATH . '/keywords';
    if (!is_dir($d)) {
        @mkdir($d, 0775, true);
    }
    return $d;
}

/** Keyword text as typed in Google or captured on a lead: lower case, no match-type marks, single spaces. */
function kwNorm(string $k): string
{
    $k = strtolower(trim(rawurldecode(str_replace('+', ' ', $k))));
    $k = trim($k, " \t\"'[]");
    return trim((string) preg_replace('/\s+/', ' ', $k));
}

function kwIsPlaceholder(string $norm): bool
{
    return $norm === '' || in_array($norm, KW_PLACEHOLDERS, true) || str_starts_with($norm, '{');
}

function kwDiv($a, $b, float $m = 1): ?float
{
    return ($b ?? 0) > 0 ? round((float) $a / (float) $b * $m, 2) : null;
}

/** Adds CTR, CPC, CPL, CPQL, CPSV, conversion rate; cost metrics are null when nothing was spent. */
function kwMetrics(array $r): array
{
    $sp = (float) ($r['spend'] ?? 0);
    $r['spend'] = round($sp, 2);
    $r['ctr'] = kwDiv($r['clicks'] ?? 0, $r['impressions'] ?? 0, 100);
    $r['cpc'] = $sp > 0 ? kwDiv($sp, $r['clicks'] ?? 0) : null;
    $r['cpl'] = $sp > 0 ? kwDiv($sp, $r['leads'] ?? 0) : null;
    $r['cpql'] = $sp > 0 ? kwDiv($sp, $r['ql'] ?? 0) : null;
    $r['cpsv'] = $sp > 0 ? kwDiv($sp, $r['sv'] ?? 0) : null;
    $r['ql_pct'] = kwDiv($r['ql'] ?? 0, $r['leads'] ?? 0, 100);
    $r['lead_rate'] = kwDiv($r['leads'] ?? 0, $r['clicks'] ?? 0, 100);
    return $r;
}

/** 'running' when the keyword, its ad group and its campaign are all on, else 'paused'. */
function kwState(string ...$statuses): string
{
    foreach ($statuses as $s) {
        $s = strtoupper(trim($s));
        if ($s !== '' && $s !== 'ENABLED') {
            return 'paused';
        }
    }
    return 'running';
}

/** Google keywords of this project's campaigns in the period (keyword_view). */
function kwGoogleKeywords(string $since, string $until): array
{
    $rows = googleSearch("SELECT campaign.id, campaign.name, campaign.status, ad_group.id, ad_group.name, ad_group.status,
            ad_group_criterion.criterion_id, ad_group_criterion.keyword.text, ad_group_criterion.keyword.match_type,
            ad_group_criterion.status, ad_group_criterion.quality_info.quality_score,
            metrics.impressions, metrics.clicks, metrics.cost_micros, metrics.conversions
        FROM keyword_view
        WHERE segments.date BETWEEN '{$since}' AND '{$until}' AND metrics.impressions > 0");
    $out = [];
    foreach ($rows as $r) {
        $cid = (string) ($r['campaign']['id'] ?? '');
        if ($cid === '' || !isProjectCampaign('google', $cid)) {
            continue;
        }
        $gid = (string) ($r['adGroup']['id'] ?? '');
        $kid = (string) ($r['adGroupCriterion']['criterionId'] ?? '');
        $key = $gid . '~' . $kid;
        $m = $r['metrics'] ?? [];
        $o = &$out[$key];
        $o ??= [
            'id' => $key, 'text' => (string) ($r['adGroupCriterion']['keyword']['text'] ?? ''),
            'match' => (string) ($r['adGroupCriterion']['keyword']['matchType'] ?? ''),
            'status' => (string) ($r['adGroupCriterion']['status'] ?? ''),
            'qs' => isset($r['adGroupCriterion']['qualityInfo']['qualityScore']) ? (int) $r['adGroupCriterion']['qualityInfo']['qualityScore'] : null,
            'campaign_id' => $cid, 'campaign' => (string) (projectStructure('google')['campaigns'][$cid] ?? ($r['campaign']['name'] ?? $cid)),
            'campaign_status' => (string) ($r['campaign']['status'] ?? ''),
            'adgroup_id' => $gid, 'adgroup' => (string) ($r['adGroup']['name'] ?? $gid), 'adgroup_status' => (string) ($r['adGroup']['status'] ?? ''),
            'impressions' => 0, 'clicks' => 0, 'spend' => 0.0, 'conversions' => 0.0, 'leads' => 0, 'ql' => 0, 'sv' => 0,
        ];
        $o['impressions'] += (int) ($m['impressions'] ?? 0);
        $o['clicks'] += (int) ($m['clicks'] ?? 0);
        $o['spend'] += ((int) ($m['costMicros'] ?? 0)) / 1e6;
        $o['conversions'] += (float) ($m['conversions'] ?? 0);
        unset($o);
    }
    foreach ($out as &$o) {
        $o['norm'] = kwNorm($o['text']);
        $o['state'] = kwState($o['status'], $o['adgroup_status'], $o['campaign_status']);
    }
    unset($o);
    return $out;
}

/** What people actually searched (search_term_view), for this project's campaigns. */
function kwGoogleSearchTerms(string $since, string $until): array
{
    $rows = googleSearch("SELECT search_term_view.search_term, search_term_view.status, segments.keyword.info.text,
            segments.keyword.info.match_type, campaign.id, ad_group.id, ad_group.name,
            metrics.impressions, metrics.clicks, metrics.cost_micros, metrics.conversions
        FROM search_term_view
        WHERE segments.date BETWEEN '{$since}' AND '{$until}' AND metrics.impressions > 0");
    $out = [];
    foreach ($rows as $r) {
        $cid = (string) ($r['campaign']['id'] ?? '');
        if ($cid === '' || !isProjectCampaign('google', $cid)) {
            continue;
        }
        $term = (string) ($r['searchTermView']['searchTerm'] ?? '');
        $gid = (string) ($r['adGroup']['id'] ?? '');
        $key = $gid . '~' . kwNorm($term);
        $m = $r['metrics'] ?? [];
        $o = &$out[$key];
        $o ??= [
            'id' => $key, 'term' => $term, 'norm' => kwNorm($term), 'status' => (string) ($r['searchTermView']['status'] ?? ''),
            'keyword' => (string) ($r['segments']['keyword']['info']['text'] ?? ''), 'match' => (string) ($r['segments']['keyword']['info']['matchType'] ?? ''),
            'campaign_id' => $cid, 'campaign' => (string) (projectStructure('google')['campaigns'][$cid] ?? $cid),
            'adgroup_id' => $gid, 'adgroup' => (string) ($r['adGroup']['name'] ?? $gid),
            'impressions' => 0, 'clicks' => 0, 'spend' => 0.0, 'conversions' => 0.0,
        ];
        $o['impressions'] += (int) ($m['impressions'] ?? 0);
        $o['clicks'] += (int) ($m['clicks'] ?? 0);
        $o['spend'] += ((int) ($m['costMicros'] ?? 0)) / 1e6;
        $o['conversions'] += (float) ($m['conversions'] ?? 0);
        unset($o);
    }
    return $out;
}

/**
 * CRM leads of this project's Google campaigns in the period, one per person (last 10 digits of the mobile):
 * [{keyword (normalised), adgroup_id, ql, sv, n}]. A person counts once, under their first lead's keyword;
 * qualified / site visit when any of their leads is.
 */
function kwLeads(string $since, string $until): array
{
    $people = [];
    $s = $since . ' 00:00:00';
    $u = $until . ' 23:59:59';
    foreach (pfLeadConns() as $dbName => $db) {
        // SELECT *: lead databases differ a little in columns (a missing optional one must not drop every lead)
        $st = $db->prepare('SELECT * FROM `lead` WHERE createddate >= ? AND createddate <= ? ORDER BY createddate, id');
        if (!$st) {
            continue;
        }
        $st->bind_param('ss', $s, $u);
        $st->execute();
        $res = $st->get_result();
        while ($l = $res->fetch_assoc()) {
            if (umIsTestLead($l) || umPlatformOf($l) !== 'google' || strtolower(trim((string) $l['campaignsource'])) === 'website') {
                continue;
            }
            $key = pfGoogleKey($l);
            if ($key === null) {
                continue;   // not under one of this project's Google campaigns
            }
            $ql = in_array(strtoupper(trim((string) $l['lead_status'])), SU_QUALIFIED_VALUES, true);
            $sv = in_array(strtoupper(trim((string) $l['sitevisit_status'])), SU_SITEVISIT_VALUES, true);
            $mob = umNormMobile($l['mobile'] ?? '');
            $pk = strlen($mob) >= 6 ? $mob : $dbName . '#' . $l['id'];
            $kw = kwNorm((string) ($l['keyword'] ?? ''));
            if (!isset($people[$pk])) {
                $people[$pk] = ['keyword' => $kw, 'raw' => trim((string) ($l['keyword'] ?? '')), 'campaign_id' => $key[0], 'adgroup_id' => $key[1], 'ql' => $ql, 'sv' => $sv, 'n' => 1];
            } else {
                $p = &$people[$pk];
                $p['n']++;
                if (kwIsPlaceholder($p['keyword']) && !kwIsPlaceholder($kw)) {   // a later lead of the same person with a real keyword wins
                    [$p['keyword'], $p['raw'], $p['campaign_id'], $p['adgroup_id']] = [$kw, trim((string) $l['keyword']), $key[0], $key[1]];
                }
                $p['ql'] = $p['ql'] || $ql;
                $p['sv'] = $p['sv'] || $sv;
                unset($p);
            }
        }
        $st->close();
    }
    return array_values($people);
}

/** Everything for the page (cached 10 minutes; ?force=1 skips the cache). */
function kwData(string $since, string $until, bool $force = false): array
{
    $view = pqCampaignView();   // All / Performance / Awareness tab + Users & Roles → Campaign types
    $file = kwCacheDir() . '/kw_' . md5($since . '|' . $until . '|' . (function_exists('appDbKey') ? appDbKey() : '') . '|' . $view) . '.json';
    if (!$force && is_file($file) && filemtime($file) > time() - KW_CACHE_TTL) {
        $c = json_decode((string) @file_get_contents($file), true);
        if (is_array($c)) {
            return $c;
        }
    }
    $warnings = [];
    $configured = googleAdsConfigured();
    $kws = $terms = [];
    if (!$configured) {
        $warnings[] = 'Google Ads is not connected (config.php), so only the CRM leads by keyword are shown.';
    } else {
        try {
            $kws = kwGoogleKeywords($since, $until);
        } catch (Throwable $e) {
            $warnings[] = 'Google keywords: ' . $e->getMessage();
        }
        try {
            $terms = kwGoogleSearchTerms($since, $until);
        } catch (Throwable $e) {
            $warnings[] = 'Google search terms: ' . $e->getMessage();
        }
    }

    // only the campaigns of the tab (and that the role may see)
    if ($view !== 'all') {
        $shows = fn($r) => pqViewShows(pqCampaignType('google', (string) ($r['campaign_id'] ?? '')), $view);
        $kws = array_filter($kws, $shows);
        $terms = array_filter($terms, $shows);
    }

    // leads → keyword rows: same ad group + same text, else the busiest keyword with that text, else a CRM-only row
    $byText = [];
    foreach ($kws as $k => $r) {
        $byText[$r['norm']][] = $k;
    }
    foreach ($byText as &$list) {
        usort($list, fn($a, $b) => $kws[$b]['clicks'] <=> $kws[$a]['clicks']);
    }
    unset($list);
    $noKw = ['leads' => 0, 'ql' => 0, 'sv' => 0, 'placeholder' => 0, 'empty' => 0];
    $leadTotal = ['leads' => 0, 'ql' => 0, 'sv' => 0];
    $people = kwLeads($since, $until);
    if ($view !== 'all') {
        $people = array_filter($people, fn($p) => pqViewShows(pqCampaignType('google', (string) $p['campaign_id']), $view));
    }
    foreach ($people as $p) {
        $c = ['leads' => 1, 'ql' => $p['ql'] ? 1 : 0, 'sv' => $p['sv'] ? 1 : 0];
        foreach ($c as $f => $v) {
            $leadTotal[$f] += $v;
        }
        if (kwIsPlaceholder($p['keyword'])) {
            foreach ($c as $f => $v) {
                $noKw[$f] += $v;
            }
            $noKw[$p['raw'] === '' ? 'empty' : 'placeholder']++;
            continue;
        }
        $target = null;
        foreach ($byText[$p['keyword']] ?? [] as $k) {
            if ($p['adgroup_id'] !== '' && $kws[$k]['adgroup_id'] === $p['adgroup_id']) {
                $target = $k;
                break;
            }
        }
        $target ??= ($byText[$p['keyword']][0] ?? null);
        if ($target === null) {   // keyword on the lead but not in Google's list for these dates (paused / removed / no impressions)
            $target = 'crm~' . $p['keyword'];
            $sg = projectStructure('google');
            $kws[$target] ??= ['id' => $target, 'text' => $p['raw'] !== '' ? $p['raw'] : $p['keyword'], 'norm' => $p['keyword'], 'match' => '', 'status' => '', 'qs' => null,
                'campaign_id' => $p['campaign_id'], 'campaign' => (string) ($sg['campaigns'][$p['campaign_id']] ?? $p['campaign_id']), 'campaign_status' => '',
                'adgroup_id' => $p['adgroup_id'], 'adgroup' => (string) ($sg['adgroups'][$p['adgroup_id']]['name'] ?? ''), 'adgroup_status' => '',
                'impressions' => 0, 'clicks' => 0, 'spend' => 0.0, 'conversions' => 0.0, 'leads' => 0, 'ql' => 0, 'sv' => 0, 'state' => 'unknown', 'crm_only' => true];
        }
        foreach ($c as $f => $v) {
            $kws[$target][$f] += $v;
        }
    }

    $kwOut = [];
    $t = ['impressions' => 0, 'clicks' => 0, 'spend' => 0.0, 'conversions' => 0.0];
    foreach ($kws as $r) {
        foreach ($t as $f => $_) {
            $t[$f] += $r[$f];
        }
        $r['conversions'] = round($r['conversions'], 2);
        $kwOut[] = kwMetrics($r);
    }
    usort($kwOut, fn($a, $b) => [$b['spend'], $b['leads']] <=> [$a['spend'], $a['leads']]);

    $kwTexts = [];
    foreach ($kws as $r) {
        $kwTexts[$r['norm']] = true;
    }
    $termOut = [];
    foreach ($terms as $r) {
        $r['is_keyword'] = isset($kwTexts[$r['norm']]) || in_array(strtoupper($r['status']), ['ADDED', 'ADDED_EXCLUDED'], true);
        $r['excluded'] = in_array(strtoupper($r['status']), ['EXCLUDED', 'ADDED_EXCLUDED'], true);
        $r['conversions'] = round($r['conversions'], 2);
        $termOut[] = kwMetrics($r);
    }
    usort($termOut, fn($a, $b) => $b['spend'] <=> $a['spend']);

    $total = kwMetrics($t + $leadTotal);
    $total['conversions'] = round($t['conversions'], 2);
    $total['keywords'] = count(array_filter($kwOut, fn($r) => empty($r['crm_only'])));
    $total['search_terms'] = count($termOut);
    $out = ['since' => $since, 'until' => $until, 'configured' => $configured, 'total' => $total,
            'keywords' => $kwOut, 'search_terms' => $termOut, 'no_keyword' => $noKw, 'warnings' => $warnings];
    if (!$warnings) {
        @file_put_contents($file, json_encode($out, JSON_UNESCAPED_UNICODE | JSON_PARTIAL_OUTPUT_ON_ERROR), LOCK_EX);
    }
    return $out;
}

/**
 * Insights & Actions from fixed rules (no AI): numbers come straight from the data.
 * Benchmarks: the account's CPL and CPQL for these dates (keywords with leads).
 */
function kwInsights(array $d, array $hidden = []): array
{
    $t = $d['total'];
    $cpl = $t['cpl'];
    $cpql = in_array('qualified', $hidden, true) || in_array('cpql', $hidden, true) ? null : $t['cpql'];
    $showQl = !in_array('qualified', $hidden, true);
    $money = fn($v) => $v === null ? '—' : '₹' . number_format((float) round($v), 0, '.', ',');
    $f = [];
    $add = function (array $x) use (&$f) {
        $x['id'] = 'k' . count($f);
        $f[] = $x;
    };
    $kw = array_values(array_filter($d['keywords'], fn($r) => empty($r['crm_only'])));
    $where = fn($r) => $r['campaign'] . ($r['adgroup'] !== '' ? ' › ' . $r['adgroup'] : '');
    $label = fn($r) => '"' . $r['text'] . '"' . ($r['match'] !== '' ? ' (' . strtolower($r['match']) . ')' : '');

    // 1. spending without leads
    $floor = max(1000.0, ($cpl ?? 0) * 1.5);
    $waste = array_filter($kw, fn($r) => $r['spend'] >= $floor && $r['leads'] === 0);
    usort($waste, fn($a, $b) => $b['spend'] <=> $a['spend']);
    foreach (array_slice($waste, 0, 4) as $r) {
        $add(['type' => 'waste', 'severity' => 'bad', 'ref' => $r['id'], 'tab' => 'keywords',
              'title' => 'No leads from ' . $label($r),
              'text' => $money($r['spend']) . ' spent, ' . number_format($r['clicks']) . ' clicks, 0 leads (' . $where($r) . ').',
              'action' => 'Lower its bid or pause it, and check its search terms for the wrong intent (add those as negatives).']);
    }
    // 2. best keywords: cheap leads / cheap qualified leads
    // (with qualified numbers shown: 3+ leads and none qualified is not a winner — rule 3 flags it instead)
    $best = array_filter($kw, fn($r) => $r['leads'] >= 2 && $r['cpl'] !== null && $cpl !== null && $r['cpl'] <= $cpl * 0.7
        && !($showQl && $r['leads'] >= 3 && ($r['ql'] ?? 0) === 0));
    if ($showQl && $cpql !== null) {
        $best += array_filter($kw, fn($r) => $r['ql'] >= 1 && $r['cpql'] !== null && $r['cpql'] <= $cpql * 0.8);
    }
    usort($best, fn($a, $b) => [$b['ql'], $b['leads']] <=> [$a['ql'], $a['leads']]);
    foreach (array_slice($best, 0, 4) as $r) {
        $add(['type' => 'winner', 'severity' => 'good', 'ref' => $r['id'], 'tab' => 'keywords',
              'title' => 'Push ' . $label($r),
              'text' => $r['leads'] . ' leads at ' . $money($r['cpl']) . ' CPL' . ($cpl !== null ? ' (account ' . $money($cpl) . ')' : '')
                  . ($showQl ? ', ' . $r['ql'] . ' qualified' . ($cpql !== null && $r['cpql'] !== null ? ' at ' . $money($r['cpql']) . ' CPQL' : '') : '') . '.',
              'action' => 'Raise its bid / budget share' . (strtoupper($r['match']) !== 'EXACT' ? ' and add it as an exact-match keyword' : '') . '; write ads around this search.']);
    }
    // 3. leads but none qualified
    if ($showQl) {
        $junk = array_filter($kw, fn($r) => $r['leads'] >= 3 && $r['ql'] === 0);
        usort($junk, fn($a, $b) => $b['leads'] <=> $a['leads']);
        foreach (array_slice($junk, 0, 3) as $r) {
            $add(['type' => 'junk', 'severity' => 'warn', 'ref' => $r['id'], 'tab' => 'keywords',
                  'title' => 'Leads but none qualified: ' . $label($r),
                  'text' => $r['leads'] . ' leads, 0 qualified, ' . $money($r['spend']) . ' spent.',
                  'action' => 'Check the intent of its search terms; tighten the match type or move budget to keywords that qualify.']);
        }
    }
    // 4. low quality score with real spend
    $lowQs = array_filter($kw, fn($r) => $r['qs'] !== null && $r['qs'] <= 4 && $r['spend'] >= 500);
    usort($lowQs, fn($a, $b) => $b['spend'] <=> $a['spend']);
    foreach (array_slice($lowQs, 0, 3) as $r) {
        $add(['type' => 'quality', 'severity' => 'warn', 'ref' => $r['id'], 'tab' => 'keywords',
              'title' => 'Quality score ' . $r['qs'] . '/10: ' . $label($r),
              'text' => $money($r['spend']) . ' spent at ' . $money($r['cpc']) . ' a click (' . $where($r) . ').',
              'action' => 'Put the keyword in the ad headlines and on the landing page, or move it to its own ad group — a better score lowers the cost per click.']);
    }
    // 5. search terms (added up over ad groups): spend with no conversion → negative; converting terms that are not keywords → add
    $terms = [];
    foreach ($d['search_terms'] as $r) {
        $t0 = &$terms[$r['norm']];
        $t0 ??= ['id' => $r['id'], 'term' => $r['term'], 'spend' => 0.0, 'clicks' => 0, 'conversions' => 0.0, 'is_keyword' => false, 'excluded' => false];
        $t0['spend'] += $r['spend'];
        $t0['clicks'] += $r['clicks'];
        $t0['conversions'] += $r['conversions'];
        $t0['is_keyword'] = $t0['is_keyword'] || $r['is_keyword'];
        $t0['excluded'] = $t0['excluded'] || $r['excluded'];
        unset($t0);
    }
    $neg = array_filter($terms, fn($r) => !$r['is_keyword'] && !$r['excluded'] && $r['conversions'] <= 0 && $r['spend'] >= max(500.0, ($cpl ?? 0) * 0.75));
    usort($neg, fn($a, $b) => $b['spend'] <=> $a['spend']);
    if ($neg) {
        $top = array_slice($neg, 0, 5);
        $add(['type' => 'negatives', 'severity' => 'bad', 'ref' => $top[0]['id'], 'tab' => 'terms',
              'title' => count($neg) . ' search term' . (count($neg) === 1 ? '' : 's') . ' to add as negatives',
              'text' => implode(', ', array_map(fn($r) => '"' . $r['term'] . '" ' . $money($r['spend']), $top)) . ' — no conversion.',
              'action' => 'Add the ones that are not about this project as negative keywords.']);
    }
    $addKw = array_filter($terms, fn($r) => !$r['is_keyword'] && !$r['excluded'] && $r['conversions'] >= 1);
    usort($addKw, fn($a, $b) => $b['conversions'] <=> $a['conversions']);
    if ($addKw) {
        $top = array_slice($addKw, 0, 5);
        $add(['type' => 'add_kw', 'severity' => 'good', 'ref' => $top[0]['id'], 'tab' => 'terms',
              'title' => count($addKw) . ' converting search term' . (count($addKw) === 1 ? '' : 's') . ' to add as keywords',
              'text' => implode(', ', array_map(fn($r) => '"' . $r['term'] . '" ' . rtrim(rtrim(number_format($r['conversions'], 1), '0'), '.') . ' conversions', $top)) . '.',
              'action' => 'Add them as exact / phrase-match keywords so they get their own bid and ads.']);
    }
    // 6. tracking: leads that came without a keyword
    $nk = $d['no_keyword'];
    if ($nk['leads'] > 0 && $t['leads'] > 0) {
        $share = round($nk['leads'] / $t['leads'] * 100);
        $add(['type' => 'tracking', 'severity' => $share >= 25 ? 'warn' : 'info', 'ref' => null, 'tab' => null,
              'title' => $nk['leads'] . ' Google lead' . ($nk['leads'] === 1 ? '' : 's') . ' (' . $share . '%) came without a keyword',
              'text' => ($nk['placeholder'] ? $nk['placeholder'] . ' arrived as "{keyword}" (the tag was not filled in)' : '')
                  . ($nk['placeholder'] && $nk['empty'] ? ', ' : '') . ($nk['empty'] ? $nk['empty'] . ' with no keyword at all' : '') . '.',
              'action' => 'Check the final URL suffix / tracking template has keyword={keyword}; Performance Max and Display ads never pass a keyword.']);
    }
    return $f;
}
