<?php
/**
 * app/Ads/portfolio_data.php — data for the portfolio PDF ("Export PDF (Meta + Google)").
 *
 * One month at a time:
 *   spend / impressions / clicks — Meta ads insights (fetchAdsPivotSpend) and the Google pivot report
 *                                  (googleapi.php?action=fetch_pivot_report), both already limited to
 *                                  the campaigns / ad sets / ads saved for this project;
 *   leads / qualified / site visits — straight from the lead table(s), each lead put under its saved
 *                                  campaign → ad set / ad group → ad (by ID first, then by name).
 * So the report shows the same campaigns and the same lead counts as the dashboards, with the names
 * saved in the database. Leads that can't be placed are counted separately as "unmapped".
 */

require_once __DIR__ . '/fetch_meta.php';                     // fetchAdsPivotSpend + master_tables.php
require_once dirname(__DIR__) . '/Leads/unmapped.php';         // umPlatformOf / umIsTestLead
require_once dirname(__DIR__) . '/Leads/status_upload.php';    // SU_QUALIFIED_VALUES / SU_SITEVISIT_VALUES

const PF_NO_GROUP = '(ad set / ad group not known)';
const PF_NO_AD = '(ad not known)';

/** Lead databases the report reads: PORTFOLIO_REPORT_DB when set, else all of them (like the dashboards). */
function pfLeadConns(): array
{
    if (defined('PORTFOLIO_REPORT_DB') && ($db = leadDb((string) PORTFOLIO_REPORT_DB))) {
        return [(string) PORTFOLIO_REPORT_DB => $db];
    }
    return leadDbs('all');
}

function pfIncludeTaboola(): bool
{
    return defined('PORTFOLIO_INCLUDE_TABOOLA') && PORTFOLIO_INCLUDE_TABOOLA;
}

/** POST to another API of this admin (same login cookie + internal key). */
function pfInternalApi(string $script, array $body): array
{
    $urls = [];
    if (defined('APP_URL') && APP_URL !== '') {
        $urls[] = rtrim(APP_URL, '/') . '/ads/' . $script;
    }
    if (!empty($_SERVER['HTTP_HOST'])) {
        $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
        $dir = rtrim(str_replace('\\', '/', dirname((string) ($_SERVER['SCRIPT_NAME'] ?? '/ads/x.php'))), '/');
        $urls[] = "{$scheme}://{$_SERVER['HTTP_HOST']}{$dir}/{$script}";
    }
    $last = 'no URL';
    foreach (array_unique($urls) as $url) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => json_encode($body),
            CURLOPT_HTTPHEADER => ['Content-Type: application/json', 'X-PQ-Internal: ' . pqInternalKey()],
            CURLOPT_TIMEOUT => 120,
            CURLOPT_CONNECTTIMEOUT => 8,
            CURLOPT_SSL_VERIFYPEER => false,   // the server calling itself
            CURLOPT_COOKIE => (string) ($_SERVER['HTTP_COOKIE'] ?? ''),
        ]);
        $res = curl_exec($ch);
        $err = curl_error($ch);
        $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        unset($ch);
        $json = is_string($res) ? json_decode($res, true) : null;
        if (is_array($json)) {
            return $json;
        }
        $last = $err ?: "HTTP {$code}";
    }
    return ['error' => "Could not read {$script} ({$last})"];
}

/** Pseudo campaign id for Meta leads that are not under one of this project's campaigns. */
const PF_UNMAPPED = '__unmapped';

/**
 * Count Meta / Google leads that are not under a project campaign on the dashboards (Meta → "Unmapped leads" row,
 * Google → "Website / Direct"). config: define('DASHBOARD_COUNT_UNMAPPED', false) → leave them out (old behaviour).
 * Leads with no source at all are never counted — they stay in Unmapped Leads until a platform is chosen.
 */
function pfCountUnmapped(): bool
{
    return !defined('DASHBOARD_COUNT_UNMAPPED') || DASHBOARD_COUNT_UNMAPPED;
}

/** Leads = every form entry (default) or one per person: define('DASHBOARD_LEADS_AS_PEOPLE', true). */
function pfLeadsAsPeople(): bool
{
    return defined('DASHBOARD_LEADS_AS_PEOPLE') && DASHBOARD_LEADS_AS_PEOPLE;
}

/** [campaign id, ad set id|'', ad id|''] of a saved Meta campaign, or null. */
function pfMetaKey(array $l): ?array
{
    $s = projectStructure('meta');
    $adId = pqCleanTrack($l['ad_id'] ?? '');
    if ($adId !== '' && isset($s['ads'][$adId])) {
        $gid = (string) $s['ads'][$adId]['adgroup_id'];
        return [(string) $s['adgroups'][$gid]['campaign_id'], $gid, $adId];
    }
    $name = pqCleanTrack($l['campaign_name'] ?? '');
    $cid = projectCampaignId('meta', null, $name !== '' ? $name : pqCleanTrack($l['utm_campaignname'] ?? ''));
    if ($cid === null) {
        return null;
    }
    $gid = (string) (projectAdgroupId('meta', $cid, null, (string) ($l['adset_name'] ?? '')) ?? '');
    $aid = $gid !== '' ? (string) (projectAdId('meta', $gid, null, (string) ($l['ad_name'] ?? '')) ?? '') : '';
    return [$cid, $gid, $aid];
}

/** Same for Google (utm_* columns). */
function pfGoogleKey(array $l): ?array
{
    $cid = projectCampaignId('google', pqCleanTrack($l['utm_campaignid'] ?? ''), pqCleanTrack($l['utm_campaignname'] ?? ''));
    if ($cid === null) {
        return null;
    }
    $gid = (string) (projectAdgroupId('google', $cid, (string) ($l['utm_adgroupid'] ?? ''), (string) ($l['utm_adgroupname'] ?? '')) ?? '');
    $aid = $gid !== '' ? (string) (projectAdId('google', $gid, (string) ($l['utm_adid'] ?? ''), (string) ($l['utm_adname'] ?? '')) ?? '') : '';
    return [$cid, $gid, $aid];
}

function pfBlank(): array
{
    return ['impressions' => 0, 'clicks' => 0, 'spend' => 0.0, 'leads' => 0, 'ql' => 0, 'sv_done' => 0];
}

function pfAdd(array &$a, array $b): void
{
    foreach (['impressions', 'clicks', 'spend', 'leads', 'ql', 'sv_done'] as $k) {
        $a[$k] += $b[$k] ?? 0;
    }
}

function pfRow(string $platform, string $type, string $name, int $level, array $m): array
{
    $r = ['platform' => $platform, 'type' => $type, 'name' => $name, 'level' => $level] + $m;
    $r['spend'] = round((float) $r['spend'], 2);
    $r['ctr'] = $r['impressions'] > 0 ? round($r['clicks'] / $r['impressions'] * 100, 2) : 0.0;
    $r['cpl'] = $r['leads'] > 0 ? round($r['spend'] / $r['leads'], 2) : 0.0;
    $r['ql_pct'] = $r['leads'] > 0 ? round($r['ql'] / $r['leads'] * 100, 2) : 0.0;
    $r['cpql'] = $r['ql'] > 0 ? round($r['spend'] / $r['ql'], 2) : 0.0;
    $r['cpsv'] = $r['sv_done'] > 0 ? round($r['spend'] / $r['sv_done'], 2) : 0.0;
    return $r;
}

/** Lead status bucket for the disposition table. */
function pfDisposition(?string $status): string
{
    $u = strtoupper(trim((string) $status));
    if (in_array($u, SU_QUALIFIED_VALUES, true)) {
        return 'QUALIFIED';
    }
    if (in_array($u, ['NON-QUALIFIED', 'NON QUALIFIED', 'NOT QUALIFIED', 'UNQUALIFIED', 'DISQUALIFIED'], true)) {
        return 'NON-QUALIFIED';
    }
    if (in_array($u, ['TO BE QUALIFIED', 'TBQ'], true)) {
        return 'TO BE QUALIFIED';
    }
    return 'NOT SET / OTHER';
}

/**
 * One period of the report.
 * Leads are counted as PEOPLE: one person per platform (last 10 digits of the mobile, else the lead id) in the
 * period. A person who filled the form twice counts once, under the campaign of their first lead, and is
 * Qualified / has a site visit when any of their leads is.
 * $withSpend = false skips the Meta / Google spend calls (lead counts only — used by the Overview).
 * $only = null → every campaign; else ['Meta' => [campaign ids], 'Google' => [ids]]: only those campaigns (report
 * downloads → "Select campaigns"). Leads outside them — other campaigns, Website / Direct, unmapped — are left out.
 * @return array{rows: array, total: array, disposition: array, unmapped: array, warnings: array, entries: int}
 */
function pfPeriod(string $since, string $until, array $conns, bool $withSpend = true, ?array $only = null): array
{
    $onlySet = null;
    if ($only !== null) {
        $onlySet = [];
        foreach (['Meta', 'Google'] as $P) {
            $onlySet[$P] = array_fill_keys(array_map('strval', (array) ($only[$P] ?? [])), true);
        }
    }
    $kept = fn($place): bool => $onlySet === null
        || (is_array($place) && isset($onlySet[$place[0]][(string) $place[1]]));
    // All / Performance / Awareness tab (cookie pq_view) + Users & Roles → Campaign types
    $view = function_exists('pqCampaignView') ? pqCampaignView() : 'all';
    $shown = function ($place) use ($view): bool {
        if ($view === 'all') {
            return true;
        }
        if (!is_array($place) || $place[1] === PF_UNMAPPED || (string) $place[1] === '') {
            return pqViewShows('performance', $view);   // Website / Direct, unmapped
        }
        return pqViewShows(pqCampaignType($place[0] === 'Meta' ? 'meta' : 'google', (string) $place[1]), $view);
    };
    $warnings = [];
    // tree[platform][cid][gid][aid] = metrics
    $tree = ['Meta' => [], 'Google' => [], 'Taboola' => []];
    $leaf = function (string $p, string $c, string $g, string $a) use (&$tree): array {
        return $tree[$p][$c][$g][$a] ?? pfBlank();
    };

    // 1. spend — Meta
    $meta = $withSpend ? fetchAdsPivotSpend(null, $since, $until) : [];
    if (!empty($meta['api_error'])) {
        $warnings[] = 'Meta spend: ' . (is_array($meta['api_error']) ? ($meta['api_error']['message'] ?? 'API error') : $meta['api_error']);
    }
    $metaFreq = [];   // ad id → frequency (Creatives & Insights: creative fatigue)
    foreach ($meta['rows'] ?? [] as $r) {
        [$c, $g, $a] = [(string) $r['campaign_id'], (string) ($r['adset_id'] ?? ''), (string) ($r['ad_id'] ?? '')];
        if ($a !== '') {
            $metaFreq[$a] = (float) ($r['frequency'] ?? 0);
        }
        $m = $leaf('Meta', $c, $g, $a);
        pfAdd($m, ['impressions' => (int) $r['impressions'], 'clicks' => (int) $r['clicks'], 'spend' => (float) $r['spend']]);
        $tree['Meta'][$c][$g][$a] = $m;
    }
    // 1b. spend — Google
    $gp = $withSpend ? pfInternalApi('googleapi.php?action=fetch_pivot_report', ['since' => $since, 'until' => $until]) : ['rows' => []];
    if (isset($gp['error']) && empty($gp['rows'])) {
        $warnings[] = 'Google spend: ' . (is_array($gp['error']) ? ($gp['error']['message'] ?? 'error') : $gp['error']);
    }
    foreach ($gp['rows'] ?? [] as $r) {
        $c = (string) ($r['campaign_id'] ?? '');
        if ($c === '' || !isProjectCampaign('google', $c)) {
            continue;   // Website row / other projects — leads are counted from the lead table below
        }
        [$g, $a] = [(string) ($r['adgroup_id'] ?? ''), (string) ($r['ad_id'] ?? '')];
        $m = $leaf('Google', $c, $g, $a);
        pfAdd($m, ['impressions' => (int) ($r['impressions'] ?? 0), 'clicks' => (int) ($r['clicks'] ?? 0), 'spend' => (float) ($r['spend'] ?? 0)]);
        $tree['Google'][$c][$g][$a] = $m;
    }
    // 1c. Taboola (only when PORTFOLIO_INCLUDE_TABOOLA) — campaign level
    if ($withSpend && pfIncludeTaboola() && $onlySet === null) {
        $tb = pfInternalApi('taboolaapi.php', ['since' => $since, 'until' => $until, 'pdf_export' => 1]);
        foreach ($tb['campaigns'] ?? [] as $c) {
            $name = (string) ($c['name'] ?? 'Taboola');
            $tree['Taboola'][$name][''][''] = ['impressions' => (int) ($c['impressions'] ?? 0), 'clicks' => (int) ($c['clicks'] ?? 0),
                'spend' => (float) ($c['spend'] ?? 0), 'leads' => (int) ($c['leads'] ?? 0), 'ql' => (int) ($c['qualified'] ?? 0), 'sv_done' => (int) ($c['walkins'] ?? 0)];
        }
    }

    // 2. leads from the lead table(s)
    $disp = ['QUALIFIED' => 0, 'NON-QUALIFIED' => 0, 'TO BE QUALIFIED' => 0, 'NOT SET / OTHER' => 0];
    $unmapped = ['meta' => 0, 'google' => 0, 'unknown' => 0];
    $website = pfBlank();
    $people = [];
    $entries = 0;
    $s = (new DateTime($since))->format('Y-m-d') . ' 00:00:00';
    $u = (new DateTime($until))->format('Y-m-d') . ' 23:59:59';
    foreach ($conns as $dbName => $db) {
        $st = $db->prepare('SELECT id, name, email, mobile, campaignsource, leadgen_id, gclid, ad_id, campaign_name, adset_name, ad_name,
                                   utm_campaignid, utm_campaignname, utm_adgroupid, utm_adgroupname, utm_adid, utm_adname, lead_status, sitevisit_status
                            FROM `lead` WHERE createddate >= ? AND createddate <= ? ORDER BY createddate, id');
        if (!$st) {
            $warnings[] = "Leads from {$dbName}: " . $db->error;
            continue;
        }
        $st->bind_param('ss', $s, $u);
        $st->execute();
        $res = $st->get_result();
        while ($l = $res->fetch_assoc()) {
            if (umIsTestLead($l)) {
                continue;
            }
            $entries++;
            $src = strtolower(trim((string) $l['campaignsource']));
            $ql = in_array(strtoupper(trim((string) $l['lead_status'])), SU_QUALIFIED_VALUES, true);
            $sv = in_array(strtoupper(trim((string) $l['sitevisit_status'])), SU_SITEVISIT_VALUES, true);
            if ($src === 'taboola' || $src === 'native') {
                continue;   // Taboola leads come with Taboola's own numbers (when included)
            }
            $p = $src === 'website' ? 'google' : umPlatformOf($l);
            if ($p === '') {
                continue;
            }
            // where this lead goes: [platform, cid, gid, aid] | 'website' | 'unmapped'
            if ($src === 'website' || ($p === 'google' && pqGoogleCampaignIsWebsite(pqCleanTrack($l['utm_campaignid']), pqCleanTrack($l['utm_campaignname'])))) {
                $place = 'website';   // like the Google dashboard: no campaign, or one not in this project → "Website / Direct"
            } elseif ($p === 'meta' || $p === 'google') {
                $key = $p === 'meta' ? pfMetaKey($l) : pfGoogleKey($l);
                if ($key !== null) {
                    $place = array_merge([$p === 'meta' ? 'Meta' : 'Google'], $key);
                } elseif ($p === 'meta' && pfCountUnmapped()) {
                    $place = ['Meta', PF_UNMAPPED, '', ''];   // Meta lead under no project campaign → "Unmapped leads" row
                } elseif ($p === 'google' && pfCountUnmapped()) {
                    $place = 'website';
                } else {
                    $place = 'unmapped';
                }
            } else {
                $place = 'unmapped';
            }
            $mob = umNormMobile($l['mobile'] ?? '');
            $pk = $p . '|' . (strlen($mob) >= 6 ? $mob : $dbName . '#' . $l['id']);
            if (!isset($people[$pk])) {
                $people[$pk] = ['p' => $p, 'place' => $place, 'ql' => $ql, 'sv' => $sv, 'status' => $l['lead_status'], 'n' => 1];
            } else {
                $pp = &$people[$pk];
                $pp['n']++;   // every form entry counts as a lead; qualified / site visit count once per person
                $isWeak = fn($pl) => $pl === 'unmapped' || $pl === 'website' || (is_array($pl) && $pl[1] === PF_UNMAPPED);
                if ($isWeak($pp['place']) && !$isWeak($place)) {
                    $pp['place'] = $place;   // a later lead of the same person that can be placed wins over "unmapped"
                }
                if ($ql && !$pp['ql']) {
                    $pp['status'] = $l['lead_status'];
                }
                $pp['ql'] = $pp['ql'] || $ql;
                $pp['sv'] = $pp['sv'] || $sv;
                if (!$pp['ql'] && trim((string) $l['lead_status']) !== '') {
                    $pp['status'] = $l['lead_status'];   // latest status for the disposition
                }
                unset($pp);
            }
        }
        $st->close();
    }
    foreach ($people as $pp) {
        // leads = every form entry of the person (DASHBOARD_LEADS_AS_PEOPLE = true → 1 per person); qualified / site visit = unique people
        $counts = ['leads' => pfLeadsAsPeople() ? 1 : (int) $pp['n'], 'ql' => $pp['ql'] ? 1 : 0, 'sv_done' => $pp['sv'] ? 1 : 0];
        if (!$kept($pp['place']) || !$shown($pp['place'])) {
            continue;   // "Select campaigns": not one of the chosen campaigns; or not in the tab / role's campaign types
        }
        if ($pp['place'] === 'unmapped') {
            $unmapped[$pp['p']]++;
            continue;
        }
        $disp[pfDisposition($pp['ql'] ? 'QUALIFIED' : $pp['status'])]++;
        if ($pp['place'] === 'website') {
            pfAdd($website, $counts);
            continue;
        }
        [$P, $c, $g, $a] = $pp['place'];
        $m = $leaf($P, $c, $g, $a);
        pfAdd($m, $counts);
        $tree[$P][$c][$g][$a] = $m;
    }

    // 2b. All / Performance / Awareness tab (cookie pq_view) and Users & Roles → Campaign types: campaigns of the
    //     other type are left out (spend and leads). Website / Direct, unmapped leads and Taboola count as performance.
    if ($view !== 'all') {
        foreach (['Meta' => 'meta', 'Google' => 'google'] as $P => $key) {
            foreach (array_keys($tree[$P]) as $cid) {
                $type = ($cid === PF_UNMAPPED || $cid === '') ? 'performance' : pqCampaignType($key, (string) $cid);
                if (!pqViewShows($type, $view)) {
                    unset($tree[$P][$cid]);
                }
            }
        }
        if (!pqViewShows('performance', $view)) {
            $website = pfBlank();
            $tree['Taboola'] = [];
            $unmapped = ['meta' => 0, 'google' => 0, 'unknown' => 0];
        }
    }

    // 3. tree → rows (saved names)
    $rows = [];
    $total = pfBlank();
    foreach (['Meta' => 'meta', 'Google' => 'google', 'Taboola' => ''] as $P => $key) {
        if ($P === 'Taboola' && (!pfIncludeTaboola() || $onlySet !== null)) {
            continue;
        }
        if ($onlySet !== null) {
            if (!$onlySet[$P]) {
                continue;   // no campaign of this platform chosen
            }
            $tree[$P] = array_intersect_key($tree[$P], $onlySet[$P]);   // spend of the other campaigns out
        }
        $struct = $key ? projectStructure($key) : null;
        $platformM = pfBlank();
        $sub = [];
        $campaigns = $tree[$P];
        if ($P === 'Google' && ($website['leads'] > 0)) {
            $campaigns['__website'] = ['' => ['' => $website]];
        }
        foreach ($campaigns as $cid => $groups) {
            $cName = $cid === '__website' ? 'Website / Direct' : ($cid === PF_UNMAPPED ? 'Unmapped leads (no campaign)' : ($struct ? ($struct['campaigns'][$cid] ?? (string) $cid) : (string) $cid));
            $cM = pfBlank();
            $cRows = [];
            ksort($groups);
            foreach ($groups as $gid => $ads) {
                $gName = $gid === '' ? ($cid === '__website' ? 'Website' : PF_NO_GROUP) : ($struct['adgroups'][$gid]['name'] ?? (string) $gid);
                $gM = pfBlank();
                $aRows = [];
                foreach ($ads as $aid => $m) {
                    $aName = $aid === '' ? ($cid === '__website' ? 'Website' : PF_NO_AD) : ($struct['ads'][$aid]['name'] ?? (string) $aid);
                    pfAdd($gM, $m);
                    if ($m['spend'] > 0 || $m['leads'] > 0) {
                        $aRows[] = pfRow($P, 'ad', $aName, 3, $m);
                    }
                }
                pfAdd($cM, $gM);
                if ($gM['spend'] > 0 || $gM['leads'] > 0) {
                    $cRows[] = pfRow($P, 'adset', $gName, 2, $gM);
                    array_push($cRows, ...$aRows);
                }
            }
            pfAdd($platformM, $cM);
            if ($cM['spend'] > 0 || $cM['leads'] > 0) {
                $sub[] = [$cM['spend'], pfRow($P, 'campaign', $cName, 1, $cM), ($cid === '__website' || $cid === PF_UNMAPPED) ? [] : $cRows];
            }
        }
        usort($sub, fn($a, $b) => $b[0] <=> $a[0]);   // biggest spend first
        $rows[] = pfRow($P, 'platform', $P, 0, $platformM);
        foreach ($sub as [, $cRow, $cRows]) {
            $rows[] = $cRow;
            array_push($rows, ...$cRows);
        }
        pfAdd($total, $platformM);
    }
    $totalRow = pfRow('Total', 'total', 'Total', 0, $total);
    // tree / meta_freq: raw numbers by platform → campaign id → ad set id → ad id (app/Ads/creatives.php)
    return ['rows' => $rows, 'total' => $totalRow, 'disposition' => $disp, 'unmapped' => $unmapped, 'warnings' => $warnings, 'entries' => $entries,
            'tree' => $tree, 'meta_freq' => $metaFreq];
}
