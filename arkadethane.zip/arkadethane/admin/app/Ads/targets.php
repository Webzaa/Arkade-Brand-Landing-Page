<?php
/**
 * app/Ads/targets.php — Targets: plan vs achieved, per month or per quarter, Overall and per platform.
 *
 * Entered on the Targets page (public/targets.php, permission Targets → Edit targets):
 *   targets   Spends, Leads, Qualified leads, Site visits, Bookings, Clash bookings, Revenue — and, optionally,
 *             fixed targets for the rates (CPL, Lead → QL %, CPQL, QL → SV %, CPSV, SV → Booking %, Cost to sales %);
 *             a rate left empty is worked out from the numbers (e.g. CPL = Spends ÷ Leads).
 *   achieved  Bookings, Clash bookings and Revenue (the admin has no booking data — they come from the client).
 * Achieved Spends / Leads / Qualified / Site visits are the dashboard numbers (same as the PDF report: pfPeriod()).
 *
 * Overall target = what was entered for Overall, else the sum of the platforms (per metric, per period).
 * A date range takes every period it touches: the full target ("full period") or the share of days in the range
 * ("pro-rated", e.g. 18 of 31 days of October). Rates are never pro-rated.
 * Stored in pq_targets (main database). Settings (month / quarter, default view) in pq_settings key 'targets'.
 */

require_once __DIR__ . '/portfolio_data.php';
require_once dirname(__DIR__) . '/Leads/crm_sfdc.php';    // pq_settings helpers

/** Report rows in order: key => [label, format, better, base|rate, hidden-metric keys]. */
const PQT_ROWS = [
    'spend'    => ['Spends', 'money', 'neutral', 'base', []],
    'leads'    => ['Leads (Workable)', 'int', 'high', 'base', []],
    'cpl'      => ['CPL', 'money', 'low', 'rate', []],
    'ql'       => ['Qualified Leads', 'int', 'high', 'base', ['qualified']],
    'ql_rate'  => ['Lead to QL %', 'pct', 'high', 'rate', ['qualified']],
    'cpql'     => ['CPQL', 'money', 'low', 'rate', ['qualified', 'cpql']],
    'sv_rate'  => ['QL to SV %', 'pct', 'high', 'rate', ['qualified', 'sitevisits']],
    'sv'       => ['SV', 'int', 'high', 'base', ['sitevisits']],
    'cpsv'     => ['CPSV', 'money', 'low', 'rate', ['sitevisits', 'cpsv']],
    'bk_rate'  => ['SV to Booking %', 'pct', 'high', 'rate', ['sitevisits']],
    'bookings' => ['Bookings', 'int', 'high', 'base', []],
    'clash'    => ['Clash Booking', 'int', 'neutral', 'base', []],
    'revenue'  => ['Revenue', 'money', 'high', 'base', []],
    'cts'      => ['Cost to Sales% (Digital)', 'pct', 'low', 'rate', []],
];
/** Achieved values entered by hand. */
const PQT_MANUAL_ACTUALS = ['bookings', 'clash', 'revenue'];

/* ======================================================================
 * Storage
 * ====================================================================== */

function pqtDb(): mysqli
{
    $db = leadDb(appDbKey());
    if (!$db) {
        throw new RuntimeException('The main database is not reachable.');
    }
    $db->query("CREATE TABLE IF NOT EXISTS `pq_targets` (
        `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        `period_type` VARCHAR(10) NOT NULL,
        `period_key` VARCHAR(10) NOT NULL,
        `platform` VARCHAR(50) NOT NULL,
        `kind` VARCHAR(10) NOT NULL,
        `metric` VARCHAR(20) NOT NULL,
        `value` DECIMAL(18,4) NOT NULL,
        `updated_at` DATETIME DEFAULT NULL,
        `updated_by` VARCHAR(100) DEFAULT NULL,
        UNIQUE KEY `uq_target` (`period_type`, `period_key`, `platform`, `kind`, `metric`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    return $db;
}

function pqtSettings(?mysqli $db = null): array
{
    $db ??= pqtDb();
    $s = pqSettingGet($db, 'targets') ?? [];
    return ['period' => ($s['period'] ?? 'month') === 'quarter' ? 'quarter' : 'month', 'prorate' => !empty($s['prorate'])];
}

/** Platforms a target can be set for: key => name. */
function pqtPlatforms(): array
{
    $p = ['overall' => 'Overall', 'meta' => 'Meta', 'google' => 'Google'];
    if ((pfIncludeTaboola() || (defined('SHOW_TABOOLA') && SHOW_TABOOLA)) && (!function_exists('pqCanSeeType') || pqCanSeeType('performance'))) {
        $p['taboola'] = 'Taboola';
    }
    try {
        require_once __DIR__ . '/ott.php';
        foreach (ottVisiblePlatforms() as $mp) {   // Users & Roles → Campaign types
            $p['m-' . $mp['key']] = (string) $mp['name'];
        }
    } catch (Throwable $e) {
        // manual platforms not set up
    }
    return $p;
}

/* ======================================================================
 * Periods
 * ====================================================================== */

function pqtPeriodKey(string $type, string $ymd): string
{
    [$y, $m] = array_map('intval', explode('-', substr($ymd, 0, 7)));
    return $type === 'quarter' ? sprintf('%04d-Q%d', $y, intdiv($m - 1, 3) + 1) : sprintf('%04d-%02d', $y, $m);
}

/** @return array{0:string,1:string} first and last day */
function pqtPeriodBounds(string $type, string $key): array
{
    if ($type === 'quarter') {
        if (!preg_match('/^(\d{4})-Q([1-4])$/', $key, $m)) {
            throw new InvalidArgumentException('Bad quarter.');
        }
        $start = sprintf('%04d-%02d-01', $m[1], ($m[2] - 1) * 3 + 1);
        return [$start, date('Y-m-t', strtotime($start . ' +2 months'))];
    }
    if (!preg_match('/^\d{4}-(0[1-9]|1[0-2])$/', $key)) {
        throw new InvalidArgumentException('Bad month.');
    }
    return [$key . '-01', date('Y-m-t', strtotime($key . '-01'))];
}

function pqtPeriodLabel(string $type, string $key): string
{
    if ($type === 'quarter') {
        [$a, $b] = pqtPeriodBounds($type, $key);
        return substr($key, 5) . ' ' . substr($key, 0, 4) . ' (' . date('M', strtotime($a)) . '–' . date('M', strtotime($b)) . ')';
    }
    return date('F Y', strtotime($key . '-01'));
}

/** Periods a date range touches, with the share of each period's days inside the range. */
function pqtPeriodsIn(string $type, string $since, string $until): array
{
    $out = [];
    $key = pqtPeriodKey($type, $since);
    for ($i = 0; $i < 40; $i++) {
        [$a, $b] = pqtPeriodBounds($type, $key);
        if ($a > $until) {
            break;
        }
        $from = max($a, $since);
        $to = min($b, $until);
        $days = (int) ((strtotime($b) - strtotime($a)) / 86400) + 1;
        $in = (int) ((strtotime($to) - strtotime($from)) / 86400) + 1;
        $out[] = ['key' => $key, 'start' => $a, 'end' => $b, 'days' => $days, 'days_in' => $in, 'share' => $in / $days];
        $key = pqtPeriodKey($type, date('Y-m-d', strtotime($b . ' +1 day')));
    }
    return $out;
}

/* ======================================================================
 * Read / write entries
 * ====================================================================== */

/** @return array [period_key][platform][kind][metric] = float */
function pqtLoad(mysqli $db, string $type, array $keys): array
{
    if (!$keys) {
        return [];
    }
    $in = implode(',', array_map(fn($k) => "'" . $db->real_escape_string($k) . "'", $keys));
    $res = $db->query("SELECT period_key, platform, kind, metric, value FROM `pq_targets` WHERE period_type = '"
        . $db->real_escape_string($type) . "' AND period_key IN ($in)");
    $out = [];
    while ($res && ($r = $res->fetch_assoc())) {
        $out[$r['period_key']][$r['platform']][$r['kind']][$r['metric']] = (float) $r['value'];
    }
    return $out;
}

/**
 * Saves one period. $values = [platform => ['target' => [metric => number|''], 'actual' => [...]]].
 * An empty value removes that entry.
 */
function pqtSave(mysqli $db, string $type, string $key, array $values, string $user): int
{
    pqtPeriodBounds($type, $key);   // validates
    $platforms = pqtPlatforms();
    // 1. check everything first — a bad value saves nothing
    $ops = [];
    foreach ($values as $pf => $kinds) {
        if (!isset($platforms[$pf])) {
            continue;
        }
        foreach (['target' => array_keys(PQT_ROWS), 'actual' => PQT_MANUAL_ACTUALS] as $kind => $allowed) {
            foreach ((array) ($kinds[$kind] ?? []) as $metric => $v) {
                if (!in_array($metric, $allowed, true)) {
                    continue;
                }
                $v = is_string($v) ? str_replace([',', ' ', '₹', '%'], '', $v) : $v;
                if ($v !== '' && $v !== null && (!is_numeric($v) || (float) $v < 0)) {
                    throw new InvalidArgumentException(PQT_ROWS[$metric][0] . ' (' . $platforms[$pf] . '): enter a number of 0 or more.');
                }
                $ops[] = [$pf, $kind, (string) $metric, ($v === '' || $v === null) ? null : round((float) $v, 4)];
            }
        }
    }
    // 2. write in one transaction
    $del = $db->prepare('DELETE FROM `pq_targets` WHERE period_type = ? AND period_key = ? AND platform = ? AND kind = ? AND metric = ?');
    $ins = $db->prepare('INSERT INTO `pq_targets` (period_type, period_key, platform, kind, metric, value, updated_at, updated_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
    $now = date('Y-m-d H:i:s');
    $n = 0;
    $db->begin_transaction();
    try {
        foreach ($ops as [$pf, $kind, $metric, $f]) {
            $del->bind_param('sssss', $type, $key, $pf, $kind, $metric);
            $del->execute();
            if ($f === null) {
                continue;
            }
            $ins->bind_param('sssssdss', $type, $key, $pf, $kind, $metric, $f, $now, $user);
            if (!$ins->execute()) {
                throw new RuntimeException('Could not save the targets: ' . $db->error);
            }
            $n++;
        }
        $db->commit();
    } catch (Throwable $e) {
        $db->rollback();
        throw $e;
    }
    return $n;
}

/* ======================================================================
 * Numbers
 * ====================================================================== */

/** Rates from the base numbers (null when the divisor is 0). */
function pqtDerive(array $b): array
{
    $div = fn($x, $y, $m = 1) => ($y ?? 0) > 0 && $x !== null ? $x / $y * $m : null;
    return [
        'cpl' => $div($b['spend'] ?? null, $b['leads'] ?? 0),
        'ql_rate' => $div($b['ql'] ?? null, $b['leads'] ?? 0, 100),
        'cpql' => $div($b['spend'] ?? null, $b['ql'] ?? 0),
        'sv_rate' => $div($b['sv'] ?? null, $b['ql'] ?? 0, 100),
        'cpsv' => $div($b['spend'] ?? null, $b['sv'] ?? 0),
        'bk_rate' => $div($b['bookings'] ?? null, $b['sv'] ?? 0, 100),
        'cts' => $div($b['spend'] ?? null, $b['revenue'] ?? 0, 100),
    ];
}

/**
 * Target values for a platform over a date range.
 * @return array{values: array<string,?float>, entered: bool, fixed_rates: list<string>}
 */
function pqtTarget(array $data, array $periods, string $pf, bool $prorate, array $platformKeys): array
{
    $base = [];
    $rateSum = [];
    $rateW = [];
    $entered = false;
    foreach ($periods as $p) {
        $row = $data[$p['key']] ?? [];
        $w = $prorate ? $p['share'] : 1.0;
        foreach (PQT_ROWS as $m => $def) {
            $v = $row[$pf]['target'][$m] ?? null;
            if ($v === null && $pf === 'overall' && $def[3] === 'base') {      // Overall = sum of the platforms
                foreach ($platformKeys as $k) {
                    if ($k !== 'overall' && isset($row[$k]['target'][$m])) {
                        $v = ($v ?? 0) + $row[$k]['target'][$m];
                    }
                }
            }
            if ($v === null) {
                continue;
            }
            $entered = true;
            if ($def[3] === 'base') {
                $base[$m] = ($base[$m] ?? 0) + $v * $w;
            } else {
                $rateSum[$m] = ($rateSum[$m] ?? 0) + $v * $p['days_in'];
                $rateW[$m] = ($rateW[$m] ?? 0) + $p['days_in'];
            }
        }
    }
    $vals = array_fill_keys(array_keys(PQT_ROWS), null);
    foreach ($base as $m => $v) {
        $vals[$m] = $v;
    }
    $derived = pqtDerive($base);
    $fixed = [];
    foreach ($derived as $m => $v) {
        if (isset($rateSum[$m])) {
            $vals[$m] = $rateSum[$m] / $rateW[$m];
            $fixed[] = $m;
        } else {
            $vals[$m] = $v;
        }
    }
    return ['values' => $vals, 'entered' => $entered, 'fixed_rates' => $fixed];
}

/**
 * Dashboard numbers for a range, per platform key (+ 'overall'): spend, leads, ql, sv. Cached 10 minutes.
 * @return array{platforms: array<string, array>, warnings: list<string>}
 */
function pqtAchievedDashboard(string $since, string $until): array
{
    // + the All / Performance / Awareness tab (and the role's campaign types): achieved follows what the dashboard shows
    $view = function_exists('pqCampaignView') ? pqCampaignView() : 'all';
    $cacheFile = CACHE_PATH . '/targets_achieved_' . md5($since . '|' . $until . '|' . appDbKey() . '|' . $view) . '.json';
    if (is_file($cacheFile)) {
        $c = json_decode((string) @file_get_contents($cacheFile), true);
        $ttl = !empty($c['spend_failed']) ? 120 : 600;      // retry sooner when a platform's spend could not be read
        if (is_array($c) && isset($c['platforms']) && filemtime($cacheFile) > time() - $ttl) {
            return $c;
        }
    }
    $out = ['platforms' => [], 'warnings' => []];
    $zero = ['spend' => 0.0, 'leads' => 0, 'ql' => 0, 'sv' => 0];
    $overall = $zero;
    $conns = pfLeadConns();
    if ($conns) {
        $r = pfPeriod($since, $until, $conns, true);
        $out['warnings'] = $r['warnings'] ?? [];
        foreach ($r['rows'] as $row) {
            if (($row['type'] ?? '') !== 'platform') {
                continue;
            }
            $k = strtolower((string) $row['platform']);
            $v = ['spend' => (float) $row['spend'], 'leads' => (int) $row['leads'], 'ql' => (int) $row['ql'], 'sv' => (int) $row['sv_done']];
            $out['platforms'][$k] = $v;
            foreach ($v as $m => $x) {
                $overall[$m] += $x;
            }
        }
    }
    try {
        require_once __DIR__ . '/ott.php';
        foreach (ottVisiblePlatforms() as $mp) {
            $rows = ottRows($mp['key'], $since, $until);
            [$rows, $leadsHere] = ottViewRows($mp, $rows, ottAwarenessSplit($mp, $rows), $view);
            $t = ottTotals($rows, $leadsHere ? ottLeadsByDay($mp['key'], $since, $until) : []);
            $v = ['spend' => (float) $t['spend'], 'leads' => (int) $t['leads'], 'ql' => (int) $t['qualified'], 'sv' => (int) $t['sitevisits']];
            $out['platforms']['m-' . $mp['key']] = $v;
            foreach ($v as $m => $x) {
                $overall[$m] = $overall[$m] === null ? null : $overall[$m] + $x;
            }
        }
    } catch (Throwable $e) {
        $out['warnings'][] = 'Manual platforms: ' . $e->getMessage();
    }
    $failed = [];
    foreach ($out['warnings'] as $w) {
        if (preg_match('/^(Meta|Google|Taboola) spend/i', (string) $w, $m)) {
            $failed[] = strtolower($m[1]);
        }
    }
    foreach (array_unique($failed) as $k) {
        if (isset($out['platforms'][$k])) {
            $out['platforms'][$k]['spend'] = null;
        }
    }
    if ($failed) {
        $overall['spend'] = null;
    }
    $out['platforms']['overall'] = $overall;
    $out['spend_failed'] = array_values(array_unique($failed));
    @file_put_contents($cacheFile, json_encode($out), LOCK_EX);
    return $out;
}

function pqtClearCache(): void
{
    foreach (glob(CACHE_PATH . '/targets_achieved_*.json') ?: [] as $f) {
        @unlink($f);
    }
}

/**
 * Target vs achieved for one platform and date range.
 * @return array{rows: list<array>, periods: list<array>, ...}
 */
function pqtReport(string $pf, string $since, string $until, ?bool $prorate = null): array
{
    $db = pqtDb();
    $set = pqtSettings($db);
    $prorate ??= $set['prorate'];
    $platforms = pqtPlatforms();
    if (!isset($platforms[$pf])) {
        throw new InvalidArgumentException('Unknown platform.');
    }
    $periods = pqtPeriodsIn($set['period'], $since, $until);
    $data = pqtLoad($db, $set['period'], array_column($periods, 'key'));
    $target = pqtTarget($data, $periods, $pf, $prorate, array_keys($platforms));

    $dash = pqtAchievedDashboard($since, $until);
    $a = $dash['platforms'][$pf] ?? ['spend' => 0.0, 'leads' => 0, 'ql' => 0, 'sv' => 0];
    // bookings / clash / revenue: what was entered for the periods in the range (Overall: entered, else sum of the platforms)
    $manualEntered = false;
    foreach (PQT_MANUAL_ACTUALS as $m) {
        $sum = null;
        foreach ($periods as $p) {
            $row = $data[$p['key']] ?? [];
            $v = $row[$pf]['actual'][$m] ?? null;
            if ($v === null && $pf === 'overall') {
                foreach ($platforms as $k => $_) {
                    if ($k !== 'overall' && isset($row[$k]['actual'][$m])) {
                        $v = ($v ?? 0) + $row[$k]['actual'][$m];
                    }
                }
            }
            if ($v !== null) {
                $sum = ($sum ?? 0) + $v;
                $manualEntered = true;
            }
        }
        $a[$m] = $sum;
    }
    $achieved = $a + pqtDerive($a);

    $hidden = function_exists('pqHiddenMetrics') ? pqHiddenMetrics() : [];
    $rows = [];
    foreach (PQT_ROWS as $m => [$label, $fmt, $better, $kind, $needs]) {
        if (array_intersect($needs, $hidden)) {
            continue;
        }
        $t = $target['values'][$m];
        $x = $achieved[$m] ?? null;
        $status = '';
        if ($t !== null && $x !== null && $better !== 'neutral' && $t > 0) {
            $good = $better === 'high' ? $x >= $t : $x <= $t;
            $near = $better === 'high' ? $x >= $t * 0.9 : $x <= $t * 1.1;
            $status = $good ? 'good' : ($near ? 'near' : 'bad');
        }
        $rows[] = ['key' => $m, 'label' => $label, 'format' => $fmt, 'better' => $better, 'kind' => $kind,
                   'target' => $t, 'achieved' => $x, 'pct' => ($t !== null && $t > 0 && $x !== null && $kind === 'base') ? $x / $t * 100 : null,
                   'status' => $status, 'fixed' => in_array($m, $target['fixed_rates'], true),
                   'manual' => in_array($m, PQT_MANUAL_ACTUALS, true)];
    }
    return [
        'platform' => $pf, 'platform_name' => $platforms[$pf], 'since' => $since, 'until' => $until,
        'period_type' => $set['period'], 'prorate' => $prorate,
        'periods' => array_map(fn($p) => $p + ['label' => pqtPeriodLabel($set['period'], $p['key'])], $periods),
        'has_targets' => $target['entered'], 'manual_entered' => $manualEntered,
        'rows' => $rows, 'warnings' => $dash['warnings'], 'spend_failed' => $dash['spend_failed'] ?? [],
    ];
}
