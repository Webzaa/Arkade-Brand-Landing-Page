<?php
/**
 * app/Ads/platform_metrics.php — extra metrics straight from Meta and Google (video views, link clicks, landing page
 * views, engagements, conversions …) for the ▥ Columns panel on the campaign tables.
 *
 * Fetched in a SEPARATE, optional request next to the dashboards' own one: if a platform rejects a field (names change
 * between API versions), that field is dropped and the request retried; if it still fails the dashboard simply has no
 * extra columns — its own numbers are never affected. Every row gets 'pm' => [key => number].
 *   pmMetaFetch()    Meta Insights at level campaign | adset | ad
 *   pmGoogleFetch()  Google Ads (GAQL) FROM campaign | ad_group_ad
 *   pmLabels()       key => [label, kind] for the columns panel (kind: sum | rate = impressions-weighted %)
 */

/** Meta Insights fields: field => [key, label] (array fields = sum of their values) */
const PM_META_FIELDS = [
    'unique_clicks'                  => ['pm_unique_clicks', 'Unique clicks (all)'],
    'inline_link_clicks'             => ['pm_link_clicks', 'Link clicks'],
    'unique_inline_link_clicks'      => ['pm_unique_link_clicks', 'Unique link clicks'],
    'outbound_clicks'                => ['pm_outbound_clicks', 'Outbound clicks'],
    'video_play_actions'             => ['pm_video_plays', 'Video plays'],
    'video_p25_watched_actions'      => ['pm_video_p25', 'Video plays at 25%'],
    'video_p50_watched_actions'      => ['pm_video_p50', 'Video plays at 50%'],
    'video_p75_watched_actions'      => ['pm_video_p75', 'Video plays at 75%'],
    'video_p100_watched_actions'     => ['pm_video_p100', 'Video plays at 100%'],
    'video_thruplay_watched_actions' => ['pm_thruplays', 'ThruPlays'],
    'video_30_sec_watched_actions'   => ['pm_video_30s', '30-second video plays'],
    'actions'                        => ['', ''],     // split by action type below
];
/** Meta "actions" types kept: action_type => [key, label] */
const PM_META_ACTIONS = [
    'landing_page_view'                               => ['pm_landing_page_views', 'Landing page views'],
    'link_click'                                      => ['pm_link_click_actions', 'Link click actions'],
    'post_engagement'                                 => ['pm_post_engagement', 'Post engagements'],
    'page_engagement'                                 => ['pm_page_engagement', 'Page engagements'],
    'post_reaction'                                   => ['pm_post_reactions', 'Post reactions'],
    'comment'                                         => ['pm_comments', 'Post comments'],
    'post'                                            => ['pm_shares', 'Post shares'],
    'video_view'                                      => ['pm_video_views_3s', '3-second video views'],
    'lead'                                            => ['pm_meta_leads', 'Leads (Meta reported)'],
    'onsite_conversion.messaging_conversation_started_7d' => ['pm_messaging_started', 'Messaging conversations started'],
];
/** Google Ads metrics: GAQL field => [key, label, kind] (two names for video views: the field was renamed in newer API versions) */
const PM_GOOGLE_FIELDS = [
    'metrics.interactions'             => ['pm_interactions', 'Interactions', 'sum'],
    'metrics.engagements'              => ['pm_engagements', 'Engagements', 'sum'],
    'metrics.conversions'              => ['pm_conversions', 'Conversions (Google)', 'sum'],
    'metrics.all_conversions'          => ['pm_all_conversions', 'All conversions', 'sum'],
    'metrics.conversions_value'        => ['pm_conversions_value', 'Conversion value', 'sum'],
    'metrics.view_through_conversions' => ['pm_view_through_conv', 'View-through conversions', 'sum'],
    'metrics.video_trueview_views'     => ['pm_video_views', 'TrueView views', 'sum'],
    'metrics.video_views'              => ['pm_video_views', 'TrueView views', 'sum'],
    'metrics.invalid_clicks'           => ['pm_invalid_clicks', 'Invalid clicks', 'sum'],
    'metrics.unique_users'             => ['pm_unique_users', 'Reach (unique users)', 'sum'],   // video / display; whole period, ≤ 92 days
    'metrics.video_quartile_p25_rate'  => ['pm_video_p25_rate', 'Video played to 25%', 'rate'],
    'metrics.video_quartile_p50_rate'  => ['pm_video_p50_rate', 'Video played to 50%', 'rate'],
    'metrics.video_quartile_p75_rate'  => ['pm_video_p75_rate', 'Video played to 75%', 'rate'],
    'metrics.video_quartile_p100_rate' => ['pm_video_p100_rate', 'Video played to 100%', 'rate'],
];

function pmLabels(string $platform): array
{
    // campaign budgets (app/Ads/creatives.php crBudgetPm) — campaign tables only, shown by default
    $out = ['pm_daily_budget' => ['label' => 'Daily budget', 'kind' => 'sum', 'money' => true, 'default' => true],
            'pm_lifetime_budget' => ['label' => 'Lifetime budget', 'kind' => 'sum', 'money' => true]];
    if ($platform === 'meta') {
        foreach (PM_META_FIELDS as [$k, $l]) {
            if ($k !== '') {
                $out[$k] = ['label' => $l, 'kind' => 'sum'];
            }
        }
        foreach (PM_META_ACTIONS as [$k, $l]) {
            $out[$k] = ['label' => $l, 'kind' => 'sum'];
        }
    } else {
        foreach (PM_GOOGLE_FIELDS as [$k, $l, $kind]) {
            $out[$k] = ['label' => $l, 'kind' => $kind];
        }
    }
    return $out;
}

/** Fields the platform rejected this run (so later calls skip them straight away). */
function &pmRejected(string $platform): array
{
    static $r = ['meta' => [], 'google' => []];
    return $r[$platform];
}

/** Which of $candidates does an error message name? */
function pmFieldsInError(string $msg, array $candidates): array
{
    $hit = [];
    foreach ($candidates as $f) {
        if (preg_match('/(?<![a-z0-9_.])' . preg_quote($f, '/') . '(?![a-z0-9_])/i', $msg)) {
            $hit[] = $f;
        }
    }
    return $hit;
}

/**
 * Meta Insights extra metrics for one ad account.
 * @param string $level  campaign | adset | ad
 * @param string $params the same &time_range=…&action_attribution_windows=…&filtering=… the dashboard request uses
 * @return array id => [pm key => number]
 */
function pmMetaFetch(string $version, string $accId, string $token, string $level, string $params): array
{
    $idField = ['campaign' => 'campaign_id', 'adset' => 'adset_id', 'ad' => 'ad_id'][$level] ?? null;
    if (!$idField || !function_exists('fetchAllPages')) {
        return [];
    }
    $rejected = &pmRejected('meta');
    $fields = array_values(array_diff(array_keys(PM_META_FIELDS), $rejected));
    for ($try = 0; $try < 4 && $fields; $try++) {
        $url = "https://graph.facebook.com/{$version}/act_{$accId}/insights?fields=" . $idField . ',' . implode(',', $fields)
            . "&level={$level}{$params}&limit=200&access_token=" . urlencode($token);
        $res = fetchAllPages($url);
        if (isset($res['error'])) {
            $msg = is_array($res['error']) ? (string) ($res['error']['message'] ?? json_encode($res['error'])) : (string) $res['error'];
            $bad = pmFieldsInError($msg, $fields);
            if (!$bad) {
                error_log("[platform_metrics] Meta {$level}: {$msg}");
                return [];
            }
            error_log('[platform_metrics] Meta rejected ' . implode(', ', $bad) . ' — retrying without');
            $rejected = array_values(array_unique(array_merge($rejected, $bad)));
            $fields = array_values(array_diff($fields, $bad));
            continue;
        }
        $out = [];
        foreach (($res['data'] ?? []) as $row) {
            $id = (string) ($row[$idField] ?? '');
            if ($id === '') {
                continue;
            }
            $m = &$out[$id];
            $m ??= [];
            foreach (PM_META_FIELDS as $f => [$key]) {
                if (!isset($row[$f])) {
                    continue;
                }
                if ($f === 'actions') {
                    foreach ((array) $row['actions'] as $a) {
                        $t = (string) ($a['action_type'] ?? '');
                        if (isset(PM_META_ACTIONS[$t])) {
                            $k = PM_META_ACTIONS[$t][0];
                            $m[$k] = ($m[$k] ?? 0) + (float) ($a['value'] ?? 0);
                        }
                    }
                    continue;
                }
                $v = is_array($row[$f]) ? array_sum(array_map(fn($a) => (float) ($a['value'] ?? 0), $row[$f])) : (float) $row[$f];
                $m[$key] = ($m[$key] ?? 0) + $v;
            }
            unset($m);
        }
        return $out;
    }
    return [];
}

/**
 * Google Ads extra metrics.
 * @param string $from   campaign | ad_group_ad
 * @param string $where  e.g. "campaign.status = 'ENABLED' AND segments.date BETWEEN '…' AND '…'"
 * @return array id => [pm key => number]   (id = campaign id, or ad id for ad_group_ad)
 */
function pmGoogleFetch(string $apiUrl, string $token, string $from, string $where): array
{
    if (!defined('GOOGLE_DEVELOPER_TOKEN')) {
        return [];
    }
    $idSel = $from === 'ad_group_ad' ? 'ad_group_ad.ad.id, ad_group.id' : 'campaign.id';
    $rejected = &pmRejected('google');
    $fields = array_values(array_diff(array_keys(PM_GOOGLE_FIELDS), $rejected));
    // unique users (reach) only exists for ranges of 92 days or less, and only for whole campaigns
    if (preg_match("/BETWEEN '(\d{4}-\d{2}-\d{2})' AND '(\d{4}-\d{2}-\d{2})'/", $where, $m)
        && ((new DateTime($m[1]))->diff(new DateTime($m[2]))->days > 92 || $from !== 'campaign')) {
        $fields = array_values(array_diff($fields, ['metrics.unique_users']));
    }
    for ($try = 0; $try < 5 && $fields; $try++) {
        $q = "SELECT {$idSel}, metrics.impressions, " . implode(', ', $fields) . " FROM {$from} WHERE {$where}";
        $ch = curl_init($apiUrl);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true, CURLOPT_POST => true, CURLOPT_TIMEOUT => 60,
            CURLOPT_POSTFIELDS => json_encode(['query' => $q]),
            CURLOPT_HTTPHEADER => ['Authorization: Bearer ' . $token, 'developer-token: ' . GOOGLE_DEVELOPER_TOKEN, 'Content-Type: application/json'],   // same headers as googleapi.php
        ]);
        $raw = curl_exec($ch);
        unset($ch);
        $json = json_decode((string) $raw, true);
        $err = is_array($json) ? ($json[0]['error'] ?? $json['error'] ?? null) : ['message' => 'no response'];
        if ($err) {
            $msg = json_encode($err);
            $bad = pmFieldsInError($msg, $fields);
            if (!$bad) {
                error_log("[platform_metrics] Google {$from}: " . substr($msg, 0, 400));
                return [];
            }
            error_log('[platform_metrics] Google rejected ' . implode(', ', $bad) . ' — retrying without');
            $rejected = array_values(array_unique(array_merge($rejected, $bad)));
            $fields = array_values(array_diff($fields, $bad));
            continue;
        }
        $out = [];
        $wsum = [];    // rate metrics: impressions-weighted
        foreach ((array) $json as $chunk) {
            foreach ((array) ($chunk['results'] ?? []) as $r) {
                $id = (string) ($from === 'ad_group_ad' ? ($r['adGroupAd']['ad']['id'] ?? '') : ($r['campaign']['id'] ?? ''));
                if ($id === '') {
                    continue;
                }
                $imp = (float) ($r['metrics']['impressions'] ?? 0);
                foreach ($fields as $f) {
                    [$key, , $kind] = PM_GOOGLE_FIELDS[$f];
                    $camel = lcfirst(str_replace(' ', '', ucwords(str_replace('_', ' ', substr($f, 8)))));
                    if (!isset($r['metrics'][$camel])) {
                        continue;
                    }
                    $v = (float) $r['metrics'][$camel];
                    if ($kind === 'rate') {
                        $wsum[$id][$key]['v'] = ($wsum[$id][$key]['v'] ?? 0) + $v * $imp;
                        $wsum[$id][$key]['w'] = ($wsum[$id][$key]['w'] ?? 0) + $imp;
                    } else {
                        $out[$id][$key] = ($out[$id][$key] ?? 0) + $v;
                    }
                }
            }
        }
        foreach ($wsum as $id => $ks) {
            foreach ($ks as $key => $s) {
                $out[$id][$key] = $s['w'] > 0 ? round($s['v'] / $s['w'] * 100, 2) : 0;   // as a % (0.55 → 55%)
            }
        }
        return $out;
    }
    return [];
}

/** Adds pm values of $b into $a (sum metrics add up; rate metrics are impressions-weighted when $wA / $wB given). */
function pmMerge(array $a, array $b, string $platform = 'google', float $wA = 0, float $wB = 0): array
{
    $labels = pmLabels($platform);
    foreach ($b as $k => $v) {
        if (($labels[$k]['kind'] ?? 'sum') === 'rate') {
            $a[$k] = ($wA + $wB) > 0 ? round((($a[$k] ?? 0) * $wA + $v * $wB) / ($wA + $wB), 2) : $v;
        } else {
            $a[$k] = ($a[$k] ?? 0) + $v;
        }
    }
    return $a;
}
