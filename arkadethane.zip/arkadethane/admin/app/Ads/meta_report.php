<?php
require_once __DIR__ . '/meta_sync.php';   // project campaign list (campaigns table)

require_once dirname(__DIR__) . '/bootstrap.php';
if (!function_exists('emptyRow')) {
    function emptyRow(string $platform, string $type = 'platform', string $name = '', int $level = 0): array {
        return [
            'platform'    => $platform,
            'type'        => $type,
            'name'        => $name ?: $platform,
            'level'       => $level,
            'impressions' => 0,
            'clicks'      => 0,
            'leads'       => 0,
            'spend'       => 0.0,
            'ctr'         => 0.0,
            'cpl'         => 0.0,
            'ql'          => 0,
            'ql_pct'      => 0.0,
            'cpql'        => 0.0,
            'sv_done'     => 0,
            'cpsv'        => 0.0,
        ];
    }
}

if (!function_exists('finalizeRow')) {
    function finalizeRow(array $row): array {
        $row['spend']  = round($row['spend'], 2);
        $row['ctr']    = $row['impressions'] > 0 ? round(($row['clicks'] / $row['impressions']) * 100, 2) : 0.0;
        $row['cpl']    = $row['leads'] > 0 ? round($row['spend'] / $row['leads'], 2) : 0.0;
        $row['ql_pct'] = $row['leads'] > 0 ? round(($row['ql'] / $row['leads']) * 100, 2) : 0.0;
        $row['cpql']   = $row['ql'] > 0 ? round($row['spend'] / $row['ql'], 2) : 0.0;
        $row['cpsv']   = $row['sv_done'] > 0 ? round($row['spend'] / $row['sv_done'], 2) : 0.0;
        return $row;
    }
}

/**
 * Report key (saved campaign|||ad set|||ad names, lower-case) for a lead row, or null when the lead
 * is not of a campaign in the `campaigns` table. Matched by ad ID first, then by campaign name,
 * so campaigns / ad sets / ads renamed in the tables still get their leads.
 */
function metaReportLeadKey(array $row): ?string
{
    $s = projectStructure('meta');
    $low = fn($v) => strtolower(trim((string) $v));
    $ad = $s['ads'][trim((string) ($row['ad_id'] ?? ''))] ?? null;
    $set = $ad ? ($s['adgroups'][$ad['adgroup_id']] ?? null) : null;
    if ($set && isset($s['campaigns'][$set['campaign_id']])) {
        return $low($s['campaigns'][$set['campaign_id']]) . '|||' . $low($set['name']) . '|||' . $low($ad['name']);
    }
    $cid = projectCampaignId('meta', '', (string) ($row['campaign_name'] ?? ''));
    if ($cid === null) {
        return null;
    }
    $cName = $s['campaigns'][$cid];
    $aName = trim((string) ($row['adset_name'] ?? '')) !== '' ? $row['adset_name'] : $cName;
    $adName = trim((string) ($row['ad_name'] ?? '')) !== '' ? $row['ad_name'] : $aName;
    $gid = projectAdgroupId('meta', $cid, null, $aName);
    if ($gid !== null) {
        $aName = $s['adgroups'][$gid]['name'];
        $aid = projectAdId('meta', $gid, null, $adName);
        if ($aid !== null) {
            $adName = $s['ads'][$aid]['name'];
        }
    }
    return $low($cName) . '|||' . $low($aName) . '|||' . $low($adName);
}

function fetchMetaData(string $since, string $until, array $mappedMetaCampaignNames, $conn = null, bool $isPdfExport = false): array {
    // Resolve DB connection (prefer conn2/test_belicia if available)
    $dbConn = (isset($conn) && $conn && !$conn->connect_error) ? $conn : ((isset($GLOBALS['conn2']) && $GLOBALS['conn2'] && !$GLOBALS['conn2']->connect_error) ? $GLOBALS['conn2'] : ((isset($GLOBALS['conn']) && $GLOBALS['conn'] && !$GLOBALS['conn']->connect_error) ? $GLOBALS['conn'] : null));

    // Resolve DB date range
    $dbStart = $since . ' 00:00:00';
    $dbEnd   = $until . ' 23:59:59';

    // Initialise rows container
    $metaTree = [];
    $metaRow  = emptyRow('Meta', 'platform', 'Meta', 0);

    // Fetch spend data
    try {
        $metaPivot = fetchAdsPivotSpend(null, $since, $until);

        // Gather leads / QL / SV data from DB
        $metaDbLeads = [];
        if (isset($dbConn) && $dbConn && !$dbConn->connect_error) {
            $leadsStatusCond = "";
            // Name used for WhatsApp leads (config/config.php)
            $waCampaignSql = $dbConn->real_escape_string(defined('META_WHATSAPP_CAMPAIGN_NAME') ? META_WHATSAPP_CAMPAIGN_NAME : 'WhatsApp');

            // Leads count (campaignsource + leadgen_id matching fetch_meta.php)
            $sqlMetaLeadsCount = "SELECT
                    COALESCE(CASE WHEN LOWER(TRIM(campaignsource)) = 'whatsapp' THEN '{$waCampaignSql}' ELSE campaign_name END, '') AS campaign_name,
                    COALESCE(adset_name, '') AS adset_name,
                    COALESCE(ad_name, '') AS ad_name,
                    TRIM(COALESCE(ad_id, '')) AS ad_id,
                    COUNT(*) AS total_leads
                FROM `lead`
                WHERE createddate >= ? AND createddate <= ?
                    AND (campaign_name IS NOT NULL AND campaign_name <> '' OR LOWER(TRIM(campaignsource)) = 'whatsapp')
                    AND (leadgen_id IS NOT NULL AND TRIM(leadgen_id) != '' OR LOWER(TRIM(campaignsource)) IN ('fb','ig','facebook lead form','facebook','instagram','whatsapp'))
                    $leadsStatusCond
                GROUP BY CASE WHEN LOWER(TRIM(campaignsource)) = 'whatsapp' THEN '{$waCampaignSql}' ELSE campaign_name END, adset_name, ad_name, TRIM(COALESCE(ad_id, ''))";
            $stmtLeadsCount = $dbConn->prepare($sqlMetaLeadsCount);
            if ($stmtLeadsCount) {
                $stmtLeadsCount->bind_param('ss', $dbStart, $dbEnd);
                $stmtLeadsCount->execute();
                $resLeadsCount = $stmtLeadsCount->get_result();
                while ($row = $resLeadsCount->fetch_assoc()) {
                    $key = metaReportLeadKey($row);
                    if ($key === null) continue;   // lead of a campaign that isn't in the `campaigns` table
                    $metaDbLeads[$key] = $metaDbLeads[$key] ?? ['total_leads' => 0, 'ql' => 0, 'sv_done' => 0];
                    $metaDbLeads[$key]['total_leads'] += (int) $row['total_leads'];
                }
                $stmtLeadsCount->close();
            }

            // QL / SV counts
            $sqlMetaQlSv = "SELECT
                    COALESCE(CASE WHEN LOWER(TRIM(campaignsource)) = 'whatsapp' THEN '{$waCampaignSql}' ELSE campaign_name END, '') AS campaign_name,
                    COALESCE(adset_name, '') AS adset_name,
                    COALESCE(ad_name, '') AS ad_name,
                    TRIM(COALESCE(ad_id, '')) AS ad_id,
                    SUM(CASE WHEN TRIM(UPPER(lead_status)) IN ('QUALIFIED','LOST POST QUALIFIED','LOST POST QUALIFICATION') THEN 1 ELSE 0 END) AS ql,
                    SUM(CASE WHEN TRIM(UPPER(sitevisit_status)) = 'VISITED' THEN 1 ELSE 0 END) AS sv_done
                FROM `lead`
                WHERE createddate >= ? AND createddate <= ?
                    AND (campaign_name IS NOT NULL AND campaign_name <> '' OR LOWER(TRIM(campaignsource)) = 'whatsapp')
                    AND (leadgen_id IS NOT NULL AND TRIM(leadgen_id) != '' OR LOWER(TRIM(campaignsource)) IN ('fb','ig','facebook','instagram','whatsapp'))
                    $leadsStatusCond
                GROUP BY CASE WHEN LOWER(TRIM(campaignsource)) = 'whatsapp' THEN '{$waCampaignSql}' ELSE campaign_name END, adset_name, ad_name, TRIM(COALESCE(ad_id, ''))";
            $stmtQlSv = $dbConn->prepare($sqlMetaQlSv);
            if ($stmtQlSv) {
                $stmtQlSv->bind_param('ss', $dbStart, $dbEnd);
                $stmtQlSv->execute();
                $resQlSv = $stmtQlSv->get_result();
                while ($row = $resQlSv->fetch_assoc()) {
                    $key = metaReportLeadKey($row);
                    if ($key === null) continue;
                    $metaDbLeads[$key] = $metaDbLeads[$key] ?? ['total_leads' => 0, 'ql' => 0, 'sv_done' => 0];
                    $metaDbLeads[$key]['ql'] += (int) $row['ql'];
                    $metaDbLeads[$key]['sv_done'] += (int) $row['sv_done'];
                }
                $stmtQlSv->close();
            }
        }

        // Also aggregate DB totals by campaign_name for campaign-level fallback matching
        $campDbTotals = [];
        foreach ($metaDbLeads as $leadKey => $counts) {
            $parts = explode('|||', $leadKey);
            $cKey = $parts[0] ?? '';
            if ($cKey === '') continue;
            if (!isset($campDbTotals[$cKey])) {
                $campDbTotals[$cKey] = ['total_leads' => 0, 'ql' => 0, 'sv_done' => 0];
            }
            $campDbTotals[$cKey]['total_leads'] += $counts['total_leads'];
            $campDbTotals[$cKey]['ql'] += $counts['ql'];
            $campDbTotals[$cKey]['sv_done'] += $counts['sv_done'];
        }

        // Build list of all campaign-adset-ad keys from BOTH pivot rows and database leads
        $allKeys = [];
        foreach ($metaPivot['rows'] ?? [] as $r) {
            $cName = $r['campaign_name'] ?: 'Unknown';
            $cNameKey = strtolower(trim($cName));
            if ($cNameKey === '') continue;

            // Only campaigns saved for this project (campaigns table) — none linked means none reported.
            if (!metaIsProjectCampaign((string) ($r['campaign_id'] ?? ''), $cName)) {
                continue;
            }

            $aName = $r['adset_name'] ?: $cName;
            $adName = $r['ad_name'] ?: $aName;
            $leadKey = $cNameKey . '|||' . strtolower(trim($aName)) . '|||' . strtolower(trim($adName));   // saved names
            $allKeys[$leadKey] = [
                'campaign_name' => $cName,
                'adset_name' => $aName,
                'ad_name' => $adName,
                'impressions' => (int)$r['impressions'],
                'clicks' => (int)$r['clicks'],
                'spend' => (float)$r['spend'],
            ];
        }

        foreach ($metaDbLeads as $leadKey => $dbLeads) {
            if (!isset($allKeys[$leadKey])) {
                $parts = explode('|||', $leadKey);
                $cName = $parts[0] ?? 'Unknown';
                $aName = $parts[1] ?? $cName;
                $adName = $parts[2] ?? $aName;
                if (strtolower(trim($cName)) === '') continue;
                // Keys are built from saved names (metaReportLeadKey); show them with their saved spelling.
                $pcid = projectCampaignId('meta', '', $cName);
                if ($pcid === null) continue;
                $cName = projectStructure('meta')['campaigns'][$pcid];

                $allKeys[$leadKey] = [
                    'campaign_name' => $cName,
                    'adset_name'    => $aName,
                    'ad_name'       => $adName,
                    'impressions'   => 0,
                    'clicks'        => 0,
                    'spend'         => 0.0,
                ];
            }
        }

        // Build hierarchical tree from all compiled keys
        foreach ($allKeys as $leadKey => $r) {
            $cName = $r['campaign_name'];
            $aName = $r['adset_name'];
            $adName = $r['ad_name'];
            $dbLeads = $metaDbLeads[$leadKey] ?? ['total_leads' => 0, 'ql' => 0, 'sv_done' => 0];

            $metaTree[$cName][$aName][$adName] = [
                'platform' => 'Meta',
                'type' => 'ad',
                'name' => $adName,
                'level' => 3,
                'impressions' => $r['impressions'],
                'clicks' => $r['clicks'],
                'leads' => $dbLeads['total_leads'],
                'spend' => $r['spend'],
                'ql' => $dbLeads['ql'],
                'sv_done' => $dbLeads['sv_done'],
            ];
        }

        // Ensure campaign-level totals match campDbTotals if adset/ad matching was incomplete
        foreach ($metaTree as $cName => &$adsets) {
            $cKey = strtolower(trim($cName));
            if (!isset($campDbTotals[$cKey])) continue;
            
            $dbTotalLeads = $campDbTotals[$cKey]['total_leads'];
            $dbTotalQl = $campDbTotals[$cKey]['ql'];
            $dbTotalSv = $campDbTotals[$cKey]['sv_done'];

            $treeLeads = 0; $treeQl = 0; $treeSv = 0;
            $firstAdset = null; $firstAd = null;
            foreach ($adsets as $aName => &$ads) {
                foreach ($ads as $adName => &$ad) {
                    $treeLeads += $ad['leads'];
                    $treeQl += $ad['ql'];
                    $treeSv += $ad['sv_done'];
                    if ($firstAdset === null) {
                        $firstAdset = $aName;
                        $firstAd = $adName;
                    }
                }
                unset($ad);
            }
            unset($ads);

            // If DB had leads for this campaign that were unassigned to specific ad keys, allocate to first ad
            if ($firstAdset !== null && $firstAd !== null) {
                if ($dbTotalLeads > $treeLeads) {
                    $adsets[$firstAdset][$firstAd]['leads'] += ($dbTotalLeads - $treeLeads);
                }
                if ($dbTotalQl > $treeQl) {
                    $adsets[$firstAdset][$firstAd]['ql'] += ($dbTotalQl - $treeQl);
                }
                if ($dbTotalSv > $treeSv) {
                    $adsets[$firstAdset][$firstAd]['sv_done'] += ($dbTotalSv - $treeSv);
                }
            }
        }
        unset($adsets);
    } catch (Throwable $e) {
        error_log('[portfolio_report_api][Meta] ' . $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine());
    }

    // Collapse tree into rows compatible with existing format
    $metaSubRows = [];
    foreach ($metaTree as $cName => $adsets) {
        $campRow = emptyRow('Meta', 'campaign', $cName, 1);
        $campSubRows = [];
        foreach ($adsets as $aName => $ads) {
            $adsetRow = emptyRow('Meta', 'adset', $aName, 2);
            $adsetSubRows = [];
            foreach ($ads as $adName => $ad) {
                if ($ad['spend'] > 0 || $ad['leads'] > 0) {
                    $adsetSubRows[] = finalizeRow($ad);
                    addCampaignToRow($adsetRow, $ad);
                }
            }
            if ($adsetRow['spend'] > 0 || $adsetRow['leads'] > 0) {
                $campSubRows[] = finalizeRow($adsetRow);
                $campSubRows = array_merge($campSubRows, $adsetSubRows);
                addCampaignToRow($campRow, $adsetRow);
            }
        }
        if ($campRow['spend'] > 0 || $campRow['leads'] > 0) {
            $metaSubRows[] = finalizeRow($campRow);
            $metaSubRows = array_merge($metaSubRows, $campSubRows);
            addCampaignToRow($metaRow, $campRow);
        }
    }
    $metaRow = finalizeRow($metaRow);

    return ['totalRow' => $metaRow, 'subRows' => $metaSubRows];
}
?>
