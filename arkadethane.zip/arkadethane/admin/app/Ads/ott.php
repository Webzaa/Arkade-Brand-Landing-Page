<?php
/**
 * app/Ads/ott.php — MANUAL platforms (OTT Video, Display, MyGate, TOI Interstitial, …): daily numbers entered or
 * pasted by hand, no ad API. Any number of platforms can be added from the admin — no new table per platform.
 *
 * Two tables (created on first use, in the master-tables database — MASTER_TABLES_DB):
 *   ad_platforms        one row per platform: id, platform_key (used in URLs), name, color, lead_sources (JSON),
 *                       columns_json (the page's column layout: order, hidden, custom columns), sort_order
 *   ad_platform_daily   ALL the daily numbers of every platform: platform_id → ad_platforms.id, stat_date, campaign,
 *                       impressions, clicks, reach, views, spend, extra (JSON: values of custom "typed in" columns)
 *                       — unique on platform_id + stat_date + campaign
 * CTR, CPM, CPC, CPV, view rate and frequency are calculated, never stored.
 * The first version's ott_daily / ott_settings tables (if any) are copied in once, automatically, and left untouched.
 * Leads: CRM leads whose campaignsource is one of the platform's lead sources are counted per day,
 * so CPL / CPQL / CPSV work like the other platforms (OTT Video default: OTT_LEAD_SOURCES in config).
 */

require_once dirname(__DIR__) . '/Core/db.php';
require_once __DIR__ . '/master_tables.php';

const OTT_PLATFORM_NAME = 'OTT Video';
const OTT_DEFAULT_CAMPAIGN = 'OTT Video';
const OTT_BASE_FIELDS = ['impressions', 'clicks', 'reach', 'views', 'spend'];
const OTT_COLORS = ['#9B6BF2', '#0EA5E9', '#14B8A6', '#F59E0B', '#EC4899', '#84CC16', '#6366F1', '#F97316'];
const OTT_RESERVED_KEYS = ['meta', 'google', 'taboola', 'overview', 'leads', 'unmapped', 'crm', 'status', 'analytics', 'capi', 'import', 'all', 'new'];

function ottLeadSources(): array
{
    $list = defined('OTT_LEAD_SOURCES') && is_array(OTT_LEAD_SOURCES) ? OTT_LEAD_SOURCES : ['ott', 'ott video', 'ott_video', 'ctv', 'connected tv'];
    return array_values(array_unique(array_map(fn($s) => strtolower(trim((string) $s)), $list)));
}

function ottDb(): mysqli
{
    $db = masterDb();
    if (!$db) {
        throw new RuntimeException('The database for manual platform data is not reachable.');
    }
    static $ready = false;
    if (!$ready) {
        $ready = true;
        $db->query("CREATE TABLE IF NOT EXISTS `ad_platforms` (
            `id`           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            `platform_key` VARCHAR(40)  NOT NULL,
            `name`         VARCHAR(60)  NOT NULL,
            `color`        VARCHAR(7)   NOT NULL DEFAULT '#9B6BF2',
            `lead_sources` TEXT         NULL,
            `columns_json` MEDIUMTEXT   NULL,
            `sort_order`   INT          NOT NULL DEFAULT 0,
            `awareness_json` TEXT       NULL,
            `created_at`   DATETIME     NULL,
            `updated_at`   DATETIME     NULL,
            UNIQUE KEY `platform_key` (`platform_key`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci");
        $db->query("CREATE TABLE IF NOT EXISTS `ad_platform_daily` (
            `id`          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            `platform_id` INT UNSIGNED  NOT NULL,
            `stat_date`   DATE          NOT NULL,
            `campaign`    VARCHAR(191)  NOT NULL DEFAULT '',
            `impressions` BIGINT        NOT NULL DEFAULT 0,
            `clicks`      BIGINT        NOT NULL DEFAULT 0,
            `reach`       BIGINT        NOT NULL DEFAULT 0,
            `views`       BIGINT        NOT NULL DEFAULT 0,
            `spend`       DECIMAL(14,2) NOT NULL DEFAULT 0,
            `extra`       TEXT          NULL,
            `updated_at`  DATETIME      NULL,
            `updated_by`  VARCHAR(100)  NULL,
            UNIQUE KEY `platform_date_campaign` (`platform_id`, `stat_date`, `campaign`),
            KEY `stat_date` (`stat_date`),
            CONSTRAINT `fk_ad_platform_daily_platform` FOREIGN KEY (`platform_id`) REFERENCES `ad_platforms` (`id`) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci");
        // awareness setting (added later): how much of the spend is awareness — see ottAwarenessSplit()
        if (!@$db->query('SELECT `awareness_json` FROM `ad_platforms` LIMIT 0')) {
            $db->query('ALTER TABLE `ad_platforms` ADD COLUMN `awareness_json` TEXT NULL');
        }
        ottMigrateLegacy($db);
        ottDropUnusedDefault($db);
    }
    return $db;
}

/**
 * Manual platforms are optional: OTT Video is no longer added on its own. Earlier versions created an empty
 * "OTT Video" platform automatically — it is removed once, if nobody ever entered a number for it.
 * A platform added from "Add platform" (or one that has numbers) is never touched.
 */
function ottDropUnusedDefault(mysqli $db): void
{
    try {
        require_once dirname(__DIR__) . '/Leads/crm_sfdc.php';   // pqSettingGet / pqSettingPut
        if (pqSettingGet($db, 'ott_default_cleanup')) {
            return;
        }
        $r = $db->query("SELECT p.id, (SELECT COUNT(*) FROM `ad_platform_daily` d WHERE d.platform_id = p.id) AS n
                         FROM `ad_platforms` p WHERE p.platform_key = 'ott' AND (p.columns_json IS NULL OR p.columns_json = '')");
        $row = $r ? $r->fetch_assoc() : null;
        $removed = 0;
        if ($row && (int) $row['n'] === 0) {
            $id = (int) $row['id'];
            $db->query("DELETE FROM `ad_platforms` WHERE id = '{$id}'");
            $removed = 1;
        }
        pqSettingPut($db, 'ott_default_cleanup', ['done' => date('Y-m-d H:i:s'), 'removed' => $removed], 'system');
    } catch (Throwable $e) {
        error_log('[ott] default cleanup: ' . $e->getMessage());
    }
}

/** One-time copy from the first version (ott_settings + ott_daily). No platform is added when there is nothing to copy. */
function ottMigrateLegacy(mysqli $db): void
{
    $r = $db->query('SELECT COUNT(*) AS n FROM `ad_platforms`');
    if (!$r || (int) $r->fetch_assoc()['n'] > 0) {
        return;
    }
    $setting = function (string $k) use ($db): ?string {
        if (!masterTableExists($db, 'ott_settings')) {
            return null;
        }
        $st = $db->prepare('SELECT v FROM `ott_settings` WHERE k = ?');
        $st->bind_param('s', $k);
        $st->execute();
        $row = $st->get_result()->fetch_assoc();
        $st->close();
        return $row ? (string) $row['v'] : null;
    };
    $list = json_decode((string) $setting('platforms'), true);
    if (!is_array($list) || !$list) {
        // OTT Video is optional: only bring it over when the first version has OTT numbers; otherwise nothing is added
        $legacyRows = 0;
        if (masterTableExists($db, 'ott_daily')) {
            $lr = $db->query('SELECT COUNT(*) AS n FROM `ott_daily`');
            $legacyRows = $lr ? (int) ($lr->fetch_assoc()['n'] ?? 0) : 0;
        }
        if ($legacyRows === 0) {
            return;
        }
        $list = [['key' => 'ott', 'name' => OTT_PLATFORM_NAME, 'color' => OTT_COLORS[0]]];
    }
    $now = date('Y-m-d H:i:s');
    $ins = $db->prepare('INSERT INTO `ad_platforms` (platform_key, name, color, lead_sources, columns_json, sort_order, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
    foreach (array_values($list) as $i => $p) {
        $key = preg_replace('/[^a-z0-9_]/', '', strtolower((string) ($p['key'] ?? ''))) ?: 'ott';
        $name = (string) ($p['name'] ?? $key);
        $color = preg_match('/^#[0-9a-f]{6}$/i', (string) ($p['color'] ?? '')) ? (string) $p['color'] : OTT_COLORS[$i % count(OTT_COLORS)];
        $src = isset($p['lead_sources']) && is_array($p['lead_sources']) ? json_encode(array_values($p['lead_sources'])) : null;
        $cols = $setting($key === 'ott' ? 'columns' : 'columns:' . $key);
        $order = ($i + 1) * 10;
        $ins->bind_param('sssssiss', $key, $name, $color, $src, $cols, $order, $now, $now);
        $ins->execute();
    }
    $ins->close();
    if (masterTableExists($db, 'ott_daily')) {
        $hasPf = false;
        try {
            $hasPf = (bool) $db->query('SELECT `platform` FROM `ott_daily` LIMIT 0');
        } catch (Throwable $e) {
            $hasPf = false;
        }
        $on = $hasPf ? "p.platform_key = COALESCE(NULLIF(d.platform, ''), 'ott')" : "p.platform_key = 'ott'";
        $db->query("INSERT INTO `ad_platform_daily` (platform_id, stat_date, campaign, impressions, clicks, reach, views, spend, extra, updated_at, updated_by)
                    SELECT p.id, d.stat_date, d.campaign, d.impressions, d.clicks, d.reach, d.views, d.spend, d.extra, d.updated_at, d.updated_by
                    FROM `ott_daily` d JOIN `ad_platforms` p ON {$on}");
    }
}

/* ------------------------------------------------------------------ platforms */

/** Manual platforms in sidebar order: [{id, key, name, color, lead_sources: [...]}] */
function ottPlatforms(bool $fresh = false): array
{
    static $cache = null;
    if ($cache !== null && !$fresh) {
        return $cache;
    }
    $db = ottDb();
    $res = $db->query('SELECT id, platform_key, name, color, lead_sources, columns_json, awareness_json FROM `ad_platforms` ORDER BY sort_order, id')
        ?: $db->query('SELECT id, platform_key, name, color, lead_sources, columns_json FROM `ad_platforms` ORDER BY sort_order, id');
    $out = [];
    while ($res && ($p = $res->fetch_assoc())) {
        $key = (string) $p['platform_key'];
        $src = json_decode((string) ($p['lead_sources'] ?? ''), true);
        if (!is_array($src)) {
            $src = $key === 'ott' ? ottLeadSources() : [strtolower((string) $p['name']), $key];
        }
        $out[] = ['id' => (int) $p['id'], 'key' => $key, 'name' => (string) $p['name'], 'color' => (string) $p['color'],
                  'lead_sources' => array_values(array_unique(array_filter(array_map(fn($s) => strtolower(trim((string) $s)), $src)))),
                  'columns_json' => (string) ($p['columns_json'] ?? ''),
                  'awareness' => ottAwarenessCfg(json_decode((string) ($p['awareness_json'] ?? ''), true))];
    }
    return $cache = $out;
}

/** One platform by key (as used in URLs); throws when it doesn't exist. */
function ottPlatform(string $key): array
{
    foreach (ottPlatforms() as $p) {
        if ($p['key'] === $key) {
            return $p;
        }
    }
    throw new InvalidArgumentException('Unknown platform.');
}

/** ad_platforms.id of a platform key. */
function ottPid(string $key): int
{
    return ottPlatform($key)['id'];
}

/** Public fields only (no column layout) — for the API / sidebar. */
function ottPlatformPublic(array $p): array
{
    return ['id' => $p['id'], 'key' => $p['key'], 'name' => $p['name'], 'color' => $p['color'], 'lead_sources' => $p['lead_sources'],
            'awareness' => $p['awareness'] ?? ottAwarenessCfg(null)];
}

/* ------------------------------------------------------------------ awareness */

/**
 * How much of a manual platform's spend is awareness (its share shows in the Awareness tab, the rest in the
 * Performance tab — the same tabs as Meta / Google):
 *   none       all spend is performance (default)
 *   all        all spend is awareness
 *   campaigns  the spend of the campaigns listed in 'campaigns'
 *   amount     a fixed ₹ amount per month ('amounts' = {"2026-10": 50000, …}); it is spread over that month's days
 *              in proportion to their spend, and never more than the month's spend
 */
function ottAwarenessCfg($c): array
{
    $c = is_array($c) ? $c : [];
    $mode = in_array($c['mode'] ?? '', ['none', 'all', 'campaigns', 'amount'], true) ? $c['mode'] : 'none';
    $camps = array_values(array_unique(array_filter(array_map(fn($x) => trim(mb_substr((string) $x, 0, 191)), (array) ($c['campaigns'] ?? [])), fn($x) => $x !== '')));
    $amounts = [];
    foreach ((array) ($c['amounts'] ?? []) as $m => $v) {
        if (preg_match('/^\d{4}-(0[1-9]|1[0-2])$/', (string) $m) && is_numeric($v) && (float) $v > 0) {
            $amounts[(string) $m] = round((float) $v, 2);
        }
    }
    ksort($amounts);
    return ['mode' => $mode, 'campaigns' => array_slice($camps, 0, 300), 'amounts' => $amounts];
}

/** Saves the awareness setting of a platform. $in = {mode, campaigns?: [...], amounts?: {"YYYY-MM": n}} */
function ottSaveAwareness(string $key, array $in, string $user): array
{
    $p = ottPlatform($key);
    $cfg = ottAwarenessCfg($in);
    if ($cfg['mode'] === 'campaigns' && !$cfg['campaigns']) {
        throw new InvalidArgumentException('Tick at least one campaign, or choose another option.');
    }
    if ($cfg['mode'] === 'amount' && !$cfg['amounts']) {
        throw new InvalidArgumentException('Enter the awareness amount for at least one month, or choose another option.');
    }
    $json = json_encode($cfg + ['by' => $user, 'at' => date('Y-m-d H:i:s')], JSON_UNESCAPED_UNICODE);
    $now = date('Y-m-d H:i:s');
    $id = (int) $p['id'];
    $st = ottDb()->prepare('UPDATE `ad_platforms` SET awareness_json = ?, updated_at = ? WHERE id = ?');
    $st->bind_param('ssi', $json, $now, $id);
    if (!$st->execute()) {
        throw new RuntimeException('Could not save: ' . ottDb()->error);
    }
    $st->close();
    ottPlatforms(true);
    masterClearDashboardCache();
    return $cfg;
}

/** Spend per month and per campaign over all saved days — for the awareness editor. */
function ottSpendBreakdown(string $pf): array
{
    $months = $camps = [];
    foreach (ottRows($pf, '', '') as $r) {
        $m = substr($r['date'], 0, 7);
        $months[$m] = ($months[$m] ?? 0) + $r['spend'];
        $camps[$r['campaign']] = ($camps[$r['campaign']] ?? 0) + $r['spend'];
    }
    krsort($months);
    $out = ['months' => [], 'campaigns' => []];
    foreach ($months as $m => $v) {
        $out['months'][] = ['month' => $m, 'spend' => round($v, 2)];
    }
    arsort($camps);
    foreach ($camps as $c => $v) {
        $out['campaigns'][] = ['name' => (string) $c, 'spend' => round($v, 2)];
    }
    return $out;
}

/**
 * The awareness part of each row's spend (same keys as $rows) for a platform's setting.
 * For 'amount' the whole month's spend is read, so a part of a month gets its share of that month's amount.
 */
function ottAwarenessSplit(array $plat, array $rows): array
{
    $cfg = $plat['awareness'] ?? ottAwarenessCfg(null);
    $out = [];
    if ($cfg['mode'] === 'amount') {
        $factor = [];
        foreach ($rows as $r) {
            $m = substr($r['date'], 0, 7);
            if (isset($factor[$m])) {
                continue;
            }
            $amt = (float) ($cfg['amounts'][$m] ?? 0);
            if ($amt <= 0) {
                $factor[$m] = 0.0;
                continue;
            }
            $monthSpend = array_sum(array_column(ottRows($plat['key'], $m . '-01', date('Y-m-t', strtotime($m . '-01'))), 'spend'));
            $factor[$m] = $monthSpend > 0 ? min(1.0, $amt / $monthSpend) : 0.0;
        }
    }
    foreach ($rows as $i => $r) {
        $sp = (float) $r['spend'];
        $out[$i] = match ($cfg['mode']) {
            'all' => $sp,
            'campaigns' => in_array($r['campaign'], $cfg['campaigns'], true) ? $sp : 0.0,
            'amount' => $sp * ($factor[substr($r['date'], 0, 7)] ?? 0),
            default => 0.0,
        };
    }
    return $out;
}

/** {view, tabs, included, tagged, count, spend, mode} — same shape as Meta / Google (pqApplyView). */
function ottAwarenessInfo(array $plat, array $rows, array $split): array
{
    $camps = [];
    foreach ($rows as $i => $r) {
        if (($split[$i] ?? 0) > 0) {
            $camps[$r['campaign']] = true;
        }
    }
    $cfg = $plat['awareness'] ?? ottAwarenessCfg(null);
    $awSpend = round(array_sum($split), 2);
    $total = round(array_sum(array_column($rows, 'spend')), 2);
    $seeAw = pqCanSeeType('awareness');
    return ['view' => pqCampaignView(), 'tabs' => pqViewTabs(), 'types' => ottPlatformTypes($plat),
            'awareness' => $seeAw ? ['count' => count($camps), 'spend' => $awSpend] : null,
            'performance' => pqCanSeeType('performance') ? ['count' => 0, 'spend' => round($total - $awSpend, 2)] : null,
            'included' => pqAwarenessIncluded(), 'tagged' => $cfg['mode'] === 'none' ? 0 : max(1, count($camps)), 'count' => count($camps),
            'spend' => $seeAw ? $awSpend : 0.0, 'mode' => $cfg['mode']];
}

/* ------------------------------------------------------------------ All / Performance / Awareness */

/** Campaign types a manual platform has: 'all' awareness → [awareness], 'none' → [performance], else both. */
function ottPlatformTypes(array $plat): array
{
    $mode = ($plat['awareness'] ?? ottAwarenessCfg(null))['mode'];
    return match ($mode) {
        'all' => ['awareness'],
        'none' => ['performance'],
        default => ['performance', 'awareness'],
    };
}

/** May this viewer see the platform at all (menu, All Platforms, its dashboard)? (Users & Roles → Campaign types) */
function ottPlatformVisible(array $plat): bool
{
    return (bool) array_intersect(ottPlatformTypes($plat), pqViewTypes());
}

/** Manual platforms this viewer may see. */
function ottVisiblePlatforms(): array
{
    return array_values(array_filter(ottPlatforms(), 'ottPlatformVisible'));
}

/**
 * Rows of a manual platform for a view: 'all' = as saved; 'performance' / 'awareness' = each row's share of that type
 * (spend from ottAwarenessSplit; impressions, clicks, reach, views in the same proportion). Rows with nothing of
 * the type are left out. A changed row keeps its saved numbers in 'raw' (for Edit) when the viewer may see both types.
 * Leads (not tied to a campaign) belong to awareness only when the whole platform is awareness.
 * @return array{0: array, 1: bool} [rows, leads belong to this view]
 */
function ottViewRows(array $plat, array $rows, array $split, string $view): array
{
    $mode = ($plat['awareness'] ?? ottAwarenessCfg(null))['mode'];
    $leadsType = $mode === 'all' ? 'awareness' : 'performance';
    if ($view === 'all') {
        return [$rows, true];
    }
    $camps = ($plat['awareness'] ?? ottAwarenessCfg(null))['campaigns'];
    $both = count(pqViewTypes()) > 1;
    $out = [];
    foreach ($rows as $i => $r) {
        $sp = (float) $r['spend'];
        $aw = (float) ($split[$i] ?? 0);
        if ($sp > 0) {
            $share = $view === 'awareness' ? $aw / $sp : ($sp - $aw) / $sp;
        } else {   // a day with no spend: by the setting
            $isAw = $mode === 'all' || ($mode === 'campaigns' && in_array($r['campaign'], $camps, true));
            $share = ($view === 'awareness') === $isAw ? 1.0 : 0.0;
        }
        $share = max(0.0, min(1.0, $share));
        if ($share <= 0.0001) {
            continue;
        }
        if ($share < 0.9999) {
            $raw = $r;
            foreach (['impressions', 'clicks', 'reach', 'views'] as $k) {
                $r[$k] = (int) round($r[$k] * $share);
            }
            $r['spend'] = round($view === 'awareness' ? $aw : $sp - $aw, 2);
            $r['share'] = round($share, 4);
            if ($both) {
                unset($raw['aw']);
                $r['raw'] = $raw;
            }
        }
        $out[] = $r;
    }
    return [$out, $leadsType === $view];
}

/** Adds or edits a platform. $in = {key?, name, color?, lead_sources?: "a, b" | [...]} */
function ottSavePlatform(array $in): array
{
    $name = trim(mb_substr((string) ($in['name'] ?? ''), 0, 60));
    if ($name === '') {
        throw new InvalidArgumentException('Give the platform a name.');
    }
    $list = ottPlatforms(true);
    $key = (string) ($in['key'] ?? '');
    $isNew = $key === '';
    if ($isNew) {
        $base = substr(trim(preg_replace('/[^a-z0-9]+/', '_', strtolower($name)), '_') ?: 'platform', 0, 30);
        $key = $base;
        $n = 2;
        while (in_array($key, array_column($list, 'key'), true) || in_array($key, OTT_RESERVED_KEYS, true)) {
            $key = $base . '_' . $n++;
        }
    } else {
        ottPlatform($key);
    }
    foreach ($list as $p) {
        if ($p['key'] !== $key && strcasecmp($p['name'], $name) === 0) {
            throw new InvalidArgumentException("There is already a platform called \"{$name}\".");
        }
    }
    $color = preg_match('/^#[0-9a-f]{6}$/i', (string) ($in['color'] ?? '')) ? (string) $in['color'] : OTT_COLORS[count($list) % count(OTT_COLORS)];
    $src = $in['lead_sources'] ?? null;
    if (is_string($src)) {
        $src = explode(',', $src);
    }
    $srcJson = is_array($src) ? json_encode(array_values(array_filter(array_map(fn($s) => strtolower(trim((string) $s)), $src)))) : null;
    $now = date('Y-m-d H:i:s');
    $db = ottDb();
    if ($isNew) {
        $srcJson ??= json_encode([strtolower($name), $key]);
        $order = (count($list) + 1) * 10;
        $st = $db->prepare('INSERT INTO `ad_platforms` (platform_key, name, color, lead_sources, sort_order, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)');
        $st->bind_param('ssssiss', $key, $name, $color, $srcJson, $order, $now, $now);
    } elseif ($srcJson !== null) {
        $st = $db->prepare('UPDATE `ad_platforms` SET name = ?, color = ?, lead_sources = ?, updated_at = ? WHERE platform_key = ?');
        $st->bind_param('sssss', $name, $color, $srcJson, $now, $key);
    } else {
        $st = $db->prepare('UPDATE `ad_platforms` SET name = ?, color = ?, updated_at = ? WHERE platform_key = ?');
        $st->bind_param('ssss', $name, $color, $now, $key);
    }
    if (!$st->execute()) {
        throw new RuntimeException('Could not save the platform: ' . $db->error);
    }
    $st->close();
    ottPlatforms(true);
    masterClearDashboardCache();
    return ottPlatformPublic(ottPlatform($key));
}

/** Removes a platform and all its rows. Returns the number of rows deleted. */
function ottDeletePlatform(string $key): int
{
    $id = ottPid($key);
    $db = ottDb();
    $db->begin_transaction();
    try {
        $st = $db->prepare('DELETE FROM `ad_platform_daily` WHERE platform_id = ?');
        $st->bind_param('i', $id);
        $st->execute();
        $n = (int) $st->affected_rows;
        $st->close();
        $st = $db->prepare('DELETE FROM `ad_platforms` WHERE id = ?');
        $st->bind_param('i', $id);
        $st->execute();
        $st->close();
        $db->commit();
    } catch (Throwable $e) {
        $db->rollback();
        throw $e;
    }
    ottPlatforms(true);
    masterClearDashboardCache();
    return $n;
}

/* ------------------------------------------------------------------ rows */

/** Daily rows in a period (optionally one campaign), oldest first. */
function ottRows(string $pf, string $since, string $until, string $campaign = ''): array
{
    $db = ottDb();
    $sql = 'SELECT id, stat_date, campaign, impressions, clicks, reach, views, spend, extra FROM `ad_platform_daily` WHERE platform_id = ?';
    $types = 'i';
    $args = [ottPid($pf)];
    if ($since !== '') {
        $sql .= ' AND stat_date >= ?';
        $types .= 's';
        $args[] = $since;
    }
    if ($until !== '') {
        $sql .= ' AND stat_date <= ?';
        $types .= 's';
        $args[] = $until;
    }
    if ($campaign !== '') {
        $sql .= ' AND campaign = ?';
        $types .= 's';
        $args[] = $campaign;
    }
    $sql .= ' ORDER BY stat_date, campaign';
    $st = $db->prepare($sql);
    if (!$st) {
        throw new RuntimeException('Could not read OTT data: ' . $db->error);
    }
    $st->bind_param($types, ...$args);
    $st->execute();
    $res = $st->get_result();
    $out = [];
    while ($r = $res->fetch_assoc()) {
        $extra = json_decode((string) ($r['extra'] ?? ''), true);
        $out[] = ['id' => (int) $r['id'], 'date' => (string) $r['stat_date'], 'campaign' => (string) $r['campaign'],
            'impressions' => (int) $r['impressions'], 'clicks' => (int) $r['clicks'], 'reach' => (int) $r['reach'],
            'views' => (int) $r['views'], 'spend' => round((float) $r['spend'], 2), 'extra' => is_array($extra) ? $extra : []];
    }
    $st->close();
    return $out;
}

function ottCampaigns(string $pf): array
{
    $pid = ottPid($pf);
    $st = ottDb()->prepare('SELECT campaign, MIN(stat_date) AS first, MAX(stat_date) AS last, COUNT(*) AS days FROM `ad_platform_daily` WHERE platform_id = ? GROUP BY campaign ORDER BY campaign');
    $st->bind_param('i', $pid);
    $st->execute();
    $res = $st->get_result();
    $out = [];
    while ($res && ($r = $res->fetch_assoc())) {
        $out[] = ['name' => (string) $r['campaign'], 'first' => (string) $r['first'], 'last' => (string) $r['last'], 'days' => (int) $r['days']];
    }
    return $out;
}

function ottNum($v): float
{
    if (is_int($v) || is_float($v)) {
        return (float) $v;
    }
    $s = str_replace([',', '₹', ' ', "\u{00A0}"], '', trim((string) $v));
    return is_numeric($s) ? (float) $s : 0.0;
}

/** Validates one row from the page / an import. */
function ottCleanRow(array $r, array $manualKeys, string $defCampaign = OTT_DEFAULT_CAMPAIGN): array
{
    $d = trim((string) ($r['date'] ?? ''));
    $dt = DateTime::createFromFormat('!Y-m-d', $d);
    if (!$dt || $dt->format('Y-m-d') !== $d) {
        throw new InvalidArgumentException("Date \"{$d}\" is not a valid date (YYYY-MM-DD).");
    }
    $campaign = trim((string) ($r['campaign'] ?? '')) ?: $defCampaign;
    $row = ['date' => $d, 'campaign' => mb_substr($campaign, 0, 191)];
    foreach (OTT_BASE_FIELDS as $f) {
        $n = ottNum($r[$f] ?? 0);
        if ($n < 0) {
            throw new InvalidArgumentException(ucfirst($f) . " can't be negative ({$d}).");
        }
        $row[$f] = $f === 'spend' ? round($n, 2) : (int) round($n);
    }
    $extra = [];
    foreach ($manualKeys as $k) {
        if (isset($r['extra'][$k]) && $r['extra'][$k] !== '' && $r['extra'][$k] !== null) {
            $extra[$k] = ottNum($r['extra'][$k]);
        }
    }
    $row['extra'] = $extra;
    return $row;
}

/** Insert or replace rows (unique on date + campaign). Returns [inserted, updated]. */
function ottSaveRows(string $pf, array $rows, string $user): array
{
    $db = ottDb();
    $plat = ottPlatform($pf);
    $manual = array_column(array_filter(ottColumns($pf)['custom'], fn($c) => $c['type'] === 'manual'), 'key');
    $clean = [];
    foreach ($rows as $i => $r) {
        try {
            $clean[] = ottCleanRow((array) $r, $manual, $plat['name']);
        } catch (InvalidArgumentException $e) {
            throw new InvalidArgumentException('Row ' . ($i + 1) . ': ' . $e->getMessage());
        }
    }
    $pid = (int) $plat['id'];
    $sel = $db->prepare('SELECT id, extra FROM `ad_platform_daily` WHERE platform_id = ? AND stat_date = ? AND campaign = ?');
    $ins = $db->prepare('INSERT INTO `ad_platform_daily` (platform_id, stat_date, campaign, impressions, clicks, reach, views, spend, extra, updated_at, updated_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
    $upd = $db->prepare('UPDATE `ad_platform_daily` SET impressions = ?, clicks = ?, reach = ?, views = ?, spend = ?, extra = ?, updated_at = ?, updated_by = ? WHERE id = ?');
    if (!$sel || !$ins || !$upd) {
        throw new RuntimeException('Could not prepare the OTT save: ' . $db->error);
    }
    $now = date('Y-m-d H:i:s');
    $n = ['inserted' => 0, 'updated' => 0];
    $db->begin_transaction();
    try {
        foreach ($clean as $r) {
            $sel->bind_param('iss', $pid, $r['date'], $r['campaign']);
            $sel->execute();
            $cur = $sel->get_result()->fetch_assoc();
            if ($cur) {
                $old = json_decode((string) ($cur['extra'] ?? ''), true);
                $extra = json_encode(array_merge(is_array($old) ? $old : [], $r['extra']));
                $id = (int) $cur['id'];
                $upd->bind_param('iiiidsssi', $r['impressions'], $r['clicks'], $r['reach'], $r['views'], $r['spend'], $extra, $now, $user, $id);
                $upd->execute();
                $n['updated']++;
            } else {
                $extra = json_encode($r['extra']);
                $ins->bind_param('issiiiidsss', $pid, $r['date'], $r['campaign'], $r['impressions'], $r['clicks'], $r['reach'], $r['views'], $r['spend'], $extra, $now, $user);
                $ins->execute();
                $n['inserted']++;
            }
        }
        $db->commit();
    } catch (Throwable $e) {
        $db->rollback();
        throw $e;
    }
    masterClearDashboardCache();
    return $n;
}

function ottDeleteRows(string $pf, array $ids): int
{
    $ids = array_values(array_filter(array_map('intval', $ids), fn($v) => $v > 0));
    if (!$ids) {
        throw new InvalidArgumentException('Nothing selected.');
    }
    $db = ottDb();
    $db->query('DELETE FROM `ad_platform_daily` WHERE platform_id = ' . ottPid($pf) . ' AND id IN (' . implode(',', $ids) . ')');
    masterClearDashboardCache();
    return count($ids);
}

/* ------------------------------------------------------------------ leads */

/** Leads per day from the OTT lead sources (all lead databases, test leads left out). */
function ottLeadsByDay(string $pf, string $since, string $until): array
{
    $sources = ottPlatform($pf)['lead_sources'];
    if (!$sources) {
        return [];
    }
    $out = [];
    $seen = [];
    foreach (leadDbs('all') as $db) {
        $in = implode(',', array_map(fn($s) => "'" . $db->real_escape_string($s) . "'", $sources));
        $where = "LOWER(TRIM(COALESCE(campaignsource, ''))) IN ({$in})";
        if ($since !== '') {
            $where .= " AND createddate >= '" . $db->real_escape_string($since) . " 00:00:00'";
        }
        if ($until !== '') {
            $where .= " AND createddate <= '" . $db->real_escape_string($until) . " 23:59:59'";
        }
        $res = $db->query("SELECT id, name, email, mobile, lead_status, sitevisit_status, DATE(createddate) AS d FROM `lead` WHERE {$where}");
        while ($res && ($l = $res->fetch_assoc())) {
            $st = strtoupper(trim((string) $l['lead_status']));
            if (in_array($st, ['TEST', 'JUNK'], true) || str_contains(strtolower((string) $l['name'] . ' ' . $l['email']), 'test')) {
                continue;
            }
            $mob = preg_replace('/\D+/', '', (string) $l['mobile']);
            $key = strlen($mob) >= 6 ? substr($mob, -10) : 'id' . $l['id'];
            if (isset($seen[$key])) {
                continue;      // one person once (same as All Platforms)
            }
            $seen[$key] = true;
            $d = (string) $l['d'];
            $out[$d] ??= ['leads' => 0, 'qualified' => 0, 'sitevisits' => 0];
            $out[$d]['leads']++;
            if (in_array($st, ['QUALIFIED', 'LOST POST QUALIFIED', 'LOST POST QUALIFICATION'], true)) {
                $out[$d]['qualified']++;
            }
            if (in_array(strtoupper(trim((string) $l['sitevisit_status'])), ['VISITED', 'VISIT DONE', 'SITE VISIT DONE', 'SITE VISIT', 'WALKIN', 'WALK-IN', 'DONE', 'YES', 'CONDUCTED'], true)) {
                $out[$d]['sitevisits']++;
            }
        }
    }
    return $out;
}

/** Totals with every calculated metric. */
function ottTotals(array $rows, array $leads): array
{
    $t = ['impressions' => 0, 'clicks' => 0, 'reach' => 0, 'views' => 0, 'spend' => 0.0, 'leads' => 0, 'qualified' => 0, 'sitevisits' => 0];
    foreach ($rows as $r) {
        foreach (OTT_BASE_FIELDS as $f) {
            $t[$f] += $r[$f];
        }
    }
    foreach ($leads as $l) {
        foreach (['leads', 'qualified', 'sitevisits'] as $f) {
            $t[$f] += $l[$f];
        }
    }
    $div = fn($a, $b, $m = 1) => $b > 0 ? round($a / $b * $m, 4) : null;
    $t['spend'] = round($t['spend'], 2);
    $t['ctr'] = $div($t['clicks'], $t['impressions'], 100);
    $t['cpm'] = $div($t['spend'], $t['impressions'], 1000);
    $t['cpc'] = $div($t['spend'], $t['clicks']);
    $t['cpv'] = $div($t['spend'], $t['views']);
    $t['view_rate'] = $div($t['views'], $t['impressions'], 100);
    $t['frequency'] = $div($t['impressions'], $t['reach']);
    $t['cpl'] = $div($t['spend'], $t['leads']);
    $t['cpql'] = $div($t['spend'], $t['qualified']);
    $t['cpsv'] = $div($t['spend'], $t['sitevisits']);
    return $t;
}

/* ------------------------------------------------------------------ columns */

/** Built-in columns: key => [label, kind]. kind: base (stored), calc (calculated), lead (from the CRM). */
const OTT_COLUMNS = [
    'date'        => ['Date', 'dim'],
    'campaign'    => ['Campaign', 'dim'],
    'impressions' => ['Impressions', 'base'],
    'clicks'      => ['Clicks', 'base'],
    'ctr'         => ['CTR', 'calc'],
    'reach'       => ['Reach', 'base'],
    'frequency'   => ['Frequency', 'calc'],
    'views'       => ['Views', 'base'],
    'view_rate'   => ['View rate', 'calc'],
    'spend'       => ['Spend', 'base'],
    'cpm'         => ['CPM', 'calc'],
    'cpc'         => ['CPC', 'calc'],
    'cpv'         => ['CPV (cost per view)', 'calc'],
    'leads'       => ['Leads', 'lead'],
    'cpl'         => ['CPL', 'lead'],
    'qualified'   => ['Qualified', 'lead'],
    'cpql'        => ['CPQL', 'lead'],
    'sitevisits'  => ['Site visits', 'lead'],
    'cpsv'        => ['CPSV', 'lead'],
];
const OTT_DEFAULT_ORDER = ['date', 'impressions', 'clicks', 'ctr', 'reach', 'views', 'spend', 'cpm', 'cpv', 'view_rate', 'frequency',
                           'campaign', 'cpc', 'leads', 'cpl', 'qualified', 'cpql', 'sitevisits', 'cpsv'];
const OTT_DEFAULT_HIDDEN = ['campaign', 'cpc', 'leads', 'cpl', 'qualified', 'cpql', 'sitevisits', 'cpsv'];
const OTT_NO_VIEWS_HIDDEN = ['views', 'view_rate', 'cpv'];   // other manual platforms start without the video columns

/** Column layout: {order: [...keys], hidden: [...keys], custom: [{key, label, type: manual|formula, formula?, format}]} */
function ottColumns(string $pf): array
{
    $saved = json_decode(ottPlatform($pf)['columns_json'], true);
    $cfg = ['order' => OTT_DEFAULT_ORDER, 'hidden' => $pf === 'ott' ? OTT_DEFAULT_HIDDEN : array_merge(OTT_DEFAULT_HIDDEN, OTT_NO_VIEWS_HIDDEN), 'custom' => []];
    if (is_array($saved)) {
        foreach (['order', 'hidden', 'custom'] as $k) {
            if (isset($saved[$k]) && is_array($saved[$k])) {
                $cfg[$k] = $saved[$k];
            }
        }
    }
    $known = array_merge(array_keys(OTT_COLUMNS), array_column($cfg['custom'], 'key'));
    $cfg['order'] = array_values(array_unique(array_merge(array_values(array_intersect($cfg['order'], $known)), $known)));
    $cfg['hidden'] = array_values(array_intersect($cfg['hidden'], $known));
    return $cfg;
}

/** A formula may use column keys, numbers, + - * / ( ) only. */
function ottFormulaOk(string $f, array $keys): bool
{
    if (trim($f) === '' || !preg_match('/^[a-z0-9_\s\.\+\-\*\/\(\)]+$/i', $f)) {
        return false;
    }
    preg_match_all('/[a-z_][a-z0-9_]*/i', $f, $m);
    foreach ($m[0] as $id) {
        if (!in_array($id, $keys, true)) {
            return false;
        }
    }
    return substr_count($f, '(') === substr_count($f, ')');
}

function ottSaveColumns(string $pf, array $in): array
{
    ottPlatform($pf);
    $custom = [];
    $keys = array_keys(OTT_COLUMNS);
    foreach ((array) ($in['custom'] ?? []) as $c) {
        $label = trim(mb_substr((string) ($c['label'] ?? ''), 0, 40));
        $key = preg_replace('/[^a-z0-9_]/', '', strtolower((string) ($c['key'] ?? '')));
        $type = ($c['type'] ?? '') === 'formula' ? 'formula' : 'manual';
        $format = in_array($c['format'] ?? '', ['number', 'money', 'percent', 'decimal'], true) ? $c['format'] : 'number';
        if ($label === '' || $key === '' || !str_starts_with($key, 'x_') || isset(OTT_COLUMNS[$key])) {
            throw new InvalidArgumentException('Each custom column needs a name.');
        }
        $item = ['key' => $key, 'label' => $label, 'type' => $type, 'format' => $format];
        if ($type === 'formula') {
            $formula = trim((string) ($c['formula'] ?? ''));
            if (!ottFormulaOk($formula, array_merge($keys, array_column($custom, 'key')))) {
                throw new InvalidArgumentException("Formula for \"{$label}\" can only use column names, numbers and + - * / ( ).");
            }
            $item['formula'] = $formula;
        }
        $custom[$key] = $item;
        $keys[] = $key;
    }
    $cfg = ['order' => array_values(array_filter((array) ($in['order'] ?? []), 'is_string')),
            'hidden' => array_values(array_filter((array) ($in['hidden'] ?? []), 'is_string')),
            'custom' => array_values($custom)];
    $v = json_encode($cfg, JSON_UNESCAPED_UNICODE);
    $now = date('Y-m-d H:i:s');
    $st = ottDb()->prepare('UPDATE `ad_platforms` SET columns_json = ?, updated_at = ? WHERE platform_key = ?');
    $st->bind_param('sss', $v, $now, $pf);
    $st->execute();
    $st->close();
    ottPlatforms(true);
    return ottColumns($pf);
}
