<?php
/**
 * app/Ads/meta_sync.php — which Meta campaigns belong to THIS project, and syncing them from Meta.
 *
 * The `campaigns` master table (platform = 'meta') is the project's campaign list:
 *   - The Meta dashboard, pivot export and Overview show ONLY campaigns in that table
 *     (matched by campaign ID, or by name for CRM-only rows).
 *   - "Sync with Meta" on the dashboard (public/ads/meta_sync_api.php) fills it:
 *       • suggests campaigns that brought leads to this project (ad_id in the `lead` table → Meta),
 *       • lists every campaign in the ad account(s) so you can tick the ones that belong here,
 *       • saves them with their ad sets and ads (`adgroups`, `ads` tables).
 *
 * Tables live in MASTER_TABLES_DB (config/config.php; default: the first LEAD_DATABASES entry)
 * and are created automatically if missing.
 */

require_once __DIR__ . '/master_tables.php';   // shared campaigns / adgroups / ads logic (all platforms)

const META_SYNC_PLATFORM = 'meta';

/* ======================================================================
 * Master tables — thin Meta wrappers around app/Ads/master_tables.php
 * ====================================================================== */

function metaMasterDb(): ?mysqli { return masterDb(); }
function metaTableExists(mysqli $db, string $table): bool { return masterTableExists($db, $table); }
function metaEnsureMasterTables(mysqli $db): void { masterEnsureTables($db); }
function metaNormName(string $name): string { return masterNorm($name); }
function metaClean($v, int $max = 255): string { return masterClean($v, $max); }
function metaClearDashboardCache(): void { masterClearDashboardCache(); }

/**
 * The project's Meta campaigns (kept for older callers).
 * @return array{ids: array<string,bool>, names: array<string,bool>, count: int, configured: bool, error: ?string}
 */
function metaProjectCampaigns(): array
{
    $s = projectStructure(META_SYNC_PLATFORM);
    return [
        'ids'        => array_fill_keys(array_map('strval', array_keys($s['campaigns'])), true),
        'names'      => array_fill_keys(array_map('strval', array_keys($s['campaign_by_name'])), true),
        'count'      => $s['count'],
        'configured' => $s['configured'],
        'error'      => $s['error'],
    ];
}

function metaIsProjectCampaign(?string $id, ?string $name): bool
{
    return isProjectCampaign(META_SYNC_PLATFORM, $id, $name);
}

/** Only the project's Meta campaigns, with their saved names. @return array{0: array, 1: array} */
function metaApplyProjectFilter(array $campaigns): array
{
    return applyProjectCampaignFilter(META_SYNC_PLATFORM, $campaigns, 'id', ['name', 'campaign', 'campaign_name']);
}

/* ======================================================================
 * Graph API
 * ====================================================================== */

function metaGraphVersion(): string
{
    $v = trim((string) (defined('META_API_VERSION') ? META_API_VERSION : 'v23.0'));
    return ($v !== '' && $v[0] !== 'v') ? 'v' . $v : $v;
}

function metaAccountIds(): array
{
    $ids = [];
    if (defined('META_AD_ACCOUNT_IDS')) {
        $raw = META_AD_ACCOUNT_IDS;
        $ids = is_array($raw) ? $raw : (json_decode((string) $raw, true) ?: [(string) $raw]);
    } elseif (defined('META_AD_ACCOUNT_ID')) {
        $ids = [META_AD_ACCOUNT_ID];
    }
    $ids = array_map(fn($id) => preg_replace('/^act_/i', '', trim((string) $id)), $ids);
    return array_values(array_unique(array_filter($ids, fn($id) => $id !== '')));
}

/** GET a Graph path (or a full "next" URL). Throws RuntimeException on any error. */
function metaGraphGet(string $pathOrUrl, array $params = []): array
{
    if (str_starts_with($pathOrUrl, 'https://')) {
        $url = $pathOrUrl;
    } else {
        $params['access_token'] = (string) (defined('META_ACCESS_TOKEN') ? META_ACCESS_TOKEN : '');
        $url = 'https://graph.facebook.com/' . rawurlencode(metaGraphVersion()) . '/' . ltrim($pathOrUrl, '/')
            . '?' . http_build_query($params, '', '&', PHP_QUERY_RFC3986);
    }
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CONNECTTIMEOUT => 10,
        CURLOPT_TIMEOUT        => 60,
        CURLOPT_HTTPHEADER     => ['Accept: application/json'],
    ]);
    $body = curl_exec($ch);
    $err = curl_error($ch);
    $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
    unset($ch);

    if ($body === false) {
        throw new RuntimeException('Network error talking to Meta: ' . $err);
    }
    $json = json_decode((string) $body, true);
    if (!is_array($json)) {
        throw new RuntimeException("Invalid response from Meta (HTTP {$code}).");
    }
    if ($code < 200 || $code >= 300 || isset($json['error'])) {
        $e = $json['error'] ?? [];
        throw new RuntimeException('Meta: ' . ((string) ($e['message'] ?? "HTTP {$code}")));
    }
    return $json;
}

/** All pages of a Graph list edge. */
function metaGraphAll(string $path, array $params = [], int $maxPages = 50): array
{
    $rows = [];
    // Big campaigns can make Meta answer "Please reduce the amount of data you're asking for":
    // retry the first page with smaller pages before giving up.
    // Temporary Meta errors ("An unexpected error has occurred. Please retry…") get two more tries.
    $limit = (int) ($params['limit'] ?? 0);
    $retries = 2;
    while (true) {
        try {
            $page = metaGraphGet($path, $params);
            break;
        } catch (RuntimeException $e) {
            $msg = $e->getMessage();
            if (stripos($msg, 'reduce the amount of data') !== false && $limit > 25) {
                $limit = max(25, intdiv($limit, 4));
                $params['limit'] = $limit;
                continue;
            }
            if ($retries-- > 0 && (stripos($msg, 'unexpected error') !== false || stripos($msg, 'retry your request') !== false
                    || stripos($msg, 'unknown error') !== false || stripos($msg, 'Network error') !== false)) {
                sleep(2);
                continue;
            }
            throw $e;
        }
    }
    for ($i = 0; $i < $maxPages; $i++) {
        foreach (($page['data'] ?? []) as $r) {
            $rows[] = $r;
        }
        $next = $page['paging']['next'] ?? null;
        if (!$next) {
            break;
        }
        $page = metaGraphGet($next);
    }
    return $rows;
}


/**
 * Every campaign in the ad account(s), with spend for the period.
 * @return array{campaigns: array, errors: array}
 */
function metaListAccountCampaigns(string $since, string $until): array
{
    $out = [];
    $errors = [];
    foreach (metaAccountIds() as $acc) {
        try {
            $list = metaGraphAll("act_{$acc}/campaigns", [
                'fields' => 'id,name,effective_status,created_time,objective',
                'limit'  => 250,
            ]);
            foreach ($list as $c) {
                $id = (string) ($c['id'] ?? '');
                if ($id === '') {
                    continue;
                }
                $out[$id] = [
                    'id'         => $id,
                    'name'       => metaClean($c['name'] ?? ''),
                    'status'     => (string) ($c['effective_status'] ?? ''),
                    'created'    => substr((string) ($c['created_time'] ?? ''), 0, 10),
                    'account_id' => $acc,
                    'objective'  => (string) ($c['objective'] ?? ''),
                    'spend'      => 0.0,
                    'leads_seen' => 0,
                ];
            }
            $ins = metaGraphAll("act_{$acc}/insights", [
                'fields'     => 'campaign_id,spend',
                'level'      => 'campaign',
                'time_range' => json_encode(function_exists('metaSafeSince') ? ['since' => metaSafeSince($since), 'until' => max($until, metaSafeSince($since))] : ['since' => $since, 'until' => $until]),
                'limit'      => 500,
            ]);
            foreach ($ins as $r) {
                $id = (string) ($r['campaign_id'] ?? '');
                if (isset($out[$id])) {
                    $out[$id]['spend'] += (float) ($r['spend'] ?? 0);
                }
            }
        } catch (Throwable $e) {
            $errors[] = "Ad account {$acc}: " . $e->getMessage();
        }
    }
    return ['campaigns' => array_values($out), 'errors' => $errors];
}

/**
 * Meta leads per campaign name in this project's lead table(s) (`campaign_name` column).
 * @return array<string,int> normalised name => leads
 */
function metaLeadCountsByCampaignName(): array
{
    $counts = [];
    foreach (leadDbs('all') as $db) {
        $res = $db->query("SELECT campaign_name, COUNT(*) AS n FROM `lead`
                            WHERE campaign_name IS NOT NULL AND TRIM(campaign_name) <> ''
                            GROUP BY campaign_name");
        while ($res && ($row = $res->fetch_assoc())) {
            $k = metaNormName((string) $row['campaign_name']);
            $counts[$k] = ($counts[$k] ?? 0) + (int) $row['n'];
        }
    }
    return $counts;
}

/**
 * Campaigns that brought leads to THIS project: every ad_id in the lead table(s), looked up in Meta.
 * @return array{campaigns: array<string, array{id:string,name:string,leads:int}>, ads_checked:int, errors:array}
 */
function metaCampaignsFromLeads(): array
{
    $leadsPerAd = [];
    foreach (leadDbs('all') as $db) {
        $res = $db->query("SELECT TRIM(ad_id) AS ad_id, COUNT(*) AS n FROM `lead`
                            WHERE ad_id IS NOT NULL AND TRIM(ad_id) <> '' GROUP BY TRIM(ad_id)");
        while ($res && ($row = $res->fetch_assoc())) {
            $id = (string) $row['ad_id'];
            if (preg_match('/^\d{6,25}$/', $id)) {
                $leadsPerAd[$id] = ($leadsPerAd[$id] ?? 0) + (int) $row['n'];
            }
        }
    }

    $campaigns = [];
    $errors = [];
    foreach (array_chunk(array_keys($leadsPerAd), 50) as $batch) {
        try {
            $found = metaGraphGet('', ['ids' => implode(',', $batch), 'fields' => 'campaign{id,name}']);
        } catch (Throwable $e) {
            // one deleted / foreign ad fails the whole batch → retry one by one
            $found = [];
            foreach ($batch as $one) {
                try {
                    $found += metaGraphGet('', ['ids' => $one, 'fields' => 'campaign{id,name}']);
                } catch (Throwable $e2) {
                    // ad not readable with this token (deleted / other account) — skip
                }
            }
        }
        foreach ($found as $adId => $ad) {
            $c = $ad['campaign'] ?? null;
            if (empty($c['id'])) {
                continue;
            }
            $cid = (string) $c['id'];
            $campaigns[$cid] = $campaigns[$cid] ?? ['id' => $cid, 'name' => metaClean($c['name'] ?? ''), 'leads' => 0];
            $campaigns[$cid]['leads'] += $leadsPerAd[(string) $adId] ?? 0;
        }
        usleep(150000);
    }
    return ['campaigns' => $campaigns, 'ads_checked' => count($leadsPerAd), 'errors' => $errors];
}

/**
 * Save campaigns (by Meta ID) into the project with their ad sets and ads.
 * @return array{campaigns:int, adgroups:int, ads:int, errors:array}
 */
function metaSyncCampaignStructure(mysqli $db, array $campaignIds): array
{
    $done = ['campaigns' => 0, 'adgroups' => 0, 'ads' => 0, 'leads_filled' => 0, 'errors' => [], 'failed' => []];
    $adNames = [];   // ad_id => [campaign name, ad set name, ad name] — to fill blank names on leads

    foreach (array_unique(array_map('strval', $campaignIds)) as $cid) {
        if (!preg_match('/^\d{6,25}$/', $cid)) {
            continue;
        }
        try {
            for ($try = 0; ; $try++) {
                try {
                    $c = metaGraphGet($cid, ['fields' => 'id,name,effective_status']);
                    break;
                } catch (RuntimeException $e) {
                    if ($try >= 2 || !preg_match('/unexpected error|retry your request|unknown error|Network error/i', $e->getMessage())) {
                        throw $e;
                    }
                    sleep(2);   // temporary Meta error — try again
                }
            }
        } catch (Throwable $e) {
            // The campaign itself can't be read (deleted, or in an ad account this token can't open).
            $done['errors'][] = "Campaign {$cid}: " . $e->getMessage();
            $done['failed'][] = $cid;
            continue;
        }
        // Ad sets / ads: if Meta refuses them, still save the campaign and report it.
        $adsets = $ads = [];
        try {
            $adsets = metaGraphAll("{$cid}/adsets", ['fields' => 'id,name,effective_status', 'limit' => 200]);
            $ads = metaGraphAll("{$cid}/ads", ['fields' => 'id,name,effective_status,adset_id', 'limit' => 200]);
        } catch (Throwable $e) {
            $done['errors'][] = '"' . metaClean($c['name'] ?? $cid) . "\": campaign saved, but its ad sets / ads could not be read (" . $e->getMessage() . ')';
        }
        $name = metaClean($c['name'] ?? '');
        $setNames = [];
        $g = [];
        foreach ($adsets as $as) {
            $setNames[(string) ($as['id'] ?? '')] = metaClean($as['name'] ?? '');
            $g[] = ['id' => $as['id'] ?? '', 'campaign_id' => $cid, 'name' => $as['name'] ?? '', 'status' => $as['effective_status'] ?? ''];
        }
        $a = [];
        foreach ($ads as $ad) {
            $a[] = ['id' => $ad['id'] ?? '', 'adgroup_id' => $ad['adset_id'] ?? '', 'name' => $ad['name'] ?? '', 'status' => $ad['effective_status'] ?? ''];
            $adNames[metaClean($ad['id'] ?? '', 64)] = [$name, $setNames[(string) ($ad['adset_id'] ?? '')] ?? '', metaClean($ad['name'] ?? '')];
        }
        try {
            $w = masterUpsert($db, META_SYNC_PLATFORM, [['id' => $cid, 'name' => $name, 'status' => $c['effective_status'] ?? '']], $g, $a);
            foreach (['campaigns', 'adgroups', 'ads'] as $k) {
                $done[$k] += $w[$k];
            }
        } catch (Throwable $e) {
            $done['errors'][] = "Campaign {$cid}: could not save (" . $e->getMessage() . ')';
        }
        usleep(100000);
    }

    // Leads that came in with an ad_id but no campaign / ad set / ad name: fill the blanks
    // (only empty fields are touched), so the dashboard can count them under their campaign.
    if ($adNames) {
        foreach (leadDbs('all') as $leadDb) {
            $st = $leadDb->prepare("UPDATE `lead`
                SET campaign_name = CASE WHEN campaign_name IS NULL OR TRIM(campaign_name) = '' THEN ? ELSE campaign_name END,
                    adset_name    = CASE WHEN adset_name    IS NULL OR TRIM(adset_name)    = '' THEN ? ELSE adset_name END,
                    ad_name       = CASE WHEN ad_name       IS NULL OR TRIM(ad_name)       = '' THEN ? ELSE ad_name END
                WHERE TRIM(ad_id) = ? AND (campaign_name IS NULL OR TRIM(campaign_name) = '')");
            if (!$st) {
                continue;
            }
            foreach ($adNames as $adId => [$cn, $sn, $an]) {
                $adId = (string) $adId;
                $st->bind_param('ssss', $cn, $sn, $an, $adId);
                if ($st->execute()) {
                    $done['leads_filled'] += max(0, (int) $st->affected_rows);
                }
            }
            $st->close();
        }
    }
    return $done;
}

/** Remove Meta campaigns (and their ad sets / ads) from this project. Returns campaigns removed. */
function metaRemoveCampaigns(mysqli $db, array $campaignIds): int
{
    return masterRemoveCampaigns($db, META_SYNC_PLATFORM, $campaignIds);
}
