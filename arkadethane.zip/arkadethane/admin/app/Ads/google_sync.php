<?php
/**
 * app/Ads/google_sync.php — Google Ads side of "Sync with Google" (see app/Ads/master_tables.php).
 *
 * Lists the account's campaigns, suggests the ones that brought leads to this project
 * (lead.utm_campaignid / utm_campaignname), and saves chosen campaigns with their ad groups and ads
 * into campaigns / adgroups / ads (platform = 'google').
 */

require_once __DIR__ . '/master_tables.php';

const GOOGLE_SYNC_PLATFORM = 'google';

function googleAdsConfigured(): bool
{
    foreach (['GOOGLE_CLIENT_ID', 'GOOGLE_CLIENT_SECRET', 'GOOGLE_REFRESH_TOKEN', 'GOOGLE_DEVELOPER_TOKEN', 'GOOGLE_CUSTOMER_ID'] as $c) {
        if (!defined($c) || trim((string) constant($c)) === '') {
            return false;
        }
    }
    return true;
}

function googleAdsBase(): string
{
    return 'https://googleads.googleapis.com/v24/customers/' . preg_replace('/\D+/', '', (string) GOOGLE_CUSTOMER_ID);
}

/** OAuth access token (cached for the request). Throws on failure. */
function googleAccessToken(): string
{
    static $token = null;
    if ($token !== null) {
        return $token;
    }
    $ch = curl_init('https://oauth2.googleapis.com/token');
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_TIMEOUT        => 30,
        CURLOPT_POSTFIELDS     => http_build_query([
            'client_id'     => GOOGLE_CLIENT_ID,
            'client_secret' => GOOGLE_CLIENT_SECRET,
            'refresh_token' => GOOGLE_REFRESH_TOKEN,
            'grant_type'    => 'refresh_token',
        ]),
        CURLOPT_HTTPHEADER     => ['Content-Type: application/x-www-form-urlencoded'],
    ]);
    $json = json_decode((string) curl_exec($ch), true);
    unset($ch);
    if (empty($json['access_token'])) {
        throw new RuntimeException('Google: could not get an access token (' . ($json['error_description'] ?? $json['error'] ?? 'no response') . ').');
    }
    return $token = (string) $json['access_token'];
}

/** Run a GAQL query (searchStream) and return all result rows. Throws on error. */
function googleSearch(string $gaql): array
{
    $ch = curl_init(googleAdsBase() . '/googleAds:searchStream');
    $headers = [
        'Authorization: Bearer ' . googleAccessToken(),
        'developer-token: ' . GOOGLE_DEVELOPER_TOKEN,
        'Content-Type: application/json',
    ];
    if (defined('GOOGLE_LOGIN_CUSTOMER_ID') && trim((string) GOOGLE_LOGIN_CUSTOMER_ID) !== '') {
        $headers[] = 'login-customer-id: ' . preg_replace('/\D+/', '', (string) GOOGLE_LOGIN_CUSTOMER_ID);
    }
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_TIMEOUT        => 90,
        CURLOPT_POSTFIELDS     => json_encode(['query' => $gaql]),
        CURLOPT_HTTPHEADER     => $headers,
    ]);
    $body = curl_exec($ch);
    $err = curl_error($ch);
    unset($ch);
    if ($body === false) {
        throw new RuntimeException('Google: network error (' . $err . ').');
    }
    $json = json_decode((string) $body, true);
    if (!is_array($json)) {
        throw new RuntimeException('Google: invalid response.');
    }
    if (isset($json['error']) || isset($json[0]['error'])) {
        $e = $json['error'] ?? $json[0]['error'];
        throw new RuntimeException('Google: ' . ($e['message'] ?? 'API error'));
    }
    $rows = [];
    foreach ($json as $chunk) {
        foreach (($chunk['results'] ?? []) as $r) {
            $rows[] = $r;
        }
    }
    return $rows;
}

/** Every (non-removed) campaign in the account, with cost for the period. */
function googleListAccountCampaigns(string $since, string $until): array
{
    $out = [];
    try {
        $rows = googleSearch("SELECT campaign.id, campaign.name, campaign.status, campaign.advertising_channel_type, campaign.bidding_strategy_type FROM campaign WHERE campaign.status != 'REMOVED'");
    } catch (RuntimeException $e) {
        // older API version without one of the extra fields: names and statuses are enough
        $rows = googleSearch("SELECT campaign.id, campaign.name, campaign.status FROM campaign WHERE campaign.status != 'REMOVED'");
    }
    foreach ($rows as $r) {
        $id = (string) ($r['campaign']['id'] ?? '');
        if ($id === '') continue;
        $out[$id] = ['id' => $id, 'name' => masterClean($r['campaign']['name'] ?? ''), 'status' => (string) ($r['campaign']['status'] ?? ''), 'spend' => 0.0,
                     'channel' => (string) ($r['campaign']['advertisingChannelType'] ?? ''), 'bidding' => (string) ($r['campaign']['biddingStrategyType'] ?? '')];
    }
    $since = preg_replace('/[^0-9-]/', '', $since);
    $until = preg_replace('/[^0-9-]/', '', $until);
    foreach (googleSearch("SELECT campaign.id, metrics.cost_micros FROM campaign WHERE segments.date BETWEEN '{$since}' AND '{$until}'") as $r) {
        $id = (string) ($r['campaign']['id'] ?? '');
        if (isset($out[$id])) {
            $out[$id]['spend'] += ((float) ($r['metrics']['costMicros'] ?? 0)) / 1000000;
        }
    }
    return array_values($out);
}

/** Leads per Google campaign ID and per campaign name in this project's lead table(s). */
function googleLeadCounts(): array
{
    return [
        'by_id'   => masterLeadCounts('TRIM(utm_campaignid)'),
        'by_name' => masterLeadCounts('TRIM(utm_campaignname)'),
    ];
}

/**
 * Save Google campaigns (by ID) into the project with their ad groups and ads,
 * and fill blank utm_campaignname on leads that only have utm_campaignid.
 */
function googleSyncCampaignStructure(mysqli $db, array $campaignIds): array
{
    $ids = array_values(array_filter(array_unique(array_map(fn($v) => preg_replace('/\D+/', '', (string) $v), $campaignIds)), fn($v) => $v !== ''));
    $done = ['campaigns' => 0, 'adgroups' => 0, 'ads' => 0, 'leads_filled' => 0, 'errors' => [], 'failed' => []];
    if (!$ids) {
        return $done;
    }
    foreach (array_chunk($ids, 50) as $chunk) {
        $in = implode(',', $chunk);
        try {
            $camps = [];
            foreach (googleSearch("SELECT campaign.id, campaign.name, campaign.status FROM campaign WHERE campaign.id IN ({$in})") as $r) {
                $camps[] = ['id' => (string) $r['campaign']['id'], 'name' => $r['campaign']['name'] ?? '', 'status' => $r['campaign']['status'] ?? ''];
            }
            $groups = [];
            foreach (googleSearch("SELECT ad_group.id, ad_group.name, ad_group.status, campaign.id FROM ad_group WHERE campaign.id IN ({$in}) AND ad_group.status != 'REMOVED'") as $r) {
                $groups[] = ['id' => (string) $r['adGroup']['id'], 'campaign_id' => (string) $r['campaign']['id'], 'name' => $r['adGroup']['name'] ?? '', 'status' => $r['adGroup']['status'] ?? ''];
            }
            $ads = [];
            foreach (googleSearch("SELECT ad_group_ad.ad.id, ad_group_ad.ad.name, ad_group_ad.status, ad_group.id FROM ad_group_ad WHERE campaign.id IN ({$in}) AND ad_group_ad.status != 'REMOVED'") as $r) {
                $adId = (string) ($r['adGroupAd']['ad']['id'] ?? '');
                $name = trim((string) ($r['adGroupAd']['ad']['name'] ?? ''));
                $ads[] = ['id' => $adId, 'adgroup_id' => (string) ($r['adGroup']['id'] ?? ''), 'name' => $name !== '' ? $name : 'Ad #' . $adId, 'status' => $r['adGroupAd']['status'] ?? ''];
            }
            $w = masterUpsert($db, GOOGLE_SYNC_PLATFORM, $camps, $groups, $ads);
            foreach (['campaigns', 'adgroups', 'ads'] as $k) {
                $done[$k] += $w[$k];
            }
            $missing = array_diff($chunk, array_column($camps, 'id'));
            foreach ($missing as $m) {
                $done['errors'][] = "Campaign {$m}: not found in the Google Ads account";
                $done['failed'][] = (string) $m;
            }
            // leads with a campaign ID but no campaign name → fill the name (blank fields only)
            foreach (leadDbs('all') as $leadDb) {
                $st = $leadDb->prepare("UPDATE `lead` SET utm_campaignname = ? WHERE TRIM(utm_campaignid) = ? AND (utm_campaignname IS NULL OR TRIM(utm_campaignname) = '')");
                if (!$st) continue;
                foreach ($camps as $c) {
                    $n = masterClean($c['name']);
                    $cid = $c['id'];
                    $st->bind_param('ss', $n, $cid);
                    if ($st->execute()) {
                        $done['leads_filled'] += max(0, (int) $st->affected_rows);
                    }
                }
                $st->close();
            }
        } catch (Throwable $e) {
            $done['errors'][] = $e->getMessage();
        }
    }
    return $done;
}
