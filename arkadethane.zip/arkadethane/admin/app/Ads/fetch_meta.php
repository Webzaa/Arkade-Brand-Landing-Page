<?php
require_once dirname(__DIR__, 2) . '/app/Core/db.php';
require_once __DIR__ . '/meta_sync.php';   // project campaign list (campaigns table)
require_once __DIR__ . '/platform_metrics.php';   // extra Meta metrics for the ▥ Columns panel (optional request)

/*
| CRM DATABASES — every database in LEAD_DATABASES (config/config.php)
*/
function getFetchMetaCrmDatabases(): array
{
    return leadDbs('all');
}


// Rewritten for dashboard compatibility: CRM leads are authoritative; Meta supplies ad metrics.
// The confirmed `lead` schema has no sitevisit_status column, so site visits are returned as 0.


// ============================================================
// HELPERS — top level (never nested inside functions)
// ============================================================

/**
 * Extract lead count.
 * 'lead' is the aggregate — use it alone to avoid double-counting.
 * Fall back to sub-types only if 'lead' row is absent.
 */
function extractLeads(array $actions): int
{  /// This Function Is Used To Extract Lead Count.
    if (empty($actions))
        return 0;

    // Pass 1 — aggregate parent wins
    foreach ($actions as $action) {
        if (($action['action_type'] ?? '') === 'lead') {
            return (int) $action['value'];
        }
    }

    // Pass 2 — sub-types only (some campaign types never emit 'lead')
    $fallback = [
        'onsite_conversion.lead_grouped',
        'onsite_conversion.messaging_first_reply',
    ];
    $total = 0;
    foreach ($actions as $action) {
        $type = $action['action_type'] ?? '';
        if (in_array($type, $fallback, true) || strpos($type, 'offsite_conversion.custom.') === 0) {
            $total += (int) $action['value'];
        }
    }
    return $total;
}

/**
 * Extract CPL from Meta's cost_per_action_type.
 * Meta calculates this server-side with deduplication — more accurate than spend/leads.
 */
function extractCPL(array $costPerAction): float
{   /// This Function Is Used To Extract CPL.
    if (empty($costPerAction))
        return 0.0;

    foreach (['lead', 'onsite_conversion.lead_grouped'] as $type) {
        foreach ($costPerAction as $item) {
            if (($item['action_type'] ?? '') === $type) {
                return round((float) $item['value'], 2);
            }
        }
    }
    return 0.0;
}

/**
 * Count leads from the `lead` table whose campaignsource is one of Meta's
 * canonical values ('fb', 'ig', 'Facebook Lead Form') within a date range.
 * This is the single source of truth for "Leads" on the Meta dashboard
 * (previously this came from Meta's own reported conversions via extractLeads()).
 *
 * - $groupCol === null                => returns a single total (int)
 * - $groupCol 'campaign_name' | 'adset_name' | 'ad_name'
 *                                      => assoc array [lowercased/trimmed name => count]
 * - $groupCol 'DATE(createddate)'     => assoc array ['Y-m-d' => count]
 *
 * $extraFilters: ['column' => 'value'] exact-match (case-insensitive) filters,
 * e.g. ['campaign_name' => 'Summer Sale'] to scope an adset/ad-level query.
 */
function getMetaDbLeadsCount($conn, string $dbStart, string $dbEnd, ?string $groupCol = null, array $extraFilters = [])
{
    $empty = $groupCol === null ? 0 : [];
    if (!isset($conn) || $conn->connect_error) {
        return $empty;
    }

    $where = "createddate >= ? AND createddate <= ?
              AND " . PQ_META_LEAD_SQL . "
              AND (lead_status IS NULL OR UPPER(TRIM(lead_status)) NOT IN ('TEST', 'JUNK'))
              AND (name IS NULL OR LOWER(TRIM(name)) NOT LIKE '%test%')
              AND (email IS NULL OR LOWER(TRIM(email)) NOT LIKE '%test%')
              AND (mobile IS NULL OR (
                  LOWER(TRIM(mobile)) NOT LIKE '%test%'
                  AND TRIM(mobile) NOT IN ('9999999999', '8888888888', '0000000000', '1234567890', '1111111111')
              ))";
    $types = 'ss';
    $params = [$dbStart, $dbEnd];

    foreach ($extraFilters as $col => $val) {
        $where .= " AND LOWER(TRIM({$col})) = LOWER(TRIM(?))";
        $types .= 's';
        $params[] = $val;
    }

    if ($groupCol === null) {
        $sql = "SELECT COUNT(*) as cnt FROM `lead` WHERE {$where}";
        $stmt = $conn->prepare($sql);
        if (!$stmt)
            return 0;
        $stmt->bind_param($types, ...$params);
        $stmt->execute();
        $res = $stmt->get_result();
        $row = $res ? $res->fetch_assoc() : null;
        $stmt->close();
        return $row ? (int) $row['cnt'] : 0;
    }

    $isDateGroup = (strtoupper($groupCol) === 'DATE(CREATEDDATE)');
    if (!$isDateGroup) {
        $where .= " AND {$groupCol} IS NOT NULL AND {$groupCol} <> ''";
    }
    $selectExpr = $isDateGroup ? 'DATE(createddate)' : $groupCol;

    $sql = "SELECT {$selectExpr} as grp, COUNT(*) as cnt FROM `lead` WHERE {$where} GROUP BY {$selectExpr}";
    $stmt = $conn->prepare($sql);
    if (!$stmt)
        return [];
    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $res = $stmt->get_result();
    $out = [];
    if ($res) {
        while ($row = $res->fetch_assoc()) {
            $key = $isDateGroup ? $row['grp'] : strtolower(trim($row['grp']));
            $out[$key] = (int) $row['cnt'];
        }
    }
    $stmt->close();
    return $out;
}

/**
 * Aggregate CRM Meta lead counts across all configured CRM databases.
 */
function getCombinedMetaDbLeadsCount(
    array $databases,
    string $dbStart,
    string $dbEnd,
    ?string $groupCol = null,
    array $extraFilters = []
) {
    $combined = $groupCol === null ? 0 : [];

    foreach ($databases as $db) {
        if (!($db instanceof mysqli) || $db->connect_errno) {
            continue;
        }

        $value = getMetaDbLeadsCount(
            $db,
            $dbStart,
            $dbEnd,
            $groupCol,
            $extraFilters
        );

        if ($groupCol === null) {
            $combined += (int) $value;
            continue;
        }

        foreach ($value as $key => $count) {
            if (!isset($combined[$key])) {
                $combined[$key] = 0;
            }
            $combined[$key] += (int) $count;
        }
    }

    return $combined;
}

/**
 * Paginate through all Meta API pages and return every record.
 * Without this, &limit=10 silently drops campaigns beyond #10.
 */
/**
 * Meta keeps ad results for 37 months and counts them in the ad account's time zone, so a start date right on the
 * edge (as "All time" sends) is refused with error #3018. Start dates older than that are moved forward, with a
 * two-day margin; CRM leads still use the dates as chosen.
 */
function metaSafeSince(string $since): string
{
    $limit = date('Y-m-d', strtotime('-37 months +2 days'));
    return (preg_match('/^\d{4}-\d{2}-\d{2}$/', $since) && $since < $limit) ? $limit : $since;
}

/**
 * Splits since..until into windows of at most $days days (Meta's daily breakdowns over years are too big for one
 * request and time out or answer "Please reduce the amount of data").
 */
function metaDateChunks(string $since, string $until, int $days = 90): array
{
    $out = [];
    $s = new DateTime($since);
    $u = new DateTime($until);
    while ($s <= $u) {
        $e = (clone $s)->modify('+' . ($days - 1) . ' days');
        if ($e > $u) $e = clone $u;
        $out[] = [$s->format('Y-m-d'), $e->format('Y-m-d')];
        $s = (clone $e)->modify('+1 day');
    }
    return $out;
}

function fetchAllPages(string $firstUrl): array
{
    $allData = [];
    $nextUrl = $firstUrl;
    $seenUrls = []; // guards against Meta returning a 'next' cursor that loops back to a page already fetched

    while ($nextUrl) {
        if (isset($seenUrls[$nextUrl])) {
            break; // would re-fetch (and duplicate) a page we already have
        }
        $seenUrls[$nextUrl] = true;

        $result = apiGet($nextUrl);

        if (isset($result['error'])) {
            return ['data' => $allData, 'error' => $result['error']];
        }

        $allData = array_merge($allData, $result['data'] ?? []);
        $nextUrl = $result['paging']['next'] ?? null;
    }

    return ['data' => $allData];
}

/**
 * Translate dashboard/Meta date preset into concrete start/end dates.
 */
function getDatesFromPreset(string $preset): array
{
    $today = new DateTime();
    $since = '';
    $until = $today->format('Y-m-d');

    switch ($preset) {
        case 'today':
            $since = $today->format('Y-m-d');
            break;
        case 'yesterday':
            $yesterday = new DateTime('yesterday');
            $since = $yesterday->format('Y-m-d');
            $until = $yesterday->format('Y-m-d');
            break;
        case 'last_3d':
            $since = (new DateTime('-3 days'))->format('Y-m-d');
            break;
        case 'last_7d':
            $since = (new DateTime('-7 days'))->format('Y-m-d');
            break;
        case 'last_14d':
            $since = (new DateTime('-14 days'))->format('Y-m-d');
            break;
        case 'last_30d':
            $since = (new DateTime('-30 days'))->format('Y-m-d');
            break;
        case 'last_90d':
            $since = (new DateTime('-90 days'))->format('Y-m-d');
            break;
        case 'this_month':
            $since = $today->format('Y-m-01');
            break;
        case 'last_month':
            $since = (new DateTime('first day of last month'))->format('Y-m-d');
            $until = (new DateTime('last day of last month'))->format('Y-m-d');
            break;
        case 'this_quarter':
            $month = (int) $today->format('n');
            $quarterStartMonth = 1 + 3 * floor(($month - 1) / 3);
            $since = $today->format("Y-") . str_pad((string) $quarterStartMonth, 2, '0', STR_PAD_LEFT) . "-01";
            break;
        case 'last_quarter':
            $month = (int) $today->format('n');
            $currentQuarterStartMonth = 1 + 3 * floor(($month - 1) / 3);
            $lastQuarterStart = new DateTime($today->format("Y-") . str_pad((string) $currentQuarterStartMonth, 2, '0', STR_PAD_LEFT) . "-01" . " -3 months");
            $since = $lastQuarterStart->format('Y-m-d');
            $until = (new DateTime($lastQuarterStart->format('Y-m-d') . " +3 months -1 day"))->format('Y-m-d');
            break;
        case 'this_year':
            $since = $today->format('Y-01-01');
            break;
        case 'last_year':
            $since = (new DateTime('-1 year'))->format('Y-01-01');
            $until = (new DateTime('-1 year'))->format('Y-12-31');
            break;
        default:
            $since = (new DateTime('-30 days'))->format('Y-m-d');
            break;
    }
    return [$since, $until];
}

// ============================================================
// MAIN FETCH
// ============================================================
// This Is Main Fetch Function. It Is Used To Fetch Data From Meta Ads.
function fetchMetaAdsData(string $preset = null, string $since = null, string $until = null): array
{
    $crmDatabases = getFetchMetaCrmDatabases();

    $preset = $preset ?? ($_GET['preset'] ?? (defined('DATE_PRESET') ? DATE_PRESET : 'last_30d'));
    $since = $since ?? ($_GET['since'] ?? null);
    $until = $until ?? ($_GET['until'] ?? null);

    if (empty($since) || empty($until)) {
        [$since, $until] = getDatesFromPreset($preset);
    }

    $dbStart = $since . ' 00:00:00';
    $dbEnd = $until . ' 23:59:59';

    // ------------------------------------------------------------
    // 1. CRM is the source of truth for leads.
    //    Aggregate Pseudo + Official databases.
    // ------------------------------------------------------------
    $crmCampaigns = [];
    $crmTrend = [];
    $crmTrendByName = [];
    $totalLeads = 0;
    $totalQualified = 0;
    $totalWalkins = 0;

    foreach ($crmDatabases as $dbName => $db) {
        $where = "createddate >= ? AND createddate <= ?
                  AND " . PQ_META_LEAD_SQL . "
                  AND (lead_status IS NULL OR UPPER(TRIM(lead_status)) NOT IN ('TEST', 'JUNK'))
                  AND (name IS NULL OR LOWER(TRIM(name)) NOT LIKE '%test%')
                  AND (email IS NULL OR LOWER(TRIM(email)) NOT LIKE '%test%')
                  AND (mobile IS NULL OR (
                      LOWER(TRIM(mobile)) NOT LIKE '%test%'
                      AND TRIM(mobile) NOT IN ('9999999999', '8888888888', '0000000000', '1234567890', '1111111111')
                  ))";

        $sql = "SELECT
                    COALESCE(NULLIF(TRIM(campaign_name), ''), 'Unknown Campaign') AS campaign_name,
                    COUNT(*) AS leads,
                    -- qualified / site visits: unique people (by mobile), leads: every entry
                    COUNT(DISTINCT CASE
                            WHEN TRIM(UPPER(COALESCE(lead_status,'')))
                                 IN ('QUALIFIED','LOST POST QUALIFIED','LOST POST QUALIFICATION')
                            THEN " . PQ_PERSON_KEY_SQL . " END
                    ) AS qualified,
                    COUNT(DISTINCT CASE
                            WHEN TRIM(UPPER(COALESCE(sitevisit_status,'')))
                                 IN ('VISIT DONE','VISITED','SITE VISIT DONE','SITE VISIT','WALKIN','WALK-IN','DONE','YES','CONDUCTED')
                                 OR TRIM(UPPER(COALESCE(lead_status,'')))
                                 IN ('VISIT DONE','VISITED','SITE VISIT DONE','SITE VISIT','WALKIN','WALK-IN','DONE','YES','CONDUCTED')
                            THEN " . PQ_PERSON_KEY_SQL . " END
                    ) AS walkins
                FROM `lead`
                WHERE {$where}
                GROUP BY campaign_name";

        $stmt = $db->prepare($sql);
        if ($stmt) {
            $stmt->bind_param('ss', $dbStart, $dbEnd);
            $stmt->execute();
            $res = $stmt->get_result();

            while ($row = $res->fetch_assoc()) {
                $name = trim((string) $row['campaign_name']);
                $key = strtolower($name);
                $leads = (int) $row['leads'];
                $qualified = (int) $row['qualified'];
                $walkins = (int) ($row['walkins'] ?? 0);

                if (!isset($crmCampaigns[$key])) {
                    $crmCampaigns[$key] = [
                        'name' => $name,
                        'leads' => 0,
                        'qualified' => 0,
                        'walkins' => 0
                    ];
                }

                $crmCampaigns[$key]['leads'] += $leads;
                $crmCampaigns[$key]['qualified'] += $qualified;
                $crmCampaigns[$key]['walkins'] += $walkins;
                $totalLeads += $leads;
                $totalQualified += $qualified;
                $totalWalkins += $walkins;
            }

            $stmt->close();
        }

        $trendSql = "SELECT
                        DATE(createddate) AS dt,
                        campaign_name,
                        COUNT(*) AS leads,
                        SUM(
                            CASE
                                WHEN TRIM(UPPER(COALESCE(lead_status,'')))
                                     IN ('QUALIFIED','LOST POST QUALIFIED')
                                THEN 1 ELSE 0
                            END
                        ) AS qualified,
                        SUM(
                            CASE
                                WHEN TRIM(UPPER(COALESCE(sitevisit_status,'')))
                                     IN ('VISIT DONE','VISITED','SITE VISIT DONE','SITE VISIT','WALKIN','WALK-IN','DONE','YES','CONDUCTED')
                                     OR TRIM(UPPER(COALESCE(lead_status,'')))
                                     IN ('VISIT DONE','VISITED','SITE VISIT DONE','SITE VISIT','WALKIN','WALK-IN','DONE','YES','CONDUCTED')
                                THEN 1 ELSE 0
                            END
                        ) AS walkins
                     FROM `lead`
                     WHERE {$where}
                     GROUP BY DATE(createddate), campaign_name
                     ORDER BY dt";

        $stmt = $db->prepare($trendSql);
        if ($stmt) {
            $stmt->bind_param('ss', $dbStart, $dbEnd);
            $stmt->execute();
            $res = $stmt->get_result();

            while ($row = $res->fetch_assoc()) {
                $crmTrendByName[] = $row;   // filtered to this project's campaigns in step 6
            }

            $stmt->close();
        }
    }

    // ------------------------------------------------------------
    // 2. Resolve Meta accounts.
    // ------------------------------------------------------------
    $accountIds = [];
    if (defined('META_AD_ACCOUNT_IDS')) {
        $raw = META_AD_ACCOUNT_IDS;
        if (is_array($raw)) {
            $accountIds = $raw;
        } else {
            $decoded = json_decode((string) $raw, true);
            $accountIds = is_array($decoded) ? $decoded : [(string) $raw];
        }
    } elseif (defined('META_AD_ACCOUNT_ID')) {
        $accountIds = [META_AD_ACCOUNT_ID];
    }

    $accountIds = array_values(array_unique(array_filter(array_map(function ($id) {
        return preg_replace('/^act_/i', '', trim((string) $id));
    }, $accountIds), fn($id) => $id !== '')));

    $token = defined('META_ACCESS_TOKEN') ? META_ACCESS_TOKEN : '';
    $version = defined('META_API_VERSION') ? META_API_VERSION : 'v23.0';

    $apiErrors = [];
    $campaignStatusMap = [];
    $metaCampaignRows = [];
    $metaTrendRows = [];
    $metaSummary = [
        'spend' => 0.0,
        'impressions' => 0,
        'clicks' => 0,
        'reach' => 0
    ];

    // ------------------------------------------------------------
    // 3. Fetch Meta campaign list + status.
    //    Failure here MUST NOT prevent CRM data from being returned.
    // ------------------------------------------------------------
    $accountCampaignIds = [];
    foreach ($accountIds as $accId) {
        $accountCampaignIds[$accId] = [];
        $url = "https://graph.facebook.com/{$version}/act_{$accId}/campaigns"
            . "?fields=id,name,status,effective_status&limit=250&access_token=" . urlencode($token);
        $result = apiGet($url);
        if (isset($result['error'])) {
            $apiErrors[] = [
                'stage' => 'campaign_list',
                'account_id' => $accId,
                'error' => $result['error']
            ];
            continue;
        }

        $pages = fetchAllPages($url);
        if (isset($pages['error'])) {
            $apiErrors[] = [
                'stage' => 'campaign_list',
                'account_id' => $accId,
                'error' => $pages['error']
            ];
            continue;
        }

        foreach (($pages['data'] ?? []) as $campaign) {
            $id = (string) ($campaign['id'] ?? '');
            $name = trim((string) ($campaign['name'] ?? ''));
            if ($id === '')
                continue;
            $campaignStatusMap[$id] = [
                'status' => $campaign['status'] ?? 'UNKNOWN',
                'effective_status' => $campaign['effective_status'] ?? 'UNKNOWN',
                'name' => $name
            ];
            /*
             * IMPORTANT:
             * Do not restrict Meta campaigns to CRM campaign names.
             * Meta spend/clicks must be fetched independently, then CRM leads
             * are merged afterward. Otherwise a campaign that has spend but no
             * exact CRM name match disappears from the dashboard.
             */
            $accountCampaignIds[$accId][] = $id;
        }
    }

    // ------------------------------------------------------------
    // 4. Fetch Meta campaign insights and summary.
    // ------------------------------------------------------------
    $metaSince = metaSafeSince($since);
    $metaUntil = max($until, $metaSince);
    $dateParam = '&time_range=' . urlencode(json_encode(['since' => $metaSince, 'until' => $metaUntil]));
    $metaWarnings = [];
    $attrWindow = '&action_attribution_windows=' . urlencode('["7d_click"]');

    foreach ($accountIds as $accId) {
        $ids = array_values(array_unique($accountCampaignIds[$accId] ?? []));

        /*
         * Fetch ALL campaign insights for this account.
         * Do not filter by CRM campaign names.
         */
        $summaryUrl = "https://graph.facebook.com/{$version}/act_{$accId}/insights"
            . "?fields=spend,impressions,clicks,reach"
            . "&level=account{$dateParam}{$attrWindow}"
            . "&limit=250&access_token=" . urlencode($token);

        $summaryResult = fetchAllPages($summaryUrl);
        if (isset($summaryResult['error'])) {
            $apiErrors[] = [
                'stage' => 'summary',
                'account_id' => $accId,
                'error' => $summaryResult['error']
            ];
        } else {
            foreach (($summaryResult['data'] ?? []) as $row) {
                $metaSummary['spend'] += (float) ($row['spend'] ?? 0);
                $metaSummary['impressions'] += (int) ($row['impressions'] ?? 0);
                $metaSummary['clicks'] += (int) ($row['clicks'] ?? 0);
                $metaSummary['reach'] += (int) ($row['reach'] ?? 0);
            }
        }

        $campaignUrl = "https://graph.facebook.com/{$version}/act_{$accId}/insights"
            . "?fields=campaign_id,campaign_name,spend,impressions,clicks,ctr,cpm,reach,frequency"
            . "&level=campaign{$dateParam}{$attrWindow}"
            . "&limit=250&access_token=" . urlencode($token);

        $campaignResult = fetchAllPages($campaignUrl);

        if (isset($campaignResult['error'])) {
            $apiErrors[] = [
                'stage' => 'campaign_insights',
                'account_id' => $accId,
                'error' => $campaignResult['error']
            ];
        } else {
            $metaCampaignRows = array_merge(
                $metaCampaignRows,
                $campaignResult['data'] ?? []
            );
            // extra metrics (video plays, link clicks, landing page views …) — separate, optional request
            foreach (pmMetaFetch($version, (string) $accId, $token, 'campaign', $dateParam . $attrWindow) as $pmId => $pmVals) {
                $pmCampaign[$pmId] = pmMerge($pmCampaign[$pmId] ?? [], $pmVals, 'meta');
            }
        }

        /*
         * Daily Meta trend, per campaign (time_increment=1 → one row per campaign per day),
         * so only this project's campaigns are added up below.
         */
        // daily rows in windows (one request for up to 92 days, then 180-day windows; a window Meta finds too big is
        // split in half), so "Last 1 year" / "All time" work; a failed window only leaves a gap in the daily
        // chart — spend and the campaign table above are unaffected
        $trendFail = [];
        $trendUrlFor = fn(string $cs, string $cu) => "https://graph.facebook.com/{$version}/act_{$accId}/insights"
            . "?fields=campaign_id,campaign_name,date_start,spend,impressions,clicks"
            . "&level=campaign&time_increment=1"
            . '&time_range=' . urlencode(json_encode(['since' => $cs, 'until' => $cu])) . $attrWindow
            . "&limit=500&access_token=" . urlencode($token);
        $days = (int) (new DateTime($metaSince))->diff(new DateTime($metaUntil))->days + 1;
        $queue = metaDateChunks($metaSince, $metaUntil, $days <= 92 ? 92 : 180);
        while ($queue) {
            [$cs, $cu] = array_shift($queue);
            $trendResult = fetchAllPages($trendUrlFor($cs, $cu));
            if (!isset($trendResult['error'])) {
                $metaTrendRows = array_merge($metaTrendRows, $trendResult['data'] ?? []);
                continue;
            }
            $err = $trendResult['error'];
            $msg = is_array($err) ? (string) ($err['message'] ?? 'Meta error') : (string) $err;
            $len = (int) (new DateTime($cs))->diff(new DateTime($cu))->days + 1;
            $tooBig = (is_array($err) && in_array((int) ($err['code'] ?? 0), [1, 2], true)) || stripos($msg, 'reduce the amount') !== false
                || stripos($msg, 'timed out') !== false;
            if ($tooBig && $len > 14) {                      // split and retry: rows from the failed attempt are dropped
                $half = intdiv($len, 2);
                $mid = (new DateTime($cs))->modify('+' . ($half - 1) . ' days')->format('Y-m-d');
                array_unshift($queue, [$cs, $mid], [(new DateTime($mid))->modify('+1 day')->format('Y-m-d'), $cu]);
                continue;
            }
            $trendFail[] = [$cs, $cu, $msg];
            if (stripos($msg, 'Connection error') === 0) {    // Meta unreachable: do not try the other windows
                break;
            }
        }
        if ($trendFail) {
            $metaWarnings[] = [
                'stage' => 'trend',
                'account_id' => $accId,
                'message' => 'Daily chart incomplete (' . count($trendFail) . ' period' . (count($trendFail) === 1 ? '' : 's')
                    . ', first ' . $trendFail[0][0] . ' – ' . $trendFail[0][1] . '): ' . $trendFail[0][2],
            ];
        }
    }

    // ------------------------------------------------------------
    // 5. Merge Meta campaign rows + CRM campaign rows.
    //
    // Meta campaigns are authoritative for ad metrics.
    // CRM databases are authoritative for lead/qualified counts.
    //
    // Exact campaign-name matching is used only to attach CRM leads.
    // Meta-only campaigns are NEVER discarded.
    // ------------------------------------------------------------
    $campaigns = [];
    $claimedCrm = [];

    // daily / lifetime budget per campaign (▥ Columns → "Daily budget"); never blocks the dashboard
    $budgetPm = [];
    try {
        require_once __DIR__ . '/creatives.php';
        $budgetPm = crBudgetPm('meta', array_filter(array_map(
            fn($r) => isProjectCampaign('meta', (string) ($r['campaign_id'] ?? ''), (string) ($r['campaign_name'] ?? '')) ? (string) $r['campaign_id'] : '',
            $metaCampaignRows)));
    } catch (Throwable $e) {
        error_log('[fetch_meta] budgets: ' . $e->getMessage());
    }

    foreach ($metaCampaignRows as $row) {
        $name = trim((string) ($row['campaign_name'] ?? ''));
        if ($name === '') {
            $name = 'Unknown Campaign';
        }

        $key = strtolower($name);
        $crm = $crmCampaigns[$key] ?? [
            'name' => $name,
            'leads' => 0,
            'qualified' => 0,
            'walkins' => 0
        ];

        /*
         * If multiple Meta rows/accounts expose the same campaign name,
         * CRM leads should only be claimed once.
         */
        if (isset($claimedCrm[$key])) {
            $crmForRow = [
                'leads' => 0,
                'qualified' => 0,
                'walkins' => 0
            ];
        } else {
            $crmForRow = $crm;
            if (isset($crmCampaigns[$key])) {
                $claimedCrm[$key] = true;
            }
        }

        $spend = round((float) ($row['spend'] ?? 0), 2);
        $leads = (int) ($crmForRow['leads'] ?? 0);
        $qualified = (int) ($crmForRow['qualified'] ?? 0);
        $walkins = (int) ($crmForRow['walkins'] ?? 0);
        $id = (string) ($row['campaign_id'] ?? '');

        $status = $campaignStatusMap[$id] ?? [
            'status' => 'UNKNOWN',
            'effective_status' => 'UNKNOWN'
        ];

        $campaigns[] = [
            'id' => $id,
            'name' => $name,
            'spend' => $spend,
            'impressions' => (int) ($row['impressions'] ?? 0),
            'clicks' => (int) ($row['clicks'] ?? 0),
            'ctr' => round((float) ($row['ctr'] ?? 0), 2),
            'cpm' => round((float) ($row['cpm'] ?? 0), 2),
            'reach' => (int) ($row['reach'] ?? 0),
            'frequency' => round((float) ($row['frequency'] ?? 0), 2),
            'leads' => $leads,
            'cpl' => $leads > 0 ? round($spend / $leads, 2) : 0.0,
            'qualified' => $qualified,
            'walkins' => $walkins,
            'cpql' => $qualified > 0 ? round($spend / $qualified, 2) : 0.0,
            'cpsv' => $walkins > 0 ? round($spend / $walkins, 2) : 0.0,
            'status' => $status['status'],
            'effective_status' => $status['effective_status'],
            'pm' => array_merge($pmCampaign[$id] ?? [], $budgetPm[$id] ?? []),
            'daily_budget' => $budgetPm[$id]['pm_daily_budget'] ?? null,
            'lifetime_budget' => $budgetPm[$id]['pm_lifetime_budget'] ?? null,
            'data_source' => isset($crmCampaigns[$key])
                ? 'meta+crm'
                : 'meta_only'
        ];
    }

    /*
     * Add CRM-only campaigns.
     */
    foreach ($crmCampaigns as $key => $crm) {
        if (isset($claimedCrm[$key])) {
            continue;
        }

        $campaignId = '';
        foreach ($campaignStatusMap as $id => $status) {
            if (strtolower(trim((string) ($status['name'] ?? ''))) === $key) {
                $campaignId = $id;
                break;
            }
        }

        $status = $campaignId !== ''
            ? $campaignStatusMap[$campaignId]
            : ['status' => 'UNKNOWN', 'effective_status' => 'UNKNOWN'];

        $walkins = (int) ($crm['walkins'] ?? 0);
        $campaigns[] = [
            'id' => $campaignId,
            'name' => $crm['name'],
            'spend' => 0.0,
            'impressions' => 0,
            'clicks' => 0,
            'ctr' => 0.0,
            'cpm' => 0.0,
            'reach' => 0,
            'frequency' => 0.0,
            'leads' => (int) $crm['leads'],
            'cpl' => 0.0,
            'qualified' => (int) $crm['qualified'],
            'walkins' => $walkins,
            'cpql' => 0.0,
            'cpsv' => 0.0,
            'status' => $status['status'],
            'effective_status' => $status['effective_status'],
            'data_source' => 'crm_only'
        ];
    }

    // ------------------------------------------------------------
    // 5b. Only this project's campaigns (the `campaigns` table, see app/Ads/meta_sync.php).
    // ------------------------------------------------------------
    [$campaigns, $campaignFilter] = metaApplyProjectFilter($campaigns);

    // 5c. Meta leads not under one of this project's campaigns → one "Unmapped leads (no campaign)" row,
    //     so uploaded qualified leads / site visits still show (map them in Unmapped Leads to move them).
    if (!defined('DASHBOARD_COUNT_UNMAPPED') || DASHBOARD_COUNT_UNMAPPED) {
        $inProject = [];
        foreach ($campaigns as $c) {
            $inProject[strtolower(trim((string) $c['name']))] = true;
        }
        $um = ['leads' => 0, 'qualified' => 0, 'walkins' => 0];
        foreach ($crmCampaigns as $key => $crm) {
            if (!isset($inProject[$key]) && !metaIsProjectCampaign(null, (string) $crm['name'])) {
                $um['leads'] += (int) $crm['leads'];
                $um['qualified'] += (int) $crm['qualified'];
                $um['walkins'] += (int) $crm['walkins'];
            }
        }
        if ($um['leads'] > 0) {
            $campaigns[] = ['id' => '', 'name' => 'Unmapped leads (no campaign)', 'spend' => 0.0, 'impressions' => 0, 'clicks' => 0,
                'ctr' => 0.0, 'cpm' => 0.0, 'reach' => 0, 'frequency' => 0.0, 'leads' => $um['leads'], 'cpl' => 0.0,
                'qualified' => $um['qualified'], 'walkins' => $um['walkins'], 'cpql' => 0.0, 'cpsv' => 0.0,
                'status' => 'UNMAPPED', 'effective_status' => 'UNMAPPED', 'data_source' => 'crm_unmapped'];
        }
    }

    // ------------------------------------------------------------
    // 6. Merge daily Meta spend with CRM daily leads.
    // ------------------------------------------------------------
    // Lead names → Meta campaign ID (so a campaign renamed in the `campaigns` table still matches its leads).
    $leadNameToId = [];
    foreach ($metaCampaignRows as $row) {
        $n = strtolower(trim((string) ($row['campaign_name'] ?? '')));
        if ($n !== '' && !empty($row['campaign_id'])) {
            $leadNameToId[$n] = (string) $row['campaign_id'];
        }
    }
    foreach ($crmTrendByName as $row) {
        $n = trim((string) ($row['campaign_name'] ?? ''));
        if (!metaIsProjectCampaign($leadNameToId[strtolower($n)] ?? null, $n)) {
            continue;   // leads of campaigns not in the `campaigns` table
        }
        $date = $row['dt'];
        if (!isset($crmTrend[$date])) {
            $crmTrend[$date] = ['date' => $date, 'leads' => 0, 'qualified' => 0, 'walkins' => 0, 'spend' => 0.0, 'impressions' => 0, 'clicks' => 0];
        }
        $crmTrend[$date]['leads'] += (int) $row['leads'];
        $crmTrend[$date]['qualified'] += (int) $row['qualified'];
        $crmTrend[$date]['walkins'] += (int) ($row['walkins'] ?? 0);
    }

    $trend = $crmTrend;
    $awarenessIds = projectStructure('meta')['awareness'] ?? [];
    $awarenessTrend = [];   // daily spend of awareness campaigns (public/ads/api.php: the Performance / Awareness tabs' daily chart)
    foreach ($metaTrendRows as $row) {
        $date = $row['date_start'] ?? '';
        if ($date === '')
            continue;
        if (!metaIsProjectCampaign((string) ($row['campaign_id'] ?? ''), (string) ($row['campaign_name'] ?? ''))) {
            continue;
        }
        $awCid = projectCampaignId('meta', (string) ($row['campaign_id'] ?? ''), (string) ($row['campaign_name'] ?? ''));
        if ($awCid !== null && isset($awarenessIds[$awCid])) {
            $awarenessTrend[$date] = $awarenessTrend[$date] ?? ['spend' => 0.0, 'impressions' => 0, 'clicks' => 0];
            $awarenessTrend[$date]['spend'] += round((float) ($row['spend'] ?? 0), 2);
            $awarenessTrend[$date]['impressions'] += (int) ($row['impressions'] ?? 0);
            $awarenessTrend[$date]['clicks'] += (int) ($row['clicks'] ?? 0);
        }
        if (!isset($trend[$date])) {
            $trend[$date] = [
                'date' => $date,
                'spend' => 0.0,
                'impressions' => 0,
                'clicks' => 0,
                'leads' => 0,
                'qualified' => 0,
                'walkins' => 0
            ];
        }
        $trend[$date]['spend'] += round((float) ($row['spend'] ?? 0), 2);
        $trend[$date]['impressions'] += (int) ($row['impressions'] ?? 0);
        $trend[$date]['clicks'] += (int) ($row['clicks'] ?? 0);
    }
    ksort($trend);
    $trend = array_values($trend);

    // Totals = this project's campaigns only (the account-level summary includes other projects).
    $totalSpend = round(array_sum(array_map(fn($c) => (float) ($c['spend'] ?? 0), $campaigns)), 2);
    $totalImpressions = (int) array_sum(array_map(fn($c) => (int) ($c['impressions'] ?? 0), $campaigns));
    $totalClicks = (int) array_sum(array_map(fn($c) => (int) ($c['clicks'] ?? 0), $campaigns));
    $totalReach = (int) array_sum(array_map(fn($c) => (int) ($c['reach'] ?? 0), $campaigns));
    $totalLeads = (int) array_sum(array_map(fn($c) => (int) ($c['leads'] ?? 0), $campaigns));
    $totalQualified = (int) array_sum(array_map(fn($c) => (int) ($c['qualified'] ?? 0), $campaigns));
    $totalWalkins = (int) array_sum(array_map(fn($c) => (int) ($c['walkins'] ?? 0), $campaigns));

    return [
        'fetched_at' => date('d M Y, h:i A'),
        'date_preset' => !empty($_GET['since']) && !empty($_GET['until'])
            ? date('d/m/Y', strtotime($since)) . ' - ' . date('d/m/Y', strtotime($until))
            : $preset,
        'api_error' => empty($apiErrors) ? null : $apiErrors,
        'api_warning' => empty($metaWarnings) ? null : $metaWarnings,
        'meta_since' => $metaSince !== $since ? $metaSince : null,   // Meta results start here (37-month limit)
        'data_source' => [
            'leads' => 'mysql_lead_table_combined',
            'qualified' => 'mysql_lead_table_combined',
            'spend' => 'meta_insights',
            'impressions' => 'meta_insights',
            'clicks' => 'meta_insights',
            'site_visits' => 'mysql_lead_table_combined'
        ],
        'summary' => [
            'spend' => $totalSpend,
            'impressions' => $totalImpressions,
            'clicks' => $totalClicks,
            'ctr' => $totalImpressions > 0 ? round(($totalClicks / $totalImpressions) * 100, 2) : 0.0,
            'cpm' => $totalImpressions > 0 ? round(($totalSpend / $totalImpressions) * 1000, 2) : 0.0,
            'reach' => $totalReach,
            'frequency' => $totalReach > 0 ? round($totalImpressions / $totalReach, 2) : 0.0,
            'leads' => $totalLeads,
            'qualified' => $totalQualified,
            'walkins' => $totalWalkins,
            'cpl' => $totalLeads > 0 ? round($totalSpend / $totalLeads, 2) : 0.0,
            'cpsv' => $totalWalkins > 0 ? round($totalSpend / $totalWalkins, 2) : 0.0,
            'lead_rate' => $totalClicks > 0 ? round(($totalLeads / $totalClicks) * 100, 2) : 0.0
        ],
        'campaigns' => $campaigns,
        'campaign_filter' => $campaignFilter,
        'trend' => $trend,
        'awareness_trend' => $awarenessTrend
    ];
}
// ============================================================
// ADSET LEVEL FETCH
// ============================================================

/**
 * Fetch adset-level insights for a given campaign ID.
 *
 * @param string      $campaignId  Meta campaign ID to drill into.
 * @param string|null $preset      Date preset (e.g. 'last_30d'). Falls back to DATE_PRESET.
 * @param string|null $since       Custom range start (YYYY-MM-DD). Overrides $preset when both $since/$until supplied.
 * @param string|null $until       Custom range end   (YYYY-MM-DD).
 *
 * @return array {
 *   fetched_at: string,
 *   campaign_id: string,
 *   date_preset: string,
 *   api_error: array|null,
 *   adsets: array<{
 *     adset_id, adset_name, campaign_id, campaign_name,
 *     spend, impressions, clicks, ctr, cpm, reach, frequency,
 *     leads, cpl
 *   }>
 * }
 */
function fetchAdsetData(string $campaignId, string $preset = null, string $since = null, string $until = null, string $campaignName = ''): array
{
    $crmDatabases = getFetchMetaCrmDatabases();
    if (empty($preset) && (empty($since) || empty($until))) {
        $preset = defined('DATE_PRESET') ? DATE_PRESET : 'last_30d';
    }

    // Resolve account IDs (same logic as fetchMetaAdsData)
    $accountIds = [];
    if (defined('META_AD_ACCOUNT_IDS')) {
        $rawIds = META_AD_ACCOUNT_IDS;
        if (is_array($rawIds)) {
            $accountIds = $rawIds;
        } else {
            $decoded = json_decode($rawIds, true);
            $accountIds = is_array($decoded) ? $decoded : [$rawIds];
        }
    } elseif (defined('META_AD_ACCOUNT_ID')) {
        $accountIds = [META_AD_ACCOUNT_ID];
    }
    if (empty($accountIds)) {
        $accountIds = [''];
    }

    $token = META_ACCESS_TOKEN;
    $version = META_API_VERSION;

    // Build date parameter
    if (!empty($since) && !empty($until)) {
        $timeRange = json_encode(['since' => metaSafeSince($since), 'until' => max($until, metaSafeSince($since))]);
        $dateParam = "&time_range=" . urlencode($timeRange);
        $displayPreset = date('d/m/Y', strtotime($since)) . ' - ' . date('d/m/Y', strtotime($until));
    } else {
        $dateParam = "&date_preset={$preset}";
        $displayPreset = $preset;
    }

    // Cache key scoped to campaign + campaign name + date range
    $safeCampaignId = preg_replace('/[^0-9]/', '', $campaignId);
    $safeCampName = preg_replace('/[^a-zA-Z0-9\_]/', '', $campaignName);
    if (!empty($since) && !empty($until)) {
        $safeSince = preg_replace('/[^0-9\-]/', '', $since);
        $safeUntil = preg_replace('/[^0-9\-]/', '', $until);
        $cacheFile = CACHE_PATH . "/meta_adsets_{$safeCampaignId}_{$safeCampName}_{$safeSince}_{$safeUntil}.json";
    } else {
        $safePreset = preg_replace('/[^a-zA-Z0-9\_]/', '', $preset);
        $cacheFile = CACHE_PATH . "/meta_adsets_{$safeCampaignId}_{$safeCampName}_{$safePreset}.json";
    }

    // Return from cache if still fresh (uses same CACHE_SECONDS as full campaign cache)
    if (file_exists($cacheFile) && (time() - filemtime($cacheFile)) < CACHE_SECONDS) {
        $cached = json_decode(file_get_contents($cacheFile), true);
        if (isset($cached['adsets']) && !isset($cached['api_error'])) {
            return metaFilterAdsetResult($cached, $campaignId);
        }
    }

    $filtering = [['field' => 'campaign.id', 'operator' => 'EQUAL', 'value' => $campaignId]];
    $filteringParam = "&filtering=" . urlencode(json_encode($filtering));

    $fields = "adset_id,adset_name,campaign_id,campaign_name,"
        . "spend,impressions,reach,clicks,ctr,cpm,frequency,"
        . "actions,cost_per_action_type";

    // Fetch adset-level status (Active/Inactive) separately since status is not in insights.
    // FIX: also store 'name' in the map so inactive adsets can be injected with correct names.
    $adsetStatusMap = [];
    foreach ($accountIds as $accId) {
        if (empty($accId))
            continue;
        $adsetStatusUrl = "https://graph.facebook.com/{$version}/act_{$accId}/adsets"
            . "?fields=id,name,status,effective_status"
            . "&filtering=" . urlencode(json_encode([['field' => 'campaign.id', 'operator' => 'EQUAL', 'value' => $campaignId]]))
            . "&limit=200"
            . "&access_token={$token}";
        $adsetStatusResult = fetchAllPages($adsetStatusUrl);
        if (isset($adsetStatusResult['data']) && is_array($adsetStatusResult['data'])) {
            foreach ($adsetStatusResult['data'] as $as) {
                $adsetStatusMap[$as['id'] ?? ''] = [
                    'name' => $as['name'] ?? '',   // FIX: store name
                    'status' => $as['status'] ?? 'UNKNOWN',
                    'effective_status' => $as['effective_status'] ?? 'UNKNOWN',
                ];
            }
        }
    }

    $allAdsetsRaw = [];
    $apiError = null;

    foreach ($accountIds as $accId) {
        if (empty($accId))
            continue;

        $url = "https://graph.facebook.com/{$version}/act_{$accId}/insights"
            . "?fields={$fields}"
            . "&level=adset"
            . $dateParam
            . $filteringParam
            . "&limit=100"
            . "&access_token={$token}";

        $result = fetchAllPages($url);

        if (isset($result['error'])) {
            $apiError = $result['error'];
            break;
        }
        foreach (pmMetaFetch($version, (string) $accId, $token, 'adset', $dateParam . $filteringParam) as $pmId => $pmVals) {
            $pmAdset[$pmId] = pmMerge($pmAdset[$pmId] ?? [], $pmVals, 'meta');
        }

        $allAdsetsRaw = array_merge($allAdsetsRaw, $result['data'] ?? []);
    }

    // Map raw API rows to a clean structure
    $adsets = [];
    if (!$apiError) {
        global $conn;
        $crmCounts = [];
        if (!empty($crmDatabases)) {
            if (!empty($since) && !empty($until)) {
                $dbStartDate = $since . ' 00:00:00';
                $dbEndDate = $until . ' 23:59:59';
            } else {
                list($s, $u) = getDatesFromPreset($preset);
                $dbStartDate = $s . ' 00:00:00';
                $dbEndDate = $u . ' 23:59:59';
            }

            // Resolve parent campaign name if not passed in
            if (empty($campaignName)) {
                $stmtName = $conn->prepare("SELECT campaign_name FROM `campaigns_master` WHERE campaign_id = ? LIMIT 1");
                if ($stmtName) {
                    $stmtName->bind_param('s', $campaignId);
                    $stmtName->execute();
                    $stmtName->bind_result($name);
                    if ($stmtName->fetch()) {
                        $campaignName = $name;
                    }
                    $stmtName->close();
                }
            }
            if (empty($campaignName) && !empty($allAdsetsRaw)) {
                $campaignName = $allAdsetsRaw[0]['campaign_name'] ?? '';
            }
            if (empty($campaignName)) {
                $campaignNameUrl = "https://graph.facebook.com/{$version}/{$campaignId}?fields=name&access_token={$token}";
                $campaignNameResult = apiGet($campaignNameUrl);
                if (isset($campaignNameResult['name'])) {
                    $campaignName = $campaignNameResult['name'];
                }
            }

            if (!empty($campaignName)) {
                foreach ($crmDatabases as $db) {
                    $sqlCrm = "SELECT adset_name,
                                      SUM(CASE WHEN TRIM(UPPER(COALESCE(lead_status,'')))
                                               IN ('QUALIFIED','LOST POST QUALIFIED')
                                               THEN 1 ELSE 0 END) AS qualified_leads,
                                      0 AS site_visits
                               FROM `lead`
                               WHERE createddate >= ? AND createddate <= ?
                                 AND LOWER(TRIM(campaign_name)) = LOWER(TRIM(?))
                                 AND adset_name IS NOT NULL AND adset_name <> ''
                                 AND " . PQ_META_LEAD_SQL . "
                                 AND (lead_status IS NULL OR UPPER(TRIM(lead_status)) NOT IN ('TEST', 'JUNK'))
                                 AND (name IS NULL OR LOWER(TRIM(name)) NOT LIKE '%test%')
                                 AND (email IS NULL OR LOWER(TRIM(email)) NOT LIKE '%test%')
                                 AND (mobile IS NULL OR (
                                     LOWER(TRIM(mobile)) NOT LIKE '%test%'
                                     AND TRIM(mobile) NOT IN ('9999999999', '8888888888', '0000000000', '1234567890', '1111111111')
                                 ))
                               GROUP BY adset_name";

                    $stmtCrm = $db->prepare($sqlCrm);
                    if ($stmtCrm) {
                        $stmtCrm->bind_param('sss', $dbStartDate, $dbEndDate, $campaignName);
                        $stmtCrm->execute();
                        $resCrm = $stmtCrm->get_result();

                        while ($rowCrm = $resCrm->fetch_assoc()) {
                            $adsetNameLow = strtolower(trim($rowCrm['adset_name']));
                            if (!isset($crmCounts[$adsetNameLow])) {
                                $crmCounts[$adsetNameLow] = [
                                    'qualified' => 0,
                                    'walkins' => 0
                                ];
                            }
                            $crmCounts[$adsetNameLow]['qualified'] += (int) $rowCrm['qualified_leads'];
                        }

                        $stmtCrm->close();
                    }
                }

                $adsetLeadsCounts = getCombinedMetaDbLeadsCount(
                    $crmDatabases,
                    $dbStartDate,
                    $dbEndDate,
                    'adset_name',
                    ['campaign_name' => $campaignName]
                );
            } else {
                foreach ($crmDatabases as $db) {
                    $sqlCrm = "SELECT adset_name,
                                      SUM(CASE WHEN TRIM(UPPER(COALESCE(lead_status,'')))
                                               IN ('QUALIFIED','LOST POST QUALIFIED')
                                               THEN 1 ELSE 0 END) AS qualified_leads,
                                      0 AS site_visits
                               FROM `lead`
                               WHERE createddate >= ? AND createddate <= ?
                                 AND adset_name IS NOT NULL AND adset_name <> ''
                                 AND " . PQ_META_LEAD_SQL . "
                                 AND (lead_status IS NULL OR UPPER(TRIM(lead_status)) NOT IN ('TEST', 'JUNK'))
                                 AND (name IS NULL OR LOWER(TRIM(name)) NOT LIKE '%test%')
                                 AND (email IS NULL OR LOWER(TRIM(email)) NOT LIKE '%test%')
                                 AND (mobile IS NULL OR (
                                     LOWER(TRIM(mobile)) NOT LIKE '%test%'
                                     AND TRIM(mobile) NOT IN ('9999999999', '8888888888', '0000000000', '1234567890', '1111111111')
                                 ))
                               GROUP BY adset_name";

                    $stmtCrm = $db->prepare($sqlCrm);
                    if ($stmtCrm) {
                        $stmtCrm->bind_param('ss', $dbStartDate, $dbEndDate);
                        $stmtCrm->execute();
                        $resCrm = $stmtCrm->get_result();

                        while ($rowCrm = $resCrm->fetch_assoc()) {
                            $adsetNameLow = strtolower(trim($rowCrm['adset_name']));
                            if (!isset($crmCounts[$adsetNameLow])) {
                                $crmCounts[$adsetNameLow] = [
                                    'qualified' => 0,
                                    'walkins' => 0
                                ];
                            }
                            $crmCounts[$adsetNameLow]['qualified'] += (int) $rowCrm['qualified_leads'];
                        }

                        $stmtCrm->close();
                    }
                }

                $adsetLeadsCounts = getCombinedMetaDbLeadsCount(
                    $crmDatabases,
                    $dbStartDate,
                    $dbEndDate,
                    'adset_name'
                );
            }

            foreach ($adsetLeadsCounts as $adsetNameLow => $cnt) {
                if (!isset($crmCounts[$adsetNameLow])) {
                    $crmCounts[$adsetNameLow] = ['qualified' => 0, 'walkins' => 0];
                }
                $crmCounts[$adsetNameLow]['leads'] = $cnt;
            }
        }

        // FIX: Track which adset names have already claimed their CRM qualified/walkins
        // count. $crmCounts is keyed by adset_name only (the `lead` table has no
        // adset_id column), so if the same adset name appears more than once in
        // $allAdsetsRaw — e.g. a generic audience name like "LAL_1%" reused across
        // multiple ad accounts under the same campaign — every matching row previously
        // got the FULL crm count assigned independently. Summing those in the frontend
        // totals row then doubled (or tripled) the real number. We now assign the count
        // only once, to the first row with that name.
        $usedAdsetCrmNames = [];
        foreach ($allAdsetsRaw as $row) {
            $spend = round((float) ($row['spend'] ?? 0), 2);

            $adsetName = $row['adset_name'] ?? 'Unknown';
            $adsetNameLower = strtolower(trim($adsetName));
            if (!isset($usedAdsetCrmNames[$adsetNameLower])) {
                $crm = $crmCounts[$adsetNameLower] ?? ['qualified' => 0, 'walkins' => 0, 'leads' => 0];
                $usedAdsetCrmNames[$adsetNameLower] = true;
            } else {
                $crm = ['qualified' => 0, 'walkins' => 0, 'leads' => 0];
            }
            $qualified = $crm['qualified'];
            $walkins = $crm['walkins'];
            // Leads now come from the `lead` table (campaignsource fb/ig/
            // Facebook Lead Form) instead of Meta's own reported conversions.
            $leads = $crm['leads'] ?? 0;
            $cpl = $leads > 0 ? round($spend / $leads, 2) : 0.0;

            $cpql = $qualified > 0 ? round($spend / $qualified, 2) : 0.0;
            $cpsv = $walkins > 0 ? round($spend / $walkins, 2) : 0.0;

            // Get adset status from status map
            $aid = $row['adset_id'] ?? '';
            $adsetStatusInfo = $adsetStatusMap[$aid] ?? ['name' => $adsetName, 'status' => 'UNKNOWN', 'effective_status' => 'UNKNOWN'];

            $adsets[] = [
                'adset_id' => $aid,
                'pm' => $pmAdset[(string) $aid] ?? [],
                'adset_name' => $adsetName,
                'campaign_id' => $row['campaign_id'] ?? $campaignId,
                'campaign_name' => $row['campaign_name'] ?? '',
                'spend' => $spend,
                'impressions' => (int) ($row['impressions'] ?? 0),
                'reach' => (int) ($row['reach'] ?? 0),
                'clicks' => (int) ($row['clicks'] ?? 0),
                'ctr' => round((float) ($row['ctr'] ?? 0), 2),
                'cpm' => round((float) ($row['cpm'] ?? 0), 2),
                'frequency' => round((float) ($row['frequency'] ?? 0), 2),
                'leads' => $leads,
                'cpl' => $cpl,
                'qualified' => $qualified,
                'walkins' => $walkins,
                'cpql' => $cpql,
                'cpsv' => $cpsv,
                'status' => $adsetStatusInfo['status'],
                'effective_status' => $adsetStatusInfo['effective_status'],
            ];
        }

        // ── FIX: Inject zero-metric rows for INACTIVE / paused adsets ───────────
        // Meta's Insights API omits adsets with no activity in the selected date
        // range. The $adsetStatusMap already contains ALL adsets (fetched above),
        // so we cross-reference and add any that are missing from insights with
        // zeroed metrics so they still appear on the dashboard with correct status.
        $insightAdsetIds = array_column($adsets, 'adset_id');
        $insightAdsetIds = array_map('strval', $insightAdsetIds);
        foreach ($adsetStatusMap as $asId => $asStatusInfo) {
            $asId = (string) $asId;   // numeric array keys come back as int
            if ($asId === '' || in_array($asId, $insightAdsetIds, true))
                continue;
            $asName = $asStatusInfo['name'];
            $asNameLower = strtolower(trim($asName));
            if (!isset($usedAdsetCrmNames[$asNameLower])) {
                $crm = $crmCounts[$asNameLower] ?? ['qualified' => 0, 'walkins' => 0, 'leads' => 0];
                $usedAdsetCrmNames[$asNameLower] = true;
            } else {
                $crm = ['qualified' => 0, 'walkins' => 0, 'leads' => 0];
            }
            $adsets[] = [
                'adset_id' => $asId,
                'adset_name' => $asName,
                'campaign_id' => $campaignId,
                'campaign_name' => '',
                'spend' => 0.0,
                'impressions' => 0,
                'reach' => 0,
                'clicks' => 0,
                'ctr' => 0.0,
                'cpm' => 0.0,
                'frequency' => 0.0,
                'leads' => $crm['leads'] ?? 0,
                'cpl' => 0.0,
                'qualified' => $crm['qualified'],
                'walkins' => $crm['walkins'],
                'cpql' => 0.0,
                'cpsv' => 0.0,
                'status' => $asStatusInfo['status'],
                'effective_status' => $asStatusInfo['effective_status'],
            ];
        }
        // ── End inactive adset injection ─────────────────────────────────────────

        // ── Inject any remaining CRM adsets with leads so no CRM leads are dropped ──
        foreach ($crmCounts as $adsetNameLow => $crm) {
            if (!isset($usedAdsetCrmNames[$adsetNameLow]) && (($crm['leads'] ?? 0) > 0 || ($crm['qualified'] ?? 0) > 0)) {
                $usedAdsetCrmNames[$adsetNameLow] = true;
                $adsets[] = [
                    'adset_id' => 'crm_' . md5($adsetNameLow),
                    'adset_name' => ucwords($adsetNameLow),
                    'campaign_id' => $campaignId,
                    'campaign_name' => $campaignName,
                    'spend' => 0.0,
                    'impressions' => 0,
                    'reach' => 0,
                    'clicks' => 0,
                    'ctr' => 0.0,
                    'cpm' => 0.0,
                    'frequency' => 0.0,
                    'leads' => $crm['leads'] ?? 0,
                    'cpl' => 0.0,
                    'qualified' => $crm['qualified'] ?? 0,
                    'walkins' => $crm['walkins'] ?? 0,
                    'cpql' => 0.0,
                    'cpsv' => 0.0,
                    'status' => 'ACTIVE',
                    'effective_status' => 'ACTIVE',
                ];
            }
        }
    }

    $data = [
        'fetched_at' => date('d M Y, h:i A'),
        'campaign_id' => $campaignId,
        'date_preset' => $displayPreset,
        'api_error' => $apiError,
        'adsets' => $adsets,
    ];

    // Persist to cache only on clean response
    if (!$apiError) {
        if (!is_dir(dirname($cacheFile))) {
            mkdir(dirname($cacheFile), 0755, true);
        }
        file_put_contents($cacheFile, json_encode($data));
    }

    return metaFilterAdsetResult($data, $campaignId);
}

// ============================================================
// AD LEVEL FETCH
// ============================================================

/**
 * Fetch ad-level insights for a given adset ID.
 *
 * @param string      $adsetId   Meta adset ID to drill into.
 * @param string|null $preset    Date preset (e.g. 'last_30d'). Falls back to DATE_PRESET.
 * @param string|null $since     Custom range start (YYYY-MM-DD). Overrides $preset when both $since/$until supplied.
 * @param string|null $until     Custom range end   (YYYY-MM-DD).
 *
 * @return array {
 *   fetched_at: string,
 *   adset_id: string,
 *   date_preset: string,
 *   api_error: array|null,
 *   ads: array<{
 *     ad_id, ad_name, adset_id, adset_name, campaign_id, campaign_name,
 *     spend, impressions, reach, clicks, ctr, cpm, frequency,
 *     leads, cpl
 *   }>
 * }
 */
/**
 * Fast, flat ad-level spend fetch for reports (e.g. the Export Analysis Report).
 * Replaces the old "1 campaign -> fetchAdsetData -> N adsets -> fetchAdData" walk,
 * which fired 3 Graph API calls per campaign PLUS 3 more per ad set (100+ sequential
 * round-trips on a real account, ~2-3 minutes). This does ONE insights call per ad
 * account at level=ad, paginated by fetchAllPages() — typically 1-3 calls total
 * regardless of how many campaigns/ad sets exist.
 *
 * Returns: ['rows' => [{campaign_name, adset_name, ad_name, spend}], 'api_error' => array|null]
 */
function fetchAdsPivotSpend(string $preset = null, string $since = null, string $until = null): array
{
    if (empty($preset) && (empty($since) || empty($until))) {
        $preset = defined('DATE_PRESET') ? DATE_PRESET : 'last_30d';
    }

    // Resolve account IDs (same logic used everywhere else in this file)
    $accountIds = [];
    if (defined('META_AD_ACCOUNT_IDS')) {
        $rawIds = META_AD_ACCOUNT_IDS;
        if (is_array($rawIds)) {
            $accountIds = $rawIds;
        } else {
            $decoded = json_decode($rawIds, true);
            $accountIds = is_array($decoded) ? $decoded : [$rawIds];
        }
    } elseif (defined('META_AD_ACCOUNT_ID')) {
        $accountIds = [META_AD_ACCOUNT_ID];
    }
    // Normalize (trim + strip a leading "act_" if someone configured it that way) BEFORE
    // dedup, so "123456", " 123456", and "act_123456" are recognized as the same account
    // instead of each being fetched separately and doubling every row.
    $accountIds = array_map(function ($id) {
        $id = trim((string) $id);
        return preg_replace('/^act_/i', '', $id);
    }, $accountIds);
    $accountIds = array_values(array_unique(array_filter($accountIds, fn($id) => $id !== '')));
    if (empty($accountIds)) {
        return ['rows' => [], 'api_error' => null];
    }

    $token = META_ACCESS_TOKEN;
    $version = META_API_VERSION;

    $dateParam = "";
    if (!empty($since) && !empty($until)) {
        $timeRange = json_encode(['since' => metaSafeSince($since), 'until' => max($until, metaSafeSince($since))]);
        $dateParam = "&time_range=" . urlencode($timeRange);
    } else {
        $dateParam = "&date_preset={$preset}";
    }

    $fields = "ad_id,campaign_id,campaign_name,adset_id,adset_name,ad_name,spend,impressions,clicks,frequency,reach";
    $rows = [];
    $apiError = null;

    foreach ($accountIds as $accId) {
        if (empty($accId)) {
            continue;
        }
        $url = "https://graph.facebook.com/{$version}/act_{$accId}/insights"
            . "?fields={$fields}"
            . "&level=ad"
            . $dateParam
            . "&limit=500"
            . "&access_token={$token}";

        $result = fetchAllPages($url);
        if (isset($result['error'])) {
            $apiError = $result['error'];
            break;
        }
        foreach ($result['data'] ?? [] as $row) {
            $rows[] = [
                'ad_id' => $row['ad_id'] ?? '',
                'campaign_id' => $row['campaign_id'] ?? '',
                'campaign_name' => $row['campaign_name'] ?? '',
                'adset_id' => $row['adset_id'] ?? '',
                'adset_name' => $row['adset_name'] ?? '',
                'ad_name' => $row['ad_name'] ?? '',
                'spend' => (float) ($row['spend'] ?? 0),
                'impressions' => (int) ($row['impressions'] ?? 0),
                'clicks' => (int) ($row['clicks'] ?? 0),
                'frequency' => (float) ($row['frequency'] ?? 0),
                'reach' => (int) ($row['reach'] ?? 0),
            ];
        }
    }

    // Only ads saved for this project (campaign → ad set → ad), with saved names.
    [$rows, $hiddenRows] = filterProjectAdRows('meta', $rows, [
        'campaign_id' => 'campaign_id', 'campaign_name' => 'campaign_name',
        'adgroup_id' => 'adset_id', 'adgroup_name' => 'adset_name',
        'ad_id' => 'ad_id', 'ad_name' => 'ad_name',
    ]);

    return ['rows' => $rows, 'api_error' => $apiError, 'hidden_rows' => $hiddenRows];
}

function fetchAdData(string $adsetId, string $preset = null, string $since = null, string $until = null, string $campaignName = '', string $adsetName = ''): array
{
    $crmDatabases = getFetchMetaCrmDatabases();
    if (empty($preset) && (empty($since) || empty($until))) {
        $preset = defined('DATE_PRESET') ? DATE_PRESET : 'last_30d';
    }

    // Resolve account IDs
    $accountIds = [];
    if (defined('META_AD_ACCOUNT_IDS')) {
        $rawIds = META_AD_ACCOUNT_IDS;
        if (is_array($rawIds)) {
            $accountIds = $rawIds;
        } else {
            $decoded = json_decode($rawIds, true);
            $accountIds = is_array($decoded) ? $decoded : [$rawIds];
        }
    } elseif (defined('META_AD_ACCOUNT_ID')) {
        $accountIds = [META_AD_ACCOUNT_ID];
    }
    if (empty($accountIds)) {
        $accountIds = [''];
    }

    $token = META_ACCESS_TOKEN;
    $version = META_API_VERSION;

    // Build date parameter
    if (!empty($since) && !empty($until)) {
        $timeRange = json_encode(['since' => metaSafeSince($since), 'until' => max($until, metaSafeSince($since))]);
        $dateParam = "&time_range=" . urlencode($timeRange);
        $displayPreset = date('d/m/Y', strtotime($since)) . ' - ' . date('d/m/Y', strtotime($until));
    } else {
        $dateParam = "&date_preset={$preset}";
        $displayPreset = $preset;
    }

    // Cache key scoped to adset + adset name + campaign name + date range
    $safeAdsetId = preg_replace('/[^0-9]/', '', $adsetId);
    $safeAdsetName = preg_replace('/[^a-zA-Z0-9\_]/', '', $adsetName);
    $safeCampName = preg_replace('/[^a-zA-Z0-9\_]/', '', $campaignName);
    if (!empty($since) && !empty($until)) {
        $safeSince = preg_replace('/[^0-9\-]/', '', $since);
        $safeUntil = preg_replace('/[^0-9\-]/', '', $until);
        $cacheFile = CACHE_PATH . "/meta_ads_{$safeAdsetId}_{$safeAdsetName}_{$safeCampName}_{$safeSince}_{$safeUntil}.json";
    } else {
        $safePreset = preg_replace('/[^a-zA-Z0-9\_]/', '', $preset);
        $cacheFile = CACHE_PATH . "/meta_ads_{$safeAdsetId}_{$safeAdsetName}_{$safeCampName}_{$safePreset}.json";
    }

    // Return from cache if still fresh
    if (file_exists($cacheFile) && (time() - filemtime($cacheFile)) < CACHE_SECONDS) {
        $cached = json_decode(file_get_contents($cacheFile), true);
        if (isset($cached['ads']) && !isset($cached['api_error'])) {
            return metaFilterAdResult($cached, $adsetId);
        }
    }

    $filtering = [['field' => 'adset.id', 'operator' => 'EQUAL', 'value' => $adsetId]];
    $filteringParam = "&filtering=" . urlencode(json_encode($filtering));

    $fields = "ad_id,ad_name,adset_id,adset_name,campaign_id,campaign_name,"
        . "spend,impressions,reach,clicks,ctr,cpm,frequency,"
        . "actions,cost_per_action_type";

    // Fetch ad-level status (Active/Inactive) separately since status is not in insights.
    // FIX: also store 'name' in the map so inactive ads can be injected with correct names.
    $adStatusMap = [];
    foreach ($accountIds as $accId) {
        if (empty($accId))
            continue;
        $adStatusUrl = "https://graph.facebook.com/{$version}/act_{$accId}/ads"
            . "?fields=id,name,status,effective_status"
            . "&filtering=" . urlencode(json_encode([['field' => 'adset.id', 'operator' => 'EQUAL', 'value' => $adsetId]]))
            . "&limit=200"
            . "&access_token={$token}";
        $adStatusResult = fetchAllPages($adStatusUrl);
        if (isset($adStatusResult['data']) && is_array($adStatusResult['data'])) {
            foreach ($adStatusResult['data'] as $adObj) {
                $adStatusMap[$adObj['id'] ?? ''] = [
                    'name' => $adObj['name'] ?? '',   // FIX: store name
                    'status' => $adObj['status'] ?? 'UNKNOWN',
                    'effective_status' => $adObj['effective_status'] ?? 'UNKNOWN',
                ];
            }
        }
    }

    $allAdsRaw = [];
    $apiError = null;

    foreach ($accountIds as $accId) {
        if (empty($accId))
            continue;

        $url = "https://graph.facebook.com/{$version}/act_{$accId}/insights"
            . "?fields={$fields}"
            . "&level=ad"
            . $dateParam
            . $filteringParam
            . "&limit=100"
            . "&access_token={$token}";

        $result = fetchAllPages($url);

        if (isset($result['error'])) {
            $apiError = $result['error'];
            break;
        }
        foreach (pmMetaFetch($version, (string) $accId, $token, 'ad', $dateParam . $filteringParam) as $pmId => $pmVals) {
            $pmAd[$pmId] = pmMerge($pmAd[$pmId] ?? [], $pmVals, 'meta');
        }

        $allAdsRaw = array_merge($allAdsRaw, $result['data'] ?? []);
    }

    // Map raw API rows to a clean structure
    $ads = [];
    if (!$apiError) {
        global $conn;
        $crmCounts = [];
        if (!empty($crmDatabases)) {
            if (!empty($since) && !empty($until)) {
                $dbStartDate = $since . ' 00:00:00';
                $dbEndDate = $until . ' 23:59:59';
            } else {
                list($s, $u) = getDatesFromPreset($preset);
                $dbStartDate = $s . ' 00:00:00';
                $dbEndDate = $u . ' 23:59:59';
            }

            // Resolve campaign and adset names for the current adset if not passed in.
            if (empty($adsetName) || empty($campaignName)) {
                if (!empty($allAdsRaw)) {
                    if (empty($adsetName)) $adsetName = $allAdsRaw[0]['adset_name'] ?? '';
                    if (empty($campaignName)) $campaignName = $allAdsRaw[0]['campaign_name'] ?? '';
                }
            }
            if (empty($adsetName) || empty($campaignName)) {
                // Fallback only when insights rows didn't give us what we need
                // (e.g. the adset has zero ads with activity in this date range).
                $adsetUrl = "https://graph.facebook.com/{$version}/{$adsetId}?fields=name,campaign{name}&access_token={$token}";
                $adsetResult = apiGet($adsetUrl);
                if (empty($adsetName) && isset($adsetResult['name'])) {
                    $adsetName = $adsetResult['name'];
                }
                if (empty($campaignName) && isset($adsetResult['campaign']['name'])) {
                    $campaignName = $adsetResult['campaign']['name'];
                }
            }

            if (!empty($campaignName) && !empty($adsetName)) {
                foreach ($crmDatabases as $db) {
                    $sqlCrm = "SELECT ad_name,
                                      SUM(CASE WHEN TRIM(UPPER(COALESCE(lead_status,'')))
                                               IN ('QUALIFIED','LOST POST QUALIFIED')
                                               THEN 1 ELSE 0 END) AS qualified_leads,
                                      0 AS site_visits
                               FROM `lead`
                               WHERE createddate >= ? AND createddate <= ?
                                 AND LOWER(TRIM(campaign_name)) = LOWER(TRIM(?))
                                 AND LOWER(TRIM(adset_name)) = LOWER(TRIM(?))
                                 AND ad_name IS NOT NULL AND ad_name <> ''
                                 AND " . PQ_META_LEAD_SQL . "
                                 AND (lead_status IS NULL OR UPPER(TRIM(lead_status)) NOT IN ('TEST', 'JUNK'))
                                 AND (name IS NULL OR LOWER(TRIM(name)) NOT LIKE '%test%')
                                 AND (email IS NULL OR LOWER(TRIM(email)) NOT LIKE '%test%')
                                 AND (mobile IS NULL OR (
                                     LOWER(TRIM(mobile)) NOT LIKE '%test%'
                                     AND TRIM(mobile) NOT IN ('9999999999', '8888888888', '0000000000', '1234567890', '1111111111')
                                 ))
                               GROUP BY ad_name";

                    $stmtCrm = $db->prepare($sqlCrm);
                    if ($stmtCrm) {
                        $stmtCrm->bind_param('ssss', $dbStartDate, $dbEndDate, $campaignName, $adsetName);
                        $stmtCrm->execute();
                        $resCrm = $stmtCrm->get_result();

                        while ($rowCrm = $resCrm->fetch_assoc()) {
                            $adNameLow = strtolower(trim($rowCrm['ad_name']));
                            if (!isset($crmCounts[$adNameLow])) {
                                $crmCounts[$adNameLow] = [
                                    'qualified' => 0,
                                    'walkins' => 0
                                ];
                            }
                            $crmCounts[$adNameLow]['qualified'] += (int) $rowCrm['qualified_leads'];
                        }

                        $stmtCrm->close();
                    }
                }

                $adLeadsCounts = getCombinedMetaDbLeadsCount(
                    $crmDatabases,
                    $dbStartDate,
                    $dbEndDate,
                    'ad_name',
                    [
                        'campaign_name' => $campaignName,
                        'adset_name' => $adsetName
                    ]
                );
            } else {
                foreach ($crmDatabases as $db) {
                    $sqlCrm = "SELECT ad_name,
                                      SUM(CASE WHEN TRIM(UPPER(COALESCE(lead_status,'')))
                                               IN ('QUALIFIED','LOST POST QUALIFIED')
                                               THEN 1 ELSE 0 END) AS qualified_leads,
                                      0 AS site_visits
                               FROM `lead`
                               WHERE createddate >= ? AND createddate <= ?
                                 AND ad_name IS NOT NULL AND ad_name <> ''
                                 AND " . PQ_META_LEAD_SQL . "
                                 AND (lead_status IS NULL OR UPPER(TRIM(lead_status)) NOT IN ('TEST', 'JUNK'))
                                 AND (name IS NULL OR LOWER(TRIM(name)) NOT LIKE '%test%')
                                 AND (email IS NULL OR LOWER(TRIM(email)) NOT LIKE '%test%')
                                 AND (mobile IS NULL OR (
                                     LOWER(TRIM(mobile)) NOT LIKE '%test%'
                                     AND TRIM(mobile) NOT IN ('9999999999', '8888888888', '0000000000', '1234567890', '1111111111')
                                 ))
                               GROUP BY ad_name";

                    $stmtCrm = $db->prepare($sqlCrm);
                    if ($stmtCrm) {
                        $stmtCrm->bind_param('ss', $dbStartDate, $dbEndDate);
                        $stmtCrm->execute();
                        $resCrm = $stmtCrm->get_result();

                        while ($rowCrm = $resCrm->fetch_assoc()) {
                            $adNameLow = strtolower(trim($rowCrm['ad_name']));
                            if (!isset($crmCounts[$adNameLow])) {
                                $crmCounts[$adNameLow] = [
                                    'qualified' => 0,
                                    'walkins' => 0
                                ];
                            }
                            $crmCounts[$adNameLow]['qualified'] += (int) $rowCrm['qualified_leads'];
                        }

                        $stmtCrm->close();
                    }
                }

                $adLeadsCounts = getCombinedMetaDbLeadsCount(
                    $crmDatabases,
                    $dbStartDate,
                    $dbEndDate,
                    'ad_name'
                );
            }

            foreach ($adLeadsCounts as $adNameLow => $cnt) {
                if (!isset($crmCounts[$adNameLow])) {
                    $crmCounts[$adNameLow] = ['qualified' => 0, 'walkins' => 0];
                }
                $crmCounts[$adNameLow]['leads'] = $cnt;
            }
        }

        // FIX: Same double-count protection as campaign/adset level — $crmCounts is
        // keyed by ad_name only, so a reused ad/creative name (e.g. "Video Ad 1") across
        // multiple adsets/accounts would otherwise get the full crm count assigned to
        // every matching row, inflating the summed total.
        $usedAdCrmNames = [];
        foreach ($allAdsRaw as $row) {
            $spend = round((float) ($row['spend'] ?? 0), 2);

            $adName = $row['ad_name'] ?? 'Unknown';
            $adNameLower = strtolower(trim($adName));
            if (!isset($usedAdCrmNames[$adNameLower])) {
                $crm = $crmCounts[$adNameLower] ?? ['qualified' => 0, 'walkins' => 0, 'leads' => 0];
                $usedAdCrmNames[$adNameLower] = true;
            } else {
                $crm = ['qualified' => 0, 'walkins' => 0, 'leads' => 0];
            }
            $qualified = $crm['qualified'];
            $walkins = $crm['walkins'];
            // Leads now come from the `lead` table (campaignsource fb/ig/
            // Facebook Lead Form) instead of Meta's own reported conversions.
            $leads = $crm['leads'] ?? 0;
            $cpl = $leads > 0 ? round($spend / $leads, 2) : 0.0;

            $cpql = $qualified > 0 ? round($spend / $qualified, 2) : 0.0;
            $cpsv = $walkins > 0 ? round($spend / $walkins, 2) : 0.0;

            // Get ad status from status map
            $adId = $row['ad_id'] ?? '';
            $adStatusInfo = $adStatusMap[$adId] ?? ['name' => $adName, 'status' => 'UNKNOWN', 'effective_status' => 'UNKNOWN'];

            $ads[] = [
                'ad_id' => $adId,
                'pm' => $pmAd[(string) $adId] ?? [],
                'ad_name' => $adName,
                'adset_id' => $row['adset_id'] ?? $adsetId,
                'adset_name' => $row['adset_name'] ?? '',
                'campaign_id' => $row['campaign_id'] ?? '',
                'campaign_name' => $row['campaign_name'] ?? '',
                'spend' => $spend,
                'impressions' => (int) ($row['impressions'] ?? 0),
                'reach' => (int) ($row['reach'] ?? 0),
                'clicks' => (int) ($row['clicks'] ?? 0),
                'ctr' => round((float) ($row['ctr'] ?? 0), 2),
                'cpm' => round((float) ($row['cpm'] ?? 0), 2),
                'frequency' => round((float) ($row['frequency'] ?? 0), 2),
                'leads' => $leads,
                'cpl' => $cpl,
                'qualified' => $qualified,
                'walkins' => $walkins,
                'cpql' => $cpql,
                'cpsv' => $cpsv,
                'status' => $adStatusInfo['status'],
                'effective_status' => $adStatusInfo['effective_status'],
            ];
        }

        // ── FIX: Inject zero-metric rows for INACTIVE / paused ads ──────────────
        // Meta's Insights API omits ads with no activity in the selected date range.
        // The $adStatusMap already contains ALL ads for this adset (fetched above),
        // so we cross-reference and add any that are missing from insights with
        // zeroed metrics so they still appear on the dashboard with correct status.
        $insightAdIds = array_column($ads, 'ad_id');
        $insightAdIds = array_map('strval', $insightAdIds);
        foreach ($adStatusMap as $adId => $adStatusInfo) {
            $adId = (string) $adId;   // numeric array keys come back as int
            if ($adId === '' || in_array($adId, $insightAdIds, true))
                continue;
            $adName = $adStatusInfo['name'];
            $adNameLower = strtolower(trim($adName));
            if (!isset($usedAdCrmNames[$adNameLower])) {
                $crm = $crmCounts[$adNameLower] ?? ['qualified' => 0, 'walkins' => 0, 'leads' => 0];
                $usedAdCrmNames[$adNameLower] = true;
            } else {
                $crm = ['qualified' => 0, 'walkins' => 0, 'leads' => 0];
            }
            $ads[] = [
                'ad_id' => $adId,
                'pm' => $pmAd[(string) $adId] ?? [],
                'ad_name' => $adName,
                'adset_id' => $adsetId,
                'adset_name' => '',
                'campaign_id' => '',
                'campaign_name' => '',
                'spend' => 0.0,
                'impressions' => 0,
                'reach' => 0,
                'clicks' => 0,
                'ctr' => 0.0,
                'cpm' => 0.0,
                'frequency' => 0.0,
                'leads' => $crm['leads'] ?? 0,
                'cpl' => 0.0,
                'qualified' => $crm['qualified'],
                'walkins' => $crm['walkins'],
                'cpql' => 0.0,
                'cpsv' => 0.0,
                'status' => $adStatusInfo['status'],
                'effective_status' => $adStatusInfo['effective_status'],
            ];
        }
        // ── End inactive ad injection ────────────────────────────────────────────

        // ── Inject any remaining CRM ads with leads so no CRM leads are dropped ──
        foreach ($crmCounts as $adNameLow => $crm) {
            if (!isset($usedAdCrmNames[$adNameLow]) && (($crm['leads'] ?? 0) > 0 || ($crm['qualified'] ?? 0) > 0)) {
                $usedAdCrmNames[$adNameLow] = true;
                $ads[] = [
                    'ad_id' => 'crm_' . md5($adNameLow),
                    'ad_name' => ucwords($adNameLow),
                    'adset_id' => $adsetId,
                    'adset_name' => $adsetName,
                    'campaign_id' => '',
                    'campaign_name' => $campaignName,
                    'spend' => 0.0,
                    'impressions' => 0,
                    'reach' => 0,
                    'clicks' => 0,
                    'ctr' => 0.0,
                    'cpm' => 0.0,
                    'frequency' => 0.0,
                    'leads' => $crm['leads'] ?? 0,
                    'cpl' => 0.0,
                    'qualified' => $crm['qualified'] ?? 0,
                    'walkins' => $crm['walkins'] ?? 0,
                    'cpql' => 0.0,
                    'cpsv' => 0.0,
                    'status' => 'ACTIVE',
                    'effective_status' => 'ACTIVE',
                ];
            }
        }
    }

    $data = [
        'fetched_at' => date('d M Y, h:i A'),
        'adset_id' => $adsetId,
        'date_preset' => $displayPreset,
        'api_error' => $apiError,
        'ads' => $ads,
    ];

    // Persist to cache only on clean response
    if (!$apiError) {
        if (!is_dir(dirname($cacheFile))) {
            mkdir(dirname($cacheFile), 0755, true);
        }
        file_put_contents($cacheFile, json_encode($data));
    }

    return metaFilterAdResult($data, $adsetId);
}

// ============================================================
// cURL helper
// ============================================================

function apiGet(string $url): array
{ //if nothing comes it will fetch from here
    if (!function_exists('curl_init')) {
        return ['error' => ['message' => 'cURL is not enabled. Enable it in php.ini']];
    }

    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 20,
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_SSL_VERIFYHOST => 2,
        CURLOPT_USERAGENT => 'MetaAdsDashboard/1.0',
        CURLOPT_HTTPHEADER => ['Accept: application/json'],
    ]);

    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlError = curl_error($ch);
    curl_close($ch);

    if ($curlError) {
        return ['error' => ['message' => 'Connection error: ' . $curlError]];
    }
    if ($response === false || $response === '') {
        return ['error' => ['message' => 'Empty response (HTTP ' . $httpCode . ')']];
    }

    $decoded = json_decode($response, true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        return ['error' => ['message' => 'Invalid JSON from Meta API']];
    }

    return $decoded;
}

// ============================================================
// PROJECT FILTER for drill-downs — only ad sets / ads saved in the
// adgroups / ads tables (app/Ads/master_tables.php), with saved names.
// ============================================================
function metaFilterAdsetResult(array $data, string $campaignId): array
{
    [$data['adsets'], $info] = filterProjectAdgroups('meta', $campaignId, $data['adsets'] ?? [], 'adset_id', 'adset_name');
    $data['structure'] = $info + ['level' => 'adset'];
    return $data;
}

function metaFilterAdResult(array $data, string $adsetId): array
{
    [$data['ads'], $info] = filterProjectAds('meta', $adsetId, $data['ads'] ?? [], 'ad_id', 'ad_name');
    $data['structure'] = $info + ['level' => 'ad'];
    return $data;
}
