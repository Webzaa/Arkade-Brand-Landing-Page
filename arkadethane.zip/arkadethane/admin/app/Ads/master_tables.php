<?php
/**
 * app/Ads/master_tables.php — the project's campaigns, ad sets and ads, for EVERY ad platform.
 *
 * Ad accounts are shared between projects, so the master tables decide what belongs here:
 *
 *   campaigns (campaign_id, campaign_name, status, platform)
 *   adgroups  (adgroup_id, campaign_id, adgroup_name, status, platform)   ← Meta ad sets / Google ad groups
 *   ads       (ad_id, adgroup_id, ad_name, status, platform)
 *
 * platform = 'meta' | 'google'.
 *
 * Rules used by every dashboard, drill-down, export and report:
 *   - Only campaigns / ad sets / ads saved in these tables are shown.
 *   - Their NAMES come from these tables (use "Refresh details" in the Sync window to update them).
 *   - Lead data (lead table) is attached to them; leads are never deleted or hidden from the CRM.
 *
 * Filled by the "Sync with Meta / Google / Taboola" buttons (public/ads/*_sync_api.php).
 * Tables live in MASTER_TABLES_DB (default: the first LEAD_DATABASES entry) and are created if missing.
 */

require_once dirname(__DIR__) . '/Core/db.php';

/**
 * Which leads are Meta leads — one definition for every dashboard, report and the Unmapped page:
 * a Meta lead-form ID (leadgen_id), or a Meta source name (lead forms imported without leadgen_id
 * such as "metalf", click-to-WhatsApp leads tagged "Social Media", Instagram, WhatsApp…).
 */
const PQ_META_SOURCES = ['facebook lead form', 'facebook', 'fb', 'ig', 'instagram', 'meta', 'metalf', 'meta lead form', 'whatsapp', 'social media', 'facebook ads', 'meta ads'];
const PQ_META_LEAD_SQL = "(TRIM(COALESCE(leadgen_id, '')) <> '' OR LOWER(TRIM(COALESCE(campaignsource, ''))) IN ('facebook lead form', 'facebook', 'fb', 'ig', 'instagram', 'meta', 'metalf', 'meta lead form', 'whatsapp', 'social media', 'facebook ads', 'meta ads'))";
/** Google source names (leads with a Google campaign ID / gclid count as Google too). */
const PQ_GOOGLE_SOURCES = ['google', 'googledg', 'google ads', 'adwords', 'google search', 'google display', 'display / programmatic', 'demandgen', 'demand gen', 'youtube', 'pmax', 'performance max'];

/** Tracking macros that were never filled in ("{campaignid}", "{gclid}", "{creative}") count as empty. */
function pqCleanTrack($v): string
{
    $v = trim((string) $v);
    return preg_match('/^\{[^}]*\}$/', $v) ? '' : $v;
}

const MASTER_PLATFORMS = ['meta', 'google'];   // Taboola is not filtered by the campaigns table (for now)

/* ======================================================================
 * Tables
 * ====================================================================== */

function masterDb(): ?mysqli
{
    $db = leadDb(masterTablesDbKey());
    return ($db instanceof mysqli && !$db->connect_errno) ? $db : null;
}

function masterTableExists(mysqli $db, string $table): bool
{
    $res = $db->query("SHOW TABLES LIKE '" . $db->real_escape_string($table) . "'");
    $ok = $res && $res->num_rows > 0;
    if ($res instanceof mysqli_result) {
        $res->free();
    }
    return $ok;
}

/** Creates campaigns / adgroups / ads if they don't exist (each unique on its platform ID). */
function masterEnsureTables(mysqli $db): void
{
    $db->query("CREATE TABLE IF NOT EXISTS `campaigns` (
        `id`            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        `campaign_id`   VARCHAR(64)  NOT NULL,
        `campaign_name` VARCHAR(255) NOT NULL,
        `status`        VARCHAR(50)  NULL,
        `platform`      VARCHAR(20)  NOT NULL DEFAULT 'meta',
        `created_at`    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY `campaign_id` (`campaign_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci");
    masterCampaignTypeColumn($db, true);

    $db->query("CREATE TABLE IF NOT EXISTS `adgroups` (
        `id`           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        `adgroup_id`   VARCHAR(64)  NOT NULL,
        `campaign_id`  VARCHAR(64)  NOT NULL,
        `adgroup_name` VARCHAR(255) NOT NULL,
        `status`       VARCHAR(50)  NULL,
        `platform`     VARCHAR(20)  NOT NULL DEFAULT 'meta',
        `created_at`   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY `adgroup_id` (`adgroup_id`),
        KEY `campaign_id` (`campaign_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci");

    $db->query("CREATE TABLE IF NOT EXISTS `ads` (
        `id`         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        `ad_id`      VARCHAR(64)  NOT NULL,
        `adgroup_id` VARCHAR(64)  NOT NULL,
        `ad_name`    VARCHAR(255) NOT NULL,
        `status`     VARCHAR(50)  NULL,
        `platform`   VARCHAR(20)  NOT NULL DEFAULT 'meta',
        `created_at` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY `ad_id` (`ad_id`),
        KEY `adgroup_id` (`adgroup_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci");
}

function masterNorm(?string $name): string
{
    $name = (string) $name;
    return strtolower(trim(preg_replace('/\s+/u', ' ', $name) ?? $name));
}

function masterClean($v, int $max = 255): string
{
    $v = trim(preg_replace('/\s+/u', ' ', (string) $v) ?? (string) $v);
    return function_exists('mb_substr') ? mb_substr($v, 0, $max) : substr($v, 0, $max);
}

/* ======================================================================
 * Read: the project's structure for one platform (cached per request)
 * ====================================================================== */

/** @internal cache holder */
function &masterStructureCache(): array
{
    static $cache = [];
    return $cache;
}

function masterForgetCache(): void
{
    $c = &masterStructureCache();
    $c = [];
}

/**
 * @return array{
 *   campaigns: array<string,string>,          id => saved name
 *   campaign_by_name: array<string,string>,   normalised name => id
 *   adgroups: array<string,array{name:string,campaign_id:string}>,
 *   adgroups_by_campaign: array<string,int>,
 *   adgroup_by_name: array<string,string>,    campaign_id|normalised name => adgroup id
 *   ads: array<string,array{name:string,adgroup_id:string}>,
 *   ad_by_name: array<string,string>,         adgroup_id|normalised name => ad id
 *   count: int, configured: bool, error: ?string
 * }
 */
function projectStructure(string $platform): array
{
    $platform = strtolower($platform);
    $cache = &masterStructureCache();
    if (isset($cache[$platform])) {
        return $cache[$platform];
    }
    $s = ['campaigns' => [], 'campaign_by_name' => [], 'adgroups' => [], 'adgroups_by_campaign' => [], 'adgroup_by_name' => [],
          'ads' => [], 'ad_by_name' => [], 'count' => 0, 'configured' => false, 'error' => null, 'types' => [], 'awareness' => []];

    $db = masterDb();
    if (!$db) {
        $s['error'] = 'Campaign database is not reachable';
        return $cache[$platform] = $s;
    }
    if (!masterTableExists($db, 'campaigns')) {
        return $cache[$platform] = $s;   // not set up yet → "Sync"
    }
    $p = "'" . $db->real_escape_string($platform) . "'";
    // Rows saved before the platform column existed count as Meta.
    $pc = $platform === 'meta' ? "LOWER(COALESCE(NULLIF(TRIM(platform), ''), 'meta')) = 'meta'" : "LOWER(TRIM(platform)) = {$p}";

    $typeCol = masterCampaignTypeColumn($db, true) ? ', campaign_type' : '';
    try {
        $res = $db->query("SELECT TRIM(campaign_id) AS id, campaign_name{$typeCol} FROM `campaigns` WHERE {$pc}");
    } catch (Throwable $e) {
        $res = false;
    }
    if (!$res && $typeCol !== '') {
        $res = $db->query("SELECT TRIM(campaign_id) AS id, campaign_name FROM `campaigns` WHERE {$pc}");   // no campaign_type column (yet)
    }
    while ($res && ($r = $res->fetch_assoc())) {
        $id = (string) $r['id'];
        $name = masterClean($r['campaign_name'] ?? '');
        if ($id === '') {
            continue;
        }
        $type = strtolower(trim((string) ($r['campaign_type'] ?? ''))) === 'awareness' ? 'awareness' : 'performance';
        $s['types'][$id] = $type;
        if ($type === 'awareness') {
            $s['awareness'][$id] = true;
        }
        $s['campaigns'][$id] = $name !== '' ? $name : $id;
        if ($name !== '') {
            $s['campaign_by_name'][masterNorm($name)] = $id;
        }
    }
    $s['count'] = count($s['campaigns']);
    $s['configured'] = $s['count'] > 0;

    if ($s['configured'] && masterTableExists($db, 'adgroups')) {
        $res = $db->query("SELECT TRIM(adgroup_id) AS id, TRIM(campaign_id) AS cid, adgroup_name FROM `adgroups` WHERE {$pc}");
        while ($res && ($r = $res->fetch_assoc())) {
            $cid = (string) $r['cid'];
            if (!isset($s['campaigns'][$cid]) || (string) $r['id'] === '') {
                continue;   // ad sets of campaigns that are not in the project don't count
            }
            $s['adgroups'][(string) $r['id']] = ['name' => masterClean($r['adgroup_name'] ?? ''), 'campaign_id' => $cid];
            $s['adgroups_by_campaign'][$cid] = ($s['adgroups_by_campaign'][$cid] ?? 0) + 1;
            $s['adgroup_by_name'][$cid . '|' . masterNorm($r['adgroup_name'] ?? '')] = (string) $r['id'];
        }
    }
    if ($s['adgroups'] && masterTableExists($db, 'ads')) {
        $res = $db->query("SELECT TRIM(ad_id) AS id, TRIM(adgroup_id) AS gid, ad_name, status FROM `ads` WHERE {$pc}");
        while ($res && ($r = $res->fetch_assoc())) {
            $gid = (string) $r['gid'];
            if (!isset($s['adgroups'][$gid]) || (string) $r['id'] === '') {
                continue;
            }
            $s['ads'][(string) $r['id']] = ['name' => masterClean($r['ad_name'] ?? ''), 'adgroup_id' => $gid, 'status' => strtoupper(trim((string) ($r['status'] ?? '')))];
            $s['ad_by_name'][$gid . '|' . masterNorm($r['ad_name'] ?? '')] = (string) $r['id'];
        }
    }
    return $cache[$platform] = $s;
}

/** The project campaign ID for a row (by ID, else by saved name), or null when it's not in the project. */
function projectCampaignId(string $platform, ?string $id, ?string $name = null): ?string
{
    $s = projectStructure($platform);
    $id = trim((string) $id);
    if ($id !== '' && isset($s['campaigns'][$id])) {
        return $id;
    }
    $n = masterNorm($name);
    return ($n !== '' && isset($s['campaign_by_name'][$n])) ? $s['campaign_by_name'][$n] : null;
}

/** SQL expression: one key per person (last 10 digits of the mobile, else the lead id) — for COUNT(DISTINCT …). */
if (!defined('PQ_PERSON_KEY_SQL')) {
    define('PQ_PERSON_KEY_SQL', "COALESCE(NULLIF(RIGHT(REGEXP_REPLACE(COALESCE(mobile, ''), '[^0-9]', ''), 10), ''), CONCAT('id', id))");
}

/**
 * Google lead whose campaign is not one of this project's saved campaigns (or has no campaign at all)?
 * Such leads are counted as "Website / Direct" on the dashboards and reports, unless config sets
 * define('GOOGLE_UNMAPPED_TO_WEBSITE', false) — then only leads with no campaign at all are.
 */
function pqGoogleCampaignIsWebsite(?string $campaignId, ?string $campaignName): bool
{
    $id = trim((string) $campaignId);
    $name = trim((string) $campaignName);
    if (($id === '' && $name === '') || strtolower($name) === 'website') {
        return true;
    }
    if (defined('GOOGLE_UNMAPPED_TO_WEBSITE') && !GOOGLE_UNMAPPED_TO_WEBSITE) {
        return false;
    }
    return projectCampaignId('google', $id !== '' ? $id : null, $name) === null;
}

/**
 * SQL condition that keeps only leads of this project's campaign(s): the lead's campaign name is a
 * saved name (or one of $extraNames), its campaign ID column ($campaignIdCol) is a saved campaign ID,
 * or its ad ID belongs to a saved ad of that campaign.
 * $campaignId = null → every project campaign. Returns '1=0' when nothing is linked.
 */
function projectLeadCondition(mysqli $db, string $platform, ?string $campaignId, string $nameCol, string $adIdCol = '', array $extraNames = [], string $campaignIdCol = ''): string
{
    $s = projectStructure($platform);
    $ids = $campaignId === null ? array_keys($s['campaigns']) : (isset($s['campaigns'][$campaignId]) ? [$campaignId] : []);
    $ids = array_map('strval', $ids);
    if (!$ids) {
        return '1=0';
    }
    $names = $extraNames;
    foreach ($ids as $cid) {
        $names[] = $s['campaigns'][$cid];
    }
    $q = fn($v) => "'" . $db->real_escape_string((string) $v) . "'";
    $names = array_values(array_unique(array_filter(array_map(fn($n) => mb_strtolower(trim((string) $n)), $names), fn($n) => $n !== '')));
    $parts = [];
    if ($names) {
        $parts[] = "LOWER(TRIM(COALESCE({$nameCol}, ''))) IN (" . implode(',', array_map($q, $names)) . ')';
    }
    if ($campaignIdCol !== '') {
        $parts[] = "TRIM(COALESCE({$campaignIdCol}, '')) IN (" . implode(',', array_map($q, $ids)) . ')';
    }
    if ($adIdCol !== '') {
        $want = array_flip($ids);
        $adIds = [];
        foreach ($s['ads'] as $adId => $ad) {
            $gid = $ad['adgroup_id'];
            if (isset($s['adgroups'][$gid]) && isset($want[$s['adgroups'][$gid]['campaign_id']])) {
                $adIds[] = (string) $adId;
            }
        }
        if ($adIds) {
            $parts[] = "TRIM(COALESCE({$adIdCol}, '')) IN (" . implode(',', array_map($q, $adIds)) . ')';
        }
    }
    return $parts ? '(' . implode(' OR ', $parts) . ')' : '1=0';
}

function isProjectCampaign(string $platform, ?string $id, ?string $name = null): bool
{
    return projectCampaignId($platform, $id, $name) !== null;
}

/** The project ad set / ad group ID (by ID, else by saved name inside that campaign), or null. */
function projectAdgroupId(string $platform, string $campaignId, ?string $id, ?string $name = null): ?string
{
    $s = projectStructure($platform);
    $id = trim((string) $id);
    if ($id !== '' && isset($s['adgroups'][$id]) && $s['adgroups'][$id]['campaign_id'] === $campaignId) {
        return $id;
    }
    $k = $campaignId . '|' . masterNorm($name);
    return isset($s['adgroup_by_name'][$k]) ? $s['adgroup_by_name'][$k] : null;
}

/** The project ad ID (by ID, else by saved name inside that ad set), or null. */
function projectAdId(string $platform, string $adgroupId, ?string $id, ?string $name = null): ?string
{
    $s = projectStructure($platform);
    $id = trim((string) $id);
    if ($id !== '' && isset($s['ads'][$id]) && $s['ads'][$id]['adgroup_id'] === $adgroupId) {
        return $id;
    }
    $k = $adgroupId . '|' . masterNorm($name);
    return isset($s['ad_by_name'][$k]) ? $s['ad_by_name'][$k] : null;
}

/**
 * Keep only the project's campaigns and give them their saved (database) names.
 *
 * @param string   $idKey    row field with the platform campaign ID
 * @param string[] $nameKeys row fields holding the campaign name (all are set to the saved name)
 * @param callable|null $keep extra rows to keep as-is (e.g. Google's "Website" leads row)
 * @return array{0: array, 1: array} [kept rows, filter info for the dashboard banner]
 */
function applyProjectCampaignFilter(string $platform, array $rows, string $idKey = 'id', array $nameKeys = ['name'], ?callable $keep = null): array
{
    $s = projectStructure($platform);
    $kept = [];
    $extra = 0;          // rows kept by $keep (e.g. Google "Website / Direct") are not linked campaigns
    $hidden = [];        // unique hidden campaigns (an API row and a leads-only row of one campaign count once)
    $hiddenSpend = 0.0;
    foreach ($rows as $row) {
        if ($keep && $keep($row)) {
            $kept[] = $row;
            $extra++;
            continue;
        }
        $name = '';
        foreach ($nameKeys as $k) {
            if (!empty($row[$k])) {
                $name = (string) $row[$k];
                break;
            }
        }
        $cid = projectCampaignId($platform, (string) ($row[$idKey] ?? ''), $name);
        if ($cid !== null) {
            $row[$idKey] = $cid;
            if ($name !== '' && $name !== $s['campaigns'][$cid]) {
                $row['source_name'] = $row['source_name'] ?? $name;   // name used by the ad platform / leads
            }
            foreach ($nameKeys as $k) {
                $row[$k] = $s['campaigns'][$cid];   // the name saved in the database
            }
            $kept[] = $row;
        } elseif (trim((string) ($row[$idKey] ?? '')) !== '' || (float) ($row['spend'] ?? 0) > 0) {
            $hidden[masterNorm($name) !== '' ? 'n:' . masterNorm($name) : 'i:' . trim((string) ($row[$idKey] ?? ''))] = true;
            $hiddenSpend += (float) ($row['spend'] ?? 0);
        }
    }
    return [$kept, projectFilterInfo($platform, count($kept) - $extra, count($hidden), $hiddenSpend)];
}

function projectFilterInfo(string $platform, int $shown, int $hiddenCount, float $hiddenSpend): array
{
    $s = projectStructure($platform);
    return [
        'mode'          => 'campaigns_table',
        'platform'      => $platform,
        'configured'    => $s['configured'],
        'project_count' => $s['count'],
        'shown'         => $shown,
        'hidden_count'  => $hiddenCount,
        'hidden_spend'  => round($hiddenSpend, 2),
        'error'         => $s['error'],
    ];
}

/** Combine two filter infos (e.g. a first pass in a library and a second pass in the API). */
function mergeFilterInfo(array $a, array $b): array
{
    $b['hidden_count'] = (int) ($b['hidden_count'] ?? 0) + (int) ($a['hidden_count'] ?? 0);
    $b['hidden_spend'] = round((float) ($b['hidden_spend'] ?? 0) + (float) ($a['hidden_spend'] ?? 0), 2);
    return $b;
}

/* ======================================================================
 * Write
 * ====================================================================== */

/**
 * Insert / update campaigns, ad sets and ads for one platform.
 * Each list item: campaigns [id, name, status], adgroups [id, campaign_id, name, status], ads [id, adgroup_id, name, status].
 */
/* ======================================================================
 * Campaign type: performance (default) | awareness
 * ----------------------------------------------------------------------
 * campaigns.campaign_type, set by the execution team in the Sync window (⟳ Sync with Meta / Google).
 * The dashboards' tabs (All / Performance / Awareness) and Users & Roles → Campaign types decide which
 * campaigns are shown — see pqCampaignView() below.
 * ====================================================================== */

/** Does campaigns.campaign_type exist? $add = create it when missing (VARCHAR(20) DEFAULT 'performance'). */
function masterCampaignTypeColumn(mysqli $db, bool $add = false): bool
{
    static $has = null;
    if ($has === true) {
        return true;
    }
    try {
        $r = $db->query("SHOW COLUMNS FROM `campaigns` LIKE 'campaign_type'");
        $has = $r && $r->num_rows > 0;
        if (!$has && $add) {
            $has = (bool) $db->query("ALTER TABLE `campaigns` ADD COLUMN `campaign_type` VARCHAR(20) NOT NULL DEFAULT 'performance'");
        }
    } catch (Throwable $e) {
        error_log('[master_tables] campaign_type: ' . $e->getMessage());
        $has = false;
    }
    return (bool) $has;
}

/** Save campaign types: [campaign id => 'performance' | 'awareness'] (only campaigns of this platform in the project). */
function masterSetCampaignTypes(mysqli $db, string $platform, array $types): int
{
    if (!$types) {
        return 0;
    }
    masterEnsureTables($db);
    if (!masterCampaignTypeColumn($db, true)) {
        throw new RuntimeException('Could not add the campaign_type column to the campaigns table.');
    }
    $pc = $platform === 'meta' ? "LOWER(COALESCE(NULLIF(TRIM(platform), ''), 'meta')) = 'meta'" : "LOWER(TRIM(platform)) = '" . $db->real_escape_string($platform) . "'";
    $st = $db->prepare("UPDATE `campaigns` SET campaign_type = ? WHERE TRIM(campaign_id) = ? AND {$pc}");
    $n = 0;
    foreach ($types as $id => $type) {
        $id = masterClean((string) $id, 64);
        $type = $type === 'awareness' ? 'awareness' : 'performance';
        if ($id === '') {
            continue;
        }
        $st->bind_param('ss', $type, $id);
        $st->execute();
        $n += max(0, (int) $st->affected_rows);
    }
    $st->close();
    masterForgetCache();
    return $n;
}

/* ======================================================================
 * Campaign view: All | Performance | Awareness (the tabs on the dashboards)
 * ----------------------------------------------------------------------
 *   all          every campaign
 *   performance  only performance campaigns (everything not tagged Awareness)
 *   awareness    only campaigns tagged Awareness in ⟳ Sync (and the awareness share of manual platforms)
 * The viewer's tab is a cookie (pq_view), so every dashboard, report and API call follows it; ?view= wins.
 * Users & Roles → Campaign types can take Performance or Awareness away from a role: those campaigns are then
 * left out everywhere, whatever the tab (pqAllowedCampaignTypes in app/Core/access.php).
 * ====================================================================== */

/** Types this viewer may see (both when the access layer is not loaded, e.g. a CLI script). */
function pqViewTypes(): array
{
    return function_exists('pqAllowedCampaignTypes') ? pqAllowedCampaignTypes() : ['performance', 'awareness'];
}

/** The tabs this viewer gets: ['all', 'performance', 'awareness'], or just the one type the role may see. */
function pqViewTabs(): array
{
    $t = pqViewTypes();
    return count($t) > 1 ? array_merge(['all'], $t) : $t;
}

/** The view of this request: ?view=, else the viewer's tab (cookie pq_view), limited to what the role may see. */
function pqCampaignView(): string
{
    $tabs = pqViewTabs();
    $v = strtolower((string) ($_GET['view'] ?? ''));
    if ($v === '' && isset($_GET['awareness']) && in_array((string) $_GET['awareness'], ['0', '1'], true)) {
        $v = $_GET['awareness'] === '1' ? 'all' : 'performance';   // links from before the tabs
    }
    if ($v === '') {
        $v = strtolower((string) ($_COOKIE['pq_view'] ?? 'all'));
    }
    return in_array($v, $tabs, true) ? $v : $tabs[0];
}

/** Does this view show campaigns of this type? */
function pqViewShows(string $type, ?string $view = null): bool
{
    $view ??= pqCampaignView();
    $type = $type === 'awareness' ? 'awareness' : 'performance';
    return $view === 'all' ? in_array($type, pqViewTypes(), true) : $view === $type;
}

/** performance | awareness of a project campaign (by ID, else name). Campaigns not in the project count as performance. */
function pqCampaignType(string $platform, ?string $id, ?string $name = null): string
{
    $s = projectStructure($platform);
    if (empty($s['awareness'])) {
        return 'performance';
    }
    $cid = projectCampaignId($platform, (string) $id, $name);
    return $cid !== null && isset($s['awareness'][$cid]) ? 'awareness' : 'performance';
}

/** Kept for older callers: is awareness spend part of this request's numbers? */
function pqAwarenessIncluded(): bool
{
    return pqViewShows('awareness');
}

/** Empty totals of one campaign type. */
function pqViewTotals(): array
{
    return ['count' => 0, 'spend' => 0.0, 'impressions' => 0, 'clicks' => 0, 'leads' => 0, 'qualified' => 0, 'walkins' => 0, 'ids' => []];
}

/**
 * Keeps the campaign rows of the current view (and that the role may see); every row gets campaign_type.
 * @return array{0: array, 1: array} [rows, info: view, tabs, tagged, performance{…}, awareness{…}]
 *   performance / awareness = totals of all rows of that type (before the view), for the tab badges;
 *   a type the role may not see is reported as null.
 */
function pqApplyView(string $platform, array $rows, string $idKey = 'id', array $nameKeys = ['name']): array
{
    $view = pqCampaignView();
    $s = projectStructure($platform);
    $tot = ['performance' => pqViewTotals(), 'awareness' => pqViewTotals()];
    $out = [];
    foreach ($rows as $r) {
        $name = '';
        foreach ($nameKeys as $k) {
            if (!empty($r[$k])) {
                $name = (string) $r[$k];
                break;
            }
        }
        $cid = empty($s['awareness']) ? null : projectCampaignId($platform, (string) ($r[$idKey] ?? ''), $name);
        $type = $cid !== null && isset($s['awareness'][$cid]) ? 'awareness' : 'performance';
        $r['campaign_type'] = $type;
        $t = &$tot[$type];
        $t['ids'][] = $cid ?? (string) ($r[$idKey] ?? $name);
        $t['spend'] += (float) ($r['spend'] ?? 0);
        foreach (['impressions', 'clicks', 'leads', 'qualified', 'walkins'] as $k) {
            $t[$k] += (int) ($r[$k] ?? 0);
        }
        unset($t);
        if (pqViewShows($type, $view)) {
            $out[] = $r;
        }
    }
    $info = ['view' => $view, 'tabs' => pqViewTabs(), 'tagged' => count($s['awareness'] ?? [])];
    foreach ($tot as $type => $t) {
        $t['ids'] = array_values(array_unique(array_filter($t['ids'], fn($x) => $x !== '')));
        $t['count'] = count($t['ids']);
        $t['spend'] = round($t['spend'], 2);
        unset($t['ids']);
        $info[$type] = in_array($type, pqViewTypes(), true) ? $t : null;
    }
    // older pages read these
    $info['included'] = pqViewShows('awareness', $view);
    $info['count'] = (int) ($info['awareness']['count'] ?? 0);
    $info['spend'] = (float) ($info['awareness']['spend'] ?? 0);
    return [$out, $info];
}

/** Old name (Meta / Google APIs before the tabs). */
function pqApplyAwareness(string $platform, array $rows, string $idKey = 'id', array $nameKeys = ['name']): array
{
    return pqApplyView($platform, $rows, $idKey, $nameKeys);
}

/** Totals of a list of campaign rows (spend, impressions, clicks, reach, leads, qualified, walkins + the rates). */
function pqSumRows(array $rows): array
{
    $t = ['spend' => 0.0, 'impressions' => 0, 'clicks' => 0, 'reach' => 0, 'leads' => 0, 'qualified' => 0, 'walkins' => 0];
    foreach ($rows as $r) {
        $t['spend'] += (float) ($r['spend'] ?? 0);
        foreach (['impressions', 'clicks', 'reach', 'leads', 'qualified', 'walkins'] as $k) {
            $t[$k] += (int) ($r[$k] ?? 0);
        }
    }
    $t['spend'] = round($t['spend'], 2);
    $t['ctr'] = $t['impressions'] > 0 ? round($t['clicks'] / $t['impressions'] * 100, 2) : 0.0;
    $t['cpm'] = $t['impressions'] > 0 ? round($t['spend'] / $t['impressions'] * 1000, 2) : 0.0;
    $t['frequency'] = $t['reach'] > 0 ? round($t['impressions'] / $t['reach'], 2) : 0.0;
    $t['cpl'] = $t['leads'] > 0 ? round($t['spend'] / $t['leads'], 2) : 0.0;
    $t['cpsv'] = $t['walkins'] > 0 ? round($t['spend'] / $t['walkins'], 2) : 0.0;
    $t['lead_rate'] = $t['clicks'] > 0 ? round($t['leads'] / $t['clicks'] * 100, 2) : 0.0;
    return $t;
}

/** Project campaign IDs of a platform the current view shows (for reports, creatives, keywords). */
function pqViewCampaignIds(string $platform, ?string $view = null): array
{
    $s = projectStructure($platform);
    $out = [];
    foreach (array_keys($s['campaigns']) as $id) {
        if (pqViewShows(isset($s['awareness'][$id]) ? 'awareness' : 'performance', $view)) {
            $out[] = (string) $id;
        }
    }
    return $out;
}

function masterUpsert(mysqli $db, string $platform, array $campaigns, array $adgroups = [], array $ads = []): array
{
    masterEnsureTables($db);
    $done = ['campaigns' => 0, 'adgroups' => 0, 'ads' => 0];

    $upC = $db->prepare('INSERT INTO `campaigns` (campaign_id, campaign_name, status, platform) VALUES (?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE campaign_name = VALUES(campaign_name), status = VALUES(status), platform = VALUES(platform)');
    $upG = $db->prepare('INSERT INTO `adgroups` (adgroup_id, campaign_id, adgroup_name, status, platform) VALUES (?, ?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE campaign_id = VALUES(campaign_id), adgroup_name = VALUES(adgroup_name), status = VALUES(status), platform = VALUES(platform)');
    $upA = $db->prepare('INSERT INTO `ads` (ad_id, adgroup_id, ad_name, status, platform) VALUES (?, ?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE adgroup_id = VALUES(adgroup_id), ad_name = VALUES(ad_name), status = VALUES(status), platform = VALUES(platform)');
    if (!$upC || !$upG || !$upA) {
        throw new RuntimeException('Could not prepare master-table writes: ' . $db->error);
    }

    $db->begin_transaction();
    try {
        foreach ($campaigns as $c) {
            [$id, $name, $status] = [masterClean($c['id'] ?? '', 64), masterClean($c['name'] ?? ''), masterClean($c['status'] ?? '', 50)];
            if ($id === '') continue;
            $name = $name !== '' ? $name : $id;
            $upC->bind_param('ssss', $id, $name, $status, $platform);
            $upC->execute();
            $done['campaigns']++;
        }
        foreach ($adgroups as $g) {
            [$id, $cid, $name, $status] = [masterClean($g['id'] ?? '', 64), masterClean($g['campaign_id'] ?? '', 64), masterClean($g['name'] ?? ''), masterClean($g['status'] ?? '', 50)];
            if ($id === '' || $cid === '') continue;
            $name = $name !== '' ? $name : $id;
            $upG->bind_param('sssss', $id, $cid, $name, $status, $platform);
            $upG->execute();
            $done['adgroups']++;
        }
        foreach ($ads as $a) {
            [$id, $gid, $name, $status] = [masterClean($a['id'] ?? '', 64), masterClean($a['adgroup_id'] ?? '', 64), masterClean($a['name'] ?? ''), masterClean($a['status'] ?? '', 50)];
            if ($id === '' || $gid === '') continue;
            $name = $name !== '' ? $name : $id;
            $upA->bind_param('sssss', $id, $gid, $name, $status, $platform);
            $upA->execute();
            $done['ads']++;
        }
        $db->commit();
    } catch (Throwable $e) {
        $db->rollback();
        throw $e;
    } finally {
        $upC->close();
        $upG->close();
        $upA->close();
        masterForgetCache();
    }
    return $done;
}

/** Remove campaigns (and their ad sets / ads) of one platform from the project. Returns campaigns removed. */
function masterRemoveCampaigns(mysqli $db, string $platform, array $campaignIds): int
{
    $ids = array_values(array_filter(array_unique(array_map(fn($v) => masterClean($v, 64), $campaignIds)), fn($i) => $i !== ''));
    if (!$ids || !masterTableExists($db, 'campaigns')) {
        return 0;
    }
    $in = implode(',', array_map(fn($i) => "'" . $db->real_escape_string($i) . "'", $ids));
    $p = "'" . $db->real_escape_string($platform) . "'";
    $cnt = $db->query("SELECT COUNT(*) AS n FROM `campaigns` WHERE platform = {$p} AND campaign_id IN ({$in})");
    $removed = $cnt ? (int) ($cnt->fetch_assoc()['n'] ?? 0) : 0;

    $db->begin_transaction();
    try {
        if (masterTableExists($db, 'ads') && masterTableExists($db, 'adgroups')) {
            $db->query("DELETE FROM `ads` WHERE platform = {$p} AND adgroup_id IN (SELECT adgroup_id FROM `adgroups` WHERE platform = {$p} AND campaign_id IN ({$in}))");
            $db->query("DELETE FROM `adgroups` WHERE platform = {$p} AND campaign_id IN ({$in})");
        }
        $db->query("DELETE FROM `campaigns` WHERE platform = {$p} AND campaign_id IN ({$in})");
        $db->commit();
    } catch (Throwable $e) {
        $db->rollback();
        throw $e;
    } finally {
        masterForgetCache();
    }
    return $removed;
}

/** Drop cached dashboard data (all platforms) so changes show immediately. */
function masterClearDashboardCache(): void
{
    foreach (['meta_*.json', 'google_*.json', 'taboola_*.json', 'portfolio_*.json'] as $pattern) {
        foreach (glob(CACHE_PATH . '/' . $pattern) ?: [] as $file) {
            if (is_file($file)) {
                @unlink($file);
            }
        }
    }
}

/**
 * Leads per campaign in this project's lead table(s), by a column (or SQL expression) holding
 * the campaign name or ID. Used by the Sync windows to suggest campaigns.
 * @return array<string,int> normalised value => leads
 */
function masterLeadCounts(string $columnExpr, string $where = '1=1'): array
{
    $counts = [];
    foreach (leadDbs('all') as $db) {
        $res = $db->query("SELECT {$columnExpr} AS v, COUNT(*) AS n FROM `lead`
                            WHERE ({$where}) AND {$columnExpr} IS NOT NULL AND TRIM({$columnExpr}) <> ''
                            GROUP BY {$columnExpr}");
        while ($res && ($row = $res->fetch_assoc())) {
            $k = masterNorm((string) $row['v']);
            $counts[$k] = ($counts[$k] ?? 0) + (int) $row['n'];
        }
    }
    return $counts;
}

/**
 * Drill-down: keep only the ad sets / ad groups saved for this campaign, with their saved names.
 * @return array{0: array, 1: array} [kept rows, info: synced (does the campaign have any saved ad sets), hidden]
 */
function filterProjectAdgroups(string $platform, string $campaignId, array $rows, string $idKey, string $nameKey): array
{
    $s = projectStructure($platform);
    $kept = [];
    $hidden = 0;
    foreach ($rows as $row) {
        $gid = projectAdgroupId($platform, $campaignId, (string) ($row[$idKey] ?? ''), (string) ($row[$nameKey] ?? ''));
        if ($gid === null) {
            $hidden++;
            continue;
        }
        $row[$idKey] = $gid;
        $row[$nameKey] = $s['adgroups'][$gid]['name'];
        $kept[] = $row;
    }
    return [$kept, ['synced' => !empty($s['adgroups_by_campaign'][$campaignId]), 'hidden' => $hidden]];
}

/**
 * Drill-down: keep only the ads saved for this ad set, with their saved names.
 * @return array{0: array, 1: array} [kept rows, info: synced, hidden]
 */
function filterProjectAds(string $platform, string $adgroupId, array $rows, string $idKey, string $nameKey): array
{
    $s = projectStructure($platform);
    $kept = [];
    $hidden = 0;
    $hasAds = false;
    foreach ($s['ads'] as $a) {
        if ($a['adgroup_id'] === $adgroupId) { $hasAds = true; break; }
    }
    foreach ($rows as $row) {
        $aid = projectAdId($platform, $adgroupId, (string) ($row[$idKey] ?? ''), (string) ($row[$nameKey] ?? ''));
        if ($aid === null) {
            $hidden++;
            continue;
        }
        $row[$idKey] = $aid;
        $row[$nameKey] = $s['ads'][$aid]['name'];
        $kept[] = $row;
    }
    return [$kept, ['synced' => $hasAds, 'hidden' => $hidden]];
}

/**
 * Ad-level rows (pivot exports): keep a row only when its campaign → ad set → ad chain is saved
 * for the project, and give all three their saved names.
 * $k maps logical fields to row keys: campaign_id, campaign_name, adgroup_id, adgroup_name, ad_id, ad_name.
 * @return array{0: array, 1: int} [kept rows, hidden rows]
 */
function filterProjectAdRows(string $platform, array $rows, array $k): array
{
    $s = projectStructure($platform);
    $kept = [];
    $hidden = 0;
    foreach ($rows as $row) {
        $cid = projectCampaignId($platform, (string) ($row[$k['campaign_id']] ?? ''), (string) ($row[$k['campaign_name']] ?? ''));
        $gid = $cid === null ? null : projectAdgroupId($platform, $cid, (string) ($row[$k['adgroup_id']] ?? ''), (string) ($row[$k['adgroup_name']] ?? ''));
        $aid = $gid === null ? null : projectAdId($platform, $gid, (string) ($row[$k['ad_id']] ?? ''), (string) ($row[$k['ad_name']] ?? ''));
        if ($aid === null) {
            $hidden++;
            continue;
        }
        $row[$k['campaign_id']] = $cid;
        $row[$k['campaign_name']] = $s['campaigns'][$cid];
        $row[$k['adgroup_id']] = $gid;
        $row[$k['adgroup_name']] = $s['adgroups'][$gid]['name'];
        $row[$k['ad_id']] = $aid;
        $row[$k['ad_name']] = $s['ads'][$aid]['name'];
        $kept[] = $row;
    }
    return [$kept, $hidden];
}

/* ======================================================================
 * Internal calls (portfolio PDF → googleapi.php / taboolaapi.php, also from cron)
 * ====================================================================== */

/** Secret for server-to-server calls, derived from config secrets (never sent to browsers). */
function pqInternalKey(): string
{
    $seed = (defined('META_ACCESS_TOKEN') ? (string) META_ACCESS_TOKEN : '')
        . '|' . (defined('GOOGLE_CLIENT_SECRET') ? (string) GOOGLE_CLIENT_SECRET : '')
        . '|' . (defined('TABOOLA_CLIENT_SECRET') ? (string) TABOOLA_CLIENT_SECRET : '')
        . '|' . (defined('APP_URL') ? (string) APP_URL : '');
    return hash_hmac('sha256', 'performiq-internal', $seed);
}

/** True when the request came from this server's own internal call (X-PQ-Internal header). */
function pqInternalRequest(): bool
{
    $h = (string) ($_SERVER['HTTP_X_PQ_INTERNAL'] ?? '');
    return $h !== '' && hash_equals(pqInternalKey(), $h);
}
