<?php
/**
 * app/Ads/creatives.php — Creatives & Insights for the execution team.
 *
 * Every Meta / Google ad of this project with its image or video, its spend and its CRM results (leads,
 * qualified leads, site visits — the same numbers as the dashboards and the PDF report: pfPeriod()),
 * the campaigns' daily / lifetime budgets, and "Insights & Actions": what to scale, what to pause and which
 * creatives to make more of. The advice comes from fixed rules (crRules) so the numbers are always right;
 * Groq (GROQ_API_KEY in config.php) only writes the wording. Without Groq the rules' own wording is used.
 *
 *   crAds($platform, $since, $until)          ads + campaigns (with budgets), this period and the one before
 *   crBudgets($platform, $campaignIds)        daily / lifetime budget per campaign (₹)
 *   crBudgetPm($platform, $campaignIds)       the same as ▥ Columns values (pm_daily_budget / pm_lifetime_budget)
 *   crInsights($platform, $since, $until)     findings from the rules
 *   crInsightsText($platform, $label, $f)     Groq wording (cached) or the rules' wording
 *   crThumbFile($platform, $id)               cached thumbnail on this server (downloaded the first time)
 *   crMedia($platform, $adId)                 images / video of one ad, fetched fresh (for the preview window)
 *
 * Settings: pq_settings key 'insights' (thresholds, edited on the page by a Super Admin).
 */

require_once __DIR__ . '/portfolio_data.php';          // pfPeriod, fetch_meta.php, master_tables.php, meta_sync.php
require_once __DIR__ . '/google_sync.php';             // googleSearch / googleAdsConfigured
require_once dirname(__DIR__) . '/Leads/crm_sfdc.php'; // pqSettingGet / pqSettingPut

const CR_CACHE_TTL = 600;           // ads / budgets: 10 minutes (like the dashboards)
const CR_DETAILS_TTL = 21600;       // creative details (images, headlines): 6 hours
const CR_THUMB_TTL = 604800;        // thumbnails on this server: 7 days
const CR_TEXT_TTL = 86400;          // Groq wording for the same findings: 1 day

/** Default thresholds (Settings → saved in pq_settings 'insights'). */
const CR_RULES = [
    'min_ql_winner'      => ['Qualified leads before an ad can be a winner', 3, 1, 50],
    'winner_cpql_below'  => ['Winner: CPQL this % below the benchmark', 20, 0, 90],
    'min_leads'          => ['Leads before CPL / CTR rules apply', 5, 1, 100],
    'good_cpl_below'     => ['Good CPL: this % below the benchmark', 20, 0, 90],
    'junk_min_leads'     => ['Cheap-but-junk: at least this many leads', 8, 1, 200],
    'junk_ql_rate_below' => ['Cheap-but-junk: qualified rate under this %', 10, 0, 100],
    'losing_spend_x'     => ['Losing: spent this many × the benchmark CPQL with no qualified lead', 2, 0.5, 20],
    'fatigue_frequency'  => ['Fatigue: Meta frequency at least', 3, 1, 20],
    'fatigue_ctr_drop'   => ['Fatigue: CTR down this % vs the period before', 30, 5, 90],
    'cpl_change'         => ['CPL better / worse by this % vs the period before', 30, 5, 200],
    'underspend_pct'     => ['Under-spending: average daily spend under this % of the daily budget', 60, 5, 100],
];

/* ======================================================================
 * Small helpers
 * ====================================================================== */

function crCacheDir(): string
{
    $d = CACHE_PATH . '/creatives';
    if (!is_dir($d)) {
        @mkdir($d, 0775, true);
    }
    return $d;
}

function crCacheGet(string $key, int $ttl): ?array
{
    $f = crCacheDir() . '/' . $key . '.json';
    if (is_file($f) && filemtime($f) > time() - $ttl) {
        $j = json_decode((string) @file_get_contents($f), true);
        if (is_array($j)) {
            return $j;
        }
    }
    return null;
}

function crCachePut(string $key, array $v): void
{
    @file_put_contents(crCacheDir() . '/' . $key . '.json', json_encode($v, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PARTIAL_OUTPUT_ON_ERROR), LOCK_EX);
}

function crDiv($a, $b, float $m = 1): ?float
{
    return ($b ?? 0) > 0 ? round((float) $a / (float) $b * $m, 2) : null;
}

function crMoney(?float $v): string
{
    if ($v === null) {
        return '—';
    }
    $s = number_format(abs($v), 0, '.', '');
    if (strlen($s) > 3) {
        $s = preg_replace('/\B(?=(\d{2})+(?!\d))/', ',', substr($s, 0, -3)) . ',' . substr($s, -3);
    }
    return ($v < 0 ? '-' : '') . '₹' . $s;
}

function crPlatformName(string $p): string
{
    return $p === 'google' ? 'Google' : 'Meta';
}

/** The same number of days just before since..until. */
function crPrevRange(string $since, string $until): array
{
    $s = new DateTimeImmutable($since);
    $u = new DateTimeImmutable($until);
    $days = $s->diff($u)->days + 1;
    return [$s->modify("-{$days} days")->format('Y-m-d'), $s->modify('-1 day')->format('Y-m-d')];
}

function crRules(): array
{
    $saved = [];
    try {
        $db = leadDb(appDbKey());
        if ($db) {
            $saved = pqSettingGet($db, 'insights') ?? [];
        }
    } catch (Throwable $e) {
        error_log('[creatives] settings: ' . $e->getMessage());
    }
    $out = [];
    foreach (CR_RULES as $k => [, $def, $min, $max]) {
        $v = $saved['rules'][$k] ?? $def;
        $out[$k] = is_numeric($v) ? max($min, min($max, (float) $v)) : $def;
    }
    return $out;
}

/** Saves thresholds (Super Admin). Unknown keys are ignored; values are clamped. */
function crSaveRules(array $in, string $user): array
{
    $db = leadDb(appDbKey());
    if (!$db) {
        throw new RuntimeException('The main database is not reachable.');
    }
    $rules = [];
    foreach (CR_RULES as $k => [$label, $def, $min, $max]) {
        $v = $in[$k] ?? $def;
        if (!is_numeric($v)) {
            throw new InvalidArgumentException($label . ': enter a number.');
        }
        $rules[$k] = max($min, min($max, (float) $v));
    }
    pqSettingPut($db, 'insights', ['rules' => $rules], $user);
    return $rules;
}

/* ======================================================================
 * Period numbers (pfPeriod, cached)
 * ====================================================================== */

/** pfPeriod() for a range: raw tree + Meta frequencies + warnings. Cached 10 minutes. */
function crPeriod(string $since, string $until): array
{
    $key = 'period_' . md5($since . '|' . $until . '|' . appDbKey() . '|' . pqCampaignView());   // + All / Performance / Awareness tab
    $c = crCacheGet($key, CR_CACHE_TTL);
    if ($c !== null) {
        return $c;
    }
    $conns = pfLeadConns();
    if (!$conns) {
        throw new RuntimeException('No lead database is reachable.');
    }
    $r = pfPeriod($since, $until, $conns, true);
    $out = ['tree' => $r['tree'] ?? [], 'meta_freq' => $r['meta_freq'] ?? [], 'warnings' => $r['warnings'] ?? []];
    crCachePut($key, $out);
    return $out;
}

/* ======================================================================
 * Budgets
 * ====================================================================== */

/**
 * Daily / lifetime budget per campaign, in ₹ (Meta sends the account currency's smallest unit: paise).
 * Meta: the campaign's budget (Advantage campaign budget), else the sum of its ad sets' budgets.
 * Google: the campaign budget (daily, or a total for a custom period).
 * @return array<string, array{daily: ?float, lifetime: ?float, level: string, status: string}>
 */
function crBudgets(string $platform, array $campaignIds): array
{
    $ids = array_values(array_unique(array_filter(array_map(fn($v) => preg_replace('/\D+/', '', (string) $v), $campaignIds))));
    if (!$ids) {
        return [];
    }
    sort($ids);
    $key = 'budgets_' . $platform . '_' . md5(implode(',', $ids));
    $c = crCacheGet($key, CR_CACHE_TTL);
    if ($c !== null) {
        return $c;
    }
    $out = [];
    try {
        $out = $platform === 'google' ? crGoogleBudgets($ids) : crMetaBudgets($ids);
    } catch (Throwable $e) {
        error_log('[creatives] budgets ' . $platform . ': ' . $e->getMessage());
        return [];   // not cached: tried again next time
    }
    crCachePut($key, $out);
    return $out;
}

function crMetaBudgets(array $ids): array
{
    $out = [];
    foreach (array_chunk($ids, 40) as $chunk) {
        $res = metaGraphGet('', [
            'ids' => implode(',', $chunk),
            'fields' => 'daily_budget,lifetime_budget,effective_status,adsets.limit(200){daily_budget,lifetime_budget,effective_status}',
        ]);
        foreach ($chunk as $id) {
            $c = $res[$id] ?? null;
            if (!is_array($c)) {
                continue;
            }
            $daily = isset($c['daily_budget']) && (float) $c['daily_budget'] > 0 ? (float) $c['daily_budget'] / 100 : null;
            $life = isset($c['lifetime_budget']) && (float) $c['lifetime_budget'] > 0 ? (float) $c['lifetime_budget'] / 100 : null;
            $level = 'campaign';
            if ($daily === null && $life === null) {
                // budgets on the ad sets: add up the active ones (all of them when none is active)
                $sets = (array) ($c['adsets']['data'] ?? []);
                $active = array_filter($sets, fn($a) => strtoupper((string) ($a['effective_status'] ?? '')) === 'ACTIVE');
                $use = $active ?: array_filter($sets, fn($a) => !in_array(strtoupper((string) ($a['effective_status'] ?? '')), ['DELETED', 'ARCHIVED'], true));
                foreach ($use as $a) {
                    if ((float) ($a['daily_budget'] ?? 0) > 0) {
                        $daily = ($daily ?? 0) + (float) $a['daily_budget'] / 100;
                    }
                    if ((float) ($a['lifetime_budget'] ?? 0) > 0) {
                        $life = ($life ?? 0) + (float) $a['lifetime_budget'] / 100;
                    }
                }
                $level = 'adset';
            }
            $out[$id] = ['daily' => $daily, 'lifetime' => $life, 'level' => $level, 'status' => strtoupper((string) ($c['effective_status'] ?? ''))];
        }
    }
    return $out;
}

function crGoogleBudgets(array $ids): array
{
    if (!googleAdsConfigured()) {
        return [];
    }
    $out = [];
    foreach (array_chunk($ids, 500) as $chunk) {
        $rows = googleSearch('SELECT campaign.id, campaign.status, campaign_budget.amount_micros, campaign_budget.total_amount_micros, campaign_budget.period, campaign_budget.explicitly_shared'
            . ' FROM campaign WHERE campaign.id IN (' . implode(',', $chunk) . ')');
        foreach ($rows as $r) {
            $id = (string) ($r['campaign']['id'] ?? '');
            if ($id === '') {
                continue;
            }
            $b = $r['campaignBudget'] ?? [];
            $amount = isset($b['amountMicros']) ? (float) $b['amountMicros'] / 1e6 : null;
            $total = isset($b['totalAmountMicros']) ? (float) $b['totalAmountMicros'] / 1e6 : null;
            $period = strtoupper((string) ($b['period'] ?? 'DAILY'));
            $out[$id] = [
                'daily' => $period === 'DAILY' && $amount > 0 ? $amount : null,
                'lifetime' => $total > 0 ? $total : ($period !== 'DAILY' && $amount > 0 ? $amount : null),
                'level' => !empty($b['explicitlyShared']) ? 'shared' : 'campaign',
                'status' => strtoupper((string) ($r['campaign']['status'] ?? '')),
            ];
        }
    }
    return $out;
}

/** Budgets as ▥ Columns values for the Meta / Google campaign tables. */
function crBudgetPm(string $platform, array $campaignIds): array
{
    $pm = [];
    foreach (crBudgets($platform, $campaignIds) as $id => $b) {
        if ($b['daily'] !== null) {
            $pm[$id]['pm_daily_budget'] = round($b['daily'], 2);
        }
        if ($b['lifetime'] !== null) {
            $pm[$id]['pm_lifetime_budget'] = round($b['lifetime'], 2);
        }
    }
    return $pm;
}

/* ======================================================================
 * Creative details (images, videos, text)
 * ====================================================================== */

/** Remote image URL for a thumbnail id ("<adId>" or "a<assetId>"), saved so crThumbFile() can download it. */
function crThumbRegister(string $platform, string $id, $urls): ?string
{
    // $urls: one URL, or a list (the first that downloads is used; the rest are fall-backs)
    $list = array_values(array_unique(array_filter(array_map(fn($u) => trim((string) $u), is_array($urls) ? $urls : [$urls]),
        fn($u) => $u !== '' && preg_match('#^https://#i', $u))));
    if (!$list) {
        return null;
    }
    $url = $list[0];
    $alts = array_slice($list, 1, 5);
    $file = crCacheDir() . '/thumbs_' . $platform . '.json';
    $map = is_file($file) ? (json_decode((string) @file_get_contents($file), true) ?: []) : [];
    if (($map[$id] ?? '') !== $url || ($map['~' . $id] ?? []) !== $alts) {
        $map[$id] = $url;
        if ($alts) {
            $map['~' . $id] = $alts;
        } else {
            unset($map['~' . $id]);
        }
        @file_put_contents($file, json_encode($map, JSON_UNESCAPED_SLASHES), LOCK_EX);
    }
    // the URL also travels in the link (signed), so pictures work even when the cache folder can't be written
    return 'creatives_api.php?action=thumb&platform=' . $platform . '&id=' . rawurlencode($id) . '&v=' . substr(md5($url), 0, 8)
        . '&u=' . rtrim(strtr(base64_encode($url), '+/', '-_'), '=') . '&s=' . crThumbSig($platform, $id, $url);
}

function crThumbSig(string $platform, string $id, string $url): string
{
    return substr(hash_hmac('sha256', $platform . '|' . $id . '|' . $url, pqRefKey()), 0, 20);
}

/** The picture URL carried in a thumbnail link (?u=…&s=…), when its signature is right. */
function crThumbUrlFromLink(string $platform, string $id, string $u, string $sig): string
{
    $url = (string) base64_decode(strtr($u, '-_', '+/'), true);
    return ($url !== '' && preg_match('#^https://#i', $url) && hash_equals(crThumbSig($platform, $id, $url), $sig)) ? $url : '';
}

/**
 * Details of Meta ads: name, status, preview link, creative type, image / thumbnail, text.
 * @return array<string, array>
 */
function crMetaDetails(array $adIds): array
{
    $out = [];
    foreach (array_chunk(array_values(array_unique($adIds)), 40) as $chunk) {
        $crFields = '{id,object_type,thumbnail_url,image_url,video_id,title,body,call_to_action_type,object_story_spec,asset_feed_spec}';
        $res = null;
        // larger thumbnails first (480 px); plain creative fields if Meta refuses the size parameters
        foreach (['creative.thumbnail_width(480).thumbnail_height(480)' . $crFields, 'creative' . $crFields] as $cf) {
            try {
                $res = metaGraphGet('', ['ids' => implode(',', $chunk), 'fields' => 'name,account_id,effective_status,preview_shareable_link,' . $cf]);
                break;
            } catch (Throwable $e) {
                error_log('[creatives] Meta details: ' . $e->getMessage());
            }
        }
        if ($res === null) {
            continue;
        }
        foreach ($chunk as $id) {
            $a = $res[$id] ?? null;
            if (!is_array($a)) {
                continue;
            }
            $cr = (array) ($a['creative'] ?? []);
            $spec = (array) ($cr['object_story_spec'] ?? []);
            $feed = (array) ($cr['asset_feed_spec'] ?? []);
            $videoId = (string) ($cr['video_id'] ?? ($spec['video_data']['video_id'] ?? ''));
            $type = 'image';
            $ot = strtoupper((string) ($cr['object_type'] ?? ''));
            if ($videoId !== '' || $ot === 'VIDEO' || !empty($feed['videos'])) {
                $type = 'video';
            } elseif (!empty($spec['link_data']['child_attachments']) || count((array) ($feed['images'] ?? [])) > 1) {
                $type = count((array) ($feed['images'] ?? [])) > 1 ? 'dynamic' : 'carousel';
            }
            $body = (string) ($cr['body'] ?? ($spec['link_data']['message'] ?? ($spec['video_data']['message'] ?? ($feed['bodies'][0]['text'] ?? ''))));
            $title = (string) ($cr['title'] ?? ($spec['link_data']['name'] ?? ($spec['video_data']['title'] ?? ($feed['titles'][0]['text'] ?? ''))));
            // multi-asset (dynamic / Advantage+ creative) and carousel: every image and video of the ad
            $feedImgs = [];
            foreach ((array) ($feed['images'] ?? []) as $im) {
                $feedImgs[] = ['url' => (string) ($im['url'] ?? ''), 'hash' => (string) ($im['hash'] ?? '')];
            }
            foreach ((array) ($spec['link_data']['child_attachments'] ?? []) as $ca) {
                $feedImgs[] = ['url' => (string) ($ca['picture'] ?? ''), 'hash' => (string) ($ca['image_hash'] ?? '')];
            }
            if (!empty($spec['link_data']['image_hash']) && empty($spec['link_data']['picture'])) {
                $feedImgs[] = ['url' => '', 'hash' => (string) $spec['link_data']['image_hash']];
            }
            $feedVids = [];
            foreach ((array) ($feed['videos'] ?? []) as $v) {
                if (!empty($v['video_id'])) {
                    $feedVids[] = ['video_id' => (string) $v['video_id'], 'thumb' => (string) ($v['thumbnail_url'] ?? '')];
                }
            }
            if ($videoId === '' && $feedVids) {
                $videoId = $feedVids[0]['video_id'];
            }
            $img = (string) ($cr['image_url'] ?? ($spec['link_data']['picture'] ?? ''));
            if ($img === '' && $type !== 'video') {
                foreach ($feedImgs as $fi) {
                    if ($fi['url'] !== '') {
                        $img = $fi['url'];
                        break;
                    }
                }
            }
            $thumb = (string) ($cr['thumbnail_url'] ?? ($feedVids[0]['thumb'] ?? ''));
            $first = $img !== '' && $type !== 'video' ? $img : ($thumb !== '' ? $thumb : $img);
            $out[$id] = [
                'name' => (string) ($a['name'] ?? ''),
                'status' => strtoupper((string) ($a['effective_status'] ?? '')),
                'type' => $type,
                'thumb_src' => $first,
                // other pictures of the same ad, tried when the first can't be fetched
                'thumb_alts' => array_values(array_diff(array_unique(array_filter(array_merge([$thumb, (string) ($cr['image_url'] ?? '')], array_column($feedVids, 'thumb')))), [$first])),
                'title' => mb_substr($title, 0, 200),
                'body' => mb_substr($body, 0, 400),
                'cta' => (string) ($cr['call_to_action_type'] ?? ''),
                'preview_url' => (string) ($a['preview_shareable_link'] ?? ''),
                'video_id' => $videoId,
                'assets' => count((array) ($feed['images'] ?? [])) + count((array) ($feed['videos'] ?? [])),
                'account_id' => preg_replace('/\D+/', '', (string) ($a['account_id'] ?? '')),
                'images' => array_slice($feedImgs, 0, 12),
                'video_ids' => array_slice(array_column($feedVids, 'video_id'), 0, 6),
            ];
        }
    }
    // images given only by hash: ask the ad account for their URLs
    $want = [];
    foreach ($out as $id => $d) {
        foreach ($d['images'] as $im) {
            if ($im['url'] === '' && $im['hash'] !== '' && $d['account_id'] !== '') {
                $want[$d['account_id']][$im['hash']] = true;
            }
        }
    }
    $byHash = [];
    foreach ($want as $acc => $hashes) {
        foreach (array_chunk(array_keys($hashes), 50) as $hc) {
            try {
                $r = metaGraphGet('act_' . $acc . '/adimages', ['hashes' => json_encode($hc), 'fields' => 'hash,url,permalink_url']);
                foreach ((array) ($r['data'] ?? []) as $im) {
                    $byHash[(string) ($im['hash'] ?? '')] = (string) ($im['url'] ?? ($im['permalink_url'] ?? ''));
                }
            } catch (Throwable $e) {
                error_log('[creatives] Meta ad images: ' . $e->getMessage());
            }
        }
    }
    foreach ($out as $id => &$d) {
        foreach ($d['images'] as &$im) {
            if ($im['url'] === '' && isset($byHash[$im['hash']])) {
                $im['url'] = $byHash[$im['hash']];
            }
        }
        unset($im);
        $d['images'] = array_values(array_filter(array_column($d['images'], 'url')));
        if (($d['thumb_src'] ?? '') === '' && $d['images']) {
            $d['thumb_src'] = $d['images'][0];
        }
        $d['thumb_alts'] = array_values(array_diff(array_unique(array_merge($d['thumb_alts'], $d['images'])), [$d['thumb_src']]));
    }
    unset($d);
    return $out;
}

/** GAQL with fields that may not exist in this API version: a field Google rejects is dropped and the query retried. */
function crGoogleFlexSearch(array $fields, string $from, string $where): array
{
    for ($i = 0; $i < 8 && $fields; $i++) {
        try {
            return googleSearch('SELECT ' . implode(', ', $fields) . " FROM {$from} WHERE {$where}");
        } catch (RuntimeException $e) {
            $bad = function_exists('pmFieldsInError') ? pmFieldsInError($e->getMessage(), $fields) : [];
            if (!$bad) {
                throw $e;
            }
            error_log('[creatives] Google rejected ' . implode(', ', $bad) . ' — retrying without');
            $fields = array_values(array_diff($fields, $bad));
        }
    }
    return [];
}

/** Details of Google ads: type, status, image / YouTube video, headlines and descriptions. */
function crGoogleDetails(array $adIds): array
{
    $ids = array_values(array_unique(array_filter(array_map(fn($v) => preg_replace('/\D+/', '', (string) $v), $adIds))));
    if (!$ids || !googleAdsConfigured()) {
        return [];
    }
    $fields = [
        'ad_group_ad.ad.id', 'ad_group_ad.ad.type', 'ad_group_ad.status', 'ad_group_ad.ad.final_urls',
        'ad_group_ad.ad.responsive_search_ad.headlines', 'ad_group_ad.ad.responsive_search_ad.descriptions',
        'ad_group_ad.ad.responsive_display_ad.marketing_images', 'ad_group_ad.ad.responsive_display_ad.square_marketing_images',
        'ad_group_ad.ad.responsive_display_ad.headlines', 'ad_group_ad.ad.responsive_display_ad.descriptions',
        'ad_group_ad.ad.responsive_display_ad.youtube_videos',
        'ad_group_ad.ad.image_ad.image_url',
        'ad_group_ad.ad.video_ad.video.asset',
        'ad_group_ad.ad.video_responsive_ad.videos', 'ad_group_ad.ad.video_responsive_ad.headlines',
        'ad_group_ad.ad.demand_gen_multi_asset_ad.marketing_images', 'ad_group_ad.ad.demand_gen_multi_asset_ad.square_marketing_images',
        'ad_group_ad.ad.demand_gen_multi_asset_ad.portrait_marketing_images', 'ad_group_ad.ad.demand_gen_multi_asset_ad.headlines',
        'ad_group_ad.ad.demand_gen_multi_asset_ad.descriptions',
        'ad_group_ad.ad.demand_gen_video_responsive_ad.videos', 'ad_group_ad.ad.demand_gen_video_responsive_ad.headlines',
    ];
    $rows = [];
    foreach (array_chunk($ids, 400) as $chunk) {
        try {
            array_push($rows, ...crGoogleFlexSearch($fields, 'ad_group_ad', 'ad_group_ad.ad.id IN (' . implode(',', $chunk) . ')'));
        } catch (Throwable $e) {
            error_log('[creatives] Google details: ' . $e->getMessage());
        }
    }
    $texts = fn($list) => array_values(array_filter(array_map(fn($x) => trim((string) ($x['text'] ?? '')), (array) $list), fn($t) => $t !== ''));
    $assetsOf = fn($list) => array_values(array_filter(array_map(fn($x) => (string) ($x['asset'] ?? ''), (array) $list)));
    $ads = [];
    $assetNames = [];
    foreach ($rows as $r) {
        $ad = $r['adGroupAd']['ad'] ?? [];
        $id = (string) ($ad['id'] ?? '');
        if ($id === '') {
            continue;
        }
        $rsa = $ad['responsiveSearchAd'] ?? [];
        $rda = $ad['responsiveDisplayAd'] ?? [];
        $vra = $ad['videoResponsiveAd'] ?? [];
        $dma = $ad['demandGenMultiAssetAd'] ?? [];
        $dva = $ad['demandGenVideoResponsiveAd'] ?? [];
        $images = array_merge($assetsOf($rda['marketingImages'] ?? []), $assetsOf($rda['squareMarketingImages'] ?? []),
            $assetsOf($dma['marketingImages'] ?? []), $assetsOf($dma['squareMarketingImages'] ?? []), $assetsOf($dma['portraitMarketingImages'] ?? []));
        $videos = array_merge(isset($ad['videoAd']['video']['asset']) ? [(string) $ad['videoAd']['video']['asset']] : [],
            $assetsOf($vra['videos'] ?? []), $assetsOf($dva['videos'] ?? []), $assetsOf($rda['youtubeVideos'] ?? []));
        $headlines = array_merge($texts($rsa['headlines'] ?? []), $texts($rda['headlines'] ?? []), $texts($vra['headlines'] ?? []),
            $texts($dma['headlines'] ?? []), $texts($dva['headlines'] ?? []));
        $descs = array_merge($texts($rsa['descriptions'] ?? []), $texts($rda['descriptions'] ?? []), $texts($dma['descriptions'] ?? []));
        $type = strtoupper((string) ($ad['type'] ?? ''));
        $kind = $videos ? 'video' : (($images || !empty($ad['imageAd']['imageUrl'])) ? 'image' : 'text');
        $url = (string) (($ad['finalUrls'] ?? [])[0] ?? '');
        $ads[$id] = [
            'status' => strtoupper((string) ($r['adGroupAd']['status'] ?? '')),
            'type' => $kind, 'ad_type' => $type,
            'image_url' => (string) ($ad['imageAd']['imageUrl'] ?? ''),
            'images' => array_values(array_unique($images)), 'videos' => array_values(array_unique($videos)),
            'headlines' => array_slice(array_values(array_unique($headlines)), 0, 15),
            'descriptions' => array_slice(array_values(array_unique($descs)), 0, 5),
            'final_url' => $url, 'host' => (string) parse_url($url, PHP_URL_HOST),
        ];
        foreach (array_merge($images, $videos) as $n) {
            $assetNames[$n] = true;
        }
    }
    // image URLs / YouTube IDs of the assets
    $assets = [];
    $names = array_keys($assetNames);
    foreach (array_chunk($names, 300) as $chunk) {
        $in = implode(',', array_map(fn($n) => "'" . str_replace("'", '', $n) . "'", $chunk));
        try {
            foreach (crGoogleFlexSearch(['asset.resource_name', 'asset.id', 'asset.type', 'asset.image_asset.full_size.url',
                'asset.youtube_video_asset.youtube_video_id', 'asset.youtube_video_asset.youtube_video_title'], 'asset', "asset.resource_name IN ({$in})") as $r) {
                $a = $r['asset'] ?? [];
                $assets[(string) ($a['resourceName'] ?? '')] = [
                    'id' => (string) ($a['id'] ?? ''),
                    'url' => (string) ($a['imageAsset']['fullSize']['url'] ?? ''),
                    'yt' => (string) ($a['youtubeVideoAsset']['youtubeVideoId'] ?? ''),
                    'yt_title' => (string) ($a['youtubeVideoAsset']['youtubeVideoTitle'] ?? ''),
                ];
            }
        } catch (Throwable $e) {
            error_log('[creatives] Google assets: ' . $e->getMessage());
        }
    }
    foreach ($ads as $id => &$d) {
        $imgs = [];
        foreach ($d['images'] as $n) {
            if (!empty($assets[$n]['url'])) {
                $imgs[] = ['id' => 'a' . $assets[$n]['id'], 'url' => $assets[$n]['url']];
            }
        }
        if ($d['image_url'] !== '') {
            array_unshift($imgs, ['id' => $id, 'url' => $d['image_url']]);
        }
        $vids = [];
        foreach ($d['videos'] as $n) {
            if (!empty($assets[$n]['yt'])) {
                $vids[] = ['youtube_id' => $assets[$n]['yt'], 'title' => $assets[$n]['yt_title']];
            }
        }
        $d['images'] = $imgs;
        $d['videos'] = $vids;
        unset($d['image_url']);
    }
    unset($d);
    return $ads;
}

/** Creative details for ads, from a 6-hour cache; only missing / old ones are fetched. */
function crDetails(string $platform, array $adIds, bool $fetch = true): array
{
    $file = 'details2_' . $platform;   // v2: with the images / videos of multi-asset ads
    $cache = crCacheGet($file, 86400 * 30) ?? [];
    $now = time();
    $need = [];
    foreach ($adIds as $id) {
        if (!isset($cache[$id]) || ($cache[$id]['_t'] ?? 0) < $now - CR_DETAILS_TTL) {
            $need[] = (string) $id;
        }
    }
    if ($need && $fetch) {
        $fresh = $platform === 'google' ? crGoogleDetails($need) : crMetaDetails($need);
        foreach ($fresh as $id => $d) {
            $cache[(string) $id] = $d + ['_t' => $now];
        }
        // keep the cache small: drop entries not used for 30 days
        foreach ($cache as $id => $d) {
            if (($d['_t'] ?? 0) < $now - 86400 * 30) {
                unset($cache[$id]);
            }
        }
        crCachePut($file, $cache);
    }
    $out = [];
    foreach ($adIds as $id) {
        if (isset($cache[$id])) {
            $out[(string) $id] = $cache[$id];
        }
    }
    return $out;
}

/** running | paused | unknown — an ad runs only when the ad and its campaign are both on. */
function crAdState(string $adStatus, string $campaignStatus): string
{
    $on = ['ACTIVE', 'ENABLED'];
    $ad = strtoupper(trim($adStatus));
    $camp = strtoupper(trim($campaignStatus));
    if ($ad === '' && $camp === '') {
        return 'unknown';
    }
    if (($ad !== '' && !in_array($ad, $on, true)) || ($camp !== '' && !in_array($camp, $on, true))) {
        return 'paused';
    }
    return 'running';
}

/** Creative details of some ads (fetched from Meta / Google when not cached), for the page: {id: {status, state, creative}}. */
function crAdDetails(string $platform, array $adIds, array $campaignStatus = []): array
{
    $out = [];
    foreach (crDetails($platform, $adIds, true) as $id => $d) {
        $st = (string) ($d['status'] ?? '');
        $out[$id] = ['status' => $st, 'state' => crAdState($st, (string) ($campaignStatus[$id] ?? '')), 'creative' => crCreativeView($platform, (string) $id, $d)];
    }
    return $out;
}

/** The creative block of one ad row for the page. */
function crCreativeView(string $platform, string $adId, ?array $d): array
{
    if (!$d) {
        return ['type' => 'unknown', 'thumb' => null];
    }
    if ($platform === 'google') {
        $thumb = null;
        if (!empty($d['images'][0])) {
            $thumb = crThumbRegister('google', (string) $d['images'][0]['id'], $d['images'][0]['url']);
        } elseif (!empty($d['videos'][0])) {
            $thumb = crThumbRegister('google', 'y' . preg_replace('/[^A-Za-z0-9_-]/', '', $d['videos'][0]['youtube_id']),
                'https://i.ytimg.com/vi/' . rawurlencode($d['videos'][0]['youtube_id']) . '/hqdefault.jpg');
        }
        return [
            'type' => $d['type'], 'ad_type' => $d['ad_type'] ?? '', 'thumb' => $thumb,
            'images' => count($d['images'] ?? []), 'videos' => array_map(fn($v) => ['youtube_id' => $v['youtube_id'], 'title' => $v['title']], $d['videos'] ?? []),
            'headlines' => array_slice($d['headlines'] ?? [], 0, 4), 'descriptions' => array_slice($d['descriptions'] ?? [], 0, 2),
            'host' => $d['host'] ?? '', 'final_url' => $d['final_url'] ?? '',
        ];
    }
    return [
        'type' => $d['type'], 'thumb' => crThumbRegister('meta', $adId, array_merge([$d['thumb_src'] ?? ''], $d['thumb_alts'] ?? [])),
        'title' => $d['title'] ?? '', 'body' => $d['body'] ?? '', 'cta' => $d['cta'] ?? '',
        'preview_url' => $d['preview_url'] ?? '', 'has_video' => ($d['video_id'] ?? '') !== '', 'assets' => (int) ($d['assets'] ?? 0),
    ];
}

/** Images and video of one ad, fetched fresh (video links from Meta expire), for the preview window. */
function crMedia(string $platform, string $adId): array
{
    $adId = preg_replace('/\D+/', '', $adId);
    if ($adId === '') {
        throw new InvalidArgumentException('Unknown ad.');
    }
    if ($platform === 'google') {
        $d = crGoogleDetails([$adId])[$adId] ?? null;
        if (!$d) {
            throw new RuntimeException('Google did not return this ad.');
        }
        $imgs = [];
        foreach ($d['images'] as $im) {
            $imgs[] = crThumbRegister('google', (string) $im['id'], $im['url']);
        }
        return ['images' => array_values(array_filter($imgs)), 'videos' => $d['videos'], 'headlines' => $d['headlines'], 'descriptions' => $d['descriptions'],
                'final_url' => $d['final_url'], 'preview_url' => ''];
    }
    $d = crMetaDetails([$adId])[$adId] ?? null;
    if (!$d) {
        throw new RuntimeException('Meta did not return this ad.');
    }
    $out = ['images' => [], 'videos' => [], 'title' => $d['title'], 'body' => $d['body'], 'preview_url' => $d['preview_url']];
    $thumb = crThumbRegister('meta', $adId, array_merge([$d['thumb_src']], $d['thumb_alts'] ?? []));
    // every image of a multi-asset / carousel ad; else the ad's own image
    foreach (array_values($d['images'] ?? []) as $n => $u) {
        $t = crThumbRegister('meta', $adId . '_' . $n, $u);
        if ($t) {
            $out['images'][] = $t;
        }
    }
    if (!$out['images'] && $thumb) {
        $out['images'][] = $thumb;
    }
    $vids = $d['video_ids'] ?? [];
    if ($d['video_id'] !== '' && !in_array($d['video_id'], $vids, true)) {
        array_unshift($vids, $d['video_id']);
    }
    foreach (array_slice($vids, 0, 4) as $vid) {
        try {
            $v = metaGraphGet($vid, ['fields' => 'source,picture,permalink_url']);
            $poster = !empty($v['picture']) ? crThumbRegister('meta', 'v' . preg_replace('/\D+/', '', $vid), (string) $v['picture']) : $thumb;
            $out['videos'][] = ['src' => (string) ($v['source'] ?? ''), 'poster' => $poster ?: $thumb,
                                'permalink' => !empty($v['permalink_url']) ? 'https://www.facebook.com' . (str_starts_with((string) $v['permalink_url'], '/') ? $v['permalink_url'] : '/' . $v['permalink_url']) : ''];
        } catch (Throwable $e) {
            // the token may not see the Page's videos: the preview link still shows the ad
            error_log('[creatives] Meta video ' . $vid . ': ' . $e->getMessage());
            $out['videos'][] = ['src' => '', 'poster' => $thumb, 'permalink' => ''];
        }
    }
    return $out;
}

/** Path of the cached thumbnail (downloaded the first time). null when it can't be fetched. */
function crThumbFile(string $platform, string $id, string $linkUrl = ''): ?array
{
    if (!in_array($platform, ['meta', 'google'], true) || !preg_match('/^[ay]?[A-Za-z0-9_-]{1,40}$/', $id)) {
        return null;
    }
    $base = crCacheDir() . '/thumb_' . $platform . '_' . $id;
    foreach (['jpg' => 'image/jpeg', 'png' => 'image/png', 'gif' => 'image/gif', 'webp' => 'image/webp'] as $ext => $mime) {
        if (is_file("{$base}.{$ext}") && filemtime("{$base}.{$ext}") > time() - CR_THUMB_TTL) {
            return ['file' => "{$base}.{$ext}", 'mime' => $mime];
        }
    }
    $mapFile = crCacheDir() . '/thumbs_' . $platform . '.json';
    $map = is_file($mapFile) ? (json_decode((string) @file_get_contents($mapFile), true) ?: []) : [];
    $urls = array_values(array_unique(array_filter(array_merge([(string) ($map[$id] ?? ''), $linkUrl], (array) ($map['~' . $id] ?? [])))));
    $got = null;
    foreach (array_filter($urls) as $u) {
        if ($got = crDownloadImage((string) $u)) {
            break;
        }
    }
    if (!$got && $platform === 'meta' && ctype_digit($id)) {
        // Meta image links expire: ask Meta for fresh ones
        $d = crMetaDetails([$id])[$id] ?? null;
        if ($d) {
            $urls = array_values(array_filter(array_merge([$d['thumb_src'] ?? ''], $d['thumb_alts'] ?? [])));
            crThumbRegister('meta', $id, $urls);
            foreach ($urls as $u) {
                if ($got = crDownloadImage((string) $u)) {
                    break;
                }
            }
        }
    }
    if (!$got) {
        // the server could not fetch any (blocked outbound / CDN refused): let the browser load it from Meta / Google
        foreach (array_filter($urls) as $u) {
            if (preg_match('#^https://#i', (string) $u)) {
                return ['redirect' => (string) $u];
            }
        }
        return null;
    }
    [$bytes, $mime] = $got;
    $ext = ['image/png' => 'png', 'image/gif' => 'gif', 'image/webp' => 'webp'][$mime] ?? 'jpg';
    $saved = @file_put_contents("{$base}.{$ext}", $bytes, LOCK_EX);
    if (!$saved) {
        error_log('[creatives] cannot write ' . crCacheDir() . ' — pictures are fetched again each time (make storage/cache writable by the web server)');
    }
    return ['file' => "{$base}.{$ext}", 'mime' => $mime, 'bytes' => $bytes];
}

/** @return array{0:string,1:string}|null [bytes, mime] — images only, at most 8 MB */
function crDownloadImage(string $url): ?array
{
    if (!preg_match('#^https://#i', $url)) {
        return null;
    }
    $ch = curl_init($url);
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_FOLLOWLOCATION => true, CURLOPT_MAXREDIRS => 3,
        CURLOPT_CONNECTTIMEOUT => 8, CURLOPT_TIMEOUT => 20, CURLOPT_PROTOCOLS => CURLPROTO_HTTPS, CURLOPT_REDIR_PROTOCOLS => CURLPROTO_HTTPS,
        CURLOPT_USERAGENT => 'PerformIQ/1.0']);
    $bytes = curl_exec($ch);
    $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $err = curl_error($ch);
    unset($ch);
    $GLOBALS['CR_LAST_DOWNLOAD'] = ['host' => (string) parse_url($url, PHP_URL_HOST), 'http' => $code, 'error' => $err, 'bytes' => is_string($bytes) ? strlen($bytes) : 0];
    if (!is_string($bytes) || $code !== 200 || strlen($bytes) < 100 || strlen($bytes) > 8 * 1024 * 1024) {
        error_log('[creatives] thumbnail download failed: ' . json_encode($GLOBALS['CR_LAST_DOWNLOAD']));
        return null;
    }
    $info = @getimagesizefromstring($bytes);
    $mime = (string) ($info['mime'] ?? '');
    $GLOBALS['CR_LAST_DOWNLOAD']['mime'] = $mime;
    return in_array($mime, ['image/jpeg', 'image/png', 'image/gif', 'image/webp'], true) ? [$bytes, $mime] : null;
}

/* ======================================================================
 * Ads + campaigns for a period
 * ====================================================================== */

/** Metrics of one tree leaf → the row fields. */
function crMetrics(array $m, ?float $freq = null): array
{
    $spend = round((float) ($m['spend'] ?? 0), 2);
    $leads = (int) ($m['leads'] ?? 0);
    $ql = (int) ($m['ql'] ?? 0);
    $sv = (int) ($m['sv_done'] ?? 0);
    $imp = (int) ($m['impressions'] ?? 0);
    $clk = (int) ($m['clicks'] ?? 0);
    return [
        'spend' => $spend, 'impressions' => $imp, 'clicks' => $clk, 'ctr' => crDiv($clk, $imp, 100),
        'leads' => $leads, 'ql' => $ql, 'sv' => $sv,
        // no spend in the dates (e.g. leads after the ad stopped): no cost per lead, not "₹0"
        'cpl' => $spend > 0 ? crDiv($spend, $leads) : null, 'cpql' => $spend > 0 ? crDiv($spend, $ql) : null,
        'cpsv' => $spend > 0 ? crDiv($spend, $sv) : null, 'ql_pct' => crDiv($ql, $leads, 100),
        'frequency' => $freq !== null && $freq > 0 ? round($freq, 2) : null,
    ];
}

/**
 * Every ad of this project with spend or leads in the period (and the same numbers for the period before),
 * the campaigns with their budgets, and the platform totals. Cached 10 minutes.
 */
function crAds(string $platform, string $since, string $until): array
{
    $platform = $platform === 'google' ? 'google' : 'meta';
    $key = 'ads3_' . $platform . '_' . md5($since . '|' . $until . '|' . appDbKey() . '|' . pqCampaignView());   // + All / Performance / Awareness tab
    $c = crCacheGet($key, CR_CACHE_TTL);
    if ($c !== null) {
        return crAdsCreatives($platform, $c);
    }
    [$ps, $pu] = crPrevRange($since, $until);
    $cur = crPeriod($since, $until);
    $prev = crPeriod($ps, $pu);
    $P = $platform === 'google' ? 'Google' : 'Meta';
    $s = projectStructure($platform);
    $tree = $cur['tree'][$P] ?? [];
    $ptree = $prev['tree'][$P] ?? [];
    $freq = $platform === 'meta' ? ($cur['meta_freq'] ?? []) : [];
    $pfreq = $platform === 'meta' ? ($prev['meta_freq'] ?? []) : [];

    $ads = [];
    $camps = [];
    $total = pfBlank();
    $ptotal = pfBlank();
    foreach ($ptree as $cid => $groups) {
        foreach ($groups as $ads_) {
            foreach ($ads_ as $m) {
                pfAdd($ptotal, $m);
            }
        }
    }
    foreach ($tree as $cid => $groups) {
        $cid = (string) $cid;
        $cM = pfBlank();
        foreach ($groups as $gid => $list) {
            foreach ($list as $aid => $m) {
                pfAdd($cM, $m);
                $aid = (string) $aid;
                if ($aid === '' || $cid === PF_UNMAPPED || $cid === '__website') {
                    continue;   // leads that can't be put under an ad: counted in the campaign / totals only
                }
                $pm = $ptree[$cid][$gid][$aid] ?? pfBlank();
                $ads[] = [
                    'id' => $aid,
                    'name' => $s['ads'][$aid]['name'] ?? $aid,
                    'campaign_id' => $cid, 'campaign' => $s['campaigns'][$cid] ?? $cid,
                    'adgroup_id' => (string) $gid, 'adgroup' => $s['adgroups'][$gid]['name'] ?? (string) $gid,
                ] + crMetrics($m, $freq[$aid] ?? null) + ['prev' => crMetrics($pm, $pfreq[$aid] ?? null)];
            }
        }
        pfAdd($total, $cM);
        if ($cid === PF_UNMAPPED || $cid === '__website') {
            continue;
        }
        $pc = pfBlank();
        foreach ($ptree[$cid] ?? [] as $list) {
            foreach ($list as $m) {
                pfAdd($pc, $m);
            }
        }
        $adLeads = 0;
        foreach ($groups as $list) {
            foreach ($list as $aid => $m) {
                if ((string) $aid !== '') {
                    $adLeads += (int) ($m['leads'] ?? 0);
                }
            }
        }
        // leads of this campaign that could not be put under an ad (Google: no utm_adid on the lead)
        $camps[$cid] = ['id' => $cid, 'name' => $s['campaigns'][$cid] ?? $cid] + crMetrics($cM) + ['prev' => crMetrics($pc), 'unplaced_leads' => max(0, (int) $cM['leads'] - $adLeads)];
    }

    // budgets + status for every campaign of the project (also the ones without spend in this period)
    foreach ($s['campaigns'] as $cid => $name) {
        if (!pqViewShows(isset($s['awareness'][$cid]) ? 'awareness' : 'performance')) {
            continue;   // not in the All / Performance / Awareness tab, or a campaign type the role may not see
        }
        $camps[(string) $cid] ??= ['id' => (string) $cid, 'name' => $name] + crMetrics(pfBlank()) + ['prev' => crMetrics(pfBlank()), 'unplaced_leads' => 0];
    }
    $budgets = crBudgets($platform, array_keys($camps));
    $today = date('Y-m-d');
    $days = (new DateTime($since))->diff(new DateTime(min($until, $today)))->days + 1;
    foreach ($camps as $cid => &$cRow) {
        $b = $budgets[$cid] ?? null;
        $cRow['status'] = $b['status'] ?? '';
        $cRow['daily_budget'] = $b['daily'] ?? null;
        $cRow['lifetime_budget'] = $b['lifetime'] ?? null;
        $cRow['budget_level'] = $b['level'] ?? '';
        $cRow['avg_daily_spend'] = $days > 0 ? round($cRow['spend'] / $days, 2) : null;
        $cRow['budget_use_pct'] = ($cRow['daily_budget'] ?? 0) > 0 && $cRow['avg_daily_spend'] !== null ? round($cRow['avg_daily_spend'] / $cRow['daily_budget'] * 100, 1) : null;
    }
    unset($cRow);
    // campaigns that spent or are running first, biggest spend first
    $camps = array_values(array_filter($camps, fn($c) => $c['spend'] > 0 || $c['leads'] > 0 || in_array($c['status'], ['ACTIVE', 'ENABLED'], true)));
    usort($camps, fn($a, $b) => [$b['spend'], $b['leads']] <=> [$a['spend'], $a['leads']]);

    $campStatus = array_column($camps, 'status', 'id');
    foreach ($ads as &$a) {
        $a['master_status'] = (string) ($s['ads'][$a['id']]['status'] ?? '');
        $a['campaign_status'] = (string) ($campStatus[$a['campaign_id']] ?? '');
    }
    unset($a);
    usort($ads, fn($a, $b) => [$b['spend'], $b['leads']] <=> [$a['spend'], $a['leads']]);

    $out = [
        'platform' => $platform, 'since' => $since, 'until' => $until, 'prev_since' => $ps, 'prev_until' => $pu, 'days' => $days,
        'total' => crMetrics($total), 'prev_total' => crMetrics($ptotal),
        'ads' => $ads, 'campaigns' => $camps,
        'warnings' => array_values(array_unique(array_filter(array_merge($cur['warnings'] ?? [], $prev['warnings'] ?? []),
            fn($w) => stripos((string) $w, $P) !== false))),
        'configured' => $s['configured'],
    ];
    crCachePut($key, $out);
    return crAdsCreatives($platform, $out);
}

/**
 * Adds status, running / paused and the creative to each ad — only from creatives already cached on this server
 * (fast). The page asks for the rest a few at a time (creatives_api.php?action=details).
 */
function crAdsCreatives(string $platform, array $out): array
{
    $details = crDetails($platform, array_column($out['ads'], 'id'), false);
    foreach ($out['ads'] as &$a) {
        $d = $details[$a['id']] ?? null;
        $a['status'] = (string) (($d['status'] ?? '') !== '' ? $d['status'] : ($a['master_status'] ?? ''));
        $a['state'] = crAdState($a['status'], (string) ($a['campaign_status'] ?? ''));
        $a['creative'] = $d ? crCreativeView($platform, (string) $a['id'], $d) : null;
        unset($a['master_status']);
    }
    unset($a);
    return $out;
}

/* ======================================================================
 * Insights & Actions (rules)
 * ====================================================================== */

/** Target CPL / CPQL / CPSV and qualified leads for the dates (Targets page), or nulls. */
function crTargets(string $platform, string $since, string $until): array
{
    $none = ['cpl' => null, 'cpql' => null, 'cpsv' => null, 'ql' => null, 'leads' => null];
    try {
        require_once __DIR__ . '/targets.php';
        $db = pqtDb();
        $set = pqtSettings($db);
        $periods = pqtPeriodsIn($set['period'], $since, $until);
        $data = pqtLoad($db, $set['period'], array_column($periods, 'key'));
        $t = pqtTarget($data, $periods, $platform, true, array_keys(pqtPlatforms()));   // pro-rated to the dates
        if (!$t['entered']) {
            return $none;
        }
        $v = $t['values'];
        return ['cpl' => $v['cpl'] ?? null, 'cpql' => $v['cpql'] ?? null, 'cpsv' => $v['cpsv'] ?? null, 'ql' => $v['ql'] ?? null, 'leads' => $v['leads'] ?? null];
    } catch (Throwable $e) {
        return $none;
    }
}

/**
 * Findings for the execution team, most important first.
 * Each: {id, type, severity: good|warn|bad|info, level: ad|campaign|platform, title, text, action, ad_id?, campaign_id?}
 * $hidden = metrics this viewer may not see (Users & Roles → Hide numbers): rules that use them are skipped.
 */
function crInsights(string $platform, string $since, string $until, array $hidden = []): array
{
    $d = crAds($platform, $since, $until);
    $R = crRules();
    $T = crTargets($platform, $since, $until);
    $tot = $d['total'];
    $noQl = in_array('qualified', $hidden, true);
    $noCpql = $noQl || in_array('cpql', $hidden, true);
    $noSv = in_array('sitevisits', $hidden, true);
    $noCpsv = $noSv || in_array('cpsv', $hidden, true);
    $statusesIn = $tot['ql'] > 0 || $tot['sv'] > 0;   // CRM statuses uploaded for this period?

    // benchmarks: the target, else this platform's own average for the dates
    $bCpql = $T['cpql'] ?? $tot['cpql'];
    $bCpl = $T['cpl'] ?? $tot['cpl'];
    $bCpqlLabel = $T['cpql'] !== null ? 'target CPQL' : crPlatformName($platform) . ' average CPQL';
    $bCplLabel = $T['cpl'] !== null ? 'target CPL' : crPlatformName($platform) . ' average CPL';
    $f = [];
    $add = function (array $x) use (&$f) {
        $x['id'] = 'f' . (count($f) + 1);
        $f[] = $x;
    };
    $label = fn($a) => '“' . $a['name'] . '”';
    $where = fn($a) => $a['campaign'] . ' › ' . $a['adgroup'];
    $kind = fn($a) => ['video' => 'video', 'carousel' => 'carousel', 'dynamic' => 'multi-asset', 'image' => 'image', 'text' => 'search text'][$a['creative']['type'] ?? ''] ?? 'creative';

    // ---- platform: pace vs target ----
    if (!$noQl && $T['ql'] !== null && $T['ql'] > 0) {
        $pct = round($tot['ql'] / $T['ql'] * 100);
        $gap = (int) ceil($T['ql'] - $tot['ql']);
        $add(['type' => 'pace', 'severity' => $pct >= 100 ? 'good' : ($pct >= 85 ? 'warn' : 'bad'), 'level' => 'platform',
              'title' => $pct >= 100 ? 'Ahead of the qualified-lead target' : 'Behind the qualified-lead target',
              'text' => "{$tot['ql']} qualified leads vs a target of " . round($T['ql']) . " for these dates ({$pct}%).",
              'action' => $pct >= 100 ? 'Keep the budget on the campaigns with the best CPQL below.' : "About {$gap} more needed — move budget to the winners below and fix or pause the losing ads."]);
    }
    if (!$statusesIn && $tot['leads'] >= 10 && !$noQl) {
        $add(['type' => 'no_status', 'severity' => 'info', 'level' => 'platform', 'title' => 'Lead quality not updated yet',
              'text' => "{$tot['leads']} leads in these dates, none marked qualified or visited.",
              'action' => 'Upload the CRM status (Upload Lead Status) so CPQL and the quality rules can be checked.']);
    }

    // ---- ads ----
    // campaigns where many leads could not be put under an ad: per-ad lead rules would be wrong there
    $unsure = [];
    $unplaced = 0;
    foreach ($d['campaigns'] as $c) {
        $unplaced += (int) ($c['unplaced_leads'] ?? 0);
        if (($c['unplaced_leads'] ?? 0) > 0 && $c['unplaced_leads'] >= 0.2 * max(1, $c['leads'])) {
            $unsure[$c['id']] = true;
        }
    }
    if ($unplaced > 0 && $unsure) {
        $add(['type' => 'unplaced', 'severity' => 'info', 'level' => 'platform',
              'title' => 'Some leads are not linked to an ad',
              'text' => "{$unplaced} lead" . ($unplaced === 1 ? '' : 's') . ' could not be put under an ad, so per-ad results skip those campaigns.',
              'action' => $platform === 'google'
                  ? 'Add utm_adid={creative} (with utm_campaignid={campaignid} and utm_adgroupid={adgroupid}) to the Google Ads tracking template and save it with each lead.'
                  : 'Make sure the lead forms / landing pages save the Meta ad ID (ad_id) with each lead.']);
    }
    $ads = $d['ads'];
    $svBest = null;
    foreach ($ads as $a) {
        if (!isset($unsure[$a['campaign_id']]) && !$noCpsv && $a['sv'] >= 2 && $a['cpsv'] !== null && ($svBest === null || $a['cpsv'] < $svBest['cpsv'])) {
            $svBest = $a;
        }
    }
    foreach ($ads as $a) {
        $p = $a['prev'];
        $leadRules = !isset($unsure[$a['campaign_id']]);
        // losing: spent a lot with no qualified lead (or no lead at all)
        if ($leadRules && $statusesIn && !$noCpql && $bCpql && $a['ql'] === 0 && $a['spend'] >= $R['losing_spend_x'] * $bCpql) {
            $add(['type' => 'losing', 'severity' => 'bad', 'level' => 'ad', 'ad_id' => $a['id'], 'campaign_id' => $a['campaign_id'],
                  'title' => 'Pause or replace ' . $label($a),
                  'text' => crMoney($a['spend']) . " spent, {$a['leads']} lead" . ($a['leads'] === 1 ? '' : 's') . ' and no qualified lead (' . $where($a) . ').',
                  'action' => 'Pause it, or replace the creative and move its budget to a winner.']);
            continue;
        }
        if ($leadRules && $a['leads'] === 0 && $bCpl && $a['spend'] >= max(2 * $bCpl, 1000)) {
            $add(['type' => 'losing', 'severity' => 'bad', 'level' => 'ad', 'ad_id' => $a['id'], 'campaign_id' => $a['campaign_id'],
                  'title' => 'No leads from ' . $label($a),
                  'text' => crMoney($a['spend']) . ' spent without a lead (' . $where($a) . ').',
                  'action' => 'Check the form / landing page, then pause or replace the creative.']);
            continue;
        }
        // winner on CPQL
        if ($leadRules && !$noCpql && $bCpql && $a['ql'] >= $R['min_ql_winner'] && $a['cpql'] !== null && $a['cpql'] <= $bCpql * (1 - $R['winner_cpql_below'] / 100)) {
            $below = round((1 - $a['cpql'] / $bCpql) * 100);
            $add(['type' => 'winner', 'severity' => 'good', 'level' => 'ad', 'ad_id' => $a['id'], 'campaign_id' => $a['campaign_id'],
                  'title' => 'Make more like ' . $label($a),
                  'text' => "{$a['ql']} qualified leads at " . crMoney($a['cpql']) . " CPQL — {$below}% below the {$bCpqlLabel} (" . crMoney($bCpql) . ').',
                  'action' => 'Raise its budget 20–30% and brief 2–3 new ' . $kind($a) . ' creatives in the same style.']);
            continue;
        }
        // cheap leads that don't qualify
        if ($leadRules && $statusesIn && !$noQl && $bCpl && $a['leads'] >= $R['junk_min_leads'] && $a['cpl'] !== null && $a['cpl'] <= $bCpl
            && ($a['ql_pct'] ?? 0) < $R['junk_ql_rate_below']) {
            $add(['type' => 'junk', 'severity' => 'warn', 'level' => 'ad', 'ad_id' => $a['id'], 'campaign_id' => $a['campaign_id'],
                  'title' => 'Cheap leads but low quality: ' . $label($a),
                  'text' => "{$a['leads']} leads at " . crMoney($a['cpl']) . ' CPL, but ' . ($a['ql'] === 0 ? 'none qualified.' : "only {$a['ql']} qualified (" . round((float) $a['ql_pct']) . '%).'),
                  'action' => 'Tighten the audience or add a qualifying question to the form before adding budget.']);
            continue;
        }
        // creative fatigue (Meta)
        if ($platform === 'meta' && ($a['frequency'] ?? 0) >= $R['fatigue_frequency'] && $a['impressions'] >= 1000 && ($p['ctr'] ?? 0) > 0
            && $a['ctr'] !== null && $a['ctr'] <= $p['ctr'] * (1 - $R['fatigue_ctr_drop'] / 100)) {
            $add(['type' => 'fatigue', 'severity' => 'warn', 'level' => 'ad', 'ad_id' => $a['id'], 'campaign_id' => $a['campaign_id'],
                  'title' => 'Creative fatigue: ' . $label($a),
                  'text' => "Frequency {$a['frequency']} and CTR down from {$p['ctr']}% to {$a['ctr']}% vs the period before.",
                  'action' => 'Refresh the creative (new image / hook) or widen the audience.']);
            continue;
        }
        // good CPL with decent quality
        if ($leadRules && $bCpl && $a['leads'] >= $R['min_leads'] && $a['cpl'] !== null && $a['cpl'] <= $bCpl * (1 - $R['good_cpl_below'] / 100)
            && (!$statusesIn || $noQl || ($a['ql_pct'] ?? 0) >= $R['junk_ql_rate_below'])) {
            $below = round((1 - $a['cpl'] / $bCpl) * 100);
            $add(['type' => 'good_cpl', 'severity' => 'good', 'level' => 'ad', 'ad_id' => $a['id'], 'campaign_id' => $a['campaign_id'],
                  'title' => 'Good CPL: ' . $label($a),
                  'text' => "{$a['leads']} leads at " . crMoney($a['cpl']) . " CPL — {$below}% below the {$bCplLabel} (" . crMoney($bCpl) . ').'
                      . ($statusesIn && !$noQl ? " {$a['ql']} qualified." : ''),
                  'action' => 'Test more ' . $kind($a) . ' creatives like this one.']);
            continue;
        }
        // CPL much worse than before
        if ($leadRules && $a['leads'] >= $R['min_leads'] && ($p['leads'] ?? 0) >= $R['min_leads'] && $p['cpl'] && $a['cpl'] >= $p['cpl'] * (1 + $R['cpl_change'] / 100)) {
            $up = round(($a['cpl'] / $p['cpl'] - 1) * 100);
            $add(['type' => 'worsening', 'severity' => 'warn', 'level' => 'ad', 'ad_id' => $a['id'], 'campaign_id' => $a['campaign_id'],
                  'title' => 'CPL rising: ' . $label($a),
                  'text' => 'CPL ' . crMoney($a['cpl']) . " vs " . crMoney($p['cpl']) . " the period before (+{$up}%).",
                  'action' => 'Check frequency and the audience; refresh the creative if it keeps rising.']);
            continue;
        }
    }
    if ($svBest !== null) {
        $a = $svBest;
        $add(['type' => 'sv_driver', 'severity' => 'good', 'level' => 'ad', 'ad_id' => $a['id'], 'campaign_id' => $a['campaign_id'],
              'title' => 'Best for site visits: ' . $label($a),
              'text' => "{$a['sv']} site visits at " . crMoney($a['cpsv']) . ' CPSV (' . $where($a) . ').',
              'action' => 'Use this message in retargeting and in the next creatives.']);
    }

    // ---- campaigns: budget ----
    foreach ($d['campaigns'] as $c) {
        if (!in_array($c['status'], ['ACTIVE', 'ENABLED'], true) || !($c['daily_budget'] ?? 0) || $d['days'] < 3) {
            continue;
        }
        if ($c['budget_use_pct'] !== null && $c['budget_use_pct'] < $R['underspend_pct']) {
            $add(['type' => 'underspend', 'severity' => 'warn', 'level' => 'campaign', 'campaign_id' => $c['id'],
                  'title' => 'Not spending its budget: “' . $c['name'] . '”',
                  'text' => 'Average ' . crMoney($c['avg_daily_spend']) . ' a day of a ' . crMoney($c['daily_budget']) . " daily budget ({$c['budget_use_pct']}%).",
                  'action' => 'The audience may be too small or the bid / cost cap too low — widen targeting or raise the bid.']);
        } elseif ($c['budget_use_pct'] !== null && $c['budget_use_pct'] >= 95 && !$noCpql && $bCpql && $c['cpql'] !== null && $c['cpql'] <= $bCpql) {
            $add(['type' => 'budget_limited', 'severity' => 'good', 'level' => 'campaign', 'campaign_id' => $c['id'],
                  'title' => 'Limited by budget: “' . $c['name'] . '”',
                  'text' => 'Spends its full ' . crMoney($c['daily_budget']) . ' daily budget at ' . crMoney($c['cpql']) . " CPQL (within the {$bCpqlLabel}).",
                  'action' => 'Raise the daily budget about 20% and watch CPQL for 3 days.']);
        }
    }

    $order = ['pace' => 0, 'no_status' => 1, 'unplaced' => 1, 'losing' => 2, 'junk' => 3, 'fatigue' => 4, 'underspend' => 5, 'worsening' => 6,
              'winner' => 7, 'budget_limited' => 8, 'sv_driver' => 9, 'good_cpl' => 10];
    usort($f, fn($x, $y) => ($order[$x['type']] ?? 99) <=> ($order[$y['type']] ?? 99));
    // at most 3 of a kind first (so ten losing ads don't hide the winners), then fill up to 14
    $pick = [];
    $per = [];
    foreach ($f as $i => $x) {
        if (($per[$x['type']] = ($per[$x['type']] ?? 0) + 1) <= 3) {
            $pick[$i] = $x;
        }
    }
    foreach ($f as $i => $x) {
        if (count($pick) >= 14) {
            break;
        }
        $pick[$i] ??= $x;
    }
    ksort($pick);
    $f = array_values($pick);
    return [
        'findings' => array_slice($f, 0, 14),
        'benchmarks' => ['cpql' => $noCpql ? null : $bCpql, 'cpql_label' => $noCpql ? null : $bCpqlLabel, 'cpl' => $bCpl, 'cpl_label' => $bCplLabel],
        'statuses_in' => $statusesIn, 'rules' => $R,
    ];
}

/**
 * Wording for the findings: Groq when GROQ_API_KEY is set (cached a day for the same findings), else the rules' own.
 * @return array{summary: string, items: array<string, string>, source: string}
 */
function crInsightsText(string $platform, string $periodLabel, array $findings): array
{
    $plain = ['summary' => '', 'items' => [], 'source' => 'rules'];
    foreach ($findings as $x) {
        $plain['items'][$x['id']] = $x['text'] . ' ' . $x['action'];
    }
    $good = count(array_filter($findings, fn($x) => $x['severity'] === 'good'));
    $bad = count(array_filter($findings, fn($x) => in_array($x['severity'], ['bad', 'warn'], true)));
    $plain['summary'] = $findings
        ? crPlatformName($platform) . ", {$periodLabel}: {$good} thing" . ($good === 1 ? '' : 's') . " to scale and {$bad} to fix or check."
        : crPlatformName($platform) . ", {$periodLabel}: nothing stands out — not enough spend or leads yet for the rules.";
    if (!$findings || !defined('GROQ_API_KEY') || trim((string) GROQ_API_KEY) === '' || !defined('GROQ_URL')) {
        return $plain;
    }
    $input = array_map(fn($x) => ['id' => $x['id'], 'type' => $x['type'], 'title' => $x['title'], 'facts' => $x['text'], 'action' => $x['action']], $findings);
    $key = 'groq_' . md5(json_encode($input) . '|' . $periodLabel . '|' . (defined('GROQ_MODEL') ? GROQ_MODEL : ''));
    $c = crCacheGet($key, CR_TEXT_TTL);
    if ($c !== null) {
        return $c;
    }
    $prompt = "You write short, practical notes for the execution team of a real-estate digital marketing agency.\n"
        . "Platform: " . crPlatformName($platform) . " Ads. Period: {$periodLabel}.\n"
        . "Below are findings already worked out from the numbers. Rewrite each one as ONE or TWO plain sentences that say what happened and exactly what to do.\n"
        . "Rules: use ONLY the numbers and names given; never add, round or invent numbers; keep ad and campaign names exactly; Indian rupee format as given; no hype.\n"
        . "Also write a 2-sentence summary of the overall picture.\n"
        . "Return JSON only: {\"summary\": \"...\", \"items\": [{\"id\": \"f1\", \"text\": \"...\"}]} with one item per finding id.\n\n"
        . "Findings:\n" . json_encode($input, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    $ch = curl_init((string) GROQ_URL);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true, CURLOPT_POST => true, CURLOPT_TIMEOUT => 40, CURLOPT_CONNECTTIMEOUT => 8,
        CURLOPT_HTTPHEADER => ['Authorization: Bearer ' . GROQ_API_KEY, 'Content-Type: application/json'],
        CURLOPT_POSTFIELDS => json_encode([
            'model' => defined('GROQ_MODEL') ? GROQ_MODEL : 'llama-3.3-70b-versatile',
            'temperature' => 0.2,
            'response_format' => ['type' => 'json_object'],
            'messages' => [
                ['role' => 'system', 'content' => 'You are a careful performance-marketing analyst. You never invent numbers.'],
                ['role' => 'user', 'content' => $prompt],
            ],
        ]),
    ]);
    $raw = curl_exec($ch);
    $http = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
    unset($ch);
    $res = json_decode((string) $raw, true);
    $j = json_decode((string) ($res['choices'][0]['message']['content'] ?? ''), true);
    if ($http !== 200 || !is_array($j) || !isset($j['items']) || !is_array($j['items'])) {
        error_log('[creatives] Groq: HTTP ' . $http . ' ' . substr((string) $raw, 0, 300));
        return $plain;   // not cached: Groq is tried again next time
    }
    // keep Groq's text only where its numbers are ones the finding already had
    $out = ['summary' => '', 'items' => $plain['items'], 'source' => 'groq'];
    $known = [];
    foreach ($findings as $x) {
        $known[$x['id']] = crNumbersIn($x['title'] . ' ' . $x['text'] . ' ' . $x['action']);
    }
    $all = array_merge(...array_values($known ?: [[]]));
    foreach ($j['items'] as $it) {
        $id = (string) ($it['id'] ?? '');
        $t = trim((string) ($it['text'] ?? ''));
        if (isset($out['items'][$id]) && $t !== '' && mb_strlen($t) <= 600 && !array_diff(crNumbersIn($t), $known[$id])) {
            $out['items'][$id] = $t;
        }
    }
    $sum = trim((string) ($j['summary'] ?? ''));
    $out['summary'] = ($sum !== '' && mb_strlen($sum) <= 600 && !array_diff(crNumbersIn($sum), $all, crNumbersIn($periodLabel))) ? $sum : $plain['summary'];
    crCachePut($key, $out);
    return $out;
}

/** Numbers written in a text (₹1,23,456 → 123456; 24% → 24), for checking that Groq did not invent any. */
function crNumbersIn(string $t): array
{
    preg_match_all('/\d[\d,]*(?:\.\d+)?/', $t, $m);
    $n = array_map(function ($x) {
        $x = str_replace(',', '', $x);
        return str_contains($x, '.') ? (rtrim(rtrim($x, '0'), '.') ?: '0') : (ltrim($x, '0') ?: '0');
    }, $m[0]);
    return array_values(array_unique(array_filter($n, fn($x) => $x !== '' && !in_array($x, ['1', '2', '3'], true))));
}
