<?php
/**
 * app/Leads/status_upload.php — "Upload Lead Status" (CPQL / CPSV data).
 *
 * Updates four things on existing leads from a CRM export (CSV / XLSX; XLS is converted to CSV in
 * the browser), matched by any lead column the user picks — mobile (last 10 digits), email, uniqueid, leadgen_id, …:
 *   lead status → lead.lead_status       QUALIFIED / NON-QUALIFIED / TO BE QUALIFIED   (CPQL)
 *   site visit  → lead.sitevisit_status  Yes → "Visited", No → "Not Visited"            (CPSV)
 *   platform    → lead.campaignsource    Google → "Google", Meta → "Facebook Lead Form"
 * Optional MQL column (CRM exports) — off unless define('STATUS_UPLOAD_MQL', true) in config.php:
 *   MQL = 1 / Yes / True → QUALIFIED, whatever the lead status column says.
 *   MQL = 0 → the lead status column decides; with no lead status column chosen, MQL = 0 → NON-QUALIFIED.
 * Nothing is inserted, and every upload is logged (old → new values) so it can be undone.
 *
 * Steps (public/status_upload.php):  1 upload → 2 unique ID → 3 map columns + values → 4 review → confirm.
 */

require_once dirname(__DIR__) . '/Core/db.php';

const SU_MAX_ROWS = 50000;

/**
 * The fields that can be updated: lead column, the only values allowed (choice label => value written),
 * and the value(s) the dashboards count. Every dashboard / report recognises these written values.
 */
const SU_FIELDS = [
    'status' => [
        'label' => 'Lead status', 'column' => 'lead_status', 'max' => 50,
        'options' => ['QUALIFIED' => 'QUALIFIED', 'NON-QUALIFIED' => 'NON-QUALIFIED', 'TO BE QUALIFIED' => 'TO BE QUALIFIED'],
        'counts' => ['QUALIFIED'],
    ],
    'sitevisit' => [
        'label' => 'Site visit', 'column' => 'sitevisit_status', 'max' => 255,
        'options' => ['Yes' => 'Visited', 'No' => 'Not Visited'],
        'counts' => ['Visited'],
    ],
    'platform' => [
        'label' => 'Platform', 'column' => 'campaignsource', 'max' => 45,
        'options' => ['Google' => 'Google', 'Meta' => 'Facebook Lead Form'],
        'counts' => [],
    ],
];
/**
 * A lead that is already Qualified and comes back Non-qualified in a new feedback file is written as
 * "LOST POST QUALIFIED" (it was a qualified lead; it still counts for CPQL), not "NON-QUALIFIED".
 */
const SU_LOST_POST_QUALIFIED = 'LOST POST QUALIFIED';
/** lead_status values counted as Qualified elsewhere too (so "already qualified" is recognised). */
const SU_QUALIFIED_VALUES = ['QUALIFIED', 'LOST POST QUALIFIED', 'LOST POST QUALIFICATION'];
/** sitevisit_status values counted as a Site Visit by the dashboards. */
const SU_SITEVISIT_VALUES = ['VISITED', 'VISIT DONE', 'SITE VISIT DONE', 'SITE VISIT', 'WALKIN', 'WALK-IN', 'DONE', 'YES', 'CONDUCTED'];
/** campaignsource values that already mean Meta / Google (the platform is only changed across families). */
const SU_META_SOURCES = ['facebook lead form', 'facebook', 'fb', 'ig', 'instagram', 'meta', 'whatsapp'];
const SU_GOOGLE_SOURCES = ['google', 'googledg', 'website', 'google ads', 'adwords'];

/* ------------------------------------------------------------------ parsing */

/** @return array{rows: array<int,array<int,string>>, sheet: string} */
function suParseFile(string $path, string $originalName): array
{
    $ext = strtolower(pathinfo($originalName, PATHINFO_EXTENSION));
    if ($ext === 'xlsx') {
        if (!class_exists('ZipArchive')) {
            throw new SuNeedClientConvert('This server cannot read .xlsx files (PHP zip extension missing).');
        }
        return suParseXlsx($path);
    }
    if ($ext === 'xls') {
        throw new SuNeedClientConvert('.xls files are converted in the browser.');
    }
    if (in_array($ext, ['csv', 'txt', 'tsv'], true)) {
        return ['rows' => suParseCsv($path), 'sheet' => ''];
    }
    throw new InvalidArgumentException('Please upload a .csv, .xlsx or .xls file.');
}

final class SuNeedClientConvert extends RuntimeException {}

function suParseCsv(string $path): array
{
    $raw = (string) file_get_contents($path);
    if (str_starts_with($raw, "\xEF\xBB\xBF")) {
        $raw = substr($raw, 3);
    } elseif (str_starts_with($raw, "\xFF\xFE") || str_starts_with($raw, "\xFE\xFF")) {
        $raw = mb_convert_encoding($raw, 'UTF-8', 'UTF-16');
    }
    if (!mb_check_encoding($raw, 'UTF-8')) {
        $raw = mb_convert_encoding($raw, 'UTF-8', 'Windows-1252');
    }
    $firstLine = strtok($raw, "\n") ?: '';
    $delims = [',' => substr_count($firstLine, ','), ';' => substr_count($firstLine, ';'), "\t" => substr_count($firstLine, "\t"), '|' => substr_count($firstLine, '|')];
    arsort($delims);
    $delim = (string) array_key_first($delims);

    $fh = fopen('php://temp', 'r+');
    fwrite($fh, $raw);
    rewind($fh);
    $rows = [];
    while (($r = fgetcsv($fh, 0, $delim, '"', '')) !== false) {
        if ($r === [null]) {
            $rows[] = [];
            continue;
        }
        $rows[] = array_map(fn($v) => trim((string) $v), $r);
        if (count($rows) > SU_MAX_ROWS + 50) {
            break;
        }
    }
    fclose($fh);
    return $rows;
}

/** Minimal XLSX reader (first sheet, values as text). Numbers are kept exactly (no 9.02E+09). */
function suParseXlsx(string $path): array
{
    $zip = new ZipArchive();
    if ($zip->open($path) !== true) {
        throw new InvalidArgumentException('The .xlsx file could not be opened. Is it a real Excel file?');
    }
    $xml = fn(string $name) => ($s = $zip->getFromName($name)) === false ? null : $s;

    // first sheet → its file
    $sheetFile = 'xl/worksheets/sheet1.xml';
    $sheetName = '';
    $wb = $xml('xl/workbook.xml');
    $rels = $xml('xl/_rels/workbook.xml.rels');
    if ($wb && $rels) {
        $w = simplexml_load_string($wb);
        $r = simplexml_load_string($rels);
        if ($w && $r && isset($w->sheets->sheet[0])) {
            $first = $w->sheets->sheet[0];
            $sheetName = (string) $first['name'];
            $rid = (string) $first->attributes('http://schemas.openxmlformats.org/officeDocument/2006/relationships')['id'];
            foreach ($r->Relationship as $rel) {
                if ((string) $rel['Id'] === $rid) {
                    $t = ltrim((string) $rel['Target'], '/');
                    $sheetFile = str_starts_with($t, 'xl/') ? $t : 'xl/' . $t;
                }
            }
        }
    }

    $shared = [];
    if (($ss = $xml('xl/sharedStrings.xml')) !== null) {
        $reader = new XMLReader();
        $reader->XML($ss);
        $ok = $reader->read();
        while ($ok) {
            if ($reader->nodeType !== XMLReader::ELEMENT || $reader->localName !== 'si') {
                $ok = $reader->read();
                continue;
            }
            $node = simplexml_load_string($reader->readOuterXml());
            $text = '';
            if (isset($node->t)) {
                $text = (string) $node->t;
            }
            foreach ($node->r ?? [] as $run) {
                $text .= (string) $run->t;
            }
            $shared[] = $text;
            $ok = $reader->next();   // next <si> (read() would skip one)
        }
        $reader->close();
    }

    $sheet = $xml($sheetFile);
    $zip->close();
    if ($sheet === null) {
        throw new InvalidArgumentException('No worksheet found in the .xlsx file.');
    }

    $rows = [];
    $reader = new XMLReader();
    $reader->XML($sheet);
    $rowIdx = -1;
    $ok = $reader->read();
    while ($ok) {
        if ($reader->nodeType !== XMLReader::ELEMENT) {
            $ok = $reader->read();
            continue;
        }
        if ($reader->localName === 'row') {
            $n = (int) $reader->getAttribute('r');
            $rowIdx = $n > 0 ? $n - 1 : $rowIdx + 1;
            $rows[$rowIdx] = $rows[$rowIdx] ?? [];
            if (count($rows) > SU_MAX_ROWS + 50) {
                break;
            }
        } elseif ($reader->localName === 'c') {
            $ref = (string) $reader->getAttribute('r');
            $type = (string) $reader->getAttribute('t');
            $node = simplexml_load_string($reader->readOuterXml());
            $v = isset($node->v) ? (string) $node->v : '';
            if ($type === 's') {
                $v = $shared[(int) $v] ?? '';
            } elseif ($type === 'inlineStr') {
                $v = isset($node->is->t) ? (string) $node->is->t : '';
                foreach ($node->is->r ?? [] as $run) {
                    $v .= (string) $run->t;
                }
            } elseif ($type === 'b') {
                $v = $v === '1' ? 'TRUE' : 'FALSE';
            } elseif ($type === '' || $type === 'n') {
                if (preg_match('/^-?\d+(\.\d+)?E\+?\d+$/i', $v)) {
                    $v = sprintf('%.0f', (float) $v);            // 9.019402997E9 → 9019402997
                } elseif (preg_match('/^-?\d+\.0+$/', $v)) {
                    $v = preg_replace('/\.0+$/', '', $v);
                }
            }
            $col = suColIndex(preg_replace('/\d+/', '', $ref));
            $rows[$rowIdx][$col] = trim($v);
            $ok = $reader->next();   // next <c> (read() would skip one)
            continue;
        }
        $ok = $reader->read();
    }
    $reader->close();

    // fill gaps so every row is a plain list
    $out = [];
    if ($rows) {
        $maxRow = max(array_keys($rows));
        for ($i = 0; $i <= $maxRow; $i++) {
            $r = $rows[$i] ?? [];
            if ($r) {
                $max = max(array_keys($r));
                $line = [];
                for ($c = 0; $c <= $max; $c++) {
                    $line[] = $r[$c] ?? '';
                }
                $out[] = $line;
            } else {
                $out[] = [];
            }
        }
    }
    return ['rows' => $out, 'sheet' => $sheetName];
}

function suColIndex(string $letters): int
{
    $n = 0;
    foreach (str_split(strtoupper($letters)) as $ch) {
        $n = $n * 26 + (ord($ch) - 64);
    }
    return max(0, $n - 1);
}

/**
 * First non-empty row = headers. Returns [headers, dataRows] (data rows keep their file row number).
 * @return array{0: string[], 1: array<int, array{n:int, cells:string[]}>}
 */
function suSplitHeader(array $rows): array
{
    $headers = null;
    $data = [];
    foreach ($rows as $i => $r) {
        $nonEmpty = array_filter($r, fn($v) => trim((string) $v) !== '');
        if ($headers === null) {
            if ($nonEmpty) {
                $headers = array_map(fn($v) => trim((string) $v), $r);
            }
            continue;
        }
        if (!$nonEmpty) {
            continue;
        }
        $data[] = ['n' => $i + 1, 'cells' => array_map(fn($v) => (string) $v, $r)];
    }
    if ($headers === null) {
        throw new InvalidArgumentException('The file is empty.');
    }
    foreach ($headers as $i => $h) {
        if ($h === '') {
            $headers[$i] = 'Column ' . suColLetter($i);
        }
    }
    if (count($data) > SU_MAX_ROWS) {
        throw new InvalidArgumentException('The file has more than ' . number_format(SU_MAX_ROWS) . ' rows. Please split it.');
    }
    return [$headers, $data];
}

function suColLetter(int $i): string
{
    $s = '';
    for ($i++; $i > 0; $i = intdiv($i - 1, 26)) {
        $s = chr(65 + ($i - 1) % 26) . $s;
    }
    return $s;
}

/* ------------------------------------------------------------------ temp storage */

/**
 * Folder for the parsed upload between the steps: storage/cache/status_upload, or — when the
 * server doesn't let PHP write there — the system temp folder. Returns null if neither works.
 */
function suTmpDir(): ?string
{
    static $dir = false;
    if ($dir !== false) {
        return $dir;
    }
    $candidates = [STORAGE_PATH . '/cache/status_upload',
                   rtrim(sys_get_temp_dir(), '/\\') . '/pq_status_upload_' . substr(md5(BASE_PATH), 0, 8)];
    foreach ($candidates as $c) {
        if (!is_dir($c)) {
            @mkdir($c, 0775, true);
        }
        if (is_dir($c) && is_writable($c)) {
            $probe = $c . '/.probe_' . bin2hex(random_bytes(4));
            if (@file_put_contents($probe, 'ok') !== false) {
                @unlink($probe);
                return $dir = $c;
            }
        }
    }
    return $dir = null;
}

function suTmpPath(string $token): string
{
    if (!preg_match('/^[a-f0-9]{32}$/', $token)) {
        throw new InvalidArgumentException('Upload expired — please upload the file again.');
    }
    $dir = suTmpDir();
    if ($dir === null) {
        throw new RuntimeException('The server has no writable folder for uploads. Make storage/cache writable (see the checks at the top of the page).');
    }
    $owner = substr(hash('sha256', session_id() . '|' . ($_SESSION['uid'] ?? $_SESSION['username'] ?? '')), 0, 16);
    return $dir . "/{$owner}_{$token}.json";
}

function suSaveUpload(array $payload): string
{
    $token = bin2hex(random_bytes(16));
    $path = suTmpPath($token);
    foreach (glob(dirname($path) . '/*.json') ?: [] as $old) {        // clean up after a day
        if (filemtime($old) < time() - 86400) {
            @unlink($old);
        }
    }
    if (@file_put_contents($path, json_encode($payload, JSON_UNESCAPED_UNICODE)) === false) {
        throw new RuntimeException('Could not store the upload on the server (' . dirname($path) . ' is not writable).');
    }
    return $token;
}

/** Size in bytes of a php.ini value like "8M". */
function suIniBytes(string $v): int
{
    $v = trim($v);
    $n = (int) $v;
    switch (strtolower(substr($v, -1))) {
        case 'g': $n *= 1024;
        // no break
        case 'm': $n *= 1024;
        // no break
        case 'k': $n *= 1024;
    }
    return $n;
}

/**
 * Everything the upload needs, checked before a file is chosen.
 * @return array<int, array{key:string, label:string, ok:bool, blocking:bool, detail:string, fix:string}>
 */
function suChecks(?mysqli $db, string $dbLabel): array
{
    $out = [];
    $add = function (string $key, string $label, bool $ok, bool $blocking, string $detail, string $fix = '') use (&$out) {
        $out[] = compact('key', 'label', 'ok', 'blocking', 'detail', 'fix');
    };
    $rel = fn(string $p) => str_starts_with($p, BASE_PATH) ? ltrim(substr($p, strlen(BASE_PATH)), '/') : $p;

    // 1. somewhere to keep the file between the steps
    $dir = suTmpDir();
    $main = STORAGE_PATH . '/cache/status_upload';
    if ($dir === $main) {
        $add('storage', 'Upload folder is writable', true, true, $rel($main));
    } elseif ($dir !== null) {
        $add('storage', 'Upload folder is writable', true, false,
             'storage/cache is not writable, so the server temp folder is used instead (' . $dir . ').',
             'Recommended: make storage/cache writable for PHP — the dashboards cache their data there too.');
    } else {
        $add('storage', 'Upload folder is writable', false, true, $rel(STORAGE_PATH . '/cache') . ' is not writable by PHP.',
             'In cPanel File Manager (or FTP), set the folders storage, storage/cache and storage/logs to permission 755 — or 775 if that is not enough — and make sure they belong to the site\'s user. Over SSH: chmod -R 775 storage');
    }

    // 2. database
    if (!$db) {
        $add('db', 'Lead database is reachable', false, true, $dbLabel . ' could not be opened.', 'Check LEAD_DATABASES in config/config.php.');
        return $out;
    }
    $add('db', 'Lead database is reachable', true, true, $dbLabel);

    // 3. lead table columns used
    $need = ['id', 'lead_status', 'sitevisit_status', 'campaignsource'];
    $missing = [];
    foreach ($need as $c) {
        try {
            $ok = $db->query("SELECT `{$c}` FROM `lead` LIMIT 0");
        } catch (Throwable $e) {
            $ok = false;
        }
        if (!$ok) {
            $missing[] = $c;
        }
    }
    $add('columns', 'Lead table has the needed columns', !$missing, true,
         $missing ? 'Missing: ' . implode(', ', $missing) : implode(', ', array_slice($need, 1)),
         $missing ? 'Add the missing column(s) to the `lead` table.' : '');

    // 4. leads that can be matched
    $counts = [];
    try {
        foreach (suIdColumns($db) as $c) {
            if ($c['suggested'] && $c['column'] !== 'id') {
                $counts[$c['column']] = $c['filled'];
            }
        }
    } catch (Throwable $e) {
    }
    $parts = [];
    foreach ($counts as $c => $n) {
        $parts[] = number_format($n) . ' with ' . $c;
    }
    $add('leads', 'Leads to match against', array_sum($counts) > 0, false,
         $parts ? implode(' · ', $parts) : 'No lead columns found',
         array_sum($counts) > 0 ? '' : 'No leads have a mobile, email or unique ID yet, so nothing can be matched.');

    // 5. history / undo tables
    try {
        suEnsureLogTables($db);
        $ok = (bool) $db->query('SELECT id FROM `lead_status_uploads` LIMIT 0');
    } catch (Throwable $e) {
        $ok = false;
    }
    $add('log', 'Upload history (for Undo) can be saved', $ok, true,
         $ok ? 'Tables lead_status_uploads / lead_status_upload_rows' : 'Could not create the history tables: ' . $db->error,
         $ok ? '' : 'The database user needs CREATE and ALTER rights, or create the two tables by hand (see docs/STRUCTURE.md).');

    // 6. file types
    $zip = class_exists('ZipArchive');
    $add('xlsx', 'Excel files can be read', true, false,
         $zip ? '.csv and .xlsx on the server · .xls in the browser' : '.csv on the server · .xlsx / .xls are converted in the browser (PHP zip extension is off)');

    // 7. size limit
    $max = min(suIniBytes((string) ini_get('upload_max_filesize')) ?: PHP_INT_MAX, suIniBytes((string) ini_get('post_max_size')) ?: PHP_INT_MAX);
    $add('size', 'Largest file allowed', $max >= 2 * 1024 * 1024, false,
         $max === PHP_INT_MAX ? 'No limit set' : round($max / 1048576, 1) . ' MB (upload_max_filesize / post_max_size)',
         $max >= 2 * 1024 * 1024 ? '' : 'Raise upload_max_filesize and post_max_size in php.ini (cPanel → MultiPHP INI Editor) for big exports.');
    return $out;
}

function suLoadUpload(string $token): array
{
    $p = suTmpPath($token);
    $d = is_file($p) ? json_decode((string) file_get_contents($p), true) : null;
    if (!is_array($d)) {
        throw new InvalidArgumentException('Upload expired — please upload the file again.');
    }
    return $d;
}

/* ------------------------------------------------------------------ guessing / values */

function suNorm(string $s): string
{
    return trim(preg_replace('/[^a-z0-9]+/', ' ', strtolower($s)));
}

/** Best guess of the file column for each field. */
function suGuessColumns(array $headers): array
{
    $find = function (array $want, array $avoid = []) use ($headers): ?int {
        foreach ($want as $w) {
            foreach ($headers as $i => $h) {
                $n = suNorm($h);
                foreach ($avoid as $a) {
                    if (str_contains($n, $a)) {
                        continue 2;
                    }
                }
                if ($n === $w || str_contains($n, $w)) {
                    return $i;
                }
            }
        }
        return null;
    };
    return [
        'mobile'    => $find(['mobile', 'phone', 'contact number', 'mobile number', 'contact'], ['whatsapp', 'alternate']),
        'uniqueid'  => $find(['uniqueid', 'unique id', 'lead id', 'leadid', 'lead uid', 'enquiry id']),
        'email'     => $find(['email', 'e mail', 'mail id', 'mail'], ['alternate', 'secondary']),
        'status'    => $find(['lead status', 'status'], ['site', 'visit', 'sub']),
        'sitevisit' => $find(['site visit done', 'sitevisit status', 'site visit status', 'site visit', 'sitevisit', 'visit done', 'walk in', 'walkin']),
        'mql'       => $find(['mql', 'marketing qualified']),
        'platform'  => $find(['platform', 'campaign source', 'campaignsource', 'sub source category', 'lead source detail', 'channel', 'source']),
    ];
}

/** Default choice (a key of SU_FIELDS[$field]['options']) for a file value, or '' = leave the lead as it is. */
function suDefaultChoice(string $field, string $value): string
{
    $n = suNorm($value);
    if ($n === '') {
        return '';
    }
    if ($field === 'status') {
        if (preg_match('/\b(un ?qualified|non ?qualified|not qualified|disqualified|junk|dnd|invalid|spam|fake|not interested|lost|duplicate|wrong)\b/', $n)) {
            return 'NON-QUALIFIED';
        }
        if (preg_match('/\b(to be qualified|tbq|pending|new|open|contacted|follow ?up|callback|call back|not contacted|ringing|in progress|nurture)\b/', $n)) {
            return 'TO BE QUALIFIED';
        }
        if (preg_match('/\b(qualified|mql|sql|hot|warm|interested)\b/', $n)) {
            return 'QUALIFIED';
        }
        return '';
    }
    if ($field === 'sitevisit') {
        if (in_array($n, ['1', 'yes', 'y', 'true', 'done', 'visited', 'visit done', 'site visit done', 'completed', 'conducted'], true)) {
            return 'Yes';
        }
        if (in_array($n, ['0', 'no', 'n', 'false', 'not visited', 'pending', 'not done'], true)) {
            return 'No';
        }
        return '';
    }
    // platform
    if (preg_match('/\b(google|adwords|search|ppc|sem|youtube|pmax|performance max|display|discovery|gdn)\b/', $n)) {
        return 'Google';
    }
    if (preg_match('/\b(meta|facebook|fb|instagram|ig|social media|lead form)\b/', $n)) {
        return 'Meta';
    }
    return '';
}

/** Is the MQL column offered on Upload Lead Status? Off by default; define('STATUS_UPLOAD_MQL', true) in config.php brings it back. */
function suMqlEnabled(): bool
{
    return defined('STATUS_UPLOAD_MQL') && STATUS_UPLOAD_MQL;
}

/** MQL cell → true (1 / yes / true), false (0 / no / false) or null (empty / unreadable). */
function suMqlValue(string $v): ?bool
{
    $n = suNorm($v);
    if (in_array($n, ['1', '1 0', 'yes', 'y', 'true', 'mql'], true)) {
        return true;
    }
    if (in_array($n, ['0', '0 0', 'no', 'n', 'false'], true)) {
        return false;
    }
    return null;
}

/** Value written for a choice ('' = no change). */
function suWriteValue(string $field, string $choice): string
{
    return SU_FIELDS[$field]['options'][$choice] ?? '';
}

/** Does this stored value count for CPQL / CPSV? */
function suCounts(string $field, ?string $stored): bool
{
    $u = strtoupper(trim((string) $stored));
    if ($field === 'status') {
        return in_array($u, SU_QUALIFIED_VALUES, true);
    }
    if ($field === 'sitevisit') {
        return in_array($u, SU_SITEVISIT_VALUES, true);
    }
    return false;
}

/**
 * The platform the lead's own ad tracking proves: Meta lead form id → 'meta', Google click id / campaign id → 'google'.
 * An upload never moves a lead away from this (the CRM's source column is often wrong).
 */
function suTrackedPlatform(array $lead): string
{
    if (trim((string) ($lead['leadgen_id'] ?? '')) !== '') {
        return 'meta';
    }
    if (trim((string) ($lead['gclid'] ?? '')) !== '' || trim((string) ($lead['utm_campaignid'] ?? '')) !== '') {
        return 'google';
    }
    return '';
}

/** 'meta' | 'google' | '' for a campaignsource value. */
function suPlatformFamily(?string $source): string
{
    $s = strtolower(trim((string) $source));
    if (in_array($s, SU_META_SOURCES, true)) {
        return 'meta';
    }
    if (in_array($s, SU_GOOGLE_SOURCES, true)) {
        return 'google';
    }
    return '';
}

/** Distinct values of a column with counts and the default choice. */
function suDistinct(array $data, int $col, string $field): array
{
    $c = [];
    foreach ($data as $r) {
        $v = trim((string) ($r['cells'][$col] ?? ''));
        $c[$v] = ($c[$v] ?? 0) + 1;
    }
    arsort($c);
    $out = [];
    foreach ($c as $v => $n) {
        $v = (string) $v;
        $choice = suDefaultChoice($field, $v);
        $out[] = ['value' => $v, 'rows' => $n, 'choice' => $choice];
        if (count($out) >= 200) {
            break;
        }
    }
    return $out;
}

/* ------------------------------------------------------------------ matching */

function suNormMobile(?string $m): string
{
    $d = preg_replace('/\D+/', '', (string) $m);
    return strlen($d) > 10 ? substr($d, -10) : $d;
}

/** How a lead column is compared: 'mobile' (last 10 digits), 'email' (trimmed, lower case) or 'text' (trimmed, lower case). */
function suIdKind(string $column): string
{
    $c = strtolower($column);
    if (preg_match('/mobile|phone|whatsapp|contact_?no|contactnumber/', $c)) {
        return 'mobile';
    }
    return str_contains($c, 'mail') ? 'email' : 'text';
}

function suNormKey(string $idType, ?string $v): string
{
    $kind = suIdKind($idType);
    if ($kind === 'mobile') {
        return suNormMobile($v);
    }
    $v = mb_strtolower(trim((string) $v));
    if ($kind === 'email') {
        $v = preg_replace('/^mailto:/', '', preg_replace('/\s+/', '', $v));
    }
    return $v;
}

/** Is this key usable? (mobile: at least 6 digits; email: has an @) */
function suKeyOk(string $idType, string $key): bool
{
    if ($key === '') {
        return false;
    }
    return match (suIdKind($idType)) {
        'mobile' => strlen($key) >= 6,
        'email'  => str_contains($key, '@'),
        default  => true,
    };
}

/** Name for the ID in messages ("mobile number", "email", "unique ID", or the column name). */
function suIdLabel(string $idType): string
{
    return match ($idType) {
        'mobile' => 'mobile number',
        'uniqueid' => 'unique ID',
        'email' => 'email',
        default => $idType,
    };
}

/** Columns that are commonly good IDs, in the order they are offered. */
const SU_SUGGESTED_IDS = ['mobile', 'email', 'uniqueid', 'leadgen_id', 'gclid', 'id'];
/** Lead columns never offered as an ID (status / dates / long text). */
const SU_ID_SKIP = ['lead_status', 'sitevisit_status', 'campaignsource', 'campaignsubsource', 'createddate', 'updateddate', 'crm_response', 'response'];

/**
 * Every column of the lead table that can be used to match, with how many leads have a value and how many values
 * appear on more than one lead. @return array<int, array{column:string, kind:string, filled:int, suggested:bool}>
 */
function suIdColumns(mysqli $db): array
{
    static $cache = [];
    $key = spl_object_id($db);
    if (isset($cache[$key])) {
        return $cache[$key];
    }
    $res = $db->query('SHOW COLUMNS FROM `lead`');
    if (!$res) {
        throw new RuntimeException('Could not read the lead table columns: ' . $db->error);
    }
    $cols = [];
    while ($r = $res->fetch_assoc()) {
        $name = (string) ($r['Field'] ?? '');
        $type = strtolower((string) ($r['Type'] ?? ''));
        if ($name === '' || !preg_match('/^[A-Za-z0-9_]{1,64}$/', $name) || in_array(strtolower($name), SU_ID_SKIP, true)
            || preg_match('/(text|blob|json|date|time)/', $type)) {
            continue;
        }
        $cols[] = $name;
    }
    $out = [];
    if ($cols) {
        // one pass over the table for all the counts
        $sel = implode(', ', array_map(fn($c, $i) => "SUM(CASE WHEN `{$c}` IS NOT NULL AND TRIM(`{$c}`) <> '' THEN 1 ELSE 0 END) AS c{$i}", $cols, array_keys($cols)));
        $row = ($q = $db->query("SELECT {$sel} FROM `lead`")) ? $q->fetch_assoc() : [];
        foreach ($cols as $i => $c) {
            $out[] = ['column' => $c, 'kind' => suIdKind($c), 'filled' => (int) ($row['c' . $i] ?? 0),
                      'suggested' => in_array(strtolower($c), SU_SUGGESTED_IDS, true)];
        }
    }
    $rank = fn($c) => [($p = array_search(strtolower($c['column']), SU_SUGGESTED_IDS, true)) === false ? 99 : $p, $c['filled'] > 0 ? 0 : 1, $c['column']];
    usort($out, fn($a, $b) => $rank($a) <=> $rank($b));
    return $cache[$key] = $out;
}

/** Throws unless $col is a real, allowed lead column. Returns it with the table's own spelling. */
function suCheckIdColumn(mysqli $db, string $col): string
{
    foreach (suIdColumns($db) as $c) {
        if (strcasecmp($c['column'], $col) === 0) {
            return $c['column'];
        }
    }
    throw new InvalidArgumentException('"' . $col . '" is not a column of the lead table that can be matched on.');
}

/** Leads of one database indexed by the chosen ID column. */
function suLeadIndex(mysqli $db, string $idType): array
{
    $col = suCheckIdColumn($db, $idType);
    $track = '';
    foreach (['leadgen_id', 'gclid', 'utm_campaignid'] as $tc) {
        try {
            if (@$db->query("SELECT `{$tc}` FROM `lead` LIMIT 0")) {
                $track .= ", `{$tc}`";
            }
        } catch (Throwable $e) {
        }
    }
    $res = $db->query("SELECT id, name, `{$col}` AS k, lead_status, sitevisit_status, campaignsource, createddate{$track} FROM `lead` WHERE `{$col}` IS NOT NULL AND TRIM(`{$col}`) <> ''");
    if (!$res) {
        throw new RuntimeException('Could not read the lead table: ' . $db->error);
    }
    $idx = [];
    while ($r = $res->fetch_assoc()) {
        $k = suNormKey($idType, $r['k']);
        if (!suKeyOk($idType, $k)) {
            continue;
        }
        $idx[$k][] = $r;
    }
    return $idx;
}

/** Quick test of an ID choice: how many file rows find a lead. */
function suIdTest(mysqli $db, array $upload, string $idType, int $idCol): array
{
    $index = suLeadIndex($db, $idType);
    $s = ['rows' => count($upload['data']), 'matched' => 0, 'not_found' => 0, 'blank' => 0, 'multi' => 0, 'looks_cut' => 0, 'examples' => []];
    foreach ($upload['data'] as $r) {
        $raw = trim((string) ($r['cells'][$idCol] ?? ''));
        $k = suNormKey($idType, $raw);
        if (!suKeyOk($idType, $k)) {
            $s['blank']++;
            continue;
        }
        if (isset($index[$k])) {
            $s['matched']++;
            if (count($index[$k]) > 1) {
                $s['multi']++;
            }
            continue;
        }
        $s['not_found']++;
        if (suIdKind($idType) === 'email' && !preg_match('/@[^@]+\.[a-z]{2,}$/', $k)) {
            $s['looks_cut']++;
        }
        if (count($s['examples']) < 5) {
            $s['examples'][] = suIdKind($idType) === 'mobile' && function_exists('pqContact') ? pqContact($raw, 'mobile') : $raw;   // last 5 digits only
        }
    }
    return $s;
}

/** Validates the mapping sent by the page. */
function suConfig(array $in, array $headers): array
{
    $idType = is_string($in['id_type'] ?? null) && preg_match('/^[A-Za-z0-9_]{1,64}$/', $in['id_type']) ? $in['id_type'] : null;
    if (!$idType) {
        throw new InvalidArgumentException('Choose the lead column to match on (mobile, email, uniqueid, …).');
    }
    $col = function ($k) use ($in, $headers): ?int {
        if (!isset($in[$k]) || $in[$k] === '' || $in[$k] === null) {
            return null;
        }
        $i = (int) $in[$k];
        if ($i < 0 || $i >= count($headers)) {
            throw new InvalidArgumentException('Unknown column selected.');
        }
        return $i;
    };
    $cfg = ['id_type' => $idType, 'id_col' => $col('id_col'), 'cols' => [], 'maps' => [], 'mql_col' => suMqlEnabled() ? $col('mql_col') : null];
    if ($cfg['mql_col'] !== null && $cfg['mql_col'] === $cfg['id_col']) {
        throw new InvalidArgumentException('The ID column cannot also be the MQL column.');
    }
    if ($cfg['id_col'] === null) {
        throw new InvalidArgumentException('Choose the file column that holds the ' . suIdLabel($idType) . '.');
    }
    foreach (array_keys(SU_FIELDS) as $f) {
        $cfg['cols'][$f] = $col($f . '_col');
        $cfg['maps'][$f] = [];
        foreach ((array) ($in[$f . '_map'] ?? []) as $from => $choice) {
            $choice = (string) $choice;
            if ($choice !== '' && !isset(SU_FIELDS[$f]['options'][$choice])) {
                throw new InvalidArgumentException(SU_FIELDS[$f]['label'] . ': "' . $choice . '" is not an allowed value.');
            }
            $cfg['maps'][$f][(string) $from] = $choice;
        }
        if ($cfg['cols'][$f] !== null && $cfg['cols'][$f] === $cfg['id_col']) {
            throw new InvalidArgumentException('The ID column cannot also be the ' . strtolower(SU_FIELDS[$f]['label']) . ' column.');
        }
    }
    if (!array_filter($cfg['cols'], fn($c) => $c !== null) && $cfg['mql_col'] === null) {
        throw new InvalidArgumentException('Choose at least one column to import: lead status, ' . (suMqlEnabled() ? 'MQL, ' : '') . 'site visit or platform.');
    }
    return $cfg;
}

/**
 * Works out every change. Nothing is written.
 * changes: lead id => ['id', 'set' => [field => new value], 'old' => [field => old value]]
 */
function suPlan(mysqli $db, array $upload, array $cfg): array
{
    $cfg['id_type'] = suCheckIdColumn($db, $cfg['id_type']);
    $index = suLeadIndex($db, $cfg['id_type']);
    $fields = array_keys(array_filter($cfg['cols'], fn($c) => $c !== null));
    $mqlCol = $cfg['mql_col'] ?? null;
    if (($mqlCol !== null || in_array('sitevisit', $fields, true)) && !in_array('status', $fields, true)) {
        array_unshift($fields, 'status');     // MQL / site visit only → it still writes lead_status (site visit → QUALIFIED)
    }
    $choiceOf = function (string $f, string $v) use ($cfg): string {
        return array_key_exists($v, $cfg['maps'][$f]) ? $cfg['maps'][$f][$v] : suDefaultChoice($f, $v);
    };

    $seen = [];
    $items = [];
    $changes = [];
    $s = ['rows' => count($upload['data']), 'blank_id' => 0, 'not_found' => 0, 'matched_rows' => 0, 'leads_matched' => 0,
          'leads_to_update' => 0, 'unchanged' => 0, 'duplicates_in_file' => 0, 'multi_lead_rows' => 0,
          'status_changes' => 0, 'sitevisit_changes' => 0, 'platform_changes' => 0, 'platform_kept' => 0,
          'new_qualified' => 0, 'lost_qualified' => 0, 'lost_post_qualified' => 0, 'new_sitevisits' => 0, 'lost_sitevisits' => 0, 'unmapped_values' => 0,
          'mql_used' => $mqlCol !== null, 'mql_rows' => 0, 'sv_qualified_rows' => 0, 'looks_cut' => 0, 'id_label' => suIdLabel($cfg['id_type'])];

    /*
     * The same person (same ID) more than once in the file — e.g. two enquiries, one "Site Visit Done" and one "Lost":
     * the row with the best outcome is used (site visit > qualified > anything else); on a tie, the lower row, as before.
     * So a site visit or a qualified lead is never undone by a second, weaker enquiry of the same person.
     */
    $rank = function (array $r) use ($cfg, $choiceOf, $mqlCol): int {
        $val = fn(string $f) => ($c = $cfg['cols'][$f] ?? null) === null ? '' : $choiceOf($f, trim((string) ($r['cells'][$c] ?? '')));
        $status = $val('status');
        if ($mqlCol !== null && suMqlValue(trim((string) ($r['cells'][$mqlCol] ?? ''))) === true) {
            $status = 'QUALIFIED';
        }
        $sv = suCounts('sitevisit', suWriteValue('sitevisit', $val('sitevisit')));
        return ($sv ? 2 : 0) + ($sv || suCounts('status', $status) ? 1 : 0);
    };
    $best = [];        // key => [rank, row index]
    foreach ($upload['data'] as $i => $r) {
        $k = suNormKey($cfg['id_type'], trim((string) ($r['cells'][$cfg['id_col']] ?? '')));
        if (!suKeyOk($cfg['id_type'], $k)) {
            continue;
        }
        $rk = $rank($r);
        if (!isset($best[$k]) || $rk >= $best[$k][0]) {
            $best[$k] = [$rk, $i, $r['n']];
        }
    }

    foreach ($upload['data'] as $ri => $r) {
        $rawId = trim((string) ($r['cells'][$cfg['id_col']] ?? ''));
        $key = suNormKey($cfg['id_type'], $rawId);
        $file = [];
        $choice = [];
        foreach ($fields as $f) {
            $c = $cfg['cols'][$f];
            $file[$f] = $c === null ? '' : trim((string) ($r['cells'][$c] ?? ''));
            $choice[$f] = $c === null ? '' : $choiceOf($f, $file[$f]);
            if ($f === 'status' && $mqlCol !== null) {
                $mv = trim((string) ($r['cells'][$mqlCol] ?? ''));
                $mql = suMqlValue($mv);
                if ($mql === true) {
                    $choice[$f] = 'QUALIFIED';         // MQL = 1 always means Qualified
                    $s['mql_rows']++;
                } elseif ($mql === false && $c === null) {
                    $choice[$f] = 'NON-QUALIFIED';
                }
                if ($mv !== '') {
                    $file[$f] = ($file[$f] !== '' ? $file[$f] . ' · ' : '') . 'MQL ' . $mv;
                }
            }
            if ($file[$f] !== '' && $choice[$f] === '') {
                $s['unmapped_values']++;
            }
        }
        // a site visit is always a qualified lead: Site visit = Yes → lead status QUALIFIED, whatever the status column says
        if (isset($choice['sitevisit']) && suCounts('sitevisit', suWriteValue('sitevisit', $choice['sitevisit']))
            && !suCounts('status', $choice['status'] ?? '')) {
            $choice['status'] = 'QUALIFIED';
            $s['sv_qualified_rows']++;
        }
        $item = ['row' => $r['n'], 'id' => $rawId, 'file' => $file, 'choice' => $choice, 'leads' => []];

        if (!suKeyOk($cfg['id_type'], $key)) {
            $s['blank_id']++;
            $items[] = $item + ['state' => 'blank'];
            continue;
        }
        if (($best[$key][1] ?? $ri) !== $ri) {
            // another row of the same person is used (better outcome, or the lower row on a tie)
            $s['duplicates_in_file']++;
            $items[] = $item + ['state' => 'dup', 'note' => 'Same ' . suIdLabel($cfg['id_type']) . ' again in row ' . $best[$key][2]
                . ' — that row is used' . ($best[$key][0] > 0 ? ' (it has the ' . ($best[$key][0] >= 2 ? 'site visit' : 'qualified status') . ')' : '')];
            continue;
        }
        $leads = $index[$key] ?? [];
        if (!$leads) {
            $s['not_found']++;
            if (suIdKind($cfg['id_type']) === 'email' && !preg_match('/@[^@]+\.[a-z]{2,}$/', $key)) {
                $s['looks_cut']++;
                $item['note'] = 'This email looks cut off (no full domain at the end)';
            }
            $items[] = $item + ['state' => 'notfound'];
            continue;
        }
        $s['matched_rows']++;
        if (count($leads) > 1) {
            $s['multi_lead_rows']++;
        }
        $rowChanged = false;
        foreach ($leads as $l) {
            $set = [];
            $old = [];
            $view = ['id' => (int) $l['id'], 'name' => (string) $l['name'], 'date' => substr((string) $l['createddate'], 0, 10)];
            foreach ($fields as $f) {
                $cur = $l[SU_FIELDS[$f]['column']];
                $new = suWriteValue($f, $choice[$f]);
                if ($f === 'status' && $new === 'NON-QUALIFIED' && in_array(strtoupper(trim((string) $cur)), SU_QUALIFIED_VALUES, true)) {
                    // was Qualified, now not: Lost post qualified (one that already is stays as it is)
                    $new = strtoupper(trim((string) $cur)) === 'QUALIFIED' ? SU_LOST_POST_QUALIFIED : (string) $cur;
                }
                $change = $new !== '' && (string) $cur !== $new;
                if ($f === 'platform' && $change) {
                    // only move a lead between platforms; keep e.g. "Facebook Lead Form" vs "Instagram" as it is
                    $change = suPlatformFamily($cur) !== suPlatformFamily($new);
                    $tracked = suTrackedPlatform($l);
                    if ($change && $tracked !== '' && suPlatformFamily($new) !== $tracked) {
                        $change = false;   // the lead's own Meta / Google tracking wins over the file
                        $s['platform_kept']++;
                        $item['note'] = 'Platform kept: this lead has ' . ($tracked === 'meta' ? 'a Meta lead form id' : 'Google click tracking') . ', so it stays ' . ($tracked === 'meta' ? 'Meta' : 'Google');
                    }
                }
                $view['old_' . $f] = $cur;
                $view['new_' . $f] = $change ? $new : null;
                if ($change) {
                    $set[$f] = $new;
                    $old[$f] = $cur;
                }
            }
            $item['leads'][] = $view;
            $id = (int) $l['id'];
            if ($set) {
                $changes[$id] = ['id' => $id, 'set' => $set, 'old' => $old];
                $rowChanged = true;
            } else {
                unset($changes[$id]);     // a later duplicate row may make it unchanged again
            }
        }
        $items[] = $item + ['state' => $rowChanged ? 'change' : 'same'];
    }

    foreach ($items as $it) {
        if ($it['state'] === 'same') {
            $s['unchanged']++;
        }
    }
    foreach ($changes as $c) {
        foreach ($c['set'] as $f => $new) {
            $s[$f . '_changes']++;
            if ($f === 'status' || $f === 'sitevisit') {
                $was = suCounts($f, (string) $c['old'][$f]);
                $now = suCounts($f, $new);
                $k = $f === 'status' ? 'qualified' : 'sitevisits';
                if ($now && !$was) {
                    $s['new_' . $k]++;
                } elseif ($was && !$now) {
                    $s['lost_' . $k]++;
                }
                if ($f === 'status' && $new === SU_LOST_POST_QUALIFIED) {
                    $s['lost_post_qualified']++;
                }
            }
        }
    }
    $s['leads_matched'] = array_sum(array_map(fn($it) => count($it['leads']), $items));
    $s['leads_to_update'] = count($changes);
    ksort($changes);
    $hash = hash('sha256', json_encode([$fields, array_values($changes)]));
    return ['summary' => $s, 'fields' => $fields, 'items' => $items, 'changes' => $changes, 'hash' => $hash];
}

/* ------------------------------------------------------------------ write + log + undo */

function suEnsureLogTables(mysqli $db): void
{
    $db->query("CREATE TABLE IF NOT EXISTS `lead_status_uploads` (
        `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        `created_at` DATETIME NOT NULL,
        `created_by` VARCHAR(100) NULL,
        `file_name` VARCHAR(255) NULL,
        `id_type` VARCHAR(20) NOT NULL,
        `rows_in_file` INT NOT NULL DEFAULT 0,
        `leads_updated` INT NOT NULL DEFAULT 0,
        `summary` TEXT NULL,
        `undone_at` DATETIME NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $db->query("CREATE TABLE IF NOT EXISTS `lead_status_upload_rows` (
        `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        `upload_id` INT UNSIGNED NOT NULL,
        `lead_id` INT NOT NULL,
        `old_status` VARCHAR(50) NULL,
        `new_status` VARCHAR(50) NULL,
        `old_sitevisit` TEXT NULL,
        `new_sitevisit` TEXT NULL,
        `old_source` VARCHAR(45) NULL,
        `new_source` VARCHAR(45) NULL,
        KEY `upload_id` (`upload_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    // tables created by the first version have no platform columns yet
    try {
        $ok = $db->query('SELECT old_source FROM `lead_status_upload_rows` LIMIT 0');
    } catch (Throwable $e) {
        $ok = false;
    }
    if (!$ok) {
        $db->query('ALTER TABLE `lead_status_upload_rows` ADD COLUMN `old_source` VARCHAR(45) NULL');
        $db->query('ALTER TABLE `lead_status_upload_rows` ADD COLUMN `new_source` VARCHAR(45) NULL');
    }
}

const SU_LOG_COLS = ['status' => ['old_status', 'new_status'], 'sitevisit' => ['old_sitevisit', 'new_sitevisit'], 'platform' => ['old_source', 'new_source']];

/** Applies a plan in one transaction and logs it. Returns the upload ID. */
function suCommit(mysqli $db, array $plan, array $upload, array $cfg, string $user): int
{
    suEnsureLogTables($db);
    $db->begin_transaction();
    try {
        $now = date('Y-m-d H:i:s');
        $summary = json_encode($plan['summary'] + ['fields' => $plan['fields']]);
        $file = mb_substr((string) $upload['file_name'], 0, 255);
        $rows = (int) $plan['summary']['rows'];
        $n = count($plan['changes']);
        $st = $db->prepare('INSERT INTO `lead_status_uploads` (created_at, created_by, file_name, id_type, rows_in_file, leads_updated, summary) VALUES (?, ?, ?, ?, ?, ?, ?)');
        $idt = mb_substr((string) $cfg['id_type'], 0, 20);     // the matched lead column
        $st->bind_param('ssssiis', $now, $user, $file, $idt, $rows, $n, $summary);
        $st->execute();
        $st->close();
        $uploadId = 0;
        try {
            $uploadId = (int) $db->insert_id;
        } catch (Throwable $e) {
            // some drivers / test doubles don't expose insert_id — fall back below
        }
        if ($uploadId <= 0) {
            $r = $db->query('SELECT MAX(id) AS id FROM `lead_status_uploads`');
            $uploadId = (int) ($r ? $r->fetch_assoc()['id'] : 0);
        }

        $log = $db->prepare('INSERT INTO `lead_status_upload_rows` (upload_id, lead_id, old_status, new_status, old_sitevisit, new_sitevisit, old_source, new_source) VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
        if (!$log) {
            throw new RuntimeException('Could not prepare the upload log: ' . $db->error);
        }
        $updates = [];   // one prepared UPDATE per combination of fields
        foreach ($plan['changes'] as $c) {
            $id = (int) $c['id'];
            $fieldsSet = array_keys($c['set']);
            $sig = implode(',', $fieldsSet);
            if (!isset($updates[$sig])) {
                $sql = 'UPDATE `lead` SET ' . implode(', ', array_map(fn($f) => SU_FIELDS[$f]['column'] . ' = ?', $fieldsSet)) . ' WHERE id = ?';
                $updates[$sig] = $db->prepare($sql);
                if (!$updates[$sig]) {
                    throw new RuntimeException('Could not prepare the update: ' . $db->error);
                }
            }
            $vals = array_values($c['set']);
            $vals[] = $id;
            $types = str_repeat('s', count($fieldsSet)) . 'i';
            $updates[$sig]->bind_param($types, ...$vals);
            if (!$updates[$sig]->execute()) {
                throw new RuntimeException("Lead {$id} could not be updated: " . $db->error);
            }
            $l = [];
            foreach (SU_LOG_COLS as $f => [$o, $nw]) {
                $l[$o] = array_key_exists($f, $c['set']) ? $c['old'][$f] : null;
                $l[$nw] = $c['set'][$f] ?? null;
            }
            $log->bind_param('iissssss', $uploadId, $id, $l['old_status'], $l['new_status'], $l['old_sitevisit'], $l['new_sitevisit'], $l['old_source'], $l['new_source']);
            $log->execute();
        }
        foreach ($updates as $u) {
            $u->close();
        }
        $log->close();
        $db->commit();
        return $uploadId;
    } catch (Throwable $e) {
        $db->rollback();
        throw $e;
    }
}

function suHistory(mysqli $db, int $limit = 15): array
{
    $res = @$db->query("SHOW TABLES LIKE 'lead_status_uploads'");
    if (!$res || $res->num_rows === 0) {
        return [];
    }
    $out = [];
    $res = $db->query('SELECT id, created_at, created_by, file_name, id_type, rows_in_file, leads_updated, summary, undone_at FROM `lead_status_uploads` ORDER BY id DESC LIMIT ' . (int) $limit);
    while ($res && ($r = $res->fetch_assoc())) {
        $sum = json_decode((string) ($r['summary'] ?? ''), true) ?: [];
        $r['fields'] = $sum['fields'] ?? array_values(array_filter(['status', 'sitevisit'], fn($f) => !empty($sum[$f . '_changes'])));
        unset($r['summary']);
        $out[] = $r;
    }
    return $out;
}

/** Puts the old values back — only on leads still holding the uploaded value (later edits are kept). */
function suUndo(mysqli $db, int $uploadId): array
{
    suEnsureLogTables($db);
    $st = $db->prepare('SELECT undone_at FROM `lead_status_uploads` WHERE id = ?');
    $st->bind_param('i', $uploadId);
    $st->execute();
    $row = $st->get_result()->fetch_assoc();
    $st->close();
    if (!$row) {
        throw new InvalidArgumentException('Upload not found.');
    }
    if (!empty($row['undone_at'])) {
        throw new InvalidArgumentException('This upload was already undone.');
    }
    $db->begin_transaction();
    try {
        $st = $db->prepare('SELECT r.*, l.lead_status AS cur_status, l.sitevisit_status AS cur_sitevisit, l.campaignsource AS cur_platform
                            FROM `lead_status_upload_rows` r JOIN `lead` l ON l.id = r.lead_id WHERE r.upload_id = ?');
        $st->bind_param('i', $uploadId);
        $st->execute();
        $res = $st->get_result();
        $restored = 0;
        $kept = 0;
        $up = [];
        foreach (SU_FIELDS as $f => $def) {
            $up[$f] = $db->prepare('UPDATE `lead` SET ' . $def['column'] . ' = ? WHERE id = ?');
        }
        while ($r = $res->fetch_assoc()) {
            $id = (int) $r['lead_id'];
            $did = false;
            foreach (SU_LOG_COLS as $f => [$o, $nw]) {
                if (!array_key_exists($nw, $r) || $r[$nw] === null) {
                    continue;
                }
                if ((string) $r['cur_' . $f] === (string) $r[$nw]) {
                    $v = $r[$o];
                    $up[$f]->bind_param('si', $v, $id);
                    $up[$f]->execute();
                    $did = true;
                } else {
                    $kept++;
                }
            }
            $restored += $did ? 1 : 0;
        }
        $st->close();
        foreach ($up as $u) {
            $u->close();
        }
        $now = date('Y-m-d H:i:s');
        $st = $db->prepare('UPDATE `lead_status_uploads` SET undone_at = ? WHERE id = ?');
        $st->bind_param('si', $now, $uploadId);
        $st->execute();
        $st->close();
        $db->commit();
        return ['restored' => $restored, 'kept' => $kept];
    } catch (Throwable $e) {
        $db->rollback();
        throw $e;
    }
}
