<?php
/**
 * app/Leads/status_upload_multi.php — Upload Lead Status over EVERY lead database at once ("All databases").
 *
 * Each file row is matched in every database (LEAD_DATABASES), with the same mapping:
 *   - found in one database      → updated there;
 *   - found in several databases → the file's campaign column decides: the database whose lead campaign looks most
 *     like the file's campaign (and whose name — e.g. "Pseudo" / "Official" — appears in it) gets the update;
 *   - still undecided            → updated in every database where it was found ("all", default) or left alone ("skip").
 * Each database gets its own upload record, so history, undo and Meta CAPI keep working per database.
 * Single-database uploads still use suPlan() / suCommit() from status_upload.php unchanged.
 */

require_once __DIR__ . '/status_upload.php';
require_once dirname(__DIR__) . '/Ads/master_tables.php';   // pqCleanTrack

const SU_ALL = 'all';

/** @return array<string, mysqli> reachable lead databases */
function suAllDbs(): array
{
    $out = leadDbs('all');
    if (!$out) {
        throw new RuntimeException('No lead database is reachable.');
    }
    return $out;
}

function suCampNorm(string $s): string
{
    $s = strtolower(pqCleanTrack($s));
    $s = preg_replace('/[^a-z0-9]+/', ' ', $s);
    return trim(preg_replace('/\s+/', ' ', $s));
}

/** Similarity of two campaign names, 0..1 (word overlap, exact = 1). */
function suCampSim(string $a, string $b): float
{
    $a = suCampNorm($a);
    $b = suCampNorm($b);
    if ($a === '' || $b === '') {
        return 0.0;
    }
    if ($a === $b) {
        return 1.0;
    }
    $wa = array_unique(array_filter(explode(' ', $a), fn($w) => strlen($w) > 1));
    $wb = array_unique(array_filter(explode(' ', $b), fn($w) => strlen($w) > 1));
    if (!$wa || !$wb) {
        return 0.0;
    }
    $inter = count(array_intersect($wa, $wb));
    $union = count(array_unique(array_merge($wa, $wb)));
    $sim = $union ? $inter / $union : 0.0;
    if (str_contains($a, $b) || str_contains($b, $a)) {
        $sim = max($sim, 0.8);
    }
    return $sim;
}

/** Words that name a database ("pseudo", "official", "westgate"…) from its key and label. */
function suDbWords(string $key): array
{
    $w = explode(' ', suCampNorm($key . ' ' . leadDbLabel($key)));
    return array_values(array_unique(array_filter($w, fn($x) => strlen($x) > 2 && !in_array($x, ['campaign', 'campaigns', 'database', 'leads', 'lead', 'crm', 'the'], true))));
}

/**
 * Which databases a row found in several databases belongs to.
 * @param array<string, list<array>> $leadsByDb  db key => raw lead rows matched by this row
 * @return array{keys: list<string>, how: string}
 */
function suPickDbs(string $fileCampaign, array $leadsByDb): array
{
    $keys = array_keys($leadsByDb);
    $fc = suCampNorm($fileCampaign);
    if ($fc === '') {
        return ['keys' => $keys, 'how' => 'no_campaign'];
    }
    $score = [];
    $fileWords = explode(' ', $fc);
    foreach ($leadsByDb as $k => $leads) {
        $best = 0.0;
        foreach ($leads as $l) {
            foreach (['campaign_name', 'utm_campaignname', 'campaignsubsource'] as $col) {
                $best = max($best, suCampSim($fileCampaign, (string) ($l[$col] ?? '')));
            }
        }
        $hint = array_intersect(suDbWords($k), $fileWords) ? 0.6 : 0.0;
        $score[$k] = $best + $hint;
    }
    arsort($score);
    $ranked = array_keys($score);
    $top = $score[$ranked[0]];
    $second = $score[$ranked[1]] ?? 0.0;
    if ($top > 0.25 && $top - $second >= 0.15) {
        return ['keys' => [$ranked[0]], 'how' => 'campaign'];
    }
    return ['keys' => $keys, 'how' => 'undecided'];
}

/**
 * Plan over every database. Nothing is written.
 * @return array{plans: array<string, array>, items: list<array>, summary: array, fields: list<string>, hash: string}
 */
function suPlanAll(array $dbs, array $upload, array $cfg): array
{
    $plans = [];
    $byRow = [];
    foreach ($dbs as $k => $db) {
        $plans[$k] = suPlan($db, $upload, $cfg);
        foreach ($plans[$k]['items'] as $it) {
            $byRow[$it['row']][$k] = $it;
        }
    }
    $first = array_key_first($plans);
    $campCol = $cfg['campaign_col'] ?? null;
    $policy = ($cfg['multi_db'] ?? 'all') === 'skip' ? 'skip' : 'all';
    $cells = [];
    foreach ($upload['data'] as $r) {
        $cells[$r['n']] = $r['cells'];
    }
    $matchedStates = ['change', 'same', 'dup'];
    $drop = [];                      // db => lead ids whose change is not applied there
    $items = [];
    $extra = ['in_several_dbs' => 0, 'split_by_campaign' => 0, 'updated_in_all' => 0, 'skipped_undecided' => 0, 'per_db' => []];
    foreach ($byRow as $n => $perDb) {
        $hit = array_filter($perDb, fn($it) => in_array($it['state'], $matchedStates, true));
        if (!$hit) {
            $items[] = $perDb[$first] + ['dbs' => []];
            continue;
        }
        $keep = array_keys($hit);
        $note = '';
        if (count($hit) > 1) {
            $extra['in_several_dbs']++;
            $leadsByDb = [];
            foreach ($hit as $k => $it) {
                $leadsByDb[$k] = suRawLeads($dbs[$k], array_column($it['leads'], 'id'));
            }
            $fileCamp = $campCol === null ? '' : trim((string) ($cells[$n][$campCol] ?? ''));
            $pick = suPickDbs($fileCamp, $leadsByDb);
            if ($pick['how'] === 'campaign') {
                $keep = $pick['keys'];
                $extra['split_by_campaign']++;
                $note = 'In ' . implode(' and ', array_map('leadDbLabel', array_keys($hit))) . ' — the file\'s campaign matches ' . leadDbLabel($keep[0]);
            } elseif ($policy === 'skip') {
                $keep = [];
                $extra['skipped_undecided']++;
                $note = 'In ' . implode(' and ', array_map('leadDbLabel', array_keys($hit))) . ' — the campaign does not say which, so it is skipped';
            } else {
                $extra['updated_in_all']++;
                $note = 'In ' . implode(' and ', array_map('leadDbLabel', array_keys($hit))) . ' — ' . ($pick['how'] === 'no_campaign' ? 'no campaign to tell them apart' : 'the campaign does not say which') . ', so both are updated';
            }
            foreach ($hit as $k => $it) {
                if (!in_array($k, $keep, true)) {
                    foreach ($it['leads'] as $v) {
                        $drop[$k][(int) $v['id']] = true;
                    }
                }
            }
        }
        // merged row for the review: the chosen databases' leads, each tagged with its database
        $base = $hit[$keep[0] ?? array_key_first($hit)];
        $leads = [];
        $state = 'same';
        foreach ($keep as $k) {
            foreach ($hit[$k]['leads'] as $v) {
                $leads[] = $v + ['db' => leadDbLabel($k), 'db_key' => $k];
            }
            if ($hit[$k]['state'] === 'change') {
                $state = 'change';
            } elseif ($hit[$k]['state'] === 'dup' && $state !== 'change') {
                $state = 'dup';
            }
        }
        if (!$keep) {
            $state = 'skipped';
            foreach ($hit as $k => $it) {
                foreach ($it['leads'] as $v) {
                    $leads[] = $v + ['db' => leadDbLabel($k), 'db_key' => $k, 'skipped' => true];
                }
            }
        }
        $item = $base;
        $item['leads'] = $leads;
        $item['state'] = $state;
        $item['dbs'] = array_map('leadDbLabel', $keep);
        if ($note !== '') {
            $item['note'] = trim(($base['note'] ?? '') . ($base['note'] ?? '' ? ' · ' : '') . $note);
        }
        $items[] = $item;
    }
    // drop the changes that go to another database, then add everything up again
    foreach ($drop as $k => $ids) {
        foreach (array_keys($ids) as $id) {
            unset($plans[$k]['changes'][$id]);
        }
    }
    $s = $plans[$first]['summary'];          // file-level numbers (rows, blank ids, duplicates, MQL rows…) are the same everywhere
    foreach (['matched_rows', 'not_found', 'leads_matched', 'leads_to_update', 'unchanged', 'multi_lead_rows', 'status_changes', 'sitevisit_changes',
              'platform_changes', 'platform_kept', 'new_qualified', 'lost_qualified', 'lost_post_qualified', 'new_sitevisits', 'lost_sitevisits'] as $f) {
        $s[$f] = 0;
    }
    foreach ($items as $it) {
        if (in_array($it['state'], ['change', 'same', 'dup', 'skipped'], true)) {
            $s['matched_rows']++;
            $s['leads_matched'] += count($it['leads']);
        } elseif ($it['state'] === 'notfound') {
            $s['not_found']++;
        }
        if ($it['state'] === 'same') {
            $s['unchanged']++;
        }
        $perDbCount = [];                       // duplicates inside one database (a lead in two databases is not a duplicate)
        foreach ($it['leads'] as $v) {
            if (empty($v['skipped'])) {
                $perDbCount[$v['db_key'] ?? ''] = ($perDbCount[$v['db_key'] ?? ''] ?? 0) + 1;
            }
        }
        if ($perDbCount && max($perDbCount) > 1) {
            $s['multi_lead_rows']++;
        }
    }
    foreach ($plans as $k => $p) {
        $s['platform_kept'] += (int) $p['summary']['platform_kept'];
        $extra['per_db'][$k] = ['label' => leadDbLabel($k), 'leads_to_update' => count($p['changes'])];
        foreach ($p['changes'] as $c) {
            $s['leads_to_update']++;
            foreach ($c['set'] as $f => $new) {
                $s[$f . '_changes']++;
                if ($f === 'status' || $f === 'sitevisit') {
                    $was = suCounts($f, (string) $c['old'][$f]);
                    $now = suCounts($f, $new);
                    $kk = $f === 'status' ? 'qualified' : 'sitevisits';
                    if ($now && !$was) {
                        $s['new_' . $kk]++;
                    } elseif ($was && !$now) {
                        $s['lost_' . $kk]++;
                    }
                    if ($f === 'status' && $new === SU_LOST_POST_QUALIFIED) {
                        $s['lost_post_qualified']++;
                    }
                }
            }
        }
    }
    $s['all_dbs'] = $extra;
    $fields = $plans[$first]['fields'];
    $sig = [];
    foreach ($plans as $k => $p) {
        ksort($plans[$k]['changes']);
        $sig[$k] = array_values($plans[$k]['changes']);
    }
    ksort($sig);
    return ['plans' => $plans, 'items' => $items, 'summary' => $s, 'fields' => $fields,
            'hash' => hash('sha256', json_encode([$fields, $sig, $policy, $campCol]))];
}

/** Raw lead rows (campaign columns) by id. */
function suRawLeads(mysqli $db, array $ids): array
{
    $ids = array_values(array_filter(array_map('intval', $ids)));
    if (!$ids) {
        return [];
    }
    $out = [];
    $r = $db->query('SELECT * FROM `lead` WHERE id IN (' . implode(',', $ids) . ')');
    while ($r && ($l = $r->fetch_assoc())) {
        $out[] = $l;
    }
    return $out;
}

/** How many file rows find a lead in each database / in any database. */
function suIdTestAll(array $dbs, array $upload, string $idType, int $idCol): array
{
    $idx = [];
    foreach ($dbs as $k => $db) {
        $idx[$k] = suLeadIndex($db, $idType);
    }
    $s = ['rows' => count($upload['data']), 'matched' => 0, 'not_found' => 0, 'blank' => 0, 'multi' => 0, 'looks_cut' => 0, 'examples' => [],
          'in_several_dbs' => 0, 'per_db' => array_fill_keys(array_keys($dbs), 0)];
    foreach ($upload['data'] as $r) {
        $raw = trim((string) ($r['cells'][$idCol] ?? ''));
        $key = suNormKey($idType, $raw);
        if (!suKeyOk($idType, $key)) {
            $s['blank']++;
            continue;
        }
        $in = array_keys(array_filter($idx, fn($ix) => isset($ix[$key])));
        if ($in) {
            $s['matched']++;
            foreach ($in as $k) {
                $s['per_db'][$k]++;
            }
            if (count($in) > 1) {
                $s['in_several_dbs']++;
            }
            continue;
        }
        $s['not_found']++;
        if (suIdKind($idType) === 'email' && !preg_match('/@[^@]+\.[a-z]{2,}$/', $key)) {
            $s['looks_cut']++;
        }
        if (count($s['examples']) < 5) {
            $s['examples'][] = $raw;
        }
    }
    $s['per_db_labels'] = array_map('leadDbLabel', array_combine(array_keys($dbs), array_keys($dbs)));
    return $s;
}
