<?php
/**
 * app/Leads/missing_leads.php — "Add missing leads" for Upload Lead Status (the CRM feedback report).
 *
 * Rows of the feedback file whose lead is not in the lead table can be added as new leads:
 *   1. ml_from_upload()  builds one editable draft per not-found row from the file (name, mobile, email, campaign,
 *                        created date, lead status / site visit as the upload's mapping reads them, the matching ID)
 *   2. the page shows them in a table — every field can be edited, rows can be left out, one campaign source can be
 *      set for all of them — or downloads them as a CSV (ML_FIELDS headers) to add later
 *   3. ml_parse_file()   reads such a CSV / XLSX back (same headers), any time later
 *      With several lead databases every row has its own database (ml_assign_dbs guesses it from the campaign;
 *      the page can change it per row or for all rows); the leads are added database by database.
 *   4. ml_insert()       checks every row again (needs a mobile or email; skips leads already in the database, also
 *                        repeats inside the list), inserts them in one transaction and logs the new lead ids, so
 *   5. ml_undo()         can delete exactly those leads again (edited ones too; not once CRM Push has sent them).
 *
 * New leads get curlresponse = "imported from the CRM feedback report" — they came from the CRM, so CRM Push treats
 * them as already sent and never pushes them back.
 */

require_once __DIR__ . '/status_upload.php';
require_once __DIR__ . '/status_upload_multi.php';   // suCampNorm / suDbWords (which database a campaign belongs to)

/** Editable fields: key => [label (= CSV header), lead column(s)] */
const ML_FIELDS = [
    'name'             => ['Name', ['name']],
    'mobile'           => ['Mobile', ['mobile']],
    'email'            => ['Email', ['email']],
    'campaignsource'   => ['Campaign source', ['campaignsource']],
    'campaign'         => ['Campaign', ['campaign_name']],          // + utm_campaignname for Google sources
    'lead_status'      => ['Lead status', ['lead_status']],
    'sitevisit_status' => ['Site visit', ['sitevisit_status']],
    'createddate'      => ['Created date', ['createddate']],
    'uniqueid'         => ['Unique ID', ['uniqueid']],
];
const ML_STATUS = ['', 'QUALIFIED', 'NON-QUALIFIED', 'TO BE QUALIFIED', 'LOST POST QUALIFIED'];
const ML_SITEVISIT = ['', 'Visited', 'Not Visited'];
const ML_CRM_NOTE = '{"status":"success","success":true,"message":"Imported from the CRM feedback report (already in the CRM)","source":"feedback_import"}';
const ML_MAX_ROWS = 5000;

/* ------------------------------------------------------------------ build drafts */

/** File column for name / created date / campaign (null when the file has none). */
function ml_guess(array $headers): array
{
    $find = function (array $want, array $avoid = []) use ($headers): ?int {
        foreach ($want as $w) {
            foreach ($headers as $i => $h) {
                $n = suNorm((string) $h);
                foreach ($avoid as $a) {
                    if (str_contains($n, $a)) {
                        continue 2;
                    }
                }
                if ($n === $w || str_contains($n, $w)) {
                    return $i;
                }
            }
        }
        return null;
    };
    $g = suGuessColumns($headers);
    return [
        'name'        => $find(['full name', 'lead name', 'customer name', 'contact name', 'name', 'first name'],
                               ['campaign', 'project', 'source', 'owner', 'user', 'agent', 'created by', 'modified', 'file', 'ad name', 'adset', 'last name']),
        'last_name'   => $find(['last name', 'surname']),
        'createddate' => $find(['created date', 'created on', 'createddate', 'lead date', 'enquiry date', 'lead created', 'created time', 'date'],
                               ['modified', 'updated', 'visit', 'follow', 'next', 'last']),
        'campaign'    => $find(['campaign name', 'utm campaign', 'campaign'], ['source', 'id']),
        'mobile'      => $g['mobile'],
        'email'       => $g['email'],
        'uniqueid'    => $g['uniqueid'],
    ];
}

/** A date from the file as Y-m-d H:i:s ('' when it can't be read). Excel serials, dd/mm/yyyy, yyyy-mm-dd, "12 Oct 2026 …". */
function ml_date(string $v): string
{
    $v = trim($v);
    if ($v === '') {
        return '';
    }
    if (is_numeric($v) && (float) $v > 20000 && (float) $v < 80000) {          // Excel day number
        $ts = (int) round(((float) $v - 25569) * 86400);
        return gmdate('Y-m-d H:i:s', $ts);
    }
    if (preg_match('#^(\d{1,2})[/\-.](\d{1,2})[/\-.](\d{2,4})(?:[ T,]+(\d{1,2}):(\d{2})(?::(\d{2}))?\s*([ap]m)?)?$#i', $v, $m)) {   // dd/mm/yyyy (India)
        $y = strlen($m[3]) === 2 ? 2000 + (int) $m[3] : (int) $m[3];
        $h = (int) ($m[4] ?? 0);
        if (!empty($m[7])) {
            $h = $h % 12 + (strtolower($m[7]) === 'pm' ? 12 : 0);
        }
        if (checkdate((int) $m[2], (int) $m[1], $y)) {
            return sprintf('%04d-%02d-%02d %02d:%02d:%02d', $y, $m[2], $m[1], $h, (int) ($m[5] ?? 0), (int) ($m[6] ?? 0));
        }
    }
    $ts = strtotime(str_replace(',', ' ', $v));
    return $ts ? date('Y-m-d H:i:s', $ts) : '';
}

/** Mobile as stored: digits, Indian numbers without 91 / 0 in front. */
function ml_mobile(string $v): string
{
    $d = preg_replace('/\D+/', '', $v);
    if (strlen($d) === 12 && str_starts_with($d, '91')) {
        $d = substr($d, 2);
    } elseif (strlen($d) === 11 && str_starts_with($d, '0')) {
        $d = substr($d, 1);
    }
    return $d;
}

/** Campaign source from the file's platform value, as the leads already use it (Google / Facebook Lead Form). */
function ml_source_from(string $platformChoice, string $raw): string
{
    if ($platformChoice !== '' && isset(SU_FIELDS['platform']['options'][$platformChoice])) {
        return SU_FIELDS['platform']['options'][$platformChoice];
    }
    return mb_substr(trim($raw), 0, 45);
}

/**
 * Drafts for the not-found rows of a previewed upload.
 * $items = the plan's items (state notfound), $upload = suLoadUpload(), $cfg = suConfig() (+ campaign_col).
 */
function ml_from_upload(array $items, array $upload, array $cfg): array
{
    $byN = [];
    foreach ($upload['data'] as $r) {
        $byN[$r['n']] = $r['cells'];
    }
    $g = ml_guess($upload['headers']);
    if (isset($cfg['campaign_col']) && $cfg['campaign_col'] !== null) {
        $g['campaign'] = (int) $cfg['campaign_col'];
    }
    $idType = (string) $cfg['id_type'];
    $kind = suIdKind($idType);
    $cell = fn(array $c, ?int $i) => $i === null ? '' : trim((string) ($c[$i] ?? ''));
    $out = [];
    foreach ($items as $it) {
        if (($it['state'] ?? '') !== 'notfound' || !isset($byN[$it['row']])) {
            continue;
        }
        $c = $byN[$it['row']];
        $name = trim($cell($c, $g['name']) . ' ' . ($g['last_name'] !== null && $g['last_name'] !== $g['name'] ? $cell($c, $g['last_name']) : ''));
        $d = [
            'row'              => (int) $it['row'],
            'name'             => mb_substr($name, 0, 100),
            'mobile'           => ml_mobile($kind === 'mobile' ? (string) $it['id'] : $cell($c, $g['mobile'])),
            'email'            => strtolower($kind === 'email' ? (string) $it['id'] : $cell($c, $g['email'])),
            'campaignsource'   => ml_source_from((string) ($it['choice']['platform'] ?? ''), (string) ($it['file']['platform'] ?? '')),
            'campaign'         => mb_substr($cell($c, $g['campaign']), 0, 191),
            'lead_status'      => isset($it['choice']['status']) ? suWriteValue('status', (string) $it['choice']['status']) : '',
            'sitevisit_status' => isset($it['choice']['sitevisit']) ? suWriteValue('sitevisit', (string) $it['choice']['sitevisit']) : '',
            'createddate'      => ml_date($cell($c, $g['createddate'])),
            'uniqueid'         => $idType === 'uniqueid' ? (string) $it['id'] : ($g['uniqueid'] !== null ? $cell($c, $g['uniqueid']) : ''),
        ];
        // matched on another lead column (leadgen_id, gclid, …): keep that value too
        if (!in_array($idType, ['mobile', 'email', 'uniqueid'], true) && (string) $it['id'] !== '') {
            $d['extra'] = [$idType => (string) $it['id']];
        }
        $out[] = $d;
        if (count($out) >= ML_MAX_ROWS) {
            break;
        }
    }
    return $out;
}

/** Drafts from a saved missing-leads file (the CSV this page downloads, or the same columns in XLSX). */
function ml_parse_file(string $path, string $name): array
{
    $p = suParseFile($path, $name);
    [$headers, $data] = suSplitHeader($p['rows']);
    $col = [];
    foreach ($headers as $i => $h) {
        $n = suNorm((string) $h);
        foreach (ML_FIELDS as $k => [$label]) {
            if ($n === suNorm($label) || $n === suNorm($k)) {
                $col[$k] = $i;
            }
        }
        if ($n === 'row') {
            $col['row'] = $i;
        }
        if ($n === 'database' || $n === 'lead database' || $n === 'db') {
            $col['db'] = $i;
        }
        if (preg_match('/^(leadgen id|gclid|utm campaignid|ad id)$/', $n)) {
            $col['x:' . str_replace(' ', '_', $n)] = $i;
        }
    }
    if (!isset($col['mobile']) && !isset($col['email'])) {
        throw new InvalidArgumentException('This file has no Mobile or Email column. Use the CSV downloaded from “Add missing leads” (first row: ' . implode(', ', array_column(ML_FIELDS, 0)) . ').');
    }
    $out = [];
    foreach ($data as $r) {
        $c = $r['cells'];
        $v = fn(string $k) => isset($col[$k]) ? trim((string) ($c[$col[$k]] ?? '')) : '';
        $d = ['row' => isset($col['row']) && ctype_digit($v('row')) ? (int) $v('row') : (int) $r['n']];
        foreach (array_keys(ML_FIELDS) as $k) {
            $d[$k] = $v($k);
        }
        $d['mobile'] = ml_mobile($d['mobile']);
        $d['email'] = strtolower($d['email']);
        $d['createddate'] = $d['createddate'] === '' ? '' : (ml_date($d['createddate']) ?: $d['createddate']);
        $d['db'] = ml_db_key($v('db'));
        foreach ($col as $k => $i) {
            if (str_starts_with($k, 'x:')) {
                $d['extra'][substr($k, 2)] = trim((string) ($c[$i] ?? ''));
            }
        }
        if (implode('', array_map('strval', array_intersect_key($d, ML_FIELDS))) === '') {
            continue;   // empty line
        }
        $out[] = $d;
        if (count($out) >= ML_MAX_ROWS) {
            break;
        }
    }
    if (!$out) {
        throw new InvalidArgumentException('No rows in this file.');
    }
    return $out;
}

/** A database key from a key or a label ("official", "Official Campaign"), '' when unknown. */
function ml_db_key(string $v): string
{
    $n = suNorm($v);
    if ($n === '') {
        return '';
    }
    foreach (leadDbKeys() as $k) {
        if ($n === suNorm($k) || $n === suNorm(leadDbLabel($k))) {
            return $k;
        }
    }
    return '';
}

/**
 * Database of each row (rows without one): the database whose leads already use the row's campaign; else the one
 * whose name is in the campaign ("Pseudo", "Official"…); else $default.
 */
function ml_assign_dbs(array $rows, string $default): array
{
    $keys = leadDbKeys();
    if (count($keys) < 2) {
        foreach ($rows as &$d) {
            $d['db'] = $keys[0];
        }
        return $rows;
    }
    $camps = [];   // db => [normalised campaign => true]
    foreach ($keys as $k) {
        $camps[$k] = [];
        $db = leadDb($k);
        if (!$db) {
            continue;
        }
        foreach (['campaign_name', 'utm_campaignname'] as $col) {
            try {
                $r = $db->query("SELECT DISTINCT {$col} AS c FROM `lead` WHERE {$col} IS NOT NULL AND {$col} <> '' LIMIT 5000");   // (no ORDER BY: DISTINCT + ORDER BY id fails on MySQL 8)
            } catch (Throwable $e) {
                $r = false;
            }
            while ($r && ($x = $r->fetch_assoc())) {
                $camps[$k][suCampNorm((string) $x['c'])] = true;
            }
        }
    }
    foreach ($rows as &$d) {
        if (!empty($d['db']) && in_array($d['db'], $keys, true)) {
            continue;
        }
        $c = suCampNorm((string) ($d['campaign'] ?? ''));
        $pick = '';
        if ($c !== '') {
            $hit = array_values(array_filter($keys, fn($k) => isset($camps[$k][$c])));
            if (count($hit) === 1) {
                $pick = $hit[0];
            } else {
                $words = explode(' ', $c);
                $hint = array_values(array_filter($keys, fn($k) => (bool) array_intersect(suDbWords($k), $words)));
                $pick = count($hint) === 1 ? $hint[0] : '';
            }
        }
        $d['db'] = $pick !== '' ? $pick : $default;
    }
    return $rows;
}

/** Campaign sources already used in a lead database (most used first), for the "campaign source" list. */
function ml_sources(mysqli $db): array
{
    $out = [];
    $r = $db->query("SELECT TRIM(campaignsource) AS s, COUNT(*) AS n FROM `lead` WHERE campaignsource IS NOT NULL AND TRIM(campaignsource) <> ''
                     GROUP BY TRIM(campaignsource) ORDER BY n DESC LIMIT 40");
    while ($r && ($x = $r->fetch_assoc())) {
        $out[] = (string) $x['s'];
    }
    foreach (['Google', 'Facebook Lead Form', 'Website', 'Walk-in', 'Channel Partner', 'Referral'] as $s) {
        if (!in_array(strtolower($s), array_map('strtolower', $out), true)) {
            $out[] = $s;
        }
    }
    return $out;
}

/* ------------------------------------------------------------------ insert + undo */

function ml_ensure_log(mysqli $db): void
{
    $db->query("CREATE TABLE IF NOT EXISTS `lead_missing_imports` (
        `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        `created_at` DATETIME NULL,
        `created_by` VARCHAR(100) NULL,
        `file_name` VARCHAR(255) NULL,
        `rows_added` INT NOT NULL DEFAULT 0,
        `lead_ids` MEDIUMTEXT NULL,
        `undone_at` DATETIME NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
}

/** Lead columns that exist in this database. */
function ml_columns(mysqli $db): array
{
    $cols = [];
    $r = $db->query('SHOW COLUMNS FROM `lead`');
    while ($r && ($x = $r->fetch_assoc())) {
        $cols[(string) ($x['Field'] ?? '')] = true;
    }
    if (!$cols) {   // drivers without SHOW COLUMNS
        $r = $db->query('SELECT * FROM `lead` LIMIT 1');
        if ($r && ($x = $r->fetch_assoc())) {
            $cols = array_fill_keys(array_keys($x), true);
        }
    }
    return $cols;
}

/** Already in the database? (same mobile — last 10 digits — or same email or unique ID). */
function ml_existing(mysqli $db, array $d): ?array
{
    $m10 = substr(preg_replace('/\D/', '', (string) $d['mobile']), -10);
    if (strlen($m10) >= 6) {
        $st = $db->prepare("SELECT id, name FROM `lead` WHERE RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(IFNULL(mobile,''), '+', ''), ' ', ''), '-', ''), '(', ''), 10) = ? LIMIT 1");
        if ($st) {
            $st->bind_param('s', $m10);
            $st->execute();
            if ($x = $st->get_result()->fetch_assoc()) {
                return $x + ['why' => 'same mobile'];
            }
        }
    }
    foreach (['email' => 'same email', 'uniqueid' => 'same unique ID'] as $k => $why) {
        $v = trim((string) ($d[$k] ?? ''));
        if ($v === '') {
            continue;
        }
        $st = $db->prepare("SELECT id, name FROM `lead` WHERE LOWER(TRIM({$k})) = LOWER(?) LIMIT 1");
        if ($st) {
            $st->bind_param('s', $v);
            $st->execute();
            if ($x = $st->get_result()->fetch_assoc()) {
                return $x + ['why' => $why];
            }
        }
    }
    return null;
}

/**
 * Checks and inserts the rows. $only_check = true: nothing is written (the page shows what would happen).
 * @return array{added:int, skipped:list<array>, errors:list<array>, import_id:int, lead_ids:list<int>}
 */
function ml_insert(mysqli $db, array $rows, string $user, string $file, bool $onlyCheck = false): array
{
    if (!$rows) {
        throw new InvalidArgumentException('No rows to add.');
    }
    if (count($rows) > ML_MAX_ROWS) {
        throw new InvalidArgumentException('At most ' . ML_MAX_ROWS . ' rows at a time.');
    }
    $have = ml_columns($db);
    $todo = $skipped = $errors = [];
    $seen = [];
    foreach (array_values($rows) as $i => $d) {
        $row = (int) ($d['row'] ?? $i + 1);
        $d = array_map(fn($v) => is_array($v) ? $v : trim((string) $v), (array) $d);
        $d['mobile'] = ml_mobile((string) ($d['mobile'] ?? ''));
        $d['email'] = strtolower((string) ($d['email'] ?? ''));
        $err = [];
        if ($d['mobile'] === '' && $d['email'] === '') {
            $err[] = 'needs a mobile or an email';
        }
        if ($d['mobile'] !== '' && (strlen($d['mobile']) < 8 || strlen($d['mobile']) > 15)) {
            $err[] = 'mobile should have 8–15 digits';
        }
        if ($d['email'] !== '' && !filter_var($d['email'], FILTER_VALIDATE_EMAIL)) {
            $err[] = 'email is not valid';
        }
        if (trim((string) ($d['campaignsource'] ?? '')) === '') {
            $err[] = 'choose the campaign source';
        }
        if (!in_array(strtoupper((string) ($d['lead_status'] ?? '')), ML_STATUS, true)) {
            $err[] = 'lead status must be ' . implode(' / ', array_filter(ML_STATUS));
        }
        $sv = (string) ($d['sitevisit_status'] ?? '');
        if (!in_array(strtolower($sv), array_map('strtolower', ML_SITEVISIT), true)) {
            $err[] = 'site visit must be Visited / Not Visited';
        }
        $cd = (string) ($d['createddate'] ?? '');
        if ($cd !== '') {
            $cd = ml_date($cd);
            if ($cd === '') {
                $err[] = 'created date not readable (use YYYY-MM-DD or DD/MM/YYYY)';
            } elseif ($cd > date('Y-m-d H:i:s', time() + 86400)) {
                $err[] = 'created date is in the future';
            }
        }
        if ($err) {
            $errors[] = ['row' => $row, 'name' => (string) ($d['name'] ?? ''), 'reason' => implode('; ', $err)];
            continue;
        }
        $key = $d['mobile'] !== '' ? 'm' . substr($d['mobile'], -10) : 'e' . $d['email'];
        if (isset($seen[$key])) {
            $skipped[] = ['row' => $row, 'name' => (string) ($d['name'] ?? ''), 'reason' => 'repeated in this list (row ' . $seen[$key] . ')'];
            continue;
        }
        $seen[$key] = $row;
        if ($x = ml_existing($db, $d)) {
            $skipped[] = ['row' => $row, 'name' => (string) ($d['name'] ?? ''), 'reason' => 'already in the database (' . $x['why'] . ', lead #' . $x['id'] . ')'];
            continue;
        }
        $src = mb_substr((string) $d['campaignsource'], 0, 45);
        $rec = [
            'name' => mb_substr((string) ($d['name'] ?? ''), 0, 100),
            'mobile' => $d['mobile'],
            'email' => mb_substr($d['email'], 0, 150),
            'campaignsource' => $src,
            'campaign_name' => mb_substr((string) ($d['campaign'] ?? ''), 0, 191),
            'lead_status' => strtoupper((string) ($d['lead_status'] ?? '')),
            'sitevisit_status' => $sv === '' ? '' : (strtolower($sv) === 'visited' ? 'Visited' : 'Not Visited'),
            'createddate' => $cd !== '' ? $cd : date('Y-m-d H:i:s'),
            'uniqueid' => mb_substr((string) ($d['uniqueid'] ?? ''), 0, 100),
            'curlresponse' => ML_CRM_NOTE,
        ];
        if (suPlatformFamily($src) === 'google' && $rec['campaign_name'] !== '') {
            $rec['utm_campaignname'] = $rec['campaign_name'];   // Google leads are matched to campaigns by utm_campaignname
        }
        foreach ((array) ($d['extra'] ?? []) as $k => $v) {
            if (preg_match('/^(leadgen_id|gclid|utm_campaignid|ad_id)$/', (string) $k) && trim((string) $v) !== '') {
                $rec[$k] = mb_substr(trim((string) $v), 0, 100);
            }
        }
        $rec = array_filter(array_intersect_key($rec, $have), fn($v) => $v !== '');
        $todo[] = ['row' => $row, 'rec' => $rec];
    }
    $out = ['added' => 0, 'to_add' => count($todo), 'skipped' => $skipped, 'errors' => $errors, 'import_id' => 0, 'lead_ids' => []];
    if ($onlyCheck || !$todo) {
        return $out;
    }
    $db->begin_transaction();
    try {
        foreach ($todo as $t) {
            $rec = $t['rec'];
            $cols = '`' . implode('`, `', array_keys($rec)) . '`';
            $st = $db->prepare("INSERT INTO `lead` ({$cols}) VALUES (" . implode(', ', array_fill(0, count($rec), '?')) . ')');
            if (!$st) {
                throw new RuntimeException('Could not prepare the insert: ' . $db->error);
            }
            $vals = array_values($rec);
            $st->bind_param(str_repeat('s', count($vals)), ...$vals);
            if (!$st->execute()) {
                throw new RuntimeException('Row ' . $t['row'] . ': ' . $st->error);
            }
            $id = (int) $st->insert_id;
            if ($id <= 0) {
                $r = $db->query('SELECT MAX(id) AS id FROM `lead`');
                $id = (int) ($r ? $r->fetch_assoc()['id'] : 0);
            }
            $out['lead_ids'][] = $id;
            $st->close();
        }
        ml_ensure_log($db);
        $now = date('Y-m-d H:i:s');
        $ids = json_encode($out['lead_ids']);
        $n = count($out['lead_ids']);
        $file = mb_substr($file, 0, 250);
        $st = $db->prepare('INSERT INTO `lead_missing_imports` (created_at, created_by, file_name, rows_added, lead_ids) VALUES (?, ?, ?, ?, ?)');
        $st->bind_param('sssis', $now, $user, $file, $n, $ids);
        $st->execute();
        $out['import_id'] = (int) $st->insert_id;
        if ($out['import_id'] <= 0) {
            $r = $db->query('SELECT MAX(id) AS id FROM `lead_missing_imports`');
            $out['import_id'] = (int) ($r ? $r->fetch_assoc()['id'] : 0);
        }
        $db->commit();
    } catch (Throwable $e) {
        $db->rollback();
        throw $e;
    }
    $out['added'] = count($out['lead_ids']);
    return $out;
}

/** Recent "add missing leads" imports of a database. */
function ml_history(mysqli $db, int $limit = 10): array
{
    ml_ensure_log($db);
    $out = [];
    $r = $db->query('SELECT id, created_at, created_by, file_name, rows_added, undone_at FROM `lead_missing_imports` ORDER BY id DESC LIMIT ' . (int) $limit);
    while ($r && ($x = $r->fetch_assoc())) {
        $out[] = ['id' => (int) $x['id'], 'at' => (string) $x['created_at'], 'by' => (string) $x['created_by'], 'file' => (string) $x['file_name'],
                  'rows' => (int) $x['rows_added'], 'undone' => (string) ($x['undone_at'] ?? '')];
    }
    return $out;
}

/** Deletes the leads of one import (only leads still marked as imported from the feedback report). */
function ml_undo(mysqli $db, int $importId): array
{
    ml_ensure_log($db);
    $st = $db->prepare('SELECT lead_ids, undone_at FROM `lead_missing_imports` WHERE id = ?');
    $st->bind_param('i', $importId);
    $st->execute();
    $x = $st->get_result()->fetch_assoc();
    if (!$x) {
        throw new InvalidArgumentException('Unknown import.');
    }
    if (!empty($x['undone_at'])) {
        throw new InvalidArgumentException('This import was already undone.');
    }
    $ids = array_values(array_filter(array_map('intval', (array) json_decode((string) $x['lead_ids'], true))));
    $deleted = 0;
    $note = ML_CRM_NOTE;
    $del = $db->prepare('DELETE FROM `lead` WHERE id = ? AND curlresponse = ?');
    foreach ($ids as $id) {
        $del->bind_param('is', $id, $note);
        $del->execute();
        $deleted += max(0, (int) $del->affected_rows);
    }
    $now = date('Y-m-d H:i:s');
    $u = $db->prepare('UPDATE `lead_missing_imports` SET undone_at = ? WHERE id = ?');
    $u->bind_param('si', $now, $importId);
    $u->execute();
    return ['deleted' => $deleted, 'of' => count($ids)];
}
