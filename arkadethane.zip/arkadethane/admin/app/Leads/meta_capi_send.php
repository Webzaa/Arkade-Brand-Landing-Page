<?php
/**
 * app/Leads/meta_capi_send.php — Meta Conversions API (CRM events) straight from Upload Lead Status.
 *
 * When a feedback upload makes a Meta lead Qualified, or gives it a site visit, the event is sent to Meta
 * (Conversions API for CRM: action_source = system_generated, user_data.lead_id = the lead form ID, hashed
 * email / phone, custom_data.event_source = crm). Meta then optimises the lead-form campaigns for leads that
 * turn into qualified leads and site visits, not just form fills.
 *
 * Settings: Admin → CRM Settings → "Meta Conversions API" (pq_settings key 'meta_capi', token encrypted).
 * Rules: only Meta leads (lead form ID or a Meta source), never test leads, each (lead, event) sent once
 * (log table meta_capi_events), up to 500 events per call. Undoing an upload does not take events back.
 */

require_once __DIR__ . '/crm_sfdc.php';      // settings storage + encryption
require_once __DIR__ . '/crm_push.php';      // crmIsTestLead, crmPlatform
require_once __DIR__ . '/status_upload.php';  // suCounts

const CAPI_STAGES = ['qualified' => 'Qualified', 'sitevisit' => 'Site visit'];
const CAPI_BATCH = 500;

function capiDefaults(): array
{
    return [
        'enabled' => false,
        'dataset_id' => defined('META_PIXEL_ID') ? (string) META_PIXEL_ID : '',
        'access_token' => '',
        'use_config_token' => true,
        'send' => ['qualified' => true, 'sitevisit' => true],
        'events' => ['qualified' => 'Qualified', 'sitevisit' => 'Site Visit'],
        'lead_event_source' => 'PerformIQ',
        'test_event_code' => '',
    ];
}

/** Settings with the token in plain text (server side only). */
function capiSettings(?mysqli $appDb = null): array
{
    $appDb ??= leadDb(appDbKey());
    $saved = $appDb ? pqSettingGet($appDb, 'meta_capi') : null;
    $s = array_replace_recursive(capiDefaults(), is_array($saved) ? array_intersect_key($saved, capiDefaults()) : []);
    $s['enabled'] = !empty($s['enabled']);
    $s['use_config_token'] = !empty($s['use_config_token']);
    $s['send'] = ['qualified' => !empty($s['send']['qualified']), 'sitevisit' => !empty($s['send']['sitevisit'])];
    $s['dataset_id'] = preg_replace('/\D+/', '', (string) $s['dataset_id']);
    $tok = pqDecrypt((string) $s['access_token']);
    $s['token_error'] = $tok === null;
    $s['access_token'] = (string) $tok;
    $s['saved'] = $saved !== null;
    $s['updated_at'] = (string) ($saved['_updated_at'] ?? '');
    $s['updated_by'] = (string) ($saved['_updated_by'] ?? '');
    return $s;
}

function capiToken(array $s): string
{
    if ($s['access_token'] !== '') {
        return $s['access_token'];
    }
    return $s['use_config_token'] && defined('META_ACCESS_TOKEN') ? (string) META_ACCESS_TOKEN : '';
}

/** '' = ready to send, else why not (plain words). */
function capiProblem(array $s): string
{
    if (!$s['enabled']) {
        return 'Meta Conversions API is turned off (Admin → CRM Settings)';
    }
    if ($s['dataset_id'] === '') {
        return 'No Meta dataset / pixel ID set (Admin → CRM Settings)';
    }
    if (capiToken($s) === '') {
        return 'No Meta access token (Admin → CRM Settings)';
    }
    if (!$s['send']['qualified'] && !$s['send']['sitevisit']) {
        return 'Both events are turned off (Admin → CRM Settings)';
    }
    return '';
}

function capiLogTable(mysqli $db): void
{
    $db->query("CREATE TABLE IF NOT EXISTS `meta_capi_events` (
        `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        `lead_id` INT NOT NULL,
        `stage` VARCHAR(20) NOT NULL,
        `event_name` VARCHAR(60) NOT NULL,
        `event_id` VARCHAR(100) NOT NULL,
        `leadgen_id` VARCHAR(40) DEFAULT NULL,
        `sent_at` DATETIME NOT NULL,
        `sent_by` VARCHAR(100) DEFAULT NULL,
        `source` VARCHAR(40) DEFAULT NULL,
        `result` VARCHAR(20) NOT NULL,
        `response` TEXT,
        KEY `lead_stage` (`lead_id`, `stage`),
        KEY `sent_at` (`sent_at`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
}

/** (lead id, stage) pairs already sent successfully. */
function capiAlreadySent(mysqli $db, array $leadIds): array
{
    $ids = array_values(array_filter(array_map('intval', $leadIds)));
    if (!$ids) {
        return [];
    }
    capiLogTable($db);
    $out = [];
    foreach (array_chunk($ids, 500) as $part) {
        $r = $db->query("SELECT lead_id, stage FROM `meta_capi_events` WHERE result = 'sent' AND lead_id IN (" . implode(',', $part) . ')');
        while ($r && ($x = $r->fetch_assoc())) {
            $out[(int) $x['lead_id'] . '|' . $x['stage']] = true;
        }
    }
    return $out;
}

/**
 * Events for the changes of an upload plan (suPlan()['changes']): Meta leads that become Qualified or get a site visit.
 * @return array{events: list<array>, skipped: array<string,int>, by_stage: array<string,int>}
 */
function capiFromChanges(mysqli $db, array $changes, array $s): array
{
    $want = [];
    foreach ($changes as $c) {
        $id = (int) $c['id'];
        foreach (['status' => 'qualified', 'sitevisit' => 'sitevisit'] as $f => $stage) {
            if (!array_key_exists($f, $c['set']) || empty($s['send'][$stage])) {
                continue;
            }
            if (suCounts($f, (string) $c['set'][$f]) && !suCounts($f, (string) ($c['old'][$f] ?? ''))) {
                $want[$id][] = $stage;
            }
        }
    }
    $out = ['events' => [], 'skipped' => ['not_meta' => 0, 'test' => 0, 'already_sent' => 0, 'no_contact' => 0], 'by_stage' => ['qualified' => 0, 'sitevisit' => 0]];
    if (!$want) {
        return $out;
    }
    $sent = capiAlreadySent($db, array_keys($want));
    foreach (array_chunk(array_keys($want), 500) as $part) {
        $r = $db->query('SELECT * FROM `lead` WHERE id IN (' . implode(',', array_map('intval', $part)) . ')');
        while ($r && ($l = $r->fetch_assoc())) {
            $id = (int) $l['id'];
            if (isset($changes[$id]['set']['platform'])) {
                $l['campaignsource'] = $changes[$id]['set']['platform'];   // preview: the platform after the upload
            }
            foreach ($want[$id] ?? [] as $stage) {
                if (crmPlatform($l) !== 'Meta') {
                    $out['skipped']['not_meta']++;
                } elseif (crmIsTestLead($l)) {
                    $out['skipped']['test']++;
                } elseif (isset($sent[$id . '|' . $stage])) {
                    $out['skipped']['already_sent']++;
                } elseif (pqCleanTrack($l['leadgen_id'] ?? '') === '' && trim((string) $l['email']) === '' && trim((string) $l['mobile']) === '') {
                    $out['skipped']['no_contact']++;
                } else {
                    $out['events'][] = ['lead' => $l, 'stage' => $stage];
                    $out['by_stage'][$stage]++;
                }
            }
        }
    }
    return $out;
}

/** Phone as Meta wants it before hashing: digits with the country code, no + or 0. */
function capiPhone(array $l): string
{
    $d = preg_replace('/\D+/', '', (string) ($l['mobile'] ?? ''));
    if ($d === '') {
        return '';
    }
    $cc = preg_replace('/\D+/', '', (string) ($l['countrycode'] ?? '')) ?: '91';
    $d = ltrim($d, '0');
    if (strlen($d) === 10) {
        $d = $cc . $d;
    }
    return $d;
}

function capiEvent(array $l, string $stage, array $s, int $now): array
{
    $leadgen = pqCleanTrack($l['leadgen_id'] ?? '');
    $user = [];
    if ($leadgen !== '' && ctype_digit($leadgen)) {
        $user['lead_id'] = strlen($leadgen) <= 18 ? (int) $leadgen : $leadgen;
    }
    $em = strtolower(trim((string) ($l['email'] ?? '')));
    if ($em !== '' && str_contains($em, '@')) {
        $user['em'] = [hash('sha256', $em)];
    }
    $ph = capiPhone($l);
    if ($ph !== '') {
        $user['ph'] = [hash('sha256', $ph)];
    }
    $name = (string) ($s['events'][$stage] ?? CAPI_STAGES[$stage]);
    return [
        'event_name' => $name,
        'event_time' => $now,
        'action_source' => 'system_generated',
        'event_id' => 'pq_' . $stage . '_' . ($leadgen !== '' ? $leadgen : 'l' . (int) $l['id']),
        'user_data' => $user,
        'custom_data' => ['event_source' => 'crm', 'lead_event_source' => (string) ($s['lead_event_source'] ?: 'PerformIQ')],
    ];
}

function capiGraphUrl(array $s, string $path): string
{
    $base = defined('PQ_META_GRAPH_URL') ? rtrim((string) PQ_META_GRAPH_URL, '/') : 'https://graph.facebook.com';
    $ver = defined('META_API_VERSION') ? (string) META_API_VERSION : 'v23.0';
    return "$base/$ver/" . ltrim($path, '/');
}

/**
 * Sends events (from capiFromChanges) and logs them. Never throws for Meta errors — returns them.
 * @return array{sent:int, failed:int, error:string, by_stage: array<string,int>}
 */
function capiSend(mysqli $db, array $events, array $s, string $user, string $source): array
{
    $res = ['sent' => 0, 'failed' => 0, 'error' => '', 'by_stage' => ['qualified' => 0, 'sitevisit' => 0]];
    if (!$events) {
        return $res;
    }
    $why = capiProblem($s);
    if ($why !== '') {
        $res['error'] = $why;
        $res['failed'] = count($events);
        return $res;
    }
    capiLogTable($db);
    $log = $db->prepare('INSERT INTO `meta_capi_events` (lead_id, stage, event_name, event_id, leadgen_id, sent_at, sent_by, source, result, response) VALUES (?, ?, ?, ?, ?, NOW(), ?, ?, ?, ?)');
    $mark = $db->prepare('UPDATE `lead` SET capi_sent = 1, capi_sent_stage = ?, meta_curlresponse = ? WHERE id = ?');
    $now = time();
    $token = capiToken($s);
    foreach (array_chunk($events, CAPI_BATCH) as $batch) {
        $data = array_map(fn($e) => capiEvent($e['lead'], $e['stage'], $s, $now), $batch);
        $post = ['data' => json_encode($data, JSON_UNESCAPED_SLASHES), 'access_token' => $token];
        if (trim((string) $s['test_event_code']) !== '') {
            $post['test_event_code'] = trim((string) $s['test_event_code']);
        }
        [$code, $body, $err] = crmHttpPost(capiGraphUrl($s, $s['dataset_id'] . '/events'), http_build_query($post), ['Content-Type: application/x-www-form-urlencoded'], 60);
        $d = json_decode($body, true);
        $ok = $err === '' && $code >= 200 && $code < 300 && (int) ($d['events_received'] ?? 0) === count($batch);
        $reply = $err !== '' ? $err : mb_substr($body, 0, 2000);
        if (!$ok && $res['error'] === '') {
            $res['error'] = $err !== '' ? 'Could not reach Meta: ' . $err
                : 'Meta: ' . trim((string) ($d['error']['message'] ?? ('HTTP ' . $code . ' ' . mb_substr(strip_tags($body), 0, 160))));
        }
        foreach ($batch as $i => $e) {
            $l = $e['lead'];
            $id = (int) $l['id'];
            $stage = $e['stage'];
            $name = $data[$i]['event_name'];
            $eid = $data[$i]['event_id'];
            $lg = pqCleanTrack($l['leadgen_id'] ?? '');
            $result = $ok ? 'sent' : 'failed';
            $log->bind_param('issssssss', $id, $stage, $name, $eid, $lg, $user, $source, $result, $reply);
            $log->execute();
            if ($ok) {
                $mark->bind_param('ssi', $name, $reply, $id);
                $mark->execute();
                $res['sent']++;
                $res['by_stage'][$stage]++;
            } else {
                $res['failed']++;
            }
        }
    }
    return $res;
}

/** Checks the dataset + token: {ok, name, error}. Sends nothing. */
function capiCheck(array $s): array
{
    if ($s['dataset_id'] === '' || capiToken($s) === '') {
        return ['ok' => false, 'error' => 'Enter the dataset / pixel ID and an access token first.'];
    }
    $url = capiGraphUrl($s, $s['dataset_id']) . '?fields=id,name&access_token=' . rawurlencode(capiToken($s));
    $ch = curl_init($url);
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 20, CURLOPT_CONNECTTIMEOUT => 10]);
    $body = (string) curl_exec($ch);
    $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $err = curl_error($ch);
    curl_close($ch);
    $d = json_decode($body, true);
    if ($err === '' && $code === 200 && !empty($d['id'])) {
        return ['ok' => true, 'name' => (string) ($d['name'] ?? ''), 'id' => (string) $d['id']];
    }
    return ['ok' => false, 'error' => $err !== '' ? $err : (string) ($d['error']['message'] ?? ('HTTP ' . $code))];
}

/** Events of an upload that Meta did not take (and were not sent since), ready to send again. */
function capiFailedOfUpload(mysqli $db, int $uploadId): array
{
    capiLogTable($db);
    $src = 'upload:' . $uploadId;
    $st = $db->prepare("SELECT DISTINCT lead_id, stage FROM `meta_capi_events` WHERE source = ? AND result = 'failed'");
    $st->bind_param('s', $src);
    $st->execute();
    $res = $st->get_result();
    $want = [];
    while ($res && ($r = $res->fetch_assoc())) {
        $want[(int) $r['lead_id']][] = (string) $r['stage'];
    }
    if (!$want) {
        return [];
    }
    $sent = capiAlreadySent($db, array_keys($want));
    $events = [];
    $r = $db->query('SELECT * FROM `lead` WHERE id IN (' . implode(',', array_map('intval', array_keys($want))) . ')');
    while ($r && ($l = $r->fetch_assoc())) {
        foreach (array_unique($want[(int) $l['id']]) as $stage) {
            if (!isset($sent[(int) $l['id'] . '|' . $stage]) && isset(CAPI_STAGES[$stage])) {
                $events[] = ['lead' => $l, 'stage' => $stage];
            }
        }
    }
    return $events;
}
