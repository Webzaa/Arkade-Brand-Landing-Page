<?php
/**
 * app/Leads/crm_sfdc.php — built-in Salesforce (SFDC) integration, set up per project with no code:
 * Admin → CRM Settings (public/crm_settings.php). Used by "Send to CRM" on the CRM Push page.
 *
 * Settings live in the main database (table pq_settings, key 'crm_sfdc'); client secret and password are
 * encrypted (AES-256-GCM, key: PQ_APP_KEY in config.php, else REPORT_LINK_SECRET). If nothing was saved
 * there yet, the older CRM_SFDC block in config.php is used (same behaviour as before).
 *
 * Shape (normalized):
 *   enabled    bool
 *   auth       {mode: client_credentials|password, token_url, client_id, client_secret, username, password}
 *   fallback   same shape, mode '' = no backup sign-in
 *   lead_url   full URL, or a path such as /services/apexrest/Marketing/Leads/ (added to the instance URL Salesforce returns)
 *   platforms  {meta, google, other}: which leads may be sent
 *   fields     list of {name, meta, google, other}: Salesforce field → value for each platform ('' = not sent)
 *
 * Field values: plain text plus placeholders in { }:
 *   {name} {mobile} {email} {campaign_name} …  any column of the lead table
 *   {a|b|c}                                     the first one that has a value
 *   {campaignsubsource|'Google'}                text in quotes = fixed fallback; {countrycode|+91} works too
 *   specials: {enquiry_date} (YYYY-MM-DD)  {enquiry_datetime}  {enquiry_iso}  {countrycode} (+91 style)
 *             {mobile_10} {first_name} {last_name} {lead_id} {project_name} {platform} {today}
 */

require_once dirname(__DIR__) . '/Core/db.php';
require_once dirname(__DIR__) . '/Ads/master_tables.php';

const CRM_SFDC_PLATFORMS = ['meta' => 'Meta', 'google' => 'Google', 'other' => 'Other sources'];
const CRM_SFDC_SPECIALS = [
    'enquiry_date' => 'Lead date, YYYY-MM-DD', 'enquiry_datetime' => 'Lead date and time, YYYY-MM-DD HH:MM:SS',
    'enquiry_iso' => 'Lead date and time, ISO 8601 (2026-10-23T12:30:00+05:30)', 'countrycode' => 'Country code as +91 (default +91)',
    'mobile_10' => 'Last 10 digits of the mobile', 'first_name' => 'First word of the name', 'last_name' => 'Rest of the name (or “.”)',
    'lead_id' => 'Lead ID in this admin', 'project_name' => 'PROJECT_NAME from config.php', 'platform' => 'Meta / Google / source name',
    'today' => "Today's date, YYYY-MM-DD",
];

/* ======================================================================
 * Settings storage
 * ====================================================================== */

function pqSettingsTable(mysqli $db): void
{
    $db->query("CREATE TABLE IF NOT EXISTS `pq_settings` (
        `setting_key` VARCHAR(64) NOT NULL PRIMARY KEY,
        `value` MEDIUMTEXT,
        `updated_at` DATETIME DEFAULT NULL,
        `updated_by` VARCHAR(100) DEFAULT NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
}

function pqSettingGet(mysqli $db, string $key): ?array
{
    pqSettingsTable($db);
    $st = $db->prepare('SELECT value, updated_at, updated_by FROM `pq_settings` WHERE setting_key = ?');
    $st->bind_param('s', $key);
    $st->execute();
    $r = $st->get_result()->fetch_assoc();
    if (!$r) {
        return null;
    }
    $v = json_decode((string) $r['value'], true);
    return is_array($v) ? $v + ['_updated_at' => $r['updated_at'], '_updated_by' => $r['updated_by']] : null;
}

function pqSettingPut(mysqli $db, string $key, array $value, string $user): void
{
    pqSettingsTable($db);
    unset($value['_updated_at'], $value['_updated_by']);
    $json = json_encode($value, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    $now = date('Y-m-d H:i:s');
    $del = $db->prepare('DELETE FROM `pq_settings` WHERE setting_key = ?');
    $del->bind_param('s', $key);
    $del->execute();
    $st = $db->prepare('INSERT INTO `pq_settings` (setting_key, value, updated_at, updated_by) VALUES (?, ?, ?, ?)');
    $st->bind_param('ssss', $key, $json, $now, $user);
    if (!$st->execute()) {
        throw new RuntimeException('Could not save the settings: ' . $db->error);
    }
}

/* ── secrets ── */
function pqSecretKey(): string
{
    if (defined('PQ_APP_KEY') && (string) PQ_APP_KEY !== '') {
        return hash('sha256', 'pq-app-key|' . PQ_APP_KEY, true);
    }
    if (defined('REPORT_LINK_SECRET') && (string) REPORT_LINK_SECRET !== '') {
        return hash('sha256', 'pq-report-secret|' . REPORT_LINK_SECRET, true);
    }
    $cfg = leadDatabaseConfig()[appDbKey()] ?? [];
    return hash('sha256', 'pq-fallback|' . ($cfg['pass'] ?? '') . '|' . ($cfg['name'] ?? '') . '|' . BASE_PATH, true);
}

function pqEncrypt(string $plain): string
{
    if ($plain === '') {
        return '';
    }
    $iv = random_bytes(12);
    $tag = '';
    $ct = openssl_encrypt($plain, 'aes-256-gcm', pqSecretKey(), OPENSSL_RAW_DATA, $iv, $tag);
    return 'enc:v1:' . base64_encode($iv . $tag . $ct);
}

/** null = could not decrypt (key changed) */
function pqDecrypt(string $enc): ?string
{
    if ($enc === '' || !str_starts_with($enc, 'enc:v1:')) {
        return $enc;
    }
    $raw = base64_decode(substr($enc, 7), true);
    if ($raw === false || strlen($raw) < 29) {
        return null;
    }
    $out = openssl_decrypt(substr($raw, 28), 'aes-256-gcm', pqSecretKey(), OPENSSL_RAW_DATA, substr($raw, 0, 12), substr($raw, 12, 16));
    return $out === false ? null : $out;
}

/* ======================================================================
 * Settings: load / normalize
 * ====================================================================== */

function crmSfdcBlankAuth(): array
{
    return ['mode' => '', 'token_url' => '', 'client_id' => '', 'client_secret' => '', 'username' => '', 'password' => ''];
}

/** Starting point for a new project (the Embassy setup, without its IDs). */
function crmSfdcDefaultFields(): array
{
    $f = fn($n, $m, $g, $o = '') => ['name' => $n, 'meta' => $m, 'google' => $g, 'other' => $o];
    return [
        $f('firstname', '{name|.}', '{name|.}', '{name|.}'),
        $f('lastname', '.', '.', '.'),
        $f('mobile', '{mobile}', '{mobile}', '{mobile}'),
        $f('email', '{email}', '{email}', '{email}'),
        $f('countrycode', '{countrycode|+91}', '{countrycode|+91}', '{countrycode|+91}'),
        $f('Project_interested', '', '', ''),
        $f('LeadSource', 'Digital Marketing', 'Digital Marketing', 'Digital Marketing'),
        $f('modeofenquiry', 'Web', 'Web', 'Web'),
        $f('subsource', 'Social Media', "{campaignsubsource|'Google'}", '{campaignsubsource|campaignsource}'),
        $f('owner', 'LMT Queue', 'LMT Queue', 'LMT Queue'),
        $f('Medium', 'Webzaa', 'Webzaa', 'Webzaa'),
        $f('Term', '{campaign_name|utm_campaignname}', '{utm_campaignname|campaign_name}', '{utm_campaignname|campaign_name}'),
        $f('comments', '{adset_name|utm_adgroupname}', '{utm_adname|ad_name}', '{utm_adname}'),
        $f('LeadSourceDetail', '{ad_name|utm_adname}', '{adcreative}', '{adcreative}'),
        $f('campaignId', '', '', ''),
        $f('enquiryDate', '{enquiry_date}', '{enquiry_date}', '{enquiry_date}'),
        $f('utm_ssc', 'Facebook', "{utm_ssc|'Google'}", '{utm_ssc|campaignsource}'),
    ];
}

/** The older CRM_SFDC block in config.php → the same shape. */
function crmSfdcFromConfig(): ?array
{
    if (!defined('CRM_SFDC') || !is_array(CRM_SFDC)) {
        return null;
    }
    $c = CRM_SFDC;
    if (trim((string) ($c['token_url'] ?? '')) === '' || trim((string) ($c['lead_url'] ?? '')) === '') {
        return null;
    }
    $fields = crmSfdcDefaultFields();
    $set = function (string $name, string $col, string $v) use (&$fields) {
        foreach ($fields as &$x) {
            if ($x['name'] === $name) {
                $x[$col] = $v;
            }
        }
    };
    foreach (['meta', 'google', 'other'] as $p) {
        $set('Project_interested', $p, (string) ($c['project'] ?? ''));
        $set('LeadSource', $p, (string) ($c['lead_source'] ?? 'Digital Marketing'));
        $set('modeofenquiry', $p, (string) ($c['mode_of_enquiry'] ?? 'Web'));
        $set('owner', $p, (string) ($c['owner'] ?? 'LMT Queue'));
        $set('Medium', $p, (string) ($c['medium'] ?? 'Webzaa'));
        $set('countrycode', $p, '{countrycode|' . ($c['default_countrycode'] ?? '+91') . '}');
    }
    $set('campaignId', 'meta', (string) ($c['meta']['campaignId'] ?? ''));
    $set('campaignId', 'google', (string) ($c['google']['campaignId'] ?? ''));
    $set('subsource', 'meta', (string) ($c['meta']['subsource'] ?? 'Social Media'));
    $set('subsource', 'google', "{campaignsubsource|'" . ($c['google']['subsource'] ?? 'Google') . "'}");
    $set('utm_ssc', 'meta', (string) ($c['meta']['utm_ssc'] ?? 'Facebook'));
    $set('utm_ssc', 'google', "{utm_ssc|'" . ($c['google']['utm_ssc'] ?? 'Google') . "'}");
    $fb = $c['fallback'] ?? null;
    return [
        'enabled' => true,
        'auth' => ['mode' => 'client_credentials', 'token_url' => (string) $c['token_url'], 'client_id' => (string) ($c['client_id'] ?? ''),
                   'client_secret' => (string) ($c['client_secret'] ?? ''), 'username' => '', 'password' => ''],
        'fallback' => is_array($fb) && !empty($fb['token_url'])
            ? ['mode' => 'password', 'token_url' => (string) $fb['token_url'], 'client_id' => (string) ($fb['client_id'] ?? ''),
               'client_secret' => (string) ($fb['client_secret'] ?? ''), 'username' => (string) ($fb['username'] ?? ''), 'password' => (string) ($fb['password'] ?? '')]
            : crmSfdcBlankAuth(),
        'lead_url' => (string) $c['lead_url'],
        'platforms' => ['meta' => trim((string) ($c['meta']['campaignId'] ?? '')) !== '', 'google' => trim((string) ($c['google']['campaignId'] ?? '')) !== '', 'other' => false],
        'fields' => $fields,
    ];
}

function crmSfdcNormalize(array $s): array
{
    $auth = fn($a) => array_intersect_key(array_merge(crmSfdcBlankAuth(), is_array($a) ? $a : []), crmSfdcBlankAuth());
    $fields = [];
    foreach ((array) ($s['fields'] ?? []) as $f) {
        $n = trim((string) ($f['name'] ?? ''));
        if ($n !== '') {
            $fields[] = ['name' => $n, 'meta' => (string) ($f['meta'] ?? ''), 'google' => (string) ($f['google'] ?? ''), 'other' => (string) ($f['other'] ?? '')];
        }
    }
    return [
        'enabled' => !empty($s['enabled']),
        'auth' => $auth($s['auth'] ?? []),
        'fallback' => $auth($s['fallback'] ?? []),
        'lead_url' => trim((string) ($s['lead_url'] ?? '')),
        'platforms' => ['meta' => !empty($s['platforms']['meta']), 'google' => !empty($s['platforms']['google']), 'other' => !empty($s['platforms']['other'])],
        'fields' => $fields,
    ];
}

/**
 * Current settings with secrets in plain text (server side only).
 * @return array{settings: ?array, source: string, updated_at?: string, updated_by?: string, secret_errors: list<string>}
 */
function crmSfdcLoad(?mysqli $appDb = null): array
{
    $appDb ??= leadDb(appDbKey());
    $saved = $appDb ? pqSettingGet($appDb, 'crm_sfdc') : null;
    if ($saved !== null) {
        $s = crmSfdcNormalize($saved);
        $errs = [];
        foreach (['auth', 'fallback'] as $blk) {
            foreach (['client_secret', 'password'] as $k) {
                $plain = pqDecrypt((string) $s[$blk][$k]);
                if ($plain === null) {
                    $errs[] = "$blk.$k";
                    $plain = '';
                }
                $s[$blk][$k] = $plain;
            }
        }
        return ['settings' => $s, 'source' => 'db', 'updated_at' => (string) ($saved['_updated_at'] ?? ''), 'updated_by' => (string) ($saved['_updated_by'] ?? ''), 'secret_errors' => $errs];
    }
    $c = crmSfdcFromConfig();
    return ['settings' => $c ? crmSfdcNormalize($c) : null, 'source' => $c ? 'config' : 'none', 'secret_errors' => []];
}

/** Ready-to-send settings, or null (not set up / turned off / incomplete). */
function crmSfdcActive(): ?array
{
    $s = crmSfdcLoad()['settings'];
    if (!$s || !$s['enabled'] || $s['lead_url'] === '' || $s['auth']['token_url'] === '' || $s['auth']['client_id'] === '') {
        return null;
    }
    return $s;
}

/** Lead → platform key (meta | google | other). */
function crmSfdcPlatformKey(string $platformLabel): string
{
    return match ($platformLabel) { 'Meta' => 'meta', 'Google' => 'google', default => 'other' };
}

/* ======================================================================
 * Field values
 * ====================================================================== */

function crmSfdcSpecial(string $k, array $l, string $platformLabel): ?string
{
    $created = (string) ($l['createddate'] ?? '');
    $ts = $created !== '' ? strtotime($created) : false;
    $name = trim((string) ($l['name'] ?? ''));
    switch ($k) {
        case 'enquiry_date': return $ts ? date('Y-m-d', $ts) : date('Y-m-d');
        case 'enquiry_datetime': return $ts ? date('Y-m-d H:i:s', $ts) : date('Y-m-d H:i:s');
        case 'enquiry_iso': return $ts ? date('c', $ts) : date('c');
        case 'today': return date('Y-m-d');
        case 'countrycode':
            $cc = preg_replace('/[^\d+]/', '', (string) ($l['countrycode'] ?? ''));
            return $cc === '' ? '' : ($cc[0] === '+' ? $cc : '+' . ltrim($cc, '0'));
        case 'mobile_10': $d = preg_replace('/\D+/', '', (string) ($l['mobile'] ?? '')); return $d === '' ? '' : substr($d, -10);
        case 'first_name': return $name === '' ? '' : (string) preg_split('/\s+/', $name)[0];
        case 'last_name': $p = preg_split('/\s+/', $name, 2); return trim((string) ($p[1] ?? '')) !== '' ? trim($p[1]) : '.';
        case 'lead_id': return (string) ($l['id'] ?? '');
        case 'project_name': return defined('PROJECT_NAME') ? (string) PROJECT_NAME : '';
        case 'platform': return $platformLabel;
    }
    return null;
}

/** Renders one field value for a lead. Unknown names give ''. */
function crmSfdcRender(string $tpl, array $l, string $platformLabel): string
{
    $lower = array_change_key_case($l, CASE_LOWER);
    return preg_replace_callback('/\{([^{}]*)\}/', function ($m) use ($l, $lower, $platformLabel) {
        foreach (explode('|', $m[1]) as $part) {
            $part = trim($part);
            if ($part === '') {
                continue;
            }
            if (preg_match('/^([\'"])(.*)\1$/s', $part, $q)) {
                return $q[2];                                 // 'fixed text'
            }
            if (!preg_match('/^[A-Za-z_][A-Za-z0-9_]*$/', $part)) {
                return $part;                                 // +91, -, N/A …
            }
            $k = strtolower($part);
            $v = array_key_exists($k, CRM_SFDC_SPECIALS) ? crmSfdcSpecial($k, $l, $platformLabel) : pqCleanTrack($lower[$k] ?? '');
            if ($v !== null && trim($v) !== '') {
                return trim($v);
            }
        }
        return '';
    }, $tpl);
}

/** Placeholder names used in a value that are neither a lead column nor a special. */
function crmSfdcUnknownNames(string $tpl, array $columns): array
{
    $cols = array_map('strtolower', $columns);
    $bad = [];
    preg_match_all('/\{([^{}]*)\}/', $tpl, $mm);
    foreach ($mm[1] as $inside) {
        foreach (explode('|', $inside) as $part) {
            $part = trim($part);
            if (preg_match('/^[A-Za-z_][A-Za-z0-9_]*$/', $part) && !array_key_exists(strtolower($part), CRM_SFDC_SPECIALS) && !in_array(strtolower($part), $cols, true)) {
                $bad[] = $part;
            }
        }
    }
    return array_values(array_unique($bad));
}

/** The JSON body for one lead. Fields left empty for this platform are not sent. */
function crmSfdcPayloadFor(array $s, array $l, string $platformLabel): array
{
    $pk = crmSfdcPlatformKey($platformLabel);
    $out = [];
    foreach ($s['fields'] as $f) {
        $tpl = (string) ($f[$pk] ?? '');
        if ($tpl === '') {
            continue;
        }
        $out[$f['name']] = crmSfdcRender($tpl, $l, $platformLabel);
    }
    return $out;
}

/* ======================================================================
 * Salesforce calls
 * ====================================================================== */

/** POST helper. @return array{0:int,1:string,2:string} [http code, body, curl error] */
function crmHttpPost(string $url, $body, array $headers, int $timeout = 30): array
{
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true, CURLOPT_POST => true, CURLOPT_POSTFIELDS => $body, CURLOPT_HTTPHEADER => $headers,
        CURLOPT_TIMEOUT => $timeout, CURLOPT_CONNECTTIMEOUT => 10, CURLOPT_FOLLOWLOCATION => true, CURLOPT_MAXREDIRS => 5,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    ]);
    $out = curl_exec($ch);
    $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $err = curl_error($ch);
    curl_close($ch);
    return [$code, is_string($out) ? $out : '', $err];
}

/** One sign-in. @return array{token:string, instance_url:string, error:string} */
function crmSfdcAuth(array $a): array
{
    if (($a['mode'] ?? '') === '' || trim((string) $a['token_url']) === '') {
        return ['token' => '', 'instance_url' => '', 'error' => 'not set up'];
    }
    $form = ['client_id' => $a['client_id'], 'client_secret' => $a['client_secret']];
    $form = $a['mode'] === 'password'
        ? ['grant_type' => 'password'] + $form + ['username' => $a['username'], 'password' => $a['password']]
        : ['grant_type' => 'client_credentials'] + $form;
    [$code, $body, $err] = crmHttpPost((string) $a['token_url'], http_build_query($form), ['Content-Type: application/x-www-form-urlencoded']);
    $d = json_decode($body, true);
    $tok = (string) ($d['access_token'] ?? '');
    if ($tok !== '') {
        return ['token' => $tok, 'instance_url' => rtrim((string) ($d['instance_url'] ?? ''), '/'), 'error' => ''];
    }
    $why = $err !== '' ? $err : ('HTTP ' . $code . ': ' . (is_array($d) ? trim(($d['error'] ?? '') . ' ' . ($d['error_description'] ?? '')) : mb_substr(strip_tags($body), 0, 160)));
    return ['token' => '', 'instance_url' => '', 'error' => $why];
}

/** Token (primary sign-in, then the backup), cached 30 minutes. @return array{token:string, instance_url:string, via:string} */
function crmSfdcToken(array $s, bool $fresh = false): array
{
    $id = substr(sha1(json_encode([$s['auth']['token_url'], $s['auth']['client_id'], $s['fallback']['token_url'], $s['fallback']['client_id']])), 0, 12);
    $cache = CACHE_PATH . '/sfdc_token_' . $id . '.json';
    if (!$fresh && is_file($cache)) {
        $c = json_decode((string) @file_get_contents($cache), true);
        if (is_array($c) && !empty($c['token']) && ($c['at'] ?? 0) > time() - 1800) {
            return ['token' => (string) $c['token'], 'instance_url' => (string) ($c['instance_url'] ?? ''), 'via' => (string) ($c['via'] ?? 'primary')];
        }
    }
    $errors = [];
    foreach (['primary' => $s['auth'], 'backup' => $s['fallback']] as $via => $a) {
        if (($a['mode'] ?? '') === '') {
            continue;
        }
        $r = crmSfdcAuth($a);
        if ($r['token'] !== '') {
            @file_put_contents($cache, json_encode(['token' => $r['token'], 'instance_url' => $r['instance_url'], 'via' => $via, 'at' => time()]), LOCK_EX);
            @chmod($cache, 0600);
            return ['token' => $r['token'], 'instance_url' => $r['instance_url'], 'via' => $via];
        }
        $errors[] = "$via sign-in: " . $r['error'];
    }
    throw new RuntimeException('Could not sign in to Salesforce (' . ($errors ? implode('; ', $errors) : 'no sign-in set up') . ').');
}

/** Full lead URL (a path is added to the instance URL from the token). */
function crmSfdcLeadUrl(array $s, string $instanceUrl): string
{
    $u = $s['lead_url'];
    if (preg_match('#^https?://#i', $u)) {
        return $u;
    }
    if ($instanceUrl === '') {
        throw new RuntimeException('The lead endpoint is a path, but Salesforce did not return an instance URL. Use the full URL.');
    }
    return $instanceUrl . '/' . ltrim($u, '/');
}

function crmSfdcClearTokenCache(): void
{
    foreach (glob(CACHE_PATH . '/sfdc_token_*.json') ?: [] as $f) {
        @unlink($f);
    }
}
