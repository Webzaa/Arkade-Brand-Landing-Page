<?php
// ===m=== Greetings Codes Started ===m===
require_once dirname(__DIR__, 2) . '/app/bootstrap.php';
require_once dirname(__DIR__, 2) . '/app/Core/db.php';
// session_start();

/* ===m=== Get logged in user ===m=== */
$username = 'Admin'; // ===m== fallback ===m===

if (!empty($_SESSION['uid'])) {
    $stmt = $conn->prepare(
        "SELECT username FROM users WHERE uid = ? AND status = 'Y' LIMIT 1"
    );
    $stmt->bind_param("i", $_SESSION['uid']);
    $stmt->execute();
    $res = $stmt->get_result();

    if ($row = $res->fetch_assoc()) {
        $username = $row['username'];
    }
}

/* ===m=== Greeting by time ===m=== */
$hour = (int) date('H');

if ($hour >= 5 && $hour < 12) {
    $greeting = 'Good Morning';
} elseif ($hour >= 12 && $hour < 17) {
    $greeting = 'Good Afternoon';
} elseif ($hour >= 17 && $hour < 21) {
    $greeting = 'Good Evening';
} else {
    $greeting = 'Good Night';
}
// ===m=== Greetings Codes Ended ===m===
