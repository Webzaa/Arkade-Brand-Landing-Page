<?php
/**
 * app/Leads/unmapped.php — "Unmapped Leads" for Meta and Google in one place.
 *
 * A lead is UNMAPPED when the dashboards can't put it under one of this project's campaigns
 * (the campaigns / adgroups / ads tables, see app/Ads/master_tables.php):
 *   Meta   lead (leadgen_id, or source Facebook / Instagram / …): its ad_id is not a saved ad AND its
 *          campaign_name is not a saved campaign name.
 *   Google lead (source Google / gclid / utm_campaignid): its utm_campaignid is not a saved campaign ID
 *          AND its utm_campaignname is not a saved campaign name.
 *   Unknown source (campaignsource empty, no leadgen_id / gclid): listed so it can be given a platform.
 * Website and Taboola leads are not part of this page. TEST / JUNK and obvious test leads are skipped.
 *
 * Mapping only offers the campaigns, ad sets / ad groups and ads saved in the database, and writes
 * their saved names (Meta → campaign_name / adset_name / ad_name, Google → utm_* columns).
 */

require_once dirname(__DIR__) . '/Core/db.php';
require_once dirname(__DIR__) . '/Ads/master_tables.php';
require_once __DIR__ . '/crm_push.php';

const UM_META_SOURCES = PQ_META_SOURCES;      // app/Ads/master_tables.php — same list as the dashboards
const UM_GOOGLE_SOURCES = PQ_GOOGLE_SOURCES;
const UM_SKIP_SOURCES = ['website', 'taboola', 'native'];   // website = Google's "Website / Direct"; native = Taboola
const UM_TEST_MOBILES = ['9999999999', '8888888888', '0000000000', '1234567890', '1111111111'];
const UM_LOG = 'unmapped_actions.log';

function umNormMobile(?string $m): string
{
    $d = preg_replace('/\D+/', '', (string) $m);
    return strlen($d) > 10 ? substr($d, -10) : $d;
}

/** 'meta' | 'google' | 'unknown' | '' (= not on this page) */
function umPlatformOf(array $l): string
{
    $src = strtolower(trim((string) ($l['campaignsource'] ?? '')));
    if (in_array($src, UM_SKIP_SOURCES, true)) {
        return '';
    }
    if (pqCleanTrack($l['leadgen_id'] ?? '') !== '' || in_array($src, UM_META_SOURCES, true)) {
        return 'meta';
    }
    if (in_array($src, UM_GOOGLE_SOURCES, true) || pqCleanTrack($l['gclid'] ?? '') !== '' || pqCleanTrack($l['utm_campaignid'] ?? '') !== '') {
        return 'google';
    }
    return $src === '' ? 'unknown' : '';     // other sources (referral, walk-in…) aren't ad leads
}

/**
 * Is the lead already under a saved campaign? Returns null when mapped, else the reason.
 * @return array{code:string, text:string, campaign:string}|null
 */
function umUnmappedReason(array $l, string $platform): ?array
{
    if ($platform === 'meta') {
        $s = projectStructure('meta');
        $adId = pqCleanTrack($l['ad_id'] ?? '');
        if ($adId !== '' && isset($s['ads'][$adId])) {
            return null;
        }
        $name = pqCleanTrack($l['campaign_name'] ?? '');
        if ($name === '') {
            $name = pqCleanTrack($l['utm_campaignname'] ?? '');   // click-to-WhatsApp leads carry the campaign in utm_*
        }
        if ($name !== '' && projectCampaignId('meta', null, $name) !== null) {
            return null;
        }
        return $name === ''
            ? ['code' => 'none', 'text' => 'No campaign on the lead', 'campaign' => '']
            : ['code' => 'unlinked', 'text' => 'Campaign is not linked to this project', 'campaign' => $name];
    }
    if ($platform === 'google') {
        $id = pqCleanTrack($l['utm_campaignid'] ?? '');
        $name = pqCleanTrack($l['utm_campaignname'] ?? '');
        if (projectCampaignId('google', $id, $name) !== null) {
            return null;
        }
        $asWeb = !(defined('GOOGLE_UNMAPPED_TO_WEBSITE') && !GOOGLE_UNMAPPED_TO_WEBSITE);
        return ($id === '' && $name === '')
            ? ['code' => 'none', 'text' => 'No campaign on the lead — counted as “Website / Direct” until it is mapped', 'campaign' => '']
            : ['code' => 'unlinked', 'text' => 'Campaign is not linked to this project' . ($asWeb ? ' — counted as “Website / Direct” until it is mapped' : ''), 'campaign' => $name !== '' ? $name : 'ID ' . $id];
    }
    return ['code' => 'source', 'text' => 'No source — choose Meta or Google', 'campaign' => ''];
}

function umIsTestLead(array $l): bool
{
    $st = strtoupper(trim((string) ($l['lead_status'] ?? '')));
    if (in_array($st, ['TEST', 'JUNK'], true)) {
        return true;
    }
    foreach (['name', 'email'] as $f) {
        if (str_contains(strtolower((string) ($l[$f] ?? '')), 'test')) {
            return true;
        }
    }
    $m = trim((string) ($l['mobile'] ?? ''));
    return str_contains(strtolower($m), 'test') || in_array($m, UM_TEST_MOBILES, true);
}

/**
 * Unmapped leads, grouped by platform + mobile (one row per person; the newest lead is shown).
 * @param array{since?:string, until?:string, search?:string} $f
 * @return array{rows: array, counts: array, unlinked: array}
 */
function umList(mysqli $db, array $f): array
{
    $where = ['1=1'];
    if (!empty($f['since'])) {
        $where[] = "createddate >= '" . $db->real_escape_string($f['since']) . " 00:00:00'";
    }
    if (!empty($f['until'])) {
        $where[] = "createddate <= '" . $db->real_escape_string($f['until']) . " 23:59:59'";
    }
    $q = trim((string) ($f['search'] ?? ''));
    if ($q !== '') {
        $e = $db->real_escape_string($q);
        $digits = preg_replace('/\D+/', '', $q);
        $parts = ["name LIKE '%{$e}%'", "email LIKE '%{$e}%'", "leadgen_id = '{$e}'", "gclid = '{$e}'", "uniqueid = '{$e}'"];
        if (strlen($digits) >= 4) {
            $parts[] = "mobile LIKE '%" . $db->real_escape_string($digits) . "%'";
        }
        $where[] = '(' . implode(' OR ', $parts) . ')';
    }
    $sql = 'SELECT id, name, email, mobile, campaignsource, leadgen_id, gclid, ad_id, campaign_name, adset_name, ad_name,
                   utm_campaignid, utm_campaignname, utm_adgroupname, utm_adname, lead_status, createddate, curlresponse
            FROM `lead` WHERE ' . implode(' AND ', $where) . ' ORDER BY createddate DESC';
    $res = $db->query($sql);
    if (!$res) {
        throw new RuntimeException('Could not read the lead table: ' . $db->error);
    }

    $groups = [];
    $unlinked = [];
    while ($l = $res->fetch_assoc()) {
        if (umIsTestLead($l)) {
            continue;
        }
        $p = umPlatformOf($l);
        if ($p === '') {
            continue;
        }
        $why = umUnmappedReason($l, $p);
        if ($why === null) {
            continue;
        }
        $mob = umNormMobile($l['mobile'] ?? '');
        $key = $p . '|' . (strlen($mob) >= 6 ? $mob : 'id' . $l['id']);
        if (!isset($groups[$key])) {
            $groups[$key] = [
                'key' => $key, 'platform' => $p, 'lead_ids' => [], 'leads' => 0,
                'id' => (int) $l['id'], 'name' => (string) $l['name'], 'mobile' => (string) $l['mobile'], 'email' => (string) $l['email'],
                'source' => (string) $l['campaignsource'], 'leadgen_id' => (string) $l['leadgen_id'], 'gclid' => (string) $l['gclid'],
                'status' => (string) $l['lead_status'], 'date' => (string) $l['createddate'], 'first_date' => (string) $l['createddate'],
                'reason' => $why,
                'crm' => array_intersect_key(crmPushResult($l['curlresponse'] ?? ''), ['state' => 1, 'reason' => 1]),
                'current' => $p === 'google'
                    ? ['campaign' => (string) $l['utm_campaignname'], 'group' => (string) $l['utm_adgroupname'], 'ad' => (string) $l['utm_adname']]
                    : ['campaign' => (string) $l['campaign_name'], 'group' => (string) $l['adset_name'], 'ad' => (string) $l['ad_name']],
            ];
        }
        $g = &$groups[$key];
        $g['lead_ids'][] = (int) $l['id'];
        $g['leads']++;
        $g['first_date'] = (string) $l['createddate'];
        unset($g);
        if ($why['code'] === 'unlinked') {
            $uk = $p . '|' . $why['campaign'];
            $unlinked[$uk] = ['platform' => $p, 'campaign' => $why['campaign'], 'leads' => ($unlinked[$uk]['leads'] ?? 0) + 1];
        }
    }
    $rows = array_values($groups);
    $counts = ['all' => count($rows), 'meta' => 0, 'google' => 0, 'unknown' => 0];
    foreach ($rows as $r) {
        $counts[$r['platform']]++;
    }
    usort($unlinked, fn($a, $b) => $b['leads'] <=> $a['leads']);
    return ['rows' => $rows, 'counts' => $counts, 'unlinked' => array_values($unlinked)];
}

/** Saved campaigns → ad sets / ad groups → ads, for the mapping dropdowns. */
function umStructure(string $platform): array
{
    $s = projectStructure($platform);
    $camps = [];
    foreach ($s['campaigns'] as $cid => $name) {
        $camps[(string) $cid] = ['id' => (string) $cid, 'name' => $name, 'groups' => []];
    }
    foreach ($s['adgroups'] as $gid => $g) {
        if (isset($camps[$g['campaign_id']])) {
            $camps[$g['campaign_id']]['groups'][(string) $gid] = ['id' => (string) $gid, 'name' => $g['name'], 'ads' => []];
        }
    }
    foreach ($s['ads'] as $aid => $a) {
        $g = $s['adgroups'][$a['adgroup_id']] ?? null;
        if ($g && isset($camps[$g['campaign_id']]['groups'][$a['adgroup_id']])) {
            $camps[$g['campaign_id']]['groups'][$a['adgroup_id']]['ads'][] = ['id' => (string) $aid, 'name' => $a['name']];
        }
    }
    $out = [];
    foreach ($camps as $c) {
        $groups = array_values($c['groups']);
        foreach ($groups as &$g) {
            usort($g['ads'], fn($x, $y) => strcasecmp($x['name'], $y['name']));
        }
        unset($g);
        usort($groups, fn($x, $y) => strcasecmp($x['name'], $y['name']));
        $out[] = ['id' => $c['id'], 'name' => $c['name'], 'groups' => $groups];
    }
    usort($out, fn($x, $y) => strcasecmp($x['name'], $y['name']));
    return $out;
}

/** Resolves a choice to saved IDs + names; throws when it isn't in the database. */
function umResolveChoice(string $platform, string $campaignId, string $groupId = '', string $adId = ''): array
{
    $s = projectStructure($platform);
    if (!isset($s['campaigns'][$campaignId])) {
        throw new InvalidArgumentException('Choose a campaign saved for this project.');
    }
    $out = ['campaign_id' => $campaignId, 'campaign' => $s['campaigns'][$campaignId], 'group_id' => '', 'group' => '', 'ad_id' => '', 'ad' => ''];
    if ($groupId !== '') {
        $g = $s['adgroups'][$groupId] ?? null;
        if (!$g || (string) $g['campaign_id'] !== $campaignId) {
            throw new InvalidArgumentException('That ad set / ad group is not part of the chosen campaign.');
        }
        $out['group_id'] = $groupId;
        $out['group'] = $g['name'];
    }
    if ($adId !== '') {
        $a = $s['ads'][$adId] ?? null;
        if (!$a || $groupId === '' || (string) $a['adgroup_id'] !== $groupId) {
            throw new InvalidArgumentException('That ad is not part of the chosen ad set / ad group.');
        }
        $out['ad_id'] = $adId;
        $out['ad'] = $a['name'];
    }
    return $out;
}

/** Writes the mapping onto the given leads. Returns the number of leads changed. */
function umMap(mysqli $db, string $platform, array $leadIds, array $c): int
{
    $ids = array_values(array_unique(array_filter(array_map('intval', $leadIds), fn($v) => $v > 0)));
    if (!$ids) {
        throw new InvalidArgumentException('No leads selected.');
    }
    if ($platform === 'meta') {
        $st = $db->prepare("UPDATE `lead` SET campaign_name = ?, adset_name = ?, ad_name = ?,
                ad_id = CASE WHEN ? <> '' AND (ad_id IS NULL OR TRIM(ad_id) = '') THEN ? ELSE ad_id END,
                campaignsource = CASE WHEN campaignsource IS NULL OR TRIM(campaignsource) = '' THEN 'Facebook Lead Form' ELSE campaignsource END
            WHERE id = ?");
    } else {
        $st = $db->prepare("UPDATE `lead` SET utm_campaignname = ?, utm_campaignid = ?, utm_adgroupname = ?, utm_adgroupid = ?, utm_adname = ?, utm_adid = ?,
                campaignsource = CASE WHEN campaignsource IS NULL OR TRIM(campaignsource) = '' THEN 'Google' ELSE campaignsource END
            WHERE id = ?");
    }
    if (!$st) {
        throw new RuntimeException('Could not prepare the update: ' . $db->error);
    }
    $n = 0;
    $db->begin_transaction();
    try {
        foreach ($ids as $id) {
            if ($platform === 'meta') {
                $st->bind_param('sssssi', $c['campaign'], $c['group'], $c['ad'], $c['ad_id'], $c['ad_id'], $id);
            } else {
                $st->bind_param('ssssssi', $c['campaign'], $c['campaign_id'], $c['group'], $c['group_id'], $c['ad'], $c['ad_id'], $id);
            }
            if (!$st->execute()) {
                throw new RuntimeException("Lead {$id} could not be updated: " . $db->error);
            }
            $n++;
        }
        $db->commit();
    } catch (Throwable $e) {
        $db->rollback();
        throw $e;
    } finally {
        $st->close();
    }
    masterClearDashboardCache();
    return $n;
}

function umMarkStatus(mysqli $db, array $leadIds, string $status): int
{
    if (!in_array($status, ['TEST', 'JUNK'], true)) {
        throw new InvalidArgumentException('Status must be TEST or JUNK.');
    }
    $ids = array_values(array_unique(array_filter(array_map('intval', $leadIds), fn($v) => $v > 0)));
    if (!$ids) {
        throw new InvalidArgumentException('No leads selected.');
    }
    $ok = $db->query("UPDATE `lead` SET lead_status = '{$status}' WHERE id IN (" . implode(',', $ids) . ')');
    if (!$ok) {
        throw new RuntimeException('Could not update: ' . $db->error);
    }
    masterClearDashboardCache();
    return count($ids);
}

/**
 * CSV import (dry run or write): each row has mobile / leadgen_id / gclid, platform, campaign, ad set, ad
 * (names as saved). Only leads that are currently unmapped are changed.
 */
function umImport(mysqli $db, array $rows, bool $write): array
{
    $all = umList($db, []);
    $byMobile = [];
    $byLeadgen = [];
    $byGclid = [];
    foreach ($all['rows'] as $g) {
        $m = umNormMobile($g['mobile']);
        if (strlen($m) >= 6) {
            $byMobile[$m][] = $g;
        }
        if ($g['leadgen_id'] !== '') {
            $byLeadgen[$g['leadgen_id']][] = $g;
        }
        if ($g['gclid'] !== '') {
            $byGclid[$g['gclid']][] = $g;
        }
    }
    $out = [];
    $plan = [];
    foreach ($rows as $i => $r) {
        $n = $i + 2;   // file row (after the header)
        $platform = strtolower(trim((string) ($r['platform'] ?? '')));
        $platform = str_contains($platform, 'google') ? 'google' : (preg_match('/meta|facebook|fb|insta/', $platform) ? 'meta' : $platform);
        $res = ['row' => $n, 'id' => trim((string) ($r['mobile'] ?? $r['leadgen_id'] ?? $r['gclid'] ?? '')), 'ok' => false, 'message' => '', 'leads' => 0];
        $found = [];
        $mob = umNormMobile($r['mobile'] ?? '');
        if (strlen($mob) >= 6 && isset($byMobile[$mob])) $found = $byMobile[$mob];
        elseif (!empty($r['leadgen_id']) && isset($byLeadgen[trim($r['leadgen_id'])])) $found = $byLeadgen[trim($r['leadgen_id'])];
        elseif (!empty($r['gclid']) && isset($byGclid[trim($r['gclid'])])) $found = $byGclid[trim($r['gclid'])];
        if (!$found) {
            $out[] = array_merge($res, ['message' => 'No unmapped lead with this mobile / ID']);
            continue;
        }
        if (!in_array($platform, ['meta', 'google'], true)) {
            $platform = $found[0]['platform'] === 'unknown' ? '' : $found[0]['platform'];
        }
        if ($platform === '') {
            $out[] = array_merge($res, ['message' => 'Platform missing (Meta or Google)']);
            continue;
        }
        try {
            $s = projectStructure($platform);
            $cid = projectCampaignId($platform, (string) ($r['campaign_id'] ?? ''), (string) ($r['campaign'] ?? $r['campaign_name'] ?? ''));
            if ($cid === null) {
                throw new InvalidArgumentException('Campaign "' . ($r['campaign'] ?? $r['campaign_name'] ?? '') . '" is not saved for this project');
            }
            $gid = '';
            $gName = trim((string) ($r['adgroup'] ?? $r['adset'] ?? $r['adset_name'] ?? $r['adgroup_name'] ?? ''));
            if ($gName !== '') {
                $gid = (string) projectAdgroupId($platform, $cid, null, $gName);
                if ($gid === '') {
                    throw new InvalidArgumentException("Ad set / ad group \"{$gName}\" is not in that campaign");
                }
            }
            $aid = '';
            $aName = trim((string) ($r['ad'] ?? $r['ad_name'] ?? ''));
            if ($aName !== '' && $gid !== '') {
                $aid = (string) projectAdId($platform, $gid, null, $aName);
                if ($aid === '') {
                    throw new InvalidArgumentException("Ad \"{$aName}\" is not in that ad set / ad group");
                }
            }
            $choice = umResolveChoice($platform, $cid, $gid, $aid);
            $ids = [];
            foreach ($found as $g) {
                if ($g['platform'] === $platform || $g['platform'] === 'unknown') {
                    $ids = array_merge($ids, $g['lead_ids']);
                }
            }
            if (!$ids) {
                throw new InvalidArgumentException('The lead is a ' . ucfirst($found[0]['platform']) . ' lead, not ' . ucfirst($platform));
            }
            $plan[] = [$platform, $ids, $choice];
            $out[] = array_merge($res, ['ok' => true, 'leads' => count($ids), 'message' => $choice['campaign'] . ($choice['group'] ? ' › ' . $choice['group'] : '') . ($choice['ad'] ? ' › ' . $choice['ad'] : '')]);
        } catch (InvalidArgumentException $e) {
            $out[] = array_merge($res, ['message' => $e->getMessage()]);
        }
    }
    $written = 0;
    if ($write) {
        foreach ($plan as [$p, $ids, $choice]) {
            $written += umMap($db, $p, $ids, $choice);
        }
    }
    return ['rows' => $out, 'ok' => count(array_filter($out, fn($r) => $r['ok'])), 'failed' => count(array_filter($out, fn($r) => !$r['ok'])),
            'leads' => array_sum(array_column(array_filter($out, fn($r) => $r['ok']), 'leads')), 'written' => $written];
}

function umLog(string $user, string $action, array $data): void
{
    @file_put_contents(LOG_PATH . '/' . UM_LOG, json_encode(['at' => date('c'), 'by' => $user, 'action' => $action] + $data, JSON_UNESCAPED_UNICODE) . "\n", FILE_APPEND);
}
