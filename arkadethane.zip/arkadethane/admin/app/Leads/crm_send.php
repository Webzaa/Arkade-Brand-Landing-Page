<?php
/**
 * app/Leads/crm_send.php — "Send to CRM" on the CRM Push page: pushes failed / not-sent leads to Salesforce.
 *
 * Salesforce sign-in, endpoint and field list come from Admin → CRM Settings (app/Leads/crm_sfdc.php);
 * an older CRM_SFDC block in config.php still works when nothing was saved there.
 * The JSON is built with json_encode, so a quote or line break in a name can no longer break the request.
 *
 * Safety:
 *   - only leads whose saved CRM reply is still "failed" or "not sent" (checked again right before each send,
 *     so two people clicking at once cannot create the lead twice), and only platforms turned on in the settings;
 *   - never test leads; one batch at a time per database (MySQL lock);
 *   - a batch stops as soon as Salesforce says its daily request / email limit is reached.
 * Result: the Salesforce reply is saved in lead.curlresponse (the CRM Push page reads it from there) and
 * every attempt is logged in crm_push_log (who, when, request, reply).
 */

require_once __DIR__ . '/crm_push.php';
require_once __DIR__ . '/crm_sfdc.php';

const CRM_SEND_MAX_BATCH = 25;

/** Why leads of this platform (Meta / Google / anything else) cannot be sent ('' = they can). */
function crmSfdcPlatformProblem(array $s, string $platformLabel): string
{
    $pk = crmSfdcPlatformKey($platformLabel);
    if (empty($s['platforms'][$pk])) {
        return $pk === 'other' ? 'Sending is turned off for leads that are not from Meta or Google' : "Sending is turned off for {$platformLabel} leads";
    }
    foreach ($s['fields'] as $f) {
        if (strtolower($f['name']) === 'campaignid' && trim((string) ($f[$pk] ?? '')) === '') {
            return "Salesforce campaign ID for " . CRM_SFDC_PLATFORMS[$pk] . ' is empty (Admin → CRM Settings)';
        }
    }
    return '';
}

/** What the CRM Push page needs to show the buttons. */
function crmSendStatus(): array
{
    $s = crmSfdcActive();
    if ($s === null) {
        return ['ready' => false, 'platforms' => [], 'problems' => (object) [], 'other' => false];
    }
    $problems = [];
    $ok = [];
    foreach (['Meta', 'Google', 'Other'] as $p) {
        $why = crmSfdcPlatformProblem($s, $p);
        $why === '' ? $ok[] = $p : $problems[$p] = $why;
    }
    return ['ready' => true, 'platforms' => $ok, 'problems' => (object) $problems, 'other' => in_array('Other', $ok, true)];
}

function crmLogTable(mysqli $db): void
{
    $db->query("CREATE TABLE IF NOT EXISTS `crm_push_log` (
        `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        `lead_id` INT NOT NULL,
        `sent_at` DATETIME NOT NULL,
        `sent_by` VARCHAR(100) DEFAULT NULL,
        `platform` VARCHAR(20) DEFAULT NULL,
        `http_code` INT DEFAULT NULL,
        `result` VARCHAR(20) DEFAULT NULL,
        `crm_id` VARCHAR(40) DEFAULT NULL,
        `request` TEXT,
        `response` MEDIUMTEXT,
        KEY `lead_id` (`lead_id`),
        KEY `sent_at` (`sent_at`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
}

/**
 * Sends the given leads. @return array{results: list<array>, stopped: string}
 * Each result: id, name, state (sent|existing|failed|skipped), reason, crm_id
 */
function crmSendLeads(mysqli $db, array $ids, string $user): array
{
    $s = crmSfdcActive();
    if ($s === null) {
        throw new RuntimeException('Salesforce is not set up or turned off: Admin → CRM Settings.');
    }
    $ids = array_values(array_unique(array_filter(array_map('intval', $ids), fn($v) => $v > 0)));
    if (!$ids) {
        throw new RuntimeException('No leads selected.');
    }
    if (count($ids) > CRM_SEND_MAX_BATCH) {
        throw new RuntimeException('Send at most ' . CRM_SEND_MAX_BATCH . ' leads per request.');
    }
    crmLogTable($db);
    $lockName = 'pq_crm_send_' . substr(sha1(crmDbName($db)), 0, 16);
    $got = $db->query("SELECT GET_LOCK('" . $db->real_escape_string($lockName) . "', 0) AS l");
    if (!$got || (int) ($got->fetch_assoc()['l'] ?? 0) !== 1) {
        throw new RuntimeException('Someone else is sending leads to the CRM right now. Try again in a minute.');
    }
    $results = [];
    $stopped = '';
    try {
        $tok = crmSfdcToken($s);
        $url = crmSfdcLeadUrl($s, $tok['instance_url']);
        $sel = $db->prepare('SELECT * FROM `lead` WHERE id = ?');
        $upd = $db->prepare('UPDATE `lead` SET curlresponse = ? WHERE id = ?');
        $log = $db->prepare('INSERT INTO `crm_push_log` (lead_id, sent_at, sent_by, platform, http_code, result, crm_id, request, response) VALUES (?, NOW(), ?, ?, ?, ?, ?, ?, ?)');
        foreach ($ids as $id) {
            if ($stopped !== '') {
                $results[] = ['id' => $id, 'name' => '', 'state' => 'skipped', 'reason' => 'Not tried: ' . $stopped, 'crm_id' => ''];
                continue;
            }
            $sel->bind_param('i', $id);
            $sel->execute();
            $l = $sel->get_result()->fetch_assoc();
            if (!$l) {
                $results[] = ['id' => $id, 'name' => '', 'state' => 'skipped', 'reason' => 'Lead not found', 'crm_id' => ''];
                continue;
            }
            $name = (string) $l['name'];
            $now = crmPushResult($l['curlresponse']);
            if (!in_array($now['state'], ['failed', 'not_sent'], true)) {
                $results[] = ['id' => $id, 'name' => $name, 'state' => 'skipped', 'reason' => $now['state'] === 'sent' ? 'Already in the CRM' : 'CRM already matched it to an account', 'crm_id' => $now['crm_id']];
                continue;
            }
            if (crmIsTestLead($l)) {
                $results[] = ['id' => $id, 'name' => $name, 'state' => 'skipped', 'reason' => 'Test lead — not sent', 'crm_id' => ''];
                continue;
            }
            $platform = crmPlatform($l);
            $why = crmSfdcPlatformProblem($s, $platform);
            if ($why !== '') {
                $results[] = ['id' => $id, 'name' => $name, 'state' => 'skipped', 'reason' => $why, 'crm_id' => ''];
                continue;
            }
            if (trim((string) $l['mobile']) === '' && trim((string) $l['email']) === '') {
                $results[] = ['id' => $id, 'name' => $name, 'state' => 'skipped', 'reason' => 'No mobile or email on the lead', 'crm_id' => ''];
                continue;
            }
            $payload = json_encode(crmSfdcPayloadFor($s, $l, $platform), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            $send = fn($t) => crmHttpPost($url, $payload, ['Authorization: Bearer ' . $t, 'Content-Type: application/json']);
            [$code, $body, $err] = $send($tok['token']);
            if ($code === 401) {                         // token expired — get a new one, try once more
                $tok = crmSfdcToken($s, true);
                [$code, $body, $err] = $send($tok['token']);
            }
            $r = $err !== '' || $code === 0
                ? ['state' => 'failed', 'key' => 'network', 'reason' => 'Could not reach Salesforce: ' . ($err ?: 'no reply'), 'crm_id' => '']
                : crmPushResult($body);
            $state = $r['state'] === 'not_sent' ? 'failed' : $r['state'];
            if ($state === 'failed' && $r['reason'] === 'No CRM reply saved for this lead') {
                $r['reason'] = 'Salesforce sent an empty reply (HTTP ' . $code . ')';
            }
            // Saved like the website's newer wrapper, so the CRM Push page reads it the same way.
            $saved = json_encode([
                'success' => $state === 'sent', 'stage' => 'salesforce_lead', 'http_code' => $code,
                'response' => $body !== '' ? $body : null, 'message' => $err !== '' ? $err : null,
                'via' => 'admin', 'sent_by' => $user, 'sent_at' => date('Y-m-d H:i:s'),
            ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            $upd->bind_param('si', $saved, $id);
            $upd->execute();
            $plat = crmSfdcPlatformKey($platform);
            $resp = $body !== '' ? $body : $err;
            $log->bind_param('ississss', $id, $user, $plat, $code, $state, $r['crm_id'], $payload, $resp);
            $log->execute();
            $results[] = ['id' => $id, 'name' => $name, 'state' => $state, 'reason' => $r['reason'], 'crm_id' => $r['crm_id']];
            if ($state === 'failed' && in_array($r['key'], ['limit', 'email_limit'], true)) {
                $stopped = $r['reason'];
            }
        }
    } finally {
        $db->query("DO RELEASE_LOCK('" . $db->real_escape_string($lockName) . "')");
    }
    return ['results' => $results, 'stopped' => $stopped];
}

/** Database name for the lock key (one batch at a time per database). */
function crmDbName(mysqli $db): string
{
    $r = $db->query('SELECT DATABASE() AS d');
    return $r ? (string) ($r->fetch_assoc()['d'] ?? '') : '';
}
