<?php
/**
 * app/Leads/status_filter.php — the "Lead status" filter of Leads & CRM (list, charts and Excel export).
 * Values come from a fixed list, so the SQL never contains user text.
 */

const PQ_LEAD_STATUS_FILTERS = [
    'QUALIFIED'       => 'Qualified (counts for CPQL)',
    'TO BE QUALIFIED' => 'To be qualified',
    'NON-QUALIFIED'   => 'Non-qualified',
    '__none'          => 'No status yet',
    'SITE_VISIT'      => 'Site visit done (counts for CPSV)',
    'TEST'            => 'Test',
    'JUNK'            => 'Junk',
];

/** SQL condition for a filter value ('' = no filter). */
function pqLeadStatusFilterSql(string $v): string
{
    $st = "UPPER(TRIM(COALESCE(lead_status, '')))";
    switch ($v) {
        case 'QUALIFIED':
            return "{$st} IN ('QUALIFIED', 'LOST POST QUALIFIED', 'LOST POST QUALIFICATION')";
        case 'TO BE QUALIFIED':
            return "{$st} IN ('TO BE QUALIFIED', 'TBQ')";
        case 'NON-QUALIFIED':
            return "{$st} IN ('NON-QUALIFIED', 'NON QUALIFIED', 'NOT QUALIFIED', 'UNQUALIFIED', 'DISQUALIFIED')";
        case '__none':
            return "{$st} = ''";
        case 'SITE_VISIT':
            return "UPPER(TRIM(COALESCE(sitevisit_status, ''))) IN ('VISITED', 'VISIT DONE', 'SITE VISIT DONE', 'SITE VISIT', 'WALKIN', 'WALK-IN', 'DONE', 'YES', 'CONDUCTED')";
        case 'TEST':
        case 'JUNK':
            return "{$st} = '{$v}'";
    }
    return '';
}

/** The filter of the current request (POST lead_status). */
function pqLeadStatusFilterFromRequest(): string
{
    $v = (string) ($_POST['lead_status'] ?? $_GET['lead_status'] ?? '');
    return isset(PQ_LEAD_STATUS_FILTERS[$v]) ? pqLeadStatusFilterSql($v) : '';
}
