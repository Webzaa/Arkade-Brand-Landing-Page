<?php
/**
 * app/Leads/crm_push.php — did each lead reach the CRM?
 *
 * The website saves the CRM (Salesforce) reply of every lead in lead.curlresponse. This reads it:
 *   sent      status 200 + a Lead ID (00Q…), or {"success":true,…}
 *   existing  no status, an Account ID (001…) — the CRM matched an existing customer, no new lead
 *   failed    status 400 / an error list (limit reached, field value not allowed, …)
 *   not_sent  nothing saved — the lead was never sent (or the reply was lost)
 * The website sends leads to the CRM; failed / not-sent Meta and Google leads can be sent again from the
 * CRM Push page ("Send to CRM", app/Leads/crm_send.php — needs CRM_SFDC in config.php).
 */

require_once dirname(__DIR__) . '/Core/db.php';
require_once dirname(__DIR__) . '/Ads/master_tables.php';

const CRM_STATES = ['sent' => 'Sent', 'existing' => 'Matched existing account', 'failed' => 'Failed', 'not_sent' => 'Not sent'];

/** Unwraps the saved reply (it is often JSON inside a JSON string, sometimes wrapped in {"success":…,"response":…}). */
function crmDecode(?string $raw)
{
    $v = trim((string) $raw);
    for ($i = 0; $i < 4 && is_string($v); $i++) {
        $d = json_decode($v, true);
        if ($d === null && json_last_error() !== JSON_ERROR_NONE) {
            break;
        }
        $v = $d;
    }
    if (is_array($v) && isset($v['response']) && is_string($v['response'])) {
        $inner = crmDecode($v['response']);
        if (is_array($inner)) {
            $v = $inner + ['_wrapper_success' => $v['success'] ?? null];
        }
    }
    return $v;
}

/** Plain-words reason for a CRM error text. Returns [key, text]. */
function crmReason(string $msg): array
{
    $m = trim(preg_replace('/\s+/', ' ', strip_tags($msg)));
    if (preg_match('/REQUEST_LIMIT_EXCEEDED|TotalRequests Limit/i', $m)) {
        return ['limit', 'CRM daily request limit reached'];
    }
    if (preg_match('/SINGLE_EMAIL_LIMIT_EXCEEDED|Email limit exceeded/i', $m)) {
        return ['email_limit', 'CRM email limit reached'];
    }
    if (preg_match('/RESTRICTED_PICKLIST.*?(?:field:\s*)?([^:\[]+)?:\s*\[(\w+)\]/i', $m, $x)) {
        $val = trim((string) ($x[1] ?? ''));
        $field = str_replace(['__c', '_'], ['', ' '], $x[2]);
        return ['picklist_' . strtolower($x[2]) . '_' . strtolower($val), "Value “{$val}” not allowed in CRM field {$field}"];
    }
    if (preg_match('/REQUIRED_FIELD_MISSING.*?\[([^\]]+)\]/i', $m, $x)) {
        return ['required_' . strtolower($x[1]), 'Required CRM field missing: ' . $x[1]];
    }
    if (preg_match('/FIELD_CUSTOM_VALIDATION_EXCEPTION,\s*([^:]+)/i', $m, $x)) {
        return ['validation_' . strtolower(substr(preg_replace('/\W+/', '_', $x[1]), 0, 40)), 'CRM validation rule: ' . trim($x[1])];
    }
    if (preg_match('/DUPLICATE/i', $m)) {
        return ['duplicate', 'CRM blocked it as a duplicate'];
    }
    if (preg_match('/^Invalid format/i', $m)) {
        return ['date_format', 'CRM rejected the date format'];
    }
    if (preg_match('/Unexpected character|JSON|malformed/i', $m)) {
        return ['bad_request', 'Bad data sent to CRM (format error)'];
    }
    return ['other', $m === '' ? 'CRM returned an error' : mb_substr($m, 0, 140)];
}

/** @return array{state:string, key:string, reason:string, crm_id:string} */
function crmPushResult(?string $raw): array
{
    if (trim((string) $raw) === '' || trim((string) $raw) === 'null' || trim((string) $raw) === '""') {
        return ['state' => 'not_sent', 'key' => 'not_sent', 'reason' => 'No CRM reply saved for this lead', 'crm_id' => ''];
    }
    $d = crmDecode($raw);
    if (!is_array($d)) {
        $txt = trim((string) $d);
        if (preg_match('/^(success|ok|lead (created|saved|inserted)|inserted|saved)\b/i', $txt)) {
            return ['state' => 'sent', 'key' => 'sent', 'reason' => '', 'crm_id' => ''];
        }
        [$k, $t] = crmReason($txt);
        return ['state' => 'failed', 'key' => $k, 'reason' => $t, 'crm_id' => ''];
    }
    if (isset($d[0]) && is_array($d[0])) {            // [{"message":…,"errorCode":…}]
        [$k, $t] = crmReason(($d[0]['errorCode'] ?? '') . ' ' . ($d[0]['message'] ?? ''));
        return ['state' => 'failed', 'key' => $k, 'reason' => $t, 'crm_id' => ''];
    }
    // Works with any CRM's reply: Salesforce {"status":"200","responseId":"00Q…"}, wrappers {"success":true,…},
    // and others such as {"status":"success","message":"<lead id>"} (Hiranandani Westgate) or {"code":200}.
    $raw0 = $d['status'] ?? $d['Status'] ?? $d['code'] ?? $d['statusCode'] ?? $d['http_code'] ?? null;
    $status = is_bool($raw0) ? ($raw0 ? 'true' : 'false') : strtolower(trim((string) ($raw0 ?? '')));
    $flag = $d['success'] ?? $d['Success'] ?? $d['_wrapper_success'] ?? null;
    $msg = trim((string) (is_scalar($d['message'] ?? null) ? $d['message'] : ''));
    $id = (string) ($d['leadId'] ?? $d['lead_id'] ?? $d['responseId'] ?? $d['id'] ?? $d['LeadId'] ?? '');
    $isSfId = (bool) preg_match('/^[a-zA-Z0-9]{15}([a-zA-Z0-9]{3})?$/', $id);
    $okWords = ['200', '201', '202', 'success', 'successful', 'ok', 'true', '1', 'created', 'done'];
    $badWords = ['400', '401', '403', '404', '409', '422', '429', '500', '502', '503', 'error', 'fail', 'failed', 'failure', 'false', '0'];
    $hasError = !empty($d['errorCode']) || !empty($d['error']) || !empty($d['errors'])
        || (isset($d['errorcode']) && $d['errorcode'] !== null && $d['errorcode'] !== '');

    $ok = !$hasError && (in_array($status, $okWords, true) || $flag === true || $flag === 'true'
        || ($status === '' && strcasecmp($msg, 'success') === 0));
    if ($ok && !($status === '200' && $id !== '' && !$isSfId && preg_match('/failed|exception|error/i', $id))) {
        if ($id === '' && $msg !== '' && preg_match('/^[A-Za-z0-9_\-]{10,}$/', $msg)) {
            $id = $msg;                       // e.g. {"status":"success","message":"2026102104035531…"} — the CRM's lead ID
        }
        return ['state' => 'sent', 'key' => 'sent', 'reason' => '', 'crm_id' => $id];
    }
    if ($status === '' && !$hasError && $isSfId) {
        return str_starts_with($id, '001')
            ? ['state' => 'existing', 'key' => 'existing', 'reason' => 'CRM matched an existing account — no new lead created', 'crm_id' => $id]
            : ['state' => 'sent', 'key' => 'sent', 'reason' => '', 'crm_id' => $id];
    }
    $text = $isSfId ? '' : $id;
    if ($text === '') {
        foreach (['message', 'error', 'errors', 'errorcode', 'errorCode', 'msg'] as $k) {
            if (!empty($d[$k])) {
                $text = is_scalar($d[$k]) ? (string) $d[$k] : json_encode($d[$k]);
                break;
            }
        }
    }
    [$k, $t] = crmReason($text);
    if ($status !== '' && !in_array($status, ['400', 'error', 'fail', 'failed', 'false'], true)) {
        $t .= ctype_digit($status) ? " (HTTP {$status})" : " (status “{$status}”)";
    }
    return ['state' => 'failed', 'key' => $k, 'reason' => $t, 'crm_id' => ''];
}

function crmIsTestLead(array $l): bool
{
    if (in_array(strtoupper(trim((string) ($l['lead_status'] ?? ''))), ['TEST', 'JUNK'], true)) {
        return true;
    }
    foreach (['name', 'email', 'mobile'] as $f) {
        if (str_contains(strtolower((string) ($l[$f] ?? '')), 'test')) {
            return true;
        }
    }
    return false;
}

function crmPlatform(array $l): string
{
    $src = strtolower(trim((string) ($l['campaignsource'] ?? '')));
    if (pqCleanTrack($l['leadgen_id'] ?? '') !== '' || in_array($src, PQ_META_SOURCES, true)) {
        return 'Meta';
    }
    if (in_array($src, PQ_GOOGLE_SOURCES, true) || pqCleanTrack($l['gclid'] ?? '') !== '') {
        return 'Google';
    }
    return $src === '' ? 'No source' : ucfirst((string) $l['campaignsource']);
}

/**
 * CRM push results for a period.
 * @param array{since?:string, until?:string, search?:string, tests?:bool} $f
 */
function crmList(mysqli $db, array $f): array
{
    $where = ['1=1'];
    if (!empty($f['since'])) {
        $where[] = "createddate >= '" . $db->real_escape_string($f['since']) . " 00:00:00'";
    }
    if (!empty($f['until'])) {
        $where[] = "createddate <= '" . $db->real_escape_string($f['until']) . " 23:59:59'";
    }
    $q = trim((string) ($f['search'] ?? ''));
    if ($q !== '') {
        $e = $db->real_escape_string($q);
        $parts = ["name LIKE '%{$e}%'", "email LIKE '%{$e}%'", "campaign_name LIKE '%{$e}%'", "utm_campaignname LIKE '%{$e}%'"];
        $digits = preg_replace('/\D+/', '', $q);
        if (strlen($digits) >= 4) {
            $parts[] = "mobile LIKE '%" . $db->real_escape_string($digits) . "%'";
        }
        $where[] = '(' . implode(' OR ', $parts) . ')';
    }
    $res = $db->query('SELECT id, name, email, mobile, campaignsource, leadgen_id, gclid, campaign_name, utm_campaignname,
                              lead_status, createddate, curlresponse
                       FROM `lead` WHERE ' . implode(' AND ', $where) . ' ORDER BY createddate DESC');
    if (!$res) {
        throw new RuntimeException('Could not read the lead table: ' . $db->error);
    }
    $counts = ['total' => 0, 'sent' => 0, 'existing' => 0, 'failed' => 0, 'not_sent' => 0, 'tests_skipped' => 0];
    $reasons = [];
    $rows = [];
    while ($l = $res->fetch_assoc()) {
        if (empty($f['tests']) && crmIsTestLead($l)) {
            $counts['tests_skipped']++;
            continue;
        }
        $r = crmPushResult($l['curlresponse']);
        $counts['total']++;
        $counts[$r['state']]++;
        if ($r['state'] === 'sent') {
            continue;
        }
        if ($r['state'] !== 'existing') {
            $rk = $r['key'];
            $reasons[$rk] ??= ['key' => $rk, 'state' => $r['state'], 'reason' => $r['reason'], 'leads' => 0, 'latest' => (string) $l['createddate']];
            $reasons[$rk]['leads']++;
        }
        $camp = pqCleanTrack($l['campaign_name']) !== '' ? $l['campaign_name'] : pqCleanTrack($l['utm_campaignname']);
        $rows[] = [
            'id' => (int) $l['id'], 'date' => (string) $l['createddate'], 'name' => (string) $l['name'], 'mobile' => (string) $l['mobile'],
            'email' => (string) $l['email'], 'source' => (string) $l['campaignsource'], 'platform' => crmPlatform($l),
            'campaign' => (string) $camp, 'status' => (string) $l['lead_status'],
            'state' => $r['state'], 'key' => $r['key'], 'reason' => $r['reason'], 'crm_id' => $r['crm_id'],
            'raw' => mb_substr((string) $l['curlresponse'], 0, 1500),
            'test' => crmIsTestLead($l),
        ];
    }
    usort($reasons, fn($a, $b) => $b['leads'] <=> $a['leads']);
    return ['counts' => $counts, 'reasons' => array_values($reasons), 'rows' => $rows];
}
