<?php
/**
 * otp_mail.php — the login code email (template + sending).
 *
 *   otpEmailHtml($otp, $email, $minutes)  → [subject, html, text]
 *   sendLoginOtpMail($email, $otp)        → true when sent
 *
 * How the email is sent (config.php, optional):
 *   define('OTP_MAIL_VIA', 'smtp');   // default: this admin's SMTP (same as the report emails), old mailer API as fallback
 *   define('OTP_MAIL_VIA', 'api');    // only the old external mailer API (its own template)
 *   define('OTP_MAIL_API_URL', 'https://wzpocs.in/admin/Go_Daddy_Admin/mailer/sendMail.php');
 */

require_once dirname(__DIR__) . '/bootstrap.php';

const OTP_MAIL_DEFAULT_API = 'https://wzpocs.in/admin/Go_Daddy_Admin/mailer/sendMail.php';
const OTP_VALID_MINUTES = 5;

function otpH(string $s): string
{
    return htmlspecialchars($s, ENT_QUOTES, 'UTF-8');
}

function otpProjectName(): string
{
    return defined('PROJECT_NAME') && trim((string) PROJECT_NAME) !== '' ? trim((string) PROJECT_NAME) : 'Webzaa Admin';
}

function otpLogoUrl(): string
{
    if (defined('REPORT_LOGO_URL') && trim((string) REPORT_LOGO_URL) !== '') {
        return (string) REPORT_LOGO_URL;
    }
    return defined('APP_URL') ? rtrim((string) APP_URL, '/') . '/assets/images/webzaa-logo.png' : '';
}

/** @return array{0:string,1:string,2:string} subject, html, plain text */
function otpEmailHtml(string $otp, string $email, int $minutes = OTP_VALID_MINUTES): array
{
    $project = otpProjectName();
    $tz = new DateTimeZone(defined('APP_TIMEZONE') ? (string) APP_TIMEZONE : 'Asia/Kolkata');
    $now = new DateTime('now', $tz);
    $until = (clone $now)->modify("+{$minutes} minutes");
    $at = $now->format('j M Y, g:i A');
    $till = $until->format('g:i A');
    $login = defined('APP_URL') ? rtrim((string) APP_URL, '/') . '/login.php' : '';
    $host = $login !== '' ? (string) parse_url($login, PHP_URL_HOST) : '';
    $logo = otpLogoUrl();

    $orange = '#e84e24';
    $ink = '#1c1917';
    $dim = '#78716c';

    // each digit in its own cell: easy to read, and copy-paste still gives "123456"
    $digits = '';
    foreach (str_split($otp) as $i => $d) {
        $digits .= '<td align="center" style="padding:0 3px;">'
            . '<div style="width:46px;height:58px;line-height:58px;background:#fff7f4;border:1px solid #fbd3c4;border-radius:10px;'
            . 'font-family:\'SFMono-Regular\',Menlo,Consolas,monospace;font-size:30px;font-weight:700;color:' . $ink . ';text-align:center;">'
            . otpH($d) . '</div></td>';
    }

    $row = fn(string $k, string $v) => '<tr><td style="padding:7px 0;color:' . $dim . ';font-size:13px;width:110px;">' . $k . '</td>'
        . '<td style="padding:7px 0;color:' . $ink . ';font-size:13px;font-weight:600;">' . $v . '</td></tr>';

    $html = '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
        . '<meta name="color-scheme" content="light"><title>' . otpH($project) . ' login code</title></head>'
        . '<body style="margin:0;padding:0;background:#f5f5f4;">'
        // inbox preview line (no code in it)
        . '<div style="display:none;max-height:0;overflow:hidden;opacity:0;">Use this code to sign in to the ' . otpH($project) . ' admin. It expires in ' . $minutes . ' minutes.</div>'
        . '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#f5f5f4;padding:32px 12px;"><tr><td align="center">'
        . '<table role="presentation" width="480" cellpadding="0" cellspacing="0" style="width:100%;max-width:480px;background:#ffffff;border-radius:16px;overflow:hidden;border:1px solid #e7e5e4;font-family:Arial,Helvetica,sans-serif;">'
        . '<tr><td style="height:6px;background:' . $orange . ';font-size:0;line-height:0;">&nbsp;</td></tr>'
        // header: logo + project
        . '<tr><td style="padding:22px 28px 0;"><table role="presentation" width="100%" cellpadding="0" cellspacing="0"><tr>'
        . '<td valign="middle">' . ($logo !== '' ? '<img src="' . otpH($logo) . '" width="66" height="48" alt="Webzaa" style="display:block;border:0;width:66px;height:48px;">'
            : '<span style="font-size:20px;font-weight:700;color:#6a6968;">Web<span style="color:' . $orange . ';">zaa</span></span>') . '</td>'
        . '<td valign="middle" align="right"><span style="display:inline-block;background:' . $ink . ';color:#ffffff;font-size:12px;font-weight:700;padding:6px 12px;border-radius:999px;">' . otpH($project) . '</span></td>'
        . '</tr></table></td></tr>'
        // title
        . '<tr><td style="padding:26px 28px 6px;">'
        . '<div style="color:' . $orange . ';font-size:11px;font-weight:700;letter-spacing:2px;text-transform:uppercase;">Admin login</div>'
        . '<div style="color:' . $ink . ';font-size:24px;font-weight:700;margin-top:6px;line-height:1.25;">Your login code</div>'
        . '<div style="color:' . $dim . ';font-size:14px;line-height:1.55;margin-top:8px;">Enter this code on the login page to open the <b style="color:' . $ink . ';">' . otpH($project) . '</b> dashboard.</div>'
        . '</td></tr>'
        // code
        . '<tr><td align="center" style="padding:18px 28px 6px;"><table role="presentation" cellpadding="0" cellspacing="0"><tr>' . $digits . '</tr></table></td></tr>'
        . '<tr><td align="center" style="padding:10px 28px 4px;">'
        . '<span style="display:inline-block;background:#f5f5f4;color:' . $ink . ';font-size:12.5px;padding:7px 12px;border-radius:999px;">&#9201; Valid for ' . $minutes . ' minutes · until ' . otpH($till) . '</span>'
        . '</td></tr>'
        // details
        . '<tr><td style="padding:22px 28px 4px;"><table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="border-top:1px solid #f0efee;border-bottom:1px solid #f0efee;">'
        . $row('Project', otpH($project))
        . $row('Account', otpH($email))
        . $row('Requested', otpH($at) . ' IST')
        . ($host !== '' ? $row('Login page', '<a href="' . otpH($login) . '" style="color:' . $orange . ';text-decoration:none;">' . otpH($host) . '</a>') : '')
        . '</table></td></tr>'
        // security note
        . '<tr><td style="padding:18px 28px 26px;">'
        . '<div style="background:#fafaf9;border-radius:10px;padding:12px 14px;color:' . $dim . ';font-size:12.5px;line-height:1.55;">'
        . '<b style="color:' . $ink . ';">Didn\'t ask for this?</b> You can ignore this email — nobody can log in without the code. Never share it; Webzaa will never ask you for it.'
        . '</div></td></tr>'
        . '<tr><td style="padding:14px 28px;background:#fafaf9;border-top:1px solid #f0efee;color:#a8a29e;font-size:11px;">'
        . 'Sent by <span style="color:' . $orange . ';font-weight:700;">Webzaa</span> Admin for ' . otpH($project) . ' · automated email, please don\'t reply'
        . '</td></tr>'
        . '</table></td></tr></table></body></html>';

    $text = "Your login code for {$project}: {$otp}\n\nValid for {$minutes} minutes (until {$till} IST).\nAccount: {$email}\n"
        . ($login !== '' ? "Login page: {$login}\n" : '')
        . "\nDidn't ask for this? Ignore this email. Never share the code.";

    $subject = "Your login code · {$project} · Webzaa Admin";
    return [$subject, $html, $text];
}

/** Sends the code. SMTP first (unless OTP_MAIL_VIA = 'api'), then the old mailer API as a fallback. */
function sendLoginOtpMail(string $email, string $otp): bool
{
    $via = defined('OTP_MAIL_VIA') ? strtolower((string) OTP_MAIL_VIA) : 'smtp';
    if ($via !== 'api') {
        try {
            require_once dirname(__DIR__) . '/Reports/report_mailer.php';
            [$subject, $html, $text] = otpEmailHtml($otp, $email);
            $mail = reportGetMailer();
            $mail->Timeout = 20;
            $mail->isHTML(true);
            $mail->CharSet = 'UTF-8';
            $mail->FromName = otpProjectName() . ' · Webzaa Admin';
            $mail->addAddress($email);
            $mail->Subject = $subject;
            $mail->Body = $html;
            $mail->AltBody = $text;
            $mail->send();
            return true;
        } catch (Throwable $e) {
            error_log('[otp_mail] SMTP failed, trying the mailer API: ' . $e->getMessage());
        }
    }
    return otpSendViaApi($email, $otp);
}

/** The old way: external mailer API (uses its own template). */
function otpSendViaApi(string $email, string $otp): bool
{
    $url = defined('OTP_MAIL_API_URL') && OTP_MAIL_API_URL ? (string) OTP_MAIL_API_URL : OTP_MAIL_DEFAULT_API;
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => $url,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => http_build_query(['email' => $email, 'otp' => $otp, 'project_name' => otpProjectName()]),
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 10,
    ]);
    $response = curl_exec($ch);
    curl_close($ch);
    return trim((string) $response) === 'sent';
}
