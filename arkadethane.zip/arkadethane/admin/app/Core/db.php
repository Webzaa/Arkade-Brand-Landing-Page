<?php

declare(strict_types=1);

require_once dirname(__DIR__) . '/bootstrap.php';


/*
|--------------------------------------------------------------------------
| DATABASE CONNECTION FUNCTION
|--------------------------------------------------------------------------
*/

function createDatabaseConnection(
    string $host,
    string $username,
    string $password,
    string $database,
    int $port = 3306,
    bool $fatal = true
): ?mysqli {

    mysqli_report(MYSQLI_REPORT_OFF);

    $connection = mysqli_init();

    if ($connection === false) {
        error_log('Unable to initialize MySQLi.');
        die('Database connection initialization failed.');
    }

    /*
    |--------------------------------------------------------------------------
    | Connection timeout
    |--------------------------------------------------------------------------
    |
    | Particularly important for DB2 because it is a remote server.
    |
    */

    mysqli_options(
        $connection,
        MYSQLI_OPT_CONNECT_TIMEOUT,
        10
    );

    /*
    |--------------------------------------------------------------------------
    | Connect
    |--------------------------------------------------------------------------
    */

    if (
        !$connection->real_connect(
            $host,
            $username,
            $password,
            $database,
            $port
        )
    ) {

        error_log(
            sprintf(
                'Database connection failed: %s:%d / database=%s / error=%s',
                $host,
                $port,
                $database,
                $connection->connect_error
            )
        );

        if ($fatal) {
            die('Database connection failed.');
        }
        return null;
    }

    /*
    |--------------------------------------------------------------------------
    | Character Set
    |--------------------------------------------------------------------------
    */

    if (!$connection->set_charset('utf8mb4')) {

        error_log(
            sprintf(
                'Unable to set utf8mb4 for database %s: %s',
                $database,
                $connection->error
            )
        );
    }

    return $connection;
}



/*
|--------------------------------------------------------------------------
| DATABASES — one list, any number (config/config.php → LEAD_DATABASES)
|--------------------------------------------------------------------------
|
|   APP_DB          key of the database that holds users / sessions / logs.
|                   Its connection is $conn (required — the page stops if it is down).
|   LEAD_DATABASES  every database that has a `lead` table: 1, 2, 5 … all the same.
|
| Old configs with only DB1_* / DB2_* still work: they become
|   'pseudo'   => DB1 (Pseudo Campaign)
|   'official' => DB2 (Official Campaign)
|
| Helpers (use these instead of $conn2):
|   leadDbKeys()            ['pseudo', 'official', …]
|   leadDbLabels()          ['pseudo' => 'Pseudo Campaign', …]
|   leadDbLabel($key)       'Pseudo Campaign'
|   leadDbNames()           ['pseudo' => 'test_beliciacp', …]   (real MySQL database names)
|   leadDb($key)            mysqli, or null if that database is unreachable
|   leadDbs('all'|$key)     [key => mysqli] for every reachable selected database
|   isLeadDbChoice($v)      true for 'all' or a configured key
|   leadDbFailures()        [key => error] for databases that could not be reached
|   reportLeadDb()          the single database used by the portfolio PDF report
|--------------------------------------------------------------------------
*/

function leadDatabaseConfig(): array
{
    static $cfg = null;
    if ($cfg !== null) {
        return $cfg;
    }

    $cfg = [];
    if (defined('LEAD_DATABASES') && is_array(LEAD_DATABASES) && LEAD_DATABASES) {
        foreach (LEAD_DATABASES as $key => $db) {
            $key = strtolower(trim((string) $key));
            if ($key === '' || $key === 'all' || !preg_match('/^[a-z0-9_]+$/', $key) || !is_array($db)) {
                error_log("LEAD_DATABASES: skipped invalid entry '{$key}' (keys: a-z, 0-9, _ ; 'all' is reserved).");
                continue;
            }
            $cfg[$key] = [
                'label' => (string) ($db['label'] ?? ucfirst($key)),
                'host'  => (string) ($db['host'] ?? '127.0.0.1'),
                'port'  => (int) ($db['port'] ?? 3306),
                'user'  => (string) ($db['user'] ?? ''),
                'pass'  => (string) ($db['pass'] ?? ''),
                'name'  => (string) ($db['name'] ?? ''),
            ];
        }
    } else {
        // Backward compatible: the old two-database constants
        if (defined('DB1_NAME')) {
            $cfg['pseudo'] = [
                'label' => 'Pseudo Campaign', 'host' => (string) DB1_HOST, 'port' => (int) DB1_PORT,
                'user' => (string) DB1_USER, 'pass' => (string) DB1_PASS, 'name' => (string) DB1_NAME,
            ];
        }
        if (defined('DB2_NAME') && (string) DB2_NAME !== '') {
            $cfg['official'] = [
                'label' => 'Official Campaign', 'host' => (string) DB2_HOST, 'port' => (int) DB2_PORT,
                'user' => (string) DB2_USER, 'pass' => (string) DB2_PASS, 'name' => (string) DB2_NAME,
            ];
        }
    }

    if (!$cfg) {
        error_log('No databases configured: set LEAD_DATABASES (or DB1_*) in config/config.php.');
        die('No database configured.');
    }
    return $cfg;
}

function appDbKey(): string
{
    $cfg = leadDatabaseConfig();
    if (defined('APP_DB') && isset($cfg[(string) APP_DB])) {
        return (string) APP_DB;
    }
    return (string) array_key_first($cfg);
}

/** Connection cache + failures; connects lazily, at most once per request. */
function &leadDbRegistry(): array
{
    static $registry = ['conn' => [], 'failed' => []];
    return $registry;
}

function leadDb(string $key): ?mysqli
{
    $cfg = leadDatabaseConfig();
    if (!isset($cfg[$key])) {
        return null;
    }
    $reg = &leadDbRegistry();
    if (array_key_exists($key, $reg['conn'])) {
        return $reg['conn'][$key];
    }
    $c = $cfg[$key];
    $db = createDatabaseConnection($c['host'], $c['user'], $c['pass'], $c['name'], $c['port'], $key === appDbKey());
    if ($db instanceof mysqli) {
        $db->query("SET time_zone = '+05:30'");
    } else {
        $reg['failed'][$key] = 'Could not connect to ' . $c['label'];
    }
    $reg['conn'][$key] = $db;
    return $db;
}

function leadDbKeys(): array
{
    return array_keys(leadDatabaseConfig());
}

function leadDbLabels(): array
{
    return array_map(fn($c) => $c['label'], leadDatabaseConfig());
}

function leadDbLabel(string $key): string
{
    return leadDatabaseConfig()[$key]['label'] ?? ucfirst($key);
}

function leadDbNames(): array
{
    return array_map(fn($c) => $c['name'], leadDatabaseConfig());
}

function isLeadDbChoice(string $value): bool
{
    return $value === 'all' || isset(leadDatabaseConfig()[$value]);
}

/** @return array<string, mysqli> reachable databases for 'all' or one key */
function leadDbs(string $which = 'all'): array
{
    $keys = $which === 'all' ? leadDbKeys() : (isset(leadDatabaseConfig()[$which]) ? [$which] : []);
    $out = [];
    foreach ($keys as $key) {
        $db = leadDb($key);
        if ($db instanceof mysqli && !$db->connect_errno) {
            $out[$key] = $db;
        }
    }
    return $out;
}

function leadDbFailures(): array
{
    return leadDbRegistry()['failed'];
}

/** Single database for the portfolio PDF report: PORTFOLIO_REPORT_DB, else the 2nd database (as before), else the first. */
function reportLeadDb(): ?mysqli
{
    $keys = leadDbKeys();
    $order = [];
    if (defined('PORTFOLIO_REPORT_DB')) {
        $order[] = (string) PORTFOLIO_REPORT_DB;
    }
    if (isset($keys[1])) {
        $order[] = $keys[1];
    }
    $order[] = $keys[0];
    foreach (array_unique($order) as $key) {
        $db = leadDb($key);
        if ($db instanceof mysqli && !$db->connect_errno) {
            return $db;
        }
    }
    return null;
}

/** Master tables (campaigns / adgroups / ads) database key: MASTER_TABLES_DB, else the first database. */
function masterTablesDbKey(): string
{
    if (defined('MASTER_TABLES_DB') && isset(leadDatabaseConfig()[(string) MASTER_TABLES_DB])) {
        return (string) MASTER_TABLES_DB;
    }
    return leadDbKeys()[0];
}

/*
|--------------------------------------------------------------------------
| $conn  = app database (users, sessions, activity logs) — always connected
| $conn2 = 2nd lead database, kept ONLY for older code; new code uses leadDbs()
|--------------------------------------------------------------------------
*/
$conn = leadDb(appDbKey());
$conn2 = null;
foreach (leadDbKeys() as $k) {
    if ($k !== appDbKey()) {
        $conn2 = leadDb($k);
        break;
    }
}

/*
|--------------------------------------------------------------------------
| Roles & permissions: every web request is checked here (app/Core/access.php)
|--------------------------------------------------------------------------
*/
require_once APP_PATH . '/Core/access.php';
pqAccessGuard($conn instanceof mysqli ? $conn : null);



/*
|--------------------------------------------------------------------------
| MASKING LOGIC
|--------------------------------------------------------------------------
*/

function renderMaskedData($data, $type = 'email')
{
    /*
    |--------------------------------------------------------------------------
    | Email - Unmasked
    |--------------------------------------------------------------------------
    */

    if (
        $type === 'email' &&
        isset($_SESSION['unmask_email']) &&
        $_SESSION['unmask_email'] === 'Y'
    ) {
        return htmlspecialchars(
            (string) $data,
            ENT_QUOTES,
            'UTF-8'
        );
    }


    /*
    |--------------------------------------------------------------------------
    | Mobile - Unmasked
    |--------------------------------------------------------------------------
    */

    if (
        $type === 'mobile' &&
        isset($_SESSION['unmask_mobile']) &&
        $_SESSION['unmask_mobile'] === 'Y'
    ) {
        return htmlspecialchars(
            (string) $data,
            ENT_QUOTES,
            'UTF-8'
        );
    }


    /*
    |--------------------------------------------------------------------------
    | Empty value
    |--------------------------------------------------------------------------
    */

    if (empty($data)) {
        return '';
    }


    /*
    |--------------------------------------------------------------------------
    | Email Masking
    |--------------------------------------------------------------------------
    */

    if ($type === 'email') {

        $parts = explode('@', (string) $data);

        if (count($parts) < 2) {
            return '*****';
        }

        return htmlspecialchars(
            substr($parts[0], 0, 2)
            . str_repeat('*', 6)
            . '@'
            . $parts[1],
            ENT_QUOTES,
            'UTF-8'
        );
    }


    /*
    |--------------------------------------------------------------------------
    | Mobile Masking
    |--------------------------------------------------------------------------
    */

    if ($type === 'mobile') {

        return htmlspecialchars(pqMaskMobile((string) $data), ENT_QUOTES, 'UTF-8');
    }


    return '*****';
}


/*
|--------------------------------------------------------------------------
| LEAD CONTACT RULES (Users & Roles → per user, four switches)
|   unmask_email / unmask_mobile  = full email / mobile ON SCREEN
|   export_email / export_mobile  = full email / mobile IN EXPORTS (Excel / CSV)
| Everything else gets the masked value: ab******@gmail.com, *****43210 (only the last 5 digits of a mobile).
|--------------------------------------------------------------------------
*/

function pqContactAllowed(string $type, string $where = 'screen'): bool
{
    $key = ($where === 'export' ? 'export_' : 'unmask_') . ($type === 'email' ? 'email' : 'mobile');
    return ($_SESSION[$key] ?? 'N') === 'Y';
}

function pqMaskEmail(string $e): string
{
    $e = trim($e);
    if ($e === '') {
        return '';
    }
    $p = explode('@', $e, 2);
    return count($p) < 2 ? '*****' : substr($p[0], 0, 2) . str_repeat('*', 6) . '@' . $p[1];
}

/** Mobile → stars + the last 5 digits: 9876543210 → *****43210, +91 98765 43210 → *******43210. 5 digits or fewer: all stars. */
function pqMaskMobile(string $m): string
{
    $m = trim($m);
    if ($m === '' || str_contains($m, '*')) {
        return $m;   // empty, or masked already
    }
    $d = preg_replace('/\D+/', '', $m);
    if (strlen($d) <= 5) {
        return str_repeat('*', max(5, strlen($d)));
    }
    return str_repeat('*', strlen($d) - 5) . substr($d, -5);
}

/** Plain text (not HTML-escaped): the value, or the masked value when this user may not see it there. */
function pqContact($value, string $type, string $where = 'screen'): string
{
    $v = (string) ($value ?? '');
    if ($v === '' || pqContactAllowed($type, $where)) {
        return $v;
    }
    return $type === 'email' ? pqMaskEmail($v) : pqMaskMobile($v);
}

/**
 * Masks the contact fields of list rows sent to the browser: `mobile` / `email` follow the on-screen rule,
 * `mobile_export` / `email_export` the export rule (the page's Excel / CSV uses those).
 * `mkey` = a fixed key per mobile number (last 10 digits, keyed hash) so pages can count unique people
 * without seeing the number — two masked mobiles can share the same last 5 digits.
 */
function pqContactRows(array $rows): array
{
    foreach ($rows as &$r) {
        if (is_array($r) && array_key_exists('mobile', $r)) {
            $d = substr(preg_replace('/\D+/', '', (string) ($r['mobile'] ?? '')), -10);
            $r['mkey'] = $d === '' ? '' : substr(hash_hmac('sha256', $d, pqRefKey()), 0, 16);
        }
        foreach (['mobile', 'email'] as $f) {
            if (is_array($r) && array_key_exists($f, $r)) {
                $raw = (string) ($r[$f] ?? '');
                $r[$f . '_export'] = pqContact($raw, $f, 'export');
                $r[$f] = pqContact($raw, $f, 'screen');
            }
        }
    }
    unset($r);
    return $rows;
}

/** The four switches for the page's JavaScript (window.PQ_CONTACT). */
function pqContactJs(): string
{
    return '<script>window.PQ_CONTACT = ' . json_encode([
        'screen' => ['email' => pqContactAllowed('email'), 'mobile' => pqContactAllowed('mobile')],
        'export' => ['email' => pqContactAllowed('email', 'export'), 'mobile' => pqContactAllowed('mobile', 'export')],
    ]) . ';</script>';
}

/*
| Lead reference: the Leads list, follow-ups and the Edit page used the mobile number as the row key in the
| browser, so the full number reached users who may only see it masked. They now get an encrypted reference
| ("ref.…") instead; the endpoints that take a lead turn it back into the mobile with pqLeadMobile().
| A plain mobile is still accepted (older pages, bookmarks).
*/
function pqRefKey(): string
{
    if (defined('PQ_APP_KEY') && (string) PQ_APP_KEY !== '') {
        return hash('sha256', 'pq-lead-ref|' . PQ_APP_KEY, true);
    }
    if (defined('REPORT_LINK_SECRET') && (string) REPORT_LINK_SECRET !== '') {
        return hash('sha256', 'pq-lead-ref|' . REPORT_LINK_SECRET, true);
    }
    $cfg = leadDatabaseConfig()[appDbKey()] ?? [];
    return hash('sha256', 'pq-lead-ref|' . ($cfg['pass'] ?? '') . '|' . ($cfg['name'] ?? '') . '|' . BASE_PATH, true);
}

function pqLeadRef($mobile): string
{
    $m = trim((string) ($mobile ?? ''));
    if ($m === '') {
        return '';
    }
    $iv = random_bytes(12);
    $tag = '';
    $ct = openssl_encrypt($m, 'aes-256-gcm', pqRefKey(), OPENSSL_RAW_DATA, $iv, $tag);
    return $ct === false ? '' : 'ref.' . rtrim(strtr(base64_encode($iv . $tag . $ct), '+/', '-_'), '=');
}

/** The mobile behind a lead reference; a plain mobile is returned trimmed; '' when the reference is invalid. */
function pqLeadMobile($value): string
{
    $v = trim((string) ($value ?? ''));
    if (!str_starts_with($v, 'ref.')) {
        return $v;
    }
    $raw = base64_decode(strtr(substr($v, 4), '-_', '+/'), true);
    if ($raw === false || strlen($raw) < 29) {
        return '';
    }
    $out = openssl_decrypt(substr($raw, 28), 'aes-256-gcm', pqRefKey(), OPENSSL_RAW_DATA, substr($raw, 0, 12), substr($raw, 12, 16));
    return $out === false ? '' : $out;
}

/**
 * Rows for the browser: adds `ref`, masks `mobile` / `email` on the server (on-screen rule) and adds
 * `mobile_export` / `email_export` (export rule). Same as pqContactRows() plus the reference.
 */
function pqLeadRowsForBrowser(array $rows): array
{
    foreach ($rows as &$r) {
        if (is_array($r) && array_key_exists('mobile', $r)) {
            $r['ref'] = pqLeadRef($r['mobile']);
        }
    }
    unset($r);
    return pqContactRows($rows);
}

/** users.export_email / export_mobile (added with this update; first filled from the on-screen switches). */
function pqEnsureContactColumns(mysqli $db): bool
{
    try {
        $c = $db->query("SHOW COLUMNS FROM `users` LIKE 'export_email'");
        if ($c && $c->num_rows > 0) {
            return true;
        }
        $ok = $db->query("ALTER TABLE `users` ADD COLUMN `export_email` ENUM('Y','N') NOT NULL DEFAULT 'N', ADD COLUMN `export_mobile` ENUM('Y','N') NOT NULL DEFAULT 'N'");
        if ($ok) {
            $db->query("UPDATE `users` SET export_email = unmask_email, export_mobile = unmask_mobile");
        }
        return (bool) $ok;
    } catch (Throwable $e) {
        error_log('[db] export columns: ' . $e->getMessage());
        return false;
    }
}


/*
|--------------------------------------------------------------------------
| TEAM ACTIVITY LOG
|--------------------------------------------------------------------------
*/

function logTeamActivity(
    $conn,
    $uid,
    $project_name,
    $action_type,
    $details_array = []
) {

    /*
    |--------------------------------------------------------------------------
    | Convert details to JSON
    |--------------------------------------------------------------------------
    */

    $details_json = empty($details_array)
        ? null
        : json_encode(
            $details_array,
            JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
        );


    /*
    |--------------------------------------------------------------------------
    | Client IP
    |--------------------------------------------------------------------------
    */

    $ip = $_SERVER['REMOTE_ADDR'] ?? null;


    /*
    |--------------------------------------------------------------------------
    | Prepare statement
    |--------------------------------------------------------------------------
    */

    $stmt = $conn->prepare("
        INSERT INTO team_activity_logs
        (
            uid,
            project_name,
            action_type,
            action_details,
            ip_address
        )
        VALUES (?, ?, ?, ?, ?)
    ");


    /*
    |--------------------------------------------------------------------------
    | Execute
    |--------------------------------------------------------------------------
    */

    if ($stmt) {

        $stmt->bind_param(
            "issss",
            $uid,
            $project_name,
            $action_type,
            $details_json,
            $ip
        );

        if (!$stmt->execute()) {

            error_log(
                "Activity log insert failed for project {$project_name}: "
                . $stmt->error
            );
        }

        $stmt->close();

    } else {

        error_log(
            "Activity log prepare failed for project {$project_name}: "
            . $conn->error
        );
    }
}