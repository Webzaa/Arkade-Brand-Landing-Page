<?php
/**
 * access.php — roles & permissions.
 *
 * - Super Admin always has full access (and is the only one who sees Users & Roles, Logs).
 * - Every other role has a set of permissions per module, edited in Users → Roles & permissions.
 *   Stored in table `pq_roles` (role_key, name, description, permissions JSON, is_system).
 * - pqAccessGuard() runs at the end of app/Core/db.php on every web request: it maps the script
 *   being called to a module (PQ_ROUTES), checks login, re-reads the user (blocked / deleted → logged out,
 *   role changes apply at once) and answers 403 when the role may not use that page / API.
 *
 *   pqCan('leads', 'export')   → bool, for the current user
 *   pqAllowedViews()           → dashboard sidebar sections the user may open
 */

/** Modules and their actions. 'view' = can open it; the others are extra rights inside it. */
const PQ_MODULES = [
    'overview'  => ['label' => 'All Platforms',          'group' => 'Overview',     'desc' => 'Combined Meta + Google numbers',               'actions' => ['view' => 'View']],
    'reports'   => ['label' => 'Reports',                'group' => 'Overview',     'desc' => 'Campaign report and daily / weekly / monthly PDFs — all or selected campaigns', 'actions' => ['view' => 'Download']],
    'targets'   => ['label' => 'Targets',                'group' => 'Overview',     'desc' => 'Plan vs achieved — the Target vs Achieved card on the dashboards', 'actions' => ['view' => 'View', 'edit' => 'Edit targets']],
    'meta'      => ['label' => 'Meta Ads',               'group' => 'Ad platforms', 'desc' => 'Meta dashboard',                               'actions' => ['view' => 'View', 'sync' => 'Sync campaigns & tag awareness']],
    'google'    => ['label' => 'Google Ads',             'group' => 'Ad platforms', 'desc' => 'Google dashboard',                             'actions' => ['view' => 'View', 'sync' => 'Sync campaigns & tag awareness']],
    'taboola'   => ['label' => 'Taboola',                'group' => 'Ad platforms', 'desc' => 'Taboola dashboard (when Taboola is switched on)', 'actions' => ['view' => 'View']],
    'manual'    => ['label' => 'Manual platforms',       'group' => 'Ad platforms', 'desc' => 'OTT Video, Display, MyGate…',                   'actions' => ['view' => 'View', 'edit' => 'Add / edit numbers & platforms', 'awareness' => 'Set awareness spend']],
    'creatives' => ['label' => 'Creatives & Insights',   'group' => 'Insights',     'desc' => 'Every Meta / Google ad with its image or video, results and what to do next', 'actions' => ['view' => 'View', 'rules' => 'Edit insight rules']],
    'keywords'  => ['label' => 'Keyword Analysis',       'group' => 'Insights',     'desc' => 'Google keywords and search terms with CRM leads, and what to do next', 'actions' => ['view' => 'View', 'export' => 'Export CSV']],
    'leads'     => ['label' => 'Leads & CRM',            'group' => 'CRM',          'desc' => 'Lead list, follow-ups',                        'actions' => ['view' => 'View', 'export' => 'Export to Excel', 'edit' => 'Add leads & follow-ups']],
    'unmapped'  => ['label' => 'Unmapped Leads',         'group' => 'CRM',          'desc' => 'Leads not under a project campaign',          'actions' => ['view' => 'View', 'edit' => 'Map leads / change status']],
    'crm'       => ['label' => 'CRM Push',               'group' => 'CRM',          'desc' => 'Leads sent to / failed in the CRM',            'actions' => ['view' => 'View', 'send' => 'Send leads to the CRM']],
    'status'    => ['label' => 'Upload Lead Status',     'group' => 'CRM',          'desc' => 'Update status / site visits from a CRM export; add the leads that are not in the database', 'actions' => ['view' => 'Upload & undo', 'insert' => 'Add missing leads (not found in the file)']],
    'lphygiene' => ['label' => 'LP Hygiene',             'group' => 'Tools',        'desc' => 'Landing page speed (PageSpeed), tracking & form checks, Meta / landing page test leads, PDF report', 'actions' => ['view' => 'View', 'run' => 'Run PageSpeed & page checks', 'edit' => 'Add / edit / delete pages & form settings', 'meta_test' => 'Send Meta test leads (Graph API)', 'lp_test' => 'Send landing page test leads', 'pdf' => 'Download PDF report']],
    'analytics' => ['label' => 'Web Analytics',          'group' => 'Tools',        'desc' => 'Visitors, sessions, heatmaps',                 'actions' => ['view' => 'View']],
    'capi'      => ['label' => 'Meta CAPI',              'group' => 'Tools',        'desc' => 'Send offline conversions to Meta',            'actions' => ['view' => 'Use']],
    'import'    => ['label' => 'Import Leads',           'group' => 'Tools',        'desc' => 'Bulk-upload leads from CSV',                  'actions' => ['view' => 'Import']],
];

/** Numbers a role can be kept from seeing (Roles → "Hide numbers"); stored as permissions.hide_metrics. */
const PQ_METRICS = [
    'qualified'  => ['label' => 'Qualified leads', 'desc' => 'Qualified count, qualified %, funnel stage'],
    'cpql'       => ['label' => 'CPQL', 'desc' => 'Cost per qualified lead'],
    'sitevisits' => ['label' => 'Site visits', 'desc' => 'Site visits / walk-ins, funnel stage, walk-in chart'],
    'cpsv'       => ['label' => 'CPSV', 'desc' => 'Cost per site visit'],
];

/**
 * Campaign types a role can see (Roles → "Campaign types"); stored as permissions.hide_types (the hidden ones),
 * so roles saved before this existed see both. A role always keeps at least one.
 *   performance  performance campaigns (default for every campaign)
 *   awareness    campaigns tagged Awareness in ⟳ Sync, and the awareness share of manual platforms (✎ Awareness)
 */
const PQ_CAMPAIGN_TYPES = [
    'performance' => ['label' => 'Show performance', 'desc' => 'Performance campaigns: Performance tab, and their spend, leads and results everywhere'],
    'awareness'   => ['label' => 'Show awareness', 'desc' => 'Awareness campaigns and awareness platforms: Awareness tab, menu items, spend and results'],
];

/** Dashboard sidebar section → module. */
const PQ_VIEW_MODULE = [
    'overview' => 'overview', 'targets' => 'targets', 'meta' => 'meta', 'google' => 'google', 'taboola' => 'taboola',
    'creatives' => 'creatives', 'keywords' => 'keywords', 'lphygiene' => 'lphygiene',
    'leads' => 'leads', 'unmapped' => 'unmapped', 'crm' => 'crm', 'status' => 'status',
    'analytics' => 'analytics', 'capi' => 'capi', 'import' => 'import', 'm-new' => 'manual', // m-<key> → manual
];

/**
 * Script (relative to public/) → rule. Scripts not listed are left alone (login, OTP, Google callback,
 * signed report links, webhooks, cron-called report builders).
 *   'modules' any of these with 'view'; 'write' = action needed for a write request (see pqRouteAction)
 *   'kind'    page (shows a "no access" page) | api (403 JSON)
 *   'super'   Super Admin only
 */
const PQ_ROUTES = [
    'dashboard.php'                 => ['login' => true, 'kind' => 'page'],
    'about.php'                     => ['login' => true, 'kind' => 'page'],   // About PerformIQ: every signed-in user
    'ads/metadashboard.php'         => ['modules' => ['meta'], 'kind' => 'page'],
    'ads/dashboard.php'             => ['modules' => ['meta'], 'kind' => 'page'],
    'ads/googledashboard.php'       => ['modules' => ['google'], 'kind' => 'page'],
    'ads/ottdashboard.php'          => ['modules' => ['manual'], 'kind' => 'page'],
    'ads/tabooladashboard.php'      => ['modules' => ['taboola'], 'kind' => 'page'],
    'ads/unmapped.php'              => ['modules' => ['unmapped'], 'kind' => 'page'],
    'ads/unmapped_meta.php'         => ['modules' => ['unmapped'], 'kind' => 'page'],
    'index.php'                     => ['modules' => ['leads'], 'kind' => 'page'],
    'leads/add-lead.php'            => ['modules' => ['leads'], 'need' => 'edit', 'kind' => 'page'],
    'unmapped_leads.php'            => ['modules' => ['unmapped'], 'kind' => 'page'],
    'crm_push.php'                  => ['modules' => ['crm'], 'kind' => 'page'],
    'targets.php'                   => ['modules' => ['targets'], 'kind' => 'page'],
    'status_upload.php'             => ['modules' => ['status'], 'kind' => 'page'],
    'analytics.php'                 => ['modules' => ['analytics'], 'kind' => 'page'],
    'meta_capi.php'                 => ['modules' => ['capi'], 'kind' => 'page'],
    'import.php'                    => ['modules' => ['import'], 'kind' => 'page'],
    'leads/users.php'               => ['super' => true, 'kind' => 'page'],
    'crm_settings.php'              => ['super' => true, 'kind' => 'page'],
    'logs.php'                      => ['super' => true, 'kind' => 'page'],

    'ads/api.php'                   => ['modules' => ['meta', 'overview', 'reports'], 'kind' => 'api'],
    'ads/googleapi.php'             => ['modules' => ['google', 'overview', 'reports'], 'kind' => 'api'],
    // Meta dashboard → upload CRM statuses (was open to anyone with the URL): signed-in users who may open the Meta dashboard
    'ads/meta_update_leads.php'     => ['modules' => ['meta'], 'kind' => 'api'],
    'ads/taboolaapi.php'            => ['modules' => ['taboola', 'overview', 'reports'], 'kind' => 'api'],   // All Platforms adds Taboola in
    'ads/taboola_insights_api.php'  => ['modules' => ['taboola'], 'kind' => 'api'],
    'ads/ai_insights_api.php'       => ['modules' => ['meta', 'google'], 'kind' => 'api'],
    'ads/column_prefs_api.php'      => ['modules' => ['meta', 'google'], 'kind' => 'api'],
    'ads/people_counts_api.php'     => ['modules' => ['overview', 'meta', 'google', 'reports'], 'kind' => 'api'],
    'ads/portfolio_report_api.php'  => ['modules' => ['reports'], 'kind' => 'api'],
    'ads/email_report_api.php'      => ['modules' => ['reports'], 'kind' => 'api'],
    'ads/project_sync_api.php'      => ['modules' => ['meta', 'google'], 'write' => 'sync', 'platform' => true, 'readonly_actions' => ['list', 'from_leads'], 'kind' => 'api'],
    'ads/meta_sync_api.php'         => ['modules' => ['meta'], 'write' => 'sync', 'platform' => true, 'readonly_actions' => ['list', 'from_leads'], 'kind' => 'api'],
    'ads/ott_api.php'               => ['modules' => ['manual', 'overview', 'reports'], 'write' => 'edit', 'write_module' => 'manual', 'write_actions' => ['awareness' => 'awareness'], 'kind' => 'api'],
    'ads/report_campaigns_api.php'  => ['modules' => ['reports'], 'kind' => 'api'],
    'ads/unmapped_api.php'          => ['modules' => ['unmapped'], 'write' => 'edit', 'write_module' => 'unmapped', 'kind' => 'api'],
    'ads/unmapped_meta_api.php'     => ['modules' => ['unmapped'], 'write' => 'edit', 'write_module' => 'unmapped', 'kind' => 'api'],
    'unmapped_leads_api.php'        => ['modules' => ['unmapped'], 'write' => 'edit', 'write_module' => 'unmapped', 'kind' => 'api'],
    'crm_push_api.php'              => ['modules' => ['crm'], 'write' => 'send', 'kind' => 'api'],
    'targets_api.php'               => ['modules' => ['targets'], 'write' => 'edit', 'kind' => 'api'],
    // Creatives & Insights, Keyword Analysis: their own modules (Users & Roles)
    'creatives.php'                 => ['modules' => ['creatives'], 'kind' => 'page'],
    'creatives_api.php'             => ['modules' => ['creatives'], 'kind' => 'api'],
    'keywords.php'                  => ['modules' => ['keywords'], 'kind' => 'page'],
    'keywords_api.php'              => ['modules' => ['keywords'], 'kind' => 'api'],
    'lp_hygiene.php'                => ['modules' => ['lphygiene'], 'kind' => 'page'],
    'lp_hygiene_api.php'            => ['modules' => ['lphygiene'], 'write' => 'run', 'write_module' => 'lphygiene', 'write_actions' => ['save_page' => 'edit', 'delete_page' => 'edit', 'meta_test' => 'meta_test', 'lp_test' => 'lp_test'], 'kind' => 'api'],
    'status_upload_api.php'         => ['modules' => ['status'], 'write_module' => 'status', 'write_actions' => ['missing_insert' => 'insert', 'missing_undo' => 'insert'], 'kind' => 'api'],
    'leads/get_records.php'         => ['modules' => ['leads'], 'kind' => 'api'],
    'leads/get_data.php'            => ['modules' => ['leads', 'overview'], 'kind' => 'api'],
    'leads/get_followups.php'       => ['modules' => ['leads'], 'kind' => 'api'],
    'leads/get_logs.php'            => ['modules' => ['leads'], 'kind' => 'api'],
    'leads/pagination.php'          => ['modules' => ['leads'], 'kind' => 'api'],
    'leads/export.php'              => ['modules' => ['leads'], 'need' => 'export', 'kind' => 'page'],
    'leads/insert_curd.php'         => ['modules' => ['leads'], 'need' => 'edit', 'kind' => 'api'],
    'leads/insert_lead.php'         => ['modules' => ['leads'], 'need' => 'edit', 'kind' => 'api'],
    'leads/ajax_log_activity.php'   => ['login' => true, 'kind' => 'api'],
    'leads/users_api.php'           => ['super' => true, 'kind' => 'api'],
    'crm_settings_api.php'          => ['super' => true, 'kind' => 'api'],
    'leads/ajax_add_user.php'       => ['super' => true, 'kind' => 'api'],
    'leads/ajax_update_user.php'    => ['super' => true, 'kind' => 'api'],
    'leads/ajax_get_users.php'      => ['super' => true, 'kind' => 'api'],
    'leads/ajax_update_permissions.php' => ['super' => true, 'kind' => 'api'],
    'analytics/get_analytics.php'   => ['modules' => ['analytics'], 'kind' => 'api'],
    'analytics/get_funnel.php'      => ['modules' => ['analytics'], 'kind' => 'api'],
    'analytics/get_heatmap.php'     => ['modules' => ['analytics'], 'kind' => 'api'],
    'analytics/get_hourly_distribution.php'       => ['modules' => ['analytics', 'leads'], 'kind' => 'api'],
    'analytics/get_leads_hourly_distribution.php' => ['modules' => ['analytics', 'leads'], 'kind' => 'api'],
    'analytics/get_session_journey.php' => ['modules' => ['analytics'], 'kind' => 'api'],
    'meta_capi/upload_csv.php'      => ['modules' => ['capi'], 'kind' => 'api'],
    'meta_capi/process_capi_lead.php' => ['modules' => ['capi'], 'kind' => 'api'],
    'meta_capi/verify_pixel.php'    => ['modules' => ['capi'], 'kind' => 'api'],
];

/** Default roles created the first time (Super Admin is built in and not stored). */
function pqDefaultRoles(): array
{
    $all = [];
    foreach (PQ_MODULES as $m => $d) {
        $all[$m] = array_keys($d['actions']);
    }
    $viewOnly = [];
    foreach (['overview', 'reports', 'targets', 'meta', 'google', 'taboola', 'manual', 'creatives', 'keywords', 'lphygiene', 'leads', 'unmapped', 'crm', 'analytics'] as $m) {
        $viewOnly[$m] = ['view'];
    }
    return [
        'admin'  => ['name' => 'Admin', 'description' => 'Everything except Users & Roles', 'permissions' => $all, 'is_system' => 1],
        'viewer' => ['name' => 'Viewer', 'description' => 'Can see dashboards and leads, cannot change or export anything', 'permissions' => $viewOnly, 'is_system' => 0],
    ];
}

function pqIsSuperadmin(): bool
{
    return ($_SESSION['role'] ?? '') === 'superadmin';
}

/** Creates pq_roles (+ default roles) and widens users.role from ENUM to VARCHAR. Safe to call often. */
function pqEnsureRoles(mysqli $db): array
{
    $notes = [];
    try {
        $db->query("CREATE TABLE IF NOT EXISTS `pq_roles` (
            `role_key`    VARCHAR(50)  NOT NULL,
            `name`        VARCHAR(100) NOT NULL,
            `description` VARCHAR(255) NULL,
            `permissions` TEXT         NULL,
            `is_system`   TINYINT(1)   NOT NULL DEFAULT 0,
            `created_at`  DATETIME     NULL,
            `updated_at`  DATETIME     NULL,
            PRIMARY KEY (`role_key`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
        $r = $db->query('SELECT COUNT(*) AS n FROM `pq_roles`');
        if ($r && (int) $r->fetch_assoc()['n'] === 0) {
            $now = date('Y-m-d H:i:s');
            $st = $db->prepare('INSERT INTO `pq_roles` (role_key, name, description, permissions, is_system, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)');
            foreach (pqDefaultRoles() as $key => $r) {
                $p = json_encode($r['permissions']);
                $st->bind_param('ssssiss', $key, $r['name'], $r['description'], $p, $r['is_system'], $now, $now);
                $st->execute();
            }
        }
    } catch (Throwable $e) {
        $notes[] = 'Could not create the roles table: ' . $e->getMessage();
    }
    // users.role was ENUM('superadmin','admin') — custom roles need a text column
    try {
        $c = $db->query("SHOW COLUMNS FROM `users` LIKE 'role'");
        $col = $c ? $c->fetch_assoc() : null;
        if ($col && stripos((string) $col['Type'], 'enum') === 0) {
            if (!$db->query("ALTER TABLE `users` MODIFY `role` VARCHAR(50) NOT NULL DEFAULT 'admin'")) {
                $notes[] = 'users.role is still ENUM(superadmin, admin) — new roles cannot be given to users until it is changed: ' . $db->error;
            }
        }
    } catch (Throwable $e) {
        $notes[] = 'Could not check users.role: ' . $e->getMessage();
    }
    return $notes;
}

/** All roles: key => [name, description, permissions, is_system]. Missing table → built-in defaults. */
function pqRoles(?mysqli $db, bool $fresh = false): array
{
    static $cache = null;
    if ($cache !== null && !$fresh) {
        return $cache;
    }
    $roles = [];
    if ($db) {
        try {
            $res = @$db->query('SELECT role_key, name, description, permissions, is_system FROM `pq_roles` ORDER BY is_system DESC, name');
            while ($res && ($r = $res->fetch_assoc())) {
                $roles[$r['role_key']] = ['name' => $r['name'], 'description' => (string) $r['description'],
                    'permissions' => pqCleanPermissions(pqUpgradePermissions(json_decode((string) $r['permissions'], true) ?: [])), 'is_system' => (int) $r['is_system']];
            }
        } catch (Throwable $e) {
        }
    }
    if (!$roles) {
        $roles = pqDefaultRoles();   // table not created yet: admin keeps full access, as before
    }
    return $cache = $roles;
}

/**
 * Roles saved before a module had its own rights keep what they could do, until the role is saved again:
 *   v1 → v2: Creatives with Meta or Google view, Keywords with Google view, awareness with manual-platform edit
 *   v2 → v3: Taboola with All Platforms view
 *   v3 → v4: LP Hygiene (every right) with Meta or Google sync
 *   v4 → v5: LP Hygiene rights split — 'run' also gets 'edit' + 'pdf', 'test' becomes Meta + landing page test leads
 *   v5 → v6: Upload Lead Status → "Add missing leads" for roles that can upload
 */
function pqUpgradePermissions(array $p): array
{
    $v = (int) ($p['v'] ?? 1);
    $has = fn(string $m, string $a = 'view') => in_array($a, (array) ($p[$m] ?? []), true);
    if ($v < 2) {
        if (!isset($p['creatives']) && ($has('meta') || $has('google'))) {
            $p['creatives'] = ['view'];
        }
        if (!isset($p['keywords']) && $has('google')) {
            $p['keywords'] = ['view'];
        }
        if ($has('manual', 'edit') && !$has('manual', 'awareness')) {
            $p['manual'][] = 'awareness';
        }
    }
    if ($v < 3 && !isset($p['taboola']) && $has('overview')) {
        $p['taboola'] = ['view'];   // Taboola used to come with All Platforms
    }
    if ($v < 4 && !isset($p['lphygiene']) && ($has('meta', 'sync') || $has('google', 'sync'))) {
        $p['lphygiene'] = ['view', 'run', 'edit', 'meta_test', 'lp_test', 'pdf'];   // new module: the people who run campaigns
    } elseif ($v < 5 && isset($p['lphygiene'])) {
        $a = (array) $p['lphygiene'];
        if (in_array('run', $a, true)) {
            array_push($a, 'edit', 'pdf');
        }
        if (in_array('test', $a, true)) {
            array_push($a, 'meta_test', 'lp_test');
        }
        $p['lphygiene'] = array_values(array_unique(array_diff($a, ['test'])));
    }
    if ($v < 6 && $has('status') && !$has('status', 'insert')) {
        $p['status'][] = 'insert';   // new right: the people who upload the feedback report
    }
    return $p;
}

/** Keeps only known modules / actions; any action implies view. 'v' = permission layout version (see pqUpgradePermissions). */
function pqCleanPermissions(array $in): array
{
    $out = ['v' => 6];
    foreach (PQ_MODULES as $m => $d) {
        $acts = array_values(array_intersect(array_keys($d['actions']), array_map('strval', (array) ($in[$m] ?? []))));
        if ($acts && !in_array('view', $acts, true)) {
            array_unshift($acts, 'view');
        }
        if ($acts) {
            $out[$m] = $acts;
        }
    }
    $hide = array_values(array_intersect(array_keys(PQ_METRICS), array_map('strval', (array) ($in['hide_metrics'] ?? []))));
    if ($hide) {
        $out['hide_metrics'] = $hide;
    }
    $types = array_values(array_intersect(array_keys(PQ_CAMPAIGN_TYPES), array_map('strval', (array) ($in['hide_types'] ?? []))));
    if (count($types) >= count(PQ_CAMPAIGN_TYPES)) {
        $types = array_values(array_diff($types, ['performance']));   // never both: keep performance
    }
    if ($types) {
        $out['hide_types'] = $types;
    }
    return $out;
}

/** Metrics hidden for the logged-in user (never for Super Admin). */
function pqHiddenMetrics(): array
{
    if (pqIsSuperadmin()) {
        return [];
    }
    $roles = pqRoles($GLOBALS['conn'] ?? null);
    return array_values((array) ($roles[(string) ($_SESSION['role'] ?? '')]['permissions']['hide_metrics'] ?? []));
}

/**
 * Campaign types this user may see: ['performance', 'awareness'] minus the role's hidden ones.
 * Super Admin and requests without a signed-in user (cron reports) see both.
 */
function pqAllowedCampaignTypes(): array
{
    static $memo = null;
    if ($memo !== null) {
        return $memo;
    }
    $all = array_keys(PQ_CAMPAIGN_TYPES);
    if (pqIsSuperadmin() || ($_SESSION['role'] ?? '') === '') {
        return $memo = $all;
    }
    $roles = pqRoles($GLOBALS['conn'] ?? null);
    $hide = (array) ($roles[(string) $_SESSION['role']]['permissions']['hide_types'] ?? []);
    $ok = array_values(array_diff($all, $hide));
    return $memo = ($ok ?: ['performance']);
}

function pqCanSeeType(string $type): bool
{
    return in_array($type === 'awareness' ? 'awareness' : 'performance', pqAllowedCampaignTypes(), true);
}

/** Report / API field names per hideable metric. */
const PQ_METRIC_FIELDS = [
    'qualified'  => ['qualified', 'ql', 'positive_prospects', 'qualified_leads', 'total_qualified', 'in_qualified', 'qualified_rate', 'ql_rate'],
    'cpql'       => ['cpql'],
    'sitevisits' => ['site_visits', 'sitevisits', 'sv_done', 'site_visits_done', 'walkins', 'walkin_leads', 'total_sitevisit', 'lead_to_sv_rate', 'sv_rate'],
    'cpsv'       => ['cpsv'],
];
/** Words that give a hidden metric away in report text (AI insights, summaries). */
const PQ_METRIC_WORDS = [
    'qualified'  => '/\\b(qualified|ql|mql|positive prospects?)\\b/i',
    'cpql'       => '/\\bcpql\\b|cost per qualified/i',
    'sitevisits' => '/\\b(site[- ]?visits?|sv|walk-?ins?)\\b/i',
    'cpsv'       => '/\\bcpsv\\b|cost per site visit/i',
];

/**
 * Blank the metrics hidden for this user anywhere in a report payload (numbers → null, lists → []),
 * and drop sentences of text fields (insight_text, summary, takeaways …) that mention them.
 */
function pqStripHiddenMetrics($data, ?array $hide = null)
{
    $hide = $hide ?? pqHiddenMetrics();
    if (!$hide) {
        return $data;
    }
    $fields = [];
    foreach ($hide as $m) {
        foreach (PQ_METRIC_FIELDS[$m] ?? [] as $f) {
            $fields[$f] = true;
        }
    }
    $walk = function ($v) use (&$walk, $fields, $hide) {
        if (!is_array($v)) {
            return is_string($v) && strlen($v) > 40 ? pqStripMetricSentences($v, $hide) : $v;
        }
        foreach ($v as $k => $x) {
            if (is_string($k) && isset($fields[strtolower($k)])) {
                $v[$k] = is_array($x) ? [] : null;
            } elseif ($k === 'QUALIFIED' && in_array('qualified', $hide, true)) {
                unset($v[$k]);   // lead-status breakdown
            } else {
                $v[$k] = $walk($x);
            }
        }
        return $v;
    };
    return $walk($data);
}

/** Remove the sentences / bullet lines of $text that mention a hidden metric. */
function pqStripMetricSentences(string $text, array $hide): string
{
    $parts = preg_split('/(?<=[.!?])\\s+|\\n/u', $text, -1) ?: [$text];
    $keep = [];
    foreach ($parts as $p) {
        $bad = false;
        foreach ($hide as $m) {
            if (isset(PQ_METRIC_WORDS[$m]) && preg_match(PQ_METRIC_WORDS[$m], $p)) {
                $bad = true;
                break;
            }
        }
        if (!$bad) {
            $keep[] = $p;
        }
    }
    return trim(implode(' ', $keep));
}

/**
 * Controls a role may not use on the Meta / Google pages: Export (Reports permission) and Unmapped Leads.
 * Returns a <style> + window.PQ_CAN for the page (empty for Super Admin / full access).
 */
function pqPageControlsTag(): string
{
    $can = ['reports' => pqCan('reports'), 'unmapped' => pqCan('unmapped'), 'targets' => pqCan('targets')];
    $css = '';
    if (!$can['reports']) {
        $css .= '#export-dropdown-wrap{display:none!important}';
    }
    if (!$can['unmapped']) {
        $css .= 'button[onclick^="openUnmapped"]{display:none!important}';
    }
    return '<script>window.PQ_CAN = ' . json_encode($can) . ';</script>' . ($css !== '' ? '<style>' . $css . '</style>' : '');
}

/**
 * <script> tags for a dashboard page: the hidden-metrics list + assets/js/metric_guard.js.
 * $assetsBase = path from the page to public/ ('' for public/*.php, '../' for public/ads/*.php).
 */
/**
 * First day of "All time" on the date filters: the date of the oldest lead in the project's lead databases
 * (cached 12 hours), or define('PROJECT_START_DATE', 'YYYY-MM-DD') in config.php. Never older than 37 months less
 * two days — Meta keeps ad results that long (counted in the ad account's time zone; right on the edge it refuses).
 */
function pqAllTimeSince(): string
{
    $limit = date('Y-m-d', strtotime('-37 months +2 days'));
    $ok = fn($d) => is_string($d) && preg_match('/^\d{4}-\d{2}-\d{2}$/', $d);
    if (defined('PROJECT_START_DATE') && $ok((string) PROJECT_START_DATE)) {
        return max((string) PROJECT_START_DATE, $limit);
    }
    $file = (defined('CACHE_PATH') ? CACHE_PATH : sys_get_temp_dir()) . '/all_time_since.json';
    $c = is_file($file) && filemtime($file) > time() - 43200 ? json_decode((string) @file_get_contents($file), true) : null;
    if (is_array($c) && $ok($c['since'] ?? null)) {
        return max($c['since'], $limit);
    }
    $min = null;
    foreach (function_exists('leadDbs') ? leadDbs('all') : [] as $db) {
        try {
            $r = $db->query("SELECT MIN(createddate) AS d FROM `lead` WHERE createddate IS NOT NULL AND createddate > '2000-01-01'");
            $d = $r ? substr((string) ($r->fetch_assoc()['d'] ?? ''), 0, 10) : '';
            if ($ok($d) && ($min === null || $d < $min)) {
                $min = $d;
            }
        } catch (Throwable $e) {
            // a lead database that can't be read: ignore it
        }
    }
    $min ??= date('Y-m-d', strtotime('-1 year'));
    @file_put_contents($file, json_encode(['since' => $min]));
    return max($min, $limit);
}

/** window.PQ_ALL_SINCE + date_presets.js for the date filters' "Last 1 year" / "All time". $assetsBase = path to public/. */
function pqDatesTag(string $assetsBase = ''): string
{
    try {
        $s = pqAllTimeSince();
    } catch (Throwable $e) {
        $s = date('Y-m-d', strtotime('-1 year'));
    }
    $v = @filemtime(PUBLIC_PATH . '/assets/js/date_presets.js') ?: 1;
    return '<script>window.PQ_ALL_SINCE = ' . json_encode($s) . ';</script>'
        . '<script src="' . htmlspecialchars($assetsBase, ENT_QUOTES) . 'assets/js/date_presets.js?v=' . $v . '"></script>';
}

/** The tabs of this viewer + campaign_view.js (All / Performance / Awareness). $assetsBase = path to public/. */
function pqViewTag(string $assetsBase = ''): string
{
    $t = pqAllowedCampaignTypes();
    $tabs = count($t) > 1 ? array_merge(['all'], $t) : $t;
    $v = @filemtime(PUBLIC_PATH . '/assets/js/campaign_view.js') ?: 1;
    return '<script>window.PQ_VIEW_TABS = ' . json_encode($tabs) . ';</script>'
        . '<script src="' . htmlspecialchars($assetsBase, ENT_QUOTES) . 'assets/js/campaign_view.js?v=' . $v . '"></script>';
}

function pqMetricGuardTag(string $assetsBase = ''): string
{
    $hide = pqHiddenMetrics();
    $v = @filemtime(PUBLIC_PATH . '/assets/js/metric_guard.js') ?: 1;
    return '<script>window.PQ_HIDE_METRICS = ' . json_encode($hide) . ';</script>'
        . '<script src="' . htmlspecialchars($assetsBase, ENT_QUOTES) . 'assets/js/metric_guard.js?v=' . $v . '"></script>';
}

/** Can the logged-in user do $action in $module? */
function pqCan(string $module, string $action = 'view'): bool
{
    if (pqIsSuperadmin()) {
        return true;
    }
    $perms = $GLOBALS['PQ_PERMS'] ?? null;
    if ($perms === null) {
        $roles = pqRoles($GLOBALS['conn'] ?? null);
        $perms = $roles[(string) ($_SESSION['role'] ?? '')]['permissions'] ?? [];
        $GLOBALS['PQ_PERMS'] = $perms;
    }
    return in_array($action, $perms[$module] ?? [], true);
}

/** Dashboard sections (data-view ids) the user may open; manual platforms are 'm-…'. */
function pqCanView(string $view): bool
{
    if (str_starts_with($view, 'm-')) {
        return $view === 'm-new' ? pqCan('manual', 'edit') : pqCan('manual');
    }
    if ($view === 'users' || $view === 'crmsettings') {
        return pqIsSuperadmin();
    }
    $m = PQ_VIEW_MODULE[$view] ?? null;
    return $m !== null && pqCan($m);
}

/** What a request needs: [module list (any), action]. */
function pqRouteAction(array $rule): array
{
    $modules = $rule['modules'] ?? [];
    $need = $rule['need'] ?? 'view';
    $isWrite = ($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST';
    // a write with its own right, e.g. ott_api.php?action=awareness → Manual platforms → Set awareness spend
    $wa = $rule['write_actions'][(string) ($_GET['action'] ?? '')] ?? null;
    if ($wa !== null && $isWrite) {
        return [[$rule['write_module'] ?? $modules[0]], $wa];
    }
    if (!empty($rule['readonly_actions']) && in_array((string) ($_GET['action'] ?? ''), $rule['readonly_actions'], true)) {
        $isWrite = false;
    }
    if (!empty($rule['write']) && $isWrite) {
        $wm = $rule['write_module'] ?? null;
        if (!empty($rule['platform'])) {
            $wm = strtolower((string) ($_GET['platform'] ?? 'meta')) === 'google' ? 'google' : 'meta';
        }
        return [[$wm ?? $modules[0]], $rule['write']];
    }
    if (!empty($rule['platform'])) {
        $modules = [strtolower((string) ($_GET['platform'] ?? 'meta')) === 'google' ? 'google' : 'meta'];
    }
    return [$modules, $need];
}

function pqDeny(array $rule, string $message, int $code = 403): never
{
    while (ob_get_level()) {
        @ob_end_clean();
    }
    http_response_code($code);
    $depth = substr_count(pqScriptRel(), '/');
    $base = str_repeat('../', $depth);
    if (($rule['kind'] ?? 'api') === 'api') {
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['success' => false, 'status' => 'error', 'error' => $message, 'message' => $message, 'no_access' => true]);
        exit;
    }
    if ($code === 401) {
        header('Location: ' . $base . 'login.php');
        exit;
    }
    header('Content-Type: text/html; charset=utf-8');
    $m = htmlspecialchars($message, ENT_QUOTES, 'UTF-8');
    echo '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>No access</title>'
        . '<script>(function(){var t=null;try{t=localStorage.getItem("performiq-theme")}catch(e){}document.documentElement.setAttribute("data-theme",t==="light"?"light":"dark");window.setTheme=function(t){document.documentElement.setAttribute("data-theme",t==="light"?"light":"dark")}})();</script>'
        . '<style>:root,html[data-theme=dark]{--bg:#0B0F1A;--s:#111827;--b:#1E2A42;--t:#E2E8F0;--d:#94A3B8;--a:#E8A820}html[data-theme=light]{--bg:#F4F6FA;--s:#fff;--b:#E2E8F0;--t:#0F172A;--d:#475569;--a:#B7791F}'
        . 'body{margin:0;min-height:100vh;display:grid;place-items:center;background:var(--bg);color:var(--t);font:14px/1.6 system-ui,-apple-system,Segoe UI,sans-serif;padding:20px;box-sizing:border-box}'
        . '.c{max-width:420px;text-align:center;background:var(--s);border:1px solid var(--b);border-radius:14px;padding:32px 28px}.i{width:52px;height:52px;border-radius:14px;margin:0 auto 14px;display:grid;place-items:center;background:color-mix(in srgb,var(--a) 15%,transparent);color:var(--a);font-size:24px}'
        . 'h1{font-size:18px;margin:0 0 6px}p{color:var(--d);margin:0}</style></head>'
        . '<body><div class="c"><div class="i">&#128274;</div><h1>You don\'t have access to this page</h1><p>' . $m . '</p></div></body></html>';
    exit;
}

function pqScriptRel(): string
{
    $file = str_replace('\\', '/', (string) (realpath((string) ($_SERVER['SCRIPT_FILENAME'] ?? '')) ?: ''));
    $pub = str_replace('\\', '/', (string) (realpath(PUBLIC_PATH) ?: PUBLIC_PATH));
    return str_starts_with($file, $pub . '/') ? substr($file, strlen($pub) + 1) : '';
}

/** Runs once per web request (end of app/Core/db.php). */
function pqAccessGuard(?mysqli $conn): void
{
    static $done = false;
    if ($done || PHP_SAPI === 'cli') {
        return;
    }
    $done = true;
    $rel = pqScriptRel();
    $rule = PQ_ROUTES[$rel] ?? null;
    if ($rule === null) {
        return;
    }
    // the admin calling itself (portfolio PDF etc.) — already checked by the outer request
    $internal = (string) ($_SERVER['HTTP_X_PQ_INTERNAL'] ?? '');
    if ($internal !== '') {
        if (!function_exists('pqInternalKey')) {
            @include_once APP_PATH . '/Ads/master_tables.php';
        }
        if (function_exists('pqInternalKey') && hash_equals(pqInternalKey(), $internal)) {
            return;
        }
    }

    $opened = false;
    if (session_status() !== PHP_SESSION_ACTIVE) {
        if (headers_sent()) {
            return;
        }
        @session_start();
        $opened = true;
    }
    $close = function () use (&$opened) {
        if ($opened) {
            session_write_close();
            $opened = false;
        }
    };

    if (($_SESSION['user_logged'] ?? '') !== 'Y') {
        $close();
        pqDeny($rule, 'Please sign in again.', 401);
    }

    // re-read the user: blocked / deleted users are signed out, role changes apply straight away
    if ($conn && !empty($_SESSION['uid'])) {
        try {
            // export_email / export_mobile came with an update: add them once if missing, and never fail on them
            if (empty($_SESSION['pq_contact_cols']) && function_exists('pqEnsureContactColumns')) {
                $_SESSION['pq_contact_cols'] = pqEnsureContactColumns($conn) ? 1 : 0;
            }
            $cols = !empty($_SESSION['pq_contact_cols']) ? ', export_email, export_mobile' : '';
            $uid = (int) $_SESSION['uid'];
            $st = $conn->prepare('SELECT role, status, unmask_email, unmask_mobile' . $cols . ' FROM users WHERE uid = ?');
            if (!$st && $cols !== '') {
                $_SESSION['pq_contact_cols'] = 0;
                $st = $conn->prepare('SELECT role, status, unmask_email, unmask_mobile FROM users WHERE uid = ?');
            }
            $st->bind_param('i', $uid);
            $st->execute();
            $u = $st->get_result()->fetch_assoc();
            $st->close();
            if (!$u || ($u['status'] ?? 'Y') !== 'Y') {
                $_SESSION = [];
                if ($opened) {
                    session_destroy();
                    $opened = false;
                } else {
                    session_destroy();
                }
                pqDeny($rule, $u ? 'Your account is blocked. Contact your admin.' : 'Your account was removed.', 401);
            }
            foreach (['role', 'unmask_email', 'unmask_mobile', 'export_email', 'export_mobile'] as $k) {
                if (isset($u[$k]) && ($_SESSION[$k] ?? null) !== $u[$k]) {
                    $_SESSION[$k] = $u[$k];
                }
            }
        } catch (Throwable $e) {
            // users table unreachable: fall back to the session as it is
        }
    }
    $close();
    $GLOBALS['PQ_PERMS'] = null;

    if (!empty($rule['login']) || pqIsSuperadmin()) {
        return;
    }
    if (!empty($rule['super'])) {
        pqDeny($rule, 'Only a Super Admin can open this.');
    }
    [$modules, $action] = pqRouteAction($rule);
    foreach ($modules as $m) {
        if (pqCan($m, $action)) {
            return;
        }
    }
    $what = PQ_MODULES[$modules[0]]['label'] ?? 'this page';
    $label = PQ_MODULES[$modules[0]]['actions'][$action] ?? $action;
    pqDeny($rule, $action === 'view'
        ? "Your role doesn't include {$what}. Ask a Super Admin for access."
        : "Your role can't do this in {$what} ({$label}). Ask a Super Admin for access.");
}
