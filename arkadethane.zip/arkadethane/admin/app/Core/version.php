<?php
/**
 * version.php — PerformIQ by Webzaa: the version of this build, the release notes and the FAQs shown on the About page
 * (public/about.php), in the sidebar footer and in the user menu.
 *
 * Written for the execution / DM team: what you can do now, where to find it, why it matters. No code words.
 * Versions are major.minor.patch (1.0.37); PQ_CHANNEL adds "Beta". The technical notes keep their file names
 * (docs/CHANGES_v37.md) and are shown to Super Admin only.
 *
 * Shipping a new patch: add it at the TOP of PQ_RELEASES and update PQ_VERSION / PQ_RELEASED.
 * Each release: v, date (YYYY-MM-DD), title, areas (filter labels), why (one line: why it matters),
 * items (what you can do now), where (where to find it in the menu), optional doc (technical notes, Super Admin).
 */

const PQ_PRODUCT  = 'PerformIQ';
const PQ_VENDOR   = 'Webzaa';
const PQ_VERSION  = '1.0.37';      // major.minor.patch
const PQ_CHANNEL  = 'Beta';        // shown after the number: "1.0.37 Beta" ('' for a stable release)
const PQ_RELEASED = '2026-10-31';

const PQ_RELEASES = [
    [
        'v' => '1.0.37', 'date' => '2026-10-31', 'title' => 'About page in simple words + FAQs',
        'areas' => ['Help'], 'doc' => 'CHANGES_v37.md',
        'why' => 'Everyone on the team can see what changed and find answers without asking.',
        'items' => [
            'Every update now says what you can do, where to find it and why it helps.',
            'New FAQs: quick answers on numbers, dates, uploading CRM feedback, importing leads and access.',
            'Search the updates and the FAQs from one box.',
        ],
        'where' => 'Menu → bottom "PerformIQ 1.0.37 Beta", or your name (top right) → About PerformIQ',
    ],
    [
        'v' => '1.0.36', 'date' => '2026-10-31', 'title' => 'About PerformIQ page',
        'areas' => ['Help'], 'doc' => 'CHANGES_v36.md',
        'why' => 'You always know which version you are on and what is new.',
        'items' => [
            'The version and the date of the last update are shown at the bottom of the menu.',
            'One page lists every feature of PerformIQ and shows which ones you have access to.',
        ],
        'where' => 'Menu → bottom "PerformIQ …", or your name → About PerformIQ',
    ],
    [
        'v' => '1.0.35', 'date' => '2026-10-30', 'title' => 'Site visit = Qualified lead',
        'areas' => ['CRM feedback'], 'doc' => 'CHANGES_v35.md',
        'why' => 'CPQL and CPSV now agree with the sales team: anyone who visited the site counts as qualified.',
        'items' => [
            'When the CRM file says "Site Visit Done", the lead becomes Qualified and Site visit = Yes, whatever the status column says.',
            'Same when you add missing leads from that file.',
            'Leads that are already qualified stay qualified.',
        ],
        'where' => 'CRM → Upload Lead Status',
    ],
    [
        'v' => '1.0.34', 'date' => '2026-10-30', 'title' => 'A person listed twice keeps their site visit',
        'areas' => ['CRM feedback'], 'doc' => 'CHANGES_v34.md',
        'why' => 'Site visits are no longer lost when someone has two enquiries in the CRM file.',
        'items' => [
            'If the same mobile number appears twice (e.g. one "Site Visit Done" and one "Lost"), the site visit row is used.',
            'Order of preference: site visit, then qualified, then the other row.',
        ],
        'where' => 'CRM → Upload Lead Status → step 4 shows "Repeated" rows',
    ],
    [
        'v' => '1.0.33', 'date' => '2026-10-30', 'title' => 'Import only the missing Meta leads',
        'areas' => ['Lead import', 'Meta'], 'doc' => 'CHANGES_v33.md',
        'why' => 'Fill gaps from Meta without creating duplicates or wrong dates.',
        'items' => [
            'Upload the leads file downloaded from Meta Ads Manager: only leads not already in PerformIQ are added.',
            'Each lead keeps the exact date and time it came in (not the time you imported it).',
            'Campaign, ad set and ad names are taken from Meta automatically; leads already in PerformIQ with blank names get them filled.',
            'Tick "Preview only" to see what will be added before saving.',
        ],
        'where' => 'Tools → Import Leads → Meta',
    ],
    [
        'v' => '1.0.32', 'date' => '2026-10-30', 'title' => 'MQL removed from the feedback upload',
        'areas' => ['CRM feedback'], 'doc' => 'CHANGES_v32.md',
        'why' => 'Qualified now comes only from the lead status (and site visits), as the sales team reports it.',
        'items' => [
            'The MQL box is gone from Upload Lead Status. Choose the lead status and site visit columns as usual.',
        ],
        'where' => 'CRM → Upload Lead Status → step 3',
    ],
    [
        'v' => '1.0.31', 'date' => '2026-10-30', 'title' => '"All time" now includes Meta',
        'areas' => ['Dashboards', 'Meta'], 'doc' => 'CHANGES_v31.md',
        'why' => 'Long date ranges show Meta spend instead of "Not included: Meta".',
        'items' => [
            'All time and 1 year work for Meta (Meta keeps results for about 3 years).',
            'If Meta has a problem, the message now says what is wrong in plain words.',
            'Target vs Achieved shows long ranges as one line, e.g. "October 2023 – October 2026 (37 months)".',
        ],
        'where' => 'All Platforms → date bar → All time',
    ],
    [
        'v' => '1.0.30', 'date' => '2026-10-30', 'title' => 'Missing leads go to the right database',
        'areas' => ['CRM feedback'], 'doc' => 'CHANGES_v29.md',
        'why' => 'Projects with two lead databases (e.g. Official and Pseudo) keep each lead in the right one.',
        'items' => [
            'When adding missing leads, each row shows which database it will go to; change one row or all rows at once.',
        ],
        'where' => 'CRM → Upload Lead Status → Add missing leads',
    ],
    [
        'v' => '1.0.29', 'date' => '2026-10-30', 'title' => 'Add missing leads from the CRM file',
        'areas' => ['CRM feedback'], 'doc' => 'CHANGES_v29.md',
        'why' => 'Leads that are in the CRM but not in PerformIQ can be added, so qualified leads and site visits are complete.',
        'items' => [
            'After uploading a CRM feedback file, click "Add missing leads" to see the leads PerformIQ does not have.',
            'Choose their source (e.g. Facebook, Google), edit any field, then add them — or download the list and add it later.',
            'Added leads are not sent to the CRM again, and you can undo them.',
        ],
        'where' => 'CRM → Upload Lead Status → after the upload',
    ],
    [
        'v' => '1.0.28', 'date' => '2026-10-29', 'title' => '"1 year" and "All time" on every date filter',
        'areas' => ['Dashboards'], 'doc' => 'CHANGES_v28.md',
        'why' => 'See the full project picture in one click.',
        'items' => [
            '1 year = the last 12 months. All time = from the project\'s first lead (up to about 3 years back).',
        ],
        'where' => 'Every page with a date filter',
    ],
    [
        'v' => '1.0.27', 'date' => '2026-10-29', 'title' => 'All / Performance / Awareness tabs',
        'areas' => ['Dashboards', 'Access'], 'doc' => 'CHANGES_v27.md',
        'why' => 'Report performance spend and leads without awareness spend mixing in (and the other way round).',
        'items' => [
            'Three tabs on every dashboard: All, Performance, Awareness. Numbers, charts, tables and downloads follow the tab.',
            'Campaigns are marked as awareness in ⟳ Sync.',
            'Admins can let a role see only performance or only awareness.',
        ],
        'where' => 'Top of All Platforms, Meta Ads, Google Ads, manual platforms, Creatives, Keywords',
    ],
    [
        'v' => '1.0.26', 'date' => '2026-10-29', 'title' => 'Mobile numbers show only the last 5 digits',
        'areas' => ['Access'],
        'why' => 'Client data stays private for roles that should not see full numbers.',
        'items' => [
            'Where your role hides mobile numbers, you see *****12345 everywhere, including downloads.',
        ],
        'where' => 'Leads & CRM, CRM Push, Unmapped Leads, uploads',
    ],
    [
        'v' => '1.0.25', 'date' => '2026-10-29', 'title' => 'LP Hygiene: check landing pages',
        'areas' => ['Landing pages'], 'doc' => 'CHANGES_v25.md',
        'why' => 'Catch slow pages, broken tracking or forms before they waste spend.',
        'items' => [
            'Page speed score for mobile and desktop, plus checks for tracking codes, the form and UTM capture.',
            'Send a test lead (Meta form or landing page) and see if it reached PerformIQ and the CRM.',
            'Download a PDF report for the client.',
        ],
        'where' => 'Tools → LP Hygiene',
    ],
    [
        'v' => '1.0.24', 'date' => '2026-10-29', 'title' => 'Works better on phones and tablets',
        'areas' => ['Dashboards'], 'doc' => 'CHANGES_v24.md',
        'why' => 'Check numbers on the go.',
        'items' => [
            'Menus, date filter, tables and pop-ups fit small screens; the dark theme works on every page.',
        ],
        'where' => 'Everywhere',
    ],
    [
        'v' => '1.0.23', 'date' => '2026-10-29', 'title' => 'Today and Yesterday on every date filter',
        'areas' => ['Dashboards'], 'doc' => 'CHANGES_v23.md',
        'why' => 'Daily checks in one click.',
        'items' => [
            'Today is the day so far — Meta and Google can take a few hours to show today\'s spend.',
        ],
        'where' => 'Every page with a date filter',
    ],
    [
        'v' => '1.0.22', 'date' => '2026-10-28', 'title' => 'Targets from Excel',
        'areas' => ['Targets'], 'doc' => 'CHANGES_v22.md',
        'why' => 'Set the monthly plan in seconds instead of typing every box.',
        'items' => [
            'Import an Excel / CSV file, paste a block copied from Excel, or download the template, fill it and import it.',
        ],
        'where' => 'Overview → Targets',
    ],
    [
        'v' => '1.0.21', 'date' => '2026-10-28', 'title' => 'Keyword Analysis + choose campaigns for reports',
        'areas' => ['Google', 'Reports'], 'doc' => 'CHANGES_v21.md',
        'why' => 'See which Google keywords bring real leads, and send clients only the campaigns they need.',
        'items' => [
            'Keyword Analysis: Google keywords and search terms with CRM leads, and suggestions on what to do next.',
            'Before every report download you can pick all campaigns or only some.',
        ],
        'where' => 'Insights → Keyword Analysis · Reports button on the dashboards',
    ],
    [
        'v' => '1.0.20', 'date' => '2026-10-26', 'title' => 'Ad images load reliably',
        'areas' => ['Creatives'], 'doc' => 'CHANGES_v20.md',
        'why' => 'See exactly which creative brought the leads.',
        'items' => [
            'Ad pictures and videos show for Meta and Google; carousel ads show all their cards.',
            'If a picture really cannot load, it says "Image not available" instead of a broken image.',
        ],
        'where' => 'Insights → Creatives & Insights',
    ],
    [
        'v' => '1.0.19', 'date' => '2026-10-24', 'title' => 'Creatives & Insights',
        'areas' => ['Creatives', 'Reports'], 'doc' => 'CHANGES_v19.md',
        'why' => 'Know which ads to scale, fix or pause.',
        'items' => [
            'Every Meta and Google ad with its image or video, spend, leads, CPL, CPQL and site visits.',
            'Suggestions such as "winner on CPQL", "cheap but junk leads", "ad fatigue".',
            'Daily budget column on the Meta and Google campaign tables; report emails include the suggestions.',
        ],
        'where' => 'Insights → Creatives & Insights',
    ],
    [
        'v' => '1.0.18', 'date' => '2026-10-24', 'title' => 'One dashboard, safer data',
        'areas' => ['Access'], 'doc' => 'CHANGES_v18.md',
        'why' => 'Everything opens in one place and hidden data stays hidden.',
        'items' => [
            'Opening the admin link goes straight to the dashboard.',
            'Hidden emails and mobile numbers are never sent to your browser, not even in the page code.',
        ],
        'where' => 'Admin link',
    ],
];

/**
 * FAQs for the execution / DM team. topic groups them; q = question, a = answer (plain text; **bold** allowed).
 */
const PQ_FAQS = [
    // Numbers & dates
    ['topic' => 'Numbers & dates', 'q' => 'Why are the numbers on PerformIQ different from Meta Ads Manager or Google Ads?',
     'a' => 'Spend, impressions and clicks come from Meta / Google. **Leads, qualified leads and site visits come from the project\'s lead database and the CRM feedback**, not from Meta\'s or Google\'s own lead count. Only campaigns linked to this project (⟳ Sync) are counted, and test leads are left out.'],
    ['topic' => 'Numbers & dates', 'q' => 'Why is today\'s spend low or zero?',
     'a' => '"Today" is the day so far. Meta and Google can take a few hours to report spend — check again later or use Yesterday for a full day.'],
    ['topic' => 'Numbers & dates', 'q' => 'How far back does "All time" go?',
     'a' => 'From the project\'s first lead, up to about 3 years (37 months) back. Meta and Google do not keep detailed results longer than that.'],
    ['topic' => 'Numbers & dates', 'q' => 'Why are Reach and Frequency blank on Google for long dates?',
     'a' => 'Google gives Reach and Frequency only for 92 days or less. Pick a shorter range to see them.'],
    ['topic' => 'Numbers & dates', 'q' => 'What do CPL, CPQL and CPSV mean?',
     'a' => '**CPL** = spend ÷ leads. **CPQL** = spend ÷ qualified leads. **CPSV** = spend ÷ site visits. Qualified leads and site visits come from the CRM feedback you upload.'],
    ['topic' => 'Numbers & dates', 'q' => 'What is the difference between All, Performance and Awareness?',
     'a' => '**Performance** = lead-generation campaigns. **Awareness** = campaigns marked as awareness in ⟳ Sync (and the awareness share of manual platforms like OTT). **All** = both together. Choose the tab before downloading a report — the report follows it.'],
    ['topic' => 'Numbers & dates', 'q' => 'A Meta or Google campaign is missing from the dashboard. Why?',
     'a' => 'It is probably not linked to this project. Open Meta Ads or Google Ads → ⟳ Sync and tick the campaign. Leads that came from it appear under Unmapped Leads until then.'],

    // CRM feedback
    ['topic' => 'CRM feedback upload', 'q' => 'Which file do I upload in Upload Lead Status?',
     'a' => 'The lead export from the CRM (Salesforce etc.) as Excel (.xlsx / .xls) or CSV. It needs a **mobile number** column and a **status** column (e.g. "Pre Sales Last Call Attempt"). Site visit can be the same column.'],
    ['topic' => 'CRM feedback upload', 'q' => 'How are leads matched? Does +91 matter?',
     'a' => 'By the **last 10 digits of the mobile number**. +91, 0, spaces and dashes are ignored, so "+91 98765 43210" and "9876543210" match.'],
    ['topic' => 'CRM feedback upload', 'q' => 'What should I choose for "Open (Non Contactable)", "Call Back" or "Follow Up"?',
     'a' => '**To be qualified** — the sales team has not qualified them yet. Choose **Qualified** only for statuses the client counts as qualified, and **Non-qualified** for Lost / Junk. Wrong choices here change CPQL for the whole project.'],
    ['topic' => 'CRM feedback upload', 'q' => 'Does a site visit count as a qualified lead?',
     'a' => 'Yes. Every "Site Visit Done" lead is saved as Qualified + Site visit = Yes.'],
    ['topic' => 'CRM feedback upload', 'q' => 'Why are so many rows "Not found"?',
     'a' => 'Those enquiries are not in PerformIQ. Usual reasons: they came from the client\'s own website, walk-ins, another agency or channel partners, or Meta leads that never reached PerformIQ. Download the not-found list to check them, and use **Add missing leads** for the ones that are ours.'],
    ['topic' => 'CRM feedback upload', 'q' => 'The same person is in the file twice. Which row is used?',
     'a' => 'The row with the site visit, otherwise the qualified one, otherwise the lower row. The other row is shown under "Repeated".'],
    ['topic' => 'CRM feedback upload', 'q' => 'I uploaded with the wrong choices. Can I undo it?',
     'a' => 'Yes. Upload Lead Status → history at the bottom → **Undo** on that upload. Or simply upload the same file again with the right choices — it overwrites the statuses.'],
    ['topic' => 'CRM feedback upload', 'q' => 'What happened to MQL?',
     'a' => 'It is not used any more. Qualified comes only from the lead status and site visits.'],

    // Importing leads
    ['topic' => 'Importing leads', 'q' => 'Meta leads are missing in PerformIQ. How do I add them?',
     'a' => 'In Meta Ads Manager (or Leads Center) **download the leads** of the form. In PerformIQ open **Tools → Import Leads**, choose **Meta**, pick the file, tick **Preview only** and click Import to check. Then untick Preview and import. Only the missing leads are added, with their original date and time.'],
    ['topic' => 'Importing leads', 'q' => 'Will importing the same file twice create duplicates?',
     'a' => 'No. A Meta lead that is already in PerformIQ is skipped. A person who filled the form twice is two leads in Meta, so both are added — the result marks them "same mobile as lead #…".'],
    ['topic' => 'Importing leads', 'q' => 'Why do imported leads show the campaign and ad names?',
     'a' => 'PerformIQ asks Meta for the campaign, ad set and ad names of each lead, so they land under the right campaign on the dashboard.'],

    // Tools
    ['topic' => 'Tools', 'q' => 'How do I send a test lead without spoiling the numbers?',
     'a' => 'Use **LP Hygiene → test lead**. The name and email always contain "test", and every lead with "test" in the name or email is left out of the dashboards and reports.'],
    ['topic' => 'Tools', 'q' => 'Where do I set the monthly targets?',
     'a' => 'Overview → **Targets**. Type them, paste a block from Excel, or download the template, fill it and import it. The dashboards then show Target vs Achieved.'],
    ['topic' => 'Tools', 'q' => 'What are Unmapped Leads?',
     'a' => 'Meta or Google leads that do not belong to one of this project\'s campaigns. Map them to a campaign (or link the campaign in ⟳ Sync) so they count on the dashboard.'],
    ['topic' => 'Tools', 'q' => 'What does CRM Push show?',
     'a' => 'Which leads reached the CRM, which failed (with the reason) and which were never sent. You can resend failed leads from there if your role allows it.'],

    // Access
    ['topic' => 'Access & help', 'q' => 'Why do I see *****12345 instead of the full mobile number?',
     'a' => 'Your role hides mobile numbers (only the last 5 digits show). Ask your Super Admin if you need full numbers.'],
    ['topic' => 'Access & help', 'q' => 'I can\'t see a page or some numbers (CPQL, site visits…). Why?',
     'a' => 'Your role does not include them. The Super Admin can change this in **Admin → Users & Roles**. This page shows "You have access" next to each feature you can open.'],
    ['topic' => 'Access & help', 'q' => 'How do I know which version I am on?',
     'a' => 'At the bottom of the menu: "PerformIQ 1.0.37 Beta · Updated …". Click it to see what is new.'],
    ['topic' => 'Access & help', 'q' => 'Something looks wrong. Who do I tell?',
     'a' => 'Tell your Super Admin or the Webzaa team with: the page, the date range, a screenshot and what you expected to see.'],
];

/** "1.0.37 Beta" — the version as shown everywhere. */
function pqVersionLabel(?string $v = null): string
{
    return trim(($v ?? PQ_VERSION) . ' ' . (defined('PQ_CHANNEL') ? PQ_CHANNEL : ''));
}

/** "30 Oct 2026" */
function pqReleaseDate(string $ymd): string
{
    $t = strtotime($ymd);
    return $t ? date('j M Y', $t) : $ymd;
}

/** Plain text with **bold** → safe HTML. */
function pqHelpHtml(string $s): string
{
    $s = htmlspecialchars($s, ENT_QUOTES, 'UTF-8');
    return preg_replace('/\*\*(.+?)\*\*/', '<b>$1</b>', $s);
}
