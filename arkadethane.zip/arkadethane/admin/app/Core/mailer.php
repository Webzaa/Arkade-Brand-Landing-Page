<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require dirname(__DIR__, 2) . '/vendor/autoload.php';   // Composer path
require_once dirname(__DIR__, 2) . '/app/bootstrap.php';

// -------------------------------------------------
// Create base mailer (reusable)
// -------------------------------------------------

function getMailer()
{

  $mail = new PHPMailer(true);

  // SMTP Settings
  $mail->isSMTP();
  $mail->Host = SMTP_HOST;
  $mail->SMTPAuth = true;
  $mail->Username = SMTP_USER;
  $mail->Password = SMTP_PASS;
  $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
  $mail->Port = (int) SMTP_PORT;


  // General
  $mail->isHTML(true);
  $mail->CharSet = "UTF-8";

  $mail->setFrom(MAIL_FROM, MAIL_FROM_NAME);

  return $mail;
}


// -------------------------------------------------
// Send OTP Email
// -------------------------------------------------

function sendOTP($email, $otp)
{

  try {

    $mail = getMailer();

    $mail->addAddress($email);

    require_once __DIR__ . '/otp_mail.php';      // same template as the login page sends
    [$subject, $html, $text] = otpEmailHtml((string) $otp, (string) $email);
    $mail->Subject = $subject;
    $mail->Body = $html;
    $mail->AltBody = $text;

    $mail->send();
    return true;
  } catch (Exception $e) {

    return false;
  }
}
