<?php
/**
 * config/config.php — the ONE settings file for the whole admin.
 *
 * Every page, API, cron job and library loads this through app/bootstrap.php.
 * Contains passwords and API keys: never commit it, never put it under public/.
 * A blank copy for new servers lives in config/config.example.php.
 */

// ── App ───────────────────────────────────────────────────────────────
define('PROJECT_NAME', 'Arkade Thane');
define('APP_URL', 'https://arkadethane.info/admin');   // public URL of public/ (no trailing slash)
define('APP_TIMEZONE', 'Asia/Kolkata');

// ── Databases ─────────────────────────────────────────────────────────
// Connection details (used by LEAD_DATABASES below)
define('DB1_HOST', '127.0.0.1');
define('DB1_PORT', 3306);
define('DB1_USER', 'root');
define('DB1_PASS', 'Webadmin@931!!');
define('DB1_NAME', 'test_arkadebrand');

//define('DB2_HOST', '127.0.0.1');
//define('DB2_PORT', 3306);
//define('DB2_USER', 'root');
//define('DB2_PASS', 'Webadmin@931!!');
//define('DB2_NAME', 'test_arkadebrand');

// ── Lead databases — any number (1, 2, 5 …) ───────────────────────────
// Every database that has a `lead` table. The key (a-z, 0-9, _) is what the
// "Campaign Database" filter sends; the label is what users see.
// One entry → the filter hides itself. Add an entry → it shows up everywhere
// (Leads & CRM, exports, dashboards, reports, cron). No code changes needed.
define('LEAD_DATABASES', [
    //'pseudo' => [
       // 'label' => 'Pseudo Campaign',
       // 'host'  =>  '127.0.0.1', 'port' => 3306,
       // 'user'  =>  'root', 'pass' => 'Webadmin@931!!',
       // 'name'  => 'test_arkadebrand',
   // ],
    'official' => [
        'label' => 'Official Campaign',
        'host'  =>  '127.0.0.1', 'port' => 3306,
        'user'  => 'root', 'pass' => 'Webadmin@931!!',
        'name'  => 'test_arkadebrand',
    ],
    // Example — a third database:
    // 'westgate' => [
    //     'label' => 'Westgate',
    //     'host'  => '127.0.0.1', 'port' => 3306,
    //     'user'  => '',          'pass' => '',
    //     'name'  => 'westgate_crm',
    // ],
]);
// Database that holds users, sessions and activity logs ($conn). Must be a key above.
define('APP_DB', 'official');   // the only database configured for this project
// Optional: database the portfolio PDF report reads leads from (default: 2nd entry above, else 1st)
// define('PORTFOLIO_REPORT_DB', 'official');

// ── Email (SMTP, used by login OTP and report emails) ─────────────────
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);
define('SMTP_SECURE', 'tls');
define('SMTP_USER', 'info@webzaa.co.in');
define('SMTP_PASS', 'oyfo jtaa dvkf tqhw');
define('MAIL_FROM', 'info@webzaa.co.in');
define('MAIL_FROM_NAME', 'Webzaa Admin');

// ── Google sign-in for the admin login (google_callback.php) ─────────
// Renamed from GOOGLE_CLIENT_ID/SECRET: those names now belong to the Google Ads API below.
define('GOOGLE_LOGIN_CLIENT_ID', '536569090665-2njos6bl8gdg8052co2inithaufq52rf.apps.googleusercontent.com');
define('GOOGLE_LOGIN_CLIENT_SECRET', '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');
define('GOOGLE_LOGIN_REDIRECT_URI', 'https://arkadethane.info/admin/google_callback.php');

// ── Project-specific values (change these when copying the admin to another project) ──
// Campaign names containing any of these words count as this project in the portfolio report.
define('PROJECT_CAMPAIGN_KEYWORDS', ['belicia', 'embassy', 'rustomjee', 'pseudo', 'wz','Arkade']);
// Campaign name used for leads that arrived via WhatsApp.
define('META_WHATSAPP_CAMPAIGN_NAME', 'Wz Rustomjee Vista Bay Secondary Whatsapp Pseudo - 07/08/26');
// Google: CRM campaign value (lowercase) => campaign name shown in Google Ads.
// define('GOOGLE_CAMPAIGN_ALIASES', [
//     'location'                  => 'Belicia Location Official',
//     'location_pseudo'           => 'Belicia_Pseudo_Location',
//     'brand'                     => 'Belicia Brand Search',
//     'brand_pseudo'              => 'Belicia_Brand_Search_Pseudo',
//     'demandgen_12/09/26_pseudo' => 'Demand Gen_12/09/26_Pseudo',
// ]);

// ── Taboola ───────────────────────────────────────────────────────────
define('TABOOLA_CLIENT_ID', 'aeb643373af7409d9ba990195220dae4');
define('TABOOLA_CLIENT_SECRET', 'b5b27c0d593847e6811eff2be80faca3');
define('TABOOLA_ACCOUNT_ID', 'ssvtechnologies-houseofhiranandani-sc');
define('TABOOLA_BASE_URL', 'https://backstage.taboola.com/backstage');

// ── Meta (Facebook) ───────────────────────────────────────────────────
define('META_PIXEL_ID', '');
define('META_ACCESS_TOKEN', 'EAAFi6rjzjmUBO4ZANwI5ZBvpCWCMoEb6kIzFSKsWAQlFBfqf2ee7OGo6zu8NVhX7vAZCeVJK3KulX9JZAZAjvoZAEonP5Rgzix0ZAOLqKTwqOe99M4AAlVqddw4OyzivJBH7xZBNCDNC0SHH0HvZCNhaiVcQnbqOrgRv2Ky6zSxcWDdNieuD5OHyUPFfh');
define('META_API_VERSION', 'v23.0');
define('META_AD_ACCOUNT_ID', '377788737276888');
define('META_AD_ACCOUNT_IDS', ['377788737276888', '649582855745866', '187111206649694', '712717056579740', '4331648290228443']);

// ── Google Ads API ────────────────────────────────────────────────────
define('GOOGLE_CLIENT_ID', '629640904176-s96g5lqcg7c241cul2sbrhltdeju50rn.apps.googleusercontent.com');
define('GOOGLE_CLIENT_SECRET', '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');
define('GOOGLE_REFRESH_TOKEN', '1//04zL3uUd0mgkHCgYIARAAGAQSNwF-L9IrAVHYKF0ly1x_nOuIcaVMMDdDkXGgT5bH9DUya-c3PecmIQHJXHCb-59ZQ_utl_g7_XY');
define('GOOGLE_DEVELOPER_TOKEN', 'fZ6JomyDWxRMRzvL-h5KGg');
define('GOOGLE_CUSTOMER_ID', '3217466442');

// ── Ad dashboards ─────────────────────────────────────────────────────
define('DASHBOARD_TITLE', 'Performance Marketing Dashboard');
define('DATE_PRESET', 'last_30d');
define('CACHE_MINUTES', 30);
define('CACHE_SECONDS', CACHE_MINUTES * 60);
define('CACHE_SECONDS_SUMMARY', 60);
define('CACHE_FILE', CACHE_PATH . '/meta_data.json');
define('CACHE_FILE_SUMMARY', CACHE_PATH . '/meta_summary.json');
// define('MASTER_TABLES_DB', 'pseudo');   // any key from LEAD_DATABASES (default: the first)

// ── AI insights (Groq) — server-side only ─────────────────────────────
define('GROQ_API_KEY', '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');
define('GROQ_MODEL', 'llama-3.3-70b-versatile');
define('GROQ_URL', 'https://api.groq.com/openai/v1/chat/completions');

// ── Salesforce: "Send to CRM" on the CRM Push page (app/Leads/crm_send.php) ──
// Failed / not-sent Meta and Google leads can be sent again with the same details the website sends.
// Remove this block to turn the button off. Google needs its Salesforce campaign ID (701…) before it can send.
/* Send to CRM — parked for later. Uncomment, or better: Admin → CRM Settings → "Copy from config.php".
define('CRM_SFDC', [
    'token_url'     => 'https://embassygroup.my.salesforce.com/services/oauth2/token',   // client_credentials
    'client_id'     => '3MVG9ZL0ppGP5UrAIh2o_ww8zJStyG5y9IGobw7QTWK6gQZJQV8dzN5BvWckWCS4K444CUzxaO1enIIAcEJA7',
    'client_secret' => 'B5D4AF9A17B466C6386D8C75C042E744B852251BDFBECB61A2056A906097A7B2',
    // Optional second sign-in, used only if the one above fails (password grant)
    'fallback' => [
        'token_url'     => 'https://login.salesforce.com/services/oauth2/token',
        'client_id'     => '3MVG9pRzvMkjMb6k3eeHT5azSzwlzdqGM480W500E3ui2tbTLN5HwO1vDrvqlc7L07DcgkmARkfcK_3g_h4Mx',
        'client_secret' => 'F998C9BA34C36AE41909CECF4E6D31E51D1592985092392D73D9B72BCEDF1413',
        'username'      => 'integrationuser@stetig.in',
        'password'      => 'webIntegration@123O5s7naAQHzIAplJ6zEKDO3iZF',
    ],
    'lead_url' => 'https://embassygroup.my.salesforce.com/services/apexrest/Marketing/Leads/',
    'project'  => 'Embassy South Reserve',      // Project_interested
    'lead_source' => 'Digital Marketing', 'mode_of_enquiry' => 'Web', 'owner' => 'LMT Queue', 'medium' => 'Webzaa',
    'default_countrycode' => '+91',
    'meta'   => ['campaignId' => '701fv00000auLhpAAE', 'subsource' => 'Social Media', 'utm_ssc' => 'Facebook'],
    // Google: subsource / utm_ssc come from the lead (campaignsubsource / utm_ssc); these are used when the lead has none
    'google' => ['campaignId' => '', 'subsource' => 'Google', 'utm_ssc' => 'Google'],
]);
*/

// ── Scheduled report emails (cron/send_performance_reports.php) ───────
define('REPORT_MAILER_FILE', APP_PATH . '/Core/mailer.php');
define('REPORT_RECIPIENTS', [
    'meta'   => ['devops@webzaa.co.in'],
    'google' => ['devops@webzaa.co.in'],
]);
// define('REPORT_COMBINED_RECIPIENTS', ['devops@webzaa.co.in']);
define('REPORT_ADMIN_EMAIL', 'devops@webzaa.co.in');
define('REPORT_BASE_URL', APP_URL . '/ads');
define('REPORT_LINK_SECRET', '577d8a2325ac49ede69239da98200868b6893db0e051324d4b8530b7ca2d5d08');
define('REPORT_LOGO_URL', 'https://www.webzaa.in/images/webzaa-logo.png');
// define('REPORT_FROM_NAME', 'Webzaa Reports');

//Page Speed API Google API
define('PAGESPEED_API_KEY', 'AIzaSyB-jo4sO3LxXBFQUr4b9m-ihrpGZna0ASo');