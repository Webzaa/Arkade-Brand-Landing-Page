<?php
/**
 * config/config.example.php — copy to config/config.php and fill in. The ONE settings file for the whole admin.
 *
 * Every page, API, cron job and library loads this through app/bootstrap.php.
 * Contains passwords and API keys: never commit it, never put it under public/.
 * A blank copy for new servers lives in config/config.example.php.
 */

// ── App ───────────────────────────────────────────────────────────────
define('PROJECT_NAME', 'Hiranandani Belicia');
define('APP_URL', 'https://hiranandanibelicia.co/admin');   // public URL of public/ (no trailing slash)
define('APP_TIMEZONE', 'Asia/Kolkata');

// ── Databases ─────────────────────────────────────────────────────────
// Connection details (used by LEAD_DATABASES below)
define('DB1_HOST', '');
define('DB1_PORT', 3306);
define('DB1_USER', '');
define('DB1_PASS', '');
define('DB1_NAME', 'test_beliciacp');

define('DB2_HOST', '');
define('DB2_PORT', 3306);
define('DB2_USER', '');
define('DB2_PASS', '');
define('DB2_NAME', 'test_belicia');

// ── Lead databases — any number (1, 2, 5 …) ───────────────────────────
// Every database that has a `lead` table. The key (a-z, 0-9, _) is what the
// "Campaign Database" filter sends; the label is what users see.
// One entry → the filter hides itself. Add an entry → it shows up everywhere
// (Leads & CRM, exports, dashboards, reports, cron). No code changes needed.
define('LEAD_DATABASES', [
    'pseudo' => [
        'label' => 'Pseudo Campaign',
        'host'  => DB1_HOST, 'port' => DB1_PORT,
        'user'  => DB1_USER, 'pass' => DB1_PASS,
        'name'  => DB1_NAME,
    ],
    'official' => [
        'label' => 'Official Campaign',
        'host'  => DB2_HOST, 'port' => DB2_PORT,
        'user'  => DB2_USER, 'pass' => DB2_PASS,
        'name'  => DB2_NAME,
    ],
    // Example — a third database:
    // 'westgate' => [
    //     'label' => 'Westgate',
    //     'host'  => '127.0.0.1', 'port' => 3306,
    //     'user'  => '',          'pass' => '',
    //     'name'  => 'westgate_crm',
    // ],
]);
// Database that holds users, sessions and activity logs ($conn). Must be a key above.
define('APP_DB', 'pseudo');
// Optional: database the portfolio PDF report reads leads from (default: 2nd entry above, else 1st)
// define('PORTFOLIO_REPORT_DB', 'official');
// define('PORTFOLIO_INCLUDE_TABOOLA', true);   // add Taboola to the portfolio PDF (default: Meta + Google only)
// define('SHOW_TABOOLA', true);              // show Taboola in the sidebar, All Platforms and the platform switchers (hidden by default)
// define('SHOW_OTT', false);                // hide the manual platforms (OTT Video, Display, MyGate … — added and filled in on their pages)
// Google leads whose campaign is not linked to this project count as "Website / Direct" (default). false = only leads with no campaign.
// define('GOOGLE_UNMAPPED_TO_WEBSITE', false);
// Meta / Google leads not under a project campaign are counted on the dashboards (Meta: "Unmapped leads" row,
// Google: "Website / Direct"); false = leave them out. Leads with no source are never counted.
// define('DASHBOARD_COUNT_UNMAPPED', false);
// Leads = every form entry (default); true = one per person. Qualified / site visits are always one per person.
// define('DASHBOARD_LEADS_AS_PEOPLE', true);
// define('OTT_LEAD_SOURCES', ['ott', 'ott video', 'ctv']);   // campaignsource values counted as OTT leads

// ── Email (SMTP, used by login OTP and report emails) ─────────────────
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);
define('SMTP_SECURE', 'tls');
define('SMTP_USER', '');
define('SMTP_PASS', '');
define('MAIL_FROM', 'info@webzaa.co.in');
define('MAIL_FROM_NAME', 'Webzaa Admin');

// ── Google sign-in for the admin login (google_callback.php) ─────────
// Renamed from GOOGLE_CLIENT_ID/SECRET: those names now belong to the Google Ads API below.
define('GOOGLE_LOGIN_CLIENT_ID', '536569090665-2njos6bl8gdg8052co2inithaufq52rf.apps.googleusercontent.com');
define('GOOGLE_LOGIN_CLIENT_SECRET', '');
define('GOOGLE_LOGIN_REDIRECT_URI', APP_URL . '/google_callback.php');

// ── Project-specific values (change these when copying the admin to another project) ──
// Campaign names containing any of these words count as this project in the portfolio report.
define('PROJECT_CAMPAIGN_KEYWORDS', ['belicia', 'embassy', 'rustomjee', 'pseudo', 'wz']);
// Campaign name used for leads that arrived via WhatsApp.
define('META_WHATSAPP_CAMPAIGN_NAME', 'Wz Rustomjee Vista Bay Secondary Whatsapp Pseudo - 07/08/26');
// Google: CRM campaign value (lowercase) => campaign name shown in Google Ads.
define('GOOGLE_CAMPAIGN_ALIASES', [
    'location'                  => 'Belicia Location Official',
    'location_pseudo'           => 'Belicia_Pseudo_Location',
    'brand'                     => 'Belicia Brand Search',
    'brand_pseudo'              => 'Belicia_Brand_Search_Pseudo',
    'demandgen_12/09/26_pseudo' => 'Demand Gen_12/09/26_Pseudo',
]);

// ── Taboola ───────────────────────────────────────────────────────────
define('TABOOLA_CLIENT_ID', 'aeb643373af7409d9ba990195220dae4');
define('TABOOLA_CLIENT_SECRET', '');
define('TABOOLA_ACCOUNT_ID', 'ssvtechnologies-houseofhiranandani-sc');
define('TABOOLA_BASE_URL', 'https://backstage.taboola.com/backstage');

// ── Meta (Facebook) ───────────────────────────────────────────────────
define('META_PIXEL_ID', '');
define('META_ACCESS_TOKEN', '');
define('META_API_VERSION', 'v23.0');
define('META_AD_ACCOUNT_ID', '4331648290228443');
define('META_AD_ACCOUNT_IDS', ['4331648290228443', '229389882121787', '151710107069772', '353865286178083']);

// ── Google Ads API ────────────────────────────────────────────────────
define('GOOGLE_CLIENT_ID', '629640904176-s96g5lqcg7c241cul2sbrhltdeju50rn.apps.googleusercontent.com');
define('GOOGLE_CLIENT_SECRET', '');
define('GOOGLE_REFRESH_TOKEN', '');
define('GOOGLE_DEVELOPER_TOKEN', '');
define('GOOGLE_CUSTOMER_ID', '4252152384');

// ── Ad dashboards ─────────────────────────────────────────────────────
define('DASHBOARD_TITLE', 'Performance Marketing Dashboard');
define('DATE_PRESET', 'last_30d');
define('CACHE_MINUTES', 30);
define('CACHE_SECONDS', CACHE_MINUTES * 60);
define('CACHE_SECONDS_SUMMARY', 60);
define('CACHE_FILE', CACHE_PATH . '/meta_data.json');
define('CACHE_FILE_SUMMARY', CACHE_PATH . '/meta_summary.json');
// define('MASTER_TABLES_DB', 'pseudo');   // any key from LEAD_DATABASES (default: the first)

// ── AI insights (Groq) — server-side only ─────────────────────────────
define('GROQ_API_KEY', '');
define('GROQ_MODEL', 'llama-3.3-70b-versatile');
define('GROQ_URL', 'https://api.groq.com/openai/v1/chat/completions');
// Creatives & Insights + report emails: "Insights & actions" (rules; Groq above writes the wording when its key is set).
// define('REPORT_INSIGHTS', false);   // leave the Insights box out of the daily / weekly / monthly emails

// ── Salesforce (SFDC) ─────────────────────────────────────────────────
// Set it up in the admin: Admin → CRM Settings (sign-in, endpoint, fields, test, preview). Nothing needed here.
// Secrets saved there are encrypted with PQ_APP_KEY (else REPORT_LINK_SECRET). Set one long random value per
// project and never change it afterwards (changing it means entering the Salesforce secrets again).
// define('PQ_APP_KEY', 'a-long-random-string');
//
// Older way, still supported when nothing was saved in CRM Settings (CRM Settings → "Copy from config.php" moves it there):
// ── Salesforce: "Send to CRM" on the CRM Push page (app/Leads/crm_send.php) ──
// Failed / not-sent Meta and Google leads can be sent again with the same details the website sends.
// Remove this block to turn the button off. Google needs its Salesforce campaign ID (701…) before it can send.
// define('CRM_SFDC', [
//     'token_url'     => 'https://embassygroup.my.salesforce.com/services/oauth2/token',   // client_credentials
//     'client_id'     => '',
//     'client_secret' => '',
//     // Optional second sign-in, used only if the one above fails (password grant)
//     'fallback' => [
//         'token_url'     => 'https://login.salesforce.com/services/oauth2/token',
//         'client_id'     => '',
//         'client_secret' => '',
//         'username'      => '',
//         'password'      => '',
//     ],
//     'lead_url' => 'https://embassygroup.my.salesforce.com/services/apexrest/Marketing/Leads/',
//     'project'  => 'Your Project Name',      // Project_interested
//     'lead_source' => 'Digital Marketing', 'mode_of_enquiry' => 'Web', 'owner' => 'LMT Queue', 'medium' => 'Webzaa',
//     'default_countrycode' => '+91',
//     'meta'   => ['campaignId' => '', 'subsource' => 'Social Media', 'utm_ssc' => 'Facebook'],
//     // Google: subsource / utm_ssc come from the lead (campaignsubsource / utm_ssc); these are used when the lead has none
//     'google' => ['campaignId' => '', 'subsource' => 'Google', 'utm_ssc' => 'Google'],
// ]);

// ── Scheduled report emails (cron/send_performance_reports.php) ───────
define('REPORT_MAILER_FILE', APP_PATH . '/Core/mailer.php');
define('REPORT_RECIPIENTS', [
    'meta'   => ['devops@webzaa.co.in'],
    'google' => ['devops@webzaa.co.in'],
]);
// define('REPORT_COMBINED_RECIPIENTS', ['devops@webzaa.co.in']);
define('REPORT_ADMIN_EMAIL', 'devops@webzaa.co.in');
define('REPORT_BASE_URL', APP_URL . '/ads');
define('REPORT_LINK_SECRET', '');
define('REPORT_LOGO_URL', 'https://www.webzaa.in/images/webzaa-logo.png');
// define('REPORT_FROM_NAME', 'Webzaa Reports');   // default: "<PROJECT_NAME> · Webzaa"
// define('REPORT_PROJECT_NAME', 'Embassy North Yelahanka');   // name in report subjects / header (default: PROJECT_NAME)
// Login code email: 'smtp' (default — this admin's SMTP + new template, old API as fallback) or 'api' (old mailer API only)
// define('OTP_MAIL_VIA', 'smtp');
