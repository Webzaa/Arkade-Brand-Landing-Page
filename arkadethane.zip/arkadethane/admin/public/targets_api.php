<?php
/**
 * targets_api.php — Targets (plan vs achieved). Logic: app/Ads/targets.php. Permission: Targets (app/Core/access.php):
 * "View" for report / load, "Edit targets" for every POST.
 *
 *   GET  ?action=report&platform=overall|meta|google|taboola|m-<key>&since=&until=[&prorate=0|1]
 *   GET  ?action=load&period_key=2026-10 | 2026-Q4      → settings, platforms, entered values of that period
 *   POST ?action=save      {period_key, values: {platform: {target: {metric: n}, actual: {...}}}}
 *   POST ?action=settings  {period: month|quarter, prorate: bool}
 *   POST ?action=parse     multipart file=<.csv | .xlsx>  → {rows: [[cell, …], …]}  (Import on the Targets page; nothing is
 *                          saved — the page fills its boxes and the person checks them and clicks Save)
 */
ob_start();
ini_set('display_errors', '0');
session_start();
require_once dirname(__DIR__) . '/app/Ads/targets.php';

function tgReply(array $p, int $code = 200): never
{
    while (ob_get_level()) {
        ob_end_clean();
    }
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    header('X-Content-Type-Options: nosniff');
    echo json_encode($p, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}
if (($_SESSION['user_logged'] ?? '') !== 'Y') {
    tgReply(['success' => false, 'error' => 'Please sign in again.'], 401);
}
$user = (string) ($_SESSION['username'] ?? $_SESSION['user'] ?? 'user');
session_write_close();
@set_time_limit(180);

$validDate = fn($d) => is_string($d) && preg_match('/^\d{4}-\d{2}-\d{2}$/', $d) && DateTime::createFromFormat('!Y-m-d', $d) !== false;
$canEdit = !function_exists('pqCan') || pqCan('targets', 'edit');

try {
    $action = (string) ($_GET['action'] ?? '');
    $isPost = ($_SERVER['REQUEST_METHOD'] ?? '') === 'POST';
    $in = $isPost ? (array) json_decode((string) file_get_contents('php://input'), true) : [];

    if ($action === 'report') {
        $since = (string) ($_GET['since'] ?? '');
        $until = (string) ($_GET['until'] ?? '');
        if (!$validDate($since) || !$validDate($until)) {
            tgReply(['success' => false, 'error' => 'Choose a date range.'], 400);
        }
        if ($since > $until) {
            [$since, $until] = [$until, $since];
        }
        $pr = $_GET['prorate'] ?? '';
        $r = pqtReport((string) ($_GET['platform'] ?? 'overall'), $since, $until, $pr === '' ? null : $pr === '1');
        tgReply(['success' => true, 'can_edit' => $canEdit] + $r);
    }

    if ($action === 'load') {
        $db = pqtDb();
        $set = pqtSettings($db);
        $key = (string) ($_GET['period_key'] ?? '') ?: pqtPeriodKey($set['period'], date('Y-m-d'));
        [$a, $b] = pqtPeriodBounds($set['period'], $key);
        $data = pqtLoad($db, $set['period'], [$key])[$key] ?? [];
        // periods with something entered (for the picker)
        $have = [];
        $r = $db->query("SELECT DISTINCT period_key FROM `pq_targets` WHERE period_type = '" . $db->real_escape_string($set['period']) . "' ORDER BY period_key DESC LIMIT 40");
        while ($r && ($x = $r->fetch_assoc())) {
            $have[] = $x['period_key'];
        }
        $rows = [];
        foreach (PQT_ROWS as $m => [$label, $fmt, $better, $kind]) {
            $rows[] = ['key' => $m, 'label' => $label, 'format' => $fmt, 'kind' => $kind, 'manual_actual' => in_array($m, PQT_MANUAL_ACTUALS, true)];
        }
        tgReply(['success' => true, 'can_edit' => $canEdit, 'settings' => $set, 'platforms' => pqtPlatforms(),
                 'period_key' => $key, 'period_label' => pqtPeriodLabel($set['period'], $key), 'start' => $a, 'end' => $b,
                 'rows' => $rows, 'values' => (object) $data, 'periods_with_data' => $have]);
    }

    if (!$isPost) {
        tgReply(['success' => false, 'error' => 'Unknown action.'], 400);
    }
    if (!$canEdit) {
        tgReply(['success' => false, 'error' => "Your role can't change targets."], 403);
    }
    if ($action === 'save') {
        $db = pqtDb();
        $set = pqtSettings($db);
        $n = pqtSave($db, $set['period'], (string) ($in['period_key'] ?? ''), (array) ($in['values'] ?? []), $user);
        pqtClearCache();
        tgReply(['success' => true, 'saved' => $n]);
    }
    if ($action === 'parse') {
        require_once dirname(__DIR__) . '/app/Leads/status_upload.php';   // suParseFile(): CSV / XLSX reader
        $f = $_FILES['file'] ?? null;
        if (!$f || ($f['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK || !is_uploaded_file($f['tmp_name'])) {
            tgReply(['success' => false, 'error' => 'Choose a .csv or .xlsx file.'], 400);
        }
        if ($f['size'] > 2 * 1024 * 1024) {
            tgReply(['success' => false, 'error' => 'The file is larger than 2 MB — a targets sheet is much smaller. Check you picked the right file.'], 400);
        }
        try {
            $p = suParseFile($f['tmp_name'], (string) $f['name']);
        } catch (SuNeedClientConvert $e) {
            tgReply(['success' => false, 'convert' => true, 'error' => $e->getMessage()], 422);
        }
        $rows = array_slice(array_map(fn($r) => array_map(fn($c) => trim((string) $c), array_slice((array) $r, 0, 40)), $p['rows']), 0, 200);
        tgReply(['success' => true, 'rows' => $rows]);
    }
    if ($action === 'settings') {
        $db = pqtDb();
        $period = ($in['period'] ?? 'month') === 'quarter' ? 'quarter' : 'month';
        pqSettingPut($db, 'targets', ['period' => $period, 'prorate' => !empty($in['prorate'])], $user);
        tgReply(['success' => true, 'settings' => pqtSettings($db)]);
    }
    tgReply(['success' => false, 'error' => 'Unknown action.'], 400);
} catch (InvalidArgumentException $e) {
    tgReply(['success' => false, 'error' => $e->getMessage()], 400);
} catch (Throwable $e) {
    error_log('[targets_api] ' . $e->getMessage() . ' @ ' . $e->getFile() . ':' . $e->getLine());
    tgReply(['success' => false, 'error' => $e->getMessage()], 500);
}
