<?php
include dirname(__DIR__, 2) . '/app/Core/db.php';

$visitors = $conn->query("
SELECT COUNT(DISTINCT session_id) c FROM click_logs
")->fetch_assoc()['c'];

$clickers = $conn->query("
SELECT COUNT(DISTINCT session_id) c
FROM click_logs
WHERE element_name IS NOT NULL
")->fetch_assoc()['c'];

$leads = $conn->query("
SELECT COUNT(*) c FROM lead
")->fetch_assoc()['c'];

echo json_encode([
    "visitors" => $visitors,
    "clickers" => $clickers,
    "leads" => $leads
]);
