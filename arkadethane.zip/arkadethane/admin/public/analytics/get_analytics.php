<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

header('Content-Type: application/json');

include dirname(__DIR__, 2) . '/app/Core/db.php';

// ===A=== Read filter params sent from analytics.php frontend ===A===
$from_date      = isset($_GET['from_date'])      ? trim($_GET['from_date'])      : '';
$camp_source    = isset($_GET['camp_source'])     ? trim($_GET['camp_source'])     : '';
$camp_subsource = isset($_GET['camp_subsource'])  ? trim($_GET['camp_subsource'])  : '';
$keyword        = isset($_GET['keyword'])         ? trim($_GET['keyword'])         : '';
$till_date      = isset($_GET['till_date'])       ? trim($_GET['till_date'])       : '';

// ===A=== Build dynamic WHERE clause based on filters ===A===
$where = "WHERE session_id IS NOT NULL AND TRIM(session_id) <> '' AND element_name IS NOT NULL";

if ($from_date != '') {
    $dates = explode(' - ', $from_date);
    if (count($dates) == 2) {
        $d1obj = DateTime::createFromFormat('d/m/Y', trim($dates[0]));
        $d2obj = DateTime::createFromFormat('d/m/Y', trim($dates[1]));
        if ($d1obj && $d2obj) {
            $d1 = $d1obj->format('Y-m-d');
            $d2 = $d2obj->format('Y-m-d');
            if ($till_date == '1') {
                $where .= " AND DATE(created_at) <= '$d2'";
            } else {
                $where .= " AND DATE(created_at) BETWEEN '$d1' AND '$d2'";
            }
        }
    }
}
if ($camp_source != '')    $where .= " AND campaignsource = '" . $conn->real_escape_string($camp_source) . "'";
if ($camp_subsource != '') $where .= " AND campaignsubsource = '" . $conn->real_escape_string($camp_subsource) . "'";
if ($keyword != '')        $where .= " AND (element_name LIKE '%" . $conn->real_escape_string($keyword) . "%' OR page LIKE '%" . $conn->real_escape_string($keyword) . "%')";

// ===m=== Base Totals Query Started ===m===
$q = $conn->query("
    SELECT
        COUNT(DISTINCT session_id) visitors,
        COUNT(*) clicks,
        COUNT(DISTINCT CASE WHEN lead_id IS NOT NULL THEN session_id END) converted_sessions,
        SUM(CASE WHEN lead_id IS NOT NULL THEN 1 ELSE 0 END) converted_clicks
    FROM click_logs
    $where
");

$tot = $q->fetch_assoc();

$visitors         = (int)$tot["visitors"];
$clicks           = (int)$tot["clicks"];
$converted        = (int)$tot["converted_sessions"];
$converted_clicks = (int)$tot["converted_clicks"];
// ===m=== Base Totals Query Ended ===m===

// ===m=== Avg Time Spent Started ===m===
$tq = $conn->query("SELECT AVG(max_time) as avg_time FROM (
    SELECT MAX(time_spent) as max_time
    FROM click_logs
    WHERE event_type = 'time_spent'
    AND time_spent IS NOT NULL
    AND time_spent > 0
    GROUP BY session_id
) as session_times");
$trow = $tq->fetch_assoc();
$avg_time_spent = $trow['avg_time'] ? round($trow['avg_time']) : 0;
// ===m=== Avg Time Spent Ended ===m===

// ===m=== Total Leads Started ===m===
$leadWhere = "WHERE 1=1";
if ($from_date != '') {
    $dates = explode(' - ', $from_date);
    if (count($dates) == 2) {
        $d1obj = DateTime::createFromFormat('d/m/Y', trim($dates[0]));
        $d2obj = DateTime::createFromFormat('d/m/Y', trim($dates[1]));
        if ($d1obj && $d2obj) {
            $d1 = $d1obj->format('Y-m-d');
            $d2 = $d2obj->format('Y-m-d');
            if ($till_date == '1') {
                $leadWhere .= " AND DATE(createddate) <= '$d2'";
            } else {
                $leadWhere .= " AND DATE(createddate) BETWEEN '$d1' AND '$d2'";
            }
        }
    }
}
if ($camp_source != '')    $leadWhere .= " AND campaignsource = '" . $conn->real_escape_string($camp_source) . "'";
if ($camp_subsource != '') $leadWhere .= " AND campaignsubsource = '" . $conn->real_escape_string($camp_subsource) . "'";

$row = $conn->query("SELECT COUNT(*) c FROM `lead` $leadWhere")->fetch_assoc();
$leads = (int)$row["c"];
// ===m=== Total Leads Ended ===m===

// ===m=== Bounce Rate Calculation Started ===m===
$bq = $conn->query("SELECT COUNT(*) as bounced FROM (
        SELECT session_id
        FROM click_logs
        $where
        GROUP BY session_id
        HAVING COALESCE(MAX(CASE WHEN event_type = 'time_spent' THEN time_spent END), 0) <= 5
    ) as temp
");
$brow = $bq->fetch_assoc();
$bounced_sessions = (int)$brow['bounced'];
$bounce_rate = $visitors > 0 ? round(($bounced_sessions / $visitors) * 100, 2) : 0;
// ===m=== Bounce Rate Calculation Ended ===m===

// ===m=== KPI Metrics Calculation Started ===m===
$avg_clicks       = $visitors ? round($clicks / $visitors, 2) : 0;
$avg_conv_clicks  = $converted ? round($clicks / $converted, 2) : 0;

$visitor_to_click = $visitors ? round($clicks / $visitors, 2) : 0;
$click_to_lead    = $clicks ? round(($leads / $clicks) * 100, 2) : 0;
$visitor_to_lead  = $visitors ? round(($converted / $visitors) * 100, 2) : 0;
// ===m=== KPI Metrics Calculation Ended ===m===

// ===m=== Top Clicked Elements Started ===m===
$elements = [];

$q = $conn->query("SELECT element_name, COUNT(*) total FROM click_logs $where AND element_name IS NOT NULL AND TRIM(element_name) <> '' AND event_type != 'time_spent' GROUP BY element_name ORDER BY total DESC LIMIT 10");

while ($r = $q->fetch_assoc()) {
    $elements[] = [
        "element_name" => $r["element_name"],
        "total" => (int)$r["total"]
    ];
}
// ===m=== Top Clicked Elements Ended ===m===

// ===m=== Top Visited Pages Started ===m===
$pages = [];

$q = $conn->query("SELECT page, COUNT(*) total FROM click_logs $where AND page IS NOT NULL AND TRIM(page) <> '' AND event_type != 'time_spent' GROUP BY page ORDER BY total DESC  LIMIT 10");

while ($r = $q->fetch_assoc()) {
    $pages[] = [
        "page" => $r["page"],
        "total" => (int)$r["total"]
    ];
}
// ===m=== Top Visited Pages Ended ===m===

// ===m=== Session Details with Lead Info Started ===m===
$sessions = [];

$q = $conn->query("SELECT 
    c.session_id,
    SUM(CASE WHEN c.event_type != 'time_spent' THEN 1 ELSE 0 END) clicks,
    MAX(c.created_at) last_activity,
    MAX(c.lead_id) lead_id,
    MAX(l.name) lead_name,
    MAX(NULLIF(TRIM(c.campaignsource),'')) source,
    MAX(NULLIF(TRIM(c.campaignsubsource),'')) subsource,
    MAX(c.time_spent) as session_duration
FROM click_logs c
LEFT JOIN `lead` l ON l.id = c.lead_id
$where
GROUP BY c.session_id
ORDER BY last_activity DESC
LIMIT 100
");

while ($r = $q->fetch_assoc()) {
    $sessions[] = [
        "session_id" => $r["session_id"],
        "clicks"     => (int)$r["clicks"],
        "lead_id"    => $r["lead_id"] ?: null,
        "lead_name"  => $r["lead_name"] ?: null,
        "source"     => $r["source"] ?: "Website",
        "subsource"  => $r["subsource"] ?: "LP",
        "last_activity" => $r["last_activity"],
        "session_duration" => $r["session_duration"] ? (int)$r["session_duration"] : null
    ];
}
// ===m=== Session Details with Lead Info Ended ===m===

// ===m=== OS Stats with Model Detection Started ===m===
$osStats = [];

$q = $conn->query("
SELECT 
COALESCE(NULLIF(TRIM(os),''),'Unknown') os,
COUNT(*) total,
COUNT(DISTINCT session_id) users
FROM click_logs
$where
GROUP BY os
ORDER BY total DESC
");

while ($r = $q->fetch_assoc()) {
    $osStats[] = [
        "os"     => $r["os"],
        "clicks" => (int)$r["total"],
        "users"  => (int)$r["users"]
    ];
}
// ===m=== OS Stats with Model Detection Ended ===m===

// ===m=== Device Stats Started ===m===
$deviceStats = [];

$q = $conn->query("
SELECT 
COALESCE(NULLIF(TRIM(device),''),'Unknown') device,
COUNT(*) total,
COUNT(DISTINCT session_id) users
FROM click_logs
$where
GROUP BY device
ORDER BY total DESC
");

while ($r = $q->fetch_assoc()) {
    $deviceStats[] = [
        "device" => $r["device"],
        "clicks" => (int)$r["total"],
        "users"  => (int)$r["users"]
    ];
}
// ===m=== Device Stats Ended ===m===

// ===m=== Converted Leads Timeline Data Preparation Started ===m===
$converted_timeline = ['categories' => [], 'data' => [], 'clicks' => []];

$timelineWhere = "WHERE 1=1";
if ($from_date != '') {
    $dates = explode(' - ', $from_date);
    if (count($dates) == 2) {
        $d1obj = DateTime::createFromFormat('d/m/Y', trim($dates[0]));
        $d2obj = DateTime::createFromFormat('d/m/Y', trim($dates[1]));
        if ($d1obj && $d2obj) {
            $d1 = $d1obj->format('Y-m-d');
            $d2 = $d2obj->format('Y-m-d');
            if ($till_date == '1') {
                $timelineWhere .= " AND DATE(created_at) BETWEEN CURDATE() - INTERVAL 6 DAY AND '$d2'";
            } else {
                $timelineWhere .= " AND DATE(created_at) BETWEEN '$d1' AND '$d2'";
            }
        }
    }
} else {
    $timelineWhere .= " AND DATE(created_at) >= CURDATE() - INTERVAL 6 DAY";
}
if ($camp_source != '')    $timelineWhere .= " AND campaignsource = '" . $conn->real_escape_string($camp_source) . "'";
if ($camp_subsource != '') $timelineWhere .= " AND campaignsubsource = '" . $conn->real_escape_string($camp_subsource) . "'";

$q = $conn->query("
    SELECT
        DATE(created_at) AS lead_date,
        COUNT(DISTINCT CASE WHEN lead_id IS NOT NULL THEN session_id END) AS total,
        COUNT(*) AS clicks
    FROM click_logs
    $timelineWhere
    GROUP BY DATE(created_at)
    ORDER BY lead_date ASC
");

while ($r = $q->fetch_assoc()) {
    $converted_timeline['categories'][] = date('d M', strtotime($r['lead_date']));
    $converted_timeline['data'][]        = (int)$r['total'];
    $converted_timeline['clicks'][]      = (int)$r['clicks'];
}
// ===m=== Converted Leads Timeline Data Preparation Ended ===m===

// ===m=== Output all analytics data as JSON ===m===
echo json_encode([
    "visitors"           => $visitors,
    "clicks"             => $clicks,
    "leads"              => $leads,
    "avg_clicks"         => $avg_clicks,
    "avg_conv_clicks"    => $avg_conv_clicks,
    "converted_sessions" => $converted,
    "converted_clicks"   => $converted_clicks,
    "visitor_to_click"   => $visitor_to_click,
    "click_to_lead"      => $click_to_lead,
    "visitor_to_lead"    => $visitor_to_lead,
    "elements"           => $elements,
    "pages"              => $pages,
    "sessions"           => $sessions,
    "os"                 => $osStats,
    "devices"            => $deviceStats,
    "converted_timeline" => $converted_timeline,
    "avg_time_spent" => $avg_time_spent,
    "bounce_rate" => $bounce_rate . '%',
], JSON_PRETTY_PRINT);
