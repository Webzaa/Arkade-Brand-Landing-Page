<?php
include dirname(__DIR__, 2) . '/app/Core/db.php';

// ===A=== Read filter params sent from analytics.php frontend ===A===
$from_date      = isset($_GET['from_date'])      ? trim($_GET['from_date'])      : '';
$camp_source    = isset($_GET['camp_source'])     ? trim($_GET['camp_source'])     : '';
$camp_subsource = isset($_GET['camp_subsource'])  ? trim($_GET['camp_subsource'])  : '';
$keyword        = isset($_GET['keyword'])         ? trim($_GET['keyword'])         : '';
$till_date      = isset($_GET['till_date'])       ? trim($_GET['till_date'])       : '';

// ===A=== Build dynamic WHERE clause based on filters ===A===
$where = "WHERE element_name != ''";

if ($from_date != '') {
    $dates = explode(' - ', $from_date);
    if (count($dates) == 2) {
        // ===A=== FIXED: correct date parsing for DD/MM/YYYY format from daterangepicker ===A===
        $d1obj = DateTime::createFromFormat('d/m/Y', trim($dates[0]));
        $d2obj = DateTime::createFromFormat('d/m/Y', trim($dates[1]));
        if ($d1obj && $d2obj) {
            $d1 = $d1obj->format('Y-m-d');
            $d2 = $d2obj->format('Y-m-d');
            if ($till_date == '1') {
                $where .= " AND DATE(created_at) <= '$d2'";
            } else {
                $where .= " AND DATE(created_at) BETWEEN '$d1' AND '$d2'";
            }
        }
    }
}
if ($camp_source != '')    $where .= " AND campaignsource = '" . $conn->real_escape_string($camp_source) . "'";
if ($camp_subsource != '') $where .= " AND campaignsubsource = '" . $conn->real_escape_string($camp_subsource) . "'";
if ($keyword != '')        $where .= " AND element_name LIKE '%" . $conn->real_escape_string($keyword) . "%'";

$data = [];

$q = $conn->query("SELECT element_name, COUNT(*) clicks, COUNT(DISTINCT session_id) users FROM click_logs $where AND event_type != 'time_spent' GROUP BY element_name ORDER BY clicks DESC LIMIT 50");

while ($r = $q->fetch_assoc())
    $data[] = $r;

echo json_encode($data);