<?php
include dirname(__DIR__, 2) . '/app/Core/db.php';

$session = $_POST['session'] ?? '';

/* GET SESSION CLICKS */

$clicks = [];
$q = $conn->prepare("SELECT element_name,page,created_at,lead_id FROM click_logs WHERE session_id=? AND  element_name is not null AND event_type != 'time_spent' ORDER BY id ASC");

$q->bind_param("s", $session);
$q->execute();
$res = $q->get_result();

$lead_id = null;

while ($row = $res->fetch_assoc()) {
    $clicks[] = $row;
    if ($row['lead_id'] != '') {
        $lead_id = $row['lead_id'];
    }
}

/* IF LEAD EXISTS → GET NAME */

$leadName = null;

if ($lead_id) {
    $l = $conn->query("SELECT name FROM `lead` WHERE id='$lead_id'");
    if ($l->num_rows) {
        $leadName = $l->fetch_assoc()['name'];
    }
}

echo json_encode([
    "session" => $session,
    "lead" => $leadName,
    "clicks" => $clicks
]);
