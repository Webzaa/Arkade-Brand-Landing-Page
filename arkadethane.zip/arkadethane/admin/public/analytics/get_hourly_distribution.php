<?php
session_start();
include dirname(__DIR__, 2) . '/app/Core/db.php';

// ===m=== Optional access control check for logged-in users
// if (!isset($_SESSION["user_logged"])) {
//     http_response_code(403);
//     exit(json_encode(["error" => "Unauthorized"]));
// }

// ===A=== Read filter params sent from analytics.php frontend ===A===
$from_date      = isset($_GET['from_date'])      ? trim($_GET['from_date'])      : '';
$camp_source    = isset($_GET['camp_source'])     ? trim($_GET['camp_source'])     : '';
$camp_subsource = isset($_GET['camp_subsource'])  ? trim($_GET['camp_subsource'])  : '';
$till_date      = isset($_GET['till_date'])       ? trim($_GET['till_date'])       : '';

// ===A=== Build dynamic date WHERE — default last 7 days, overridden if filter set ===A===
$dateWhere = "created_at >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)";

if ($from_date != '') {
    $dates = explode(' - ', $from_date);
    if (count($dates) == 2) {
        // ===A=== FIXED: correct date parsing for DD/MM/YYYY format from daterangepicker ===A===
        $d1obj = DateTime::createFromFormat('d/m/Y', trim($dates[0]));
        $d2obj = DateTime::createFromFormat('d/m/Y', trim($dates[1]));
        if ($d1obj && $d2obj) {
            $d1 = $d1obj->format('Y-m-d');
            $d2 = $d2obj->format('Y-m-d');
            if ($till_date == '1') {
                $dateWhere = "DATE(created_at) <= '$d2'";
            } else {
                $dateWhere = "DATE(created_at) BETWEEN '$d1' AND '$d2'";
            }
        }
    }
}

// ===A=== Extra filters for source/subsource ===A===
$extraWhere = "";
if ($camp_source != '')    $extraWhere .= " AND campaignsource = '" . $conn->real_escape_string($camp_source) . "'";
if ($camp_subsource != '') $extraWhere .= " AND campaignsubsource = '" . $conn->real_escape_string($camp_subsource) . "'";

// ===m=== Filling grid with 0 first then overriding with actual counts to ensure all intervals/days are represented, even if zero ===m===
$heatmapData = [];
// ===m=== for days 0-6 [Mon-Sun] and intervals 0-5 [4-hour blocks] ===m===
for ($y = 0; $y < 7; $y++) {
    for ($x = 0; $x < 6; $x++) {
        $heatmapData["$x-$y"] = [$x, $y, 0];
    }
}

// ===m=== WEEKDAY(): 0=Mon, 6=Sun | FLOOR(HOUR/4): splits day into 6 intervals ===m===
$sql = "SELECT FLOOR(HOUR(created_at) / 4) AS interval_idx, WEEKDAY(created_at) AS day_idx, COUNT(DISTINCT session_id) AS visitors
        FROM click_logs
        WHERE $dateWhere $extraWhere
        GROUP BY interval_idx, day_idx
";

$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $x = (int)$row['interval_idx'];
        $y = (int)$row['day_idx'];
        $val = (int)$row['visitors'];

        // ===m=== Overwrite zero with actual visitor count ===m===
        $heatmapData["$x-$y"] = [$x, $y, $val];
    }
}

// ===m=== Return JSON array format required by Highcharts: [[x, y, value], [x, y, value]...] ===m===
echo json_encode(array_values($heatmapData));