<?php
/**
 * unmapped_leads_api.php — backend of unmapped_leads.php (Meta + Google unmapped leads).
 *
 *   GET  ?action=list&since=&until=&search=   → unmapped leads (one row per person + platform), counts, unlinked campaigns
 *   GET  ?action=counts                       → all-time counts (dashboard badges)
 *   GET  ?action=structure&platform=meta|google → saved campaigns → ad sets / groups → ads
 *   POST ?action=map     {platform, lead_ids[], campaign_id, group_id, ad_id}
 *   POST ?action=status  {lead_ids[], status: TEST|JUNK}
 *   POST ?action=import  {rows[], write: bool}   (dry run first, then write)
 * Logic: app/Leads/unmapped.php
 */
session_start();
header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');
require_once dirname(__DIR__) . '/app/Leads/unmapped.php';

function umReply(array $p, int $code = 200): never
{
    http_response_code($code);
    echo json_encode($p, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}
if (($_SESSION['user_logged'] ?? '') !== 'Y') {
    umReply(['success' => false, 'error' => 'Please sign in again.'], 401);
}
$user = (string) ($_SESSION['username'] ?? $_SESSION['user'] ?? 'user');
session_write_close();
@set_time_limit(180);

$action = (string) ($_GET['action'] ?? '');
$isPost = ($_SERVER['REQUEST_METHOD'] ?? '') === 'POST';
$in = $isPost ? (json_decode((string) file_get_contents('php://input'), true) ?: []) : [];
$dbKey = (string) ($in['db'] ?? $_GET['db'] ?? appDbKey());
if (!in_array($dbKey, leadDbKeys(), true)) {
    umReply(['success' => false, 'error' => 'Unknown database.'], 400);
}
$db = leadDb($dbKey);
if (!$db) {
    umReply(['success' => false, 'error' => leadDbLabel($dbKey) . ' database is not reachable.'], 500);
}
$date = fn($v) => (is_string($v) && preg_match('/^\d{4}-\d{2}-\d{2}$/', $v)) ? $v : '';

try {
    if ($action === 'list') {
        $r = umList($db, ['since' => $date($_GET['since'] ?? ''), 'until' => $date($_GET['until'] ?? ''), 'search' => (string) ($_GET['search'] ?? '')]);
        $linked = ['meta' => projectStructure('meta')['count'], 'google' => projectStructure('google')['count']];
        $r['rows'] = pqContactRows($r['rows']);      // Users & Roles: full mobile / email on screen and in the CSV, separately
        umReply(['success' => true, 'db_label' => leadDbLabel($dbKey), 'linked' => $linked] + $r);
    }
    if ($action === 'counts') {
        $r = umList($db, []);
        umReply(['success' => true, 'counts' => $r['counts']]);
    }
    if ($action === 'structure') {
        $p = (string) ($_GET['platform'] ?? '');
        if (!in_array($p, ['meta', 'google'], true)) {
            umReply(['success' => false, 'error' => 'Unknown platform.'], 400);
        }
        umReply(['success' => true, 'platform' => $p, 'campaigns' => umStructure($p)]);
    }
    if ($action === 'map' && $isPost) {
        $p = (string) ($in['platform'] ?? '');
        if (!in_array($p, ['meta', 'google'], true)) {
            umReply(['success' => false, 'error' => 'Choose Meta or Google.'], 400);
        }
        $choice = umResolveChoice($p, (string) ($in['campaign_id'] ?? ''), (string) ($in['group_id'] ?? ''), (string) ($in['ad_id'] ?? ''));
        $n = umMap($db, $p, (array) ($in['lead_ids'] ?? []), $choice);
        umLog($user, 'map', ['db' => $dbKey, 'platform' => $p, 'lead_ids' => array_map('intval', (array) $in['lead_ids'])] + $choice);
        umReply(['success' => true, 'updated' => $n, 'choice' => $choice]);
    }
    if ($action === 'status' && $isPost) {
        $st = strtoupper((string) ($in['status'] ?? ''));
        $n = umMarkStatus($db, (array) ($in['lead_ids'] ?? []), $st);
        umLog($user, 'status', ['db' => $dbKey, 'status' => $st, 'lead_ids' => array_map('intval', (array) $in['lead_ids'])]);
        umReply(['success' => true, 'updated' => $n]);
    }
    if ($action === 'import' && $isPost) {
        $rows = array_slice((array) ($in['rows'] ?? []), 0, 5000);
        if (!$rows) {
            umReply(['success' => false, 'error' => 'The file has no rows.'], 400);
        }
        $write = !empty($in['write']);
        $r = umImport($db, $rows, $write);
        if ($write) {
            umLog($user, 'import', ['db' => $dbKey, 'rows' => count($rows), 'written' => $r['written']]);
        }
        umReply(['success' => true, 'written' => $write] + $r);
    }
    umReply(['success' => false, 'error' => 'Unknown action.'], 400);
} catch (InvalidArgumentException $e) {
    umReply(['success' => false, 'error' => $e->getMessage()], 400);
} catch (Throwable $e) {
    error_log('[unmapped_leads_api] ' . $e->getMessage());
    umReply(['success' => false, 'error' => $e->getMessage()], 500);
}
