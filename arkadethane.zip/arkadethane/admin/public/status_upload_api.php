<?php
/**
 * status_upload_api.php — backend of status_upload.php ("Upload Lead Status": CPQL / CPSV data).
 *
 *   POST ?action=parse      multipart file (+ db)            → token, headers, sample, guesses
 *   POST ?action=values     {token, status_col, sitevisit_col, platform_col} → distinct values per column + allowed values
 *   POST ?action=idtest     {token, db, id_type, id_col}      → how many file rows find a lead with that ID
 *   POST ?action=preview    {token, db, mapping…}            → every change, nothing written
 *   POST ?action=commit     {token, db, mapping…, hash, send_capi} → writes the previewed changes, logs them;
 *                           send_capi = also send new Qualified / Site visit of Meta leads to Meta CAPI (app/Leads/meta_capi_send.php)
 *   GET  ?action=check&db=…                                   → can an upload run? (folder, database, columns…)
 *   GET  ?action=history&db=…                                 → recent uploads
 *   POST ?action=undo       {db, upload_id}                    → puts the old values back
 *   POST ?action=capi_retry {db, upload_id}                    → sends the Meta CAPI events of that upload that Meta did not take
 *
 * Missing leads (rows of the file that are not in the lead table) — app/Leads/missing_leads.php:
 *   POST ?action=missing         {token, db, mapping…}            → editable drafts of the not-found rows + campaign sources
 *   POST ?action=missing_parse   multipart file                   → drafts from a saved missing-leads CSV / XLSX
 *   POST ?action=missing_insert  {target_db, rows, file_name, check?} → check (check = true) or add them as new leads
 *   GET  ?action=missing_history&target_db=…                      → recent "add missing leads" imports
 *   POST ?action=missing_undo    {target_db, import_id}           → deletes the leads of that import again
 *   commit also returns 'missing' (the drafts), because the upload is removed from the server after it.
 * Users & Roles → Upload Lead Status → "Add missing leads" for missing_insert / missing_undo.
 * db = a LEAD_DATABASES key, or "all" (every database: each row is matched everywhere, rows found in several databases
 * are split by the file's campaign column — app/Leads/status_upload_multi.php). Undo / capi_retry always name one database.
 */
session_start();
header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');

require_once dirname(__DIR__) . '/app/Leads/status_upload.php';
require_once dirname(__DIR__) . '/app/Leads/status_upload_multi.php';
require_once dirname(__DIR__) . '/app/Leads/meta_capi_send.php';
require_once dirname(__DIR__) . '/app/Leads/missing_leads.php';

function suReply(array $p, int $code = 200): never
{
    http_response_code($code);
    echo json_encode($p, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

if (($_SESSION['user_logged'] ?? '') !== 'Y') {
    suReply(['success' => false, 'error' => 'Please sign in again.'], 401);
}
$user = (string) ($_SESSION['username'] ?? $_SESSION['user'] ?? 'user');
session_write_close();
@set_time_limit(300);
@ini_set('memory_limit', '512M');

$action = (string) ($_GET['action'] ?? '');
$isPost = ($_SERVER['REQUEST_METHOD'] ?? '') === 'POST';
$in = [];
if ($isPost && str_contains((string) ($_SERVER['CONTENT_TYPE'] ?? ''), 'application/json')) {
    $in = json_decode((string) file_get_contents('php://input'), true) ?: [];
}

$dbKey = (string) ($in['db'] ?? $_POST['db'] ?? $_GET['db'] ?? appDbKey());
$isAll = $dbKey === SU_ALL && count(leadDbKeys()) > 1;
if (!$isAll && !in_array($dbKey, leadDbKeys(), true)) {
    suReply(['success' => false, 'error' => $dbKey === SU_ALL ? 'Only one database is set up — choose it.' : 'Unknown database.'], 400);
}
$dbLabel = $isAll ? 'All databases' : leadDbLabel($dbKey);
// "all" only for matching and saving; undo / Meta retry belong to one database
if ($isAll && in_array($action ?? ($_GET['action'] ?? ''), ['undo', 'capi_retry'], true)) {
    suReply(['success' => false, 'error' => 'Choose the database of that upload.'], 400);
}
$getDb = function () use ($dbKey, $isAll): mysqli {
    $db = leadDb($isAll ? appDbKey() : $dbKey);
    if (!$db) {
        suReply(['success' => false, 'error' => leadDbLabel($dbKey) . ' database is not reachable.'], 500);
    }
    return $db;
};

try {
    if ($action === 'parse' && $isPost) {
        $f = $_FILES['file'] ?? null;
        if (!$f || ($f['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
            $err = (int) ($f['error'] ?? UPLOAD_ERR_NO_FILE);
            $msg = in_array($err, [UPLOAD_ERR_INI_SIZE, UPLOAD_ERR_FORM_SIZE], true)
                ? 'The file is larger than this server allows (upload_max_filesize ' . ini_get('upload_max_filesize') . ').'
                : 'No file received.';
            suReply(['success' => false, 'error' => $msg], 400);
        }
        // .xls converted to CSV in the browser keeps its original name for the log
        $name = (string) ($_POST['original_name'] ?? $f['name']);
        try {
            $parsed = suParseFile($f['tmp_name'], (string) $f['name']);
        } catch (SuNeedClientConvert $e) {
            suReply(['success' => false, 'need_client_convert' => true, 'error' => $e->getMessage()], 415);
        }
        [$headers, $data] = suSplitHeader($parsed['rows']);
        if (!$data) {
            suReply(['success' => false, 'error' => 'The file has headers but no data rows.'], 400);
        }
        $token = suSaveUpload(['file_name' => $name, 'sheet' => $parsed['sheet'], 'headers' => $headers, 'data' => $data, 'at' => time()]);

        // every lead column that can be matched on, with how many leads have a value (step 2)
        $db = $getDb();
        $idCols = suIdColumns($db);
        $stats = [];
        $totalAll = 0;
        foreach ($isAll ? suAllDbs() : [$dbKey => $db] as $k => $one) {
            foreach ($k === ($isAll ? appDbKey() : $dbKey) ? $idCols : suIdColumns($one) as $c) {
                $stats[$c['column']] = ($stats[$c['column']] ?? 0) + $c['filled'];
            }
            $r = $one->query('SELECT COUNT(*) AS n FROM `lead`');
            $totalAll += (int) ($r ? $r->fetch_assoc()['n'] : 0);
        }
        foreach ($idCols as &$c) {
            $c['filled'] = $stats[$c['column']] ?? $c['filled'];
        }
        unset($c);
        $stats['total'] = $totalAll;
        // file column that looks like each lead column (same name), on top of the usual guesses
        $guess = suGuessColumns($headers);
        foreach ($idCols as $c) {
            if (!array_key_exists($c['column'], $guess)) {
                foreach ($headers as $i => $h) {
                    if (str_replace(' ', '', suNorm($h)) === str_replace('_', '', strtolower($c['column']))) {
                        $guess[$c['column']] = $i;
                        break;
                    }
                }
            }
        }

        suReply([
            'success' => true,
            'token' => $token,
            'file_name' => $name,
            'sheet' => $parsed['sheet'],
            'headers' => $headers,
            'rows' => count($data),
            // mobile columns: last 5 digits only, unless this user may see full mobiles (Users & Roles)
            'sample' => array_map(function ($r) use ($headers) {
                $cells = $r['cells'];
                foreach ($headers as $i => $h) {
                    if (isset($cells[$i]) && preg_match('/mobile|phone|whatsapp|contact.?(no|num)/i', (string) $h) && function_exists('pqContact')) {
                        $cells[$i] = pqContact($cells[$i], 'mobile');
                    }
                }
                return $cells;
            }, array_slice($data, 0, 5)),
            'guess' => $guess,
            'db_stats' => $stats,
            'id_columns' => $idCols,
            'db_label' => $dbLabel,
        ]);
    }

    if ($action === 'values' && $isPost) {
        $up = suLoadUpload((string) ($in['token'] ?? ''));
        $out = [];
        foreach (array_keys(SU_FIELDS) as $field) {
            $k = $field . '_col';
            if (isset($in[$k]) && $in[$k] !== '' && $in[$k] !== null && (int) $in[$k] >= 0 && (int) $in[$k] < count($up['headers'])) {
                $out[$field] = suDistinct($up['data'], (int) $in[$k], $field);
            }
        }
        $fields = [];
        foreach (SU_FIELDS as $f => $d) {
            $fields[$f] = ['label' => $d['label'], 'column' => $d['column'], 'options' => $d['options'], 'counts' => $d['counts']];
        }
        suReply(['success' => true, 'values' => $out, 'fields' => $fields]);
    }

    if ($action === 'idtest' && $isPost) {
        // step 3: how many rows of the file find a lead with this ID choice
        $up = suLoadUpload((string) ($in['token'] ?? ''));
        $col = (int) ($in['id_col'] ?? -1);
        if ($col < 0 || $col >= count($up['headers'])) {
            suReply(['success' => false, 'error' => 'Choose the file column first.'], 400);
        }
        $db = $getDb();
        $idType = suCheckIdColumn($db, (string) ($in['id_type'] ?? ''));
        suReply(['success' => true, 'id_type' => $idType, 'label' => suIdLabel($idType)]
            + ($isAll ? suIdTestAll(suAllDbs(), $up, $idType, $col) : suIdTest($db, $up, $idType, $col)));
    }

    // ── missing leads ──
    $mlTarget = function () use ($in): array {
        $k = (string) ($in['target_db'] ?? $_GET['target_db'] ?? (count(leadDbKeys()) === 1 ? leadDbKeys()[0] : ''));
        if (!in_array($k, leadDbKeys(), true)) {
            suReply(['success' => false, 'error' => 'Choose the database to add the leads to.'], 400);
        }
        $db = leadDb($k);
        if (!$db) {
            suReply(['success' => false, 'error' => leadDbLabel($k) . ' database is not reachable.'], 500);
        }
        return [$k, $db];
    };
    $mlMeta = function (?mysqli $db): array {
        $dbs = [];
        foreach (leadDbKeys() as $k) {
            $dbs[] = ['key' => $k, 'label' => leadDbLabel($k)];
        }
        $src = [];
        try {
            $src = ml_sources($db ?? leadDb(appDbKey()));
        } catch (Throwable $e) {
            $src = ['Google', 'Facebook Lead Form'];
        }
        return ['databases' => $dbs, 'sources' => $src, 'fields' => array_map(fn($f) => $f[0], ML_FIELDS),
                'status_values' => array_values(array_filter(ML_STATUS)), 'sitevisit_values' => array_values(array_filter(ML_SITEVISIT)),
                'can_insert' => !function_exists('pqCan') || pqCan('status', 'insert')];
    };
    if ($action === 'missing' && $isPost) {
        $up = suLoadUpload((string) ($in['token'] ?? ''));
        $cfg = suConfig($in, $up['headers']);
        if ($isAll) {
            $cc = $in['campaign_col'] ?? null;
            $cfg['campaign_col'] = ($cc === null || $cc === '' || (int) $cc < 0 || (int) $cc >= count($up['headers'])) ? null : (int) $cc;
            $cfg['multi_db'] = ($in['multi_db'] ?? 'all') === 'skip' ? 'skip' : 'all';
            $items = suPlanAll(suAllDbs(), $up, $cfg)['items'];
        } else {
            $items = suPlan($getDb(), $up, $cfg)['items'];
        }
        $rows = ml_assign_dbs(ml_from_upload($items, $up, $cfg), $isAll ? appDbKey() : $dbKey);
        suReply(['success' => true, 'rows' => $rows, 'file_name' => (string) ($up['file_name'] ?? ''), 'id_type' => $cfg['id_type'],
                 'default_db' => $isAll ? appDbKey() : $dbKey] + $mlMeta($isAll ? null : $getDb()));
    }
    if ($action === 'missing_parse' && $isPost) {
        $f = $_FILES['file'] ?? null;
        if (!$f || ($f['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
            suReply(['success' => false, 'error' => 'No file received.'], 400);
        }
        try {
            $rows = ml_parse_file($f['tmp_name'], (string) $f['name']);
        } catch (SuNeedClientConvert $e) {
            suReply(['success' => false, 'need_client_convert' => true, 'error' => $e->getMessage()], 415);
        }
        $rows = ml_assign_dbs($rows, appDbKey());
        suReply(['success' => true, 'rows' => $rows, 'file_name' => (string) ($_POST['original_name'] ?? $f['name']),
                 'default_db' => appDbKey()] + $mlMeta(null));
    }
    if ($action === 'missing_insert' && $isPost) {
        [$k, $db] = $mlTarget();
        $res = ml_insert($db, (array) ($in['rows'] ?? []), $user, (string) ($in['file_name'] ?? ''), !empty($in['check']));
        if ($res['added'] > 0) {
            require_once dirname(__DIR__) . '/app/Ads/master_tables.php';
            masterClearDashboardCache();
        }
        suReply(['success' => true, 'db_label' => leadDbLabel($k)] + $res);
    }
    if ($action === 'missing_history') {
        $out = [];
        foreach (leadDbKeys() as $k) {
            $db = leadDb($k);
            if (!$db) {
                continue;
            }
            foreach (ml_history($db) as $h) {
                $out[] = $h + ['db' => $k, 'db_label' => leadDbLabel($k)];
            }
        }
        usort($out, fn($a, $b) => strcmp($b['at'], $a['at']));
        suReply(['success' => true, 'imports' => array_slice($out, 0, 15)]);
    }
    if ($action === 'missing_undo' && $isPost) {
        [$k, $db] = $mlTarget();
        $res = ml_undo($db, (int) ($in['import_id'] ?? 0));
        require_once dirname(__DIR__) . '/app/Ads/master_tables.php';
        masterClearDashboardCache();
        suReply(['success' => true] + $res);
    }

    if (($action === 'preview' || $action === 'commit') && $isPost && $isAll) {
        $up = suLoadUpload((string) ($in['token'] ?? ''));
        $cfg = suConfig($in, $up['headers']);
        $cc = $in['campaign_col'] ?? null;
        $cfg['campaign_col'] = ($cc === null || $cc === '' || (int) $cc < 0 || (int) $cc >= count($up['headers'])) ? null : (int) $cc;
        $cfg['multi_db'] = ($in['multi_db'] ?? 'all') === 'skip' ? 'skip' : 'all';
        $dbs = suAllDbs();
        $all = suPlanAll($dbs, $up, $cfg);
        // Meta Conversions API per database
        $capiS = null;
        $capiInfo = ['problem' => 'not checked', 'events' => 0];
        $capiEv = [];
        try {
            $capiS = capiSettings();
            $by = ['qualified' => 0, 'sitevisit' => 0];
            $skip = ['not_meta' => 0, 'test' => 0, 'already_sent' => 0, 'no_contact' => 0];
            foreach ($dbs as $k => $one) {
                $c = capiFromChanges($one, $all['plans'][$k]['changes'], $capiS);
                $capiEv[$k] = $c['events'];
                foreach ($c['by_stage'] as $st => $n) { $by[$st] += $n; }
                foreach ($c['skipped'] as $st => $n) { $skip[$st] += $n; }
            }
            $capiInfo = ['problem' => capiProblem($capiS), 'events' => array_sum(array_map('count', $capiEv)), 'by_stage' => $by, 'skipped' => $skip,
                         'names' => $capiS['events'], 'test_mode' => trim((string) $capiS['test_event_code']) !== ''];
        } catch (Throwable $e) {
            error_log('[status_upload_api] capi: ' . $e->getMessage());
            $capiInfo = ['problem' => 'Could not check Meta CAPI: ' . $e->getMessage(), 'events' => 0];
        }
        if ($action === 'preview') {
            $items = $all['items'];
            $order = ['change' => 0, 'skipped' => 1, 'dup' => 2, 'notfound' => 3, 'blank' => 4, 'same' => 5];
            usort($items, fn($a, $b) => [$order[$a['state']] ?? 9, $a['row']] <=> [$order[$b['state']] ?? 9, $b['row']]);
            suReply(['success' => true, 'summary' => $all['summary'], 'hash' => $all['hash'], 'fields' => $all['fields'], 'all_dbs' => true,
                     'items' => array_slice($items, 0, 5000), 'items_total' => count($items), 'db_label' => $dbLabel, 'capi' => $capiInfo]);
        }
        if (!hash_equals($all['hash'], (string) ($in['hash'] ?? ''))) {
            suReply(['success' => false, 'stale' => true, 'error' => 'The leads changed since the preview (or the mapping did). Please check the preview again.'], 409);
        }
        if (!$all['summary']['leads_to_update']) {
            suReply(['success' => false, 'error' => 'Nothing to update — every matched lead already has these values.'], 400);
        }
        $ids = [];
        $capiOut = ['sent' => 0, 'failed' => 0, 'error' => '', 'by_stage' => ['qualified' => 0, 'sitevisit' => 0]];
        $capiTried = false;
        foreach ($dbs as $k => $one) {
            $p = $all['plans'][$k];
            if (!$p['changes']) {
                continue;
            }
            $p['summary'] = ['rows' => $all['summary']['rows'], 'scope' => 'all databases'] + $p['summary'];
            $ids[$k] = suCommit($one, $p, $up, $cfg, $user);
            if (!empty($in['send_capi']) && $capiS !== null && ($capiInfo['problem'] ?? 'x') === '' && !empty($capiEv[$k])) {
                $capiTried = true;
                try {
                    $r = capiSend($one, $capiEv[$k], $capiS, $user, 'upload:' . $ids[$k]);
                } catch (Throwable $e) {
                    $r = ['sent' => 0, 'failed' => count($capiEv[$k]), 'error' => $e->getMessage(), 'by_stage' => []];
                }
                $capiOut['sent'] += $r['sent'];
                $capiOut['failed'] += $r['failed'];
                $capiOut['error'] = $capiOut['error'] ?: (string) $r['error'];
                foreach ((array) $r['by_stage'] as $st => $n) { $capiOut['by_stage'][$st] = ($capiOut['by_stage'][$st] ?? 0) + $n; }
                $capiOut['retry'][] = ['db' => $k, 'upload_id' => $ids[$k], 'failed' => $r['failed']];
            }
        }
        require_once dirname(__DIR__) . '/app/Ads/master_tables.php';
        masterClearDashboardCache();
        // the file is removed from the server now: hand over its not-found rows for "Add missing leads"
        $missing = $all['summary']['not_found'] ? ml_assign_dbs(ml_from_upload($all['items'], $up, $cfg), appDbKey()) : [];
        @unlink(suTmpPath((string) $in['token']));
        suReply(['success' => true, 'upload_id' => implode(', ', array_map(fn($k, $id) => leadDbLabel($k) . ' #' . $id, array_keys($ids), $ids)),
                 'upload_ids' => $ids, 'updated' => $all['summary']['leads_to_update'], 'summary' => $all['summary'], 'capi' => $capiTried ? $capiOut : null,
                 'missing' => $missing ? ['rows' => $missing, 'file_name' => (string) ($up['file_name'] ?? ''), 'default_db' => appDbKey()] + $mlMeta(null) : null]);
    }

    if (($action === 'preview' || $action === 'commit') && $isPost) {
        $up = suLoadUpload((string) ($in['token'] ?? ''));
        $cfg = suConfig($in, $up['headers']);
        $db = $getDb();
        $plan = suPlan($db, $up, $cfg);

        // Meta Conversions API: which of these changes would be sent (Meta leads newly Qualified / with a new site visit)
        $capiInfo = ['problem' => 'not checked'];
        $capiS = null;
        try {
            $capiS = capiSettings();
            $c = capiFromChanges($db, $plan['changes'], $capiS);
            $capiInfo = ['problem' => capiProblem($capiS), 'events' => count($c['events']), 'by_stage' => $c['by_stage'], 'skipped' => $c['skipped'],
                         'names' => $capiS['events'], 'test_mode' => trim((string) $capiS['test_event_code']) !== '', '_events' => $c['events']];
        } catch (Throwable $e) {
            error_log('[status_upload_api] capi: ' . $e->getMessage());
            $capiInfo = ['problem' => 'Could not check Meta CAPI: ' . $e->getMessage(), 'events' => 0];
        }

        if ($action === 'preview') {
            unset($capiInfo['_events']);
            $items = $plan['items'];
            $order = ['change' => 0, 'dup' => 1, 'notfound' => 2, 'blank' => 3, 'same' => 4];
            usort($items, fn($a, $b) => [$order[$a['state']], $a['row']] <=> [$order[$b['state']], $b['row']]);
            suReply(['success' => true, 'summary' => $plan['summary'], 'hash' => $plan['hash'], 'fields' => $plan['fields'],
                     'items' => array_slice($items, 0, 5000), 'items_total' => count($items), 'db_label' => leadDbLabel($dbKey), 'capi' => $capiInfo]);
        }

        if (!hash_equals($plan['hash'], (string) ($in['hash'] ?? ''))) {
            suReply(['success' => false, 'stale' => true,
                     'error' => 'The leads changed since the preview (or the mapping did). Please check the preview again.'], 409);
        }
        if (!$plan['changes']) {
            suReply(['success' => false, 'error' => 'Nothing to update — every matched lead already has these values.'], 400);
        }
        $uploadId = suCommit($db, $plan, $up, $cfg, $user);
        require_once dirname(__DIR__) . '/app/Ads/master_tables.php';
        masterClearDashboardCache();   // dashboards + PDF show the new statuses straight away
        // the file is removed from the server now: hand over its not-found rows for "Add missing leads"
        $missing = $plan['summary']['not_found'] ? ml_assign_dbs(ml_from_upload($plan['items'], $up, $cfg), $dbKey) : [];
        @unlink(suTmpPath((string) $in['token']));
        // The leads are saved; Meta is a bonus — its errors are reported, never undo the upload.
        $capiOut = null;
        if (!empty($in['send_capi']) && $capiS !== null && ($capiInfo['problem'] ?? 'x') === '' && !empty($capiInfo['_events'])) {
            try {
                $capiOut = capiSend($db, $capiInfo['_events'], $capiS, $user, 'upload:' . $uploadId);
            } catch (Throwable $e) {
                error_log('[status_upload_api] capi send: ' . $e->getMessage());
                $capiOut = ['sent' => 0, 'failed' => count($capiInfo['_events']), 'error' => $e->getMessage()];
            }
        }
        suReply(['success' => true, 'upload_id' => $uploadId, 'updated' => count($plan['changes']), 'summary' => $plan['summary'], 'capi' => $capiOut,
                 'missing' => $missing ? ['rows' => $missing, 'file_name' => (string) ($up['file_name'] ?? ''), 'default_db' => $dbKey] + $mlMeta($db) : null]);
    }

    if ($action === 'check') {
        $db = null;
        try {
            $db = leadDb($dbKey);
        } catch (Throwable $e) {
            $db = null;
        }
        if ($isAll) {
            $checks = [];
            foreach (leadDbKeys() as $k) {
                $one = null;
                try {
                    $one = leadDb($k);
                } catch (Throwable $e) {
                    $one = null;
                }
                foreach (suChecks($one, leadDbLabel($k)) as $c) {
                    if ($c['key'] === 'storage' && $k !== leadDbKeys()[0]) {
                        continue;                      // the upload folder is shared
                    }
                    $c['label'] = ($c['key'] === 'storage' ? '' : leadDbLabel($k) . ': ') . $c['label'];
                    $checks[] = $c;
                }
            }
        } else {
            $checks = suChecks($db, leadDbLabel($dbKey));
        }
        $ready = !array_filter($checks, fn($c) => $c['blocking'] && !$c['ok']);
        suReply(['success' => true, 'ready' => $ready, 'checks' => $checks]);
    }

    if ($action === 'history') {
        if ($isAll) {
            $list = [];
            foreach (suAllDbs() as $k => $one) {
                foreach (suHistory($one) as $h) {
                    $list[] = $h + ['db' => $k, 'db_label' => leadDbLabel($k)];
                }
            }
            usort($list, fn($a, $b) => strcmp((string) $b['created_at'], (string) $a['created_at']));
            suReply(['success' => true, 'uploads' => array_slice($list, 0, 20), 'all_dbs' => true]);
        }
        suReply(['success' => true, 'uploads' => array_map(fn($h) => $h + ['db' => $dbKey, 'db_label' => leadDbLabel($dbKey)], suHistory($getDb()))]);
    }

    if ($action === 'capi_retry' && $isPost) {
        $db = $getDb();
        $s = capiSettings();
        $why = capiProblem($s);
        if ($why !== '') {
            suReply(['success' => false, 'error' => $why], 400);
        }
        $uid = (int) ($in['upload_id'] ?? 0);
        $events = capiFailedOfUpload($db, $uid);
        if (!$events) {
            suReply(['success' => true, 'capi' => ['sent' => 0, 'failed' => 0, 'error' => '', 'by_stage' => ['qualified' => 0, 'sitevisit' => 0]], 'nothing' => true]);
        }
        suReply(['success' => true, 'capi' => capiSend($db, $events, $s, $user, 'upload:' . $uid)]);
    }

    if ($action === 'undo' && $isPost) {
        $r = suUndo($getDb(), (int) ($in['upload_id'] ?? 0));
        require_once dirname(__DIR__) . '/app/Ads/master_tables.php';
        masterClearDashboardCache();
        suReply(['success' => true] + $r);
    }

    suReply(['success' => false, 'error' => 'Unknown action.'], 400);
} catch (InvalidArgumentException $e) {
    suReply(['success' => false, 'error' => $e->getMessage()], 400);
} catch (Throwable $e) {
    error_log('[status_upload_api] ' . $e->getMessage() . ' @ ' . $e->getFile() . ':' . $e->getLine());
    suReply(['success' => false, 'error' => $e->getMessage()], 500);
}
