<?php
header('Content-Type: application/json');

ini_set('max_execution_time', '300');
ini_set('memory_limit', '256M');

require dirname(__DIR__, 2) . '/app/Core/db.php';


if (!isset($_FILES['file']))
{
    echo json_encode(["error" => "No file uploaded."]);
    exit;
}

if ($_FILES['file']['error'] !== UPLOAD_ERR_OK)
{
    echo json_encode(["error" => "Upload failed", "code" => $_FILES['file']['error']]);
    exit;
}

$file = $_FILES['file']['tmp_name'];
$fileName = $_FILES['file']['name'];
$fileExt = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));

$validMimes = ['text/csv', 'text/plain', 'application/csv', 'text/comma-separated-values', 'application/vnd.ms-excel'];
$fileMime = mime_content_type($file);

if ($fileExt !== 'csv' || (!in_array($fileMime, $validMimes) && $fileMime !== 'text/plain'))
{
    echo json_encode(["error" => "Invalid file type. Only CSV files are allowed."]);
    exit;
}

$path = STORAGE_PATH . '/meta_capi/temp.json';

$final_data = [];
$chunk = [];

$processChunk = function (&$chunk) use ($conn, &$final_data) {
    if (empty($chunk))
        return;

    $ids = [];
    foreach ($chunk as $row)
    {
        if (!empty($row[0]))
        {
            $ids[] = $conn->real_escape_string($row[0]);
        }
    }

    $existing = [];
    if (!empty($ids))
    {
        $in_clause = "'" . implode("','", $ids) . "'";
        // Grab capi_sent to see if it was already processed
        $res = $conn->query("SELECT leadgen_id FROM `lead` WHERE leadgen_id IN ($in_clause)");
        // $res = $conn->query("SELECT leadgen_id, capi_sent FROM `lead` WHERE leadgen_id IN ($in_clause)");
        if ($res)
        {
            while ($db_row = $res->fetch_assoc())
            {
                $existing[$db_row['leadgen_id']] = true;
                // $existing[$db_row['leadgen_id']] = $db_row['capi_sent'];
            }
        }
    }

    foreach ($chunk as $row)
    {
        if (empty($row[0]))
            continue;

        $row['db_exists'] = isset($existing[$row[0]]);
        // ===m=== If capi_sent is 1, flag as duplicate so it isn't sent twice ===m===
        // $row['is_duplicate'] = (isset($existing[$row[0]]) && $existing[$row[0]] == 1) ? true : false;
        $final_data[] = $row;
    }

    $chunk = [];
};

if (($handle = fopen($file, "r")) !== false)
{
    $header = fgetcsv($handle);

    while (($data = fgetcsv($handle, 1000, ",")) !== false)
    {
        $chunk[] = $data;
        if (count($chunk) >= 500)
        {
            $processChunk($chunk);
        }
    }
    $processChunk($chunk);

    fclose($handle);
}
$csv_counts = [];
foreach ($final_data as $row)
{
    if (!empty($row[0]))
    {
        $id = $row[0];
        $csv_counts[$id] = ($csv_counts[$id] ?? 0) + 1;
    }
}

// ===m=== Duplicates in CSV ===m===
$seen_in_csv = [];
foreach ($final_data as &$row)
{
    if (empty($row[0]))
        continue;
    $id = $row[0];

    $row['csv_count'] = $csv_counts[$id] ?? 1;

    // Flag the 2nd, 3rd, etc. instances as CSV Duplicates
    if (isset($seen_in_csv[$id]))
    {
        $row['is_csv_duplicate'] = true;
    } else
    {
        $row['is_csv_duplicate'] = false;
        $seen_in_csv[$id] = true;
    }
}
unset($row);

file_put_contents($path, json_encode($final_data));

echo json_encode([
    "total" => count($final_data),
    "data" => $final_data
]);
