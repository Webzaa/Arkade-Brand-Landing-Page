<?php
/**
 * creatives_api.php — backend of Creatives & Insights (creatives.php). Logic: app/Ads/creatives.php.
 *
 *   GET  ?action=data&platform=meta|google&since=Y-m-d&until=Y-m-d     ads, campaigns (budgets), totals
 *   GET  ?action=insights&platform=…&since=…&until=…                  Insights & Actions (rules + Groq wording)
 *   GET  ?action=media&platform=…&id=AD_ID                            images / video of one ad (fresh)
 *   GET  ?action=thumb&platform=…&id=…                                thumbnail image (cached on this server)
 *   GET  ?action=rules                                                thresholds
 *   POST ?action=rules  {rules: {key: number}}                        save thresholds (Super Admin)
 *
 * Access: Meta Ads → View for platform=meta, Google Ads → View for platform=google (app/Core/access.php).
 * Numbers a role may not see (Users & Roles → Hide numbers) are removed here.
 */
require_once dirname(__DIR__) . '/app/Core/db.php';      // sign-in + roles & permissions
require_once dirname(__DIR__) . '/app/Ads/creatives.php';

$action = (string) ($_GET['action'] ?? 'data');
$platform = strtolower((string) ($_GET['platform'] ?? 'meta')) === 'google' ? 'google' : 'meta';

function crJson(array $out, int $code = 200): never
{
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    echo json_encode($out, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PARTIAL_OUTPUT_ON_ERROR);
    exit;
}

/** since / until from the request: valid dates, since ≤ until, at most 1130 days (37 months: "All time"), not in the future. */
function crRange(): array
{
    $today = date('Y-m-d');
    $s = (string) ($_GET['since'] ?? '');
    $u = (string) ($_GET['until'] ?? '');
    $ok = fn($d) => preg_match('/^\d{4}-\d{2}-\d{2}$/', $d) && DateTime::createFromFormat('!Y-m-d', $d) && DateTime::createFromFormat('!Y-m-d', $d)->format('Y-m-d') === $d;
    if (!$ok($s) || !$ok($u)) {
        $u = date('Y-m-d', strtotime('-1 day'));
        $s = date('Y-m-d', strtotime('-7 days'));
    }
    if ($u > $today) {
        $u = $today;
    }
    if ($s > $u) {
        crJson(['success' => false, 'error' => 'The start date is after the end date.'], 400);
    }
    if ((new DateTime($s))->diff(new DateTime($u))->days > 1130) {
        crJson(['success' => false, 'error' => 'Choose at most 37 months (the most Meta keeps).'], 400);
    }
    return [$s, $u];
}

/** Removes the numbers this viewer's role hides from a metrics row (and its 'prev'). */
function crStrip(array $r, array $hidden): array
{
    $drop = [];
    if (in_array('qualified', $hidden, true)) {
        array_push($drop, 'ql', 'ql_pct', 'cpql');
    }
    if (in_array('cpql', $hidden, true)) {
        $drop[] = 'cpql';
    }
    if (in_array('sitevisits', $hidden, true)) {
        array_push($drop, 'sv', 'cpsv');
    }
    if (in_array('cpsv', $hidden, true)) {
        $drop[] = 'cpsv';
    }
    foreach ($drop as $k) {
        unset($r[$k]);
        if (isset($r['prev']) && is_array($r['prev'])) {
            unset($r['prev'][$k]);
        }
    }
    return $r;
}

function crLabel(string $s, string $u): string
{
    $f = fn($d, $y) => date($y ? 'j M Y' : 'j M', strtotime($d));
    return $s === $u ? $f($s, true) : $f($s, substr($s, 0, 4) !== substr($u, 0, 4)) . ' – ' . $f($u, true);
}

$hidden = function_exists('pqHiddenMetrics') ? pqHiddenMetrics() : [];

try {
    switch ($action) {
        case 'thumb': {
            // an image: nothing else may be sent (a PHP notice or a stray space before it breaks the picture)
            @ini_set('display_errors', '0');
            $id = (string) ($_GET['id'] ?? '');
            $t = crThumbFile($platform, $id, crThumbUrlFromLink($platform, $id, (string) ($_GET['u'] ?? ''), (string) ($_GET['s'] ?? '')));
            for ($i = 0; $i < 10 && ob_get_level() > 0; $i++) {
                if (!@ob_end_clean()) {
                    break;
                }
            }
            @ini_set('zlib.output_compression', 'Off');
            // no Content-Length: with PHP / server compression a fixed length cuts the picture off (broken image)
            header_remove('Content-Length');
            header('X-Content-Type-Options: nosniff');
            if ($t && isset($t['redirect'])) {
                header('Cache-Control: private, max-age=300');
                header('X-PQ-Thumb: direct');
                header('Location: ' . $t['redirect'], true, 302);
                exit;
            }
            if (!$t) {
                http_response_code(200);   // placeholder picture (the image could not be fetched from the platform)
                header('X-PQ-Placeholder: 1');
                header('Content-Type: image/svg+xml');
                header('Cache-Control: private, max-age=300');
                echo '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 160 120"><rect width="160" height="120" fill="#1E2A42"/>'
                    . '<path d="M54 80l18-22 14 16 10-12 16 18z" fill="#64748B"/><circle cx="100" cy="44" r="8" fill="#64748B"/></svg>';
                exit;
            }
            header('Content-Type: ' . $t['mime']);
            header('Cache-Control: private, max-age=86400');
            if (isset($t['bytes'])) {
                echo $t['bytes'];          // just downloaded (also when the cache folder could not be written)
            } else {
                readfile($t['file']);
            }
            exit;
        }

        // Super Admin: why a picture does not show — ?action=thumb_check&platform=meta&id=AD_ID
        case 'thumb_check': {
            if (!pqIsSuperadmin()) {
                crJson(['success' => false, 'error' => 'Only a Super Admin can run this check.'], 403);
            }
            $id = (string) ($_GET['id'] ?? '');
            $mapFile = crCacheDir() . '/thumbs_' . $platform . '.json';
            $map = is_file($mapFile) ? (json_decode((string) @file_get_contents($mapFile), true) ?: []) : [];
            $url = (string) ($map[$id] ?? '');
            $out = ['success' => true, 'id' => $id, 'known' => $url !== '', 'host' => $url !== '' ? parse_url($url, PHP_URL_HOST) : null,
                    'cache_dir_writable' => is_writable(crCacheDir()), 'curl' => function_exists('curl_init')];
            if ($url !== '') {
                $got = crDownloadImage($url);
                $out['download'] = ($GLOBALS['CR_LAST_DOWNLOAD'] ?? null);
                $out['download_ok'] = (bool) $got;
            }
            if ($platform === 'meta' && ctype_digit($id)) {
                $d = crMetaDetails([$id])[$id] ?? null;
                $out['meta_returned_image'] = $d ? (($d['thumb_src'] ?? '') !== '') : false;
                $out['meta_type'] = $d['type'] ?? null;
                $out['meta_images'] = $d ? count($d['images'] ?? []) : 0;
            }
            crJson($out);
        }

        case 'media': {
            crJson(['success' => true] + crMedia($platform, (string) ($_GET['id'] ?? '')));
        }

        case 'rules': {
            $defs = [];
            foreach (CR_RULES as $k => [$label, $def, $min, $max]) {
                $defs[] = ['key' => $k, 'label' => $label, 'default' => $def, 'min' => $min, 'max' => $max];
            }
            if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
                if (!pqCan('creatives', 'rules')) {
                    crJson(['success' => false, 'error' => 'Your role cannot change the rules (Users & Roles → Creatives & Insights → Edit insight rules).'], 403);
                }
                $in = json_decode((string) file_get_contents('php://input'), true);
                $rules = crSaveRules((array) ($in['rules'] ?? []), (string) ($_SESSION['username'] ?? $_SESSION['user'] ?? 'admin'));
                foreach (glob(crCacheDir() . '/groq_*.json') ?: [] as $f) {
                    @unlink($f);
                }
                crJson(['success' => true, 'rules' => $rules, 'defs' => $defs]);
            }
            crJson(['success' => true, 'rules' => crRules(), 'defs' => $defs, 'can_edit' => pqCan('creatives', 'rules')]);
        }

        // creatives of some ads (the page asks for the ones it is about to show): ?action=details&platform=…&ids=1,2,3[&camp=ACTIVE,PAUSED,…]
        case 'details': {
            $ids = array_slice(array_values(array_unique(array_filter(array_map(fn($v) => preg_replace('/\D+/', '', $v), explode(',', (string) ($_GET['ids'] ?? '')))))), 0, 40);
            if (!$ids) {
                crJson(['success' => false, 'error' => 'No ad given.'], 400);
            }
            $camp = array_map(fn($v) => preg_replace('/[^A-Z_]/', '', strtoupper($v)), explode(',', (string) ($_GET['camp'] ?? '')));
            $campOf = [];
            foreach ($ids as $i => $id) {
                $campOf[$id] = $camp[$i] ?? '';
            }
            crJson(['success' => true, 'ads' => crAdDetails($platform, $ids, $campOf)]);
        }

        case 'insights': {
            [$s, $u] = crRange();
            $ins = crInsights($platform, $s, $u, $hidden);
            $txt = crInsightsText($platform, crLabel($s, $u), $ins['findings']);
            $items = [];
            foreach ($ins['findings'] as $f) {
                $items[] = $f + ['say' => $txt['items'][$f['id']] ?? ($f['text'] . ' ' . $f['action'])];
            }
            crJson(['success' => true, 'platform' => $platform, 'since' => $s, 'until' => $u, 'label' => crLabel($s, $u),
                    'summary' => $txt['summary'], 'source' => $txt['source'], 'findings' => $items,
                    'benchmarks' => $ins['benchmarks'], 'statuses_in' => $ins['statuses_in']]);
        }

        case 'data':
        default: {
            [$s, $u] = crRange();
            $d = crAds($platform, $s, $u);
            $d['ads'] = array_map(fn($r) => crStrip($r, $hidden), $d['ads']);
            $d['campaigns'] = array_map(fn($r) => crStrip($r, $hidden), $d['campaigns']);
            $d['total'] = crStrip($d['total'], $hidden);
            $d['prev_total'] = crStrip($d['prev_total'], $hidden);
            // leads that could not be put under an ad (Google: no utm_adid on the lead)
            $placed = array_sum(array_column($d['ads'], 'leads'));
            $inCamps = array_sum(array_column($d['campaigns'], 'leads'));
            crJson(['success' => true, 'label' => crLabel($s, $u), 'prev_label' => crLabel($d['prev_since'], $d['prev_until']),
                    'hidden' => $hidden, 'unplaced_leads' => max(0, $inCamps - $placed), 'groq' => defined('GROQ_API_KEY') && trim((string) GROQ_API_KEY) !== '', 'rules' => crRules()] + $d);
        }
    }
} catch (InvalidArgumentException $e) {
    crJson(['success' => false, 'error' => $e->getMessage()], 400);
} catch (Throwable $e) {
    error_log('[creatives_api] ' . $e->getMessage() . ' @ ' . $e->getFile() . ':' . $e->getLine());
    crJson(['success' => false, 'error' => $e->getMessage()], 500);
}
