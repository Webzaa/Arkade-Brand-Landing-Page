<?php
/**
 * creatives.php — Creatives & Insights: every Meta / Google ad of this project with its image or video, results
 * (spend, leads, CPL, qualified, CPQL, site visits, CPSV), campaign budgets, and "Insights & Actions" for the
 * execution team (what to scale, pause, refresh, and which creatives to make more of).
 * Opened inside dashboard.php (dates come from the dashboard's date bar), or on its own.
 * Backend: creatives_api.php · logic: app/Ads/creatives.php. Access: Users & Roles → Creatives & Insights → View.
 */
session_start();
if (($_SESSION['user_logged'] ?? '') !== 'Y') {
    header('Location: login.php');
    exit;
}
require_once dirname(__DIR__) . '/app/Core/db.php';
// Users & Roles → Creatives & Insights → View: both platforms
$platforms = pqCan('creatives') ? ['meta' => 'Meta', 'google' => 'Google'] : [];
$isSuper = pqIsSuperadmin();
$canRules = pqCan('creatives', 'rules');   // Users & Roles → Creatives & Insights → Edit insight rules
?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Sora:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
<script>
(function () {
    var root = document.documentElement, t = null;
    try { t = localStorage.getItem('performiq-theme'); } catch (e) {}
    root.setAttribute('data-theme', t === 'light' ? 'light' : 'dark');
    if (/[?&]embed=1(&|$)/.test(location.search)) root.classList.add('pq-embed');
    window.addEventListener('storage', function (e) {
        if (e.key === 'performiq-theme') root.setAttribute('data-theme', e.newValue === 'light' ? 'light' : 'dark');
    });
    window.setTheme = function (t) { root.setAttribute('data-theme', t === 'light' ? 'light' : 'dark'); };
})();
</script>
<title>Creatives &amp; Insights</title>
<?= function_exists('pqMetricGuardTag') ? pqMetricGuardTag('') : '' ?>
<?= function_exists('pqViewTag') ? pqViewTag('') : '' ?>
<?= function_exists('pqDatesTag') ? pqDatesTag('') : '' ?>
<style>
    :root, html[data-theme="dark"] {
        --bg: #0B0F1A; --surface: #111827; --surface-2: #161D2E; --border: #1E2A42; --border-strong: #2A3957;
        --text: #E2E8F0; --text-dim: #94A3B8; --text-faint: #64748B; --accent: #E8A820; --accent-soft: #E8A8201F;
        --hover: #1A2337; --good: #10B981; --good-soft: #10B9811F; --bad: #EF4444; --bad-soft: #EF44441A;
        --warn: #F59E0B; --warn-soft: #F59E0B1A; --info: #60A5FA; --info-soft: #60A5FA1A;
        --meta: #3987E5; --meta-soft: #3987E51F; --google: #D95926; --google-soft: #D959261F; --thumb: #0E1524; color-scheme: dark;
    }
    html[data-theme="light"] {
        --bg: #F4F6FA; --surface: #FFFFFF; --surface-2: #F8FAFC; --border: #E2E8F0; --border-strong: #CBD5E1;
        --text: #0F172A; --text-dim: #475569; --text-faint: #94A3B8; --accent: #B7791F; --accent-soft: #B7791F1A;
        --hover: #F1F5F9; --good: #059669; --good-soft: #0596691A; --bad: #DC2626; --bad-soft: #DC26261A;
        --warn: #B45309; --warn-soft: #B453091A; --info: #2563EB; --info-soft: #2563EB14;
        --meta: #2A78D6; --meta-soft: #2A78D61A; --google: #C2410C; --google-soft: #C2410C1A; --thumb: #E8EDF5; color-scheme: light;
    }
    * { box-sizing: border-box; }
    body { margin: 0; background: var(--bg); color: var(--text); font: 14px/1.5 'Sora', system-ui, -apple-system, 'Segoe UI', sans-serif; }
    button, input, select { font: inherit; color: inherit; }
    a { color: inherit; }
    .mono, .num { font-family: 'JetBrains Mono', ui-monospace, monospace; font-variant-numeric: tabular-nums; }
    .wrap { max-width: 1480px; margin: 0 auto; padding: 28px 24px 60px; }
    .pq-embed .wrap { padding-top: 18px; }
    .pq-embed .page-head, .pq-embed .own-dates { display: none !important; }
    h1 { font-size: 22px; margin: 0 0 4px; }
    h2 { font-size: 15px; margin: 0; }
    .sub { color: var(--text-dim); margin: 0 0 18px; font-size: 13px; }
    .card { background: var(--surface); border: 1px solid var(--border); border-radius: 12px; padding: 16px 18px; margin-bottom: 16px; min-width: 0; }
    .row { display: flex; gap: 10px; align-items: center; flex-wrap: wrap; }
    .grow { flex: 1 1 auto; }
    select, input[type=date], input[type=search], input[type=number] { background: var(--surface-2); border: 1px solid var(--border-strong); border-radius: 8px; padding: 7px 10px; outline: none; min-width: 0; }
    select:focus, input:focus { border-color: var(--accent); }
    .btn { border: 1px solid var(--border-strong); background: var(--surface-2); padding: 7px 13px; border-radius: 8px; cursor: pointer; font-weight: 600; font-size: 12.5px; white-space: nowrap; text-decoration: none; display: inline-flex; gap: 6px; align-items: center; }
    .btn:hover { background: var(--hover); }
    .btn.primary { background: var(--accent); border-color: var(--accent); color: #111; }
    .btn.sm { padding: 4px 9px; font-size: 11.5px; }
    .btn:disabled { opacity: .5; cursor: not-allowed; }
    .btn:focus-visible, .chip:focus-visible, .tab:focus-visible, .thumb:focus-visible, .ins-item:focus-visible { outline: 2px solid var(--accent); outline-offset: 2px; }
    .tabs { display: inline-flex; gap: 4px; background: var(--surface-2); border: 1px solid var(--border); border-radius: 10px; padding: 3px; }
    .tab { border: 0; background: none; border-radius: 7px; padding: 6px 14px; font-size: 13px; cursor: pointer; color: var(--text-dim); font-weight: 600; }
    .tab.on { background: var(--surface); color: var(--text); box-shadow: 0 1px 0 var(--border-strong); }
    .tab .dot { display: inline-block; width: 8px; height: 8px; border-radius: 50%; margin-right: 6px; vertical-align: 1px; }
    .range { font-size: 12.5px; color: var(--text-dim); }
    .range b { color: var(--text); font-weight: 600; }
    .chip { border: 1px solid var(--border); background: var(--surface-2); border-radius: 99px; padding: 4px 11px; font-size: 12px; cursor: pointer; color: var(--text-dim); font-weight: 600; }
    .chip.on { border-color: var(--accent); color: var(--text); background: var(--accent-soft); }
    .chip b { margin-left: 4px; font-family: 'JetBrains Mono', monospace; font-weight: 500; }
    .pill { display: inline-flex; align-items: center; gap: 4px; padding: 1px 8px; border-radius: 99px; font-size: 11px; font-weight: 600; white-space: nowrap; }
    .pill.good { color: var(--good); background: var(--good-soft); } .pill.bad { color: var(--bad); background: var(--bad-soft); }
    .pill.warn { color: var(--warn); background: var(--warn-soft); } .pill.info { color: var(--info); background: var(--info-soft); }
    .pill.dim { color: var(--text-dim); background: var(--surface-2); border: 1px solid var(--border); }
    .note { padding: 10px 14px; border-radius: 10px; font-size: 12.5px; margin-bottom: 14px; border: 1px solid; }
    .note.warn { background: var(--warn-soft); border-color: var(--warn); } .note.info { background: var(--info-soft); border-color: var(--info); }
    .note.bad { background: var(--bad-soft); border-color: var(--bad); }
    .muted { color: var(--text-dim); } .faint { color: var(--text-faint); font-size: 11.5px; }
    .spinner { width: 15px; height: 15px; border: 2px solid var(--border-strong); border-top-color: var(--accent); border-radius: 50%; display: inline-block; animation: spin .8s linear infinite; vertical-align: -3px; margin-right: 8px; }
    @keyframes spin { to { transform: rotate(360deg); } }
    @media (prefers-reduced-motion: reduce) { .spinner { animation: none; } .ad.flash { animation: none; } }

    /* totals */
    .totals { display: grid; grid-template-columns: repeat(auto-fit, minmax(118px, 1fr)); gap: 10px; margin: 0 0 16px; }
    .tot { background: var(--surface); border: 1px solid var(--border); border-radius: 10px; padding: 10px 12px; }
    .tot div { color: var(--text-dim); font-size: 11px; text-transform: uppercase; letter-spacing: .05em; }
    .tot strong { display: block; font-size: 19px; margin-top: 2px; font-family: 'JetBrains Mono', monospace; font-weight: 500; }
    .delta { font-size: 11px; font-family: 'JetBrains Mono', monospace; }
    .delta.up-good, .delta.down-good { color: var(--good); } .delta.up-bad, .delta.down-bad { color: var(--bad); } .delta.flat { color: var(--text-faint); }

    /* insights */
    .ins-head { display: flex; gap: 10px; align-items: center; flex-wrap: wrap; margin-bottom: 8px; }
    .ins-sum { font-size: 13.5px; margin: 0 0 12px; max-width: 95ch; }
    .ins-list { display: grid; grid-template-columns: repeat(auto-fill, minmax(330px, 1fr)); gap: 10px; }
    .ins-item { display: grid; grid-template-columns: 56px minmax(0, 1fr); gap: 12px; align-items: start; border: 1px solid var(--border); background: var(--surface-2);
                border-radius: 10px; padding: 10px; text-align: left; cursor: default; }
    .ins-item[data-ad] { cursor: pointer; } .ins-item[data-ad]:hover { border-color: var(--border-strong); }
    .ins-thumb { position: relative; width: 56px; height: 56px; border-radius: 8px; background: var(--thumb); object-fit: cover; display: grid; place-items: center; font-size: 11px; color: var(--text-faint); overflow: hidden; }
    .ins-thumb img { width: 100%; height: 100%; object-fit: cover; display: block; }
    .ins-title { font-weight: 600; font-size: 13px; display: flex; gap: 7px; align-items: baseline; }
    .ins-title > span:last-child { min-width: 0; overflow-wrap: anywhere; }
    .ins-text { font-size: 12.5px; color: var(--text-dim); margin-top: 3px; }
    .sev { width: 9px; height: 9px; border-radius: 50%; flex: none; display: inline-block; }
    .sev.good { background: var(--good); } .sev.bad { background: var(--bad); } .sev.warn { background: var(--warn); } .sev.info { background: var(--info); }
    .ins-empty { padding: 12px; border: 1px dashed var(--border-strong); border-radius: 10px; color: var(--text-dim); font-size: 13px; }

    /* campaigns */
    .tbl-wrap { overflow: auto; border: 1px solid var(--border); border-radius: 10px; }
    table { width: 100%; border-collapse: collapse; font-size: 12.5px; }
    th { position: sticky; top: 0; z-index: 1; background: var(--surface-2); color: var(--text-dim); font-weight: 600; text-align: right; padding: 8px 10px;
         border-bottom: 1px solid var(--border); white-space: nowrap; font-size: 11px; text-transform: uppercase; letter-spacing: .04em; }
    td { padding: 8px 10px; border-bottom: 1px solid var(--border); text-align: right; white-space: nowrap; font-family: 'JetBrains Mono', monospace; font-size: 12px; }
    th:first-child, td:first-child { text-align: left; font-family: inherit; white-space: normal; min-width: 220px; }
    tr:last-child td { border-bottom: 0; }
    .use { display: inline-block; width: 54px; height: 6px; border-radius: 99px; background: var(--border); vertical-align: middle; margin-left: 6px; overflow: hidden; }
    .use i { display: block; height: 100%; border-radius: 99px; }
    .st { font-size: 10.5px; font-weight: 600; letter-spacing: .03em; }
    .st.on { color: var(--good); } .st.off { color: var(--text-faint); }

    /* gallery */
    .gal-head { display: flex; gap: 10px; align-items: center; flex-wrap: wrap; margin: 4px 0 12px; }
    .gallery { display: grid; grid-template-columns: repeat(auto-fill, minmax(260px, 1fr)); gap: 14px; }
    .ad { background: var(--surface); border: 1px solid var(--border); border-radius: 12px; overflow: hidden; display: flex; flex-direction: column; min-width: 0; }
    .ad.flash { animation: flash 1.6s ease-out; }
    @keyframes flash { 0% { box-shadow: 0 0 0 3px var(--accent); } 100% { box-shadow: 0 0 0 0 transparent; } }
    .thumb { position: relative; aspect-ratio: 16 / 10; background: var(--thumb); border: 0; padding: 0; cursor: pointer; display: block; width: 100%; overflow: hidden; }
    .thumb img { width: 100%; height: 100%; object-fit: cover; display: block; }
    .thumb .play { position: absolute; inset: 0; display: grid; place-items: center; }
    .thumb .play span { width: 46px; height: 46px; border-radius: 50%; background: rgba(0, 0, 0, .55); display: grid; place-items: center; }
    .thumb .play span::after { content: ''; border-left: 14px solid #fff; border-top: 9px solid transparent; border-bottom: 9px solid transparent; margin-left: 4px; }
    .thumb .kind { position: absolute; left: 8px; top: 8px; background: rgba(0, 0, 0, .62); color: #fff; font-size: 10.5px; font-weight: 600; padding: 2px 7px; border-radius: 6px; letter-spacing: .03em; }
    .ins-thumb .noimg { font-size: 9px; text-align: center; }
    .thumb .noimg, .ins-thumb .noimg { position: absolute; inset: 0; display: grid; place-items: center; color: var(--text-faint); font-size: 12px; }
    .serp { aspect-ratio: 16 / 10; background: var(--thumb); padding: 14px 16px; overflow: hidden; font-family: Arial, sans-serif; text-align: left; border: 0; width: 100%; cursor: pointer; color: inherit; }
    .serp .sp { font-size: 11px; color: var(--text-dim); }
    .serp .hl { color: #4C8DF6; font-size: 15px; line-height: 1.3; margin: 4px 0; }
    html[data-theme="light"] .serp .hl { color: #1a0dab; }
    .serp .ds { font-size: 12px; color: var(--text-dim); line-height: 1.4; }
    .ad-body { padding: 12px 14px 14px; display: flex; flex-direction: column; gap: 8px; flex: 1; }
    .ad-name { font-weight: 600; font-size: 13px; line-height: 1.35; overflow: hidden; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow-wrap: anywhere; }
    .ad-where { font-size: 11.5px; color: var(--text-faint); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
    .tags { display: flex; gap: 5px; flex-wrap: wrap; min-height: 0; }
    .mgrid { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 6px 8px; border-top: 1px solid var(--border); padding-top: 9px; margin-top: auto; }
    .m div { font-size: 10px; color: var(--text-faint); text-transform: uppercase; letter-spacing: .05em; }
    .m strong { font-family: 'JetBrains Mono', monospace; font-weight: 500; font-size: 12.5px; display: block; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .ad-actions { display: flex; gap: 6px; flex-wrap: wrap; }
    .more { display: flex; gap: 12px; align-items: center; justify-content: center; padding: 18px 0 6px; }
    .ad.loading .thumb, .ad.loading .serp { animation: pulse 1.2s ease-in-out infinite; }
    @keyframes pulse { 50% { opacity: .55; } }
    @media (prefers-reduced-motion: reduce) { .ad.loading .thumb, .ad.loading .serp { animation: none; } }
    .empty { padding: 30px; text-align: center; color: var(--text-dim); border: 1px dashed var(--border-strong); border-radius: 12px; }
    .skeleton { background: linear-gradient(90deg, var(--surface-2), var(--hover), var(--surface-2)); background-size: 200% 100%; border-radius: 12px; height: 320px; }

    /* dialogs */
    [hidden] { display: none !important; }
    .overlay { position: fixed; inset: 0; background: rgba(2, 6, 23, .7); display: grid; place-items: center; z-index: 50; padding: 16px; }
    .dialog { background: var(--surface); border: 1px solid var(--border-strong); border-radius: 14px; padding: 20px; max-width: 920px; width: 100%; max-height: 92vh; overflow: auto; box-shadow: 0 20px 60px rgba(0, 0, 0, .45); }
    .dialog h3 { margin: 0 0 4px; font-size: 16px; }
    .media { display: grid; gap: 12px; margin-top: 12px; }
    .media img, .media video { width: 100%; max-height: 62vh; object-fit: contain; background: #000; border-radius: 10px; display: block; }
    .media iframe { width: 100%; aspect-ratio: 16 / 9; border: 0; border-radius: 10px; background: #000; }
    .imgs { display: grid; grid-template-columns: repeat(auto-fill, minmax(180px, 1fr)); gap: 8px; }
    .imgs img { max-height: 200px; object-fit: cover; }
    .media .noimg { display: block; padding: 18px; text-align: center; color: var(--text-faint); background: var(--surface-2); border-radius: 10px; }
    .copy { background: var(--surface-2); border: 1px solid var(--border); border-radius: 10px; padding: 12px; font-size: 13px; white-space: pre-wrap; }
    .rules { display: grid; grid-template-columns: minmax(0, 1fr) 110px; gap: 8px 12px; align-items: center; font-size: 13px; margin-top: 12px; }
    .rules input { width: 100%; text-align: right; }
    .actions { display: flex; justify-content: flex-end; gap: 10px; margin-top: 16px; flex-wrap: wrap; }
    @media (max-width: 760px) { .wrap { padding: 16px; } .ins-list { grid-template-columns: 1fr; } }
</style>
</head>
<body>
<div class="wrap">
    <div class="page-head">
        <h1>Creatives &amp; Insights</h1>
        <p class="sub">Every ad with its image or video and its real results from the CRM, the campaign budgets, and what to do next.</p>
    </div>

    <?php if (!$platforms) { ?>
        <div class="empty">Your role doesn't include Creatives &amp; Insights. Ask a Super Admin for access.</div>
    <?php } else { ?>
    <div class="row" style="margin-bottom:14px">
        <div class="tabs" role="tablist" id="pf-tabs">
            <?php foreach ($platforms as $k => $n) { ?>
                <button class="tab" role="tab" data-pf="<?= $k ?>"><span class="dot" style="background:var(--<?= $k ?>)"></span><?= $n ?></button>
            <?php } ?>
        </div>
        <div class="tabs" role="group" id="state-tabs" aria-label="Show running or paused ads">
            <button class="tab" data-st="all" title="Every ad and campaign with spend or leads">All</button>
            <button class="tab" data-st="running" title="Ad and campaign both on now"><span class="dot" style="background:var(--good,#22c55e)"></span>Running</button>
            <button class="tab" data-st="paused" title="Ad or its campaign is paused / off now"><span class="dot" style="background:var(--text-faint,#64748b)"></span>Paused</button>
        </div>
        <div id="cv-host" title="All / Performance / Awareness — the same tabs as the dashboards"></div>
        <span class="range" id="range-label"></span>
        <span class="own-dates row">
            <button class="btn sm" type="button" data-qd="0">Today</button><button class="btn sm" type="button" data-qd="1">Yesterday</button><button class="btn sm" type="button" data-qr="last_1y" title="The last 12 months, till today">1 year</button><button class="btn sm" type="button" data-qr="all_time" title="From the first lead of this project till today">All time</button>
            <input type="date" id="d-since" aria-label="From"> <span class="faint">to</span> <input type="date" id="d-until" aria-label="To">
            <button class="btn sm" id="d-apply">Show</button>
        </span>
        <span class="grow"></span>
        <?php if ($canRules) { ?><button class="btn sm" id="rules-btn" title="Thresholds used by Insights &amp; Actions">Rules</button><?php } ?>
        <button class="btn sm" id="reload-btn">Refresh</button>
    </div>

    <div id="notes"></div>
    <div class="totals" id="totals"></div>

    <section class="card" id="ins-card" aria-labelledby="ins-h">
        <div class="ins-head">
            <h2 id="ins-h">Insights &amp; Actions</h2>
            <span class="pill dim" id="ins-src" hidden></span>
            <span class="faint" id="ins-bench"></span>
        </div>
        <p class="ins-sum" id="ins-sum"></p>
        <div class="ins-list" id="ins-list"><div class="ins-empty"><span class="spinner"></span>Reading the numbers…</div></div>
    </section>

    <section class="card" aria-labelledby="camp-h">
        <div class="row" style="margin-bottom:10px">
            <h2 id="camp-h">Campaigns &amp; daily budgets</h2>
            <span class="faint">Average daily spend is the spend in these dates ÷ days; budget use = that ÷ today's daily budget.</span>
        </div>
        <div class="tbl-wrap"><table id="camp-tbl"><thead></thead><tbody><tr><td colspan="12" class="muted"><span class="spinner"></span>Loading…</td></tr></tbody></table></div>
    </section>

    <section aria-labelledby="gal-h">
        <div class="gal-head">
            <h2 id="gal-h">Creatives</h2>
            <span class="faint" id="gal-count"></span>
            <span class="grow"></span>
            <div class="row" id="filters"></div>
            <input type="search" id="q" placeholder="Search ad, campaign…" aria-label="Search creatives" style="width:200px">
            <select id="sort" aria-label="Sort creatives">
                <option value="spend">Most spend</option>
                <option value="leads">Most leads</option>
                <option value="cpl">Lowest CPL</option>
                <option value="ql" data-needs="ql">Most qualified</option>
                <option value="cpql" data-needs="cpql">Lowest CPQL</option>
                <option value="sv" data-needs="sv">Most site visits</option>
                <option value="ctr">Highest CTR</option>
            </select>
        </div>
        <div class="gallery" id="gallery"><div class="skeleton"></div><div class="skeleton"></div><div class="skeleton"></div></div>
        <div class="more" id="more" hidden><button class="btn" id="more-btn" type="button">Load more</button><span class="faint" id="more-note"></span></div>
    </section>
    <?php } ?>
</div>

<div class="overlay" id="ov" hidden><div class="dialog" role="dialog" aria-modal="true" aria-labelledby="ov-title" id="ov-box"></div></div>

<script>
(function () {
    'use strict';
    const PLATFORMS = <?= json_encode(array_keys($platforms)) ?>;
    if (!PLATFORMS.length) return;
    const API = 'creatives_api.php';
    const $ = (s, el = document) => el.querySelector(s);
    const $$ = (s, el = document) => [...el.querySelectorAll(s)];
    const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
    const has = v => v !== null && v !== undefined && isFinite(v);
    const inr = (v, d = 0) => Number(v).toLocaleString('en-IN', { maximumFractionDigits: d, minimumFractionDigits: 0 });
    const money = v => has(v) ? '₹' + inr(Math.round(v)) : '—';
    const int = v => has(v) ? inr(v) : '—';
    const pct = v => has(v) ? inr(v, 2) + '%' : '—';
    const ymd = d => d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
    const store = { get(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }, set(k, v) { try { localStorage.setItem(k, v); } catch (e) {} } };

    const S = { pf: PLATFORMS.includes(store.get('pq-creatives-pf')) ? store.get('pq-creatives-pf') : PLATFORMS[0], since: '', until: '',
                data: null, ins: null, filter: 'all', req: 0, shown: 0, state: ['all', 'running', 'paused'].includes(store.get('pq-creatives-state')) ? store.get('pq-creatives-state') : 'all',
                pending: new Set() };
    const PAGE = 12;   // creatives drawn at a time (3 rows); more on scroll or "Load more"
    function setState(v) {
        S.state = v; store.set('pq-creatives-state', v);
        $$('#state-tabs .tab').forEach(b => { const on = b.dataset.st === v; b.classList.toggle('on', on); b.setAttribute('aria-pressed', on ? 'true' : 'false'); });
    }
    setState(S.state);

    // dates: from the dashboard (?since&until, then pq-range messages), else the last 7 days
    (function initRange() {
        const p = new URLSearchParams(location.search);
        let s = p.get('since'), u = p.get('until');
        if (!/^\d{4}-\d{2}-\d{2}$/.test(s || '') || !/^\d{4}-\d{2}-\d{2}$/.test(u || '')) {
            const y = new Date(); y.setDate(y.getDate() - 1);
            const a = new Date(y); a.setDate(a.getDate() - 6);
            s = ymd(a); u = ymd(y);
        }
        S.since = s; S.until = u;
        $('#d-since').value = s; $('#d-until').value = u;
    })();
    window.addEventListener('message', e => {
        const d = e.data || {};
        if (d.type === 'pq-range' && d.since && d.until && (d.since !== S.since || d.until !== S.until)) {
            S.since = d.since; S.until = d.until; load();
        }
    });
    // Today / Yesterday (on its own; inside the dashboard the date bar at the top does this)
    // Last 1 year / All time (assets/js/date_presets.js)
    document.querySelectorAll('[data-qr]').forEach(btn => btn.onclick = () => {
        const x = window.PQDates && PQDates.range(btn.dataset.qr); if (!x) return;
        S.since = x.since; S.until = x.until; $('#d-since').value = S.since; $('#d-until').value = S.until; load();
    });
    document.querySelectorAll('[data-qd]').forEach(btn => btn.onclick = () => {
        const d = new Date(); d.setDate(d.getDate() - +btn.dataset.qd);
        S.since = S.until = ymd(d); $('#d-since').value = $('#d-until').value = S.since; load();
    });
    $('#d-apply').onclick = () => {
        const s = $('#d-since').value, u = $('#d-until').value;
        if (!s || !u || s > u) { $('#d-since').focus(); return; }
        S.since = s; S.until = u; load();
    };
    $$('#pf-tabs .tab').forEach(b => b.onclick = () => { S.pf = b.dataset.pf; store.set('pq-creatives-pf', S.pf); load(); });
    $('#reload-btn').onclick = () => load();
    $('#q').oninput = () => renderGallery(true);
    $('#sort').onchange = () => renderGallery(true);
    $$('#state-tabs .tab').forEach(b => b.onclick = () => { setState(b.dataset.st); if (!S.data) return; renderCampaigns(); renderFilters(); renderGallery(true); if (S.ins) renderInsights(); });
    $('#more-btn').onclick = () => more();
    // next page when the end of the list scrolls into view
    if ('IntersectionObserver' in window) {
        new IntersectionObserver(es => { if (es.some(e => e.isIntersecting) && !$('#more').hidden) more(); }, { rootMargin: '400px' }).observe($('#more'));
    }
    function more() { S.shown += PAGE; renderGallery(false); }

    /* creatives (images, video, text, live status) are fetched only for the ads about to be shown */
    async function ensureDetails(ads) {
        const want = ads.filter(a => !a.creative && !S.pending.has(a.id)).slice(0, 40);
        if (!want.length || !S.data) return;
        const req = S.req, pf = S.pf;
        want.forEach(a => S.pending.add(a.id));
        try {
            const r = await get({ action: 'details', platform: pf, ids: want.map(a => a.id).join(','), camp: want.map(a => a.campaign_status || '').join(',') });
            if (req !== S.req) return;
            want.forEach(a => {
                const d = r.ads[a.id];
                a.creative = d ? d.creative : { type: 'unknown', thumb: null };
                if (d && d.status) { a.status = d.status; a.state = d.state; }
                const el = document.getElementById('ad-' + a.id);
                if (el) el.outerHTML = cardHtml(a);
            });
            if (S.ins) renderInsights();
            renderFilters();
            if (S.state !== 'all') renderGallery(false);   // a live status may move an ad in / out of the filter
        } catch (e) {
            want.forEach(a => { if (!a.creative) a.creative = { type: 'unknown', thumb: null }; const el = document.getElementById('ad-' + a.id); if (el) el.outerHTML = cardHtml(a); });
        } finally {
            want.forEach(a => S.pending.delete(a.id));
        }
    }
    const stateOk = st => S.state === 'all' || (S.state === 'running' ? st === 'running' : st !== 'running');

    async function get(params) {
        const res = await fetch(API + '?' + new URLSearchParams(params), { credentials: 'same-origin' });
        let j = null;
        try { j = await res.json(); } catch (e) { throw new Error('The server did not answer (HTTP ' + res.status + ').'); }
        if (!res.ok || !j.success) throw new Error(j && j.error ? j.error : 'Could not load (HTTP ' + res.status + ').');
        return j;
    }

    async function load() {
        const id = ++S.req;
        $$('#pf-tabs .tab').forEach(b => { b.classList.toggle('on', b.dataset.pf === S.pf); b.setAttribute('aria-selected', b.dataset.pf === S.pf); });
        $('#range-label').innerHTML = 'Loading <b>' + esc(S.since) + ' – ' + esc(S.until) + '</b>…';
        $('#gallery').innerHTML = '<div class="skeleton"></div><div class="skeleton"></div><div class="skeleton"></div>';
        $('#ins-list').innerHTML = '<div class="ins-empty"><span class="spinner"></span>Reading the numbers…</div>';
        $('#ins-sum').textContent = ''; $('#ins-src').hidden = true; $('#ins-bench').textContent = '';
        $('#camp-tbl tbody').innerHTML = '<tr><td colspan="12" class="muted"><span class="spinner"></span>Loading…</td></tr>';
        $('#notes').innerHTML = ''; $('#totals').innerHTML = '';
        const q = { platform: S.pf, since: S.since, until: S.until };
        try {
            const d = await get(Object.assign({ action: 'data' }, q));
            if (id !== S.req) return;
            S.data = d; S.ins = null; S.pending.clear();
            renderAll();
        } catch (e) {
            if (id !== S.req) return;
            $('#range-label').textContent = '';
            $('#gallery').innerHTML = '<div class="empty">' + esc(e.message) + '</div>';
            $('#camp-tbl tbody').innerHTML = '<tr><td colspan="12" class="muted">—</td></tr>';
            $('#ins-list').innerHTML = '<div class="ins-empty">—</div>';
            return;
        }
        try {
            const ins = await get(Object.assign({ action: 'insights' }, q));
            if (id !== S.req) return;
            S.ins = ins;
            renderInsights(); renderFilters(); renderGallery(false);
            ensureDetails(ins.findings.filter(f => f.ad_id).map(f => adById(f.ad_id)).filter(Boolean));
        } catch (e) {
            if (id !== S.req) return;
            $('#ins-list').innerHTML = '<div class="ins-empty">' + esc(e.message) + '</div>';
        }
    }

    const hidden = k => !S.data || !(k in (S.data.total || {}));
    function renderAll() {
        const d = S.data;
        $('#range-label').innerHTML = '<b>' + esc(d.label) + '</b> · compared with ' + esc(d.prev_label);
        // sort options this role can use
        $$('#sort option').forEach(o => { o.hidden = !!o.dataset.needs && hidden(o.dataset.needs); });
        if ($('#sort').selectedOptions[0] && $('#sort').selectedOptions[0].hidden) $('#sort').value = 'spend';
        const notes = [];
        if (!d.configured) notes.push(['warn', 'No ' + (S.pf === 'google' ? 'Google' : 'Meta') + ' campaigns are saved for this project yet. Use “Sync with ' + (S.pf === 'google' ? 'Google' : 'Meta') + '” on its dashboard.']);
        if (S.pf === 'google' && d.unplaced_leads > 0) {
            notes.push(['info', esc(int(d.unplaced_leads)) + ' Google lead' + (d.unplaced_leads === 1 ? '' : 's') + ' could not be put under an ad, so per-ad CPL / CPQL is incomplete. '
                + 'Add <span class="mono">utm_adid={creative}</span> to the Google Ads tracking template (with utm_campaignid={campaignid}&amp;utm_adgroupid={adgroupid}) and save it with the lead.']);
        }
        (d.warnings || []).forEach(w => notes.push(['warn', esc(w)]));
        $('#notes').innerHTML = notes.map(([c, t]) => '<div class="note ' + c + '">' + t + '</div>').join('');
        renderTotals(); renderCampaigns(); renderFilters(); renderGallery(true);
    }

    function delta(cur, prev, better) {
        if (!has(cur) || !has(prev) || prev === 0) return '';
        const ch = (cur - prev) / Math.abs(prev) * 100;
        if (Math.abs(ch) < 0.5) return '<span class="delta flat">±0%</span>';
        const up = ch > 0;
        const cls = better === 'neutral' ? 'flat' : ((up === (better === 'up')) ? (up ? 'up-good' : 'down-good') : (up ? 'up-bad' : 'down-bad'));
        return '<span class="delta ' + cls + '">' + (up ? '▲' : '▼') + ' ' + inr(Math.abs(ch), 0) + '%</span>';
    }
    function renderTotals() {
        const t = S.data.total, p = S.data.prev_total;
        const tiles = [['Spend', 'spend', money, 'neutral'], ['Leads', 'leads', int, 'up'], ['CPL', 'cpl', money, 'down'], ['Qualified', 'ql', int, 'up'],
                       ['CPQL', 'cpql', money, 'down'], ['Site visits', 'sv', int, 'up'], ['CPSV', 'cpsv', money, 'down'], ['CTR', 'ctr', pct, 'up']];
        $('#totals').innerHTML = tiles.filter(([, k]) => k in t).map(([l, k, f, b]) =>
            '<div class="tot"><div>' + l + '</div><strong>' + f(t[k]) + '</strong>' + delta(t[k], p[k], b) + '</div>').join('');
    }

    function renderCampaigns() {
        if (!S.data) return;
        const cs = (S.data.campaigns || []).filter(c => stateOk(['ACTIVE', 'ENABLED'].includes(c.status) ? 'running' : 'paused'));
        const t = S.data.total;
        const cols = [['Campaign'], ['Daily budget'], ['Avg daily spend'], ['Budget use'], ['Spend'], ['Leads'], ['CPL']]
            .concat('ql' in t ? [['Qualified']] : [], 'cpql' in t ? [['CPQL']] : [], 'sv' in t ? [['Site visits']] : [], 'cpsv' in t ? [['CPSV']] : []);
        $('#camp-tbl thead').innerHTML = '<tr>' + cols.map(([l]) => '<th scope="col">' + l + '</th>').join('') + '</tr>';
        if (!cs.length) { $('#camp-tbl tbody').innerHTML = '<tr><td colspan="' + cols.length + '" class="muted">' + (S.state === 'all' ? 'No campaign spent or ran in these dates.' : 'No ' + S.state + ' campaign in these dates.') + '</td></tr>'; return; }
        $('#camp-tbl tbody').innerHTML = cs.map(c => {
            const on = ['ACTIVE', 'ENABLED'].includes(c.status);
            const budget = has(c.daily_budget) ? money(c.daily_budget) + (c.budget_level === 'adset' ? ' <span class="faint" title="Sum of the ad sets\' daily budgets">ad sets</span>' : (c.budget_level === 'shared' ? ' <span class="faint">shared</span>' : ''))
                : (has(c.lifetime_budget) ? '<span class="faint">lifetime</span> ' + money(c.lifetime_budget) : '<span class="faint">—</span>');
            let use = '<span class="faint">—</span>';
            if (has(c.budget_use_pct)) {
                const col = c.budget_use_pct < ((S.data.rules || {}).underspend_pct || 60) ? 'var(--warn)' : (c.budget_use_pct >= 95 ? 'var(--good)' : 'var(--accent)');
                use = inr(c.budget_use_pct, 0) + '%<span class="use"><i style="width:' + Math.min(100, c.budget_use_pct) + '%;background:' + col + '"></i></span>';
            }
            return '<tr><td><div style="font-weight:600">' + esc(c.name) + '</div><span class="st ' + (on ? 'on' : 'off') + '">' + esc(c.status ? c.status.replace('_', ' ') : 'STATUS UNKNOWN') + '</span></td>'
                + '<td>' + budget + '</td><td>' + money(c.avg_daily_spend) + '</td><td>' + use + '</td><td>' + money(c.spend) + '</td><td>' + int(c.leads) + '</td><td>' + money(c.cpl) + '</td>'
                + ('ql' in t ? '<td>' + int(c.ql) + '</td>' : '') + ('cpql' in t ? '<td>' + money(c.cpql) + '</td>' : '')
                + ('sv' in t ? '<td>' + int(c.sv) + '</td>' : '') + ('cpsv' in t ? '<td>' + money(c.cpsv) + '</td>' : '') + '</tr>';
        }).join('');
    }

    const TAG = { winner: ['Winner', 'good'], good_cpl: ['Good CPL', 'good'], sv_driver: ['Site-visit driver', 'good'], junk: ['Cheap but junk', 'warn'],
                  losing: ['Losing', 'bad'], fatigue: ['Fatigued', 'warn'], worsening: ['CPL rising', 'warn'] };
    function adTags() {
        const m = {};
        ((S.ins && S.ins.findings) || []).forEach(f => { if (f.ad_id && TAG[f.type]) (m[f.ad_id] = m[f.ad_id] || []).push(f.type); });
        return m;
    }
    function adById(id) { return ((S.data && S.data.ads) || []).find(a => String(a.id) === String(id)); }

    // a picture that does not load shows a note instead of the browser's broken-image icon
    window.pqImgFail = img => { const sp = document.createElement('span'); sp.className = 'noimg'; sp.textContent = 'Image not available'; img.replaceWith(sp); };
    const IMG = (src, alt, lazy) => '<img src="' + esc(src) + '" alt="' + esc(alt || '') + '"' + (lazy ? ' loading="lazy"' : '') + ' onerror="pqImgFail(this)">';
    function thumbHtml(a, small) {
        const c = a.creative || {};
        if (small) return c.thumb ? IMG(c.thumb, '', true) : (c.type === 'text' ? 'Text' : '—');
        if (c.type === 'text' && S.pf === 'google') {
            return '<button class="serp" data-open="' + esc(a.id) + '" aria-label="Preview ' + esc(a.name) + '"><div class="sp">Sponsored · ' + esc(c.host || '') + '</div>'
                + '<div class="hl">' + esc((c.headlines || []).slice(0, 3).join(' | ') || a.name) + '</div><div class="ds">' + esc((c.descriptions || []).join(' ')) + '</div></button>';
        }
        const kind = { video: 'VIDEO', image: 'IMAGE', carousel: 'CAROUSEL', dynamic: 'MULTI-ASSET', text: 'TEXT' }[c.type] || 'AD';
        return '<button class="thumb" data-open="' + esc(a.id) + '" aria-label="Preview ' + esc(a.name) + '">'
            + (c.thumb ? IMG(c.thumb, '', true) : '<span class="noimg">No preview from ' + (S.pf === 'google' ? 'Google' : 'Meta') + '</span>')
            + (c.type === 'video' ? '<span class="play"><span></span></span>' : '') + '<span class="kind">' + kind + (c.assets > 1 ? ' · ' + c.assets : '') + '</span></button>';
    }

    function renderInsights() {
        const ins = S.ins;
        $('#ins-sum').textContent = ins.summary || '';
        const src = $('#ins-src');
        src.hidden = false;
        src.textContent = ins.source === 'groq' ? 'Wording by Groq · numbers from the rules' : 'Rules';
        src.title = ins.source === 'groq' ? 'The findings and numbers come from fixed rules; Groq only writes the sentences.' : 'Add GROQ_API_KEY in config.php for written advice.';
        const b = ins.benchmarks || {};
        $('#ins-bench').textContent = [has(b.cpql) ? 'Benchmark: ' + (b.cpql_label || 'CPQL') + ' ' + money(b.cpql) : '', has(b.cpl) ? (b.cpl_label || 'CPL') + ' ' + money(b.cpl) : ''].filter(Boolean).join(' · ');
        // Running / Paused: keep the findings of ads / campaigns in that state (account-wide ones always show)
        const campOn = id => { const c = (S.data.campaigns || []).find(x => String(x.id) === String(id)); return c ? (['ACTIVE', 'ENABLED'].includes(c.status) ? 'running' : 'paused') : 'unknown'; };
        const list = ins.findings.filter(f => {
            if (S.state === 'all') return true;
            if (f.ad_id) { const a = adById(f.ad_id); return a ? stateOk(a.state) : true; }
            if (f.campaign_id) return stateOk(campOn(f.campaign_id));
            return true;
        });
        if (!list.length && ins.findings.length) {
            $('#ins-list').innerHTML = '<div class="ins-empty">No finding for ' + S.state + ' ads in these dates. Choose All to see the ' + ins.findings.length + ' findings.</div>';
            return;
        }
        if (!ins.findings.length) {
            $('#ins-list').innerHTML = '<div class="ins-empty">Nothing stands out for these dates — not enough spend or leads yet for the rules. Try a longer date range.</div>';
            return;
        }
        $('#ins-list').innerHTML = list.map(f => {
            const a = f.ad_id ? adById(f.ad_id) : null;
            return '<div class="ins-item" ' + (a ? 'data-ad="' + esc(a.id) + '" role="button" tabindex="0"' : '') + '>'
                + '<div class="ins-thumb">' + (a ? thumbHtml(a, true) : (f.level === 'campaign' ? 'Camp.' : 'All')) + '</div>'
                + '<div><div class="ins-title"><span class="sev ' + esc(f.severity) + '" aria-hidden="true"></span><span>' + esc(f.title) + '</span></div>'
                + '<div class="ins-text">' + esc(f.say) + '</div></div></div>';
        }).join('');
        $$('#ins-list [data-ad]').forEach(el => {
            const go = () => {
                $('#q').value = ''; S.filter = 'all'; renderFilters();
                const i = filtered().findIndex(a => String(a.id) === el.dataset.ad);
                if (i < 0 && S.state !== 'all') { setState('all'); renderCampaigns(); renderFilters(); renderInsights(); }
                const j = filtered().findIndex(a => String(a.id) === el.dataset.ad);
                S.shown = Math.max(PAGE, Math.ceil((j + 1) / PAGE) * PAGE); renderGallery(false);
                const card = document.getElementById('ad-' + el.dataset.ad);
                if (card) { card.scrollIntoView({ behavior: 'smooth', block: 'center' }); card.classList.remove('flash'); void card.offsetWidth; card.classList.add('flash'); }
            };
            el.onclick = go;
            el.onkeydown = e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); go(); } };
        });
    }

    function renderFilters() {
        const ads = ((S.data && S.data.ads) || []).filter(a => stateOk(a.state));
        const tags = adTags();
        const n = f => ads.filter(f).length;
        const F = [['all', 'All', () => true], ['scale', 'To scale', a => (tags[a.id] || []).some(t => TAG[t][1] === 'good')],
                   ['fix', 'To fix', a => (tags[a.id] || []).some(t => TAG[t][1] !== 'good')],
                   ['video', 'Video', a => (a.creative || {}).type === 'video'], ['image', 'Image', a => ['image', 'carousel', 'dynamic'].includes((a.creative || {}).type)]]
            .concat(S.pf === 'google' ? [['text', 'Search text', a => (a.creative || {}).type === 'text']] : []);
        S.filters = Object.fromEntries(F.map(([k, , f]) => [k, f]));
        if (!S.filters[S.filter]) S.filter = 'all';
        $('#filters').innerHTML = F.map(([k, l, f]) => '<button class="chip ' + (S.filter === k ? 'on' : '') + '" data-f="' + k + '">' + l + '<b>' + n(f) + '</b></button>').join('');
        $$('#filters .chip').forEach(b => b.onclick = () => {
            S.filter = b.dataset.f; renderFilters(); renderGallery(true);
            // Video / Image / Search text need every ad's creative: fetch the rest in the background
            if (['video', 'image', 'text'].includes(S.filter)) loadAllDetails();
        });
    }

    async function loadAllDetails() {
        const left = () => (S.data ? S.data.ads.filter(a => !a.creative) : []);
        for (let i = 0; i < 20 && left().length; i++) {
            const n = left().length;
            await ensureDetails(left());
            if (left().length === n) break;
        }
    }

    function filtered() {
        const q = $('#q').value.trim().toLowerCase();
        const sort = $('#sort').value;
        const f = (S.filters || {})[S.filter] || (() => true);
        const ads = S.data.ads.filter(a => stateOk(a.state) && f(a) && (!q || (a.name + ' ' + a.campaign + ' ' + a.adgroup).toLowerCase().includes(q)));
        const low = ['cpl', 'cpql'].includes(sort);
        ads.sort((x, y) => {
            const a = x[sort], b = y[sort];
            if (!has(a) && !has(b)) return y.spend - x.spend;
            if (!has(a)) return 1;
            if (!has(b)) return -1;
            return low ? a - b : b - a;
        });
        return ads;
    }

    function cardHtml(a) {
        const t = S.data.total, tags = S.tagsCache || {};
        const p = a.prev || {};
        const m = [['Spend', money(a.spend)], ['Leads', int(a.leads)], ['CPL', money(a.cpl) + ' ' + delta(a.cpl, p.cpl, 'down')]];
        if ('ql' in t) m.push(['QL', int(a.ql)]);
        if ('cpql' in t) m.push(['CPQL', money(a.cpql)]);
        if ('sv' in t) m.push(['Visits', int(a.sv)]);
        if ('cpsv' in t) m.push(['CPSV', money(a.cpsv)]);
        m.push(['CTR', pct(a.ctr)]);
        if (S.pf === 'meta') m.push(['Freq.', has(a.frequency) ? inr(a.frequency, 2) : '—']);
        const c = a.creative || {};
        const st = a.state === 'running' ? '<span class="pill good">Running</span>'
            : (a.state === 'paused' ? '<span class="pill dim" title="' + esc([a.status, a.campaign_status && 'campaign ' + a.campaign_status].filter(Boolean).join(' · ').toLowerCase()) + '">Paused</span>' : '');
        const link = c.preview_url ? '<a class="btn sm" href="' + esc(c.preview_url) + '" target="_blank" rel="noopener">See it on Facebook</a>'
            : (c.final_url ? '<a class="btn sm" href="' + esc(c.final_url) + '" target="_blank" rel="noopener">Landing page</a>' : '');
        const thumb = a.creative ? thumbHtml(a, false) : '<button class="thumb" data-open="' + esc(a.id) + '" aria-label="Preview ' + esc(a.name) + '"><span class="noimg">Loading the creative…</span></button>';
        return '<article class="ad' + (a.creative ? '' : ' loading') + '" id="ad-' + esc(a.id) + '">' + thumb
            + '<div class="ad-body"><div class="tags">' + st
            + (tags[a.id] || []).map(k => '<span class="pill ' + TAG[k][1] + '">' + TAG[k][0] + '</span>').join('') + '</div>'
            + '<div class="ad-name" title="' + esc(a.name) + '">' + esc(a.name) + '</div>'
            + '<div class="ad-where" title="' + esc(a.campaign + ' › ' + a.adgroup) + '">' + esc(a.campaign) + ' › ' + esc(a.adgroup) + '</div>'
            + '<div class="mgrid">' + m.map(([l, v]) => '<div class="m"><div>' + l + '</div><strong>' + v + '</strong></div>').join('') + '</div>'
            + '<div class="ad-actions"><button class="btn sm" data-open="' + esc(a.id) + '">Preview</button>' + link + '</div></div></article>';
    }

    // reset = back to the first page (new filter / sort / search); else keep what is shown and add the next page
    function renderGallery(reset) {
        if (!S.data) return;
        if (reset || !S.shown) S.shown = PAGE;
        S.tagsCache = adTags();
        const ads = filtered();
        const show = ads.slice(0, S.shown);
        $('#gal-count').textContent = (ads.length === S.data.ads.length ? ads.length : ads.length + ' of ' + S.data.ads.length) + ' ads with spend or leads';
        $('#more').hidden = show.length >= ads.length;
        $('#more-note').textContent = show.length < ads.length ? 'Showing ' + show.length + ' of ' + ads.length : '';
        if (!ads.length) {
            $('#gallery').innerHTML = '<div class="empty" style="grid-column:1/-1">' + (S.data.ads.length ? 'No ad matches.' : 'No ad spent or brought a lead in these dates.') + '</div>';
            return;
        }
        $('#gallery').innerHTML = show.map(cardHtml).join('');
        ensureDetails(show);
    }

    /* ── preview window ── */
    const ov = $('#ov'), box = $('#ov-box');
    let lastFocus = null;
    function openDialog(html) {
        lastFocus = document.activeElement;
        box.innerHTML = html; ov.hidden = false;
        const first = box.querySelector('button, a, input'); if (first) first.focus();
    }
    function closeDialog() { ov.hidden = true; box.innerHTML = ''; if (lastFocus) lastFocus.focus(); }
    ov.addEventListener('click', e => { if (e.target === ov || e.target.closest('[data-close]')) closeDialog(); });
    document.addEventListener('keydown', e => { if (e.key === 'Escape' && !ov.hidden) closeDialog(); });
    document.addEventListener('click', async e => {
        const b = e.target.closest('[data-open]');
        if (!b) return;
        const a = adById(b.dataset.open);
        if (!a) return;
        const head = '<div class="row"><div class="grow"><h3 id="ov-title">' + esc(a.name) + '</h3><div class="faint">' + esc(a.campaign) + ' › ' + esc(a.adgroup) + '</div></div>'
            + '<button class="btn sm" data-close>Close</button></div>';
        openDialog(head + '<div class="media"><div class="muted"><span class="spinner"></span>Loading the creative…</div></div>');
        try {
            const m = await get({ action: 'media', platform: S.pf, id: a.id });
            if (ov.hidden) return;
            let h = '';
            (m.videos || []).forEach(v => {
                if (v.youtube_id) h += '<iframe src="https://www.youtube-nocookie.com/embed/' + encodeURIComponent(v.youtube_id) + '" title="' + esc(v.title || 'Video') + '" allow="encrypted-media; picture-in-picture" allowfullscreen></iframe>';
                else if (v.src) h += '<video src="' + esc(v.src) + '" controls playsinline preload="metadata"' + (v.poster ? ' poster="' + esc(v.poster) + '"' : '') + '></video>';
                else h += (v.poster ? IMG(v.poster, 'Video thumbnail') : '') + '<div class="faint">Meta did not give this login access to the video file' + (v.permalink ? ' — <a href="' + esc(v.permalink) + '" target="_blank" rel="noopener">watch it on Facebook</a>' : '') + '.</div>';
            });
            const imgs = m.images || [];
            if (!(m.videos || []).length && imgs.length === 1) h += IMG(imgs[0], 'Ad image');
            else if (imgs.length > 1 || ((m.videos || []).length && imgs.length)) h += '<div class="imgs">' + imgs.map(u => IMG(u, 'Ad image', true)).join('') + '</div>';
            const text = [m.title, m.body].filter(Boolean).join('\n\n') || [(m.headlines || []).join('\n'), (m.descriptions || []).join('\n')].filter(Boolean).join('\n\n');
            if (text) h += '<div class="copy">' + esc(text) + '</div>';
            if (!h) h = '<div class="muted">' + (S.pf === 'google' ? 'Google' : 'Meta') + ' returned no image, video or text for this ad.</div>';
            const links = (m.preview_url ? '<a class="btn" href="' + esc(m.preview_url) + '" target="_blank" rel="noopener">See it on Facebook</a>' : '')
                + (m.final_url ? '<a class="btn" href="' + esc(m.final_url) + '" target="_blank" rel="noopener">Landing page</a>' : '');
            box.querySelector('.media').innerHTML = h + (links ? '<div class="row">' + links + '</div>' : '');
        } catch (err) {
            if (!ov.hidden) box.querySelector('.media').innerHTML = '<div class="note bad">' + esc(err.message) + '</div>';
        }
    });

    /* ── rules (Super Admin) ── */
    const rb = $('#rules-btn');
    if (rb) rb.onclick = async () => {
        openDialog('<div class="muted"><span class="spinner"></span>Loading…</div>');
        try {
            const r = await get({ action: 'rules', platform: S.pf });
            box.innerHTML = '<h3 id="ov-title">Insights rules</h3><div class="faint">Thresholds the Insights &amp; Actions use. The benchmark is the target CPL / CPQL from Targets when one is set, else the platform\'s own average for the dates.</div>'
                + '<form id="rules-form"><div class="rules">' + r.defs.map(d => '<label for="r-' + d.key + '">' + esc(d.label) + '</label><input type="number" step="any" id="r-' + d.key + '" name="' + d.key + '" min="' + d.min + '" max="' + d.max + '" value="' + esc(r.rules[d.key]) + '">').join('') + '</div>'
                + '<div class="actions"><span class="faint grow" id="rules-msg"></span><button type="button" class="btn" data-close>Cancel</button><button type="button" class="btn" id="rules-reset">Defaults</button><button class="btn primary" type="submit">Save</button></div></form>';
            $('#rules-reset').onclick = () => r.defs.forEach(d => { $('#r-' + d.key).value = d.default; });
            $('#rules-form').onsubmit = async e => {
                e.preventDefault();
                const rules = Object.fromEntries(r.defs.map(d => [d.key, $('#r-' + d.key).value]));
                try {
                    const res = await fetch(API + '?action=rules&platform=' + S.pf, { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ rules }) });
                    const j = await res.json();
                    if (!j.success) throw new Error(j.error || 'Could not save.');
                    closeDialog(); load();
                } catch (err) { $('#rules-msg').textContent = err.message; }
            };
        } catch (err) { box.innerHTML = '<div class="note bad">' + esc(err.message) + '</div><div class="actions"><button class="btn" data-close>Close</button></div>'; }
    };

    // All / Performance / Awareness (same tabs and cookie as the dashboards; the server filters the campaigns)
    if (window.PQView) PQView.mount(document.getElementById('cv-host'), { onChange: () => load() });
    load();
})();
</script>
</body>
</html>
