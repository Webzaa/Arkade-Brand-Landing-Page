<?php
session_start();

if (isset($_SESSION["user_logged"]) && $_SESSION["user_logged"] == "Y") {
    header("Location: dashboard.php");
    exit;
}
require_once dirname(__DIR__) . '/app/bootstrap.php';
$project = defined('PROJECT_NAME') && trim((string) PROJECT_NAME) !== '' ? trim((string) PROJECT_NAME) : 'Webzaa Admin';
$h = fn($s) => htmlspecialchars((string) $s, ENT_QUOTES, 'UTF-8');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script>
        // Session ended while inside the dashboard shell's frame → show login full-window
        if (window.top !== window.self) { try { window.top.location.href = window.location.href; } catch (e) {} }
    </script>
    <title>Sign in · <?= $h($project) ?> · Webzaa</title>
    <link rel="icon" type="image/png" href="./assets/img/favicon.png">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=JetBrains+Mono:wght@600&display=swap" rel="stylesheet">
    <style>
        :root {
            --orange: #e84e24; --orange-2: #ff7a45; --orange-soft: #fff3ee; --orange-line: #fbd3c4;
            --ink: #1c1917; --ink-2: #44403c; --dim: #78716c; --faint: #a8a29e;
            --line: #e7e5e4; --bg: #fafaf9; --card: #ffffff;
            --good: #15803d; --good-soft: #ecfdf3; --bad: #b42318; --bad-soft: #fef3f2; --info-soft: #f5f5f4;
            --panel: #14100d;
        }
        @media (prefers-color-scheme: dark) {
            :root:not([data-theme="light"]) {
                --ink: #f5f5f4; --ink-2: #d6d3d1; --dim: #a8a29e; --faint: #78716c;
                --line: #2e2a27; --bg: #0f0d0b; --card: #181513; --orange-soft: #2a1710; --orange-line: #5a2a19;
                --good-soft: #0d2417; --bad-soft: #2c1210; --info-soft: #221f1c; --good: #4ade80; --bad: #f87171;
            }
        }
        * { box-sizing: border-box; }
        html, body { height: 100%; }
        body { margin: 0; font-family: 'Plus Jakarta Sans', system-ui, -apple-system, Segoe UI, sans-serif; background: var(--bg); color: var(--ink); -webkit-font-smoothing: antialiased; }
        .page { min-height: 100vh; display: grid; grid-template-columns: minmax(0, 1.08fr) minmax(0, 1fr); }

        /* ── left: brand panel ── */
        .brand { position: relative; overflow: hidden; background: var(--panel); color: #f5f5f4; padding: 44px 56px; display: flex; flex-direction: column; }
        .brand::before { content: ''; position: absolute; width: 760px; height: 760px; right: -260px; top: -280px; border-radius: 50%;
            background: radial-gradient(closest-side, rgba(232, 78, 36, .55), rgba(232, 78, 36, .12) 55%, transparent 72%); pointer-events: none; }
        .brand::after { content: ''; position: absolute; inset: 0; pointer-events: none; opacity: .5;
            background-image: linear-gradient(rgba(255,255,255,.045) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,.045) 1px, transparent 1px);
            background-size: 44px 44px; mask-image: linear-gradient(180deg, transparent, #000 30%, #000 70%, transparent); -webkit-mask-image: linear-gradient(180deg, transparent, #000 30%, #000 70%, transparent); }
        .brand > * { position: relative; z-index: 1; }
        .wordmark { font-weight: 800; font-size: 22px; letter-spacing: -.02em; color: #fff; display: flex; align-items: center; gap: 10px; }
        .wordmark { align-self: flex-start; }
        .wordmark img { display: block; height: 60px; width: auto; }
        .brand-main { margin: auto 0; max-width: 520px; padding: 40px 0; }
        .pill { display: inline-flex; align-items: center; gap: 8px; padding: 7px 14px 7px 10px; border-radius: 999px; background: rgba(255,255,255,.08); border: 1px solid rgba(255,255,255,.14); font-size: 13px; font-weight: 600; color: #fff; }
        .pill b { width: 8px; height: 8px; border-radius: 50%; background: #4ade80; box-shadow: 0 0 0 4px rgba(74, 222, 128, .18); }
        .brand h1 { font-size: clamp(34px, 3.6vw, 52px); line-height: 1.04; letter-spacing: -.035em; margin: 22px 0 16px; font-weight: 800; }
        .brand h1 em { font-style: normal; color: var(--orange-2); }
        .brand p.lead { color: #c9c3bd; font-size: 16px; line-height: 1.6; margin: 0; max-width: 440px; }

        /* decorative chart card — shapes only, no numbers */
        .viz { margin-top: 38px; background: rgba(255,255,255,.05); border: 1px solid rgba(255,255,255,.1); border-radius: 18px; padding: 18px 18px 12px; max-width: 470px; backdrop-filter: blur(6px); }
        .viz-top { display: flex; gap: 8px; flex-wrap: wrap; margin-bottom: 10px; }
        .chip { font-size: 11.5px; font-weight: 600; padding: 5px 10px; border-radius: 999px; background: rgba(255,255,255,.07); color: #e7e5e4; display: inline-flex; align-items: center; gap: 6px; }
        .chip s { width: 7px; height: 7px; border-radius: 2px; text-decoration: none; }
        .viz svg { display: block; width: 100%; height: auto; }
        .viz .ln { fill: none; stroke-width: 2.6; stroke-linecap: round; stroke-linejoin: round; stroke-dasharray: 700; stroke-dashoffset: 700; animation: draw 2.2s cubic-bezier(.3,.7,.2,1) forwards; }
        .viz .ln.b { animation-delay: .35s; }
        .viz .area { opacity: 0; animation: fade 1s .9s forwards; }
        .viz .dot { opacity: 0; animation: fade .4s 2.1s forwards; }
        .viz .bar { transform-origin: bottom; transform-box: fill-box; transform: scaleY(0); animation: grow .9s cubic-bezier(.3,.7,.2,1) forwards; }
        @keyframes draw { to { stroke-dashoffset: 0; } }
        @keyframes fade { to { opacity: 1; } }
        @keyframes grow { to { transform: scaleY(1); } }
        .brand-foot { display: flex; justify-content: space-between; gap: 16px; color: #8f8780; font-size: 12.5px; }

        /* ── right: form ── */
        .side { display: flex; flex-direction: column; padding: 32px 40px; }
        .side-top { display: flex; justify-content: flex-end; }
        .logo-chip { background: #fff; border-radius: 12px; padding: 6px 10px; border: 1px solid var(--line); display: inline-flex; }
        .logo-chip img { height: 34px; width: auto; display: block; }
        .form-wrap { margin: auto; width: 100%; max-width: 400px; padding: 28px 0; }
        .eyebrow { color: var(--orange); font-size: 11.5px; font-weight: 700; letter-spacing: .16em; text-transform: uppercase; }
        h2 { font-size: 30px; letter-spacing: -.03em; margin: 8px 0 8px; font-weight: 800; }
        .sub { color: var(--dim); font-size: 14.5px; line-height: 1.55; margin: 0 0 26px; }
        .sub b { color: var(--ink); font-weight: 700; word-break: break-all; }
        label.lbl { display: block; font-size: 13px; font-weight: 600; color: var(--ink-2); margin-bottom: 8px; }
        .field { position: relative; }
        .field svg { position: absolute; left: 15px; top: 50%; transform: translateY(-50%); color: var(--faint); pointer-events: none; }
        .field input { width: 100%; height: 52px; padding: 0 16px 0 46px; border-radius: 12px; border: 1.5px solid var(--line); background: var(--card); color: var(--ink);
            font: inherit; font-size: 15px; transition: border-color .15s, box-shadow .15s; }
        .field input::placeholder { color: var(--faint); }
        .field input:focus, .otp input:focus { outline: none; border-color: var(--orange); box-shadow: 0 0 0 4px rgba(232, 78, 36, .14); }
        .btn { width: 100%; height: 52px; border: 0; border-radius: 12px; font: inherit; font-size: 15px; font-weight: 700; cursor: pointer;
            display: inline-flex; align-items: center; justify-content: center; gap: 10px; transition: transform .12s, box-shadow .15s, background .15s; text-decoration: none; }
        .btn:active { transform: translateY(1px); }
        .btn-primary { background: var(--orange); color: #fff; margin-top: 16px; box-shadow: 0 8px 20px -8px rgba(232, 78, 36, .7); }
        .btn-primary:hover { background: #d9431b; box-shadow: 0 12px 24px -10px rgba(232, 78, 36, .8); }
        .btn-primary[disabled] { opacity: .65; cursor: default; box-shadow: none; }
        .btn-primary .arr { transition: transform .15s; } .btn-primary:hover .arr { transform: translateX(3px); }
        .btn-google { background: var(--card); color: var(--ink); border: 1.5px solid var(--line); }
        .btn-google:hover { border-color: var(--faint); }
        .btn-google img { width: 20px; height: 20px; }
        .or { display: flex; align-items: center; gap: 12px; color: var(--faint); font-size: 12.5px; margin: 22px 0; }
        .or::before, .or::after { content: ''; flex: 1; height: 1px; background: var(--line); }
        .spin { width: 17px; height: 17px; border-radius: 50%; border: 2.5px solid rgba(255,255,255,.4); border-top-color: #fff; animation: rot .7s linear infinite; }
        @keyframes rot { to { transform: rotate(360deg); } }

        .otp { display: grid; grid-template-columns: repeat(6, 1fr); gap: 10px; }
        .otp input { width: 100%; height: 60px; text-align: center; border-radius: 12px; border: 1.5px solid var(--line); background: var(--card); color: var(--ink);
            font-family: 'JetBrains Mono', ui-monospace, monospace; font-size: 26px; font-weight: 600; transition: border-color .15s, box-shadow .15s, background .15s; caret-color: var(--orange); }
        .otp input.filled { border-color: var(--orange-line); background: var(--orange-soft); }
        .otp.shake { animation: shake .4s; }
        @keyframes shake { 20%, 60% { transform: translateX(-6px); } 40%, 80% { transform: translateX(6px); } }
        .row-links { display: flex; justify-content: space-between; align-items: center; margin-top: 18px; font-size: 13.5px; }
        .link { background: none; border: 0; padding: 0; font: inherit; color: var(--dim); cursor: pointer; font-weight: 600; }
        .link:hover { color: var(--ink); }
        .link.orange { color: var(--orange); } .link[disabled] { color: var(--faint); cursor: default; }

        .msg { margin-top: 16px; font-size: 13.5px; line-height: 1.5; border-radius: 10px; padding: 11px 14px; display: none; }
        .msg.show { display: block; }
        .msg.bad { background: var(--bad-soft); color: var(--bad); }
        .msg.good { background: var(--good-soft); color: var(--good); }
        .msg.info { background: var(--info-soft); color: var(--ink-2); }
        .step { animation: in .35s ease both; }
        .hidden { display: none !important; }
        @keyframes in { from { opacity: 0; transform: translateY(8px); } }
        .foot-note { color: var(--faint); font-size: 12.5px; text-align: center; margin-top: 26px; line-height: 1.5; }
        .foot-note svg { vertical-align: -2px; margin-right: 4px; }

        @media (max-width: 960px) {
            .page { grid-template-columns: 1fr; }
            .brand { padding: 26px 22px 30px; }
            .brand-main { padding: 22px 0 0; margin: 0; }
            .brand h1 { font-size: 30px; margin: 16px 0 10px; }
            .brand p.lead { font-size: 14.5px; }
            .viz, .brand-foot { display: none; }
            .side { padding: 22px 16px 32px; }
            .side-top { display: none; }
            .form-wrap { padding: 10px 0; }
        }
        @media (max-width: 400px) { .otp { gap: 6px; } .otp input { height: 52px; font-size: 22px; } }
        @media (prefers-reduced-motion: reduce) { *, *::before, *::after { animation: none !important; transition: none !important; } .viz .ln { stroke-dashoffset: 0; } .viz .area, .viz .dot { opacity: 1; } .viz .bar { transform: none; } }
    </style>
</head>
<body>
<div class="page">

    <!-- brand panel -->
    <aside class="brand">
        <div class="wordmark"><img src="assets/images/webzaa-logo.png" alt="Webzaa" width="83" height="60"></div>
        <div class="brand-main">
            <div class="pill"><b></b><?= $h($project) ?></div>
            <h1>Every rupee.<br>Every lead.<br><em>One dashboard.</em></h1>
            <p class="lead">Meta and Google spend, leads, CRM status and the daily, weekly and monthly reports for <?= $h($project) ?> — in one place.</p>
            <div class="viz" aria-hidden="true">
                <div class="viz-top">
                    <span class="chip"><s style="background:#ff7a45"></s>Spend</span>
                    <span class="chip"><s style="background:#f5f5f4"></s>Leads</span>
                    <span class="chip"><s style="background:#4ade80"></s>Qualified</span>
                </div>
                <svg viewBox="0 0 440 150">
                    <defs>
                        <linearGradient id="ga" x1="0" x2="0" y1="0" y2="1"><stop offset="0" stop-color="#ff7a45" stop-opacity=".38"/><stop offset="1" stop-color="#ff7a45" stop-opacity="0"/></linearGradient>
                    </defs>
                    <g stroke="rgba(255,255,255,.07)"><line x1="0" x2="440" y1="30" y2="30"/><line x1="0" x2="440" y1="70" y2="70"/><line x1="0" x2="440" y1="110" y2="110"/></g>
                    <g fill="rgba(74,222,128,.55)">
                        <rect class="bar" x="18" y="112" width="18" height="30" rx="4" style="animation-delay:.2s"/>
                        <rect class="bar" x="78" y="104" width="18" height="38" rx="4" style="animation-delay:.3s"/>
                        <rect class="bar" x="138" y="116" width="18" height="26" rx="4" style="animation-delay:.4s"/>
                        <rect class="bar" x="198" y="96" width="18" height="46" rx="4" style="animation-delay:.5s"/>
                        <rect class="bar" x="258" y="100" width="18" height="42" rx="4" style="animation-delay:.6s"/>
                        <rect class="bar" x="318" y="86" width="18" height="56" rx="4" style="animation-delay:.7s"/>
                        <rect class="bar" x="378" y="78" width="18" height="64" rx="4" style="animation-delay:.8s"/>
                    </g>
                    <path class="area" fill="url(#ga)" d="M0 96 C40 90 60 70 100 74 S170 96 210 72 S280 40 320 48 S400 26 440 18 L440 150 L0 150 Z"/>
                    <path class="ln" stroke="#ff7a45" d="M0 96 C40 90 60 70 100 74 S170 96 210 72 S280 40 320 48 S400 26 440 18"/>
                    <path class="ln b" stroke="rgba(245,245,244,.85)" stroke-dasharray="4 7" d="M0 118 C50 112 80 100 120 104 S200 92 240 86 S320 70 360 62 S420 52 440 46"/>
                    <circle class="dot" cx="440" cy="18" r="5" fill="#ff7a45" stroke="#14100d" stroke-width="3"/>
                </svg>
            </div>
        </div>
        <div class="brand-foot"><span>© <?= date('Y') ?> Webzaa</span><span>Performance marketing · Real estate</span></div>
    </aside>

    <!-- form -->
    <main class="side">
        <div class="form-wrap">

            <!-- step 1: email -->
            <section id="step-email" class="step">
                <div class="eyebrow">Admin login</div>
                <h2>Welcome back</h2>
                <p class="sub">Sign in to the <b><?= $h($project) ?></b> admin. We'll email you a 6-digit code — no password needed.</p>
                <form id="email-form" novalidate>
                    <label class="lbl" for="email">Work email</label>
                    <div class="field">
                        <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="5" width="18" height="14" rx="2.5"/><path d="m4 7 8 6 8-6"/></svg>
                        <input type="email" id="email" name="email" placeholder="name@company.com" autocomplete="email" inputmode="email" autofocus>
                    </div>
                    <button type="submit" class="btn btn-primary" id="send-btn"><span>Send login code</span><span class="arr">→</span></button>
                </form>
                <div class="or">or</div>
                <a href="google_callback.php" class="btn btn-google">
                    <svg width="20" height="20" viewBox="0 0 48 48" aria-hidden="true"><path fill="#FFC107" d="M43.6 20.5H42V20H24v8h11.3C33.7 32.7 29.2 36 24 36c-6.6 0-12-5.4-12-12s5.4-12 12-12c3.1 0 5.8 1.2 7.9 3.1l5.7-5.7C34 6.1 29.3 4 24 4 12.9 4 4 12.9 4 24s8.9 20 20 20 20-8.9 20-20c0-1.3-.1-2.4-.4-3.5z"/><path fill="#FF3D00" d="m6.3 14.7 6.6 4.8C14.7 15.1 19 12 24 12c3.1 0 5.8 1.2 7.9 3.1l5.7-5.7C34 6.1 29.3 4 24 4 16.3 4 9.7 8.3 6.3 14.7z"/><path fill="#4CAF50" d="M24 44c5.2 0 9.9-2 13.4-5.2l-6.2-5.2C29.2 35.1 26.7 36 24 36c-5.2 0-9.6-3.3-11.3-8l-6.5 5C9.5 39.6 16.2 44 24 44z"/><path fill="#1976D2" d="M43.6 20.5H42V20H24v8h11.3c-.8 2.2-2.2 4.2-4.1 5.6l6.2 5.2C37 39.2 44 34 44 24c0-1.3-.1-2.4-.4-3.5z"/></svg>
                    Continue with Google
                </a>
            </section>

            <!-- step 2: code -->
            <section id="step-code" class="step hidden">
                <div class="eyebrow">Check your inbox</div>
                <h2>Enter your code</h2>
                <p class="sub">We sent a 6-digit code to <b id="sent-to"></b>. It's valid for 5 minutes.</p>
                <form id="code-form" novalidate>
                    <div class="otp" id="otp">
                        <?php for ($i = 0; $i < 6; $i++) { ?><input type="text" inputmode="numeric" pattern="[0-9]*" aria-label="Digit <?= $i + 1 ?>" <?= $i === 0 ? 'autocomplete="one-time-code"' : 'autocomplete="off"' ?>><?php } ?>
                    </div>
                    <button type="submit" class="btn btn-primary" id="verify-btn"><span>Verify &amp; sign in</span><span class="arr">→</span></button>
                </form>
                <div class="row-links">
                    <button type="button" class="link" id="change-email">← Use a different email</button>
                    <button type="button" class="link orange" id="resend">Resend code</button>
                </div>
            </section>

            <div class="msg" id="msg" role="status" aria-live="polite"></div>

            <p class="foot-note"><svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/></svg>Only registered team members can sign in. Trouble? Ask your Webzaa admin.</p>
        </div>
    </main>
</div>

<script>
(function () {
    'use strict';
    const $ = s => document.querySelector(s);
    const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
    const boxes = Array.from(document.querySelectorAll('#otp input'));
    let email = '', timer = null;

    function msg(text, kind) {
        const m = $('#msg');
        m.className = 'msg' + (text ? ' show ' + (kind || 'bad') : '');
        m.innerHTML = text || '';
    }
    function busy(btn, label) {
        const old = btn.innerHTML;
        btn.disabled = true;
        btn.innerHTML = `<span class="spin"></span><span>${label}</span>`;
        return () => { btn.disabled = false; btn.innerHTML = old; };
    }
    async function post(url, data) {
        const res = await fetch(url, { method: 'POST', credentials: 'same-origin', body: new URLSearchParams(data) });
        return (await res.text()).trim();
    }
    const store = { get() { try { return localStorage.getItem('pq_login_email') || ''; } catch (e) { return ''; } },
                    set(v) { try { localStorage.setItem('pq_login_email', v); } catch (e) {} } };

    // Google login errors (?google_error=…)
    const errors = { not_registered: 'This Google account is not registered for this admin.', blocked: 'Your account is blocked. Contact your admin.',
                     token_failed: 'Google login failed. Please try again.', userinfo_failed: 'Could not read your Google account. Please try again.',
                     no_email: 'Your Google account has no email address.' };
    const ge = new URLSearchParams(location.search).get('google_error');
    if (ge && errors[ge]) { msg(errors[ge], 'bad'); history.replaceState(null, '', 'login.php'); }
    $('#email').value = store.get();

    function showStep(which) {
        $('#step-email').classList.toggle('hidden', which !== 'email');
        $('#step-code').classList.toggle('hidden', which !== 'code');
        if (which === 'code') { boxes.forEach(b => { b.value = ''; b.classList.remove('filled'); }); setTimeout(() => boxes[0].focus(), 50); }
        else setTimeout(() => $('#email').focus(), 50);
    }
    function startCooldown(sec) {
        const r = $('#resend');
        clearInterval(timer);
        let left = sec;
        r.disabled = true;
        r.textContent = `Resend in ${left}s`;
        timer = setInterval(() => {
            left--;
            if (left <= 0) { clearInterval(timer); r.disabled = false; r.textContent = 'Resend code'; }
            else r.textContent = `Resend in ${left}s`;
        }, 1000);
    }

    async function sendCode(btn, isResend) {
        const done = busy(btn, isResend ? 'Sending…' : 'Sending code…');
        try {
            const res = await post('leads/ajax_send_otp.php', { email });
            if (res === 'sent') {
                store.set(email);
                $('#sent-to').textContent = email;
                if (!isResend) showStep('code');
                msg(isResend ? 'A new code is on its way. The old one no longer works.' : '', 'good');
                startCooldown(30);
            } else msg(esc(res || 'Could not send the code. Please try again.'), 'bad');
        } catch (e) { msg('Network error — check your connection and try again.', 'bad'); }
        finally { done(); if (isResend) { const r = $('#resend'); if (!timer) r.disabled = false; } }
    }

    $('#email-form').addEventListener('submit', e => {
        e.preventDefault();
        email = $('#email').value.trim();
        if (!email) return msg('Enter your email address.', 'bad');
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) return msg('That email doesn\'t look right.', 'bad');
        sendCode($('#send-btn'), false);
    });
    $('#resend').addEventListener('click', () => { if (email) sendCode($('#resend'), true); });
    $('#change-email').addEventListener('click', () => { clearInterval(timer); timer = null; msg(''); showStep('email'); });

    // six digit boxes: type, backspace, arrows, paste
    const code = () => boxes.map(b => b.value).join('');
    function fill(from, digits) {
        digits.split('').forEach((d, k) => { const b = boxes[from + k]; if (b) { b.value = d; b.classList.add('filled'); } });
        const next = boxes.find(b => !b.value);
        (next || boxes[5]).focus();
        if (code().length === 6) verify();
    }
    boxes.forEach((b, i) => {
        b.addEventListener('input', () => {
            const d = b.value.replace(/\D/g, '');
            b.value = '';
            b.classList.remove('filled');
            if (d) fill(i, d.slice(0, 6 - i));
        });
        b.addEventListener('keydown', e => {
            if (e.key === 'Backspace' && !b.value && i > 0) { boxes[i - 1].value = ''; boxes[i - 1].classList.remove('filled'); boxes[i - 1].focus(); e.preventDefault(); }
            else if (e.key === 'ArrowLeft' && i > 0) boxes[i - 1].focus();
            else if (e.key === 'ArrowRight' && i < 5) boxes[i + 1].focus();
        });
        b.addEventListener('paste', e => {
            const d = (e.clipboardData || window.clipboardData).getData('text').replace(/\D/g, '').slice(0, 6);
            if (d) { e.preventDefault(); boxes.forEach(x => { x.value = ''; x.classList.remove('filled'); }); fill(0, d); }
        });
        b.addEventListener('focus', () => b.select());
    });

    let verifying = false;
    async function verify() {
        if (verifying) return;
        const otp = code();
        if (otp.length !== 6) { msg('Enter all 6 digits of the code.', 'bad'); return; }
        verifying = true;
        const done = busy($('#verify-btn'), 'Signing in…');
        try {
            const res = await post('leads/ajax_verify_otp.php', { email, otp });
            if (res === 'success') { msg('Signed in — opening the dashboard…', 'good'); location.href = 'dashboard.php'; return; }
            msg(esc(res === 'OTP expired or incorrect' ? 'That code is wrong or has expired. Check the latest email, or resend the code.' : res), 'bad');
            const g = $('#otp'); g.classList.remove('shake'); void g.offsetWidth; g.classList.add('shake');
            boxes.forEach(x => { x.value = ''; x.classList.remove('filled'); }); boxes[0].focus();
        } catch (e) { msg('Network error — check your connection and try again.', 'bad'); }
        finally { verifying = false; done(); }
    }
    $('#code-form').addEventListener('submit', e => { e.preventDefault(); verify(); });
})();
</script>
</body>
</html>
