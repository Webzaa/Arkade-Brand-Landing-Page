<?php
/**
 * lp_hygiene_api.php — backend of LP Hygiene (lp_hygiene.php). Logic: app/Tools/lp_hygiene.php.
 *
 *   GET  ?action=pages                                   landing pages + latest results + test defaults
 *   GET  ?action=page&id=N                               one page: latest PageSpeed / checks / test leads + history
 *   GET  ?action=meta_forms                              this project's Meta lead forms (from the leads)
 *   GET  ?action=find_lead&since=…&email=…&mobile=…&leadgen_id=…   did the test lead reach the lead table / CRM?
 *   POST ?action=save_page {id?, name, url, form?}       add / edit a landing page              (Edit pages)
 *   POST ?action=delete_page {id}                                                                (Edit pages)
 *   POST ?action=pagespeed {id, strategy: mobile|desktop}                                       (Run checks)
 *   POST ?action=scan {id}                               page checks + form detection           (Run checks)
 *   POST ?action=meta_test {id, form_id, page_id, name, email, mobile}                          (Meta test leads)
 *   POST ?action=lp_test {id, name, email, mobile, form?: {endpoint, method, fields, extra}}    (Landing page test leads)
 *
 * Access: Users & Roles → LP Hygiene (app/Core/access.php). Access tokens never appear in a response.
 */
require_once dirname(__DIR__) . '/app/Core/db.php';      // sign-in + roles & permissions
require_once dirname(__DIR__) . '/app/Tools/lp_hygiene.php';

function lphJson(array $out, int $code = 200): never
{
    while (ob_get_level() > 0) {
        @ob_end_clean();
    }
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    echo json_encode($out, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PARTIAL_OUTPUT_ON_ERROR | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}

/** Removes anything that looks like an access token from a result (belt and braces). */
function lphRedact($v)
{
    if (is_array($v)) {
        $o = [];
        foreach ($v as $k => $x) {
            $o[$k] = (is_string($k) && preg_match('/access_token|appsecret|client_secret|api_key|page_token/i', $k)) ? '••• hidden' : lphRedact($x);
        }
        return $o;
    }
    if (is_string($v)) {
        return preg_replace(['/\bEAA[A-Za-z0-9]{20,}/', '/(access_token|key)=[^&\s"]+/i'], ['EAA••• hidden', '$1=••• hidden'], $v);
    }
    return $v;
}

/**
 * Users & Roles → "Full mobile numbers on screen": without it every Indian mobile in a result (test values, Graph API
 * requests / answers, form data, CRM replies) shows only its last 5 digits — *****43210. IDs (15+ digits) are left alone.
 */
function lphMaskMobiles($v)
{
    if (pqContactAllowed('mobile')) {
        return $v;
    }
    if (is_array($v)) {
        return array_map('lphMaskMobiles', $v);
    }
    if (!is_string($v)) {
        return $v;
    }
    return preg_replace_callback('/(?<![\d*])(?:\+?91[\s-]?)?[6-9]\d{4}[\s-]?\d{5}(?!\d)/', fn($m) => pqMaskMobile($m[0]), $v);
}

$action = (string) ($_GET['action'] ?? 'pages');
$isPost = ($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST';
$in = $isPost ? (json_decode((string) file_get_contents('php://input'), true) ?: $_POST) : $_GET;
$user = (string) ($_SESSION['username'] ?? $_SESSION['user'] ?? 'user');
$posts = ['save_page', 'delete_page', 'pagespeed', 'scan', 'meta_test', 'lp_test'];
if (in_array($action, $posts, true) && !$isPost) {
    lphJson(['success' => false, 'error' => 'Use POST.'], 405);
}

try {
    switch ($action) {
        case 'pages':
            $pages = lphPages();
            foreach ($pages as &$p) {
                $runs = lphRuns($p['id']);
                $l = $runs['latest'];
                $p['last'] = [
                    'mobile' => isset($l['psi_mobile']) ? ['at' => $l['psi_mobile']['at'], 'scores' => $l['psi_mobile']['result']['scores'] ?? []] : null,
                    'desktop' => isset($l['psi_desktop']) ? ['at' => $l['psi_desktop']['at'], 'scores' => $l['psi_desktop']['result']['scores'] ?? []] : null,
                    'scan' => isset($l['scan']) ? ['at' => $l['scan']['at'], 'counts' => array_count_values(array_column($l['scan']['result']['checks'] ?? [], 'status'))] : null,
                    'meta_test' => isset($l['meta_test']) ? ['at' => $l['meta_test']['at'], 'ok' => (bool) ($l['meta_test']['result']['ok'] ?? false)] : null,
                    'lp_test' => isset($l['lp_test']) ? ['at' => $l['lp_test']['at'], 'ok' => (bool) ($l['lp_test']['result']['ok'] ?? false)] : null,
                ];
            }
            unset($p);
            $mob = lphTestMobile();
            lphJson(['success' => true, 'pages' => $pages,
                     'can' => ['run' => pqCan('lphygiene', 'run'), 'edit' => pqCan('lphygiene', 'edit'), 'meta_test' => pqCan('lphygiene', 'meta_test'),
                               'lp_test' => pqCan('lphygiene', 'lp_test'), 'pdf' => pqCan('lphygiene', 'pdf')],
                     // the remembered team number only for users who may see full mobiles; others type it each time
                     'defaults' => lphTestValues(preg_replace('/@.*/', '', $user), pqContactAllowed('mobile') ? $mob : ''),
                     'psi_key' => defined('PAGESPEED_API_KEY') && trim((string) PAGESPEED_API_KEY) !== '',
                     'meta_ready' => lphMetaToken() !== '', 'project' => defined('PROJECT_NAME') ? (string) PROJECT_NAME : '']);

        case 'page':
            $p = lphPage((int) ($in['id'] ?? 0));
            lphJson(['success' => true, 'page' => $p] + lphMaskMobiles(lphRedact(lphRuns($p['id']))));

        case 'meta_forms':
            lphJson(['success' => true, 'forms' => lphMetaForms(), 'meta_ready' => lphMetaToken() !== '']);

        case 'find_lead':
            $since = (string) ($in['since'] ?? '');
            if (!preg_match('/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/', $since)) {
                $since = date('Y-m-d H:i:s', time() - 3600);
            }
            // a minute of slack for a server clock that runs behind
            $since = date('Y-m-d H:i:s', strtotime($since) - 120);
            $email = trim((string) ($in['email'] ?? ''));
            if ($email !== '' && stripos($email, 'test') === false) {
                lphJson(['success' => false, 'error' => 'Only test leads can be looked up here.'], 400);
            }
            lphJson(['success' => true, 'leads' => lphMaskMobiles(lphRedact(lphFindLead($since, $email, (string) ($in['mobile'] ?? ''), preg_replace('/\D/', '', (string) ($in['leadgen_id'] ?? ''))))), 'checked_at' => date('Y-m-d H:i:s')]);

        case 'save_page':
            lphJson(['success' => true] + lphSavePage($in, $user));

        case 'delete_page':
            lphDeletePage((int) ($in['id'] ?? 0));
            lphJson(['success' => true]);

        case 'pagespeed':
            @set_time_limit(200);
            $p = lphPage((int) ($in['id'] ?? 0));
            $strategy = ($in['strategy'] ?? '') === 'desktop' ? 'desktop' : 'mobile';
            $r = lphPageSpeed($p['url'], $strategy);
            $perf = $r['scores']['performance']['score'] ?? null;
            $r['run_id'] = lphSaveRun($p['id'], 'psi_' . $strategy, $perf !== null && $perf >= 50, ucfirst($strategy) . ' performance ' . ($perf ?? '—'), $r, $user);
            $r['at'] = date('Y-m-d H:i:s');
            lphJson(['success' => true, 'result' => $r]);

        case 'scan':
            @set_time_limit(90);
            $p = lphPage((int) ($in['id'] ?? 0));
            $r = lphScan($p['url']);
            $c = array_count_values(array_column($r['checks'], 'status'));
            // first lead form found → the page's test-lead form, unless one was set by hand
            $lead = array_values(array_filter($r['forms'], fn($f) => $f['is_lead_form']))[0] ?? null;
            if ($lead && empty($p['form']['endpoint'])) {
                lphSavePage(['id' => $p['id'], 'name' => $p['name'], 'url' => $p['url'], 'form' => [
                    'endpoint' => $lead['action'], 'method' => $lead['method'], 'fields' => $lead['map'], 'extra' => $lead['hidden']]], $user);
                $r['form_saved'] = true;
            }
            $r['run_id'] = lphSaveRun($p['id'], 'scan', ($c['fail'] ?? 0) === 0, ($c['pass'] ?? 0) . ' passed, ' . ($c['warn'] ?? 0) . ' warnings, ' . ($c['fail'] ?? 0) . ' failed', $r, $user);
            $r['at'] = date('Y-m-d H:i:s');
            $r['page'] = lphPage($p['id']);
            lphJson(['success' => true, 'result' => $r]);

        case 'meta_test':
            @set_time_limit(120);
            $p = lphPage((int) ($in['id'] ?? 0));
            $r = lphMetaTest(trim((string) ($in['form_id'] ?? '')), trim((string) ($in['page_id'] ?? '')), $in);
            lphTestMobile($r['values']['mobile'], $user);
            $r = lphRedact($r);
            $r['run_id'] = lphSaveRun($p['id'], 'meta_test', $r['ok'], ($r['ok'] ? 'Meta test lead ' . $r['lead_id'] : 'Meta test lead failed: ' . $r['error']) . ' · ' . $r['values']['email'], $r, $user);
            lphJson(['success' => true, 'result' => lphMaskMobiles($r)]);

        case 'lp_test':
            @set_time_limit(90);
            $p = lphPage((int) ($in['id'] ?? 0));
            $r = lphLpTest($p, $in, is_array($in['form'] ?? null) ? $in['form'] : []);
            lphTestMobile($r['values']['mobile'], $user);
            $r = lphRedact($r);
            $r['run_id'] = lphSaveRun($p['id'], 'lp_test', $r['ok'], 'Landing page test lead · HTTP ' . $r['http'] . ' · ' . $r['values']['email'], $r, $user);
            lphJson(['success' => true, 'result' => lphMaskMobiles($r)]);

        default:
            lphJson(['success' => false, 'error' => 'Unknown action.'], 400);
    }
} catch (InvalidArgumentException $e) {
    lphJson(['success' => false, 'error' => $e->getMessage()], 400);
} catch (Throwable $e) {
    error_log('[lp_hygiene_api] ' . $e->getMessage() . ' @ ' . $e->getFile() . ':' . $e->getLine());
    lphJson(['success' => false, 'error' => lphRedact($e->getMessage())], 500);
}
