<?php
/**
 * crm_push.php — how many leads reached the CRM, and which ones failed / were never sent (with the
 * reason in plain words). Failed / not-sent Meta and Google leads can be sent again ("Send to CRM").
 * Backend: crm_push_api.php, logic: app/Leads/crm_push.php + app/Leads/crm_send.php.
 */
session_start();
if (($_SESSION['user_logged'] ?? '') !== 'Y') {
    header('Location: login.php');
    exit;
}
require_once dirname(__DIR__) . '/app/Core/db.php';
$h = fn($v) => htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');
$dbs = [];
foreach (leadDbKeys() as $k) {
    $dbs[$k] = leadDbLabel($k);
}
$defaultDb = appDbKey();
?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>CRM Push</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Sora:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
<script>
(function () {
    var root = document.documentElement, t = null;
    try { t = localStorage.getItem('performiq-theme'); } catch (e) {}
    root.setAttribute('data-theme', t === 'light' ? 'light' : 'dark');
    if (/[?&]embed=1(&|$)/.test(location.search)) root.classList.add('pq-embed');
    window.addEventListener('storage', function (e) {
        if (e.key === 'performiq-theme') root.setAttribute('data-theme', e.newValue === 'light' ? 'light' : 'dark');
    });
    window.setTheme = function (t) { root.setAttribute('data-theme', t === 'light' ? 'light' : 'dark'); };
})();
</script>
<style>
    :root, html[data-theme="dark"] {
        --bg: #0B0F1A; --surface: #111827; --surface-2: #161D2E; --border: #1E2A42; --border-strong: #2A3957;
        --text: #E2E8F0; --text-dim: #94A3B8; --text-faint: #64748B; --accent: #E8A820; --accent-soft: #E8A8201F;
        --hover: #1A2337; --good: #10B981; --good-soft: #10B9811F; --bad: #EF4444; --bad-soft: #EF44441A;
        --warn: #F59E0B; --warn-soft: #F59E0B1A; --meta: #3987E5; --meta-soft: #3987E51F; --google: #D95926; --google-soft: #D959261F; color-scheme: dark;
    }
    html[data-theme="light"] {
        --bg: #F4F6FA; --surface: #FFFFFF; --surface-2: #F8FAFC; --border: #E2E8F0; --border-strong: #CBD5E1;
        --text: #0F172A; --text-dim: #475569; --text-faint: #94A3B8; --accent: #B7791F; --accent-soft: #B7791F1A;
        --hover: #F1F5F9; --good: #059669; --good-soft: #0596691A; --bad: #DC2626; --bad-soft: #DC26261A;
        --warn: #B45309; --warn-soft: #B453091A; --meta: #2A78D6; --meta-soft: #2A78D61A; --google: #C2410C; --google-soft: #C2410C1A; color-scheme: light;
    }
    * { box-sizing: border-box; }
    body { margin: 0; background: var(--bg); color: var(--text); font: 14px/1.5 'Sora', system-ui, -apple-system, 'Segoe UI', sans-serif; }
    button, input, select { font: inherit; color: inherit; }
    .mono { font-family: 'JetBrains Mono', ui-monospace, monospace; font-variant-numeric: tabular-nums; }
    .wrap { max-width: 1400px; margin: 0 auto; padding: 28px 24px 60px; }
    .pq-embed .wrap { padding-top: 20px; }
    .pq-embed .page-head { display: none; }
    h1 { font-size: 22px; margin: 0 0 4px; }
    .sub { color: var(--text-dim); margin: 0 0 20px; font-size: 13px; }
    .card { background: var(--surface); border: 1px solid var(--border); border-radius: 12px; padding: 18px 20px; margin-bottom: 16px; }
    .bar { display: flex; gap: 10px; align-items: center; flex-wrap: wrap; }
    .bar .grow { flex: 1 1 220px; }
    select, input[type=text], input[type=date], input[type=search] { background: var(--surface-2); border: 1px solid var(--border-strong); border-radius: 8px; padding: 8px 10px; outline: none; min-width: 0; }
    select:focus, input:focus { border-color: var(--accent); }
    .btn { border: 1px solid var(--border-strong); background: var(--surface-2); padding: 8px 14px; border-radius: 8px; cursor: pointer; font-weight: 600; font-size: 13px; white-space: nowrap; }
    .btn:hover { background: var(--hover); }
    .btn.primary { background: var(--accent); border-color: var(--accent); color: #111; }
    .btn.sm { padding: 5px 10px; font-size: 12px; }
    .btn.ghost-bad { color: var(--bad); }
    .btn.danger { background: var(--bad); border-color: var(--bad); color: #fff; }
    .btn:disabled { opacity: .5; cursor: not-allowed; }
    .tabs { display: flex; gap: 6px; flex-wrap: wrap; }
    .tab { border: 1px solid var(--border); background: var(--surface-2); border-radius: 99px; padding: 6px 14px; font-size: 12.5px; cursor: pointer; color: var(--text-dim); font-weight: 600; }
    .tab.on { border-color: var(--accent); color: var(--text); background: var(--accent-soft); }
    .tab b { margin-left: 4px; font-family: 'JetBrains Mono', monospace; }
    .tbl-wrap { overflow: auto; border: 1px solid var(--border); border-radius: 10px; }
    table { width: 100%; border-collapse: collapse; font-size: 12.5px; }
    th { position: sticky; top: 0; z-index: 1; background: var(--surface-2); color: var(--text-dim); font-weight: 600; text-align: left; padding: 9px 10px;
         border-bottom: 1px solid var(--border); white-space: nowrap; font-size: 11px; text-transform: uppercase; letter-spacing: .04em; }
    td { padding: 9px 10px; border-bottom: 1px solid var(--border); vertical-align: top; }
    tr:last-child td { border-bottom: 0; }
    tr.sel td { background: var(--accent-soft); }
    td.chk, th.chk { width: 34px; text-align: center; }
    input[type=checkbox] { accent-color: var(--accent); width: 15px; height: 15px; }
    .pill { display: inline-block; padding: 1px 8px; border-radius: 99px; font-size: 11px; font-weight: 600; white-space: nowrap; }
    .pill.meta { color: var(--meta); background: var(--meta-soft); }
    .pill.google { color: var(--google); background: var(--google-soft); }
    .pill.unknown { color: var(--text-dim); background: var(--surface-2); border: 1px solid var(--border); }
    .pill.warn { color: var(--warn); background: var(--warn-soft); }
    .pill.bad { color: var(--bad); background: var(--bad-soft); }
    .muted { color: var(--text-dim); }
    .faint { color: var(--text-faint); font-size: 11.5px; }
    .map { display: grid; grid-template-columns: repeat(3, minmax(130px, 1fr)) auto; gap: 6px; align-items: center; min-width: 500px; }
    .map select { width: 100%; padding: 6px 8px; font-size: 12px; }
    .map .plat { grid-column: 1 / -1; display: flex; gap: 6px; align-items: center; }
    .note { padding: 11px 14px; border-radius: 10px; font-size: 12.5px; margin-bottom: 14px; border: 1px solid; }
    .note.warn { background: var(--warn-soft); border-color: var(--warn); }
    .note.bad { background: var(--bad-soft); border-color: var(--bad); }
    .note.good { background: var(--good-soft); border-color: var(--good); }
    .bulk { position: sticky; bottom: 12px; z-index: 5; display: flex; gap: 10px; align-items: center; flex-wrap: wrap; background: var(--surface);
            border: 1px solid var(--accent); border-radius: 12px; padding: 10px 14px; box-shadow: 0 10px 30px rgba(0, 0, 0, .35); margin-top: 12px; }
    .pager { display: flex; justify-content: space-between; align-items: center; gap: 10px; flex-wrap: wrap; margin-top: 12px; font-size: 12px; color: var(--text-dim); }
    .pager button { border: 1px solid var(--border); background: var(--surface-2); border-radius: 6px; padding: 4px 10px; cursor: pointer; font-size: 11px; color: var(--text-dim); }
    .pager button.on { background: var(--accent); border-color: var(--accent); color: #111; font-weight: 700; }
    .hidden { display: none !important; }
    .overlay { position: fixed; inset: 0; background: rgba(2, 6, 23, .6); display: grid; place-items: center; z-index: 50; padding: 16px; }
    .dialog { background: var(--surface); border: 1px solid var(--border-strong); border-radius: 14px; padding: 22px; max-width: 620px; width: 100%; max-height: 90vh; overflow: auto; box-shadow: 0 20px 60px rgba(0, 0, 0, .45); }
    .dialog h3 { margin: 0 0 8px; font-size: 17px; }
    .actions { display: flex; justify-content: flex-end; gap: 10px; margin-top: 18px; flex-wrap: wrap; }
    .spinner { width: 15px; height: 15px; border: 2px solid var(--border-strong); border-top-color: var(--accent); border-radius: 50%; display: inline-block; animation: spin .8s linear infinite; vertical-align: -3px; margin-right: 8px; }
    @keyframes spin { to { transform: rotate(360deg); } }
    .toast { position: fixed; right: 24px; bottom: 24px; z-index: 60; background: var(--surface); border: 1px solid var(--border-strong); border-left: 4px solid var(--good);
             padding: 12px 16px; border-radius: 8px; font-size: 13px; box-shadow: 0 10px 30px rgba(0, 0, 0, .35); max-width: 440px; }
    .toast.bad { border-left-color: var(--bad); }
    @media (max-width: 760px) { .wrap { padding: 16px; } }
    .pill.bad { color: var(--bad); background: var(--bad-soft); }
    .pill.good { color: var(--good); background: var(--good-soft); }
    .tiles { display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 10px; margin-bottom: 16px; }
    .tile { background: var(--surface); border: 1px solid var(--border); border-radius: 12px; padding: 14px 16px; cursor: pointer; text-align: left; }
    .tile:hover { background: var(--hover); }
    .tile.on { border-color: var(--accent); box-shadow: 0 0 0 1px var(--accent) inset; }
    .tile div { color: var(--text-dim); font-size: 12px; }
    .tile strong { display: block; font-size: 24px; margin-top: 2px; }
    .tile small { color: var(--text-faint); font-size: 11px; }
    .tile.bad strong { color: var(--bad); } .tile.good strong { color: var(--good); } .tile.warn strong { color: var(--warn); }
    .reasons td.n, .reasons th.n { text-align: right; }
    .reasons tr { cursor: pointer; } .reasons tr:hover td { background: var(--hover); } .reasons tr.on td { background: var(--accent-soft); }
    /* phone / tablet: each reason as a small block (reason + count, bar, what to do, latest) instead of a squeezed table */
    @media (max-width: 900px) {
        .reasons thead { display: none; }
        .reasons, .reasons tbody { display: block; }
        .reasons tr { display: grid; grid-template-columns: 1fr auto; gap: 6px 12px; padding: 10px 12px; border-bottom: 1px solid var(--border); }
        .reasons tr:last-child { border-bottom: 0; }
        .reasons td { display: block; border: 0 !important; padding: 0 !important; }
        .reasons td:nth-child(n+3) { grid-column: 1 / -1; }
    }
    .bar-fill { height: 6px; border-radius: 99px; background: var(--bad); opacity: .75; }
    .send-ok { color: var(--good); } .send-bad { color: var(--bad); } .send-skip { color: var(--text-dim); }
    .res-list { max-height: 260px; overflow: auto; border: 1px solid var(--border); border-radius: 8px; margin-top: 10px; }
    .res-list div { padding: 6px 10px; border-bottom: 1px solid var(--border); font-size: 12.5px; }
    .res-list div:last-child { border-bottom: 0; }
    .progress { height: 8px; background: var(--surface-2); border-radius: 99px; overflow: hidden; margin-top: 12px; }
    .progress i { display: block; height: 100%; background: var(--accent); width: 0; transition: width .3s; }
    pre.raw { white-space: pre-wrap; word-break: break-all; font: 11px/1.45 'JetBrains Mono', monospace; background: var(--surface-2); border: 1px solid var(--border); border-radius: 8px; padding: 10px; margin: 6px 0 0; max-height: 220px; overflow: auto; }
</style>
</head>
<body>
<div class="wrap">
    <div class="page-head">
        <h1>CRM Push</h1>
        <p class="sub">Did each lead reach the CRM? Built from the CRM reply the website saves on every lead.</p>
    </div>

    <div class="card">
        <div class="bar">
            <?php if (count($dbs) > 1) { ?>
            <select id="db" title="Lead database"><?php foreach ($dbs as $k => $l) { ?><option value="<?= $h($k) ?>" <?= $k === $defaultDb ? 'selected' : '' ?>><?= $h($l) ?></option><?php } ?></select>
            <?php } else { ?><input type="hidden" id="db" value="<?= $h($defaultDb) ?>"><?php } ?>
            <select id="range">
                <option value="today">Today</option>
                <option value="yesterday">Yesterday</option>
                <option value="7">Last 7 days</option>
                <option value="30" selected>Last 30 days</option>
                <option value="90">Last 90 days</option>
                <option value="month">This month</option>
                <option value="lastmonth">Last month</option>
                <option value="last_1y">Last 1 year</option>
                <option value="all">All time</option>
                <option value="custom">Custom…</option>
            </select>
            <span id="custom" class="bar hidden"><input type="date" id="d-from"> <span class="muted">to</span> <input type="date" id="d-to"></span>
            <select id="plat" title="Platform"><option value="">All platforms</option></select>
            <input type="search" id="q" class="grow" placeholder="Search name, mobile, email or campaign…">
            <label class="muted" style="font-size:12.5px;white-space:nowrap;"><input type="checkbox" id="tests"> Include test leads</label>
            <button class="btn" id="b-refresh">↻ Refresh</button>
            <button class="btn" id="b-export">↓ Export CSV</button>
        </div>
    </div>

    <div id="msg"></div>
    <div class="tiles" id="tiles"></div>

    <div class="card" id="reasons-card">
        <h3 style="margin:0 0 4px;font-size:15px;">Why leads failed</h3>
        <p class="faint" style="margin:0 0 12px;" id="reasons-help">Click a reason to see only those leads. Fix the cause on the website / CRM side first (e.g. a limit), then send the leads again with “Send to CRM”.</p>
        <div class="tbl-wrap"><table class="reasons"><thead><tr><th>Reason</th><th class="n">Leads</th><th style="width:30%;"></th><th>What to do</th><th>Latest</th></tr></thead><tbody id="reasons"></tbody></table></div>
    </div>

    <div class="card" style="padding:0;">
        <div class="tbl-wrap" style="border:0;border-radius:12px;max-height:calc(100vh - 220px);">
            <table>
                <thead><tr><th class="chk"><input type="checkbox" id="chk-all" title="Select every lead on this page that can be sent"></th><th>Lead date</th><th>Lead</th><th>Platform / campaign</th><th>Lead status</th><th>CRM result</th><th></th></tr></thead>
                <tbody id="rows"><tr><td colspan="7" class="muted" style="padding:24px;"><span class="spinner"></span>Loading…</td></tr></tbody>
            </table>
        </div>
    </div>
    <div class="pager" id="pager"></div>
    <div class="bulk hidden" id="bulk">
        <b id="bulk-n">0 selected</b>
        <button class="btn primary" id="b-send">Send to CRM</button>
        <button class="btn" id="b-all"></button>
        <button class="btn" id="b-clear">Clear</button>
        <span class="faint" id="bulk-note"></span>
    </div>
</div>
<div class="overlay hidden" id="dlg"><div class="dialog" id="dlg-body"></div></div>

<script>
(function () {
    'use strict';
    const API = 'crm_push_api.php';
    const $ = s => document.querySelector(s);
    const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
    const fmt = n => Number(n || 0).toLocaleString('en-IN');
    const pct = (a, b) => b ? (a * 100 / b).toFixed(1) + '%' : '—';
    const S = { counts: {}, reasons: [], rows: [], view: 'problem', reason: '', plat: '', page: 1, size: 50, open: new Set(), sel: new Set(), send: {}, busy: false };
    const FIX = {
        limit: 'CRM ran out of API calls for the day. Ask the CRM admin to raise the limit; add these leads by hand.',
        email_limit: 'CRM hit its daily email limit while saving. Ask the CRM admin to raise it or turn off the email step for web leads.',
        date_format: 'The website sent the date in a format the CRM rejects. Fix the date format in the website\'s CRM call.',
        bad_request: 'The website sent broken data (often a quote or line break in a field). Fix the CRM call.',
        duplicate: 'CRM duplicate rule blocked it. Check the existing record in the CRM.',
        not_sent: 'No CRM reply saved — the lead was added by hand or by import, or the website call timed out.',
        other: 'Check the full CRM reply (Details).'
    };
    const fixFor = k => FIX[k] || (k.startsWith('picklist_') ? 'The website sends a Sub Source value the CRM doesn\'t allow. Add the value in the CRM, or change the website mapping.'
        : k.startsWith('required_') ? 'A required CRM field was empty (e.g. no last name). Make the website send a default value.'
        : k.startsWith('validation_') ? 'A CRM validation rule blocked it. Ask the CRM admin.' : FIX.other);

    async function api(action, params) {
        const qs = new URLSearchParams(Object.assign({ action, db: $('#db').value }, params || {}));
        const res = await fetch(`${API}?${qs}`, { credentials: 'same-origin' });
        const d = await res.json().catch(() => ({ success: false, error: `Server error (HTTP ${res.status}).` }));
        if (!d.success) throw new Error(d.error || 'Request failed');
        return d;
    }
    const ymd = d => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
    function range() {
        const v = $('#range').value, now = new Date(), t = ymd(now);
        if (v === 'all') return { since: '', until: '' };
        if (v === 'today') return { since: t, until: t };
        if (v === 'yesterday') { const y = new Date(now); y.setDate(y.getDate() - 1); return { since: ymd(y), until: ymd(y) }; }
        if (v === 'last_1y') { const y = new Date(now); y.setFullYear(y.getFullYear() - 1); y.setDate(y.getDate() + 1); return { since: ymd(y), until: t }; }
        if (v === 'custom') return { since: $('#d-from').value, until: $('#d-to').value };
        if (v === 'month') return { since: ymd(new Date(now.getFullYear(), now.getMonth(), 1)), until: t };
        if (v === 'lastmonth') return { since: ymd(new Date(now.getFullYear(), now.getMonth() - 1, 1)), until: ymd(new Date(now.getFullYear(), now.getMonth(), 0)) };
        const d = new Date(now); d.setDate(d.getDate() - (+v - 1));
        return { since: ymd(d), until: t };
    }
    $('#range').addEventListener('change', () => { $('#custom').classList.toggle('hidden', $('#range').value !== 'custom'); if ($('#range').value !== 'custom') load(); });
    ['#d-from', '#d-to'].forEach(id => $(id).addEventListener('change', () => { if ($('#d-from').value && $('#d-to').value) load(); }));
    let qT = null;
    $('#q').addEventListener('input', () => { clearTimeout(qT); qT = setTimeout(load, 400); });
    ['#b-refresh'].forEach(id => $(id).addEventListener('click', load));
    $('#tests').addEventListener('change', load);
    $('#db').addEventListener('change', load);
    $('#plat').addEventListener('change', () => { S.plat = $('#plat').value; S.page = 1; render(); });

    async function load() {
        $('#rows').innerHTML = `<tr><td colspan="7" class="muted" style="padding:24px;"><span class="spinner"></span>Loading…</td></tr>`;
        $('#msg').innerHTML = '';
        try {
            const r = range();
            const d = await api('list', { since: r.since, until: r.until, search: $('#q').value.trim(), tests: $('#tests').checked ? 1 : 0 });
            Object.assign(S, { counts: d.counts, reasons: d.reasons, rows: d.rows, page: 1, send: d.send || {} });
            const ids = new Set(d.rows.filter(canSend).map(r => r.id));
            S.sel = new Set([...S.sel].filter(id => ids.has(id)));
            sendNote();
            if (S.reason && !d.reasons.some(x => x.key === S.reason)) S.reason = '';
            const plats = [...new Set(d.rows.map(x => x.platform))].sort();
            if (S.plat && !plats.includes(S.plat)) S.plat = '';
            $('#plat').innerHTML = '<option value="">All platforms</option>' + plats.map(p => `<option ${p === S.plat ? 'selected' : ''}>${esc(p)}</option>`).join('');
            render();
            try { window.parent && window.parent !== window && window.parent.postMessage({ type: 'pq-crm-changed' }, '*'); } catch (e) {}
        } catch (e) {
            $('#rows').innerHTML = `<tr><td colspan="7" style="padding:24px;color:var(--bad);">${esc(e.message)}</td></tr>`;
        }
    }

    /* ── Send to CRM ── */
    const pkey = p => (p === 'Meta' || p === 'Google') ? p : 'Other';
    const canSend = r => !!(S.send.ready && S.send.allowed && !r.test && (r.state === 'failed' || r.state === 'not_sent')
        && (S.send.platforms || []).includes(pkey(r.platform)));
    function whyNot(r) {
        if (!S.send.allowed) return '';
        if (r.test) return 'Test lead';
        const p = (S.send.problems || {})[pkey(r.platform)];
        return p || '';
    }
    function sendNote() {
        const s = S.send;
        let html = '';
        const where = s.super ? 'Admin → <b>CRM Settings</b>' : 'a Super Admin (Admin → CRM Settings)';
        if (s.allowed && !s.ready) html = `<div class="note warn"><b>Send to CRM is off.</b> Set up Salesforce in ${where} to send failed leads again from here.</div>`;
        else if (s.allowed && s.problems && (s.problems.Meta || s.problems.Google)) html = `<div class="note warn">${['Meta', 'Google'].filter(p => s.problems[p]).map(p => `<b>${p} leads can't be sent:</b> ${esc(s.problems[p])}.`).join('<br>')}</div>`;
        $('#msg').innerHTML = html;
        $('#reasons-help').textContent = s.allowed && s.ready
            ? 'Click a reason to see only those leads. Fix the cause on the website / CRM side first (e.g. a limit), then send the leads again with “Send to CRM”.'
            : 'Click a reason to see only those leads. Fix the cause on the website / CRM side, then add the leads in the CRM by hand from the export.';
        $('#chk-all').closest('th').style.display = s.allowed && s.ready ? '' : 'none';
    }
    function bulkBar() {
        const n = S.sel.size, pool = visible().filter(canSend);
        $('#bulk').classList.toggle('hidden', !n);
        $('#bulk-n').textContent = `${fmt(n)} selected`;
        $('#b-send').textContent = `Send ${fmt(n)} to CRM`;
        $('#b-send').disabled = S.busy || !n;
        const rest = pool.filter(r => !S.sel.has(r.id)).length;
        $('#b-all').classList.toggle('hidden', !rest);
        $('#b-all').textContent = `Select all ${fmt(pool.length)} in this view`;
        const pageIds = pageRows().filter(canSend).map(r => r.id);
        $('#chk-all').checked = pageIds.length > 0 && pageIds.every(id => S.sel.has(id));
    }
    $('#chk-all').addEventListener('change', e => { pageRows().filter(canSend).forEach(r => e.target.checked ? S.sel.add(r.id) : S.sel.delete(r.id)); render(); });
    $('#b-all').addEventListener('click', () => { visible().filter(canSend).forEach(r => S.sel.add(r.id)); render(); });
    $('#b-clear').addEventListener('click', () => { S.sel.clear(); render(); });
    $('#b-send').addEventListener('click', () => confirmSend([...S.sel]));
    const dlg = html => { $('#dlg-body').innerHTML = html; $('#dlg').classList.remove('hidden'); };
    const closeDlg = () => { if (!S.busy) $('#dlg').classList.add('hidden'); };
    $('#dlg').addEventListener('click', e => { if (e.target.id === 'dlg') closeDlg(); });

    function confirmSend(ids) {
        const rows = S.rows.filter(r => ids.includes(r.id) && canSend(r));
        if (!rows.length) return;
        const by = p => rows.filter(r => r.platform === p).length;
        dlg(`<h3>Send ${fmt(rows.length)} lead${rows.length > 1 ? 's' : ''} to Salesforce?</h3>
            <p class="muted" style="margin:0;">Meta ${fmt(by('Meta'))} · Google ${fmt(by('Google'))}${rows.length - by('Meta') - by('Google') ? ` · other ${fmt(rows.length - by('Meta') - by('Google'))}` : ''}. Each lead is sent once with the fields set in CRM Settings,
            and the Salesforce reply is saved on the lead. Leads that reached the CRM in the meantime are skipped.</p>
            ${S.reasons.some(x => x.key === 'limit' || x.key === 'email_limit') ? '<div class="note warn" style="margin:12px 0 0;">Some leads failed because a Salesforce limit was reached. If the limit is still reached, sending stops after the first error.</div>' : ''}
            <div class="actions"><button class="btn" id="d-cancel">Cancel</button><button class="btn primary" id="d-go">Send ${fmt(rows.length)}</button></div>`);
        $('#d-cancel').onclick = closeDlg;
        $('#d-go').onclick = () => runSend(rows.map(r => r.id));
    }
    async function runSend(ids) {
        S.busy = true;
        const out = [], chunk = Math.min(10, S.send.max || 10);
        let stopped = '';
        dlg(`<h3>Sending to Salesforce…</h3><p class="muted" id="d-prog" style="margin:0;">0 of ${fmt(ids.length)}</p><div class="progress"><i id="d-bar"></i></div>`);
        try {
            for (let i = 0; i < ids.length && !stopped; i += chunk) {
                const part = ids.slice(i, i + chunk);
                const res = await fetch(`${API}?action=send&db=${encodeURIComponent($('#db').value)}`, {
                    method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ids: part })
                });
                const d = await res.json().catch(() => ({ success: false, error: `Server error (HTTP ${res.status}).` }));
                if (!d.success) throw new Error(d.error || 'Sending failed');
                out.push(...d.results);
                stopped = d.stopped || '';
                const done = Math.min(ids.length, i + part.length);
                $('#d-prog').textContent = `${fmt(done)} of ${fmt(ids.length)}`;
                $('#d-bar').style.width = (done * 100 / ids.length).toFixed(0) + '%';
            }
        } catch (e) {
            out.push({ id: 0, name: '', state: 'failed', reason: e.message });
        }
        if (stopped) ids.filter(id => !out.some(r => r.id === id)).forEach(id => out.push({ id, name: (S.rows.find(r => r.id === id) || {}).name || '', state: 'skipped', reason: 'Not tried: ' + stopped }));
        S.busy = false;
        const n = st => out.filter(r => r.state === st).length;
        const icon = { sent: ['✓', 'send-ok'], existing: ['✓', 'send-ok'], failed: ['✕', 'send-bad'], skipped: ['–', 'send-skip'] };
        dlg(`<h3>${n('sent') + n('existing') ? `${fmt(n('sent') + n('existing'))} reached the CRM` : 'Nothing reached the CRM'}</h3>
            <p class="muted" style="margin:0;">Sent ${fmt(n('sent'))}${n('existing') ? ` · matched existing account ${fmt(n('existing'))}` : ''} · failed ${fmt(n('failed'))} · skipped ${fmt(n('skipped'))}</p>
            ${stopped ? `<div class="note bad" style="margin:12px 0 0;"><b>Stopped:</b> ${esc(stopped)}. Try the rest later.</div>` : ''}
            <div class="res-list">${out.map(r => `<div><span class="${icon[r.state][1]}">${icon[r.state][0]}</span> <b>${esc(r.name || (r.id ? '#' + r.id : ''))}</b>
                <span class="faint">${esc(r.state === 'sent' ? (r.crm_id ? 'CRM lead ' + r.crm_id : 'Sent') : r.reason)}</span></div>`).join('')}</div>
            <div class="actions"><button class="btn primary" id="d-close">Done</button></div>`);
        $('#d-close').onclick = () => { closeDlg(); S.sel.clear(); load(); };
    }

    function visible() {
        return S.rows.filter(r => (S.view === 'all' || (S.view === 'problem' ? (r.state === 'failed' || r.state === 'not_sent') : r.state === S.view))
            && (!S.reason || r.key === S.reason) && (!S.plat || r.platform === S.plat));
    }
    function render() {
        const c = S.counts, problem = c.failed + c.not_sent;
        const tile = (view, label, val, cls, sub) => `<button class="tile ${cls} ${S.view === view ? 'on' : ''}" data-view="${view}"><div>${label}</div><strong class="mono">${fmt(val)}</strong><small>${sub || ''}</small></button>`;
        $('#tiles').innerHTML = `<div class="tile" style="cursor:default;"><div>Leads in period</div><strong class="mono">${fmt(c.total)}</strong><small>${c.tests_skipped ? fmt(c.tests_skipped) + ' test leads not counted' : 'no test leads'}</small></div>`
            + tile('sent', 'Reached CRM', c.sent, 'good', pct(c.sent, c.total))
            + tile('problem', 'Did not reach CRM', problem, problem ? 'bad' : '', pct(problem, c.total) + ' · failed + not sent')
            + tile('failed', 'Failed', c.failed, c.failed ? 'bad' : '', 'CRM returned an error')
            + tile('not_sent', 'Not sent', c.not_sent, c.not_sent ? 'warn' : '', 'no CRM reply saved')
            + tile('existing', 'Matched existing account', c.existing, '', 'CRM linked it to a customer, no new lead');
        $('#tiles').querySelectorAll('[data-view]').forEach(b => b.onclick = () => { S.view = b.dataset.view; S.reason = ''; S.page = 1; render(); });

        const max = Math.max(1, ...S.reasons.map(r => r.leads));
        $('#reasons-card').classList.toggle('hidden', !S.reasons.length);
        $('#reasons').innerHTML = S.reasons.map(r => `<tr class="${S.reason === r.key ? 'on' : ''}" data-reason="${esc(r.key)}">
            <td><span class="pill ${r.state === 'failed' ? 'bad' : 'warn'}">${r.state === 'failed' ? 'Failed' : 'Not sent'}</span> ${esc(r.reason)}</td>
            <td class="n mono"><b>${fmt(r.leads)}</b></td>
            <td><div class="bar-fill" style="width:${(r.leads * 100 / max).toFixed(0)}%;"></div></td>
            <td class="faint" style="font-size:12px;">${esc(fixFor(r.key))}</td>
            <td class="mono faint" style="white-space:nowrap;">${esc(r.latest.slice(0, 10))}</td></tr>`).join('');
        $('#reasons').querySelectorAll('[data-reason]').forEach(tr => tr.onclick = () => {
            S.reason = S.reason === tr.dataset.reason ? '' : tr.dataset.reason;
            if (S.reason && S.view !== 'all' && S.view !== 'problem') S.view = 'problem';
            S.page = 1; render();
        });

        const list = visible(), pages = Math.max(1, Math.ceil(list.length / S.size));
        if (S.page > pages) S.page = pages;
        const shown = pageRows();
        const chkCol = !!(S.send.allowed && S.send.ready);
        const STATE = { failed: ['Failed', 'bad'], not_sent: ['Not sent', 'warn'], existing: ['Existing account', 'unknown'] };
        if (S.view === 'sent') {
            $('#rows').innerHTML = `<tr><td colspan="7" style="padding:24px;" class="muted">${fmt(c.sent)} leads reached the CRM. Only leads with a problem are listed here.</td></tr>`;
        } else if (!shown.length) {
            $('#rows').innerHTML = `<tr><td colspan="7" style="padding:28px;" class="muted">🎉 Every lead in this period reached the CRM.</td></tr>`;
        } else {
            $('#rows').innerHTML = shown.map(r => `<tr class="${S.sel.has(r.id) ? 'sel' : ''}">
                <td class="chk" style="${chkCol ? '' : 'display:none;'}">${canSend(r) ? `<input type="checkbox" data-sel="${r.id}" ${S.sel.has(r.id) ? 'checked' : ''}>` : ''}</td>
                <td class="mono" style="white-space:nowrap;">${esc(r.date.slice(0, 16))}</td>
                <td><b>${esc(r.name) || '<span class="faint">(no name)</span>'}</b><div class="mono faint">${esc(r.mobile)}</div>${r.email ? `<div class="faint">${esc(r.email)}</div>` : ''}</td>
                <td>${esc(r.platform)}<div class="faint">${esc(r.source || '(no source)')}</div>${r.campaign ? `<div class="faint">${esc(r.campaign)}</div>` : ''}</td>
                <td>${r.status ? esc(r.status) : '<span class="faint">—</span>'}</td>
                <td><span class="pill ${STATE[r.state][1]}">${STATE[r.state][0]}</span><div style="margin-top:3px;">${esc(r.reason)}</div>${r.crm_id ? `<div class="faint mono">${esc(r.crm_id)}</div>` : ''}
                    ${S.open.has(r.id) ? `<pre class="raw">${esc(r.raw || '(empty)')}</pre>` : ''}</td>
                <td style="white-space:nowrap;">${canSend(r) ? `<button class="btn sm primary" data-send="${r.id}" ${S.busy ? 'disabled' : ''}>Send to CRM</button> ` : (chkCol && whyNot(r) && r.state !== 'existing' ? `<div class="faint" style="max-width:150px;white-space:normal;margin-bottom:4px;">${esc(whyNot(r))}</div>` : '')}<button class="btn sm" data-raw="${r.id}">${S.open.has(r.id) ? 'Hide' : 'Details'}</button></td></tr>`).join('');
            $('#rows').querySelectorAll('[data-raw]').forEach(b => b.onclick = () => { const id = +b.dataset.raw; S.open.has(id) ? S.open.delete(id) : S.open.add(id); render(); });
            $('#rows').querySelectorAll('[data-send]').forEach(b => b.onclick = () => confirmSend([+b.dataset.send]));
            $('#rows').querySelectorAll('[data-sel]').forEach(cb => cb.onchange = () => { const id = +cb.dataset.sel; cb.checked ? S.sel.add(id) : S.sel.delete(id); render(); });
        }
        const btn = (p, l) => `<button class="${p === S.page ? 'on' : ''}" data-page="${p}" ${p < 1 || p > pages ? 'disabled' : ''}>${l || p}</button>`;
        let nums = [];
        for (let p = Math.max(1, S.page - 2); p <= Math.min(pages, S.page + 2); p++) nums.push(btn(p));
        $('#pager').innerHTML = S.view === 'sent' ? '' : `<span>${fmt(list.length)} lead(s)${S.reason ? ' · filtered by reason' : ''}</span><span>${btn(S.page - 1, '‹')} ${nums.join(' ')} ${btn(S.page + 1, '›')}</span>`;
        $('#pager').querySelectorAll('[data-page]').forEach(b => b.onclick = () => { S.page = +b.dataset.page; render(); });
        bulkBar();
    }
    function pageRows() {
        if (S.view === 'sent') return [];
        return visible().slice((S.page - 1) * S.size, S.page * S.size);
    }

    $('#b-export').addEventListener('click', () => {
        const q = v => `"${String(v ?? '').replace(/"/g, '""')}"`;
        const head = ['Lead date', 'Name', 'Mobile', 'Email', 'Platform', 'Source', 'Campaign', 'Lead status', 'CRM result', 'Reason', 'CRM reply'];
        const lines = [head.map(q).join(',')].concat(visible().map(r => [r.date, r.name, r.mobile_export ?? r.mobile, r.email_export ?? r.email, r.platform, r.source, r.campaign, r.status,
            { failed: 'Failed', not_sent: 'Not sent', existing: 'Existing account' }[r.state], r.reason, r.raw].map(q).join(',')));
        const a = document.createElement('a');
        a.href = URL.createObjectURL(new Blob(['﻿' + lines.join('\r\n')], { type: 'text/csv' }));
        a.download = `crm_push_${S.view}_${ymd(new Date())}.csv`;
        a.click();
        setTimeout(() => URL.revokeObjectURL(a.href), 2000);
    });
    load();
})();
</script>
</body>
</html>
