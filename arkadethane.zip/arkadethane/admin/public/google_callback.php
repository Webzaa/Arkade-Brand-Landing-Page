<?php
session_start();

if (isset($_SESSION["user_logged"]) && $_SESSION["user_logged"] == "Y") {
    header("Location: dashboard.php");
    exit;
}

include dirname(__DIR__) . '/app/Core/db.php';
require_once dirname(__DIR__) . '/app/bootstrap.php';

// ===m=== If no code in URL, redirect to Google ===m===
if (!isset($_GET['code'])) {

    $params = http_build_query([
        'client_id'     => GOOGLE_LOGIN_CLIENT_ID,
        'redirect_uri'  => GOOGLE_LOGIN_REDIRECT_URI,
        'response_type' => 'code',
        'scope'         => 'openid email profile',
        'access_type'   => 'online',
        'prompt'        => 'select_account', // always show account picker
        'login_hint'    => $_GET['prefill_email'] ?? '',
    ]);

    header("Location: https://accounts.google.com/o/oauth2/v2/auth?" . $params);
    exit;
}

// ===m=== Exchange code for access token ===m===
$code = $_GET['code'];

$tokenResponse = file_get_contents('https://oauth2.googleapis.com/token', false, stream_context_create([
    'http' => [
        'method'  => 'POST',
        'header'  => 'Content-Type: application/x-www-form-urlencoded',
        'content' => http_build_query([
            'code'          => $code,
            'client_id'     => GOOGLE_LOGIN_CLIENT_ID,
            'client_secret' => GOOGLE_LOGIN_CLIENT_SECRET,
            'redirect_uri'  => GOOGLE_LOGIN_REDIRECT_URI,
            'grant_type'    => 'authorization_code',
        ]),
    ]
]));

if (!$tokenResponse) {
    header("Location: login.php?google_error=token_failed");
    exit;
}

$tokenData = json_decode($tokenResponse, true);

if (empty($tokenData['access_token'])) {
    header("Location: login.php?google_error=token_failed");
    exit;
}

// ===m=== Get user info from Google ===m===
$userInfoResponse = file_get_contents(
    'https://www.googleapis.com/oauth2/v3/userinfo',
    false,
    stream_context_create([
        'http' => [
            'header' => 'Authorization: Bearer ' . $tokenData['access_token'],
        ]
    ])
);

if (!$userInfoResponse) {
    header("Location: login.php?google_error=userinfo_failed");
    exit;
}

$googleUser = json_decode($userInfoResponse, true);
$email      = strtolower(trim($googleUser['email'] ?? ''));

if ($email === '') {
    header("Location: login.php?google_error=no_email");
    exit;
}

// ===m=== Check if email exists in DB  ===m===
$stmt = $conn->prepare("SELECT uid, username, role, status, unmask_email, unmask_mobile FROM users WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    // Email not registered
    header("Location: login.php?google_error=not_registered");
    exit;
}

$user = $result->fetch_assoc();

// ===m=== Check account status ===m===
if ($user['status'] !== 'Y') {
    header("Location: login.php?google_error=blocked");
    exit;
}

// ===m=== Set session ===m===
$_SESSION['user']          = $email;
$_SESSION['uid']           = $user['uid'];
$_SESSION['username']      = $user['username'];
$_SESSION['role']          = $user['role'];
$_SESSION['user_logged']   = "Y";
$_SESSION['unmask_email']  = $user['unmask_email'];
$_SESSION['unmask_mobile'] = $user['unmask_mobile'];

// last login (shown in Users & Roles)
$ll = $conn->prepare("UPDATE users SET lastlogin = NOW() WHERE uid = ?");
if ($ll) {
    $lluid = (int) $user['uid'];
    $ll->bind_param("i", $lluid);
    $ll->execute();
}

header("Location: dashboard.php");
exit;
