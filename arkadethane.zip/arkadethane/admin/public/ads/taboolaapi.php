<?php

ob_start(); // Buffer all output to prevent PHP notices corrupting JSON

ini_set('display_errors', 0);
ini_set('display_startup_errors', '0');
error_reporting(E_ALL);
ini_set('log_errors', 1);

session_start();
require_once dirname(__DIR__, 2) . '/app/Core/db.php';
require_once dirname(__DIR__, 2) . '/app/Ads/master_tables.php';   // pqInternalRequest()
// Returns spend and lead data — logged-in users (or this server's own internal calls) only.
if (($_SESSION['user_logged'] ?? '') !== 'Y' && !pqInternalRequest()) {
    http_response_code(401);
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Not logged in', 'valid' => false]);
    exit;
}
session_write_close();

header('Content-Type: application/json');

// Taboola credentials are in config/config.php

// ===m=== Parse incoming request ===m===
$input = json_decode(file_get_contents('php://input'), true) ?? [];
$action = isset($_GET['action']) ? $_GET['action'] : (isset($input['action']) ? $input['action'] : '');
$since = isset($input['since']) ? $input['since'] : date('Y-m-d', strtotime('-30 days'));
$until = isset($input['until']) ? $input['until'] : date('Y-m-d');
$campaignsstatus = isset($input['campaignsstatus']) ? $input['campaignsstatus'] : 'all';

// ===m=== API actions for Upload and Unmapped Leads Count ===m===
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'update_leads') {
    $updates = isset($input['updates']) ? $input['updates'] : [];
    $success_count = 0;
    $duplicate_count = 0;
    $failed_count = 0;

    // Every database in LEAD_DATABASES: update the lead where it already exists,
    // insert brand-new mobiles into the main database (APP_DB).
    $uploadDbs = leadDbs('all');
    if (!empty($updates) && is_array($updates) && $uploadDbs) {
        $stmts = [];
        foreach ($uploadDbs as $k => $db) {
            $stmts[$k] = [
                'check'  => $db->prepare("SELECT id FROM `lead` WHERE mobile != '' AND (mobile = ? OR RIGHT(mobile, 10) = RIGHT(?, 10)) LIMIT 1"),
                'update' => $db->prepare("UPDATE `lead` SET lead_status = ?, lead_sub_status = ?, sitevisit_status = ?, sitevisit_sub_status = ?, campaignsource = 'Taboola' WHERE id = ?"),
            ];
        }
        $insertDb = $uploadDbs[appDbKey()] ?? reset($uploadDbs);
        $insert_stmt = $insertDb->prepare("INSERT INTO `lead` (mobile, campaignsource, lead_status, lead_sub_status, sitevisit_status, sitevisit_sub_status, createddate) VALUES (?, 'Taboola', ?, ?, ?, ?, NOW())");

        foreach ($updates as $up) {
            $mobile = isset($up['mobile']) ? trim((string) $up['mobile']) : '';
            $status = isset($up['status']) ? trim((string) $up['status']) : '';
            $sub_status = isset($up['sub_status']) ? trim((string) $up['sub_status']) : '';
            $sitevisit_status = isset($up['sitevisit_status']) ? trim((string) $up['sitevisit_status']) : '';
            $sitevisit_sub_status = isset($up['sitevisit_sub_status']) ? trim((string) $up['sitevisit_sub_status']) : '';

            if ($mobile === '') {
                $failed_count++;
                continue;
            }

            $found = false;
            foreach ($stmts as $k => $st) {
                if (!$st['check'] || !$st['update']) {
                    continue;
                }
                $st['check']->bind_param("ss", $mobile, $mobile);
                $st['check']->execute();
                $res = $st['check']->get_result();
                if ($res && $res->num_rows > 0) {
                    $found = true;
                    $id = $res->fetch_assoc()['id'];
                    $st['update']->bind_param("ssssi", $status, $sub_status, $sitevisit_status, $sitevisit_sub_status, $id);
                    if ($st['update']->execute()) {
                        if ($st['update']->affected_rows > 0) {
                            $success_count++;
                        } else {
                            $duplicate_count++;
                        }
                    } else {
                        $failed_count++;
                    }
                    break;
                }
            }

            if (!$found) {
                if ($insert_stmt) {
                    $insert_stmt->bind_param("sssss", $mobile, $status, $sub_status, $sitevisit_status, $sitevisit_sub_status);
                }
                if ($insert_stmt && $insert_stmt->execute()) {
                    $success_count++;
                } else {
                    $failed_count++;
                }
            }
        }
        foreach ($stmts as $st) {
            foreach ($st as $x) {
                if ($x) $x->close();
            }
        }
        if ($insert_stmt) $insert_stmt->close();
    }

    echo json_encode([
        'success' => true,
        'updated' => $success_count,
        'duplicate' => $duplicate_count,
        'failed' => $failed_count
    ]);
    exit;
}

// ===m=== Last Lead Date for Taboola ===m===
if ($action === 'last_lead_date') {
    $lastDate = null;
    foreach (leadDbs('all') as $db) {   // newest across every database
        $res = $db->query(
            "SELECT MAX(createddate) AS last_dt FROM `lead`
             WHERE LOWER(TRIM(COALESCE(campaignsource,''))) LIKE '%taboola%'
               AND ((lead_status IS NOT NULL AND TRIM(lead_status) <> '')
                    OR (sitevisit_status IS NOT NULL AND TRIM(sitevisit_status) <> ''))"
        );
        if ($res) {
            $row = $res->fetch_assoc();
            if (!empty($row['last_dt']) && ($lastDate === null || $row['last_dt'] > $lastDate)) $lastDate = $row['last_dt'];
        }
    }
    ob_clean();
    echo json_encode(['last_lead_date' => $lastDate]);
    exit;
}

if ($action === 'unmapped_count') {
    $unmappedMobiles = [];
    foreach (leadDbs('all') as $db) {   // unique mobiles across every database
        $q = $db->query("SELECT DISTINCT mobile
                           FROM `lead`
                          WHERE (utm_campaignname IS NULL OR TRIM(utm_campaignname) = '')
                            AND LOWER(TRIM(lead_status)) = 'qualified'
                            AND LOWER(TRIM(campaignsource)) = 'taboola'");
        while ($q && ($r = $q->fetch_assoc())) {
            $unmappedMobiles[(string) $r['mobile']] = true;
        }
    }
    $totalUnmapped = count($unmappedMobiles);
    echo json_encode(['total_all_time' => $totalUnmapped]);
    exit;
}

// ===m=== Step 1 — Fetch Access Token ===m===
$tokenCh = curl_init(TABOOLA_BASE_URL . '/oauth/token');
curl_setopt_array($tokenCh, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => http_build_query([
        'client_id' => TABOOLA_CLIENT_ID,
        'client_secret' => TABOOLA_CLIENT_SECRET,
        'grant_type' => 'client_credentials',
    ]),
    CURLOPT_HTTPHEADER => ['Content-Type: application/x-www-form-urlencoded'],
]);
$tokenResponse = curl_exec($tokenCh);
$tokenError = curl_error($tokenCh);
curl_close($tokenCh);

if ($tokenError) {
    ob_clean();
    echo json_encode(['error' => 'cURL error fetching Taboola token: ' . $tokenError]);
    exit;
}

$tokenJson = json_decode($tokenResponse, true);
if (!isset($tokenJson['access_token'])) {
    ob_clean();
    echo json_encode(['error' => 'Failed to retrieve Taboola Access Token.', 'raw' => $tokenResponse]);
    exit;
}

$accessToken = $tokenJson['access_token'];

// ===m=== Step 2a — Fetch campaigns to get status mapping ===m===
$campaignsUrl = TABOOLA_BASE_URL . '/api/1.0/' . TABOOLA_ACCOUNT_ID . '/campaigns';
$campaignsCh = curl_init($campaignsUrl);
curl_setopt_array($campaignsCh, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_HTTPHEADER => [
        'Authorization: Bearer ' . $accessToken,
        'Content-Type: application/json',
    ],
]);
$campaignsResponse = curl_exec($campaignsCh);
$campaignsError = curl_error($campaignsCh);
curl_close($campaignsCh);

$campaignsStatusMap = [];
if (!$campaignsError) {
    $campaignsListJson = json_decode($campaignsResponse, true);
    $results = isset($campaignsListJson['results']) ? $campaignsListJson['results'] : $campaignsListJson;
    if (is_array($results)) {
        foreach ($results as $c) {
            $id = isset($c['id']) ? (string) $c['id'] : '';
            $status = isset($c['status']) ? (string) $c['status'] : '';
            if ($id !== '') {
                $campaignsStatusMap[$id] = $status;
            }
        }
    }
}

// ===m=== Step 2b — Fetch Campaign-Summary by Campaign breakdown ===m===
$reportUrl = TABOOLA_BASE_URL
    . '/api/1.0/' . TABOOLA_ACCOUNT_ID
    . '/reports/campaign-summary/dimensions/campaign_breakdown'
    . '?start_date=' . urlencode($since)
    . '&end_date=' . urlencode($until);

$reportCh = curl_init($reportUrl);
curl_setopt_array($reportCh, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_HTTPHEADER => [
        'Authorization: Bearer ' . $accessToken,
        'Content-Type: application/json',
    ],
]);
$reportResponse = curl_exec($reportCh);
$reportError = curl_error($reportCh);
curl_close($reportCh);

if ($reportError) {
    ob_clean();
    echo json_encode(['error' => 'cURL error fetching Taboola report: ' . $reportError]);
    exit;
}

$reportJson = json_decode($reportResponse, true);
if (isset($reportJson['message'])) {
    ob_clean();
    echo json_encode(['error' => 'Taboola API Error: ' . $reportJson['message']]);
    exit;
}

$rawRows = isset($reportJson['results']) ? $reportJson['results'] : [];

// ===m=== Step 2c — Fetch Campaign-Summary by Day (for trend chart) ===m===
$trendUrl = TABOOLA_BASE_URL
    . '/api/1.0/' . TABOOLA_ACCOUNT_ID
    . '/reports/campaign-summary/dimensions/day'
    . '?start_date=' . urlencode($since)
    . '&end_date=' . urlencode($until);

$trendCh = curl_init($trendUrl);
curl_setopt_array($trendCh, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_HTTPHEADER => [
        'Authorization: Bearer ' . $accessToken,
        'Content-Type: application/json',
    ],
]);
$trendResponse = curl_exec($trendCh);
$trendError = curl_error($trendCh);
curl_close($trendCh);

$trendRows = [];
if (!$trendError) {
    $trendJson = json_decode($trendResponse, true);
    if (isset($trendJson['results']) && is_array($trendJson['results'])) {
        $trendRows = $trendJson['results'];
    }
}

// ===m=== Step 2d — Fetch Top Campaign Content report (ad creative -> campaign_name)
// This lets us see which campaign each ad creative (item) belongs to, so
// leads/clicks that only carry a creative reference can still be mapped
// back to the correct campaign for the dashboard. ===m===
$creativeUrl = TABOOLA_BASE_URL
    . '/api/1.0/' . TABOOLA_ACCOUNT_ID
    . '/reports/top-campaign-content/dimensions/item_breakdown'
    . '?start_date=' . urlencode($since)
    . '&end_date=' . urlencode($until);

$creativeCh = curl_init($creativeUrl);
curl_setopt_array($creativeCh, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_HTTPHEADER => [
        'Authorization: Bearer ' . $accessToken,
        'Content-Type: application/json',
    ],
]);
$creativeResponse = curl_exec($creativeCh);
$creativeError = curl_error($creativeCh);
curl_close($creativeCh);

$creativeRows = [];
if (!$creativeError) {
    $creativeJson = json_decode($creativeResponse, true);
    if (isset($creativeJson['results']) && is_array($creativeJson['results'])) {
        $creativeRows = $creativeJson['results'];
    }
}

// Build lookup maps: creative id -> campaign_name, and creative name -> campaign_name
// (name-based lookup is a fallback for cases where only the ad title is available).
// We ALSO extract the utm_adcreative query-string value from the landing-page URL
// (e.g. utm_adcreative=Day_Elevation) and add it as a third lookup key — this is
// what actually gets stored in the `lead.utm_adcreative` DB column.
$creativeIdToCampaign = [];
$creativeNameToCampaign = [];
$creativeCampaignMap = [];

foreach ($creativeRows as $row) {
    $itemId   = isset($row['item'])          ? (string) $row['item']               : '';
    $itemName = isset($row['item_name'])     ? trim((string) $row['item_name'])     : '';
    $campName = isset($row['campaign_name']) ? (string) $row['campaign_name']       : '';
    $campId   = isset($row['campaign'])      ? (string) $row['campaign']            : '';
    $adName   = isset($row['ad_name'])       ? trim((string) $row['ad_name'])       : '';
    $landingUrl = isset($row['url'])         ? (string) $row['url']                 : '';

    if ($campName === '') {
        continue;
    }

    // 1) item id -> campaign
    if ($itemId !== '') {
        $creativeIdToCampaign[$itemId] = $campName;
    }

    // 2) item_name (ad headline) -> campaign
    if ($itemName !== '') {
        $creativeNameToCampaign[strtolower($itemName)] = $campName;
    }

    // 3) ad_name -> campaign (e.g. "Elevation_Static 5")
    if ($adName !== '') {
        $creativeNameToCampaign[strtolower($adName)] = $campName;
    }

    // 4) utm_adcreative URL param -> campaign (e.g. "Day_Elevation")
    //    This is the value stored in `lead.utm_adcreative` when a visitor converts.
    if ($landingUrl !== '') {
        $parsedQuery = [];
        parse_str(parse_url($landingUrl, PHP_URL_QUERY) ?? '', $parsedQuery);
        $utmAdCreative = isset($parsedQuery['utm_adcreative']) ? trim($parsedQuery['utm_adcreative']) : '';
        if ($utmAdCreative !== '') {
            $creativeNameToCampaign[strtolower($utmAdCreative)] = $campName;
        }
    }

    $creativeCampaignMap[] = [
        'item'          => $itemId,
        'item_name'     => $itemName,
        'thumbnail_url' => $row['thumbnail_url'] ?? null,
        'url'           => $landingUrl,
        'campaign'      => $campId,
        'campaign_name' => $campName,
        'impressions'   => isset($row['impressions']) ? (int) $row['impressions'] : 0,
        'clicks'        => isset($row['clicks'])      ? (int) $row['clicks']      : 0,
        'spent'         => isset($row['spent'])       ? (float) $row['spent']     : 0,
    ];
}


// ===m=== Step 3 — Aggregate by Campaign across all days ===m===
$campaignMap = []; // keyed by campaign id

foreach ($rawRows as $row) {
    $campId = $row['campaign'] ?? ($row['campaign_id'] ?? 'unknown');
    $campName = $row['campaign_name'] ?? ($row['campaign'] ?? 'Unknown');

    // Status mapping
    $campStatus = isset($campaignsStatusMap[$campId]) ? $campaignsStatusMap[$campId] : 'UNKNOWN';

    // Apply status filter
    if ($campaignsstatus === 'active' && $campStatus !== 'RUNNING') {
        continue;
    }
    if ($campaignsstatus === 'inactive' && $campStatus === 'RUNNING') {
        continue;
    }

    if (!isset($campaignMap[$campId])) {
        $campaignMap[$campId] = [
            'id' => $campId,
            'name' => $campName,
            'status' => $campStatus,
            'spend' => 0,
            'impressions' => 0,
            'clicks' => 0,
            'leads' => 0,
        ];
    }

    $campaignMap[$campId]['spend'] += isset($row['spent']) ? (float) $row['spent'] : 0;
    $campaignMap[$campId]['impressions'] += isset($row['visible_impressions']) ? (int) $row['visible_impressions'] : 0;
    $campaignMap[$campId]['clicks'] += isset($row['clicks']) ? (int) $row['clicks'] : 0;

    $actions = 0;
    if (isset($row['cpa_actions_num']))
        $actions += (int) $row['cpa_actions_num'];
    elseif (isset($row['cpa_actions_num_from_clicks']))
        $actions += (int) $row['cpa_actions_num_from_clicks'];
    elseif (isset($row['actions_num_from_clicks']))
        $actions += (int) $row['actions_num_from_clicks'];
    $campaignMap[$campId]['leads'] += $actions;
}

// ===m=== Step 4 — Fetch CRM leads from DB to compute Qualified / Site-Visit ===m===
// Fetches ALL Taboola leads in the date range (regardless of utm_campaignname)
// because most leads arrive with no campaign tracking — they are still shown
// on the dashboard as a total CRM qualified / site-visit count.
$crmData = [];
$crmByKey = [];   // mobile|source → row, merged across databases (a person stored twice counts once)
foreach (leadDbs('all') as $conn_) {
    $crmSql = "SELECT mobile, MAX(name) AS name, MAX(email) AS email,
                      MAX(utm_campaignname) AS utm_campaignname, campaignsource,
                      MAX(utmC) AS utmC, MAX(adcreative) AS adcreative,
                      MAX(lead_status) AS lead_status,
                      MAX(sitevisit_status) AS sitevisit_status,
                      MAX(createddate) AS createddate
               FROM `lead`
               WHERE LOWER(TRIM(campaignsource)) = 'taboola'
                 AND mobile IS NOT NULL AND TRIM(mobile) <> ''
                 AND createddate >= '" . $conn_->real_escape_string($since) . "'
                 AND createddate < DATE_ADD('" . $conn_->real_escape_string($until) . "', INTERVAL 1 DAY)
               GROUP BY mobile, campaignsource
               ORDER BY MAX(createddate) DESC";
    $crmResult = $conn_->query($crmSql);
    while ($crmResult && ($row = $crmResult->fetch_assoc())) {
        $k = trim((string) $row['mobile']) . '|' . strtolower(trim((string) $row['campaignsource']));
        if (!isset($crmByKey[$k])) {
            $crmByKey[$k] = $row;
            continue;
        }
        foreach ($row as $col => $val) {   // fill gaps from the other database's copy
            if (($crmByKey[$k][$col] ?? '') === '' || $crmByKey[$k][$col] === null) {
                $crmByKey[$k][$col] = $val;
            }
        }
        if ((string) $row['createddate'] > (string) $crmByKey[$k]['createddate']) {
            $crmByKey[$k]['createddate'] = $row['createddate'];
        }
    }
}
$crmData = array_values($crmByKey);
usort($crmData, fn($a, $b) => strcmp((string) $b['createddate'], (string) $a['createddate']));

// ===m=== Step 4b — Pre-compute ALL qualified / site-visit counts from CRM
// (independent of campaign matching) so we can surface a true total ===m===
$allQualifiedByMobile = [];
$allWalkinByMobile = [];
foreach ($crmData as $crm) {
    $mobile = trim($crm['mobile'] ?? '');
    if ($mobile === '')
        continue;
    $lStatus = strtolower(trim($crm['lead_status'] ?? ''));
    $svStatus = strtolower(trim($crm['sitevisit_status'] ?? ''));
    if ($lStatus === 'qualified' && !isset($allQualifiedByMobile[$mobile])) {
        $allQualifiedByMobile[$mobile] = $crm;
    }
    if ($svStatus === 'visited' && !isset($allWalkinByMobile[$mobile])) {
        $allWalkinByMobile[$mobile] = $crm;
    }
}
$totalQualifiedCrm = count($allQualifiedByMobile);
$totalWalkinsCrm = count($allWalkinByMobile);
$allQualifiedLeads = array_values($allQualifiedByMobile);
$allWalkinLeads = array_values($allWalkinByMobile);

// ===m=== Step 5 — Group CRM leads by resolved campaign name (single pass) ===m===
// Same idea as googleapi.php / api.php: bucket every lead under the campaign
// name it belongs to ONCE, then look up counts by name per campaign — no
// per-campaign, per-lead nested matching, and no hardcoded status list.
//
// Resolution order per lead:
//   1) utm_campaignname, if already set on the row
//   2) utm_adcreative -> looked up in the Taboola Top Campaign Content map
//      (and queued in Step 5c to be saved back onto the row)
//   3) utmC -> same map, as a secondary fallback
//   4) otherwise the lead stays unresolved and falls into the unmapped bucket
$leadsByCampaign = [];       // lowercase campaign name => ['qualified' => [mobile => row], 'walkin' => [mobile => row]]
$matchedMobiles = [];
$resolvedCampaignUpdates = [];
$unmappedByMobile = [];

foreach ($crmData as $crm) {
    $mobile = trim($crm['mobile'] ?? '');
    if ($mobile === '') {
        continue;
    }

    $rawCampName = trim($crm['utm_campaignname'] ?? '');
    $rawAdCreative = trim($crm['adcreative'] ?? '');
    $rawCreativeRef = trim($crm['utmC'] ?? '');

    $resolvedCampName = $rawCampName;

    if ($resolvedCampName === '' && $rawAdCreative !== '' && isset($creativeNameToCampaign[strtolower($rawAdCreative)])) {
        $resolvedCampName = $creativeNameToCampaign[strtolower($rawAdCreative)];
        // No utm_campaignname on file yet — queue this row to have it saved
        // onto the lead in Step 5c so future fetches read it directly.
        $resolvedCampaignUpdates[$mobile] = [
            'mobile'       => $mobile,
            'adcreative'   => $rawAdCreative,
            'campaign_name'=> $resolvedCampName,
        ];
    }

    if ($resolvedCampName === '' && $rawCreativeRef !== '') {
        $resolvedCampName = $creativeIdToCampaign[$rawCreativeRef]
            ?? ($creativeNameToCampaign[strtolower($rawCreativeRef)] ?? '');
    }

    $lStatus = strtolower(trim($crm['lead_status'] ?? ''));
    $svStatus = strtolower(trim($crm['sitevisit_status'] ?? ''));

    if ($resolvedCampName === '') {
        // Still unresolved — surface it in the unmapped bucket if qualified.
        if ($lStatus === 'qualified' && !isset($unmappedByMobile[$mobile])) {
            $unmappedByMobile[$mobile] = $crm;
        }
        continue;
    }

    $matchedMobiles[$mobile] = true;
    $key = strtolower($resolvedCampName);
    if (!isset($leadsByCampaign[$key])) {
        $leadsByCampaign[$key] = ['qualified' => [], 'walkin' => []];
    }

    if ($lStatus === 'qualified' && !isset($leadsByCampaign[$key]['qualified'][$mobile])) {
        $leadsByCampaign[$key]['qualified'][$mobile] = $crm;
    }
    if ($svStatus === 'visited' && !isset($leadsByCampaign[$key]['walkin'][$mobile])) {
        $leadsByCampaign[$key]['walkin'][$mobile] = $crm;
    }
}

// ===m=== Step 5a — Build final campaigns array (simple name lookup, no loop over leads) ===m===
$campaigns = [];

foreach ($campaignMap as $camp) {
    $spend = $camp['spend'];
    $impressions = $camp['impressions'];
    $clicks = $camp['clicks'];
    $leads = $camp['leads'];
    $campName = $camp['name'];
    $campStatus = $camp['status'];

    $key = strtolower($campName);
    $qualifiedLeads = isset($leadsByCampaign[$key]) ? array_values($leadsByCampaign[$key]['qualified']) : [];
    $walkinLeads = isset($leadsByCampaign[$key]) ? array_values($leadsByCampaign[$key]['walkin']) : [];
    $qualifiedCount = count($qualifiedLeads);
    $siteVisitCount = count($walkinLeads);

    $cpl = $leads > 0 ? round($spend / $leads, 2) : 0;
    $ctr = $impressions > 0 ? round(($clicks / $impressions) * 100, 2) : 0;
    $cpm = $impressions > 0 ? round(($spend / $impressions) * 1000, 2) : 0;
    $cpql = $qualifiedCount > 0 ? round($spend / $qualifiedCount, 2) : 0;
    $cpsv = $siteVisitCount > 0 ? round($spend / $siteVisitCount, 2) : 0;

    $campaigns[] = [
        'name' => $campName,
        'campStatus' => $campStatus,
        'platform' => 'Taboola',
        'spend' => $spend,
        'impressions' => $impressions,
        'clicks' => $clicks,
        'ctr' => $ctr,
        'cpm' => $cpm,
        'leads' => $leads,
        'cpl' => $cpl,
        'qualified' => $qualifiedCount,
        'walkins' => $siteVisitCount,
        'qualified_leads' => $qualifiedLeads,
        'walkin_leads' => $walkinLeads,
        'cpql' => $cpql,
        'cpsv' => $cpsv,
    ];
}

// ===m=== Step 5c — Persist resolved campaign names back to the DB.
// For leads with no utm_campaignname but whose adcreative matched a
// known Taboola creative, save that creative's campaign_name onto the row
// so future fetches read it directly instead of re-resolving it. Only rows
// that are STILL empty are touched, so this never overwrites existing data.
// ===m===
$savedCampaignNameCount = 0;
foreach (!empty($resolvedCampaignUpdates) ? leadDbs('all') : [] as $conn_) {
    $updateStmt = $conn_->prepare(
        "UPDATE `lead`
            SET utm_campaignname = ?
          WHERE mobile = ?
            AND LOWER(TRIM(campaignsource)) = 'taboola'
            AND adcreative = ?
            AND (utm_campaignname IS NULL OR TRIM(utm_campaignname) = '')"
    );
    if ($updateStmt) {
        foreach ($resolvedCampaignUpdates as $u) {
            $updateStmt->bind_param(
                "sss",
                $u['campaign_name'],
                $u['mobile'],
                $u['adcreative']
            );
            if ($updateStmt->execute()) {
                $savedCampaignNameCount += $updateStmt->affected_rows;
            }
        }
        $updateStmt->close();
    }
}

$unmappedLeads = array_values($unmappedByMobile);

// ===m=== Step 6 — Build daily trend ===m===
$trend = [];
foreach ($trendRows as $row) {
    $date = substr($row['date'] ?? '', 0, 10);
    $spent = isset($row['spent']) ? (float) $row['spent'] : 0;
    if (!$date)
        continue;
    if (!isset($trend[$date]))
        $trend[$date] = ['date' => $date, 'spend' => 0, 'clicks' => 0, 'leads' => 0];
    $trend[$date]['spend'] += $spent;
    $trend[$date]['clicks'] += isset($row['clicks']) ? (int) $row['clicks'] : 0;
    $actions = 0;
    if (isset($row['cpa_actions_num']))
        $actions += (int) $row['cpa_actions_num'];
    elseif (isset($row['cpa_actions_num_from_clicks']))
        $actions += (int) $row['cpa_actions_num_from_clicks'];
    elseif (isset($row['actions_num_from_clicks']))
        $actions += (int) $row['actions_num_from_clicks'];
    $trend[$date]['leads'] += $actions;
}
ksort($trend);
$trend = array_values($trend);

// Email / mobile masked here by Users & Roles (`mobile_export` / `email_export` for the Excel), never in the browser
foreach ($campaigns as &$c_) {
    foreach (['qualified_leads', 'walkin_leads'] as $k_) {
        if (isset($c_[$k_]) && is_array($c_[$k_])) {
            $c_[$k_] = pqContactRows($c_[$k_]);
        }
    }
}
unset($c_);
$unmappedLeads = pqContactRows($unmappedLeads);
$allQualifiedLeads = pqContactRows($allQualifiedLeads);
$allWalkinLeads = pqContactRows($allWalkinLeads);

// Taboola is all performance: nothing in the Awareness tab, nothing for roles without "Show performance"
$tbView = pqCampaignView();
if (!pqViewShows('performance', $tbView)) {
    $campaigns = $trend = $unmappedLeads = $allQualifiedLeads = $allWalkinLeads = [];
    $totalQualifiedCrm = $totalWalkinsCrm = 0;
}
ob_clean();
echo json_encode([
    'fetched_at' => date('d M Y, h:i A'),
    'date_preset' => 'Taboola Fetch',
    'awareness' => ['view' => $tbView, 'tabs' => pqViewTabs(), 'tagged' => 0, 'awareness' => null, 'performance' => null],
    'api_error' => null,
    'campaigns' => $campaigns,
    'trend' => $trend,
    'unmapped_leads' => $unmappedLeads,
    'unmapped_count' => count($unmappedLeads),
    // Total CRM qualified / site-visit counts across ALL Taboola leads
    // in the selected date range, regardless of campaign attribution.
    'total_qualified_crm' => $totalQualifiedCrm,
    'total_walkins_crm' => $totalWalkinsCrm,
    'all_qualified_leads' => $allQualifiedLeads,
    'all_walkin_leads' => $allWalkinLeads,
    // Ad creative -> campaign_name breakdown from Taboola's Top Campaign
    // Content report, for reference/mapping on the dashboard.
    'creative_campaign_map' => $creativeCampaignMap,
    // Number of `lead` rows whose utm_campaignname was just filled in from
    // Taboola (via utm_adcreative match) during this fetch.
    'saved_campaignname_count' => $savedCampaignNameCount,
]);
?>