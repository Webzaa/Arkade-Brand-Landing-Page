<?php
/**
 * portfolio_report_api.php — data for the portfolio PDF ("Export PDF (Meta + Google)").
 *
 *   GET ?since=YYYY-MM-DD&until=YYYY-MM-DD[&campaigns=meta:ID,google:ID,…][&force=1]
 *   campaigns = "Select campaigns" in the download question (js/report_picker.js); left out = all campaigns.
 *
 * Splits the range into calendar months; for each month: spend from Meta / Google (only the campaigns
 * saved for this project) and leads / qualified / site visits from the lead table(s), each lead under
 * its saved campaign → ad set / ad group → ad — see app/Ads/portfolio_data.php. Taboola is included
 * only when PORTFOLIO_INCLUDE_TABOOLA is true in config/config.php.
 * The browser turns the JSON into the PDF (js/portfolio_pdf.js). Cached 15 minutes; the cache is
 * cleared whenever leads are mapped, uploaded or campaigns are synced.
 */
ob_start();
ini_set('display_errors', '0');
session_start();
require_once dirname(__DIR__, 2) . '/app/Ads/portfolio_data.php';

function pfJson(array $p, int $code = 200): never
{
    while (ob_get_level()) {
        ob_end_clean();
    }
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($p, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}

if (PHP_SAPI !== 'cli' && ($_SESSION['user_logged'] ?? '') !== 'Y') {
    pfJson(['success' => false, 'error' => 'Not authenticated.'], 401);
}
session_write_close();   // the Google call below goes back into this site with the same session
@set_time_limit(300);

if (!defined('GROQ_API_KEY')) define('GROQ_API_KEY', '');
if (!defined('GROQ_MODEL')) define('GROQ_MODEL', 'llama-3.3-70b-versatile');
if (!defined('GROQ_URL')) define('GROQ_URL', 'https://api.groq.com/openai/v1/chat/completions');

// ── date range (default: this month so far) ──
$since = (string) ($_GET['since'] ?? '');
$until = (string) ($_GET['until'] ?? '');
$valid = fn($d) => preg_match('/^\d{4}-\d{2}-\d{2}$/', $d) && DateTime::createFromFormat('!Y-m-d', $d) !== false;
if (!$valid($since) || !$valid($until)) {
    $since = date('Y-m-01');
    $until = date('Y-m-d');
}
if ($since > $until) {
    [$since, $until] = [$until, $since];
}
$sinceDt = new DateTime($since);
$untilDt = new DateTime($until);
if ($sinceDt->diff($untilDt)->days > 1130) {   // "All time" goes back at most 37 months
    pfJson(['success' => false, 'error' => 'Please choose 37 months or less.'], 400);
}

$conns = pfLeadConns();
if (!$conns) {
    pfJson(['success' => false, 'error' => 'No lead database is reachable.'], 500);
}

// ── "Select campaigns": only these (saved project campaigns) ──
$only = null;
$campParam = trim((string) ($_GET['campaigns'] ?? ''));
if ($campParam !== '') {
    $only = ['Meta' => [], 'Google' => []];
    foreach (array_slice(explode(',', $campParam), 0, 500) as $tok) {
        [$pk, $cid] = array_pad(explode(':', trim($tok), 2), 2, '');
        $P = $pk === 'meta' ? 'Meta' : ($pk === 'google' ? 'Google' : '');
        $cid = trim($cid);
        if ($P !== '' && $cid !== '' && isProjectCampaign(strtolower($P), $cid)) {
            $only[$P][] = $cid;
        }
    }
    $only['Meta'] = array_values(array_unique($only['Meta']));
    $only['Google'] = array_values(array_unique($only['Google']));
    if (!$only['Meta'] && !$only['Google']) {
        pfJson(['success' => false, 'error' => 'None of the chosen campaigns is saved for this project any more. Choose again.'], 400);
    }
}

// ── cache (cleared by masterClearDashboardCache) ──
$cacheFile = CACHE_PATH . '/portfolio_' . md5(json_encode([$since, $until, array_keys($conns), pfIncludeTaboola(), defined('PROJECT_NAME') ? PROJECT_NAME : '', $only, pqCampaignView()])) . '.json';   // + the All / Performance / Awareness tab
if (empty($_GET['force']) && is_file($cacheFile) && time() - filemtime($cacheFile) < 900 && ($cached = @file_get_contents($cacheFile))) {
    while (ob_get_level()) {
        ob_end_clean();
    }
    header('Content-Type: application/json; charset=utf-8');
    echo pqReportJson($cached);
    exit;
}

// ── calendar months, clipped to the range ──
$months = [];
$cursor = new DateTime($sinceDt->format('Y-m-01'));
while ($cursor <= $untilDt) {
    $mStart = new DateTime($cursor->format('Y-m-01'));
    $mEnd = (clone $mStart)->modify('last day of this month');
    $months[] = [
        'label' => $mStart->format('M Y'),
        'since' => max($mStart, $sinceDt)->format('Y-m-d'),
        'until' => min($mEnd, $untilDt)->format('Y-m-d'),
    ];
    $cursor->modify('+1 month');
}

try {
    $monthsOut = [];
    $grand = pfBlank();
    $platformGrand = [];
    $unmappedAll = ['meta' => 0, 'google' => 0, 'unknown' => 0];
    $warnings = [];
    foreach ($months as $m) {
        $p = pfPeriod($m['since'], $m['until'], $conns, true, $only);
        $monthsOut[] = $m + ['rows' => $p['rows'], 'total' => $p['total'], 'disposition' => $p['disposition'], 'unmapped' => $p['unmapped']];
        pfAdd($grand, $p['total']);
        foreach ($p['rows'] as $r) {
            if ($r['level'] === 0) {
                $platformGrand[$r['platform']] = $platformGrand[$r['platform']] ?? pfBlank();
                pfAdd($platformGrand[$r['platform']], $r);
            }
        }
        foreach ($p['unmapped'] as $k => $v) {
            $unmappedAll[$k] += $v;
        }
        foreach ($p['warnings'] as $w) {
            $warnings[$w] = true;
        }
    }

    $summary = [
        'total_leads' => $grand['leads'],
        'positive_prospects' => $grand['ql'],
        'site_visits_done' => $grand['sv_done'],
        'avg_cpl' => $grand['leads'] > 0 ? round($grand['spend'] / $grand['leads'], 2) : 0.0,
        'impressions' => $grand['impressions'],
        'clicks' => $grand['clicks'],
        'spend' => round($grand['spend'], 2),
        'cpql' => $grand['ql'] > 0 ? round($grand['spend'] / $grand['ql'], 2) : 0.0,
        'cpsv' => $grand['sv_done'] > 0 ? round($grand['spend'] / $grand['sv_done'], 2) : 0.0,
        'lead_to_sv_rate' => $grand['leads'] > 0 ? round($grand['sv_done'] / $grand['leads'] * 100, 2) : 0.0,
        'unmapped' => $unmappedAll,
    ];

    // ── insight: AI when configured, else a plain summary ──
    $insightText = '';
    try {
        $insightText = generateInsights($monthsOut);
        if ($insightText === 'AI insights disabled.') {
            $insightText = '';
        }
    } catch (Throwable $e) {
        error_log('[portfolio_report] insight: ' . $e->getMessage());
    }
    if ($insightText === '') {
        $parts = [];
        $active = [];
        foreach ($platformGrand as $name => $pm) {
            if ($pm['leads'] > 0) {
                $active[$name] = $pm + ['cpl' => $pm['spend'] / $pm['leads']];
            }
        }
        if ($active) {
            uasort($active, fn($a, $b) => $b['leads'] <=> $a['leads']);
            $lead = array_key_first($active);
            $share = $grand['leads'] > 0 ? round($active[$lead]['leads'] / $grand['leads'] * 100) : 0;
            $parts[] = "{$lead} drove {$share}% of leads ({$active[$lead]['leads']} of {$grand['leads']}) at a CPL of ₹" . number_format($active[$lead]['cpl']) . '.';
            if (count($active) > 1) {
                uasort($active, fn($a, $b) => $a['cpl'] <=> $b['cpl']);
                $cheap = array_key_first($active);
                $parts[] = $cheap !== $lead
                    ? "{$cheap} had the lowest cost per lead at ₹" . number_format($active[$cheap]['cpl']) . '.'
                    : "It was also the cheapest channel per lead.";
            }
        }
        $qlPct = $grand['leads'] > 0 ? round($grand['ql'] / $grand['leads'] * 100) : 0;
        $parts[] = "{$grand['ql']} qualified leads ({$qlPct}% of all leads) and {$grand['sv_done']} site visits in the period.";
        $um = array_sum($unmappedAll);
        if ($um > 0) {
            $parts[] = "{$um} lead(s) are not under any of this project's campaigns and are not in these numbers — see Unmapped Leads.";
        }
        $insightText = implode(' ', $parts);
    }

    $payload = [
        'success' => true,
        'project' => defined('PROJECT_NAME') ? PROJECT_NAME : '',
        'since' => $since,
        'until' => $until,
        'platforms' => $only !== null ? array_values(array_filter(['Meta', 'Google'], fn($P) => (bool) $only[$P]))
            : (pfIncludeTaboola() ? ['Meta', 'Google', 'Taboola'] : ['Meta', 'Google']),
        'selection' => $only === null ? null : ['count' => count($only['Meta']) + count($only['Google']),
            'names' => array_merge(array_map(fn($id) => projectStructure('meta')['campaigns'][$id] ?? $id, $only['Meta']),
                                   array_map(fn($id) => projectStructure('google')['campaigns'][$id] ?? $id, $only['Google']))],
        'months' => $monthsOut,
        'summary' => $summary,
        'warnings' => array_keys($warnings),
        'insight_text' => $insightText,
        'generated_at' => date('d M Y, h:i A'),
    ];
    $json = json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
    if (!$warnings) {
        @file_put_contents($cacheFile, $json);   // don't keep a half-failed report
    }
    while (ob_get_level()) {
        ob_end_clean();
    }
    header('Content-Type: application/json; charset=utf-8');
    echo pqReportJson($json);
} catch (Throwable $e) {
    error_log('[portfolio_report] ' . $e->getMessage() . ' @ ' . $e->getFile() . ':' . $e->getLine());
    pfJson(['success' => false, 'error' => $e->getMessage()], 500);
}

/** The cached report is shared by everyone; numbers hidden for this user's role are removed only here. */
function pqReportJson(string $json): string
{
    if (!function_exists('pqHiddenMetrics') || !pqHiddenMetrics()) {
        return $json;
    }
    $d = json_decode($json, true);
    return is_array($d) ? json_encode(pqStripHiddenMetrics($d), JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE) : $json;
}

/* ------------------------------------------------------------------ AI insight (Groq) */
function generateInsights(array $data): string
{
    if (empty(GROQ_API_KEY)) {
        return "AI insights disabled.";
    }

    $dataSummary = "";
    foreach ($data as $m) {
        $dataSummary .= "Month: " . ($m['label'] ?? 'Unknown Month') . "\n";
        $dataSummary .= "  - Total Impressions: " . ($m['total']['impressions'] ?? 0) . "\n";
        $dataSummary .= "  - Total Clicks: " . ($m['total']['clicks'] ?? 0) . "\n";
        $dataSummary .= "  - Total Spend: ₹" . number_format($m['total']['spend'] ?? 0) . "\n";
        $dataSummary .= "  - Total Leads: " . ($m['total']['leads'] ?? 0) . "\n";
        $dataSummary .= "  - Total Qualified: " . ($m['total']['ql'] ?? 0) . "\n";
        $dataSummary .= "  - Total Site Visits: " . ($m['total']['sv_done'] ?? 0) . "\n";

        if (!empty($m['rows'])) {
            foreach ($m['rows'] as $r) {
                if (($r['type'] ?? '') === 'platform') {
                    $dataSummary .= "  - Platform: " . ($r['name'] ?? 'Unknown') . "\n";
                    $dataSummary .= "    - Spend: ₹" . number_format($r['spend'] ?? 0) . "\n";
                    $dataSummary .= "    - Leads: " . ($r['leads'] ?? 0) . "\n";
                    $dataSummary .= "    - Qualified: " . ($r['ql'] ?? 0) . "\n";
                    $dataSummary .= "    - Site Visits: " . ($r['sv_done'] ?? 0) . "\n";
                }
            }
        }
        $dataSummary .= "\n";
    }

    $platformList = pfIncludeTaboola() ? 'Meta, Google, Taboola' : 'Meta, Google';
    $prompt = <<<PROMPT
You are a Senior Digital Marketing Director.
Analyze the following month-by-month performance data for a real estate project's digital marketing campaigns ($platformList):

Data:
$dataSummary

Based on the data, you MUST structure your response into exactly three sections with the following headers (written exactly as shown, with no markdown bolding like **):

What's working:
[Identify the most efficient campaigns/platforms, volume drivers, and strong conversion rates, referencing specific metrics]

Where the value leaks:
[Identify high cost-per-lead, low lead quality/qualification rates, low site-visit conversion rates, or budget wastage, referencing specific metrics]

The lever:
[Provide 2-3 high-impact, actionable next steps to optimize performance and reduce cost]

Rules:
- Refer directly to the numbers and metrics in the data.
- Keep the response brief, professional, and direct.
- Do not use markdown bolding (e.g., do not write **What's working:**). Just write the header name on its own line.
- Do not include explanatory intro or outro text. Output only the three sections.
PROMPT;

    $post = [
        "model" => GROQ_MODEL,
        "temperature" => 0.4,
        "messages" => [
            [
                "role" => "system",
                "content" => "You are an expert Performance Marketing Consultant."
            ],
            [
                "role" => "user",
                "content" => $prompt
            ]
        ]
    ];

    $ch = curl_init(GROQ_URL);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_TIMEOUT => 15,
        CURLOPT_HTTPHEADER => [
            "Authorization: Bearer " . GROQ_API_KEY,
            "Content-Type: application/json"
        ],
        CURLOPT_POSTFIELDS => json_encode($post),
        CURLOPT_SSL_VERIFYPEER => false,
    ]);

    $response = curl_exec($ch);
    $err = curl_error($ch);
    curl_close($ch);

    if ($err) {
        throw new Exception('Groq API cURL error: ' . $err);
    }

    $json = json_decode($response, true);
    $text = $json['choices'][0]['message']['content'] ?? '';
    return trim($text);
}

