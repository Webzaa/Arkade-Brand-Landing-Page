<?php

declare(strict_types=1);

/**
 * report_view.php — OTP-protected page for weekly / monthly report links.
 *
 *   report_view.php?t=<signed token from the report email>
 *
 * 1. Checks the link signature and expiry.
 * 2. Sends a 6-digit code to the email address the link was issued to.
 * 3. After the right code, shows the report (and the deck download for monthly).
 */

date_default_timezone_set('Asia/Kolkata');

header('Cache-Control: no-store, max-age=0');
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
header('Referrer-Policy: no-referrer');

session_set_cookie_params([
    'httponly' => true,
    'secure'   => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
    'samesite' => 'Lax',
]);
session_start();

require_once dirname(__DIR__, 2) . '/app/Core/db.php';
require_once dirname(__DIR__, 2) . '/app/Reports/report_access.php';
require_once dirname(__DIR__, 2) . '/app/Reports/report_mailer.php';

function rvEsc(string $s): string
{
    return htmlspecialchars($s, ENT_QUOTES | ENT_HTML5, 'UTF-8');
}

const RV_PERIOD_TITLE = ['daily' => 'Daily Report', 'weekly' => 'Weekly Report', 'monthly' => 'Monthly Report'];
const RV_PLATFORM_NAME = ['meta' => 'Meta Ads', 'google' => 'Google Ads'];

function rvPage(string $title, string $body): never
{
    echo '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">'
        . '<title>' . rvEsc($title) . '</title>'
        . '<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>'
        . '<link href="https://fonts.googleapis.com/css2?family=Sora:wght@400;600;700&display=swap" rel="stylesheet">'
        . '<style>
            body{margin:0;background:#0B0F1A;color:#E2E8F0;font-family:Sora,Arial,sans-serif;min-height:100vh;display:flex;align-items:center;justify-content:center;padding:16px;box-sizing:border-box}
            .card{background:#111827;border:1px solid #1E2A42;border-radius:16px;padding:32px;max-width:420px;width:100%;box-sizing:border-box}
            .logo{display:block;width:77px;height:56px;margin-bottom:18px;background:#fff;border-radius:8px;padding:6px}
            .eyebrow{color:#E84E24;font-size:11px;font-weight:700;letter-spacing:.12em;text-transform:uppercase}
            h1{font-size:22px;margin:8px 0 6px}
            p{color:#94A3B8;font-size:13.5px;line-height:1.6;margin:0 0 18px}
            input{width:100%;box-sizing:border-box;background:#161D2E;border:1px solid #1E2A42;color:#E2E8F0;border-radius:10px;padding:14px;font-size:22px;letter-spacing:.4em;text-align:center;font-family:inherit;outline:none}
            input:focus{border-color:#E84E24}
            button{width:100%;margin-top:14px;background:#E84E24;color:#ffffff;border:0;border-radius:10px;padding:13px;font-weight:700;font-size:14px;font-family:inherit;cursor:pointer}
            button.secondary{background:transparent;color:#94A3B8;border:1px solid #1E2A42;font-weight:600}
            .msg{border-radius:10px;padding:10px 12px;font-size:13px;margin-bottom:16px}
            .err{background:#EF444418;border:1px solid #EF444455;color:#FCA5A5}
            .ok{background:#10B98118;border:1px solid #10B98155;color:#6EE7B7}
          </style></head><body>' . $body . '</body></html>';
    exit;
}

/* ---------- 1. Validate the link ---------- */
$token = (string) ($_GET['t'] ?? '');
try {
    $claims = $token !== '' ? reportReadToken($token) : null;
} catch (Throwable $e) {
    error_log('[report_view] ' . $e->getMessage());
    $claims = null;
}

if ($claims === null) {
    rvPage('Invalid link', '<div class="card"><img class="logo" src="images/webzaa-logo.png" alt="Webzaa"><div class="eyebrow">Performance report</div><h1>This link isn\'t valid</h1><p>Please open the link from your report email again, without changing it.</p></div>');
}
if ($claims['expired']) {
    rvPage('Link expired', '<div class="card"><img class="logo" src="images/webzaa-logo.png" alt="Webzaa"><div class="eyebrow">Performance report</div><h1>This link has expired</h1><p>Report links stay valid for a limited time. Please ask for the report to be re-sent, or open it from the dashboard.</p></div>');
}

$platform = $claims['p'];
$period = $claims['r'];
$asOf = $claims['a'];
$email = $claims['e'];
$tokenId = hash('sha256', $token);
$title = RV_PLATFORM_NAME[$platform] . ' · ' . RV_PERIOD_TITLE[$period];

/* ---------- 2. Already verified: show the report ---------- */
if (reportHasLinkAccess($platform, $period, $asOf)) {
    $isMonthly = $period === 'monthly';
    $js = json_encode(['platform' => $platform, 'period' => $period, 'asOf' => $asOf], JSON_UNESCAPED_SLASHES);
    echo '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">'
        . '<title>' . rvEsc($title) . '</title>'
        . '<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>'
        . '<link href="https://fonts.googleapis.com/css2?family=Sora:wght@300;400;500;600;700&display=swap" rel="stylesheet">'
        . '<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.7/dist/chart.umd.min.js"></script>'
        . '<script src="https://unpkg.com/xlsx-js-style@1.2.0/dist/xlsx.bundle.js"></script>'
        . '<script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>'
        . '<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>'
        . '<script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>'
        . '<style>body{margin:0;background:#0B0F1A;color:#E2E8F0;font-family:Sora,Arial,sans-serif}
            .bar{max-width:1100px;margin:0 auto;padding:28px 16px;display:flex;flex-wrap:wrap;gap:12px;align-items:center;justify-content:space-between}
            .brand{display:flex;align-items:center;gap:16px}
            .logo{width:77px;height:56px;background:#fff;border-radius:8px;padding:6px}
            .eyebrow{color:#E84E24;font-size:11px;font-weight:700;letter-spacing:.12em;text-transform:uppercase}
            h1{font-size:22px;margin:6px 0 0}
            .btns{display:flex;gap:10px;flex-wrap:wrap}
            button{background:#E84E24;color:#ffffff;border:0;border-radius:8px;padding:11px 16px;font-weight:700;font-size:13px;font-family:inherit;cursor:pointer}
            button.secondary{background:#161D2E;color:#E2E8F0;border:1px solid #1E2A42}
            button:disabled{opacity:.6;cursor:wait}</style></head><body>'
        . '<div class="bar"><div class="brand"><img class="logo" src="images/webzaa-logo.png" alt="Webzaa"><div><div class="eyebrow">Performance report</div><h1>' . rvEsc($title) . '</h1></div></div>'
        . '<div class="btns"><button class="secondary" id="export-dropdown-btn" onclick="openPerformanceReport(R.platform, R.period, R.asOf)">Open report</button>'
        . ($isMonthly ? '<button onclick="exportMonthlyDeck(R.platform, R.asOf)">Download monthly deck (PDF)</button>' : '')
        . '</div></div>'
        . '<script>const R = ' . $js . '; window.REPORT_LOGO_URL = "images/webzaa-logo.png";</script>'
        . '<script src="js/performance_reports.js?v=2"></script>'
        . '<script>document.addEventListener("DOMContentLoaded", () => openPerformanceReport(R.platform, R.period, R.asOf));</script>'
        . '</body></html>';
    exit;
}

/* ---------- 3. OTP flow ---------- */
if (empty($_SESSION['rv_csrf'])) {
    $_SESSION['rv_csrf'] = bin2hex(random_bytes(16));
}
$csrf = (string) $_SESSION['rv_csrf'];
$otpState = $_SESSION['rv_otp'][$tokenId] ?? null;
$message = '';
$messageClass = 'err';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!hash_equals($csrf, (string) ($_POST['csrf'] ?? ''))) {
        $message = 'Your session expired. Please try again.';
    } elseif (($_POST['action'] ?? '') === 'send') {
        $lastSent = (int) ($otpState['sent_at'] ?? 0);
        if ($lastSent > time() - REPORT_OTP_RESEND_WAIT) {
            $message = 'Please wait a minute before asking for another code.';
        } elseif (!reportOtpSendAllowed($tokenId)) {
            $message = 'Too many codes requested for this link. Please try again in an hour.';
        } else {
            $code = (string) random_int(100000, 999999);
            try {
                reportSendMail(
                    [$email],
                    'Your code for the ' . $title,
                    '<div style="font-family:Arial,sans-serif;color:#0f172a;max-width:480px;">'
                    . '<p style="font-size:14px;">Your one-time code to open the <strong>' . rvEsc($title) . '</strong> is:</p>'
                    . '<p style="font-size:32px;font-weight:700;letter-spacing:6px;margin:16px 0;">' . $code . '</p>'
                    . '<p style="font-size:13px;color:#64748b;">It expires in 10 minutes. If you didn\'t request it, you can ignore this email.</p></div>',
                    "Your one-time code for the {$title} is {$code}. It expires in 10 minutes."
                );
                $_SESSION['rv_otp'][$tokenId] = [
                    'hash'     => reportOtpHash($code, $tokenId),
                    'expires'  => time() + REPORT_OTP_TTL,
                    'attempts' => 0,
                    'sent_at'  => time(),
                ];
                $otpState = $_SESSION['rv_otp'][$tokenId];
                $message = 'We sent a 6-digit code to ' . reportMaskEmail($email) . '.';
                $messageClass = 'ok';
            } catch (Throwable $e) {
                error_log('[report_view] OTP mail failed: ' . $e->getMessage());
                $message = 'We couldn\'t send the code right now. Please try again shortly.';
            }
        }
    } elseif (($_POST['action'] ?? '') === 'verify') {
        $entered = preg_replace('/\D+/', '', (string) ($_POST['code'] ?? '')) ?? '';
        if (!$otpState) {
            $message = 'Please request a code first.';
        } elseif ((int) $otpState['expires'] < time()) {
            unset($_SESSION['rv_otp'][$tokenId]);
            $otpState = null;
            $message = 'That code has expired. Please request a new one.';
        } elseif ((int) $otpState['attempts'] >= REPORT_OTP_MAX_TRIES) {
            unset($_SESSION['rv_otp'][$tokenId]);
            $otpState = null;
            $message = 'Too many wrong attempts. Please request a new code.';
        } elseif (strlen($entered) === 6 && hash_equals((string) $otpState['hash'], reportOtpHash($entered, $tokenId))) {
            unset($_SESSION['rv_otp'][$tokenId]);
            session_regenerate_id(true);
            reportGrantLinkAccess($platform, $period, $asOf);
            header('Location: report_view.php?t=' . rawurlencode($token), true, 303);
            exit;
        } else {
            $_SESSION['rv_otp'][$tokenId]['attempts'] = (int) $otpState['attempts'] + 1;
            $left = REPORT_OTP_MAX_TRIES - (int) $_SESSION['rv_otp'][$tokenId]['attempts'];
            $message = $left > 0 ? "That code isn't right. {$left} attempt(s) left." : 'Too many wrong attempts. Please request a new code.';
            if ($left <= 0) {
                unset($_SESSION['rv_otp'][$tokenId]);
                $otpState = null;
            }
        }
    }
}

$action = 'report_view.php?t=' . rvEsc(rawurlencode($token));
$msgHtml = $message !== '' ? '<div class="msg ' . $messageClass . '">' . rvEsc($message) . '</div>' : '';
$hasCode = $otpState && (int) $otpState['expires'] > time();

$body = '<div class="card"><img class="logo" src="images/webzaa-logo.png" alt="Webzaa"><div class="eyebrow">Performance report</div><h1>' . rvEsc($title) . '</h1>' . $msgHtml;
if ($hasCode) {
    $body .= '<p>Enter the 6-digit code sent to ' . rvEsc(reportMaskEmail($email)) . '.</p>'
        . '<form method="post" action="' . $action . '" autocomplete="off">'
        . '<input type="hidden" name="csrf" value="' . rvEsc($csrf) . '"><input type="hidden" name="action" value="verify">'
        . '<input name="code" inputmode="numeric" pattern="[0-9]{6}" maxlength="6" autofocus required placeholder="••••••">'
        . '<button type="submit">Open report</button></form>'
        . '<form method="post" action="' . $action . '"><input type="hidden" name="csrf" value="' . rvEsc($csrf) . '">'
        . '<input type="hidden" name="action" value="send"><button class="secondary" type="submit">Send a new code</button></form>';
} else {
    $body .= '<p>For security, we\'ll email a one-time code to ' . rvEsc(reportMaskEmail($email)) . ' before showing this report.</p>'
        . '<form method="post" action="' . $action . '"><input type="hidden" name="csrf" value="' . rvEsc($csrf) . '">'
        . '<input type="hidden" name="action" value="send"><button type="submit">Email me a code</button></form>';
}
$body .= '</div>';

rvPage($title, $body);
