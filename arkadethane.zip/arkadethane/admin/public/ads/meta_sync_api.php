<?php
// Kept for older links: the Meta "Sync with Meta" backend is project_sync_api.php?platform=meta.
$_GET['platform'] = 'meta';
require __DIR__ . '/project_sync_api.php';
