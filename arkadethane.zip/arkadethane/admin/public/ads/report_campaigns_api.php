<?php
/**
 * report_campaigns_api.php — the project's saved Meta / Google campaigns, for the "All campaigns or select
 * campaigns?" question asked before every report download (assets/js/report_picker.js).
 *
 *   GET → {success, view, platforms: [{key: meta|google, name, campaigns: [{id, name, type: performance|awareness}]}]}
 *   Only the campaigns of the current tab (All / Performance / Awareness, cookie pq_view) the role may see.
 *
 * Access: Users & Roles → Reports → Download (app/Core/access.php).
 */
ob_start();
ini_set('display_errors', '0');
session_start();
require_once dirname(__DIR__, 2) . '/app/Core/db.php';
require_once dirname(__DIR__, 2) . '/app/Ads/master_tables.php';

function rcJson(array $p, int $code = 200): never
{
    while (ob_get_level()) {
        ob_end_clean();
    }
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    echo json_encode($p, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}
if (($_SESSION['user_logged'] ?? '') !== 'Y') {
    rcJson(['success' => false, 'error' => 'Please sign in again.'], 401);
}
session_write_close();

try {
    $out = [];
    foreach (['meta' => 'Meta', 'google' => 'Google'] as $key => $name) {
        $s = projectStructure($key);
        $list = [];
        foreach ($s['campaigns'] ?? [] as $id => $cname) {
            $type = ($s['types'][$id] ?? 'performance') === 'awareness' ? 'awareness' : 'performance';
            if (!pqViewShows($type)) {
                continue;   // not in the current tab (All / Performance / Awareness) or the role's campaign types
            }
            $list[] = ['id' => (string) $id, 'name' => (string) $cname, 'type' => $type];
        }
        usort($list, fn($a, $b) => strnatcasecmp($a['name'], $b['name']));
        $out[] = ['key' => $key, 'name' => $name, 'campaigns' => $list];
    }
    rcJson(['success' => true, 'platforms' => $out, 'view' => pqCampaignView()]);
} catch (Throwable $e) {
    error_log('[report_campaigns_api] ' . $e->getMessage());
    rcJson(['success' => false, 'error' => $e->getMessage()], 500);
}
