<?php
declare(strict_types=1);
/**
 * email_report_api.php — the combined Meta + Google report email as HTML, for
 * All Platforms → Reports → Daily / Weekly / Monthly (turned into a PDF in the browser by
 * js/email_report_pdf.js). Same builder as the emails: app/Reports/email_builder.php.
 *
 *   POST {period: daily|weekly|monthly, reports: {meta: {...}, google: {...}}, missing: [platform…],
 *         campaigns?: {meta: [ids], google: [ids]}}   ← "Select campaigns" (js/report_picker.js); null = all
 *        reports = the JSON of meta_performance_report.php / google_performance_report.php (fetched by the page)
 *   → {success, subject, html}
 */
ob_start();
ini_set('display_errors', '0');
session_start();

function erJson(array $p, int $code = 200): never
{
    while (ob_get_level()) {
        ob_end_clean();
    }
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    header('X-Content-Type-Options: nosniff');
    echo json_encode($p, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}
if (($_SESSION['user_logged'] ?? '') !== 'Y') {
    erJson(['success' => false, 'error' => 'Please sign in again.'], 401);
}
session_write_close();

require_once dirname(__DIR__, 2) . '/app/Core/db.php';
require_once dirname(__DIR__, 2) . '/app/Reports/email_builder.php';
require_once dirname(__DIR__, 2) . '/app/Ads/master_tables.php';   // campaign types (All / Performance / Awareness)
// Users & Roles → "Hide numbers": leave this user's hidden metrics out of the report
$GLOBALS['SR_HIDE_METRICS'] = function_exists('pqHiddenMetrics') ? pqHiddenMetrics() : [];

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    erJson(['success' => false, 'error' => 'POST only.'], 405);
}
$in = json_decode((string) file_get_contents('php://input'), true);
if (!is_array($in)) {
    erJson(['success' => false, 'error' => 'Bad request.'], 400);
}
$period = (string) ($in['period'] ?? '');
if (!isset(SR_PERIOD_TITLE[$period])) {
    erJson(['success' => false, 'error' => 'Period must be daily, weekly or monthly.'], 400);
}

// Keep only well-formed platform reports (the same shape the cron job gets).
$reports = [];
foreach (['meta', 'google'] as $p) {
    $r = $in['reports'][$p] ?? null;
    if (is_array($r) && !empty($r['success']) && isset($r['current']['totals'], $r['previous']['totals'], $r['changes'])) {
        $reports[$p] = $r;
    }
}
// "Select campaigns": keep only the chosen campaigns of each platform and add their numbers up again
$pick = $in['campaigns'] ?? null;
if (is_array($pick)) {
    foreach (array_keys($reports) as $p) {
        $ids = array_map('strval', (array) ($pick[$p] ?? []));
        if (!$ids) {
            unset($reports[$p]);    // nothing chosen on this platform: leave it out of the report
            continue;
        }
        $reports[$p] = erOnlyCampaigns($reports[$p], $ids);
    }
    if (!$reports) {
        erJson(['success' => false, 'error' => 'None of the chosen campaigns is in these reports.'], 422);
    }
}
// All / Performance / Awareness tab + Users & Roles → Campaign types: only the campaigns of the view
if (pqCampaignView() !== 'all') {
    foreach (array_keys($reports) as $p) {
        $reports[$p] = erOnlyCampaigns($reports[$p], pqViewCampaignIds($p));
    }
}
$missing = is_array($pick) ? [] : array_values(array_diff(['meta', 'google'], array_keys($reports)));
if (!$reports) {
    erJson(['success' => false, 'error' => 'Neither the Meta nor the Google report could be loaded.'], 422);
}

/** One platform report with only some campaigns: their rows, and totals / changes added up from them. */
function erOnlyCampaigns(array $r, array $ids): array
{
    $keep = array_fill_keys($ids, true);
    $camps = array_values(array_filter($r['campaigns'] ?? [], fn($c) => isset($keep[(string) ($c['campaign_id'] ?? '')])));
    $base = ['spend' => 0.0, 'impressions' => 0, 'clicks' => 0, 'leads' => 0, 'qualified' => 0, 'site_visits' => 0];
    $cur = $prev = $base;
    foreach ($camps as $c) {
        foreach ($base as $k => $_) {
            $cur[$k] += $c['current'][$k] ?? 0;
            $prev[$k] += $c['previous'][$k] ?? 0;
        }
    }
    $derive = function (array $m): array {
        $ratio = fn($a, $b, $mul = 1) => $b > 0 ? round($a / $b * $mul, 2) : null;
        $m['ctr'] = $ratio($m['clicks'], $m['impressions'], 100);
        $m['cpc'] = $ratio($m['spend'], $m['clicks']);
        $m['cpm'] = $ratio($m['spend'], $m['impressions'], 1000);
        $m['cpl'] = $ratio($m['spend'], $m['leads']);
        $m['cpql'] = $ratio($m['spend'], $m['qualified']);
        $m['cpsv'] = $ratio($m['spend'], $m['site_visits']);
        $m['qualified_rate'] = $ratio($m['qualified'], $m['leads'], 100);
        $m['site_visit_rate'] = $ratio($m['site_visits'], $m['qualified'], 100);
        $m['spend'] = round($m['spend'], 2);
        return $m;
    };
    $cur = $derive($cur);
    $prev = $derive($prev);
    $changes = [];
    foreach (['spend', 'impressions', 'clicks', 'ctr', 'cpc', 'cpm', 'leads', 'cpl', 'qualified', 'cpql', 'site_visits', 'cpsv', 'qualified_rate', 'site_visit_rate'] as $k) {
        $c = $cur[$k] ?? null;
        $p = $prev[$k] ?? null;
        $changes[$k] = ($c === null || $p === null) ? null
            : ((float) $p == 0.0 ? ((float) $c == 0.0 ? 0.0 : null) : round(((float) $c - (float) $p) / abs((float) $p) * 100, 2));
    }
    $r['campaigns'] = $camps;
    $r['current']['totals'] = $cur;
    $r['previous']['totals'] = $prev;
    $r['changes'] = $changes;
    $r['unattributed'] = ['current' => ['leads' => 0], 'previous' => ['leads' => 0], 'campaigns' => []];
    $r['daily_series'] = [];
    $r['warnings'] = array_merge(['Selected campaigns only: ' . count($camps) . ' of this platform\'s campaigns had numbers in this period ('
        . count($ids) . ' chosen). Leads not under a chosen campaign are not counted.'],
        array_values(array_filter((array) ($r['warnings'] ?? []), fn($w) => stripos((string) $w, 'did not match') === false)));
    return $r;
}

try {
    [$subject, $html] = srBuildCombinedDailyEmail($reports, $missing, $period);
    erJson(['success' => true, 'subject' => $subject, 'html' => $html, 'missing' => $missing]);
} catch (Throwable $e) {
    error_log('[email_report_api] ' . $e->getMessage() . ' @ ' . $e->getFile() . ':' . $e->getLine());
    erJson(['success' => false, 'error' => 'Could not build the report: ' . $e->getMessage()], 500);
}
