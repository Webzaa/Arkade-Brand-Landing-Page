<?php

declare(strict_types=1);

/**
 * Meta Ads performance report: daily / weekly / monthly comparisons.
 *
 *   GET meta_performance_report.php?period=daily|weekly|monthly[&as_of=YYYY-MM-DD][&debug=1]
 *
 *   daily   : yesterday vs the day before
 *   weekly  : last full Mon–Sun week vs the week before
 *   monthly : last full calendar month vs the month before
 *
 * as_of runs the report as if "today" were that date (e.g. to rebuild an older month's deck).
 * month=YYYY-MM (monthly) reports that month (the current month runs to today) vs the month before.
 *
 * Spend / impressions / clicks come from Meta Insights (campaign level, daily rows).
 * Leads / qualified / site visits come from the CRM `lead` table (pseudo + official DBs),
 * counted by the lead's created date, and matched to Meta campaigns by normalised campaign name.
 */

date_default_timezone_set('Asia/Kolkata');

header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');
header('Cache-Control: no-store, max-age=0');

/** Set to false once everything works; ?debug=1 then stops exposing error details. */
const PERF_DEBUG_ALLOWED = true;

/** lead_status values that count as a Qualified Lead (compared upper-cased and trimmed). */
const PERF_QUALIFIED_STATUSES = ['QUALIFIED', 'IN-QUALIFIED', 'LOST POST QUALIFIED', 'LOST POST QUALIFICATION'];

/** sitevisit_status values that count as a Site Visit (compared upper-cased and trimmed). */
const PERF_SITE_VISIT_STATUSES = ['VISITED', 'VISIT DONE', 'SITE VISIT DONE'];

/**
 * The Meta ad account also runs other projects (e.g. Westgate). Only campaigns listed in the
 * `campaigns` master table (platform = 'meta', filled by sync_meta_structure.php) are reported:
 * their spend, impressions, clicks AND leads. Everything else is left out of every total.
 * If that table is missing or empty, it falls back to campaign names found in the CRM.
 * Set to false to report every campaign in the ad account.
 */
const PERF_ONLY_PROJECT_CAMPAIGNS = true;

/**
 * "Select campaigns" (?campaigns=ID,ID…, js/report_picker.js): narrows the project's campaigns to the chosen ones,
 * so spend and leads of every other campaign are left out like another project's. Returns {names} or null (= all).
 */
function perfOnlyCampaigns(array &$master): ?array
{
    $raw = trim((string) ($_GET['campaigns'] ?? ''));
    // All / Performance / Awareness tab (cookie pq_view) + Users & Roles → Campaign types (cron / emails: every campaign)
    $view = PHP_SAPI === 'cli' || !function_exists('pqCampaignView') ? 'all' : pqCampaignView();
    if (($raw === '' && $view === 'all') || PHP_SAPI === 'cli') {
        return null;
    }
    $keep = [];
    if ($raw === '') {
        $keep = array_fill_keys(array_map('strval', array_keys($master['campaigns'])), true);
    } else {
        foreach (array_slice(explode(',', $raw), 0, 500) as $id) {
            $id = trim($id);
            if ($id !== '' && isset($master['campaigns'][$id])) {
                $keep[$id] = true;
            }
        }
        if (!$keep) {
            throw new InvalidArgumentException('None of the chosen campaigns is saved for this project any more. Choose again.');
        }
    }
    if ($view !== 'all') {
        $keep = array_filter($keep, fn($v, $id) => pqViewShows(pqCampaignType('meta', (string) $id), $view), ARRAY_FILTER_USE_BOTH);
        if (!$keep) {
            throw new InvalidArgumentException('There are no ' . $view . ' campaigns' . ($raw !== '' ? ' among the chosen ones' : '') . ' — switch the tab to All, or choose other campaigns.');
        }
    }
    $master['campaigns'] = array_intersect_key($master['campaigns'], $keep);
    foreach (['name_to_campaign', 'ad_to_campaign'] as $k) {
        if (isset($master[$k])) {
            $master[$k] = array_filter($master[$k], fn($cid) => isset($keep[(string) $cid]));
        }
    }
    return ['names' => array_values(array_map('strval', $master['campaigns'])), 'view' => $view, 'all_campaigns' => $raw === ''];
}

function perfJson(array $payload, int $status = 200): never
{
    // Users & Roles → "Hide numbers": a logged-in user's report leaves out what their role hides (cron / emails: unchanged)
    if (PHP_SAPI !== 'cli' && function_exists('pqStripHiddenMetrics')) {   // no admin session / Super Admin → nothing hidden
        $payload = pqStripHiddenMetrics($payload);
    }
    http_response_code($status);
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PARTIAL_OUTPUT_ON_ERROR);
    exit;
}

// Login check: dashboard users, OTP-verified report links (report_view.php),
// or the cron runner on the command line (send_performance_reports.php).
require_once dirname(__DIR__, 2) . '/app/Reports/report_access.php';
reportBootstrap('meta');

$debugMode = PHP_SAPI === 'cli' || (PERF_DEBUG_ALLOWED && (($_GET['debug'] ?? '') === '1'));

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

try {
    require_once dirname(__DIR__, 2) . '/app/Core/db.php';
    require_once dirname(__DIR__, 2) . '/app/Ads/master_tables.php';   // PQ_META_LEAD_SQL
} catch (Throwable $e) {
    error_log('[Meta Performance Report] config.php failed: ' . $e->getMessage());
    perfJson([
        'success' => false,
        'error' => 'Configuration could not be loaded.',
        'debug' => $debugMode ? ['message' => $e->getMessage()] : null,
    ], 500);
}

// Users & Roles: a signed-in user needs the Reports permission (report links with OTP and cron are not affected)
if (PHP_SAPI !== 'cli' && ($_SESSION['user_logged'] ?? '') === 'Y' && function_exists('pqCan') && !pqCan('reports')) {
    perfJson(['success' => false, 'error' => "Your role doesn't include Reports. Ask a Super Admin for access.", 'no_access' => true], 403);
}
$dbConnections = leadDbs('all');   // every database in LEAD_DATABASES
if (!$dbConnections) {
    perfJson(['success' => false, 'error' => 'No CRM database connection is available.'], 500);
}

/* ======================================================================
 * Helpers
 * ====================================================================== */

/** Works out the current and previous date ranges for a period. */
function perfResolvePeriods(string $period, DateTimeImmutable $today): array
{
    switch ($period) {
        case 'daily':
            $curStart = $today->modify('-1 day');
            $curEnd = $curStart;
            $prevStart = $today->modify('-2 days');
            $prevEnd = $prevStart;
            $label = static fn(DateTimeImmutable $s, DateTimeImmutable $e): string => $s->format('d M Y');
            break;

        case 'weekly':
            $thisMonday = $today->modify('monday this week');
            $curStart = $thisMonday->modify('-7 days');
            $curEnd = $thisMonday->modify('-1 day');
            $prevStart = $thisMonday->modify('-14 days');
            $prevEnd = $thisMonday->modify('-8 days');
            $label = static fn(DateTimeImmutable $s, DateTimeImmutable $e): string =>
                $s->format('Y') === $e->format('Y')
                ? $s->format('d M') . ' – ' . $e->format('d M Y')
                : $s->format('d M Y') . ' – ' . $e->format('d M Y');
            break;

        case 'monthly':
            $firstOfThisMonth = $today->modify('first day of this month');
            $curStart = $firstOfThisMonth->modify('-1 month');
            $curEnd = $firstOfThisMonth->modify('-1 day');
            $prevStart = $firstOfThisMonth->modify('-2 months');
            $prevEnd = $curStart->modify('-1 day');
            $label = static fn(DateTimeImmutable $s, DateTimeImmutable $e): string => $s->format('F Y');
            break;

        default:
            throw new InvalidArgumentException('period must be daily, weekly or monthly.');
    }

    $build = static fn(DateTimeImmutable $s, DateTimeImmutable $e): array => [
        'since' => $s->format('Y-m-d'),
        'until' => $e->format('Y-m-d'),
        'label' => $label($s, $e),
        'days' => $s->diff($e)->days + 1,
    ];

    return [
        'current' => $build($curStart, $curEnd),
        'previous' => $build($prevStart, $prevEnd),
    ];
}

/** Lower-case, strip punctuation and collapse spaces so CRM and Meta campaign names match. */
function perfNormaliseName(string $name): string
{
    $name = html_entity_decode(rawurldecode(trim($name)), ENT_QUOTES | ENT_HTML5, 'UTF-8');
    $name = function_exists('mb_strtolower') ? mb_strtolower($name, 'UTF-8') : strtolower($name);
    $name = preg_replace('/[^\p{L}\p{N}]+/u', ' ', $name) ?? $name;
    return trim(preg_replace('/\s+/u', ' ', $name) ?? $name);
}

function perfEmptyMetrics(): array
{
    return ['spend' => 0.0, 'impressions' => 0, 'clicks' => 0, 'leads' => 0, 'qualified' => 0, 'site_visits' => 0];
}

/** Adds ratio metrics (CTR, CPC, CPL, CPQL, CPSV, …) to a raw metrics array. */
function perfDerive(array $m): array
{
    $ratio = static fn(float $a, float $b, float $mul = 1.0): ?float => $b > 0 ? round($a / $b * $mul, 2) : null;

    $spend = (float) $m['spend'];
    $m['ctr'] = $ratio((float) $m['clicks'], (float) $m['impressions'], 100);
    $m['cpc'] = $ratio($spend, (float) $m['clicks']);
    $m['cpm'] = $ratio($spend, (float) $m['impressions'], 1000);
    $m['cpl'] = $ratio($spend, (float) $m['leads']);
    $m['cpql'] = $ratio($spend, (float) $m['qualified']);
    $m['cpsv'] = $ratio($spend, (float) $m['site_visits']);
    $m['qualified_rate'] = $ratio((float) $m['qualified'], (float) $m['leads'], 100);
    $m['site_visit_rate'] = $ratio((float) $m['site_visits'], (float) $m['qualified'], 100);
    $m['spend'] = round($spend, 2);
    return $m;
}

/** Percentage change for every metric; null when there is nothing to compare against. */
function perfChanges(array $cur, array $prev): array
{
    $keys = [
        'spend',
        'impressions',
        'clicks',
        'ctr',
        'cpc',
        'cpm',
        'leads',
        'cpl',
        'qualified',
        'cpql',
        'site_visits',
        'cpsv',
        'qualified_rate',
        'site_visit_rate'
    ];
    $out = [];
    foreach ($keys as $k) {
        $c = $cur[$k] ?? null;
        $p = $prev[$k] ?? null;
        if ($c === null || $p === null) {
            $out[$k] = null;
        } elseif ((float) $p == 0.0) {
            $out[$k] = ((float) $c == 0.0) ? 0.0 : null;
        } else {
            $out[$k] = round((((float) $c - (float) $p) / abs((float) $p)) * 100, 2);
        }
    }
    return $out;
}

/** Pulls campaign-level daily Insights rows for every ad account. */
function perfFetchMetaInsights(array $accountIds, string $graphVersion, string $token, string $since, string $until, array &$accountErrors): array
{
    $rows = [];

    foreach ($accountIds as $accountId) {
        $url = 'https://graph.facebook.com/' . rawurlencode($graphVersion)
            . '/act_' . rawurlencode($accountId) . '/insights?' . http_build_query([
                'fields' => 'campaign_id,campaign_name,date_start,spend,impressions,clicks',
                'level' => 'campaign',
                'time_increment' => 1,
                'time_range' => json_encode(function_exists('metaSafeSince') ? ['since' => metaSafeSince($since), 'until' => max($until, metaSafeSince($since))] : ['since' => $since, 'until' => $until]),
                'limit' => 500,
                'access_token' => $token,
            ], '', '&', PHP_QUERY_RFC3986);

        try {
            $pageGuard = 0;
            do {
                if (++$pageGuard > 100) {
                    throw new RuntimeException('Too many pages returned by Meta (stopped at 100).');
                }

                $ch = curl_init($url);
                curl_setopt_array($ch, [
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_CONNECTTIMEOUT => 10,
                    CURLOPT_TIMEOUT => 60,
                    CURLOPT_HTTPHEADER => ['Accept: application/json'],
                ]);
                $body = curl_exec($ch);
                $curlError = curl_error($ch);
                $httpStatus = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
                unset($ch);

                if ($body === false) {
                    throw new RuntimeException('cURL request failed: ' . $curlError);
                }

                $response = json_decode((string) $body, true);
                if (!is_array($response)) {
                    throw new RuntimeException('Invalid JSON from Meta (HTTP ' . $httpStatus . ').');
                }

                if ($httpStatus < 200 || $httpStatus >= 300 || isset($response['error'])) {
                    $err = $response['error'] ?? [];
                    $msg = (string) ($err['message'] ?? ('HTTP ' . $httpStatus));
                    if (isset($err['code'])) {
                        $msg .= ' (code ' . $err['code'] . (isset($err['error_subcode']) ? '/' . $err['error_subcode'] : '') . ')';
                    }
                    throw new RuntimeException($msg); // never include the URL: it carries the token
                }

                foreach (($response['data'] ?? []) as $item) {
                    $date = (string) ($item['date_start'] ?? '');
                    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
                        continue;
                    }
                    $rows[] = [
                        'date' => $date,
                        'campaign_id' => (string) ($item['campaign_id'] ?? ''),
                        'campaign_name' => trim((string) ($item['campaign_name'] ?? 'Unknown campaign')),
                        'spend' => (float) ($item['spend'] ?? 0),
                        'impressions' => (int) ($item['impressions'] ?? 0),
                        'clicks' => (int) ($item['clicks'] ?? 0),
                    ];
                }

                $url = (string) ($response['paging']['next'] ?? '');
            } while ($url !== '');
        } catch (Throwable $e) {
            $accountErrors[$accountId] = $e->getMessage();
            error_log('[Meta Performance Report] Meta account ' . $accountId . ': ' . $e->getMessage());
        }
    }

    return $rows;
}

/**
 * Normalised campaign names that belong to this project:
 * DISTINCT `lead`.campaign_name from every CRM database, plus `campaigns_master` where it exists.
 */
function perfProjectCampaignNames(array $dbConnections, array &$warnings): array
{
    $names = [];
    foreach ($dbConnections as $dbName => $db) {
        $queries = [
            'lead' => "SELECT DISTINCT campaign_name FROM `lead` WHERE campaign_name IS NOT NULL AND TRIM(campaign_name) <> ''",
            'campaigns_master' => "SELECT DISTINCT campaign_name FROM `campaigns_master` WHERE campaign_name IS NOT NULL AND TRIM(campaign_name) <> ''",
        ];
        foreach ($queries as $table => $sql) {
            try {
                $res = $db->query($sql);
                while ($row = $res->fetch_row()) {
                    $n = perfNormaliseName((string) $row[0]);
                    if ($n !== '') {
                        $names[$n] = true;
                    }
                }
                $res->free();
            } catch (Throwable $e) {
                if ($table === 'lead') {
                    $warnings[] = "Could not read campaign names from the {$dbName} lead table.";
                    error_log('[Meta Performance Report] campaign list ' . $dbName . ': ' . $e->getMessage());
                }
                // campaigns_master is optional; it may not exist in every database.
            }
        }
    }
    return $names;
}

/**
 * Reads the master tables (campaigns / adgroups / ads) for one platform from the database chosen by
 * MASTER_TABLES_DB (any LEAD_DATABASES key; default: first database that has a `campaigns` table).
 * Returns null when there is no usable master list.
 *
 * @return array{campaigns: array<string,string>, ad_to_campaign: array<string,string>, name_to_campaign: array<string,string>, db: string}|null
 */
function perfLoadMaster(array $dbConnections, string $platform, array &$warnings): ?array
{
    $order = array_keys($dbConnections);
    if (defined('MASTER_TABLES_DB') && isset($dbConnections[(string) MASTER_TABLES_DB])) {
        $order = [(string) MASTER_TABLES_DB];
    }
    foreach ($order as $dbName) {
        $db = $dbConnections[$dbName];
        try {
            $res = $db->query("SHOW TABLES LIKE 'campaigns'");
            $has = $res->num_rows > 0;
            $res->free();
            if (!$has) {
                continue;
            }
            $p = $db->real_escape_string($platform);

            $campaigns = [];
            $nameTo = [];
            $res = $db->query("SELECT TRIM(campaign_id), campaign_name FROM `campaigns` WHERE " . ($p === 'meta' ? "LOWER(COALESCE(NULLIF(TRIM(platform), ''), 'meta')) = 'meta'" : "LOWER(TRIM(platform)) = '{$p}'") . " AND TRIM(campaign_id) <> ''");
            while ($row = $res->fetch_row()) {
                $campaigns[(string) $row[0]] = (string) $row[1];
                $n = perfNormaliseName((string) $row[1]);
                if ($n !== '') {
                    $nameTo[$n] = (string) $row[0];
                }
            }
            $res->free();
            if (!$campaigns) {
                continue;
            }

            $adTo = [];
            try {
                $res = $db->query("SELECT TRIM(a.ad_id), TRIM(g.campaign_id) FROM `ads` a JOIN `adgroups` g ON g.adgroup_id = a.adgroup_id WHERE " . ($p === 'meta' ? "LOWER(COALESCE(NULLIF(TRIM(a.platform), ''), 'meta')) = 'meta'" : "LOWER(TRIM(a.platform)) = '{$p}'"));
                while ($row = $res->fetch_row()) {
                    $adTo[(string) $row[0]] = (string) $row[1];
                }
                $res->free();
            } catch (Throwable $e) {
                $warnings[] = 'Could not read the ads / adgroups master tables; leads are matched to campaigns by name only.';
            }

            return ['campaigns' => $campaigns, 'ad_to_campaign' => $adTo, 'name_to_campaign' => $nameTo, 'db' => $dbName];
        } catch (Throwable $e) {
            error_log('[Meta Performance Report] master tables in ' . $dbName . ': ' . $e->getMessage());
        }
    }
    return null;
}

/* ======================================================================
 * Main
 * ====================================================================== */

$warnings = [];

try {
    $tz = new DateTimeZone('Asia/Kolkata');

    $period = strtolower(trim((string) ($_GET['period'] ?? 'daily')));
    if (!in_array($period, ['daily', 'weekly', 'monthly'], true)) {
        throw new InvalidArgumentException('period must be daily, weekly or monthly.');
    }

    $today = new DateTimeImmutable('today', $tz);
    if (!empty($_GET['as_of'])) {
        $raw = (string) $_GET['as_of'];
        $parsed = DateTimeImmutable::createFromFormat('!Y-m-d', $raw, $tz);
        if (!$parsed || $parsed->format('Y-m-d') !== $raw) {
            throw new InvalidArgumentException('as_of must be a date in YYYY-MM-DD format.');
        }
        if ($parsed > $today) {
            throw new InvalidArgumentException('as_of cannot be in the future.');
        }
        $today = $parsed;
    }

    $periods = perfResolvePeriods($period, $today);

    // ?month=YYYY-MM (monthly only): report that calendar month — the current month runs to today —
    // against the full month before it. Used by the "this month to date" deck.
    if ($period === 'monthly' && !empty($_GET['month'])) {
        $rawMonth = (string) $_GET['month'];
        $m0 = DateTimeImmutable::createFromFormat('!Y-m-d', $rawMonth . '-01', $tz);
        if (!$m0 || $m0->format('Y-m') !== $rawMonth) {
            throw new InvalidArgumentException('month must be in YYYY-MM format.');
        }
        $realToday = new DateTimeImmutable('today', $tz);
        if ($m0 > $realToday) {
            throw new InvalidArgumentException('month cannot be in the future.');
        }
        $mEnd = $m0->modify('last day of this month');
        $partial = $mEnd > $realToday;
        $mEnd = $partial ? $realToday : $mEnd;
        $pStart = $m0->modify('-1 month');
        $pEnd = $m0->modify('-1 day');
        $periods = [
            'current' => ['since' => $m0->format('Y-m-d'), 'until' => $mEnd->format('Y-m-d'),
                          'label' => $m0->format('F Y') . ($partial ? ' (to ' . $mEnd->format('j M') . ')' : ''),
                          'days' => $m0->diff($mEnd)->days + 1],
            'previous' => ['since' => $pStart->format('Y-m-d'), 'until' => $pEnd->format('Y-m-d'),
                           'label' => $pStart->format('F Y'), 'days' => $pStart->diff($pEnd)->days + 1],
        ];
    }
    $rangeSince = $periods['previous']['since'];
    $rangeUntil = $periods['current']['until'];

    $bucketOf = static function (string $date) use ($periods): ?string {
        foreach (['current', 'previous'] as $b) {
            if ($date >= $periods[$b]['since'] && $date <= $periods[$b]['until']) {
                return $b;
            }
        }
        return null;
    };

    /* ---------- Meta configuration ---------- */
    if (!defined('META_ACCESS_TOKEN') || trim((string) META_ACCESS_TOKEN) === '') {
        throw new RuntimeException('META_ACCESS_TOKEN is not configured in config.php.');
    }
    if (!defined('META_API_VERSION') || trim((string) META_API_VERSION) === '') {
        throw new RuntimeException('META_API_VERSION is not configured in config.php.');
    }
    if (defined('META_AD_ACCOUNT_IDS') && is_array(META_AD_ACCOUNT_IDS)) {
        $metaAccountIds = META_AD_ACCOUNT_IDS;
    } elseif (defined('META_AD_ACCOUNT_ID')) {
        $metaAccountIds = [META_AD_ACCOUNT_ID];
    } else {
        throw new RuntimeException('META_AD_ACCOUNT_ID or META_AD_ACCOUNT_IDS is not configured in config.php.');
    }
    $metaAccountIds = array_values(array_unique(array_filter(array_map(
        static fn($id): string => (string) preg_replace('/^act_/', '', trim((string) $id)),
        $metaAccountIds
    ), static fn(string $id): bool => $id !== '')));
    if (!$metaAccountIds) {
        throw new RuntimeException('No valid Meta ad account IDs are configured.');
    }
    if (!function_exists('curl_init')) {
        throw new RuntimeException('PHP cURL extension is required for Meta Graph API requests.');
    }
    $graphVersion = trim((string) META_API_VERSION);
    if ($graphVersion[0] !== 'v') {
        $graphVersion = 'v' . $graphVersion;
    }

    /* ---------- Containers ---------- */
    $totals = ['current' => perfEmptyMetrics(), 'previous' => perfEmptyMetrics()];
    $campaigns = [];
    $unmatched = [];
    $unattributed = [
        'current' => ['leads' => 0, 'qualified' => 0, 'site_visits' => 0],
        'previous' => ['leads' => 0, 'qualified' => 0, 'site_visits' => 0],
    ];

    $series = [];
    $cursor = new DateTimeImmutable($rangeSince, $tz);
    $last = new DateTimeImmutable($rangeUntil, $tz);
    while ($cursor <= $last) {
        $ds = $cursor->format('Y-m-d');
        $series[$ds] = ['date' => $ds, 'label' => $cursor->format('d M'), 'bucket' => $bucketOf($ds)] + perfEmptyMetrics();
        $cursor = $cursor->modify('+1 day');
    }

    /* ---------- 1. Meta spend / impressions / clicks ---------- */
    $metaAccountErrors = [];
    $metaRows = perfFetchMetaInsights($metaAccountIds, $graphVersion, (string) META_ACCESS_TOKEN, $rangeSince, $rangeUntil, $metaAccountErrors);

    if (count($metaAccountErrors) === count($metaAccountIds)) {
        throw new RuntimeException('Meta Graph API failed for all accounts. First error: ' . reset($metaAccountErrors));
    }
    if ($metaAccountErrors) {
        $warnings[] = 'Meta spend is incomplete: ' . count($metaAccountErrors) . ' ad account(s) failed.';
    }

    // Keep only this project's campaigns (drops other projects in the same ad account).
    $excludedCampaigns = [];
    $master = null;
    $filterMode = 'none';
    if (PERF_ONLY_PROJECT_CAMPAIGNS) {
        $master = perfLoadMaster($dbConnections, 'meta', $warnings);
        if (!$master) {
            // Only campaigns saved for this project are reported — none saved yet means none reported.
            $master = ['campaigns' => [], 'ad_to_campaign' => [], 'name_to_campaign' => [], 'db' => null];
            $warnings[] = 'No Meta campaigns are linked to this project yet. Open the Meta dashboard → ⟳ Sync with Meta.';
        }
        $filterMode = 'master_table';
        // "Select campaigns" before the download (?campaigns=ID,ID — js/report_picker.js): only those campaigns
        $selection = perfOnlyCampaigns($master);
        $keep = static fn(array $r): bool => isset($master['campaigns'][(string) $r['campaign_id']]);
        if ($filterMode !== 'none') {
            $metaRows = array_values(array_filter($metaRows, static function (array $r) use ($keep, &$excludedCampaigns): bool {
                if ($keep($r)) {
                    return true;
                }
                $excludedCampaigns[$r['campaign_name']] = round(($excludedCampaigns[$r['campaign_name']] ?? 0) + $r['spend'], 2);
                return false;
            }));
        }
    }

    // Saved (database) names for the project's campaigns.
    if ($master) {
        foreach ($metaRows as &$mr) {
            $mid = (string) ($mr['campaign_id'] ?? '');
            if (isset($master['campaigns'][$mid]) && $master['campaigns'][$mid] !== '') {
                $mr['campaign_name'] = $master['campaigns'][$mid];
            }
        }
        unset($mr);
    }

    // Campaigns are keyed by Meta campaign ID; $nameIndex lets CRM leads be matched by name too.
    $nameIndex = [];
    if ($master) {
        $nameIndex = $master['name_to_campaign'];
    }
    foreach ($metaRows as $r) {
        $b = $bucketOf($r['date']);
        if ($b === null) {
            continue;
        }
        $key = (string) $r['campaign_id'] !== '' ? (string) $r['campaign_id'] : 'name:' . perfNormaliseName($r['campaign_name']);
        if (!isset($campaigns[$key])) {
            $campaigns[$key] = [
                'campaign_id' => $r['campaign_id'],
                'campaign_name' => $r['campaign_name'],
                'current' => perfEmptyMetrics(),
                'previous' => perfEmptyMetrics(),
            ];
        }
        $nameIndex[perfNormaliseName($r['campaign_name'])] = $key;
        foreach (['spend', 'impressions', 'clicks'] as $f) {
            $campaigns[$key][$b][$f] += $r[$f];
            $totals[$b][$f] += $r[$f];
            if (isset($series[$r['date']])) {
                $series[$r['date']][$f] += $r[$f];
            }
        }
    }

    /* ---------- 2. CRM leads / qualified / site visits ---------- */
    $sqlList = static fn(array $vals): string => implode(', ', array_map(
        static fn($v): string => "'" . str_replace("'", "''", (string) $v) . "'",
        $vals
    ));
    $qualifiedList = $sqlList(PERF_QUALIFIED_STATUSES);
    $siteVisitList = $sqlList(PERF_SITE_VISIT_STATUSES);

    $sql = "SELECT DATE(createddate) AS lead_date,
                   campaign_name,
                   TRIM(COALESCE(ad_id, '')) AS ad_id,
                   COUNT(*) AS leads,
                   SUM(CASE WHEN UPPER(TRIM(COALESCE(lead_status, ''))) IN ($qualifiedList) THEN 1 ELSE 0 END) AS qualified,
                   SUM(CASE WHEN UPPER(TRIM(COALESCE(sitevisit_status, ''))) IN ($siteVisitList) THEN 1 ELSE 0 END) AS site_visits
            FROM `lead`
            WHERE createddate >= ? AND createddate < ?
              AND " . PQ_META_LEAD_SQL . "
              AND (lead_status IS NULL OR UPPER(TRIM(lead_status)) NOT IN ('TEST', 'JUNK'))
              AND (name IS NULL OR LOWER(TRIM(name)) NOT LIKE '%test%')
              AND (email IS NULL OR LOWER(TRIM(email)) NOT LIKE '%test%')
              AND (mobile IS NULL OR (
                    LOWER(TRIM(mobile)) NOT LIKE '%test%'
                    AND TRIM(mobile) NOT IN ('9999999999', '8888888888', '0000000000', '1234567890', '1111111111')
              ))
            GROUP BY DATE(createddate), campaign_name, TRIM(COALESCE(ad_id, ''))";

    $start = $rangeSince . ' 00:00:00';
    $endExclusive = (new DateTimeImmutable($rangeUntil, $tz))->modify('+1 day')->format('Y-m-d') . ' 00:00:00';

    $dbErrors = [];
    $dbRowsRead = [];
    $excludedLeads = [];
    $leadsMatchedByAd = 0;
    $leadsMatchedByName = 0;

    foreach ($dbConnections as $dbName => $db) {
        $stmt = null;
        try {
            $stmt = $db->prepare($sql);
            if (!$stmt) {
                throw new RuntimeException('prepare failed: ' . $db->error);
            }
            $stmt->bind_param('ss', $start, $endExclusive);
            if (!$stmt->execute()) {
                throw new RuntimeException('execute failed: ' . $stmt->error);
            }

            $leadDate = $campaignName = $leadAdId = $leads = $qualified = $siteVisits = null;
            $stmt->bind_result($leadDate, $campaignName, $leadAdId, $leads, $qualified, $siteVisits);

            $dbRowsRead[$dbName] = 0;
            while ($stmt->fetch()) {
                $dbRowsRead[$dbName]++;
                $date = (string) $leadDate;
                $b = $bucketOf($date);
                if ($b === null) {
                    continue;
                }

                $vals = ['leads' => (int) $leads, 'qualified' => (int) $qualified, 'site_visits' => (int) $siteVisits];
                $rawName = trim((string) ($campaignName ?? ''));
                $norm = perfNormaliseName($rawName);
                $adId = trim((string) ($leadAdId ?? ''));

                // Which campaign is this lead from? 1) its ad_id via the master tables, 2) its campaign name.
                $key = null;
                if ($master && $adId !== '' && isset($master['ad_to_campaign'][$adId])) {
                    $key = $master['ad_to_campaign'][$adId];
                    $leadsMatchedByAd += $vals['leads'];
                } elseif ($norm !== '' && isset($nameIndex[$norm])) {
                    $key = $nameIndex[$norm];
                    $leadsMatchedByName += $vals['leads'];
                }

                if ($filterMode === 'master_table') {
                    // Only campaigns in the master table count — other leads are left out entirely.
                    if ($key === null || !isset($master['campaigns'][$key])) {
                        $label = $rawName !== '' ? $rawName : '(blank campaign name)';
                        $excludedLeads[$label] = ($excludedLeads[$label] ?? 0) + $vals['leads'];
                        continue;
                    }
                    if (!isset($campaigns[$key])) {
                        // Campaign had leads but no spend in these periods.
                        $campaigns[$key] = [
                            'campaign_id' => $key,
                            'campaign_name' => $master['campaigns'][$key],
                            'current' => perfEmptyMetrics(),
                            'previous' => perfEmptyMetrics(),
                        ];
                    }
                }

                foreach ($vals as $f => $v) {
                    $totals[$b][$f] += $v;
                    if (isset($series[$date])) {
                        $series[$date][$f] += $v;
                    }
                }

                if ($key !== null && isset($campaigns[$key])) {
                    foreach ($vals as $f => $v) {
                        $campaigns[$key][$b][$f] += $v;
                    }
                } else {
                    $uKey = $norm !== '' ? $norm : '(blank)';
                    if (!isset($unmatched[$uKey])) {
                        $unmatched[$uKey] = [
                            'crm_campaign_name' => $rawName !== '' ? $rawName : '(blank campaign name)',
                            'current' => ['leads' => 0, 'qualified' => 0, 'site_visits' => 0],
                            'previous' => ['leads' => 0, 'qualified' => 0, 'site_visits' => 0],
                        ];
                    }
                    foreach ($vals as $f => $v) {
                        $unmatched[$uKey][$b][$f] += $v;
                        $unattributed[$b][$f] += $v;
                    }
                }
            }
        } catch (Throwable $e) {
            $dbErrors[$dbName] = $e->getMessage();
            error_log('[Meta Performance Report] CRM database ' . $dbName . ': ' . $e->getMessage());
        } finally {
            if ($stmt instanceof mysqli_stmt) {
                $stmt->close();
            }
        }
    }

    if (count($dbErrors) === count($dbConnections)) {
        throw new RuntimeException('CRM lead query failed on every database. First error: ' . reset($dbErrors));
    }
    if ($dbErrors) {
        $warnings[] = 'CRM counts are incomplete: database(s) failed: ' . implode(', ', array_keys($dbErrors)) . '.';
    }
    if ($unattributed['current']['leads'] > 0 || $unattributed['previous']['leads'] > 0) {
        $warnings[] = 'Some CRM leads did not match a Meta campaign name. They are included in totals but not in the campaign table.';
    }

    /* ---------- 3. Derived metrics and output ---------- */
    $curTotals = perfDerive($totals['current']);
    $prevTotals = perfDerive($totals['previous']);

    $campaignRows = [];
    foreach ($campaigns as $c) {
        $cur = perfDerive($c['current']);
        $prev = perfDerive($c['previous']);
        $campaignRows[] = [
            'campaign_id' => $c['campaign_id'],
            'campaign_name' => $c['campaign_name'],
            'current' => $cur,
            'previous' => $prev,
            'changes' => perfChanges($cur, $prev),
        ];
    }
    usort($campaignRows, static fn(array $a, array $b): int =>
        [$b['current']['spend'], $b['previous']['spend']] <=> [$a['current']['spend'], $a['previous']['spend']]);

    $seriesOut = array_map(static function (array $d): array {
        $d['spend'] = round((float) $d['spend'], 2);
        return $d;
    }, array_values($series));


    // Linked campaigns but nothing in the reported period → say so instead of a page of zeros.
    if (!empty($master['campaigns']) && (float) ($curTotals['spend'] ?? 0) <= 0 && (int) ($curTotals['leads'] ?? 0) === 0) {
        $warnings[] = 'None of the ' . count($master['campaigns']) . ' Meta campaign(s) linked to this project had spend or leads in '
            . $periods['current']['label'] . '. Check the month, or the linked campaigns (⟳ Sync with Meta).';
    }

    perfJson([
        'success' => true,
        'selection' => $selection ?? null,
        'platform' => 'Meta',
        'period' => $period,
        'as_of' => $today->format('Y-m-d'),
        'timezone' => 'Asia/Kolkata',
        'generated_at' => (new DateTimeImmutable('now', $tz))->format('d M Y, h:i A'),
        'current' => $periods['current'] + ['totals' => $curTotals],
        'previous' => $periods['previous'] + ['totals' => $prevTotals],
        'changes' => perfChanges($curTotals, $prevTotals),
        'campaigns' => $campaignRows,
        'daily_series' => $seriesOut,
        'unattributed' => [
            'current' => $unattributed['current'],
            'previous' => $unattributed['previous'],
            'campaigns' => array_values($unmatched),
        ],
        'definitions' => [
            'leads' => 'CRM Facebook Lead Form records (test/junk excluded), by lead created date.',
            'qualified' => 'lead_status in: ' . implode(', ', PERF_QUALIFIED_STATUSES),
            'site_visits' => 'sitevisit_status in: ' . implode(', ', PERF_SITE_VISIT_STATUSES),
            'spend' => 'Meta Insights spend, campaign level, Asia/Kolkata account days.',
        ],
        'warnings' => $warnings,
        'diagnostics' => [
            'meta_accounts_queried' => count($metaAccountIds),
            'meta_rows_received' => count($metaRows),
            'campaign_filter' => $filterMode,          // master_table | crm_campaign_names | none
            'master_db' => $master['db'] ?? null,
            'master_campaigns' => $master ? count($master['campaigns']) : 0,
            'excluded_campaigns' => $excludedCampaigns,   // campaigns not in the master table => spend left out
            'excluded_leads' => $excludedLeads,       // CRM leads from campaigns not in the master table
            'leads_matched_by_ad_id' => $leadsMatchedByAd,
            'leads_matched_by_name' => $leadsMatchedByName,
            'meta_account_errors' => $metaAccountErrors,
            'crm_rows_read' => $dbRowsRead,
            'crm_errors' => $dbErrors,
        ],
    ]);
} catch (InvalidArgumentException $e) {
    perfJson(['success' => false, 'error' => $e->getMessage()], 400);
} catch (Throwable $e) {
    error_log('[Meta Performance Report] ' . get_class($e) . ': ' . $e->getMessage() . ' @ ' . $e->getFile() . ':' . $e->getLine());
    perfJson([
        'success' => false,
        'error' => 'Unable to build the Meta performance report. Check server logs for details.',
        'warnings' => $warnings,
        'debug' => $debugMode ? [
            'type' => get_class($e),
            'message' => $e->getMessage(),
            'line' => $e->getLine(),
        ] : null,
    ], 500);
}