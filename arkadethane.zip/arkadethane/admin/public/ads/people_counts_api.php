<?php
/**
 * people_counts_api.php — Leads / Qualified / Site visits as unique PEOPLE per platform, for the
 * All Platforms overview (same counting as the PDF report: app/Ads/portfolio_data.php → pfPeriod).
 *
 *   GET ?since=YYYY-MM-DD&until=YYYY-MM-DD
 *   → { success, platforms: { meta: {leads, qualified, sitevisits}, google: {…} }, entries, unmapped }
 * Spend still comes from each platform's own API; this only counts leads.
 */
ob_start();
ini_set('display_errors', '0');
session_start();
require_once dirname(__DIR__, 2) . '/app/Ads/portfolio_data.php';

function pcJson(array $p, int $code = 200): never
{
    while (ob_get_level()) {
        ob_end_clean();
    }
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($p, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}
if (($_SESSION['user_logged'] ?? '') !== 'Y') {
    pcJson(['success' => false, 'error' => 'Not authenticated.'], 401);
}
session_write_close();
@set_time_limit(120);

$valid = fn($d) => is_string($d) && preg_match('/^\d{4}-\d{2}-\d{2}$/', $d) && DateTime::createFromFormat('!Y-m-d', $d) !== false;
$since = (string) ($_GET['since'] ?? '');
$until = (string) ($_GET['until'] ?? '');
if (!$valid($since) || !$valid($until)) {
    pcJson(['success' => false, 'error' => 'Choose a date range.'], 400);
}
if ($since > $until) {
    [$since, $until] = [$until, $since];
}
$conns = pfLeadConns();
if (!$conns) {
    pcJson(['success' => false, 'error' => 'No lead database is reachable.'], 500);
}
try {
    $r = pfPeriod($since, $until, $conns, false);
    $out = [];
    foreach ($r['rows'] as $row) {
        if (($row['type'] ?? '') === 'platform') {
            $out[strtolower((string) $row['platform'])] = ['leads' => (int) $row['leads'], 'qualified' => (int) $row['ql'], 'sitevisits' => (int) $row['sv_done']];
        }
    }
    pcJson(['success' => true, 'since' => $since, 'until' => $until, 'platforms' => $out, 'entries' => $r['entries'], 'unmapped' => $r['unmapped']]);
} catch (Throwable $e) {
    error_log('[people_counts_api] ' . $e->getMessage());
    pcJson(['success' => false, 'error' => $e->getMessage()], 500);
}
