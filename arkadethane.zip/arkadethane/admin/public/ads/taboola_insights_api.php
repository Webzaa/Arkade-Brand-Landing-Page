<?php
// taboola_insights_api.php — Real AI-powered campaign analysis (Groq) for Taboola Native Ads dashboard.
header('Content-Type: application/json');

require_once dirname(__DIR__, 2) . '/app/bootstrap.php';
require_once dirname(__DIR__, 2) . '/app/Core/db.php';   // login + roles & permissions check

$input = file_get_contents("php://input");

if (empty($input)) {
    http_response_code(400);
    die(json_encode([
        "success" => false,
        "message" => "No campaign data received."
    ]));
}

$prompt = <<<PROMPT
You are a Senior Taboola Native Ads Performance Marketing Consultant with 15+ years of experience managing Native Advertising campaigns for the Real Estate industry.

Your responsibility is to analyze Taboola Native Ads campaign performance using ONLY the campaign metrics provided. Never assume or invent missing values.

Analyze the following Taboola-specific metrics where available:

- Spend
- Impressions
- Clicks
- CTR (Click-Through Rate — native ads benchmark is 0.3%–1.0%; above 1.0% is excellent)
- CPM (Cost Per Mille — benchmark is ₹20–₹80 for India Real Estate)
- CPC (Cost Per Click)
- Leads (form submissions captured)
- CPL (Cost Per Lead)
- Qualified Leads (CRM-verified leads)
- CPQL (Cost Per Qualified Lead)
- Walk-ins (site visits booked)
- CPSV (Cost Per Site Visit / Walk-in)
- Campaign Status (RUNNING / PAUSED)

Key Taboola-specific context:
- Taboola is a native content discovery platform; users are in a content-browsing mindset (not searching with intent).
- CTR benchmarks are lower than search or social; anything above 0.5% in Real Estate native is strong.
- Thumbnail creativity and headline relevance directly drive CTR.
- Publisher site quality and audience targeting affect conversion rates.
- Native ads have higher funnel drop-off; CPL will naturally be higher than search.
- Creative fatigue happens faster on native due to content-feed exposure.

For every campaign:

1. Calculate a Health Score (0–100).
2. Determine the overall campaign status.
3. Identify strengths specific to Taboola Native performance.
4. Identify weaknesses (e.g., poor CTR, high CPM, low lead-to-click ratio).
5. Explain the root cause of poor performance in native ad context.
6. Analyze CTR:
   - Is it above/below native benchmark?
   - Is it likely a thumbnail/headline issue or audience mismatch?
7. Analyze CPL vs industry average for Real Estate native ads.
8. Recommend whether to:
   - Increase Budget
   - Maintain Budget
   - Reduce Budget
   - Pause Campaign
9. Suggest Thumbnail/Creative improvements specific to Taboola.
10. Suggest Audience/Publisher targeting improvements.
11. Suggest Landing Page improvements to improve lead capture from native traffic.
12. Set Priority (High / Medium / Low).
13. Write a concise Executive Summary focused on native ad performance.

Also compare all campaigns and identify:

- Best Performing Native Campaign
- Worst Performing Native Campaign
- Campaign Ready for Scaling (strong CTR + CPL)
- Campaign Wasting Budget (high spend, poor CTR or zero leads)
- Overall Account Health for Taboola Native Portfolio

Return ONLY valid JSON.

Required JSON format:

{
  "overall_account": {
    "health_score": 85,
    "status": "Good",
    "summary": "",
    "best_campaign": "",
    "worst_campaign": "",
    "budget_wastage": "",
    "scale_recommendation": "",
    "top_5_actions": []
  },
  "campaigns": [
    {
      "campaign_name": "",
      "health_score": 80,
      "status": "",
      "strengths": [],
      "weaknesses": [],
      "root_cause": [],
      "ctr_analysis": {
        "current_ctr": "",
        "benchmark": "0.3%–1.0%",
        "status": "",
        "recommendation": ""
      },
      "cpl_analysis": {
        "current_cpl": "",
        "status": "",
        "recommendation": ""
      },
      "budget_action": "",
      "creative_recommendations": [],
      "audience_recommendations": [],
      "landing_page_recommendations": [],
      "priority": "",
      "expected_improvement": {
        "ctr": "",
        "cpl": "",
        "leads": "",
        "qualified_leads": ""
      },
      "executive_summary": ""
    }
  ]
}

Rules:

- Health Score must be between 0 and 100.
- Status must be one of:
  "Excellent"
  "Good"
  "Needs Attention"
  "Critical"
- Priority must be:
  "High"
  "Medium"
  "Low"
- Analyze CTR against Taboola native benchmarks (0.3%–1.0%).
- Always mention if poor CTR is likely a creative (thumbnail/headline) issue.
- Use Taboola-specific terminology: publisher sites, native widgets, content discovery, headline, thumbnail.
- Use only the supplied metrics.
- Never fabricate values.
- Ignore missing metrics.
- Return a maximum of 8 campaigns.
- Keep recommendations concise and actionable.
- Return ONLY valid JSON.
- Do not use Markdown.
- Do not include explanatory text outside the JSON.

Campaign Data:

$input
PROMPT;

$post = [
    "model" => GROQ_MODEL,
    "temperature" => 0.4,
    "response_format" => [
        "type" => "json_object"
    ],
    "messages" => [
        [
            "role" => "system",
            "content" => "You are an expert Performance Marketing Consultant specializing in Taboola Native Ads and Real Estate lead generation in India."
        ],
        [
            "role" => "user",
            "content" => $prompt
        ]
    ]
];

$ch = curl_init(GROQ_URL);

curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST => true,
    CURLOPT_TIMEOUT => 60,
    CURLOPT_HTTPHEADER => [
        "Authorization: Bearer " . GROQ_API_KEY,
        "Content-Type: application/json"
    ],
    CURLOPT_POSTFIELDS => json_encode($post)
]);

$response = curl_exec($ch);

if (curl_errno($ch)) {
    echo json_encode([
        "success" => false,
        "error" => curl_error($ch)
    ]);
    curl_close($ch);
    exit;
}

$http = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

$result = json_decode($response, true);

if ($http != 200) {
    echo json_encode([
        "success" => false,
        "response" => $result
    ]);
    exit;
}

$content = trim($result['choices'][0]['message']['content'] ?? '');
$json = json_decode($content, true);

if (json_last_error() !== JSON_ERROR_NONE) {
    echo json_encode([
        "success" => false,
        "raw" => $content
    ]);
    exit;
}

echo json_encode([
    "success" => true,
    "analysis" => $json
]);
