<?php
/**
 * Moved: Meta and Google unmapped leads now live in one place — dashboard.php#unmapped
 * (public/unmapped_leads.php). Taboola keeps using unmapped.php?platform=taboola.
 */
session_start();
if (($_SESSION['user_logged'] ?? '') !== 'Y') {
    header('Location: ../login.php');
    exit;
}
$pqTab = 'meta';
?><!DOCTYPE html><html><head><meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1"><title>Unmapped Leads</title>
<script>try { localStorage.setItem('pq-unmapped-tab', <?= json_encode($pqTab) ?>); } catch (e) {}
location.replace('../dashboard.php#unmapped');</script></head>
<body style="font-family:sans-serif;padding:24px;">Opening <a href="../dashboard.php#unmapped">Unmapped Leads</a>…</body></html>
