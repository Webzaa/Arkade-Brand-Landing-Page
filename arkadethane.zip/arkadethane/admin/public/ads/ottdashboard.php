<?php
/**
 * ottdashboard.php?p=<key> — a MANUAL platform (OTT Video = p=ott, Display, MyGate, …; dashboard.php#m-<key>).
 * Numbers are added per day or pasted from a sheet; columns can be shown / hidden / reordered and custom columns
 * added (typed-in numbers or formulas). ?new=1 opens "Add platform". Backend: ott_api.php · logic: app/Ads/ott.php
 */
session_start();
require_once dirname(__DIR__, 2) . '/app/Core/db.php';   // login + roles & permissions check
if (($_SESSION['user_logged'] ?? '') !== 'Y') {
    header('Location: ../login.php');
    exit;
}
$pf = preg_replace('/[^a-z0-9_]/', '', strtolower((string) ($_GET['p'] ?? 'ott'))) ?: 'ott';
$isNew = !empty($_GET['new']);
$canEdit = function_exists('pqCan') ? pqCan('manual', 'edit') : true;        // Users & Roles → Manual platforms
$canAware = (function_exists('pqCan') ? pqCan('manual', 'awareness') : true) && (!function_exists('pqCanSeeType') || (pqCanSeeType('awareness') && pqCanSeeType('performance')));
?><!DOCTYPE html>
<html lang="en">
<head>
<?= function_exists('pqMetricGuardTag') ? pqMetricGuardTag('../') : '' ?>
<?= function_exists('pqDatesTag') ? pqDatesTag('../') : '' ?>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Manual platform</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Sora:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
<script>
(function () {
    var root = document.documentElement, t = null;
    try { t = localStorage.getItem('performiq-theme'); } catch (e) {}
    root.setAttribute('data-theme', t === 'light' ? 'light' : 'dark');
    if (/[?&]embed=1(&|$)/.test(location.search)) root.classList.add('pq-embed');
    window.addEventListener('storage', function (e) {
        if (e.key === 'performiq-theme') root.setAttribute('data-theme', e.newValue === 'light' ? 'light' : 'dark');
    });
    window.setTheme = function (t) { root.setAttribute('data-theme', t === 'light' ? 'light' : 'dark'); };
})();
</script>
<style>
    :root, html[data-theme="dark"] {
        --bg: #0B0F1A; --surface: #111827; --surface-2: #161D2E; --border: #1E2A42; --border-strong: #2A3957;
        --text: #E2E8F0; --text-dim: #94A3B8; --text-faint: #64748B; --accent: #E8A820; --accent-soft: #E8A8201F;
        --hover: #1A2337; --good: #10B981; --good-soft: #10B9811F; --bad: #EF4444; --bad-soft: #EF44441A;
        --warn: #F59E0B; --warn-soft: #F59E0B1A; --meta: #3987E5; --meta-soft: #3987E51F; --google: #D95926; --google-soft: #D959261F; --ott: #9B6BF2; color-scheme: dark;
    }
    html[data-theme="light"] {
        --bg: #F4F6FA; --surface: #FFFFFF; --surface-2: #F8FAFC; --border: #E2E8F0; --border-strong: #CBD5E1;
        --text: #0F172A; --text-dim: #475569; --text-faint: #94A3B8; --accent: #B7791F; --accent-soft: #B7791F1A;
        --hover: #F1F5F9; --good: #059669; --good-soft: #0596691A; --bad: #DC2626; --bad-soft: #DC26261A;
        --warn: #B45309; --warn-soft: #B453091A; --meta: #2A78D6; --meta-soft: #2A78D61A; --google: #C2410C; --google-soft: #C2410C1A; --ott: #7C4DDB; color-scheme: light;
    }
    * { box-sizing: border-box; }
    body { margin: 0; background: var(--bg); color: var(--text); font: 14px/1.5 'Sora', system-ui, -apple-system, 'Segoe UI', sans-serif; }
    button, input, select { font: inherit; color: inherit; }
    .mono { font-family: 'JetBrains Mono', ui-monospace, monospace; font-variant-numeric: tabular-nums; }
    .wrap { max-width: 1400px; margin: 0 auto; padding: 28px 24px 60px; }
    .pq-embed .wrap { padding-top: 20px; }
    .pq-embed .page-head { display: none; }
    h1 { font-size: 22px; margin: 0 0 4px; }
    .sub { color: var(--text-dim); margin: 0 0 20px; font-size: 13px; }
    .card { background: var(--surface); border: 1px solid var(--border); border-radius: 12px; padding: 18px 20px; margin-bottom: 16px; }
    .bar { display: flex; gap: 10px; align-items: center; flex-wrap: wrap; }
    .bar .grow { flex: 1 1 220px; }
    select, input[type=text], input[type=date], input[type=search] { background: var(--surface-2); border: 1px solid var(--border-strong); border-radius: 8px; padding: 8px 10px; outline: none; min-width: 0; }
    select:focus, input:focus { border-color: var(--accent); }
    .btn { border: 1px solid var(--border-strong); background: var(--surface-2); padding: 8px 14px; border-radius: 8px; cursor: pointer; font-weight: 600; font-size: 13px; white-space: nowrap; }
    .btn:hover { background: var(--hover); }
    .btn.primary { background: var(--accent); border-color: var(--accent); color: #111; }
    .btn.sm { padding: 5px 10px; font-size: 12px; }
    .btn.ghost-bad { color: var(--bad); }
    .btn.danger { background: var(--bad); border-color: var(--bad); color: #fff; }
    .btn:disabled { opacity: .5; cursor: not-allowed; }
    .tabs { display: flex; gap: 6px; flex-wrap: wrap; }
    .tab { border: 1px solid var(--border); background: var(--surface-2); border-radius: 99px; padding: 6px 14px; font-size: 12.5px; cursor: pointer; color: var(--text-dim); font-weight: 600; }
    .tab.on { border-color: var(--accent); color: var(--text); background: var(--accent-soft); }
    .tab b { margin-left: 4px; font-family: 'JetBrains Mono', monospace; }
    .tbl-wrap { overflow: auto; border: 1px solid var(--border); border-radius: 10px; }
    table { width: 100%; border-collapse: collapse; font-size: 12.5px; }
    th { position: sticky; top: 0; z-index: 1; background: var(--surface-2); color: var(--text-dim); font-weight: 600; text-align: left; padding: 9px 10px;
         border-bottom: 1px solid var(--border); white-space: nowrap; font-size: 11px; text-transform: uppercase; letter-spacing: .04em; }
    td { padding: 9px 10px; border-bottom: 1px solid var(--border); vertical-align: top; }
    tr:last-child td { border-bottom: 0; }
    tr.sel td { background: var(--accent-soft); }
    td.chk, th.chk { width: 34px; text-align: center; }
    input[type=checkbox] { accent-color: var(--accent); width: 15px; height: 15px; }
    .pill { display: inline-block; padding: 1px 8px; border-radius: 99px; font-size: 11px; font-weight: 600; white-space: nowrap; }
    .pill.meta { color: var(--meta); background: var(--meta-soft); }
    .pill.google { color: var(--google); background: var(--google-soft); }
    .pill.unknown { color: var(--text-dim); background: var(--surface-2); border: 1px solid var(--border); }
    .pill.warn { color: var(--warn); background: var(--warn-soft); }
    .pill.bad { color: var(--bad); background: var(--bad-soft); }
    .muted { color: var(--text-dim); }
    .faint { color: var(--text-faint); font-size: 11.5px; }
    .map { display: grid; grid-template-columns: repeat(3, minmax(130px, 1fr)) auto; gap: 6px; align-items: center; min-width: 500px; }
    .map select { width: 100%; padding: 6px 8px; font-size: 12px; }
    .map .plat { grid-column: 1 / -1; display: flex; gap: 6px; align-items: center; }
    .note { padding: 11px 14px; border-radius: 10px; font-size: 12.5px; margin-bottom: 14px; border: 1px solid; }
    .note.warn { background: var(--warn-soft); border-color: var(--warn); }
    .note.bad { background: var(--bad-soft); border-color: var(--bad); }
    .note.good { background: var(--good-soft); border-color: var(--good); }
    .bulk { position: sticky; bottom: 12px; z-index: 5; display: flex; gap: 10px; align-items: center; flex-wrap: wrap; background: var(--surface);
            border: 1px solid var(--accent); border-radius: 12px; padding: 10px 14px; box-shadow: 0 10px 30px rgba(0, 0, 0, .35); margin-top: 12px; }
    .pager { display: flex; justify-content: space-between; align-items: center; gap: 10px; flex-wrap: wrap; margin-top: 12px; font-size: 12px; color: var(--text-dim); }
    .pager button { border: 1px solid var(--border); background: var(--surface-2); border-radius: 6px; padding: 4px 10px; cursor: pointer; font-size: 11px; color: var(--text-dim); }
    .pager button.on { background: var(--accent); border-color: var(--accent); color: #111; font-weight: 700; }
    .hidden { display: none !important; }
    .overlay { position: fixed; inset: 0; background: rgba(2, 6, 23, .6); display: grid; place-items: center; z-index: 50; padding: 16px; }
    .dialog { background: var(--surface); border: 1px solid var(--border-strong); border-radius: 14px; padding: 22px; max-width: 620px; width: 100%; max-height: 90vh; overflow: auto; box-shadow: 0 20px 60px rgba(0, 0, 0, .45); }
    .dialog h3 { margin: 0 0 8px; font-size: 17px; }
    .actions { display: flex; justify-content: flex-end; gap: 10px; margin-top: 18px; flex-wrap: wrap; }
    .spinner { width: 15px; height: 15px; border: 2px solid var(--border-strong); border-top-color: var(--accent); border-radius: 50%; display: inline-block; animation: spin .8s linear infinite; vertical-align: -3px; margin-right: 8px; }
    @keyframes spin { to { transform: rotate(360deg); } }
    .toast { position: fixed; right: 24px; bottom: 24px; z-index: 60; background: var(--surface); border: 1px solid var(--border-strong); border-left: 4px solid var(--good);
             padding: 12px 16px; border-radius: 8px; font-size: 13px; box-shadow: 0 10px 30px rgba(0, 0, 0, .35); max-width: 440px; }
    .toast.bad { border-left-color: var(--bad); }
    @media (max-width: 760px) { .wrap { padding: 16px; } }
    .tiles { display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 10px; margin-bottom: 16px; }
    .tile { background: var(--surface); border: 1px solid var(--border); border-radius: 12px; padding: 13px 15px; }
    .tile div { color: var(--text-dim); font-size: 12px; }
    .tile strong { display: block; font-size: 21px; margin-top: 2px; font-family: 'JetBrains Mono', monospace; font-variant-numeric: tabular-nums; }
    .tile small { color: var(--text-faint); font-size: 11px; }
    td.n, th.n { text-align: right; font-family: 'JetBrains Mono', monospace; font-variant-numeric: tabular-nums; white-space: nowrap; }
    tfoot td { font-weight: 700; background: var(--surface-2); border-top: 2px solid var(--border-strong); }
    tr.row:hover td { background: var(--hover); }
    .chart-wrap { position: relative; }
    .chart-wrap svg { display: block; width: 100%; height: 220px; }
    .chart-tip { position: absolute; pointer-events: none; background: var(--surface-2); border: 1px solid var(--border-strong); border-radius: 8px; padding: 7px 10px; font-size: 12px; white-space: nowrap; box-shadow: 0 8px 20px rgba(0,0,0,.3); }
    .seg { display: inline-flex; border: 1px solid var(--border); border-radius: 8px; overflow: hidden; }
    .seg button { background: var(--surface-2); border: 0; padding: 6px 12px; font-size: 12px; cursor: pointer; color: var(--text-dim); }
    .seg button.on { background: var(--accent-soft); color: var(--text); font-weight: 600; }
    .col-list { display: flex; flex-direction: column; gap: 4px; max-height: 330px; overflow: auto; border: 1px solid var(--border); border-radius: 10px; padding: 6px; }
    .col-item { display: flex; align-items: center; gap: 8px; padding: 5px 8px; border-radius: 7px; }
    .col-item:hover { background: var(--hover); }
    .col-item .grow { flex: 1; }
    .col-item button { background: transparent; border: 1px solid var(--border); border-radius: 6px; padding: 1px 7px; cursor: pointer; color: var(--text-dim); }
    .col-item .tag { font-size: 10.5px; color: var(--text-faint); }
    .form-grid { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 10px; }
    .form-grid label { display: flex; flex-direction: column; gap: 4px; font-size: 12px; color: var(--text-dim); }
    .form-grid input, .form-grid select { width: 100%; }
    textarea { width: 100%; min-height: 170px; background: var(--surface-2); border: 1px solid var(--border-strong); border-radius: 8px; padding: 10px; font: 12px/1.45 'JetBrains Mono', monospace; color: var(--text); resize: vertical; }
    .pill.ok { color: var(--good); background: var(--good-soft); }
    .pill.bad { color: var(--bad); background: var(--bad-soft); }
    input[type=number] { background: var(--surface-2); border: 1px solid var(--border-strong); border-radius: 8px; padding: 8px 10px; outline: none; }
    .empty { padding: 34px 20px; text-align: center; color: var(--text-dim); }
    .aw-row { display: flex; align-items: center; gap: 12px; flex-wrap: wrap; margin: 0 0 12px; }
    .aw-opt { display: flex; gap: 10px; align-items: flex-start; padding: 11px 13px; border: 1px solid var(--border); border-radius: 10px; margin-bottom: 8px; cursor: pointer; }
    .aw-opt:has(input:checked) { border-color: var(--accent); background: var(--accent-soft); }
    .aw-opt input { margin-top: 4px; accent-color: var(--accent); }
    .aw-opt b { display: block; font-size: 13.5px; }
    .aw-opt span { color: var(--text-dim); font-size: 12.5px; }
    .aw-sub { margin: 4px 0 10px 26px; max-height: 260px; overflow: auto; border: 1px solid var(--border); border-radius: 10px; }
    .aw-sub .r { display: grid; grid-template-columns: 1fr auto 150px; gap: 10px; align-items: center; padding: 7px 12px; border-bottom: 1px solid var(--border); font-size: 13px; }
    .aw-sub .r:last-child { border-bottom: 0; }
    .aw-sub .r.c { grid-template-columns: auto 1fr auto; }
    .aw-sub input[type=number] { width: 100%; padding: 6px 8px; }
</style>
<script src="../assets/js/target_report.js?v=1"></script>
<?= function_exists('pqViewTag') ? pqViewTag('../') : '' ?>
<?php if (!$canEdit || !$canAware) { ?><style><?= !$canEdit ? '#b-plat, #b-cols, #b-import, #b-add, #e-import, #e-add, [data-edit], [data-split], .chk { display: none !important; }' : '' ?><?= !$canAware ? '#b-aw { display: none !important; }' : '' ?></style><?php } ?>
</head>
<body>
<div class="wrap">
    <div class="page-head">
        <h1 id="p-title">&nbsp;</h1>
        <p class="sub">Daily numbers, added or pasted by hand. CTR, CPM, CPC, CPV, view rate and frequency are calculated.</p>
    </div>

    <div class="card">
        <div class="bar">
            <select id="range" title="Period">
                <option value="today">Today</option>
                <option value="yesterday">Yesterday</option>
                <option value="7">Last 7 days</option>
                <option value="30">Last 30 days</option>
                <option value="month">This month</option>
                <option value="lastmonth">Last month</option>
                <option value="90">Last 90 days</option>
                <option value="last_1y">Last 1 year</option>
                <option value="all" selected>All time</option>
                <option value="custom">Custom…</option>
            </select>
            <span id="custom" class="bar hidden"><input type="date" id="d-from"> <span class="muted">to</span> <input type="date" id="d-to"></span>
            <select id="camp" title="Campaign"><option value="">All campaigns</option></select>
            <span class="seg" id="group"><button data-g="day" class="on">By day</button><button data-g="campaign">By day &amp; campaign</button></span>
            <span class="grow"></span>
            <button class="btn" id="b-plat" title="Rename, colour, lead sources or remove this platform">✎ Platform</button>
            <button class="btn" id="b-aw" title="Is this platform's spend awareness? All of it, a fixed amount per month, or some campaigns">✎ Awareness</button>
            <button class="btn" id="b-cols">⚙ Columns</button>
            <button class="btn" id="b-export">↓ Export CSV</button>
            <button class="btn" id="b-import">⤓ Paste / import</button>
            <button class="btn primary" id="b-add">+ Add day</button>
        </div>
    </div>

    <div id="msg"></div>
    <div class="aw-row hidden" id="aw-row"><div id="aw-host"></div></div>
    <div class="tiles" id="tiles"></div>

    <div class="card">
        <div class="bar" style="justify-content:space-between;margin-bottom:8px;">
            <b style="font-size:14px;">Daily trend</b>
            <select id="metric" title="Metric"></select>
        </div>
        <div class="chart-wrap" id="chart"></div>
    </div>

    <div class="card" style="padding:0;">
        <div class="tbl-wrap" style="border:0;border-radius:12px;max-height:calc(100vh - 200px);">
            <table>
                <thead id="thead"></thead>
                <tbody id="rows"><tr><td class="muted" style="padding:24px;"><span class="spinner"></span>Loading…</td></tr></tbody>
                <tfoot id="tfoot"></tfoot>
            </table>
        </div>
    </div>
    <div class="bulk hidden" id="bulk"></div>
</div>

<script>
(function () {
    'use strict';
    const API = 'ott_api.php';
    const PF = <?= json_encode($pf) ?>, IS_NEW = <?= $isNew ? 'true' : 'false' ?>;
    const $ = s => document.querySelector(s);
    const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
    const S = { rows: [], leads: {}, cols: null, builtin: {}, campaigns: [], group: 'day', sel: new Set(), metric: '', pname: '', plat: null };
    const LS = k => `pq-mp-${k}-${PF}`;
    try { S.group = localStorage.getItem(LS('group')) || 'day'; S.metric = localStorage.getItem(LS('metric')) || ''; } catch (e) {}

    async function api(action, params, body) {
        const qs = new URLSearchParams(Object.assign({ action, p: PF }, params || {}));
        const opt = body ? { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) } : {};
        const res = await fetch(`${API}?${qs}`, Object.assign({ credentials: 'same-origin', cache: 'no-store' }, opt));
        const d = await res.json().catch(() => ({ success: false, error: `Server error (HTTP ${res.status}).` }));
        if (!d.success) throw new Error(d.error || 'Request failed');
        return d;
    }
    function toast(text, bad) {
        const t = document.createElement('div');
        t.className = 'toast' + (bad ? ' bad' : '');
        t.textContent = text;
        document.body.appendChild(t);
        setTimeout(() => t.remove(), 4500);
    }
    /** Opens a dialog. onOk(overlay) → true closes it; false / an error keeps it open so it can be retried. */
    function dialog(html, okText, wide, onOk) {
        const o = document.createElement('div');
        o.className = 'overlay';
        o.innerHTML = `<div class="dialog" role="dialog" aria-modal="true" style="${wide ? 'max-width:860px;' : ''}">${html}<div class="actions"><button class="btn" data-x>Cancel</button>${okText ? `<button class="btn primary" data-ok>${okText}</button>` : ''}</div></div>`;
        document.body.appendChild(o);
        const close = () => o.remove();
        o.querySelector('[data-x]').onclick = close;
        o.addEventListener('click', e => { if (e.target === o) close(); });
        const ok = o.querySelector('[data-ok]');
        if (ok && onOk) ok.onclick = async () => {
            ok.disabled = true;
            const txt = ok.textContent; ok.textContent = 'Saving…';
            try { if (await onOk(o)) close(); }
            catch (e) { toast('❌ ' + e.message, true); }
            finally { if (o.isConnected) { ok.disabled = false; ok.textContent = txt; } }
        };
        return o;
    }

    /* ── numbers ── */
    const inr = (v, dp) => v == null || !isFinite(v) ? '—' : '₹' + Number(v).toLocaleString('en-IN', { minimumFractionDigits: dp, maximumFractionDigits: dp });
    const intf = v => v == null || !isFinite(v) ? '—' : Math.round(v).toLocaleString('en-IN');
    const FORMAT = {
        impressions: intf, clicks: intf, reach: intf, views: intf, leads: intf, qualified: intf, sitevisits: intf,
        spend: v => inr(v, 2), cpm: v => inr(v, 2), cpc: v => inr(v, 2), cpv: v => inr(v, 2),
        cpl: v => inr(v, 0), cpql: v => inr(v, 0), cpsv: v => inr(v, 0),
        ctr: v => v == null ? '—' : v.toFixed(2) + '%', view_rate: v => v == null ? '—' : v.toFixed(2) + '%',
        frequency: v => v == null ? '—' : v.toFixed(2)
    };
    const CUSTOM_FMT = { number: intf, decimal: v => v == null || !isFinite(v) ? '—' : Number(v).toLocaleString('en-IN', { maximumFractionDigits: 2 }),
                         money: v => inr(v, 2), percent: v => v == null || !isFinite(v) ? '—' : Number(v).toFixed(2) + '%' };
    const div = (a, b, m) => b > 0 ? a / b * (m || 1) : null;
    function derive(r) {          // r has the base fields (+ leads); adds every calculated metric
        r.ctr = div(r.clicks, r.impressions, 100); r.cpm = div(r.spend, r.impressions, 1000); r.cpc = div(r.spend, r.clicks);
        r.cpv = div(r.spend, r.views); r.view_rate = div(r.views, r.impressions, 100); r.frequency = div(r.impressions, r.reach);
        if (r.leads != null) { r.cpl = div(r.spend, r.leads); r.cpql = div(r.spend, r.qualified); r.cpsv = div(r.spend, r.sitevisits); }
        return r;
    }

    /* ── formulas for custom columns: names, numbers, + - * / ( ) ── */
    function evalFormula(src, row) {
        const toks = String(src).match(/\s*([A-Za-z_][A-Za-z0-9_]*|\d+(?:\.\d+)?|\.\d+|[()+\-*/])\s*/g);
        if (!toks || toks.join('').replace(/\s/g, '') !== String(src).replace(/\s/g, '')) return null;
        const t = toks.map(x => x.trim()); let i = 0;
        const peek = () => t[i], next = () => t[i++];
        function atom() {
            const x = next();
            if (x === '(') { const v = expr(); if (next() !== ')') throw 0; return v; }
            if (x === '-') return -atom();
            if (/^[\d.]/.test(x)) return parseFloat(x);
            if (/^[A-Za-z_]/.test(x)) { const v = row[x]; return v == null ? NaN : Number(v); }
            throw 0;
        }
        function term() { let v = atom(); while (peek() === '*' || peek() === '/') { const op = next(), w = atom(); v = op === '*' ? v * w : (w === 0 ? NaN : v / w); } return v; }
        function expr() { let v = term(); while (peek() === '+' || peek() === '-') { const op = next(), w = term(); v = op === '+' ? v + w : v - w; } return v; }
        try { const v = expr(); return i === t.length && isFinite(v) ? v : null; } catch (e) { return null; }
    }
    function addCustom(r) {
        for (const c of S.cols.custom) {
            if (c.type === 'manual') r[c.key] = r.extra && r.extra[c.key] != null ? Number(r.extra[c.key]) : (r._sumExtra ? r._sumExtra[c.key] ?? null : null);
        }
        for (const c of S.cols.custom) if (c.type === 'formula') r[c.key] = evalFormula(c.formula, r);
        return r;
    }

    /* ── columns ── */
    function colDef(k) {
        if (S.builtin[k]) return { key: k, label: S.builtin[k][0], kind: S.builtin[k][1] };
        const c = S.cols.custom.find(x => x.key === k);
        return c ? { key: k, label: c.label, kind: c.type, custom: c } : null;
    }
    function visibleCols() {
        return S.cols.order.filter(k => !S.cols.hidden.includes(k)).map(colDef).filter(Boolean)
            .filter(c => !(c.key === 'campaign' && S.group === 'day'));
    }
    const fmtCell = (c, v) => c.custom ? CUSTOM_FMT[c.custom.format || 'number'](v) : (FORMAT[c.key] || intf)(v);

    /* ── dates ── */
    const ymd = d => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
    function range() {
        const v = $('#range').value, now = new Date(), t = ymd(now);
        if (v === 'all') return { since: '', until: '' };
        if (v === 'today') return { since: t, until: t };
        if (v === 'yesterday') { const y = new Date(now); y.setDate(y.getDate() - 1); return { since: ymd(y), until: ymd(y) }; }
        if (v === 'custom') return { since: $('#d-from').value, until: $('#d-to').value };
        if (v === 'last_1y') { const y = new Date(now); y.setFullYear(y.getFullYear() - 1); y.setDate(y.getDate() + 1); return { since: ymd(y), until: t }; }
        if (v === 'month') return { since: ymd(new Date(now.getFullYear(), now.getMonth(), 1)), until: t };
        if (v === 'lastmonth') return { since: ymd(new Date(now.getFullYear(), now.getMonth() - 1, 1)), until: ymd(new Date(now.getFullYear(), now.getMonth(), 0)) };
        const d = new Date(now); d.setDate(d.getDate() - (+v - 1));
        return { since: ymd(d), until: t };
    }
    const nice = d => new Date(d + 'T00:00:00').toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' });
    $('#range').addEventListener('change', () => { $('#custom').classList.toggle('hidden', $('#range').value !== 'custom'); if ($('#range').value !== 'custom') load(); });
    ['#d-from', '#d-to'].forEach(id => $(id).addEventListener('change', () => { if ($('#d-from').value && $('#d-to').value) load(); }));
    $('#camp').addEventListener('change', load);
    $('#group').addEventListener('click', e => {
        const b = e.target.closest('button'); if (!b) return;
        S.group = b.dataset.g; try { localStorage.setItem(LS('group'), S.group); } catch (x) {}
        S.sel.clear(); render();
    });

    /* ── data ── */
    async function load() {
        $('#msg').innerHTML = '';
        try {
            const r = range();
            if (TG && r.since && r.until) TG.update(r);
            const d = await api('list', { since: r.since, until: r.until, campaign: $('#camp').value });
            S.aw = d.awareness || null;
            Object.assign(S, { rows: d.rows, leads: $('#camp').value ? {} : d.leads, cols: d.columns, builtin: d.builtin, campaigns: d.campaigns, totals: d.totals, sources: d.lead_sources,
                               plat: d.platform_info, pname: d.platform });
            $('#p-title').textContent = S.pname; document.title = S.pname;
            document.documentElement.style.setProperty('--ott', S.plat.color);
            const cur = $('#camp').value;
            $('#camp').innerHTML = '<option value="">All campaigns</option>' + S.campaigns.map(c => `<option ${c.name === cur ? 'selected' : ''}>${esc(c.name)}</option>`).join('');
            S.sel.clear();
            render();
            try { window.parent && window.parent !== window && window.parent.postMessage({ type: 'pq-ott-changed' }, '*'); } catch (e) {}
        } catch (e) {
            $('#rows').innerHTML = `<tr><td style="padding:24px;color:var(--bad);">${esc(e.message)}</td></tr>`;
        }
    }

    /** Rows for the table: by day (summed over campaigns, leads added) or by day + campaign. */
    function tableRows() {
        if (S.group === 'campaign') {
            return S.rows.map(r => addCustom(derive(Object.assign({ _ids: [r.id], _raw: [r] }, r))));
        }
        const by = {};
        for (const r of S.rows) {
            const g = by[r.date] ??= { date: r.date, campaign: '', impressions: 0, clicks: 0, reach: 0, views: 0, spend: 0, _ids: [], _raw: [], _sumExtra: {} };
            ['impressions', 'clicks', 'reach', 'views', 'spend'].forEach(f => { g[f] += r[f]; });
            for (const [k, v] of Object.entries(r.extra || {})) g._sumExtra[k] = (g._sumExtra[k] || 0) + Number(v);
            g._ids.push(r.id); g._raw.push(r);
        }
        for (const [d, l] of Object.entries(S.leads)) by[d] ??= { date: d, campaign: '', impressions: 0, clicks: 0, reach: 0, views: 0, spend: 0, _ids: [], _raw: [], _sumExtra: {} };
        return Object.values(by).sort((a, b) => a.date.localeCompare(b.date)).map(g => {
            const l = S.leads[g.date] || { leads: 0, qualified: 0, sitevisits: 0 };
            Object.assign(g, { leads: l.leads, qualified: l.qualified, sitevisits: l.sitevisits });
            g.extra = null;
            return addCustom(derive(g));
        });
    }
    function totalRow(rows) {
        const t = { impressions: 0, clicks: 0, reach: 0, views: 0, spend: 0, leads: 0, qualified: 0, sitevisits: 0, _sumExtra: {} };
        for (const r of rows) {
            ['impressions', 'clicks', 'reach', 'views', 'spend'].forEach(f => { t[f] += r[f]; });
            ['leads', 'qualified', 'sitevisits'].forEach(f => { t[f] += r[f] || 0; });
            for (const c of S.cols.custom) if (c.type === 'manual' && r[c.key] != null) t._sumExtra[c.key] = (t._sumExtra[c.key] || 0) + r[c.key];
        }
        if (S.group === 'campaign') { for (const l of Object.values(S.leads)) { t.leads += l.leads; t.qualified += l.qualified; t.sitevisits += l.sitevisits; } }
        t.extra = null;
        return addCustom(derive(t));
    }

    /* ── render ── */
    function render() {
        $('#group').querySelectorAll('button').forEach(b => b.classList.toggle('on', b.dataset.g === S.group));
        const rows = tableRows(), cols = visibleCols();
        let t = totalRow(rows);
        // All / Performance / Awareness tab: the server sends each row's share of that type (table + tiles = the tab)
        const view = (S.aw && S.aw.view) || 'all';
        const part = view === 'all' ? '' : view;
        $('#aw-row').classList.remove('hidden');
        if (AWUI) AWUI.info(S.aw);
        const days = new Set(S.rows.map(r => r.date)).size;
        const first = S.rows[0] && S.rows[0].date, last = S.rows.length && S.rows[S.rows.length - 1].date;
        const tile = (label, v, sub) => `<div class="tile"><div>${label}</div><strong>${v}</strong><small>${sub || '&nbsp;'}</small></div>`;
        $('#tiles').innerHTML = !S.rows.length ? '' :
            tile(part ? `Spend (${part})` : 'Spend', inr(t.spend, 0), `${days} day${days === 1 ? '' : 's'} · ${nice(first)} – ${nice(last)}`)
            + tile('Impressions', intf(t.impressions), 'CPM ' + inr(t.cpm, 2))
            + (t.reach > 0 ? tile('Reach', intf(t.reach), 'Frequency ' + FORMAT.frequency(t.frequency)) : '')
            + (t.views > 0 ? tile('Views', intf(t.views), 'View rate ' + FORMAT.view_rate(t.view_rate)) + tile('Cost per view', inr(t.cpv, 2), 'CPV') : '')
            + tile('Clicks', intf(t.clicks), 'CTR ' + FORMAT.ctr(t.ctr))
            + (t.views > 0 ? '' : tile('Cost per click', inr(t.cpc, 2), 'CPC'))
            + tile('Leads', intf(t.leads), t.leads ? 'CPL ' + inr(t.cpl, 0) : 'source: ' + (S.sources || []).slice(0, 3).join(' / '));

        // chart metric list = visible numeric columns
        const metricOpts = S.cols.order.map(colDef).filter(c => c && c.kind !== 'dim');
        if (!metricOpts.some(c => c.key === S.metric)) S.metric = t.views > 0 ? 'views' : (t.impressions > 0 ? 'impressions' : 'spend');
        $('#metric').innerHTML = metricOpts.map(c => `<option value="${c.key}" ${c.key === S.metric ? 'selected' : ''}>${esc(c.label)}</option>`).join('');
        drawChart(S.group === 'day' ? rows : tableRowsByDayFor(rows));

        $('#thead').innerHTML = `<tr><th class="chk"><input type="checkbox" id="all" title="Select all"></th>${cols.map(c => `<th class="${c.kind === 'dim' ? '' : 'n'}">${esc(c.label)}</th>`).join('')}<th></th></tr>`;
        if (!rows.length) {
            const types = (S.aw && S.aw.types) || ['performance', 'awareness'];
            const other = part && !types.includes(part);
            $('#rows').innerHTML = `<tr><td colspan="${cols.length + 2}"><div class="empty">${other
                ? `Nothing in the ${esc(window.PQView ? PQView.label(part) : part)} tab — all of ${esc(S.pname)} is ${esc(types[0])} (✎ Awareness). Switch to ${types[0] === 'awareness' ? 'Awareness' : 'Performance'} or All above.`
                : part ? `No ${esc(part)} ${esc(S.pname)} numbers in this period.` : `No ${esc(S.pname)} data in this period yet.`}<br><br><button class="btn primary" id="e-import">⤓ Paste your ${esc(S.pname)} sheet</button> <button class="btn" id="e-add">+ Add a day</button></div></td></tr>`;
            $('#tfoot').innerHTML = '';
            $('#e-import').onclick = importDialog; $('#e-add').onclick = () => editDialog(null);
        } else {
            $('#rows').innerHTML = rows.map((r, i) => {
                const key = r._ids.join('-') || 'l' + r.date;
                const one = r._raw.length === 1;
                return `<tr class="row">
                    <td class="chk">${r._ids.length ? `<input type="checkbox" data-sel="${i}" ${S.sel.has(key) ? 'checked' : ''}>` : ''}</td>
                    ${cols.map(c => c.key === 'date' ? `<td class="mono" style="white-space:nowrap;">${esc(nice(r.date))}${!one && r._raw.length ? `<div class="faint">${r._raw.length} campaigns</div>` : ''}</td>`
                        : c.key === 'campaign' ? `<td>${esc(r.campaign)}</td>` : `<td class="n">${fmtCell(c, r[c.key])}</td>`).join('')}
                    <td style="white-space:nowrap;">${one ? (r._raw[0].share && !r._raw[0].raw ? `<span class="faint" title="Part of this day's numbers is ${esc(part === 'awareness' ? 'performance' : 'awareness')}">${Math.round(r._raw[0].share * 100)}%</span>` : `<button class="btn sm" data-edit="${i}" ${r._raw[0].share ? `title="${Math.round(r._raw[0].share * 100)}% of this day is ${esc(part)} — Edit shows the numbers as saved"` : ''}>Edit</button>`) : (r._raw.length ? `<button class="btn sm" data-split="1" title="This day has several campaigns">By campaign</button>` : '')}</td></tr>`;
            }).join('');
            $('#tfoot').innerHTML = `<tr><td></td>${cols.map(c => c.key === 'date' ? '<td>Total</td>' : c.key === 'campaign' ? '<td></td>' : `<td class="n">${fmtCell(c, t[c.key])}</td>`).join('')}<td></td></tr>`;
            $('#rows').querySelectorAll('[data-edit]').forEach(b => b.onclick = () => { const x = rows[+b.dataset.edit]._raw[0]; editDialog(x.raw || x); });   // a partial row: edit the numbers as saved
            $('#rows').querySelectorAll('[data-split]').forEach(b => b.onclick = () => { S.group = 'campaign'; render(); });
            $('#rows').querySelectorAll('[data-sel]').forEach(cb => cb.onchange = () => {
                const r = rows[+cb.dataset.sel], key = r._ids.join('-');
                cb.checked ? S.sel.add(key) : S.sel.delete(key); renderBulk(rows);
            });
            $('#all').onchange = e => { rows.forEach(r => { if (r._ids.length) e.target.checked ? S.sel.add(r._ids.join('-')) : S.sel.delete(r._ids.join('-')); }); render(); };
        }
        renderBulk(rows);
    }
    function tableRowsByDayFor() { const g = S.group; S.group = 'day'; const r = tableRows(); S.group = g; return r; }
    function renderBulk(rows) {
        const ids = [...S.sel].flatMap(k => k.split('-').map(Number)).filter(Boolean);
        $('#bulk').classList.toggle('hidden', !ids.length);
        if (!ids.length) return;
        $('#bulk').innerHTML = `<b>${ids.length} row(s) selected</b><button class="btn sm danger" id="bk-del">Delete</button><button class="btn sm" id="bk-clear">Clear</button>`;
        $('#bk-clear').onclick = () => { S.sel.clear(); render(); };
        $('#bk-del').onclick = async () => {
            dialog(`<h3>Delete ${ids.length} row(s)?</h3><p class="muted">The ${esc(S.pname)} numbers for these days are removed. This can't be undone.</p>`, 'Delete', false, async () => {
                await api('delete', {}, { ids }); toast('Deleted'); load(); return true;
            });
        };
    }

    /* ── chart (SVG, no library) ── */
    $('#metric').addEventListener('change', () => { S.metric = $('#metric').value; try { localStorage.setItem(LS('metric'), S.metric); } catch (e) {} render(); });
    function drawChart(rows) {
        const el = $('#chart');
        const c = colDef(S.metric);
        const pts = rows.map(r => ({ d: r.date, v: r[S.metric] })).filter(p => p.v != null && isFinite(p.v));
        if (pts.length < 1) { el.innerHTML = '<div class="empty">No data to chart.</div>'; return; }
        const W = el.clientWidth || 900, H = 220, L = 58, R = 12, T = 12, B = 26;
        const max = Math.max(...pts.map(p => p.v), 0) || 1;
        const nice10 = Math.pow(10, Math.floor(Math.log10(max))), top = Math.ceil(max / nice10) * nice10;
        const band = (W - L - R) / pts.length;
        const x = i => L + band * (i + 0.5);                  // bar centre inside its own slot
        const y = v => T + (H - T - B) * (1 - v / top);
        const bw = Math.max(3, Math.min(28, band * 0.6));
        const grid = [0, .25, .5, .75, 1].map(f => `<line x1="${L}" x2="${W - R}" y1="${y(top * f)}" y2="${y(top * f)}" stroke="var(--border)" stroke-width="1"/><text x="${L - 8}" y="${y(top * f) + 4}" text-anchor="end" font-size="10.5" fill="var(--text-faint)">${esc(fmtCell(c, top * f))}</text>`).join('');
        const step = Math.ceil(pts.length / Math.max(1, Math.floor((W - L - R) / 70)));
        const xl = pts.map((p, i) => i % step === 0 ? `<text x="${x(i)}" y="${H - 8}" text-anchor="middle" font-size="10.5" fill="var(--text-faint)">${esc(new Date(p.d + 'T00:00:00').toLocaleDateString('en-GB', { day: 'numeric', month: 'short' }))}</text>` : '').join('');
        const bars = pts.map((p, i) => `<rect x="${x(i) - bw / 2}" y="${y(p.v)}" width="${bw}" height="${Math.max(0, y(0) - y(p.v))}" rx="3" fill="var(--ott)" data-i="${i}"/>`).join('');
        el.innerHTML = `<svg viewBox="0 0 ${W} ${H}" preserveAspectRatio="none" role="img" aria-label="${esc(c.label)} per day">${grid}${bars}${xl}</svg><div class="chart-tip hidden"></div>`;
        const tip = el.querySelector('.chart-tip');
        el.querySelectorAll('rect').forEach(rc => {
            rc.addEventListener('mouseenter', () => {
                const p = pts[+rc.dataset.i];
                tip.innerHTML = `<b>${esc(nice(p.d))}</b><br>${esc(c.label)}: ${esc(fmtCell(c, p.v))}`;
                tip.classList.remove('hidden');
                const r = rc.getBoundingClientRect(), b = el.getBoundingClientRect();
                tip.style.left = Math.min(b.width - 150, Math.max(0, r.left - b.left - 40)) + 'px';
                tip.style.top = Math.max(0, r.top - b.top - 48) + 'px';
                rc.setAttribute('opacity', '.75');
            });
            rc.addEventListener('mouseleave', () => { tip.classList.add('hidden'); rc.removeAttribute('opacity'); });
        });
    }
    let rT = null; window.addEventListener('resize', () => { clearTimeout(rT); rT = setTimeout(render, 200); });

    /* ── add / edit one day ── */
    $('#b-add').onclick = () => editDialog(null);
    function editDialog(r) {
        const manual = S.cols.custom.filter(c => c.type === 'manual');
        const v = r || { date: ymd(new Date()), campaign: $('#camp').value || (S.campaigns[0] ? S.campaigns[0].name : S.pname), impressions: '', clicks: '', reach: '', views: '', spend: '', extra: {} };
        const f = (k, label, type) => `<label>${label}<input type="${type || 'number'}" step="any" min="0" id="f-${k}" value="${esc(v[k] ?? '')}"></label>`;
        const o = dialog(`<h3>${r ? 'Edit' : 'Add'} ${esc(S.pname)} day</h3>
            <div class="form-grid">
                ${f('date', 'Date', 'date')}
                <label>Campaign<input type="text" id="f-campaign" list="camp-list" value="${esc(v.campaign)}"><datalist id="camp-list">${S.campaigns.map(c => `<option value="${esc(c.name)}">`).join('')}</datalist></label>
                ${f('impressions', 'Impressions')}${f('clicks', 'Clicks')}${f('reach', 'Reach')}${f('views', 'Views')}${f('spend', 'Spend (₹)')}
                ${manual.map(c => `<label>${esc(c.label)}<input type="number" step="any" id="fx-${c.key}" value="${esc(v.extra && v.extra[c.key] != null ? v.extra[c.key] : '')}"></label>`).join('')}
            </div>
            <p class="faint" style="margin-top:10px;">CTR, CPM, CPV, view rate and frequency are calculated. Saving a date + campaign that already exists replaces it.</p>
            ${r ? '<p style="margin-top:6px;"><button class="btn sm ghost-bad" id="f-del" type="button">Delete this day</button></p>' : ''}`, r ? 'Save' : 'Add', false, async o => {
            const row = { date: o.querySelector('#f-date').value, campaign: o.querySelector('#f-campaign').value.trim() || S.pname, extra: {} };
            ['impressions', 'clicks', 'reach', 'views', 'spend'].forEach(k => { row[k] = o.querySelector('#f-' + k).value || 0; });
            manual.forEach(c => { const x = o.querySelector('#fx-' + c.key).value; if (x !== '') row.extra[c.key] = x; });
            await api('save', {}, { rows: [row] });
            if (r && (r.date !== row.date || r.campaign !== row.campaign)) await api('delete', {}, { ids: [r.id] });   // moved to another day / campaign
            toast(r ? 'Saved' : 'Added'); load(); return true;
        });
        const del = o.querySelector('#f-del');
        if (del) del.onclick = async () => {
            try { await api('delete', {}, { ids: [r.id] }); o.remove(); toast('Deleted'); load(); } catch (x) { toast('❌ ' + x.message, true); }
        };
    }

    /* ── paste / import ── */
    $('#b-import').onclick = importDialog;
    const MONTHS = { jan: 1, feb: 2, mar: 3, apr: 4, may: 5, jun: 6, jul: 7, aug: 8, sep: 9, sept: 9, oct: 10, nov: 11, dec: 12 };
    function parseDate(s, year) {
        s = String(s || '').trim();
        let m;
        if ((m = s.match(/^(\d{4})-(\d{1,2})-(\d{1,2})$/))) return [+m[1], +m[2], +m[3]];
        if ((m = s.match(/^(\d{1,2})[\/\-.](\d{1,2})[\/\-.](\d{2,4})$/))) return [m[3].length === 2 ? 2000 + +m[3] : +m[3], +m[2], +m[1]];   // dd/mm/yyyy
        if ((m = s.match(/^(\d{1,2})[\s\-]*([A-Za-z]{3,9})\.?(?:[\s\-,]*(\d{2,4}))?$/))) { const mo = MONTHS[m[2].toLowerCase().slice(0, m[2].length > 3 && m[2].toLowerCase().startsWith('sept') ? 4 : 3)]; if (mo) return [m[3] ? (m[3].length === 2 ? 2000 + +m[3] : +m[3]) : year, mo, +m[1]]; }
        if ((m = s.match(/^([A-Za-z]{3,9})\.?\s+(\d{1,2})(?:,?\s*(\d{4}))?$/))) { const mo = MONTHS[m[1].toLowerCase().slice(0, 3)]; if (mo) return [m[3] ? +m[3] : year, mo, +m[2]]; }
        return null;
    }
    const validYmd = ([y, mo, d]) => { const dt = new Date(y, mo - 1, d); return dt.getFullYear() === y && dt.getMonth() === mo - 1 && dt.getDate() === d ? ymd(dt) : null; };
    const num = s => { const v = String(s ?? '').replace(/[₹,\s]/g, '').replace(/%$/, ''); return v === '' || isNaN(v) ? null : Number(v); };
    function parseSheet(text, year, defCampaign) {
        const lines = String(text).replace(/\r/g, '').split('\n').filter(l => l.trim() !== '');
        const split = l => l.includes('\t') ? l.split('\t') : (l.includes(',') && !/\d,\d{3}/.test(l) ? l.split(',') : l.trim().split(/\s{2,}|\s(?=\d)/));
        let hi = lines.findIndex(l => /\bdate\b/i.test(l));
        const out = { rows: [], skipped: [], fileTotal: null, header: [], campaign: defCampaign, ignored: [] };
        if (hi < 0) { out.error = 'No header row with "Date" found. Paste the header row too (Date, Impression, Click, Reach, Views, Spend).'; return out; }
        if (!out.campaign) out.campaign = S.pname;
        const head = split(lines[hi]).map(h => h.trim().toLowerCase());
        // a header written on the title line above (e.g. "MyGates  …  spend") fills an empty header cell
        for (const l of lines.slice(0, hi)) {
            split(l).forEach((h, i) => { h = String(h || '').trim().toLowerCase(); if (i > 0 && h && !head[i]) head[i] = h; });
        }
        const manual = S.cols.custom.filter(c => c.type === 'manual');
        const map = {};
        head.forEach((h, i) => {
            if (/^date|day$/.test(h)) map.date ??= i;
            else if (/impr/.test(h)) map.impressions ??= i;
            else if (/^clicks?$|link click/.test(h)) map.clicks ??= i;
            else if (/reach|unique/.test(h)) map.reach ??= i;
            else if (/view/.test(h) && !/rate|cost|cpv/.test(h)) map.views ??= i;
            else if (/spend|cost|amount/.test(h) && !/per/.test(h)) map.spend ??= i;
            else if (/campaign/.test(h)) map.campaign ??= i;
            else { const c = manual.find(c => c.label.toLowerCase() === h); if (c) map['x:' + c.key] = i; else if (h) out.ignored.push(h); }
        });
        out.header = Object.keys(map);
        for (const l of lines.slice(hi + 1)) {
            const c = split(l);
            const first = String(c[map.date] ?? c[0] ?? '').trim();
            if (/^(grand\s*)?total/i.test(first)) {
                out.fileTotal = {}; ['impressions', 'clicks', 'reach', 'views', 'spend'].forEach(f => { if (map[f] != null) out.fileTotal[f] = num(c[map[f]]); });
                continue;
            }
            const p = parseDate(first, year), d = p && validYmd(p);
            if (!d) { out.skipped.push(l.slice(0, 60)); continue; }
            const row = { date: d, campaign: map.campaign != null && String(c[map.campaign] || '').trim() ? String(c[map.campaign]).trim() : out.campaign || S.pname, extra: {} };
            ['impressions', 'clicks', 'reach', 'views', 'spend'].forEach(f => { row[f] = map[f] != null ? (num(c[map[f]]) ?? 0) : 0; });
            manual.forEach(m => { if (map['x:' + m.key] != null) { const v = num(c[map['x:' + m.key]]); if (v != null) row.extra[m.key] = v; } });
            out.rows.push(row);
        }
        // spend given only once for the whole period (a Total row) → spread it over the days by impressions
        const tot = out.fileTotal && out.fileTotal.spend;
        if (out.rows.length && tot > 0 && out.rows.every(r => !r.spend)) {
            const imp = out.rows.reduce((a, r) => a + (r.impressions || 0), 0);
            let left = Math.round(tot * 100);
            out.rows.forEach((r, i) => {
                const share = i === out.rows.length - 1 ? left : Math.round(tot * 100 * (imp > 0 ? r.impressions / imp : 1 / out.rows.length));
                r.spend = share / 100; left -= share;
            });
            out.spread = { total: tot, by: imp > 0 ? 'impressions' : 'equal' };
        }
        return out;
    }
    function importDialog() {
        const yr = new Date().getFullYear();
        const o = dialog(`<h3>Paste / import ${esc(S.pname)} data</h3>
            <p class="muted" style="margin:0 0 10px;">Copy the rows from your sheet (with the header row) and paste them here, or choose a CSV. Dates like “1 Oct”, “01/10/2026” or “2026-10-01” all work. A “Total” / “Grand Total” row checks the sums — and when spend is only given there, it is spread over the days by impressions. CTR is calculated, so that column is ignored.</p>
            <div class="bar" style="margin-bottom:8px;">
                <label class="muted" style="font-size:12px;">Year for dates without one <select id="i-year">${[yr - 1, yr, yr + 1].map(y => `<option ${y === yr ? 'selected' : ''}>${y}</option>`).join('')}</select></label>
                <label class="muted" style="font-size:12px;">Campaign <input type="text" id="i-camp" placeholder="${esc(S.pname)}" list="camp-list2" style="width:170px;"><datalist id="camp-list2">${S.campaigns.map(c => `<option value="${esc(c.name)}">`).join('')}</datalist></label>
                <label class="btn sm" style="margin:0;">Choose CSV<input type="file" id="i-file" accept=".csv,.txt,.tsv" hidden></label>
            </div>
            <textarea id="i-text" placeholder="Date&#9;Impression&#9;Click&#9;CTR&#9;Reach&#9;Views&#9;Spend&#10;1 Oct&#9;67654&#9;221&#9;0.33&#9;17513&#9;40924&#9;12277.20"></textarea>
            <div id="i-prev" style="margin-top:10px;"></div>`, 'Save rows', true, async () => {
            if (!parsed || parsed.error || !parsed.rows.length) { toast('Nothing to save yet — paste the rows first.', true); return false; }
            const d = await api('save', {}, { rows: parsed.rows });
            toast(`Saved ${d.inserted} new, ${d.updated} updated`); load(); return true;
        });
        const ov = o, ta = o.querySelector('#i-text');
        let parsed = null;
        const preview = () => {
            parsed = parseSheet(ta.value, +ov.querySelector('#i-year').value, ov.querySelector('#i-camp').value.trim());
            const box = ov.querySelector('#i-prev');
            if (!ta.value.trim()) { box.innerHTML = ''; return; }
            if (parsed.error) { box.innerHTML = `<div class="note bad">${esc(parsed.error)}</div>`; return; }
            const sum = f => parsed.rows.reduce((a, r) => a + Number(r[f] || 0), 0);
            let check = '';
            if (parsed.spread) {
                check += `<div class="note warn">Spend ${inr(parsed.spread.total, 2)} is only in the Total row, so it is spread over the ${parsed.rows.length} day(s) ${parsed.spread.by === 'impressions' ? 'by impressions' : 'equally'}. Edit a day afterwards if the real split is different.</div>`;
            }
            if (parsed.fileTotal) {
                const bad = Object.entries(parsed.fileTotal).filter(([f, v]) => v != null && Math.abs(sum(f) - v) > (f === 'spend' ? 1 : 0.5));
                check += bad.length ? `<div class="note warn">The sheet's Total row doesn't match the rows for: ${bad.map(([f, v]) => `${f} (sheet ${f === 'spend' ? inr(v, 2) : intf(v)}, rows ${f === 'spend' ? inr(sum(f), 2) : intf(sum(f))})`).join(', ')}. Check for a missing or extra row.</div>`
                                   : `<div class="note good">Matches the sheet's Total row (${parsed.rows.length} days, spend ${inr(sum('spend'), 2)}).</div>`;
            }
            const exist = new Set(S.rows.map(r => r.date + '|' + r.campaign));
            const repl = parsed.rows.filter(r => exist.has(r.date + '|' + r.campaign)).length;
            box.innerHTML = check
                + `<div class="faint" style="margin-bottom:6px;">${parsed.rows.length} day(s) read · campaign “${esc(parsed.rows[0] ? parsed.rows[0].campaign : parsed.campaign || S.pname)}”${repl ? ` · <b>${repl} will replace days already saved</b>` : ''}${parsed.skipped.length ? ` · ${parsed.skipped.length} line(s) skipped` : ''}${parsed.ignored.length ? ` · ignored columns: ${esc(parsed.ignored.join(', '))}` : ''}</div>`
                + `<div class="tbl-wrap" style="max-height:240px;"><table><thead><tr><th>Date</th><th>Campaign</th><th class="n">Impr.</th><th class="n">Clicks</th><th class="n">Reach</th><th class="n">Views</th><th class="n">Spend</th></tr></thead><tbody>`
                + parsed.rows.map(r => `<tr><td class="mono">${esc(nice(r.date))}</td><td>${esc(r.campaign)}</td><td class="n">${intf(r.impressions)}</td><td class="n">${intf(r.clicks)}</td><td class="n">${intf(r.reach)}</td><td class="n">${intf(r.views)}</td><td class="n">${inr(r.spend, 2)}</td></tr>`).join('')
                + `</tbody><tfoot><tr><td>Total</td><td></td><td class="n">${intf(sum('impressions'))}</td><td class="n">${intf(sum('clicks'))}</td><td class="n">${intf(sum('reach'))}</td><td class="n">${intf(sum('views'))}</td><td class="n">${inr(sum('spend'), 2)}</td></tr></tfoot></table></div>`;
        };
        ta.addEventListener('input', preview);
        ov.querySelector('#i-year').addEventListener('change', preview);
        ov.querySelector('#i-camp').addEventListener('input', preview);
        ov.querySelector('#i-file').addEventListener('change', async e => { const f = e.target.files[0]; if (f) { ta.value = await f.text(); preview(); } });
        ta.focus();
    }

    /* ── columns ── */
    $('#b-cols').onclick = columnsDialog;
    async function columnsDialog() {
        const cfg = JSON.parse(JSON.stringify(S.cols));
        const keysFor = () => [...Object.keys(S.builtin).filter(k => S.builtin[k][1] !== 'dim'), ...cfg.custom.map(c => c.key)];
        const o = document.createElement('div');
        o.className = 'overlay';
        o.innerHTML = `<div class="dialog" role="dialog" aria-modal="true" style="max-width:680px;">
            <h3>Columns</h3>
            <p class="muted" style="margin:0 0 10px;">Tick to show, use ↑ ↓ to reorder. Add your own: a <b>number</b> you type in per day, or a <b>formula</b> from other columns (e.g. <span class="mono">spend / views</span>). Saved for everyone.</p>
            <div class="col-list" id="c-list"></div>
            <h4 style="margin:16px 0 8px;font-size:14px;">Add a column</h4>
            <div class="form-grid">
                <label>Name<input type="text" id="c-name" maxlength="40" placeholder="e.g. Completed views"></label>
                <label>Type<select id="c-type"><option value="manual">Number I type in</option><option value="formula">Formula</option></select></label>
                <label id="c-fwrap" class="hidden" style="grid-column:1/-1;">Formula<input type="text" id="c-formula" class="mono" placeholder="spend / views"><span class="faint" id="c-keys"></span></label>
                <label>Format<select id="c-format"><option value="number">Number</option><option value="decimal">Decimal</option><option value="money">₹ Money</option><option value="percent">%</option></select></label>
                <label style="justify-content:flex-end;"><button class="btn" id="c-add" type="button">+ Add column</button></label>
            </div>
            <div class="actions"><button class="btn" id="c-reset">Reset to default</button><span style="flex:1"></span><button class="btn" data-x>Cancel</button><button class="btn primary" id="c-save">Save</button></div></div>`;
        document.body.appendChild(o);
        const close = () => o.remove();
        o.querySelector('[data-x]').onclick = close;
        o.addEventListener('click', e => { if (e.target === o) close(); });
        const label = k => S.builtin[k] ? S.builtin[k][0] : (cfg.custom.find(c => c.key === k) || {}).label;
        const tag = k => { const c = cfg.custom.find(x => x.key === k); return c ? (c.type === 'formula' ? 'formula: ' + c.formula : 'typed in') : ({ base: 'from the sheet', calc: 'calculated', lead: 'from the CRM', dim: '' })[S.builtin[k][1]]; };
        function draw() {
            o.querySelector('#c-list').innerHTML = cfg.order.map((k, i) => `<div class="col-item">
                <input type="checkbox" data-vis="${k}" ${cfg.hidden.includes(k) ? '' : 'checked'} ${k === 'date' ? 'disabled' : ''}>
                <span class="grow">${esc(label(k))} <span class="tag">${esc(tag(k) || '')}</span></span>
                <button data-up="${i}" ${i === 0 ? 'disabled' : ''} title="Move up">↑</button><button data-down="${i}" ${i === cfg.order.length - 1 ? 'disabled' : ''} title="Move down">↓</button>
                ${cfg.custom.some(c => c.key === k) ? `<button data-rm="${k}" title="Remove column" style="color:var(--bad)">✕</button>` : ''}</div>`).join('');
            o.querySelectorAll('[data-vis]').forEach(cb => cb.onchange = () => { const k = cb.dataset.vis; cfg.hidden = cfg.hidden.filter(x => x !== k); if (!cb.checked) cfg.hidden.push(k); });
            o.querySelectorAll('[data-up]').forEach(b => b.onclick = () => { const i = +b.dataset.up; [cfg.order[i - 1], cfg.order[i]] = [cfg.order[i], cfg.order[i - 1]]; draw(); });
            o.querySelectorAll('[data-down]').forEach(b => b.onclick = () => { const i = +b.dataset.down; [cfg.order[i + 1], cfg.order[i]] = [cfg.order[i], cfg.order[i + 1]]; draw(); });
            o.querySelectorAll('[data-rm]').forEach(b => b.onclick = () => { const k = b.dataset.rm; cfg.custom = cfg.custom.filter(c => c.key !== k); cfg.order = cfg.order.filter(x => x !== k); cfg.hidden = cfg.hidden.filter(x => x !== k); draw(); });
            o.querySelector('#c-keys').textContent = 'Use: ' + keysFor().join(', ');
        }
        o.querySelector('#c-type').onchange = e => o.querySelector('#c-fwrap').classList.toggle('hidden', e.target.value !== 'formula');
        o.querySelector('#c-add').onclick = () => {
            const name = o.querySelector('#c-name').value.trim(), type = o.querySelector('#c-type').value, formula = o.querySelector('#c-formula').value.trim();
            if (!name) { toast('Give the column a name.', true); return; }
            let key = 'x_' + name.toLowerCase().replace(/[^a-z0-9]+/g, '_').replace(/^_|_$/g, '').slice(0, 30);
            while (cfg.order.includes(key)) key += '_2';
            if (type === 'formula') {
                const ids = formula.match(/[A-Za-z_][A-Za-z0-9_]*/g) || [];
                const bad = ids.filter(x => !keysFor().includes(x));
                if (!formula || bad.length || evalFormula(formula, Object.fromEntries(keysFor().map(k => [k, 1]))) === null) { toast('Formula: ' + (bad.length ? 'unknown name ' + bad.join(', ') : 'use column names, numbers and + - * / ( )'), true); return; }
            }
            cfg.custom.push(Object.assign({ key, label: name, type, format: o.querySelector('#c-format').value }, type === 'formula' ? { formula } : {}));
            cfg.order.push(key);
            o.querySelector('#c-name').value = ''; o.querySelector('#c-formula').value = '';
            o.querySelector('#c-type').value = 'manual'; o.querySelector('#c-format').value = 'number';
            o.querySelector('#c-fwrap').classList.add('hidden');
            draw();
        };
        o.querySelector('#c-reset').onclick = () => { cfg.order = Object.keys(S.builtin); cfg.hidden = ['campaign', 'cpc', 'leads', 'cpl', 'qualified', 'cpql', 'sitevisits', 'cpsv'].concat(PF === 'ott' ? [] : ['views', 'view_rate', 'cpv']); cfg.order = ['date', 'impressions', 'clicks', 'ctr', 'reach', 'views', 'spend', 'cpm', 'cpv', 'view_rate', 'frequency', 'campaign', 'cpc', 'leads', 'cpl', 'qualified', 'cpql', 'sitevisits', 'cpsv', ...cfg.custom.map(c => c.key)]; draw(); };
        o.querySelector('#c-save').onclick = async () => {
            try { const d = await api('columns', {}, cfg); S.cols = d.columns; close(); toast('Columns saved'); render(); }
            catch (e) { toast('❌ ' + e.message, true); }
        };
        draw();
    }

    /* ── platform: add / rename / colour / lead sources / remove ── */
    const tellParent = (msg) => { try { if (window.parent && window.parent !== window) { window.parent.postMessage(msg, '*'); return true; } } catch (e) {} return false; };
    $('#b-plat').onclick = () => platformDialog(false);

    /* ── awareness: all spend, a fixed amount per month, or some campaigns ── */
    const AWUI = window.PQView ? PQView.mount(document.getElementById('aw-host'), { onChange: () => load(), untagged: 'No awareness spend set for this platform (✎ Awareness).' }) : null;
    $('#b-aw').onclick = () => awarenessDialog();
    const monthName = m => new Date(m + '-01T00:00:00').toLocaleDateString('en-GB', { month: 'long', year: 'numeric' });
    async function awarenessDialog() {
        let d;
        try { d = await api('awareness'); } catch (e) { toast('❌ ' + e.message, true); return; }
        const cfg = d.awareness || { mode: 'none', campaigns: [], amounts: {} };
        const months = d.months.slice();
        Object.keys(cfg.amounts || {}).forEach(m => { if (!months.some(x => x.month === m)) months.push({ month: m, spend: 0 }); });
        months.sort((a, b) => b.month.localeCompare(a.month));
        const opt = (v, title, sub) => `<label class="aw-opt"><input type="radio" name="aw-mode" value="${v}" ${cfg.mode === v ? 'checked' : ''}><div><b>${title}</b><span>${sub}</span></div></label>`;
        const monthRow = m => `<div class="r"><div>${esc(monthName(m.month))}</div><div class="faint">spend ${inr(m.spend, 0)}</div>
            <input type="number" min="0" step="1" data-month="${m.month}" value="${cfg.amounts && cfg.amounts[m.month] ? cfg.amounts[m.month] : ''}" placeholder="₹ awareness" aria-label="Awareness amount for ${esc(monthName(m.month))}"></div>`;
        const o = dialog(`<h3>Awareness spend · ${esc(S.pname)}</h3>
            <p class="muted" style="margin:0 0 12px;">The awareness spend shows in the <b>Awareness</b> tab and in <b>All</b>; the <b>Performance</b> tab leaves it out of spend, CPL and CPQL — the same tabs as Meta and Google. Leads count as performance, unless all of it is awareness. A platform that is all awareness is hidden from roles without “Show awareness”.</p>
            ${opt('all', 'All of it is awareness', `Every rupee spent on ${esc(S.pname)} counts as awareness.`)}
            ${opt('amount', 'A specific amount', 'Enter how much of each month’s spend is awareness. It is spread over that month’s days by their spend.')}
            <div class="aw-sub" id="aw-months" hidden>${months.length ? months.map(monthRow).join('') : '<div class="r"><div class="muted">No spend saved yet.</div></div>'}
                <div class="r"><div class="muted">Another month</div><input type="month" id="aw-newm" aria-label="Add a month"><button class="btn sm" type="button" id="aw-addm">Add</button></div></div>
            ${opt('campaigns', 'Only some campaigns', 'The full spend of the campaigns you tick is awareness.')}
            <div class="aw-sub" id="aw-camps" hidden>${d.campaigns.length ? d.campaigns.map(c => `<label class="r c"><input type="checkbox" value="${esc(c.name)}" ${cfg.campaigns.includes(c.name) ? 'checked' : ''}><div>${esc(c.name)}</div><div class="faint">${inr(c.spend, 0)}</div></label>`).join('') : '<div class="r"><div class="muted">No campaigns saved yet.</div></div>'}</div>
            ${opt('none', 'None — all of it is performance', 'Nothing is left out.')}`, 'Save', true, async ov => {
                const mode = (ov.querySelector('input[name=aw-mode]:checked') || {}).value || 'none';
                const amounts = {};
                ov.querySelectorAll('[data-month]').forEach(i => { const v = parseFloat(i.value); if (v > 0) amounts[i.dataset.month] = v; });
                const campaigns = [...ov.querySelectorAll('#aw-camps input:checked')].map(i => i.value);
                if (mode === 'amount') {
                    const over = months.filter(m => amounts[m.month] > m.spend && m.spend > 0);
                    if (over.length) toast(`Note: the amount for ${over.map(m => monthName(m.month)).join(', ')} is more than that month's spend — only the spend is counted.`);
                }
                await api('awareness', {}, { mode, amounts, campaigns });
                toast('Awareness saved');
                tellParent({ type: 'pq-ott-changed' });
                load();
                return true;
            });
        const sync = () => {
            const mode = (o.querySelector('input[name=aw-mode]:checked') || {}).value;
            o.querySelector('#aw-months').hidden = mode !== 'amount';
            o.querySelector('#aw-camps').hidden = mode !== 'campaigns';
        };
        o.querySelectorAll('input[name=aw-mode]').forEach(i => i.addEventListener('change', sync));
        o.querySelector('#aw-addm').onclick = () => {
            const m = o.querySelector('#aw-newm').value;
            if (!/^\d{4}-\d{2}$/.test(m) || o.querySelector(`[data-month="${m}"]`)) return;
            o.querySelector('#aw-newm').closest('.r').insertAdjacentHTML('beforebegin', monthRow({ month: m, spend: 0 }));
            o.querySelector(`[data-month="${m}"]`).focus();
        };
        sync();
    }
    const PALETTE = ['#9B6BF2', '#0EA5E9', '#14B8A6', '#F59E0B', '#EC4899', '#84CC16', '#6366F1', '#F97316'];
    async function platformDialog(isNew) {
        let color = '#0EA5E9';
        if (isNew) {    // suggest a colour no other manual platform uses yet
            try { const used = (await api('platforms')).platforms.map(x => x.color.toLowerCase()); color = PALETTE.find(c => !used.includes(c.toLowerCase())) || color; } catch (e) {}
        }
        const p = isNew ? { key: '', name: '', color, lead_sources: [] } : S.plat;
        const days = S.campaigns.reduce((a, c) => a + c.days, 0);
        const o = dialog(`<h3>${isNew ? 'Add a platform' : 'Platform settings'}</h3>
            <p class="muted" style="margin:0 0 12px;">${isNew ? 'A platform whose numbers you add or paste by hand — e.g. Display, MyGate, TOI Interstitial. It gets its own page in the sidebar and is added to All Platforms.' : 'Name and colour are used in the sidebar, on All Platforms and in the charts.'}</p>
            <div class="form-grid">
                <label>Name<input type="text" id="pl-name" maxlength="40" value="${esc(p.name)}" placeholder="e.g. Display"></label>
                <label>Colour<input type="color" id="pl-color" value="${esc(p.color)}" style="height:38px;padding:3px;"></label>
                <label style="grid-column:1/-1;">Lead sources <span class="faint">(optional — CRM campaignsource values counted as this platform's leads, comma separated)</span>
                    <input type="text" id="pl-src" value="${esc((p.lead_sources || []).join(', '))}" placeholder="e.g. mygate, my gate"></label>
            </div>
            ${isNew ? '' : `<div class="note bad" style="margin-top:14px;display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap;">
                <span>Remove <b>${esc(p.name)}</b> and its ${days} saved day(s). This can't be undone.</span>
                <button class="btn sm danger" id="pl-del" type="button">Remove platform</button></div>`}`,
            isNew ? 'Add platform' : 'Save', false, async (ov) => {
                const body = { key: isNew ? '' : PF, name: ov.querySelector('#pl-name').value.trim(), color: ov.querySelector('#pl-color').value,
                               lead_sources: ov.querySelector('#pl-src').value };
                const d = await api('platform', {}, body);
                toast(isNew ? `${d.platform.name} added` : 'Saved');
                if (!tellParent({ type: 'pq-platforms-changed', key: d.platform.key })) location.href = 'ottdashboard.php?p=' + encodeURIComponent(d.platform.key);
                else if (!isNew) load();
                return true;
            });
        const del = o.querySelector('#pl-del');
        if (del) del.onclick = () => {
            dialog(`<h3>Remove ${esc(p.name)}?</h3><p class="muted">Its page, its column layout and all ${days} saved day(s) are deleted. All Platforms stops counting it.</p>
                <label class="muted" style="font-size:12.5px;">Type <b>${esc(p.name)}</b> to confirm<input type="text" id="pl-confirm" style="width:100%;margin-top:6px;"></label>`, 'Remove', false, async (ov2) => {
                if (ov2.querySelector('#pl-confirm').value.trim() !== p.name) { toast('Type the platform name to confirm.', true); return false; }
                const d = await api('platform_delete', {}, { key: PF });
                toast(`Removed (${d.deleted_rows} day(s) deleted)`);
                o.remove();
                if (!tellParent({ type: 'pq-platforms-changed', key: '' })) location.href = '../dashboard.php#overview';
                return true;
            });
        };
        setTimeout(() => o.querySelector('#pl-name').focus(), 30);
    }

    /* ── export ── */
    $('#b-export').onclick = () => {
        const rows = tableRows(), t = totalRow(rows), cols = visibleCols();
        const q = v => `"${String(v ?? '').replace(/"/g, '""')}"`;
        const raw = (c, v) => c.key === 'date' || c.key === 'campaign' ? v : (v == null || !isFinite(v) ? '' : Math.round(v * 10000) / 10000);
        const lines = [cols.map(c => q(c.label)).join(',')].concat(rows.map(r => cols.map(c => q(raw(c, r[c.key]))).join(',')))
            .concat([cols.map(c => q(c.key === 'date' ? 'Total' : c.key === 'campaign' ? '' : raw(c, t[c.key]))).join(',')]);
        const a = document.createElement('a');
        a.href = URL.createObjectURL(new Blob(['﻿' + lines.join('\r\n')], { type: 'text/csv' }));
        a.download = `${(S.pname || PF).replace(/[^A-Za-z0-9]+/g, '_')}_${ymd(new Date())}.csv`;
        a.click();
        setTimeout(() => URL.revokeObjectURL(a.href), 2000);
    };

    // ── PerformIQ: one date filter for every dashboard (main dashboard top bar) + "Target vs Achieved" card ──
    var TG = null;
    (function () {
        const EMBED = /[?&]embed=1(&|$)/.test(location.search);
        const qp = new URLSearchParams(location.search);
        const setCustom = (s, u) => { $('#range').value = 'custom'; $('#d-from').value = s; $('#d-to').value = u; };
        if (qp.get('since') && qp.get('until')) setCustom(qp.get('since'), qp.get('until'));
        if (EMBED) { $('#range').style.display = 'none'; $('#custom').classList.add('hidden'); }
        if (!IS_NEW && window.PQTargets) {
            const host = document.createElement('div');
            host.id = 'pq-targets';
            const first = document.querySelector('.wrap .card');
            if (first) first.after(host); else document.body.prepend(host);
            TG = PQTargets.mount(host, { api: '../targets_api.php', platform: 'm-' + PF, editUrl: '../dashboard.php#targets' });
        }
        window.addEventListener('message', (e) => {
            const d = e.data;
            if (!d || d.type !== 'pq-range' || e.source !== window.parent || !d.since || !d.until || IS_NEW) return;
            if ($('#range').value === 'custom' && $('#d-from').value === d.since && $('#d-to').value === d.until) return;
            setCustom(d.since, d.until);
            load();
        });
    })();

    if (IS_NEW) {
        $('#p-title').textContent = 'Add a platform';
        document.querySelectorAll('.card, #tiles').forEach(el => el.classList.add('hidden'));
        $('#msg').innerHTML = `<div class="card"><p class="muted" style="margin:0 0 12px;">Add a platform whose numbers you enter or paste by hand (Display, MyGate, TOI Interstitial, …).</p><button class="btn primary" id="np-open">+ Add a platform</button></div>`;
        $('#np-open').onclick = () => platformDialog(true);
        platformDialog(true);
    } else {
        load();
    }
})();
</script>
</body>
</html>
