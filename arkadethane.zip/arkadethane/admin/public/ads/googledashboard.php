<?php
// ===m=== Uncomment Below for Error Reporting ===m===
// ini_set('display_errors', 1);
// ini_set('display_startup_errors', 1);
// error_reporting(E_ALL);
// ===m=== Uncomment Above for Error Reporting ===m===

session_start();
require_once dirname(__DIR__, 2) . '/app/Core/db.php';
if (!isset($_SESSION["user_logged"]) || $_SESSION["user_logged"] != "Y") {
    header("Location: ../login.php");
    exit;
}

// Platform pages live inside the PerformIQ shell (../dashboard.php). Opened directly,
// send the user to the shell on this platform's section. ?standalone=1 skips that.
$pqEmbed = isset($_GET['embed']) && $_GET['embed'] === '1';
if (!$pqEmbed && !isset($_GET['standalone'])) {
    header('Location: ../dashboard.php#google');
    exit;
}
$title = DASHBOARD_TITLE;
?>
<!DOCTYPE html>
<html lang="en" class="<?= $pqEmbed ? 'pq-embed' : '' ?>">

<head>
<?= function_exists('pqMetricGuardTag') ? pqMetricGuardTag('../') : '' ?>
<?= function_exists('pqDatesTag') ? pqDatesTag('../') : '' ?>
<?= function_exists('pqPageControlsTag') ? pqPageControlsTag() : '' ?>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>
        <?= htmlspecialchars($title) ?> | Webzaa
    </title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Sora:wght@300;400;500;600;700&family=JetBrains+Mono:wght@300;400;500;600&display=swap"
        rel="stylesheet">

    <link rel="icon" type="image/png" href="../assets/img/favicon.png">
    <meta name="theme-color" content="#3B82F6">
    <script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>
    <!-- Chart.js: used by the daily / weekly / monthly reports and monthly deck -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.7/dist/chart.umd.min.js"></script>
    <script src="https://unpkg.com/xlsx-js-style@1.2.0/dist/xlsx.bundle.js"></script>
    <script src="https://unpkg.com/papaparse@5.4.1/papaparse.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <script>
        // Theme (shared with the PerformIQ shell via localStorage) — applied before paint
        (function () {
            var t = 'dark';
            try { t = localStorage.getItem('performiq-theme') || 'dark'; } catch (e) {}
            document.documentElement.setAttribute('data-theme', t === 'light' ? 'light' : 'dark');
        })();
    </script>
    <style>
        :root, :root[data-theme="dark"] {
            --pq-bg: #0B0F1A; --pq-surface: #111827; --pq-card: #161D2E; --pq-border: #1E2A42;
            --pq-text: #E2E8F0; --pq-text-dim: #94A3B8; --pq-muted: #4B5563; --pq-line: #334155;
            --pq-surface-2: #1F2937;
            color-scheme: dark;
        }
        :root[data-theme="light"] {
            --pq-bg: #F4F6FA; --pq-surface: #FFFFFF; --pq-card: #F8FAFC; --pq-border: #E2E8F0;
            --pq-text: #0F172A; --pq-text-dim: #475569; --pq-muted: #94A3B8; --pq-line: #CBD5E1;
            --pq-surface-2: #F1F5F9;
            color-scheme: light;
        }
        :root[data-theme="light"] .loader-text { color: #0F172A; }
        :root[data-theme="light"] .loader-dashboard { background: rgba(244, 246, 250, 0.7); }
        #theme-toggle { display: flex; align-items: center; gap: 6px; font-size: 12px; }

        /* ===== Embedded inside the PerformIQ shell (dashboard.php) ===== */
        .pq-embed .pq-brand,
        .pq-embed .pq-platform-switch,
        .pq-embed #theme-toggle,
        .pq-embed .pq-footer,
        .pq-embed .pq-refreshed,
        .pq-embed #refresh-btn,
        .pq-embed header span:has(> .live-dot) { display: none !important; }   /* shell top bar has Refresh */
        .pq-embed header { position: static !important; }
        .pq-embed header { padding: 0 24px !important; }
        .pq-embed header > div { height: 52px !important; justify-content: flex-end !important; max-width: none !important; }
        .pq-embed nav { padding: 0 24px !important; }
        .pq-embed nav > div, .pq-embed main { max-width: none !important; }
        .pq-embed main { padding: 20px 24px !important; }
        .pq-embed main { padding-top: 20px !important; }
    </style>

    <style>
        body {
            background-color: var(--pq-bg);
            margin: 0;
            padding: 0;
            color: var(--pq-text);
            font-family: 'Sora', sans-serif;
        }

        ::-webkit-scrollbar {
            width: 6px;
            height: 6px;
        }

        ::-webkit-scrollbar-track {
            background: var(--pq-surface);
        }

        ::-webkit-scrollbar-thumb {
            background: var(--pq-border);
            border-radius: 3px;
        }

        ::-webkit-scrollbar-thumb:hover {
            background: var(--pq-muted);
        }

        .mono {
            font-family: "JetBrains Mono", monospace;
        }

        .tab-btn {
            background: none;
            border: none;
            cursor: pointer;
            outline: none;
        }

        .tab-btn:hover {
            opacity: 0.85;
        }

        table {
            border-collapse: collapse;
            width: 100%;
        }

        th {
            color: var(--pq-text-dim);
            font-size: 11px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.07em;
            padding: 10px 14px;
            border-bottom: 1px solid var(--pq-border);
            text-align: left;
            white-space: nowrap;
        }

        td {
            color: var(--pq-text);
            font-size: 12.5px;
            padding: 10px 14px;
            border-bottom: 1px solid #1E2A4244;
            vertical-align: middle;
        }

        tr:hover td {
            background: #E8A82018;
        }

        .btn {
            background: #E8A820;
            color: var(--pq-bg);
            border: none;
            border-radius: 8px;
            padding: 10px 20px;
            font-family: "Sora";
            font-size: 13px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s;
            letter-spacing: 0.02em;
        }

        .btn:hover {
            opacity: 0.88;
            transform: translateY(-1px);
        }

        .btn:disabled {
            background: var(--pq-muted);
            color: var(--pq-text);
            cursor: not-allowed;
            opacity: 0.6;
        }

        .btn-ghost {
            background: var(--pq-card);
            color: var(--pq-text);
            border: 1px solid var(--pq-border);
        }

        .btn-ghost:hover {
            border-color: #E8A820;
            color: #E8A820;
            background: #E8A82018;
        }

        select {
            background: var(--pq-card);
            color: var(--pq-text);
            border: 1px solid var(--pq-border);
            border-radius: 8px;
            padding: 8px 12px;
            font-family: "Sora";
            font-size: 12px;
            outline: none;
            cursor: pointer;
        }

        select:focus {
            border-color: #E8A820;
        }

        input {
            background: var(--pq-card);
            color: var(--pq-text);
            border: 1px solid var(--pq-border);
            border-radius: 8px;
            padding: 8px 12px;
            font-family: "Sora";
            font-size: 12px;
            outline: none;
            width: 100%;
            box-sizing: border-box;
        }

        input:focus {
            border-color: #E8A820;
        }

        @keyframes pulse {

            0%,
            100% {
                opacity: 1
            }

            50% {
                opacity: 0.5
            }
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(8px)
            }

            to {
                opacity: 1;
                transform: translateY(0)
            }
        }

        @keyframes shimmer {
            0% {
                background-position: 200% 0
            }

            100% {
                background-position: -200% 0
            }
        }

        .animate-in {
            animation: fadeIn 0.35s ease forwards;
        }

        .pulse {
            animation: pulse 1.5s ease infinite;
        }

        .live-dot {
            display: inline-block;
            width: 6px;
            height: 6px;
            border-radius: 50%;
            background: #10B981;
            margin-right: 6px;
            animation: pulse 1.5s ease-in-out infinite;
        }

        .loader-dashboard {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(3, 7, 18, 0.65);
            backdrop-filter: blur(3px);
            display: none;
            justify-content: center;
            align-items: center;
            flex-direction: column;
            z-index: 99999;
        }

        .loader-spinner {
            width: 60px;
            height: 60px;
            border: 4px solid rgba(255, 255, 255, 0.15);
            border-top: 4px solid #fbbf24;
            border-radius: 50%;
            animation: spin 1s linear infinite;
            position: absolute;
            left: 45%;
            top: 45%;
        }

        .loader-text {
            margin-top: 15px;
            color: #fff;
            font-size: 14px;
            font-weight: 600;
            position: absolute;
            left: 40%;
            top: 56%;
        }

        @keyframes spin {
            0% {
                transform: rotate(0deg);
            }

            100% {
                transform: rotate(360deg);
            }
        }
    </style>

    <!-- Builds the "Export PDF (Meta + Google + Taboola)" report as a downloadable PDF client-side. -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>
    <script src="js/project_sync.js?v=5"></script>
    <?= function_exists('pqViewTag') ? pqViewTag('../') : '' ?>
    <script>
        // All / Performance / Awareness tabs (campaigns tagged in ⟳ Sync): reloads the dashboard with only those campaigns
        document.addEventListener('DOMContentLoaded', () => {
            window.PQAwareUI = window.PQView ? PQView.mount(document.getElementById('pq-aware-host'), { onChange: () => {
                // reload the numbers only (no session check → login redirect if a chart library hiccups)
                if (typeof window.fetchDashboardData === 'function') Promise.resolve(window.fetchDashboardData()).catch(e => console.error('[tabs]', e));
                else if (typeof handleRefresh === 'function') handleRefresh();
            } }) : null;
        });
    </script>
    <?php require_once dirname(__DIR__, 2) . '/app/Ads/platform_metrics.php'; ?>
    <script>window.PQ_PM_LABELS = Object.assign(window.PQ_PM_LABELS || {}, <?= json_encode(pmLabels('google'), JSON_UNESCAPED_UNICODE) ?>);</script>
    <script src="js/column_picker.js?v=3"></script>
<?php if (function_exists('pqCan') && !pqCan('google', 'sync')) { ?><style>button[onclick^="ProjectSync.open"]{display:none!important}</style><?php } ?>
<style>
    /* phone / small tablet: side-by-side panels stack (charts, insight cards, comparison panels) */
    @media (max-width: 760px) {
        [style*="grid-template-columns: repeat(3, 1fr)"], [style*="grid-template-columns:repeat(3, 1fr)"], [style*="grid-template-columns:repeat(3,1fr)"],
        [style*="grid-template-columns: 1fr 1fr"], [style*="grid-template-columns:1fr 1fr"],
        [style*="grid-template-columns: 1.2fr 0.8fr"], [style*="grid-template-columns:1.2fr 0.8fr"] { grid-template-columns: 1fr !important; }
        [style*="minmax(300px"] { grid-template-columns: 1fr !important; }
        main[style*="padding:28px"], main[style*="padding: 28px"] { padding: 14px !important; }
        table { max-width: none; }
    }
</style>
</head>

<body>
    <div id="loader-dashboard" class="loader-dashboard">
        <div class="loader-spinner"></div>
        <div class="loader-text">Loading dashboard data...</div>
    </div>

    <div id="app" style="min-height:100vh; background:var(--pq-bg);">

        <!-- HEADER -->
        <header
            style="background:var(--pq-surface); border-bottom:1px solid var(--pq-border); padding:0 28px; position:sticky; top:0; z-index:100;">
            <div
                style="display:flex; align-items:center; justify-content:space-between; height:60px; max-width:1600px; margin:0 auto;">
                <div class="pq-brand" style="display:flex; align-items:center; gap:14px;">
                    <div
                        style="width:32px; height:32px; border-radius:8px; background:#4285F4; display:flex; align-items:center; justify-content:center; font-size:16px; font-weight:700; color:#fff; font-family:'Sora';">
                        G</div>
                    <div>
                        <div
                            style="color:var(--pq-text); font-family:'Sora'; font-weight:700; font-size:15px; letter-spacing:-0.02em;">
                            PerformIQ</div>
                        <div
                            style="color:var(--pq-text-dim); font-size:10px; font-family:'Sora'; letter-spacing:0.05em; text-transform:uppercase;">
                            Google Ads Real Estate Dashboard</div>
                    </div>
                </div>

                <div style="display:flex; align-items:center; gap:12px;">
                    <!-- Platform switcher: Meta | Google (active) -->
                    <div class="pq-platform-switch" style="display:flex; align-items:center; gap:8px;">
                        <span
                            style="color:var(--pq-text-dim); font-size:11px; font-weight:600; text-transform:uppercase; letter-spacing:0.05em; white-space:nowrap;">Platform:</span>
                        <div
                            style="display:flex; gap:4px; align-items:center; background:var(--pq-bg); border:1px solid var(--pq-border); border-radius:8px; padding:3px;">
                            <button onclick="window.location.href='../dashboard.php#meta'" style="display:inline-flex; align-items:center; gap:5px;
                                       background:transparent; color:var(--pq-text-dim);
                                       border:1px solid transparent; border-radius:6px;
                                       padding:5px 12px; font-size:11px; font-weight:500;
                                       font-family:'Sora',sans-serif; letter-spacing:0.04em;
                                       text-transform:uppercase; cursor:pointer; white-space:nowrap;
                                       transition:all 0.15s;"
                                onmouseover="this.style.color='#1877F2'; this.style.borderColor='#1877F244';"
                                onmouseout="this.style.color='var(--pq-text-dim)'; this.style.borderColor='transparent';">
                                <svg xmlns="http://www.w3.org/2000/svg" width="13" height="13" viewBox="0 0 24 24">
                                    <circle cx="12" cy="12" r="12" fill="#1877F2" />
                                    <path
                                        d="M15.5 8H13C12.45 8 12 8.45 12 9v2h3.5l-.5 2.5H12V20H9.5v-6.5H7.5V11h2V9c0-2.21 1.79-4 4-4h2v3z"
                                        fill="white" />
                                </svg>
                                Meta
                            </button>
                            <button onclick="window.location.href='../dashboard.php#google'" style="display:inline-flex; align-items:center; gap:5px;
                                       background:#4285F418; color:#4285F4;
                                       border:1px solid #4285F444; border-radius:6px;
                                       padding:5px 12px; font-size:11px; font-weight:700;
                                       font-family:'Sora',sans-serif; letter-spacing:0.04em;
                                       text-transform:uppercase; cursor:pointer; white-space:nowrap;">
                                <svg xmlns="http://www.w3.org/2000/svg" width="13" height="13" viewBox="0 0 24 24">
                                    <path
                                        d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                                        fill="#4285F4" />
                                    <path
                                        d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                                        fill="#34A853" />
                                    <path
                                        d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
                                        fill="#FBBC05" />
                                    <path
                                        d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
                                        fill="#EA4335" />
                                </svg>
                                Google
                            </button>
                            <?php if (defined('SHOW_TABOOLA') && SHOW_TABOOLA) { ?><button onclick="window.location.href='../dashboard.php#taboola'" style="display:inline-flex; align-items:center; gap:5px;
                                       background:transparent; color:var(--pq-text-dim);
                                       border:1px solid transparent; border-radius:6px;
                                       padding:5px 12px; font-size:11px; font-weight:500;
                                       font-family:'Sora',sans-serif; letter-spacing:0.04em;
                                       text-transform:uppercase; cursor:pointer; white-space:nowrap;
                                       transition:all 0.15s;"
                                onmouseover="this.style.color='#3B82F6'; this.style.borderColor='#3B82F644';"
                                onmouseout="this.style.color='var(--pq-text-dim)'; this.style.borderColor='transparent';">
                                Taboola
                            </button><?php } ?>
                        </div>
                    </div>
                    <span
                        style="color:#10B981; background:#10B98118; border:1px solid #10B98144; padding:4px 10px; border-radius:99px; font-size:10px; font-weight:600; display:flex; align-items:center;">
                        <span class="live-dot"></span>LIVE DATA
                    </span>
                    <span class="pq-refreshed" style="color:var(--pq-text); font-size:11px;">
                        Refreshed:
                        <?= htmlspecialchars(date('d M Y, h:i A')) ?>
                    </span>
                    <button class="btn btn-ghost" onclick="handleRefresh()"
                        style="display:flex; align-items:center; gap:6px; font-size:12px;" id="refresh-btn">
                        <span id="refresh-icon">↻</span>
                        <span id="refresh-btn-text">Refresh</span>
                    </button>

                    <div
                        style="display:flex; align-items:center; gap:0; background:var(--pq-card); border:1px solid var(--pq-border); border-radius:8px; overflow:hidden;">
                        <div
                            style="padding:8px 12px; background:#10B98118; color:#10B981; font-size:11px; font-weight:600; border-right:1px solid var(--pq-border); white-space:nowrap;">
                            Last Lead: <span id="header-last-qual-date">Loading...</span>
                        </div>
                        <!-- Upload Offline Data: hidden — use "Upload Lead Status" (dashboard.php#status) -->
                        <button class="btn-ghost" onclick="UploadManager.openModal()" hidden aria-hidden="true"
                            style="display:none; align-items:center; gap:6px; font-size:12px; border:none; padding:8px 12px; cursor:pointer; color:var(--pq-text); background:transparent;">
                            <span>⬆</span>
                            <span id="upload-status-text">Upload Offline Data</span>
                        </button>
                    </div>

                    <!-- <button class="btn" onclick="handleGenerateInsights(event)"
                        style="display:flex; align-items:center; gap:6px; font-size:12px;">
                        <span>🤖</span>
                        <span id="ai-insights-btn-text">Generate AI Insights</span>
                    </button> -->
                </div>
            </div>
        </header>

        <!-- NAV TABS -->
        <nav style="background:var(--pq-surface); border-bottom:1px solid var(--pq-border); padding:0 28px;">
            <div id="tabs-container" style="display:flex; gap:4px; max-width:1600px; margin:0 auto; overflow-x:auto;">
                <!-- Inject dynamic tab buttons here -->
            </div>
        </nav>

        <!-- MAIN CONTENT -->
        <main style="max-width:1600px; margin:0 auto; padding:28px;" class="animate-in">

            <div id="error-banner"
                style="display:none; background:#EF444418; border:1px solid #EF444444; color:#EF4444; border-radius:12px; padding:12px 18px; margin-bottom:24px; font-size:13px;">
                ⚠️ <strong>Error:</strong> <span id="error-message"></span>
            </div>

            <!-- GLOBAL FILTERS ROW -->
            <div id="filters-container"
                style="display:flex; flex-wrap:wrap; gap:20px; align-items:center; background:var(--pq-surface); border:1px solid var(--pq-border); border-radius:12px; padding:16px 20px; margin-bottom:24px; position:relative;">
                <div style="display:flex; flex-direction:column; gap:6px; position:relative;">
                    <span
                        style="color:var(--pq-text-dim); font-size:11px; font-weight:600; text-transform:uppercase; letter-spacing:0.05em;">Date:</span>
                    <div onclick="toggleDatePicker(event)"
                        style="background:var(--pq-card); color:var(--pq-text); border:1px solid var(--pq-border); border-radius:8px; padding:8px 12px; font-size:12.5px; cursor:pointer; display:flex; align-items:center; justify-content:space-between; min-width:220px; user-select:none;">
                        <span id="date-range-display">📅 Loading…</span>
                        <span style="font-size:10px; opacity:0.6;">▼</span>
                    </div>
                    <div id="date-picker-popup"
                        style="display:none; position:absolute; top:100%; left:0; margin-top:8px; background:var(--pq-surface); border:1px solid var(--pq-border); border-radius:12px; box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.5), 0 8px 10px -6px rgba(0, 0, 0, 0.5); flex-direction:column; z-index:1000; padding:16px; width:700px;">
                    </div>
                </div>
                <!-- Status Filter Tabs (pill buttons) -->
                <div style="display:flex; flex-direction:column; gap:8px;">
                    <span
                        style="color:var(--pq-text-dim); font-size:11px; font-weight:600; text-transform:uppercase; letter-spacing:0.05em;">Status:</span>
                    <div id="status-tab-group"
                        style="display:flex; gap:4px; align-items:center; background:var(--pq-surface); border:1px solid var(--pq-border); border-radius:8px; padding:3px;">
                        <button id="status-tab-all" onclick="handleStatusFilterChange('all')" style="background:var(--pq-card); color:var(--pq-text); border:1px solid var(--pq-border);
                                   border-radius:6px; padding:6px 14px; font-size:11.5px; font-weight:700;
                                   font-family:'Sora',sans-serif; cursor:pointer; transition:all 0.15s;
                                   outline:none; white-space:nowrap;">
                            All
                        </button>
                        <button id="status-tab-active" onclick="handleStatusFilterChange('active')" style="background:transparent; color:var(--pq-text-dim); border:1px solid transparent;
                                   border-radius:6px; padding:6px 14px; font-size:11.5px; font-weight:400;
                                   font-family:'Sora',sans-serif; cursor:pointer; transition:all 0.15s;
                                   outline:none; white-space:nowrap;">
                            🟢 Active
                        </button>
                        <button id="status-tab-inactive" onclick="handleStatusFilterChange('inactive')" style="background:transparent; color:var(--pq-text-dim); border:1px solid transparent;
                                   border-radius:6px; padding:6px 14px; font-size:11.5px; font-weight:400;
                                   font-family:'Sora',sans-serif; cursor:pointer; transition:all 0.15s;
                                   outline:none; white-space:nowrap;">
                            🔴 Inactive
                        </button>
                    </div>
                </div>
                <!-- <div style="display:flex; flex-direction:column; gap:6px;">
        <span
                        style="color:var(--pq-text-dim); font-size:11px; font-weight:600; text-transform:uppercase; letter-spacing:0.05em;">Campaign
                        Source:</span>
                    <select id="filter-platform" onchange="handleFilterPlatformChange(this)" style="min-width:160px;">
                        <option value="All">All</option>
                    </select>
                </div>-->

                <div style="display:flex; flex-direction:column; gap:6px; flex-grow:1; min-width:200px;">
                    <span
                        style="color:var(--pq-text-dim); font-size:11px; font-weight:600; text-transform:uppercase; letter-spacing:0.05em;">Search:</span>
                    <div style="position:relative;">
                        <input id="search-query" type="text" placeholder="Search by campaign name..."
                            oninput="handleSearchInput(this)" />
                        <button id="search-clear-btn" onclick="clearSearchInput()"
                            style="display:none; position:absolute; right:10px; top:50%; transform:translateY(-50%); background:none; border:none; color:var(--pq-text-dim); cursor:pointer; font-size:14px;">✕</button>
                    </div>
                </div>
            </div>


            <!-- Project campaign filter: only campaigns saved for this project (campaigns table) -->
            <div id="campaign-filter-banner" style="display:none; margin-bottom:20px;"></div>
            <div id="pq-aware-host" style="margin:0 0 14px;"></div>

            <div id="tab-content-container">
            </div>
        </main>

        <!-- FOOTER -->
        <footer class="pq-footer" style="border-top:1px solid var(--pq-border); padding:16px 28px; margin-top:40px; background:var(--pq-surface);">
            <div
                style="max-width:1600px; margin:0 auto; display:flex; justify-content:space-between; align-items:center;">
                <span id="footer-text-left" style="color:var(--pq-muted); font-size:11px;">
                    Webzaa · Loading…
                </span>
                <span style="color:var(--pq-muted); font-size:11px;">
                    Live Google Ads API Integration · Powered by PHP & Pure JS
                </span>
            </div>
        </footer>
    </div>
    <script>
        window.handleStatusFilterChange = (status) => {
            state.filterStatus = status;

            // Update pill button styles
            ['all', 'active', 'inactive'].forEach(s => {
                const btn = document.getElementById(`status-tab-${s}`);
                if (!btn) return;
                const isActive = s === status;
                btn.style.background = isActive ? 'var(--pq-card)' : 'transparent';
                btn.style.color = isActive ? 'var(--pq-text)' : 'var(--pq-text-dim)';
                btn.style.border = isActive ? '1px solid var(--pq-border)' : '1px solid transparent';
                btn.style.fontWeight = isActive ? '700' : '400';
            });

            fetchDashboardData();
        };
    </script>
    <script>
        // ===m=== Load unmapped count on dashboard ===m===
        window.unmappedLeadsCount = "...";

        async function loadUnmappedCount() {
            if (window.PQ_CAN && !window.PQ_CAN.unmapped) return;   // role without Unmapped Leads
            try {
                // Fetch from 'master' which contains the exact Total All-Time count
                const res = await fetch('../unmapped_leads_api.php?action=counts');
                const data = await res.json();

                // Google leads not under a saved campaign (all time) — Meta leads are no longer counted here
                const count = data.counts ? data.counts.google : 0;

                window.unmappedLeadsCount = count;

                // Update the badge on the buttons
                const badges = document.querySelectorAll('#unmappedBadge');
                badges.forEach(badge => {
                    badge.textContent = count;
                });
            } catch (err) {
                console.error("Failed to fetch unmapped leads:", err);
            }
        }

        function openUnmapped() { (function(tab) {
            // Meta + Google unmapped leads live in one section of the main dashboard (unmapped_leads.php)
            try { localStorage.setItem('pq-unmapped-tab', tab); } catch (e) {}
            try {
                if (window.top !== window && window.top.location.pathname.endsWith('/dashboard.php')) { window.top.location.hash = '#unmapped'; return; }
            } catch (e) {}
            window.open('../dashboard.php#unmapped', '_blank');
        })('google'); }

        document.addEventListener('DOMContentLoaded', () => {
            loadUnmappedCount();
        });
    </script>
    <script>
        // ── Loader helpers ──
        function showLoader() {
            const loader = document.getElementById('loader-dashboard');
            if (loader) loader.style.display = 'flex';
        }

        function hideLoader() {
            const loader = document.getElementById('loader-dashboard');
            if (loader) loader.style.display = 'none';
        }

        window.handleRefresh = async () => {
            const btn = document.getElementById('refresh-btn');
            const icon = document.getElementById('refresh-icon');
            const text = document.getElementById('refresh-btn-text');

            if (btn) btn.disabled = true;
            if (text) text.innerText = 'Refreshing…';
            if (icon) {
                icon.style.display = 'inline-block';
                icon.style.animation = 'spin 1s linear infinite';
            }
            await fetchDashboardData();
            if (btn) btn.disabled = false;
            if (text) text.innerText = 'Refresh';
            if (icon) icon.style.animation = 'none';
        };

        // ── Design tokens ──
        // ── Theme-aware palette: values follow <html data-theme="dark|light"> ──
        // Charts read these as real hex (SVG/canvas can't use CSS vars), so the
        // dashboard re-renders when the theme is toggled.
        const THEME_PALETTES = {
            dark: {
                mode: "dark", bg: "#0B0F1A", surface: "#111827", card: "#161D2E", border: "#1E2A42",
                accent: "#E8A820", muted: "#4B5563", text: "#E2E8F0", textDim: "#94A3B8", textFaint: "#4B5563",
            },
            light: {
                mode: "light", bg: "#F4F6FA", surface: "#FFFFFF", card: "#F8FAFC", border: "#E2E8F0",
                accent: "#B7791F", muted: "#94A3B8", text: "#0F172A", textDim: "#475569", textFaint: "#94A3B8",
            },
        };
        const getTheme = () => document.documentElement.getAttribute('data-theme') === 'light' ? 'light' : 'dark';
        const C = {
            accentLo: "#E8A82018",
            blue: "#3B82F6",
            blueLo: "#3B82F618",
            green: "#10B981",
            greenLo: "#10B98118",
            red: "#EF4444",
            redLo: "#EF444418",
            yellow: "#F59E0B",
        };
        Object.keys(THEME_PALETTES.dark).forEach(k => {
            Object.defineProperty(C, k, {enumerable: true, get: () => THEME_PALETTES[getTheme()][k]});
        });

        // ── Dark / Light theme (driven by the PerformIQ shell) ─────────────────────────
        function updateThemeToggleLabel() {
            const isLight = getTheme() === 'light';
            const icon = document.getElementById('theme-toggle-icon');
            const text = document.getElementById('theme-toggle-text');
            if (icon) icon.textContent = isLight ? '🌙' : '☀️';
            if (text) text.textContent = isLight ? 'Dark' : 'Light';
        }
        window.setTheme = (theme, persist = true) => {
            theme = theme === 'light' ? 'light' : 'dark';
            if (getTheme() === theme && !persist) return;
            document.documentElement.setAttribute('data-theme', theme);
            if (persist) { try { localStorage.setItem('performiq-theme', theme); } catch (e) {} }
            updateThemeToggleLabel();
            try { renderDashboard(); } catch (e) { console.warn('re-render after theme change failed', e); }
        };
        window.toggleTheme = () => setTheme(getTheme() === 'light' ? 'dark' : 'light');
        // Shell (or another tab) changed the theme
        window.addEventListener('storage', (e) => {
            if (e.key === 'performiq-theme') setTheme(e.newValue, false);
        });
        document.addEventListener('DOMContentLoaded', updateThemeToggleLabel);
        const PLATFORM_COLORS = {
            Meta: "#1877F2",
            Google: "#4285F4",
            LinkedIn: "#0A66C2",
            DV360: "#34A853",
            Taboola: "#FF6B35",
            Website: "#10B981",
            Other: "#8B5CF6"
        };
        const PIE_COLORS = ["#E8A820", "#3B82F6", "#10B981", "#EF4444", "#8B5CF6", "#F59E0B", "#06B6D4"];

        // ── Global App State ──
        const state = {
            activeTab: 'executive',
            isLoading: true,
            ajaxError: null,
            rawData: null,
            campaigns: [],
            filteredCampaigns: [],
            trends: [],
            funnel: [],
            sources: [],
            creatives: [],
            keywords: [],
            projectName: 'Loading…',
            dateRange: 'Loading…',
            insights: null,
            loadingInsights: false,
            uploadStatus: null,
            filterPlatform: 'All',
            filterSubsource: 'All',
            searchQuery: '',
            isDatePickerOpen: false,
            tempPreset: 'last_30d',
            tempStartDate: null,
            tempEndDate: null,
            hoverDate: null,
            calendarMonth: new Date(),
            dtPage: 1,
            dtPageSize: 5,
            dtSortCol: '',
            dtSortDir: 1,
            dtSearch: '',

            // Drill-down state (campaign → adset → ad)
            campaignsViewLevel: 'campaign', // 'campaign', 'adset', or 'ad'
            selectedCampaignId: null,
            selectedCampaignName: '',
            selectedAdsetId: null,
            selectedAdsetName: '',
            adsets: [],
            ads: [],
            isLoadingAdsets: false,
            isLoadingAds: false,
            statusFilter: 'all',
        };
        /*const state = {
                activeTab: 'executive', isLoading: true, ajaxError: null, rawData: null,
                campaigns: [], filteredCampaigns: [], trends: [], funnel: [], sources: [], creatives: [], keywords: [],
                projectName: 'Loading…', dateRange: 'Loading…', insights: null, loadingInsights: false, uploadStatus: null,
                filterPlatform: 'All', filterSubsource: 'All', searchQuery: '',
                isDatePickerOpen: false, tempPreset: 'last_30d', tempStartDate: null, tempEndDate: null, hoverDate: null, calendarMonth: new Date(),
        };*/

        const TABS = [{
            id: "executive",
            label: "Executive Summary",
            icon: "📊 "
        },
        {
            id: "campaigns",
            label: "Campaigns",
            icon: "🎯 "
        },
        {
            id: "funnel",
            label: "Funnel Analysis",
            icon: "🔻 "
        },
        {
            id: "insights",
            label: "AI Insights",
            icon: "✨ "
        },
        ];

        // ── Formatting Helpers ──
        const fmt = (n, prefix = "₹") => (!n && n !== 0) ? `${prefix}0` : `${prefix}${Math.round(n).toLocaleString("en-IN")}`;
        const fmtD = (n, prefix = "₹") => (!n && n !== 0) ? `${prefix}0.00` : `${prefix}${n.toLocaleString("en-IN", {minimumFractionDigits: 2, maximumFractionDigits: 2})}`;
        const fmtN = n => (!n && n !== 0) ? "0" : Math.round(n).toLocaleString("en-IN");
        const pct = n => `${(n || 0).toFixed(1)}%`;
        const fmtSpend = n => fmtD(n);
        const fmtImpressions = n => fmtN(n);
        const fmtCTR = n => `${(n || 0).toFixed(2)}%`;
        const fmtCPM = n => fmtD(n);
        const fmtCPL = n => fmtD(n);
        const statusColor = s => s === "good" ? C.green : s === "warn" ? C.yellow : C.red;
        const statusLabel = s => s === "good" ? "▲ Strong" : s === "warn" ? "◆ Review" : "▼ Poor";

        // ===m=== Dedupe helper: a lead can legitimately match more than one
        // campaign (utm_campaignname can hold comma-separated values), so any
        // ===m=== Check and exclude test / junk leads ===m===
        function isTestLead(l) {
            if (!l) return false;
            const st = String(l.lead_status || '').toUpperCase().trim();
            if (st === 'TEST' || st === 'JUNK') return true;
            const name = String(l.name || '').toLowerCase();
            if (name.includes('test')) return true;
            const email = String(l.email || '').toLowerCase();
            if (email.includes('test')) return true;
            const mob = String(l.mobile || '').trim();
            if (mob.toLowerCase().includes('test')) return true;
            if (['9999999999', '8888888888', '0000000000', '1234567890', '1111111111'].includes(mob)) return true;
            return false;
        }

        // TOTAL across campaigns must count each unique lead once — not once
        // per campaign it matched. Used everywhere a cross-campaign total is shown,
        // so the table TOTAL row, KPI cards, export, and popup always agree. ===m===
        function getUniqueLeads(campaignsArr, type) {
            const seen = new Set();
            const unique = [];
            campaignsArr.forEach(c => {
                (c[type] || []).forEach(l => {
                    if (isTestLead(l)) return;
                    const mob = String(l.mkey || l.mobile || '').trim();   // mkey: the same person even when the mobile is masked
                    const gcl = String(l.gclid || '').trim();
                    const lid = String(l.id || '').trim();
                    const key = mob ? mob : (lid ? ('id_' + lid) : (gcl ? ('gclid_' + gcl) : ('rnd_' + Math.random())));
                    if (!seen.has(key)) {
                        seen.add(key);
                        unique.push(l);
                    }
                });
            });
            return unique;
        }

        // ── Mapping Data (Google adaptation) ──
        const mapPhpDataToDashboard = (phpData) => {
            const phpCamps = phpData.campaigns || [];
            const phpTrends = phpData.trend || [];

            const mappedCampaigns = phpCamps.map((c) => {
                const name = c.name || "Unknown Campaign";
                const platform = c.platform || "Google";

                const spend = Number(c.spend || 0);
                const impressions = Number(c.impressions || 0);
                const clicks = Number(c.clicks || 0);

                const cleanLeadsData = (c.leads_data || []).filter(l => !isTestLead(l));
                const cleanQualLeads = (c.qualified_leads || []).filter(l => !isTestLead(l));
                const cleanWalkLeads = (c.walkin_leads || []).filter(l => !isTestLead(l));

                const leads = cleanLeadsData.length > 0 ? cleanLeadsData.length : Number(c.leads || 0);
                const qualified = cleanQualLeads.length > 0 ? cleanQualLeads.length : Number(c.qualified || 0);
                const walkins = cleanWalkLeads.length > 0 ? cleanWalkLeads.length : Number(c.walkins || 0);

                const cpl = Number(c.cpl || 0);
                const cpql = Number(c.cpql || 0);
                const cpsv = Number(c.cpsv || 0);

                const cpc = clicks > 0 ? Number((spend / clicks).toFixed(2)) : 0;
                const ctr = Number(c.ctr || 0);
                const cpm = Number(c.cpm || 0);

                let status = "warn";
                if (leads > 0 && cpl < 500) status = "good";
                else if (cpl > 1200 || (spend > 10000 && leads === 0)) status = "bad";

                return {
                    campaign: name,
                    campaignStatus: c.campStatus || "",
                    platform,
                    spend,
                    impressions,
                    clicks,
                    leads,
                    qualified,
                    walkins,
                    bookings: 0,
                    cpl,
                    cpql,
                    cpsv,
                    cpc,
                    ctr,
                    cpm,
                    status,
                    pm: c.pm || {},          // extra metrics from Google (▥ Columns)
                    reach: Number(c.reach || 0),
                    views: Number((c.pm || {}).pm_video_views || 0),
                    non_qualified: Number(c.non_qualified || 0),
                    to_be_qualified: Number(c.to_be_qualified || 0),
                    lost_post_qualified: Number(c.lost_post_qualified || 0),
                    qualified_leads: cleanQualLeads,
                    walkin_leads: cleanWalkLeads,
                    leads_data: cleanLeadsData
                };
            });

            const sumImpr = mappedCampaigns.reduce((a, c) => a + c.impressions, 0);
            const sumClicks = mappedCampaigns.reduce((a, c) => a + c.clicks, 0);
            // const sumLeads = mappedCampaigns.reduce((a, c) => a + c.leads, 0);
            const sumLeads = getUniqueLeads(mappedCampaigns, 'leads_data').length;
            const sumQual = getUniqueLeads(mappedCampaigns, 'qualified_leads').length;
            const sumWalk = getUniqueLeads(mappedCampaigns, 'walkin_leads').length;

            const finalFunnel = [{
                stage: "Impressions",
                value: sumImpr,
                pct: 100
            },
            {
                stage: "Clicks",
                value: sumClicks,
                pct: sumImpr > 0 ? Number((sumClicks / sumImpr * 100).toFixed(2)) : 0
            },
            {
                stage: "Leads",
                value: sumLeads,
                pct: sumClicks > 0 ? Number((sumLeads / sumClicks * 100).toFixed(2)) : 0
            },
            {
                stage: "Qualified Leads",
                value: sumQual,
                pct: sumLeads > 0 ? Number((sumQual / sumLeads * 100).toFixed(2)) : 0
            },
            {
                stage: "Walk-ins",
                value: sumWalk,
                pct: sumQual > 0 ? Number((sumWalk / sumQual * 100).toFixed(2)) : 0
            },
            {
                stage: "Bookings",
                value: 0,
                pct: 0
            },
            ].filter(f => !(window.pqMetricHidden && pqMetricHidden(f.stage)));

            return {
                campaigns: mappedCampaigns,
                trends: phpTrends,
                funnel: finalFunnel,
                sources: [{
                    source: "Google Ads",
                    leads: sumLeads,
                    walkins: 0,
                    quality: 75,
                    cpl: sumLeads > 0 ? (mappedCampaigns.reduce((a, c) => a + c.spend, 0) / sumLeads) : 0
                }],
                creatives: [],
                keywords: [],
                projectName: "",
                dateRange: phpData.date_preset || "last 30 days"
            };
        };

        // ── UI Components Generators ──
        const renderInsightCardHTML = (icon, label, items = [], color = C.accent) => {
            const listHTML = items.map(item => `<div style="display:flex; gap:8px; align-items:flex-start;"><span style="color:${color}; font-size:10px; margin-top:5px; flex-shrink:0;">◆</span><span style="color:${C.text}; font-size:12.5px; line-height:1.6;">${item}</span></div>`).join('');
            return `<div style="background:${C.card}; border:1px solid ${C.border}; border-radius:12px; padding:16px 18px; display:flex; flex-direction:column; gap:8px;"><div style="display:flex; align-items:center; gap:8px; margin-bottom:4px;"><span style="font-size:16px;">${icon}</span><span style="color:${color}; font-family:'Sora'; font-weight:600; font-size:12px; text-transform:uppercase; letter-spacing:0.08em;">${label}</span></div>${items.length === 0 ? `<span style="color:${C.textFaint}; font-size:12px;">No insights available.</span>` : listHTML}</div>`;
        };

        const renderKpiCardHTML = (label, value, sub, delta, status) => {
            if (window.pqMetricHidden && pqMetricHidden(label)) return '';   // Roles → "Hide numbers"
            const borderVal = status ? `${statusColor(status)}44` : C.border;
            const topBar = status ? `<div style="position:absolute; top:0; left:0; right:0; height:2px; background:${statusColor(status)};"></div>` : '';
            const statusTag = status ? `<div style="position:absolute; top:16px; right:16px; display:flex; align-items:center; gap:4px; font-size:10px; color:${statusColor(status)}; font-weight:600;">${statusLabel(status)}</div>` : '';
            return `<div style="background:${C.card}; border:1px solid ${borderVal}; border-radius:12px; padding:18px 20px; position:relative; overflow:hidden;">${topBar}<div style="color:${C.textDim}; font-size:11px; font-family:'Sora'; font-weight:500; text-transform:uppercase; letter-spacing:0.07em; margin-bottom:8px; padding-right:48px; line-height:1.3;">${label}</div><div style="color:${C.text}; font-family:'JetBrains Mono'; font-size:20px; font-weight:500;">${value}</div>${sub ? `<div style="margin-top:6px; color:${C.textDim}; font-size:11px;">${sub}</div>` : ''}${statusTag}</div>`;
        };

        const activeCharts = {};

        function renderChart(elId, type, options) {
            if (activeCharts[elId]) {
                activeCharts[elId].destroy();
                activeCharts[elId] = null;
            }
            const el = document.getElementById(elId);
            if (!el) return;
            const chart = new ApexCharts(el, options);
            chart.render();
            activeCharts[elId] = chart;
        }

        // ── Vanilla Custom Date Picker Logic (Restored full original) ──
        function getQueryParam(name) {
            const urlParams = new URLSearchParams(window.location.search);
            return urlParams.get(name);
        }

        function getPresetDates(presetName) {
            const today = new Date();
            let since = new Date();
            let until = new Date();
            switch (presetName) {
                case 'today':
                    break;
                case 'yesterday':
                    since.setDate(today.getDate() - 1);
                    until.setDate(today.getDate() - 1);
                    break;
                case 'last_7d':
                    since.setDate(today.getDate() - 7);
                    until.setDate(today.getDate() - 1);
                    break;
                case 'last_30d':
                    since.setDate(today.getDate() - 30);
                    until.setDate(today.getDate() - 1);
                    break;
                case 'this_month':
                    since = new Date(today.getFullYear(), today.getMonth(), 1);
                    until = today;
                    break;
                case 'last_month':
                    since = new Date(today.getFullYear(), today.getMonth() - 1, 1);
                    until = new Date(today.getFullYear(), today.getMonth(), 0);
                    break;
            }
            return {
                since: since.toISOString().split('T')[0],
                until: until.toISOString().split('T')[0]
            };
        }

        function parsedInitialDates() {
            const initialSince = getQueryParam('since');
            const initialUntil = getQueryParam('until');
            const initialPreset = getQueryParam('preset');
            if (initialSince && initialUntil) return {
                since: new Date(initialSince),
                until: new Date(initialUntil)
            };
            const presetVal = initialPreset || 'last_30d';
            const dates = getPresetDates(presetVal);
            return {
                since: new Date(dates.since),
                until: new Date(dates.until)
            };
        }

        const generateCalendarCells = (year, month) => {
            const cells = [];
            const daysInMonth = new Date(year, month + 1, 0).getDate();
            const firstDay = new Date(year, month, 1).getDay();
            const prevMonth = month === 0 ? 11 : month - 1;
            const prevYear = month === 0 ? year - 1 : year;
            const daysInPrevMonth = new Date(prevYear, prevMonth + 1, 0).getDate();
            for (let i = firstDay - 1; i >= 0; i--) {
                const day = daysInPrevMonth - i;
                cells.push({
                    date: new Date(prevYear, prevMonth, day),
                    isCurrentMonth: false,
                    dayNumber: day
                });
            }
            for (let i = 1; i <= daysInMonth; i++) {
                cells.push({
                    date: new Date(year, month, i),
                    isCurrentMonth: true,
                    dayNumber: i
                });
            }
            const remaining = 42 - cells.length;
            const nextMonth = month === 11 ? 0 : month + 1;
            const nextYear = month === 11 ? year + 1 : year;
            for (let i = 1; i <= remaining; i++) {
                cells.push({
                    date: new Date(nextYear, nextMonth, i),
                    isCurrentMonth: false,
                    dayNumber: i
                });
            }
            return cells;
        };

        window.toggleDatePicker = (e) => {
            if (e) e.stopPropagation();
            state.isDatePickerOpen = !state.isDatePickerOpen;
            const popup = document.getElementById('date-picker-popup');
            if (state.isDatePickerOpen) {
                popup.style.display = 'flex';
                renderDatePickerPopup();
            } else {
                popup.style.display = 'none';
            }
        };

        window.handlePrevMonth = (e) => {
            e.stopPropagation();
            state.calendarMonth = new Date(state.calendarMonth.getFullYear(), state.calendarMonth.getMonth() - 1, 1);
            renderDatePickerPopup();
        };
        window.handleNextMonth = (e) => {
            e.stopPropagation();
            state.calendarMonth = new Date(state.calendarMonth.getFullYear(), state.calendarMonth.getMonth() + 1, 1);
            renderDatePickerPopup();
        };

        window.handlePresetClick = (presetId) => {
            // "Last 1 Year" / "All Time" (assets/js/date_presets.js): sent as dates, never as a Meta / Google preset
            const extra = window.PQDates && PQDates.range(presetId);
            if (extra) {
                state.presetAlias = presetId;
                state.tempPreset = 'custom';
                state.tempStartDate = new Date(extra.since);
                state.tempEndDate = new Date(extra.until);
                renderDatePickerPopup();
                return;
            }
            state.presetAlias = null;
            state.tempPreset = presetId;
            if (presetId !== 'custom') {
                const dates = getPresetDates(presetId);
                state.tempStartDate = new Date(dates.since);
                state.tempEndDate = new Date(dates.until);
            }
            renderDatePickerPopup();
        };

        window.handleCellClick = (el) => {
            state.presetAlias = null;
            const date = new Date(el.getAttribute('data-date'));
            state.tempPreset = 'custom';
            if (!state.tempStartDate || (state.tempStartDate && state.tempEndDate)) {
                state.tempStartDate = date;
                state.tempEndDate = null;
            } else if (state.tempStartDate && !state.tempEndDate) {
                if (date < state.tempStartDate) state.tempStartDate = date;
                else state.tempEndDate = date;
            }
            renderDatePickerPopup();
        };

        window.handleCellMouseEnter = (el) => {
            const date = new Date(el.getAttribute('data-date'));
            if (state.tempStartDate && !state.tempEndDate) {
                state.hoverDate = date;
                document.querySelectorAll('.calendar-cell').forEach(cell => {
                    const cDate = new Date(cell.getAttribute('data-date'));
                    const isStart = state.tempStartDate && cDate.toDateString() === state.tempStartDate.toDateString();
                    let inRange = cDate > state.tempStartDate && cDate < date;
                    if (!isStart) {
                        if (inRange) {
                            cell.style.background = C.blueLo;
                            cell.style.color = C.blue;
                        } else {
                            cell.style.background = 'transparent';
                            cell.style.color = cell.classList.contains('current-month') ? C.text : C.textDim + "44";
                        }
                    }
                });
            }
        };

        window.handleDatePickerCancel = (e) => {
            e.stopPropagation();
            state.isDatePickerOpen = false;
            document.getElementById('date-picker-popup').style.display = 'none';
            const parsed = parsedInitialDates();
            state.tempStartDate = parsed.since;
            state.tempEndDate = parsed.until;
            state.tempPreset = getQueryParam('since') ? 'custom' : (getQueryParam('preset') || 'last_30d');
        };

        window.handleDatePickerApply = (e) => {
            e.stopPropagation();
            state.isDatePickerOpen = false;
            document.getElementById('date-picker-popup').style.display = 'none';
            if (state.tempPreset === 'custom') {
                if (state.tempStartDate && state.tempEndDate) fetchDashboardData();
            } else {
                fetchDashboardData();
            }
        };

        // ── PerformIQ: one date filter for every dashboard (main dashboard top bar) + "Target vs Achieved" card ──
        (function () {
            const PQ_PLATFORM = 'google';
            const EMBED = /[?&]embed=1(&|$)/.test(location.search);
            const f2 = d => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
            const rangeNow = () => {
                if (state.tempPreset === 'custom' && state.tempStartDate && state.tempEndDate) return { since: f2(state.tempStartDate), until: f2(state.tempEndDate) };
                const d = getPresetDates(state.tempPreset || 'last_30d');
                return { since: d.since, until: d.until };
            };
            let tg = null;
            const tgUpdate = () => { if (tg) { try { tg.update(rangeNow()); } catch (e) { /* dates not ready yet */ } } };
            const origApply = window.handleDatePickerApply;
            window.handleDatePickerApply = (e) => { origApply(e); tgUpdate(); };
            // the main dashboard sends its dates to every embedded dashboard
            window.addEventListener('message', (e) => {
                const d = e.data;
                if (!d || d.type !== 'pq-range' || e.source !== window.parent || !d.since || !d.until) return;
                const cur = rangeNow();
                if (cur.since === d.since && cur.until === d.until && state.rawData) { tgUpdate(); return; }
                state.tempPreset = 'custom';
                state.tempStartDate = new Date(d.since + 'T00:00:00');
                state.tempEndDate = new Date(d.until + 'T00:00:00');
                window.fetchDashboardData();
                tgUpdate();
            });
            const ready = fn => document.readyState === 'loading' ? document.addEventListener('DOMContentLoaded', fn) : fn();
            ready(() => {
                if (EMBED) {                                   // one date filter: the main dashboard's
                    const l = document.getElementById('date-range-display');
                    const box = l && l.closest('div[style*="flex-direction:column"]');
                    if (box) box.style.display = 'none';
                }
                if (window.PQTargets && !(window.PQ_CAN && window.PQ_CAN.targets === false)) {
                    const host = document.createElement('div');
                    host.id = 'pq-targets';
                    const after = document.getElementById('filters-container');
                    if (after) after.after(host); else document.body.prepend(host);
                    tg = PQTargets.mount(host, { api: '../targets_api.php', platform: PQ_PLATFORM, editUrl: '../dashboard.php#targets' });
                    setTimeout(tgUpdate, 0);
                }
            });
        })();

        const renderCalendarHTML = (monthDate, isLeft) => {
            const year = monthDate.getFullYear();
            const month = monthDate.getMonth();
            const monthName = monthDate.toLocaleString('default', {
                month: 'long'
            });
            const cells = generateCalendarCells(year, month);
            const weekDays = ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'];
            const prevBtn = isLeft ? `<button onclick="handlePrevMonth(event)" style="position: absolute; left: 0; background: none; border: none; color: ${C.text}; cursor: pointer; font-weight: bold; outline:none;">◀</button>` : '';
            const nextBtn = !isLeft ? `<button onclick="handleNextMonth(event)" style="position: absolute; right: 0; background: none; border: none; color: ${C.text}; cursor: pointer; font-weight: bold; outline:none;">▶</button>` : '';
            const weekHeaders = weekDays.map(d => `<span style="color: ${C.textDim}; font-size: 10px; font-weight: 600;">${d}</span>`).join('');
            const cellElements = cells.map((cell) => {
                const isSelectedStart = state.tempStartDate && cell.date.toDateString() === state.tempStartDate.toDateString();
                const isSelectedEnd = state.tempEndDate && cell.date.toDateString() === state.tempEndDate.toDateString();
                let isInRange = false;
                if (state.tempStartDate && state.tempEndDate) isInRange = cell.date > state.tempStartDate && cell.date < state.tempEndDate;
                else if (state.tempStartDate && state.hoverDate) isInRange = (cell.date > state.tempStartDate && cell.date < state.hoverDate) || (cell.date < state.tempStartDate && cell.date > state.hoverDate);
                const isSelected = isSelectedStart || isSelectedEnd;
                let bg = "transparent",
                    color = cell.isCurrentMonth ? C.text : C.textDim + "44",
                    borderRadius = "4px";
                if (isSelected) {
                    bg = C.blue;
                    color = "#ffffff";
                    borderRadius = "50%";
                } else if (isInRange) {
                    bg = C.blueLo;
                    color = C.blue;
                }
                return `<div class="calendar-cell ${cell.isCurrentMonth ? 'current-month' : ''}" data-date="${cell.date.toISOString()}" onmouseenter="handleCellMouseEnter(this)" onclick="handleCellClick(this)" style="height: 28px; display: flex; align-items: center; justify-content: center; font-size: 11px; cursor: pointer; background: ${bg}; color: ${color}; border-radius: ${borderRadius}; font-weight: ${isSelected ? 'bold' : 'normal'};">${cell.dayNumber}</div>`;
            }).join('');
            return `<div style="width: 240px;"><div style="display: flex; justify-content: center; align-items: center; margin-bottom: 12px; position: relative;">${prevBtn}<span style="color: ${C.text}; font-weight: 600; font-size: 13px;">${monthName} ${year}</span>${nextBtn}</div><div style="display: grid; grid-template-columns: repeat(7, 1fr); gap: 4px; margin-bottom: 8px; text-align: center;">${weekHeaders}</div><div style="display: grid; grid-template-columns: repeat(7, 1fr); gap: 4px;">${cellElements}</div></div>`;
        };

        function renderDatePickerPopup() {
            const popup = document.getElementById('date-picker-popup');
            if (!popup) return;
            const leftMonth = state.calendarMonth;
            const rightMonth = new Date(state.calendarMonth.getFullYear(), state.calendarMonth.getMonth() + 1, 1);
            const formatDateDMY = (date) => {
                if (!date) return '';
                return `${String(date.getDate()).padStart(2, '0')}/${String(date.getMonth() + 1).padStart(2, '0')}/${date.getFullYear()}`;
            };
            const PRESETS = [{
                id: 'today',
                label: 'Today'
            }, {
                id: 'yesterday',
                label: 'Yesterday'
            }, {
                id: 'last_7d',
                label: 'Last 7 Days'
            }, {
                id: 'last_30d',
                label: 'Last 30 Days'
            }, {
                id: 'this_month',
                label: 'This Month'
            }, {
                id: 'last_month',
                label: 'Last Month'
            }, {
                id: 'last_1y',
                label: 'Last 1 Year'
            }, {
                id: 'all_time',
                label: 'All Time'
            }, {
                id: 'custom',
                label: 'Custom Range'
            }];
            const presetsHTML = PRESETS.map(p => `<button onclick="handlePresetClick('${p.id}')" style="background: ${(state.presetAlias ? state.presetAlias === p.id : state.tempPreset === p.id) ? C.blue : 'transparent'}; color: ${(state.presetAlias ? state.presetAlias === p.id : state.tempPreset === p.id) ? '#ffffff' : C.text}; border: none; border-radius: 6px; padding: 8px 12px; text-align: left; cursor: pointer; font-size: 12px; font-weight: ${(state.presetAlias ? state.presetAlias === p.id : state.tempPreset === p.id) ? 600 : 400}; outline: none;">${p.label}</button>`).join('');
            const displayRange = state.tempStartDate ? (state.tempEndDate ? `${formatDateDMY(state.tempStartDate)} - ${formatDateDMY(state.tempEndDate)}` : `${formatDateDMY(state.tempStartDate)} - Select End Date`) : "Select Date Range";
            popup.innerHTML = `<div style="display: flex; gap: 20px;"><div style="display: flex; flex-direction: column; gap: 4px; border-right: 1px solid ${C.border}; padding-right: 16px; width: 140px;">${presetsHTML}</div><div style="display: flex; gap: 24px; flex-grow: 1;">${renderCalendarHTML(leftMonth, true)}${renderCalendarHTML(rightMonth, false)}</div></div><div style="display: flex; justify-content: space-between; align-items: center; border-top: 1px solid ${C.border}; margin-top: 16px; padding-top: 16px;"><span style="color: ${C.text}; font-size: 12px; font-family: 'JetBrains Mono';">${displayRange}</span><div style="display: flex; gap: 10px;"><button onclick="handleDatePickerCancel(event)" style="background: ${C.card}; color: ${C.text}; border: 1px solid ${C.border}; border-radius: 6px; padding: 6px 16px; font-size: 12px; font-weight: 600; cursor: pointer;">CANCEL</button><button onclick="handleDatePickerApply(event)" ${(!state.tempStartDate || !state.tempEndDate) ? 'disabled' : ''} style="background: ${(!state.tempStartDate || !state.tempEndDate) ? C.muted : C.blue}; color: #ffffff; border: none; border-radius: 6px; padding: 6px 16px; font-size: 12px; font-weight: 600; cursor: ${(!state.tempStartDate || !state.tempEndDate) ? 'not-allowed' : 'pointer'};">APPLY</button></div></div>`;
        }

        document.addEventListener("mousedown", (event) => {
            const popup = document.getElementById('date-picker-popup');
            const trigger = event.target.closest('[onclick="toggleDatePicker(event)"]');
            if (popup && !popup.contains(event.target) && !trigger && state.isDatePickerOpen) {
                state.isDatePickerOpen = false;
                popup.style.display = 'none';
            }
        });

        // ── Client-side filtering logic ──
        window.handleFilterPlatformChange = (el) => {
            state.filterPlatform = el.value;
            updateFilteredStateAndRender();
        };
        window.handleSearchInput = (el) => {
            state.searchQuery = el.value;
            document.getElementById('search-clear-btn').style.display = el.value ? 'block' : 'none';
            updateFilteredStateAndRender();
        };
        window.clearSearchInput = () => {
            state.searchQuery = "";
            const input = document.getElementById('search-query');
            if (input) input.value = "";
            document.getElementById('search-clear-btn').style.display = 'none';
            updateFilteredStateAndRender();
        };

        function populateFilterSelects() {
            const platformSelect = document.getElementById('filter-platform');
            if (!platformSelect) return;
            const platforms = [...new Set(state.campaigns.map(c => c.platform))];
            platformSelect.innerHTML = `<option value="All">All</option>` + platforms.map(p => `<option value="${p}" ${state.filterPlatform === p ? 'selected' : ''}>${p}</option>`).join('');
        }

        function updateFilteredStateAndRender() {
            const filtered = state.campaigns.filter(c => {
                if (state.filterPlatform !== "All" && c.platform !== state.filterPlatform) return false;
                if (state.searchQuery && !c.campaign.toLowerCase().includes(state.searchQuery.toLowerCase())) return false;
                return true;
            });
            state.filteredCampaigns = filtered;
            renderDashboard();
        }

        // ── Tab Navigation ──
        window.handleTabChange = (tabId) => {
            state.activeTab = tabId;
            // Reset drill-down state when switching tabs
            state.campaignsViewLevel = 'campaign';
            state.selectedCampaignId = null;
            state.selectedCampaignName = '';
            state.selectedAdsetId = null;
            state.selectedAdsetName = '';
            state.adsets = [];
            state.ads = [];
            state.dtPage = 1;
            state.dtSearch = '';
            state.dtSortCol = '';
            state.dtSortDir = 1;
            renderDashboard();
        };

        // ── AI Insights (real AI via Groq, with local fallback) ──
        const generateLocalGoogleInsights = (camps, totalSpend, totalLeads) => {
            const avgCPL = totalLeads > 0 ? Math.round(totalSpend / totalLeads) : 0;
            return {
                executiveSummary: `Portfolio average CPL stands at ₹${fmtN(avgCPL)}. Google Search campaigns show high intent efficiency.`,
                keyWins: ["Google Search queries are capturing high-intent prospects.", "Brand campaigns yielding strong CTR."],
                majorConcerns: ["Ensure non-performing keywords are added to negative lists.", "Watch broad match queries eating into budget."],
                optimizationOpportunities: ["Shift budget toward highest converting exact-match clusters.", "Deploy remarketing lists for search ads (RLSA)."],
                budgetReallocation: ["Reallocate 15% of budget from display to search."],
                scalingRecommendations: ["Scale exact-match budget by 10% WoW."],
                actionableNextSteps: ["Review search terms report.", "Update ad extensions."]
            };
        };

        window.handleGenerateInsights = async (e) => {
            if (e) e.preventDefault();
            state.loadingInsights = true;
            state.activeTab = "insights";
            renderDashboard();

            const globalBtnText = document.getElementById('ai-insights-btn-text');
            if (globalBtnText) globalBtnText.innerText = "Analyzing…";

            const totalSpend = state.filteredCampaigns.reduce((a, c) => a + c.spend, 0);
            // const totalLeads = state.filteredCampaigns.reduce((a, c) => a + c.leads, 0);
            const totalLeads = getUniqueLeads(state.filteredCampaigns, 'leads_data').length;
            const totalWalkins = state.filteredCampaigns.reduce((a, c) => a + c.walkins, 0);
            const totalQual = state.filteredCampaigns.reduce((a, c) => a + c.qualified, 0);
            const avgCPL = totalLeads > 0 ? Math.round(totalSpend / totalLeads) : 0;

            // Build a clean payload for the AI to analyze (top 25 campaigns by spend, to keep the prompt small)
            const payload = {
                summary: {
                    total_spend: totalSpend,
                    total_leads: totalLeads,
                    total_walkins: totalWalkins,
                    total_qualified: totalQual,
                    avg_cpl: avgCPL,
                    date_range: state.dateRange || null
                },
                campaigns: [...state.filteredCampaigns]
                    .sort((a, b) => b.spend - a.spend)
                    .slice(0, 25)
                    .map(c => ({
                        campaign_name: c.campaign || 'Unknown Campaign',
                        platform: c.platform || 'Google',
                        spend: c.spend,
                        leads: c.leads,
                        walkins: c.walkins,
                        qualified: c.qualified,
                        cpl: c.cpl || (c.leads > 0 ? Math.round(c.spend / c.leads) : 0),
                        cpsv: c.cpsv,
                        cpql: c.cpql,
                        ctr: c.ctr,
                        cpc: c.cpc,
                        cpm: c.cpm,
                        impressions: c.impressions,
                        clicks: c.clicks,
                        campaign_status: c.campaignStatus
                    }))
            };

            try {
                const res = await fetch('ai_insights_api.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(payload)
                });
                const data = await res.json();

                if (data.success && data.analysis) {
                    state.insights = {
                        ...data.analysis,
                        _source: 'ai'
                    };
                } else {
                    console.warn('AI Insights failed, falling back to local insights:', data);
                    state.insights = generateLocalGoogleInsights(state.filteredCampaigns, totalSpend, totalLeads);
                    state.insights._source = 'local';
                }
            } catch (err) {
                console.error('AI Insights request error, falling back to local insights:', err);
                state.insights = generateLocalGoogleInsights(state.filteredCampaigns, totalSpend, totalLeads);
                state.insights._source = 'local';
            }

            state.loadingInsights = false;
            if (globalBtnText) globalBtnText.innerText = "Generate AI Insights";
            renderDashboard();
        };

        // pagination start
        function dtGetFiltered() {
            let d = state.campaignsViewLevel === 'campaign' ? state.filteredCampaigns : (state.campaignsViewLevel === 'adset' ? (state.adsets || []) : (state.ads || []));
            if (state.dtSearch) {
                const q = state.dtSearch.toLowerCase();
                d = d.filter(c => {
                    const label = (c.campaign || c.name || '').toLowerCase();
                    return label.includes(q);
                });
            }
            if (state.dtSortCol) {
                const k = state.dtSortCol,
                    dir = state.dtSortDir;
                d = [...d].sort((a, b) => {
                    const av = typeof a[k] === 'string' ? a[k] : +a[k];
                    const bv = typeof b[k] === 'string' ? b[k] : +b[k];
                    return av < bv ? -dir : av > bv ? dir : 0;
                });
            }
            return d;
        }

        window.dtSort = (col) => {
            if (state.dtSortCol === col) state.dtSortDir *= -1;
            else {
                state.dtSortCol = col;
                state.dtSortDir = 1;
            }
            state.dtPage = 1;
            document.querySelectorAll('#camps-table th').forEach(th => {
                th.classList.remove('sorted-asc', 'sorted-desc');
                if (th.dataset.col === col) th.classList.add(state.dtSortDir === 1 ? 'sorted-asc' : 'sorted-desc');
            });
            renderCampaignsTable();
        };

        window.dtGoTo = (p) => {
            state.dtPage = p;
            renderCampaignsTable();
        };
        window.dtSetPageSize = (n) => {
            state.dtPageSize = n;
            state.dtPage = 1;
            renderCampaignsTable();
        };
        window.dtSetSearch = (v) => {
            state.dtSearch = v;
            state.dtPage = 1;
            renderCampaignsTable();
        };


        window.fetchPivotDataIfNeeded = async () => {
            if (state.pivotRows && state.pivotRows.length > 0) return state.pivotRows;
            try {
                const params = new URLSearchParams();
                params.set('action', 'fetch_pivot_report');
                if (state.dateRange) {
                    const dates = getPresetDates(state.selectedPreset || 'last_30d');
                    params.set('since', dates.since);
                    params.set('until', dates.until);
                }
                const res = await fetch(`googleapi.php?${params.toString()}`);
                const data = await res.json();
                if (data.rows) {
                    state.pivotRows = data.rows;
                    return data.rows;
                }
            } catch (err) {
                console.error("Error loading pivot data for drilldown:", err);
            }
            return [];
        };

        window.drillDownToAdsets = async (campaignId, campaignName) => {
            state.campaignsViewLevel = 'adset';
            state.dtPage = 1;
            state.selectedCampaignId = campaignId;
            state.selectedCampaignName = campaignName;
            state.isLoadingAdsets = true;
            renderDashboard();

            const rows = await fetchPivotDataIfNeeded();
            const campRows = rows.filter(r => {
                const rCampName = (r.campaign_name || '').trim().toLowerCase();
                const cName = (campaignName || '').trim().toLowerCase();
                const cId = (campaignId || '').toString().trim();
                const rCampId = (r.campaign_id || r.utm_campaignid || '').toString().trim();

                if (cId && rCampId && cId === rCampId) return true;
                if (rCampName === cName) return true;

                const normR = rCampName.replace(/[^a-z0-9]/g, '');
                const normC = cName.replace(/[^a-z0-9]/g, '');
                if (normR && normC && normR === normC) return true;
                return false;
            });

            // Group by adset_name
            const map = {};
            campRows.forEach(r => {
                const adsetName = (r.adset_name || 'Unknown AdGroup').trim();
                if (!map[adsetName]) {
                    map[adsetName] = {
                        name: adsetName,
                        campaign: campaignName,
                        platform: 'Google',
                        spend: 0,
                        impressions: 0,
                        clicks: 0,
                        leads: 0,
                        qualified: 0,
                        walkins: 0,
                        campaignStatus: 'ENABLED'
                    };
                }
                map[adsetName].pm = window.PQColumns ? PQColumns.addPm(map[adsetName].pm, r.pm, map[adsetName].impressions, r.impressions || 0) : {};
                map[adsetName].spend += (r.spend || 0);
                map[adsetName].impressions += (r.impressions || 0);
                map[adsetName].clicks += (r.clicks || 0);
                map[adsetName].leads += (r.leads || r.total_leads || 0);
                map[adsetName].qualified += (r.qualified || r.in_qualified || 0);
                map[adsetName].walkins += (r.walkins || r.sitevisits || 0);
            });

            state.adsets = Object.values(map).map(a => {
                const ctr = a.impressions > 0 ? (a.clicks / a.impressions) * 100 : 0;
                const cpm = a.impressions > 0 ? (a.spend / a.impressions) * 1000 : 0;
                const cpl = a.leads > 0 ? a.spend / a.leads : 0;
                const cpql = a.qualified > 0 ? a.spend / a.qualified : 0;
                const cpsv = a.walkins > 0 ? a.spend / a.walkins : 0;
                return {...a, ctr, cpm, cpl, cpql, cpsv};
            });

            state.isLoadingAdsets = false;
            renderDashboard();
        };

        window.drillDownToAds = async (adsetId, adsetName) => {
            state.campaignsViewLevel = 'ad';
            state.dtPage = 1;
            state.selectedAdsetId = adsetId;
            state.selectedAdsetName = adsetName;
            state.isLoadingAds = true;
            renderDashboard();

            const rows = await fetchPivotDataIfNeeded();
            const adRows = rows.filter(r => {
                const rCampName = (r.campaign_name || '').trim().toLowerCase();
                const cName = (state.selectedCampaignName || '').trim().toLowerCase();
                const cId = (state.selectedCampaignId || '').toString().trim();
                const rCampId = (r.campaign_id || r.utm_campaignid || '').toString().trim();

                const normR = rCampName.replace(/[^a-z0-9]/g, '');
                const normC = cName.replace(/[^a-z0-9]/g, '');

                const campMatches = (cId && rCampId && cId === rCampId) || (rCampName === cName) || (normR && normC && normR === normC);

                const rAdsetName = (r.adset_name || '').trim().toLowerCase();
                const aName = (adsetName || '').trim().toLowerCase();
                const normRAdset = rAdsetName.replace(/[^a-z0-9]/g, '');
                const normA = aName.replace(/[^a-z0-9]/g, '');

                const adsetMatches = (rAdsetName === aName) || (normRAdset && normA && normRAdset === normA);

                return campMatches && adsetMatches;
            });

            // Group by ad_name
            const map = {};
            adRows.forEach(r => {
                const adName = (r.ad_name || 'Unknown Ad').trim();
                if (!map[adName]) {
                    map[adName] = {
                        name: adName,
                        adset: adsetName,
                        campaign: state.selectedCampaignName,
                        platform: 'Google',
                        spend: 0,
                        impressions: 0,
                        clicks: 0,
                        leads: 0,
                        qualified: 0,
                        walkins: 0,
                        campaignStatus: 'ENABLED'
                    };
                }
                map[adName].pm = window.PQColumns ? PQColumns.addPm(map[adName].pm, r.pm, map[adName].impressions, r.impressions || 0) : {};
                map[adName].spend += (r.spend || 0);
                map[adName].impressions += (r.impressions || 0);
                map[adName].clicks += (r.clicks || 0);
                map[adName].leads += (r.leads || r.total_leads || 0);
                map[adName].qualified += (r.qualified || r.in_qualified || 0);
                map[adName].walkins += (r.walkins || r.sitevisits || 0);
            });

            state.ads = Object.values(map).map(ad => {
                const ctr = ad.impressions > 0 ? (ad.clicks / ad.impressions) * 100 : 0;
                const cpm = ad.impressions > 0 ? (ad.spend / ad.impressions) * 1000 : 0;
                const cpl = ad.leads > 0 ? ad.spend / ad.leads : 0;
                const cpql = ad.qualified > 0 ? ad.spend / ad.qualified : 0;
                const cpsv = ad.walkins > 0 ? ad.spend / ad.walkins : 0;
                return {...ad, ctr, cpm, cpl, cpql, cpsv};
            });

            state.isLoadingAds = false;
            renderDashboard();
        };

        window.goBackView = () => {
            state.dtPage = 1;
            if (state.campaignsViewLevel === 'ad') {
                state.campaignsViewLevel = 'adset';
                state.selectedAdsetId = null;
                state.selectedAdsetName = '';
            } else if (state.campaignsViewLevel === 'adset') {
                state.campaignsViewLevel = 'campaign';
                state.selectedCampaignId = null;
                state.selectedCampaignName = '';
            }
            renderDashboard();
        };
        window.handleBack = window.goBackView;

        function renderCampaignsTable() {
            // Handle loading states
            if ((state.campaignsViewLevel === 'adset' && state.isLoadingAdsets) ||
                (state.campaignsViewLevel === 'ad' && state.isLoadingAds)) {
                const bodyEl = document.getElementById('dt-body');
                const footEl = document.getElementById('dt-foot');
                const loadingLabel = state.campaignsViewLevel === 'adset' ? 'Adsets' : 'Ads';
                if (bodyEl) bodyEl.innerHTML = `<tr><td colspan="14" style="text-align:center; padding:40px; color:${C.accent};"><span class="pulse">⏳ Loading ${loadingLabel}...</span></td></tr>`;
                if (footEl) footEl.innerHTML = '';
                return;
            }

            const all = dtGetFiltered();
            const ps = state.dtPageSize === -1 ? all.length : state.dtPageSize;
            const total = all.length;
            const pages = Math.max(1, Math.ceil(total / ps));
            if (state.dtPage > pages) state.dtPage = pages;
            const start = (state.dtPage - 1) * ps;
            const slice = all.slice(start, Math.min(start + ps, total));

            const tableRowsHTML = slice.map(c => {
                const displayName = c.campaign || c.name || '';
                const statusDot = c.campaignStatus === 'ENABLED' ? C.green : c.campaignStatus === 'PAUSED' ? C.red : C.yellow;
                let nameClickAttr = '';
                if (state.campaignsViewLevel === 'campaign') {
                    nameClickAttr = `onclick="drillDownToAdsets('${(c.id || c.campaign || '').replace(/'/g, "\\'")}', '${(c.campaign || '').replace(/'/g, "\\'")}')" title="Click to view adgroups inside this campaign"`;
                } else if (state.campaignsViewLevel === 'adset') {
                    nameClickAttr = `onclick="drillDownToAds('${(c.name || '').replace(/'/g, "\\'")}', '${(c.name || '').replace(/'/g, "\\'")}')" title="Click to view ads inside this adgroup"`;
                }
                return `
                <tr>
                  <td><span style="display:inline-block;width:8px;height:8px;border-radius:50%;background:${statusDot};box-shadow:0 0 6px ${statusDot};"></span></td>
                  <td style="font-weight:600;max-width:220px;color:${C.blue};${nameClickAttr ? 'text-decoration:underline;cursor:pointer;' : ''}" ${nameClickAttr}>
                    <div style="white-space:nowrap;overflow:hidden;text-overflow:ellipsis;" title="${displayName}">${displayName}</div>
                  </td>
                  <td><span class="badge" style="background:${(PLATFORM_COLORS[c.platform] || PLATFORM_COLORS.Other)}20;color:${PLATFORM_COLORS[c.platform] || PLATFORM_COLORS.Other};border:1px solid ${(PLATFORM_COLORS[c.platform] || PLATFORM_COLORS.Other)}44;border-radius:4px;padding:2px 8px;font-size:10px;font-weight:600;text-transform:uppercase;">${c.platform}</span></td>
                  <td class="mono">${fmtSpend(c.spend)}</td>
                  <td class="mono">${fmtImpressions(c.impressions)}</td>
                  <td class="mono">${fmtN(c.clicks)}</td>
                  <td class="mono" style="color:${c.ctr >= 1.5 ? C.green : c.ctr >= 0.8 ? C.yellow : C.red}">${fmtCTR(c.ctr)}</td>
                  <td class="mono">${fmtCPM(c.cpm || 0)}</td>
                  <td class="mono" style="color:${C.accent};font-weight:600;${c.leads > 0 ? 'cursor:pointer;text-decoration:underline;' : ''}" ${c.leads > 0 && state.campaignsViewLevel === 'campaign' ? `onclick="openLeadsModalByCampaign('${encodeURIComponent(c.campaign)}', 'leads_data')"` : ''}>${fmtN(c.leads)}</td>
                  <td class="mono" style="color:${c.cpl > 0 && c.cpl < 500 ? C.green : C.yellow};font-weight:600;">${fmtCPL(c.cpl || 0)}</td>
                  <td class="mono" style="color:${C.blue};font-weight:600;${c.qualified > 0 ? 'cursor:pointer;text-decoration:underline;' : ''}" ${c.qualified > 0 && state.campaignsViewLevel === 'campaign' ? `onclick="openLeadsModalByCampaign('${encodeURIComponent(c.campaign)}', 'qualified_leads')"` : ''}>${fmtN(c.qualified)}</td>
                  <td class="mono" style="color:${C.textDim};">${fmtCPL(c.cpql)}</td>
                  <td class="mono" style="color:${C.green};font-weight:600;${c.walkins > 0 ? 'cursor:pointer;text-decoration:underline;' : ''}" ${c.walkins > 0 && state.campaignsViewLevel === 'campaign' ? `onclick="openLeadsModalByCampaign('${encodeURIComponent(c.campaign)}', 'walkin_leads')"` : ''}>${fmtN(c.walkins)}</td>
                  <td class="mono" style="color:${C.textDim};">${fmtCPL(c.cpsv)}</td>
                </tr>`;
            }).join('');

            const tSpend = all.reduce((a, c) => a + c.spend, 0);
            const tImpr = all.reduce((a, c) => a + c.impressions, 0);
            const tClk = all.reduce((a, c) => a + c.clicks, 0);
            // At campaign level use deduped leads; at adset/ad level use simple sums
            const isTopLevel = state.campaignsViewLevel === 'campaign';
            const tLeads = isTopLevel ? getUniqueLeads(all, 'leads_data').length : all.reduce((a, c) => a + (c.leads || 0), 0);
            const tQual = isTopLevel ? getUniqueLeads(all, 'qualified_leads').length : all.reduce((a, c) => a + (c.qualified || 0), 0);
            const tWalk = isTopLevel ? getUniqueLeads(all, 'walkin_leads').length : all.reduce((a, c) => a + (c.walkins || 0), 0);
            const tCTR = tImpr > 0 ? tClk / tImpr * 100 : 0;
            const tCPM = tImpr > 0 ? tSpend / tImpr * 1000 : 0;
            const entityName = state.campaignsViewLevel === 'campaign' ? 'campaigns' : (state.campaignsViewLevel === 'adset' ? 'adsets' : 'ads');
            const totalTdStyle = `background:${C.accentLo};`;
            const totalRowHTML = `
                <tr style="background:${C.accentLo};border-top:2px solid ${C.accent}44;">
                  <td style="${totalTdStyle}"></td>
                  <td style="${totalTdStyle}font-weight:700;color:${C.accent};font-size:12.5px;">TOTAL <span style="color:${C.textDim};font-size:10px;font-weight:400;">${total} ${entityName}</span></td>
                  <td style="${totalTdStyle}"></td>
                  <td class="mono" style="${totalTdStyle}font-weight:700;color:${C.accent};">${fmtSpend(tSpend)}</td>
                  <td class="mono" style="${totalTdStyle}font-weight:700;color:${C.accent};">${fmtImpressions(tImpr)}</td>
                  <td class="mono" style="${totalTdStyle}font-weight:700;color:${C.accent};">${fmtN(tClk)}</td>
                  <td class="mono" style="${totalTdStyle}font-weight:700;color:${tCTR >= 1.5 ? C.green : tCTR >= 0.8 ? C.yellow : C.red};">${fmtCTR(tCTR)}</td>
                  <td class="mono" style="${totalTdStyle}font-weight:700;color:${C.accent};">${fmtCPM(tCPM)}</td>
                  <td class="mono" style="${totalTdStyle}font-weight:700;color:${C.accent};${tLeads > 0 ? 'cursor:pointer;text-decoration:underline;' : ''}" ${tLeads > 0 && isTopLevel ? `onclick="openLeadsModalTotal('leads_data')"` : ''}>${fmtN(tLeads)}</td>
                  <td class="mono" style="${totalTdStyle}font-weight:700;color:${tLeads > 0 && tSpend / tLeads < 500 ? C.green : C.yellow};">${fmtCPL(tLeads > 0 ? tSpend / tLeads : 0)}</td>
                  <td class="mono" style="${totalTdStyle}font-weight:700;color:${C.blue};${tQual > 0 ? 'cursor:pointer;text-decoration:underline;' : ''}" ${tQual > 0 && isTopLevel ? `onclick="openLeadsModalTotal('qualified_leads')"` : ''}>${fmtN(tQual)}</td>
                  <td class="mono" style="${totalTdStyle}font-weight:700;">${tQual > 0 ? fmtCPL(tSpend / tQual) : '₹0.00'}</td>
                  <td class="mono" style="${totalTdStyle}font-weight:700;color:${C.green};${tWalk > 0 ? 'cursor:pointer;text-decoration:underline;' : ''}" ${tWalk > 0 && isTopLevel ? `onclick="openLeadsModalTotal('walkin_leads')"` : ''}>${fmtN(tWalk)}</td>
                  <td class="mono" style="${totalTdStyle}font-weight:700;">${tWalk > 0 ? fmtCPL(tSpend / tWalk) : '₹0.00'}</td>
                </tr>`;

            const bodyEl = document.getElementById('dt-body');
            const footEl = document.getElementById('dt-foot');
            if (bodyEl) bodyEl.innerHTML = tableRowsHTML || `<tr><td colspan="14" style="text-align:center;color:${C.textDim};padding:24px;">No ${entityName} match filters.</td></tr>`;
            if (footEl) footEl.innerHTML = totalRowHTML;
            // ▥ Columns: show / hide / reorder / extra + custom columns (js/column_picker.js)
            if (window.PQColumns) PQColumns.apply({ table: 'camps-table', key: 'google', rows: slice, allRows: all, lock: 2, host: 'pq-cols-host-google' });

            const s = total === 0 ? 0 : start + 1;
            const e = Math.min(start + ps, total);
            const infoEl = document.getElementById('dt-info');
            if (infoEl) infoEl.innerText = `Showing ${s} to ${e} of ${total} entries${state.dtSearch ? ' (filtered)' : ''}`;

            const pg = document.getElementById('dt-pagination');
            if (!pg) return;
            if (state.dtPageSize === -1 || pages <= 1) {
                pg.innerHTML = '';
                return;
            }
            const btnS = `background:var(--pq-card);color:var(--pq-text-dim);border:1px solid var(--pq-border);border-radius:6px;padding:4px 10px;font-size:11px;cursor:pointer;font-family:'Sora',sans-serif;`;
            const btnA = `background:#E8A820;color:var(--pq-bg);border:1px solid #E8A820;border-radius:6px;padding:4px 10px;font-size:11px;font-weight:700;cursor:pointer;font-family:'Sora',sans-serif;`;
            const delta = 2,
                lo = Math.max(1, state.dtPage - delta),
                hi = Math.min(pages, state.dtPage + delta);
            let btns = `<button style="${btnS}" onclick="dtGoTo(${state.dtPage - 1})" ${state.dtPage === 1 ? 'disabled' : ''}>‹ Prev</button>`;
            if (lo > 1) {
                btns += `<button style="${btnS}" onclick="dtGoTo(1)">1</button>`;
                if (lo > 2) btns += `<span style="color:var(--pq-muted);padding:0 4px">…</span>`;
            }
            for (let p = lo; p <= hi; p++) btns += `<button style="${p === state.dtPage ? btnA : btnS}" onclick="dtGoTo(${p})">${p}</button>`;
            if (hi < pages) {
                if (hi < pages - 1) btns += `<span style="color:var(--pq-muted);padding:0 4px">…</span>`;
                btns += `<button style="${btnS}" onclick="dtGoTo(${pages})">${pages}</button>`;
            }
            btns += `<button style="${btnS}" onclick="dtGoTo(${state.dtPage + 1})" ${state.dtPage === pages ? 'disabled' : ''}>Next ›</button>`;
            pg.innerHTML = btns;
        }
        // pagination end
        // ── Main UI Skeleton ──
        function renderSkeleton() {
            const container = document.getElementById('tab-content-container');
            if (!container) return;
            const filters = document.getElementById('filters-container');
            if (filters) filters.style.display = 'none';
            container.innerHTML = `<div style="padding: 28px 0; max-width: 1600px; margin: 0 auto;"><div style="display:grid; grid-template-columns:repeat(auto-fill,minmax(180px,1fr)); gap:14px; margin-bottom:24px;">${Array(8).fill().map(() => `<div style="background:${C.card}; border:1px solid ${C.border}; border-radius:12px; padding:18px 20px;"><div style="width:60%; height:11px; border-radius:4px; background:linear-gradient(90deg, ${C.card} 25%, ${C.surface} 50%, ${C.card} 75%); background-size:200% 100%; animation:shimmer 1.4s infinite linear;"></div><div style="margin-top:12px; width:80%; height:24px; border-radius:4px; background:linear-gradient(90deg, ${C.card} 25%, ${C.surface} 50%, ${C.card} 75%); background-size:200% 100%; animation:shimmer 1.4s infinite linear;"></div></div>`).join('')}</div></div>`;
        }

        // ── Main UI Rendering Orchestration ──
        function renderDashboard() {
            if (state.isLoading) {
                renderSkeleton();
                return;
            }

            const filters = document.getElementById('filters-container');
            if (filters) filters.style.display = 'flex';

            // const rangeDisplay = document.getElementById('date-range-display');
            const rangeDisplay = document.getElementById('date-range-display');
            if (rangeDisplay) {
                const fmt = d => d ? `${String(d.getDate()).padStart(2, '0')}/${String(d.getMonth() + 1).padStart(2, '0')}/${d.getFullYear()}` : '';
                if (state.tempPreset && state.tempPreset !== 'custom') {
                    const presetLabels = {
                        today: 'Today',
                        yesterday: 'Yesterday',
                        last_7d: 'Last 7 Days',
                        last_30d: 'Last 30 Days',
                        this_month: 'This Month',
                        last_month: 'Last Month'
                    };
                    rangeDisplay.innerText = `${presetLabels[state.tempPreset] || state.tempPreset}`;
                } else if (state.tempStartDate && state.tempEndDate) {
                    rangeDisplay.innerText = `${fmt(state.tempStartDate)} – ${fmt(state.tempEndDate)}`;
                } else {
                    rangeDisplay.innerText = `${state.dateRange}`;
                }
            }

            const footerLeft = document.getElementById('footer-text-left');
            // if (footerLeft) footerLeft.innerText = `PerfomIQ · ${state.projectName} · ${state.dateRange}`;
            if (footerLeft) footerLeft.innerText = state.projectName ? `PerfomIQ · ${state.projectName} · ${state.dateRange}` : `PerfomIQ · ${state.dateRange}`;

            const totalSpend = state.filteredCampaigns.reduce((a, c) => a + c.spend, 0);
            const totalLeads = state.filteredCampaigns.reduce((a, c) => a + c.leads, 0);

            const sumQual = getUniqueLeads(state.filteredCampaigns, 'qualified_leads').length;
            const sumWalk = getUniqueLeads(state.filteredCampaigns, 'walkin_leads').length;
            const avgCPL = totalLeads > 0 ? totalSpend / totalLeads : 0;
            const avgCpql = sumQual > 0 ? totalSpend / sumQual : 0;
            const avgCpsv = sumWalk > 0 ? totalSpend / sumWalk : 0;

            const tabsContainer = document.getElementById('tabs-container');
            if (tabsContainer) {
                tabsContainer.innerHTML = TABS.map(t => `<button class="tab-btn" onclick="handleTabChange('${t.id}')" style="padding: 14px 16px; display: flex; align-items: center; gap: 6px; color: ${state.activeTab === t.id ? C.accent : C.textDim}; border-bottom: ${state.activeTab === t.id ? `2px solid ${C.accent}` : '2px solid transparent'}; font-size: 12.5px; font-family: 'Sora'; font-weight: ${state.activeTab === t.id ? 600 : 400};"><span>${t.icon}</span>${t.label}</button>`).join('');
            }

            const container = document.getElementById('tab-content-container');
            if (!container) return;

            // 1. EXECUTIVE SUMMARY TAB
            if (state.activeTab === "executive") {
                container.innerHTML = `
          <div style="display: flex; flex-direction: column; gap: 24px;" class="animate-in">
            <div style="background: linear-gradient(135deg, ${C.card} 0%, ${C.mode === 'light' ? '#EAF0F8' : '#17223b'} 100%); border: 1px solid ${C.border}; border-radius: 16px; padding: 24px 28px; display: flex; justify-content: space-between; align-items: center;">
              <div>
                <div style="color: ${C.accent}; font-size: 11px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.1em; margin-bottom: 6px;">Active Google Search Portfolio</div>
                <div style="color: ${C.textDim}; font-size: 13px; margin-top: 4px;">Reporting: ${state.dateRange}</div>
              </div>
            </div>
            <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(180px, 1fr)); gap: 14px; margin-bottom: 24px;">
              ${renderKpiCardHTML("Total Spend", fmtSpend(totalSpend), "Live Ad Spend", null, totalSpend > 10000 ? "good" : "warn")}
              ${renderKpiCardHTML("Total Leads", fmtN(totalLeads), `${state.campaigns.length} Active Camps`, null, totalLeads > 0 ? "good" : "warn")}
              ${renderKpiCardHTML("Average CPL", fmtCPL(avgCPL), "Portfolio CPL", null, avgCPL > 0 ? "good" : "warn")}
              ${renderKpiCardHTML("Qualified Leads", fmtN(sumQual), `${state.filteredCampaigns.length} Active Camps`, null, sumQual > 0 ? "good" : "warn")}
${renderKpiCardHTML("CPQL", sumQual > 0 ? fmtCPL(avgCpql) : "₹0.00", "Cost Per Qualified Lead", null, sumQual > 0 ? (avgCpql < 1500 ? "good" : "warn") : null)}
${renderKpiCardHTML("Site Visits", fmtN(sumWalk), "Walk-ins / Site Visits", null, sumWalk > 0 ? "good" : "warn")}
${renderKpiCardHTML("CPSV", sumWalk > 0 ? fmtCPL(avgCpsv) : "₹0.00", "Cost Per Site Visit", null, sumWalk > 0 ? (avgCpsv < 3000 ? "good" : "warn") : null)}
            </div>
            <div style="display: grid; grid-template-columns: 1fr; gap: 20px; margin-bottom: 24px;">
              <div style="background: ${C.card}; border: 1px solid ${C.border}; border-radius: 12px; padding: 20px;">
                <div style="color: ${C.text}; font-weight: 600; font-size: 14px; margin-bottom: 16px;">Portfolio Spend Distribution</div>
                <div id="spend-pie-chart"></div>
              </div>
            </div>
          </div>
        `;

                if (state.filteredCampaigns.length > 0) {
                    renderChart("spend-pie-chart", "donut", {
                        chart: {
                            type: 'donut',
                            height: 250,
                            background: 'transparent',
                            foreColor: C.textDim,
                            fontFamily: 'Sora, sans-serif'
                        },
                        series: state.filteredCampaigns.map(c => c.spend),
                        labels: state.filteredCampaigns.map(c => c.campaign),
                        colors: state.filteredCampaigns.map((_, i) => PIE_COLORS[i % PIE_COLORS.length]),
                        stroke: {
                            show: false
                        },
                        plotOptions: {
                            pie: {
                                donut: {
                                    size: '60%',
                                    labels: {
                                        show: true,
                                        name: {
                                            show: true
                                        },
                                        value: {
                                            show: true,
                                            formatter: v => fmt(v)
                                        }
                                    }
                                }
                            }
                        }
                    });
                }
            }


            if (state.activeTab === "campaigns") {
                let headerTitle = "Campaign Performance Analysis";
                let headerSubtitle = "Live Google Ads API campaigns";
                let nameColHeader = "Campaign";
                let showBackButton = false;

                if (state.campaignsViewLevel === 'adset') {
                    headerTitle = `Adsets for "${state.selectedCampaignName}"`;
                    headerSubtitle = `Active Google Ads API adgroups inside this campaign`;
                    nameColHeader = "Adset Name";
                    showBackButton = true;
                } else if (state.campaignsViewLevel === 'ad') {
                    headerTitle = `Ads for "${state.selectedAdsetName}"`;
                    headerSubtitle = `Campaign: ${state.selectedCampaignName} &nbsp;&gt;&nbsp; Adset: ${state.selectedAdsetName}`;
                    nameColHeader = "Ad Name";
                    showBackButton = true;
                }

                container.innerHTML = `
                  <div style="display:flex;flex-direction:column;gap:24px;" class="animate-in">
                    <div style="margin-bottom:20px;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:16px;position:relative;z-index:9999;">
                      <div style="display:flex;align-items:center;gap:14px;flex-wrap:wrap;">
                        ${showBackButton ? `
                          <button onclick="handleBack()" style="display:inline-flex; align-items:center; gap:7px; background:linear-gradient(135deg, var(--pq-card), var(--pq-border)); color:#3B82F6; border:1px solid #2B3A5A; border-radius:8px; padding:8px 16px; font-size:12.5px; font-weight:600; cursor:pointer; font-family:'Sora',sans-serif; transition:all 0.2s ease; box-shadow:0 2px 8px rgba(0,0,0,0.25);" onmouseover="this.style.background='var(--pq-border)'; this.style.borderColor='#3B82F6'; this.style.transform='translateY(-1px)';" onmouseout="this.style.background='linear-gradient(135deg, var(--pq-card), var(--pq-border))'; this.style.borderColor='#2B3A5A'; this.style.transform='none';">
                            <span style="font-size:16px; font-weight:700; line-height:1;">‹</span> ${state.campaignsViewLevel === 'ad' ? 'Back to Adsets' : 'Back to Campaigns'}
                          </button>
                        ` : ''}
                        <div>
                          <div style="color:${C.text};font-size:18px;font-weight:700;">${headerTitle}</div>
                          <div style="color:${C.textDim};font-size:12.5px;margin-top:4px;">${headerSubtitle}</div>
                        </div>
                      </div>
                      <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;">
                        ${!showBackButton ? `
                          <div style="display:flex;align-items:center;background:var(--pq-card);border:1px solid var(--pq-border);border-radius:8px;overflow:hidden;">
                            <input id="campaign-name-input" type="text" placeholder="Enter Campaign Name…" style="background:transparent;border:none;color:var(--pq-text);padding:9px 14px;outline:none;width:380px;"/>
                            <button onclick="handleAddCampaignName()" style="background:#3B82F6;color:#fff;border:none;padding:9px 16px;cursor:pointer;font-weight:600;font-family:'Sora';">＋ ADD</button>
                          </div>
                        ` : ''}
                        <div id="export-dropdown-wrap" style="position:relative; display:inline-block; z-index:9999;">
                          <button id="export-dropdown-btn" onclick="toggleExportDropdown(event)" style="background:${C.accent}; color:var(--pq-bg); border:none; padding:10px 16px; border-radius:8px; cursor:pointer; font-size:12px; font-weight:600; display:flex; align-items:center; gap:6px; font-family:'Sora'; white-space:nowrap;"> 📥 Export <span style="font-size:9px; margin-left:2px;">⮟</span> </button>
                          <div class="export-dropdown-menu-list" id="export-dropdown-menu-google" style="display:none; position:absolute; top:calc(100% + 6px); right:0; background:var(--pq-card); border:1px solid #2d3148; border-radius:8px; min-width:210px; box-shadow:0 10px 28px rgba(0,0,0,0.45); z-index:99999; overflow:hidden;">
                            <button onclick="closeExportDropdown(); exportCampaignsToExcel('campaign')" style="width:100%; text-align:left; background:none; border:none; color:var(--pq-text); padding:11px 14px; font-size:12px; font-family:'Sora'; cursor:pointer; display:flex; align-items:center; gap:8px;" onmouseover="this.style.background='var(--pq-border)'" onmouseout="this.style.background='none'"> 📥 Export Campaign Report </button>
                            <button onclick="closeExportDropdown(); exportPivotReport()" style="width:100%; text-align:left; background:none; border:none; color:var(--pq-text); padding:11px 14px; font-size:12px; font-family:'Sora'; cursor:pointer; display:flex; align-items:center; gap:8px; border-top:1px solid #2d3148;" onmouseover="this.style.background='var(--pq-border)'" onmouseout="this.style.background='none'"> 📊 Export Analysis Report </button>
                            <button onclick="closeExportDropdown(); exportPortfolioPDF()" style="width:100%; text-align:left; background:none; border:none; color:var(--pq-text); padding:11px 14px; font-size:12px; font-family:'Sora'; cursor:pointer; display:flex; align-items:center; gap:8px; border-top:1px solid #2d3148;" onmouseover="this.style.background='var(--pq-border)'" onmouseout="this.style.background='none'"> 🧾 Export PDF (Meta + Google) </button>
                        
                            <button onclick="closeExportDropdown(); openGooglePerformanceReport('daily')" style="width:100%; text-align:left; background:none; border:none; color:var(--pq-text); padding:11px 14px; font-size:12px; font-family:'Sora'; cursor:pointer; display:flex; align-items:center; gap:8px; border-top:1px solid #2d3148;" onmouseover="this.style.background='var(--pq-border)'" onmouseout="this.style.background='none'"> 📅 Daily Report (vs previous day) </button>
                            <button onclick="closeExportDropdown(); openGooglePerformanceReport('weekly')" style="width:100%; text-align:left; background:none; border:none; color:var(--pq-text); padding:11px 14px; font-size:12px; font-family:'Sora'; cursor:pointer; display:flex; align-items:center; gap:8px; border-top:1px solid #2d3148;" onmouseover="this.style.background='var(--pq-border)'" onmouseout="this.style.background='none'"> 🗓️ Weekly Report (vs last week) </button>
                            <button onclick="closeExportDropdown(); openGooglePerformanceReport('monthly')" style="width:100%; text-align:left; background:none; border:none; color:var(--pq-text); padding:11px 14px; font-size:12px; font-family:'Sora'; cursor:pointer; display:flex; align-items:center; gap:8px; border-top:1px solid #2d3148;" onmouseover="this.style.background='var(--pq-border)'" onmouseout="this.style.background='none'"> 📆 Monthly Report (vs last month) </button>
                            <button onclick="closeExportDropdown(); exportGoogleMonthlyDeck()" style="width:100%; text-align:left; background:none; border:none; color:var(--pq-text); padding:11px 14px; font-size:12px; font-family:'Sora'; cursor:pointer; display:flex; align-items:center; gap:8px; border-top:1px solid #2d3148;" onmouseover="this.style.background='var(--pq-border)'" onmouseout="this.style.background='none'"> 🖼️ Monthly Deck — last month (PDF) </button>
<button onclick="closeExportDropdown(); exportGoogleMonthToDateDeck()" style="width:100%; text-align:left; background:none; border:none; color:var(--pq-text); padding:11px 14px; font-size:12px; font-family:'Sora'; cursor:pointer; display:flex; align-items:center; gap:8px; border-top:1px solid #2d3148;" onmouseover="this.style.background='var(--pq-border)'" onmouseout="this.style.background='none'"> 🖼️ Monthly Deck — this month to date (PDF) </button>
                    
                          </div>
                        </div>
                        <button onclick="openUnmapped()" style="background:#1a1d27;color:#fff;border:1px solid #2d3148;padding:8px 16px;border-radius:8px;cursor:pointer;font-size:13px;font-weight:600;display:flex;align-items:center;gap:8px;">
                          Unmapped Leads <span id="unmappedBadge" style="background:#e53e3e;color:#fff;border-radius:10px;padding:2px 8px;font-size:11px;">${window.unmappedLeadsCount}</span>
                        </button>
                        <button onclick="ProjectSync.open()" title="Choose which Google campaigns belong to this project"
                          style="background:var(--pq-card);color:var(--pq-text);border:1px solid var(--pq-border);padding:8px 16px;border-radius:8px;cursor:pointer;font-size:13px;font-weight:600;display:flex;align-items:center;gap:8px;">
                          ⟳ Sync with Google
                        </button>
                      </div>
                    </div>

                    <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px;">
                      <div style="display:flex;align-items:center;gap:8px;">
                        <span style="color:${C.textDim};font-size:11px;">Show</span>
                        <select onchange="dtSetPageSize(+this.value)" style="background:var(--pq-card);color:var(--pq-text);border:1px solid var(--pq-border);border-radius:6px;padding:5px 8px;font-size:11px;outline:none;cursor:pointer;">
                          <option value="5" ${state.dtPageSize === 5 ? 'selected' : ''}>5</option>
                          <option value="10" ${state.dtPageSize === 10 ? 'selected' : ''}>10</option>
                          <option value="25" ${state.dtPageSize === 25 ? 'selected' : ''}>25</option>
                          <option value="50" ${state.dtPageSize === 50 ? 'selected' : ''}>50</option>
                          <option value="-1" ${state.dtPageSize === -1 ? 'selected' : ''}>All</option>
                        </select>
                        <span style="color:${C.textDim};font-size:11px;">entries</span>
                      </div>
                      <span id="pq-cols-host-google"></span>
                    </div>

                    <div style="background:${C.card};border:1px solid ${C.border};border-radius:12px;overflow:auto;max-height:55vh;position:relative;z-index:1;">
                      <table id="camps-table" style="width:100%; border-collapse:separate; border-spacing:0; white-space:nowrap;">
                        <thead style="position:sticky; top:0; background:var(--pq-surface); z-index:11; box-shadow:0 1px 0 var(--pq-border);"><tr>
                          <th data-col="status" onclick="dtSort('status')">Status<span class="sort-icon"></span></th>
                          <th data-col="campaign" onclick="dtSort('campaign')">${nameColHeader}<span class="sort-icon"></span></th>
                          <th>Channel</th>
                          <th data-col="spend" onclick="dtSort('spend')">Spend<span class="sort-icon"></span></th>
                          <th data-col="impressions" onclick="dtSort('impressions')">Impressions<span class="sort-icon"></span></th>
                          <th data-col="clicks" onclick="dtSort('clicks')">Clicks<span class="sort-icon"></span></th>
                          <th data-col="ctr" onclick="dtSort('ctr')">CTR<span class="sort-icon"></span></th>
                          <th data-col="cpm" onclick="dtSort('cpm')">CPM<span class="sort-icon"></span></th>
                          <th data-col="leads" onclick="dtSort('leads')">Leads<span class="sort-icon"></span></th>
                          <th data-col="cpl" onclick="dtSort('cpl')">CPL<span class="sort-icon"></span></th>
                          <th data-col="qualified" onclick="dtSort('qualified')" style="color:${C.blue};">Qualified Leads<span class="sort-icon"></span></th>
                          <th data-col="cpql" onclick="dtSort('cpql')" style="color:${C.blue};">CPQL<span class="sort-icon"></span></th>
                          <th data-col="walkins" onclick="dtSort('walkins')" style="color:${C.green};">Site Visits<span class="sort-icon"></span></th>
                          <th data-col="cpsv" onclick="dtSort('cpsv')" style="color:${C.green};">CPSV<span class="sort-icon"></span></th>
                        </tr></thead>
                        <tbody id="dt-body"></tbody>
                        <tfoot id="dt-foot" style="position:sticky; bottom:0; z-index:10; box-shadow:0 -1px 0 var(--pq-border); backdrop-filter: blur(45px);"></tfoot>
                      </table>
                    </div>

                    <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px;margin:14px 0;">
                      <span id="dt-info" style="color:${C.textDim};font-size:11px;"></span>
                      <div id="dt-pagination" style="display:flex;align-items:center;gap:4px;flex-wrap:wrap;"></div>
                    </div>

                    <div style="background:${C.card};border:1px solid ${C.border};border-radius:12px;padding:20px;">
                      <div style="color:${C.text};font-weight:600;font-size:14px;margin-bottom:16px;">Cost Per Lead (CPL) Comparison</div>
                      <div id="cpl-comparison-chart"></div>
                    </div>
                  </div>
                `;

                state.dtSearch = '';
                state.dtPage = 1;
                renderCampaignsTable();
                loadUnmappedCount();

                if (state.filteredCampaigns.length > 0) {
                    renderChart("cpl-comparison-chart", "bar", {
                        chart: {
                            type: 'bar',
                            height: 240,
                            background: 'transparent',
                            foreColor: C.textDim,
                            fontFamily: 'Sora, sans-serif',
                            toolbar: {
                                show: false
                            }
                        },
                        series: [{
                            name: 'CPL (₹)',
                            data: state.filteredCampaigns.map(c => c.cpl)
                        }],
                        xaxis: {
                            categories: state.filteredCampaigns.map(c => c.campaign),
                            labels: {
                                rotate: -45,
                                trim: true,
                                style: {
                                    fontSize: '9px'
                                }
                            }
                        },
                        colors: state.filteredCampaigns.map(c => c.status === "good" ? C.green : C.yellow),
                        plotOptions: {
                            bar: {
                                distributed: true,
                                borderRadius: 4,
                                columnWidth: '50%'
                            }
                        },
                        legend: {
                            show: false
                        },
                        grid: {
                            borderColor: C.border
                        }
                    });
                }
            }
            window.exportCampaignsToExcel = async (type = 'campaign') => {
                const level = (typeof type === 'string' && type !== 'campaign' && type !== 'analysis') ? type : (state.campaignsViewLevel || 'campaign');
                let dataList = state.filteredCampaigns;
                let nameHeader = 'Campaign';
                let pickCount = 0;

                if (level === 'adset') {
                    dataList = state.adsets || [];
                    nameHeader = 'Adset Name';
                } else if (level === 'ad') {
                    dataList = state.ads || [];
                    nameHeader = 'Ad Name';
                }

                // "All campaigns or select campaigns?" (js/report_picker.js) — campaign level only
                if (level !== 'adset' && level !== 'ad' && typeof window.pqPickCampaigns === 'function') {
                    const pick = await window.pqPickCampaigns('google', 'Google campaign report');
                    if (pick === false) return;
                    if (pick) {
                        dataList = (dataList || []).filter(c => PQReportPicker.has(pick, 'google', c.campaign_id || c.utm_campaignid || c.id, c.campaign || c.name));
                        pickCount = pick.count;
                    }
                }

                if (!dataList || !dataList.length) {
                    alert('No campaign data to export.');
                    return;
                }

                const rows = dataList.map(c => ({
                    'Campaign': c.campaign || c.name || '',
                    'Channel': c.platform || 'Google',
                    'Spend (₹)': Number(c.spend) || 0,
                    'Impressions': Number(c.impressions) || 0,
                    'Clicks': Number(c.clicks) || 0,
                    'CTR (%)': Number(c.ctr) || 0,
                    'CPM (₹)': Number(c.cpm) || 0,
                    'Frequency': Number(c.frequency) || 0,
                    'Leads': Number(c.leads) || 0,
                    'CPL (₹)': Number(c.cpl) || 0,
                    'Qualified Leads': Number(c.qualified) || 0,
                    'CPQL (₹)': Number(c.cpql) || 0,
                    'Site Visits': Number(c.walkins) || 0,
                    'CPSV (₹)': Number(c.cpsv) || 0,
                }));

                // Totals row
                const tSpend = dataList.reduce((a, c) => a + (Number(c.spend) || 0), 0);
                const tImpr = dataList.reduce((a, c) => a + (Number(c.impressions) || 0), 0);
                const tClicks = dataList.reduce((a, c) => a + (Number(c.clicks) || 0), 0);
                const tLeads = typeof getUniqueLeads === 'function' && level === 'campaign' ? getUniqueLeads(dataList, 'leads_data').length : dataList.reduce((a, c) => a + (Number(c.leads) || 0), 0);
                const tQual = typeof getUniqueLeads === 'function' && level === 'campaign' ? getUniqueLeads(dataList, 'qualified_leads').length : dataList.reduce((a, c) => a + (Number(c.qualified) || 0), 0);
                const tWalkins = typeof getUniqueLeads === 'function' && level === 'campaign' ? getUniqueLeads(dataList, 'walkin_leads').length : dataList.reduce((a, c) => a + (Number(c.walkins) || 0), 0);
                rows.push({
                    'Campaign': 'TOTAL',
                    'Channel': '',
                    'Spend (₹)': tSpend,
                    'Impressions': tImpr,
                    'Clicks': tClicks,
                    'CTR (%)': tImpr > 0 ? +((tClicks / tImpr) * 100).toFixed(2) : '',
                    'CPM (₹)': tImpr > 0 ? +((tSpend / tImpr) * 1000).toFixed(2) : '',
                    'Frequency': dataList.length > 0 ? (dataList.reduce((a, c) => a + (Number(c.frequency) || 0), 0) / dataList.length).toFixed(2) : '',
                    'Leads': tLeads,
                    'CPL (₹)': tLeads > 0 ? +(tSpend / tLeads).toFixed(2) : 0,
                    'Qualified Leads': tQual,
                    'CPQL (₹)': tQual > 0 ? +(tSpend / tQual).toFixed(2) : 0,
                    'Site Visits': tWalkins,
                    'CPSV (₹)': tWalkins > 0 ? +(tSpend / tWalkins).toFixed(2) : 0,
                });

                const wsData = [];
                wsData.push([
                    nameHeader,
                    'Channel',
                    'Spend (₹)',
                    'Impressions',
                    'Clicks',
                    'CTR (%)',
                    'CPM (₹)',
                    'Frequency',
                    'Leads',
                    'CPL (₹)',
                    'Qualified Leads',
                    'CPQL (₹)',
                    'Site Visits',
                    'CPSV (₹)'
                ]);
                rows.forEach(r => {
                    wsData.push([
                        r['Campaign'],
                        r['Channel'],
                        parseFloat((Number(r['Spend (₹)']) || 0).toFixed(2)),
                        Number(r['Impressions']) || 0,
                        Number(r['Clicks']) || 0,
                        parseFloat((Number(r['CTR (%)']) || 0).toFixed(2)),
                        parseFloat((Number(r['CPM (₹)']) || 0).toFixed(2)),
                        parseFloat((Number(r['Frequency']) || 0).toFixed(2)),
                        Number(r['Leads']) || 0,
                        r['Leads'] > 0 ? parseFloat((Number(r['Spend (₹)']) / Number(r['Leads'])).toFixed(2)) : 0,
                        r['Qualified Leads'] > 0 ? r['Qualified Leads'] : '—',
                        r['Qualified Leads'] > 0 && r['Spend (₹)'] > 0 ? parseFloat((Number(r['Spend (₹)']) / Number(r['Qualified Leads'])).toFixed(2)) : '—',
                        Number(r['Site Visits']) > 0 ? Number(r['Site Visits']) : '—',
                        Number(r['Site Visits']) > 0 && Number(r['Spend (₹)']) > 0 ? parseFloat((Number(r['Spend (₹)']) / Number(r['Site Visits'])).toFixed(2)) : '—'
                    ]);
                });
                const ws = XLSX.utils.aoa_to_sheet(wsData);
                const totalRowIndex = wsData.length;
                ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N'].forEach(col => {
                    const ref = `${col}${totalRowIndex}`;
                    if (ws[ref]) ws[ref].s = {font: {bold: true}};
                });
                ws['!cols'] = [
                    {wch: 44}, {wch: 10}, {wch: 14}, {wch: 14}, {wch: 10},
                    {wch: 8}, {wch: 10}, {wch: 10}, {wch: 8}, {wch: 12},
                    {wch: 16}, {wch: 12}, {wch: 12}, {wch: 12}
                ];
                // Remove invalid row 0 merge that merged all header columns into A1
                const wb = XLSX.utils.book_new();
                XLSX.utils.book_append_sheet(wb, ws, 'Campaigns');
                const filePrefix = (type === 'analysis' ? 'PerfomIQ_Google_Analysis_Report_' : 'PerfomIQ_Google_Campaign_Report_') + (pickCount ? pickCount + '_campaigns_' : '');
                XLSX.writeFile(wb, `${filePrefix}${(state.dateRange || 'export').replace(/\s/g, '_')}.xlsx`);
            };

            window.exportPivotReport = async () => {
                // "All campaigns or select campaigns?" (js/report_picker.js)
                const pick = typeof window.pqPickCampaigns === 'function' ? await window.pqPickCampaigns('google', 'Google analysis report') : null;
                if (pick === false) return;
                const btn = document.getElementById('export-dropdown-btn');
                const originalLabel = btn ? btn.innerHTML : '';
                if (btn) {
                    btn.disabled = true;
                    btn.innerHTML = '⏳ Building report…';
                }

                try {
                    const params = new URLSearchParams();
                    params.set('action', 'fetch_pivot_report');
                    if (state.sinceDateStr && state.untilDateStr) {
                        params.set('since', state.sinceDateStr);
                        params.set('until', state.untilDateStr);
                    } else if (state.selectedPreset) {
                        params.set('preset', state.selectedPreset);
                    }
                    if (state.statusFilter) {
                        params.set('status_filter', state.statusFilter);
                    }

                    const res = await fetch(`googleapi.php?${params.toString()}`);
                    if (!res.ok) throw new Error(`HTTP Error: ${res.status}`);
                    const data = await res.json();
                    if (!data.success) {
                        throw new Error((data.error && data.error.message) || 'Failed to load status report.');
                    }
                    if (pick && data.rows) data.rows = data.rows.filter(r => PQReportPicker.has(pick, 'google', r.campaign_id || r.utm_campaignid, r.campaign_name));
                    if (!data.rows || !data.rows.length) {
                        alert('No data to export for this date range.');
                        return;
                    }

                    const roundInt = (n) => Math.round(n);
                    const round2 = (n) => Math.round(n * 100) / 100;
                    const blankIfZero = (n) => (n ? n : '');

                    const calcRow = (r) => {
                        const grandTotal = r.in_qualified + r.lost_post_qualified + r.non_qualified + r.to_be_qualified;
                        const qualBase = r.in_qualified + r.lost_post_qualified;
                        const impressions = Number(r.impressions) || 0;
                        const clicks = Number(r.clicks) || 0;
                        return {
                            ...r,
                            grandTotal,
                            ctr: impressions > 0 ? round2((clicks / impressions) * 100) : '',
                            cpm: impressions > 0 ? round2((r.spend / impressions) * 1000) : '',
                            frequency: round2(r.frequency || 0),
                            ql: grandTotal > 0 ? round2((r.in_qualified + r.lost_post_qualified) / grandTotal) : '',
                            nq: grandTotal > 0 ? round2(r.non_qualified / grandTotal) : '',
                            tbq: grandTotal > 0 ? round2(r.to_be_qualified / grandTotal) : '',
                            cpl: grandTotal > 0 ? roundInt(r.spend / grandTotal) : '',
                            cpql: qualBase > 0 ? roundInt(r.spend / qualBase) : '',
                        };
                    };

                    const campaignMap = new Map();
                    const campaignNameCasing = new Map();
                    const adsetNameCasing = new Map();
                    data.rows.forEach(r => {
                        const rawCName = r.campaign_name || 'Unknown';
                        const rawAName = r.adset_name || 'Unknown';
                        const cKey = rawCName.toLowerCase().trim();
                        const aKey = rawAName.toLowerCase().trim();

                        if (!campaignNameCasing.has(cKey) || (rawCName !== rawCName.toLowerCase() && campaignNameCasing.get(cKey) === campaignNameCasing.get(cKey).toLowerCase())) {
                            campaignNameCasing.set(cKey, rawCName.trim());
                        }
                        const combinedKey = cKey + '|' + aKey;
                        if (!adsetNameCasing.has(combinedKey) || (rawAName !== rawAName.toLowerCase() && adsetNameCasing.get(combinedKey) === adsetNameCasing.get(combinedKey).toLowerCase())) {
                            adsetNameCasing.set(combinedKey, rawAName.trim());
                        }

                        const cName = campaignNameCasing.get(cKey);
                        const aName = adsetNameCasing.get(combinedKey);

                        if (!campaignMap.has(cName)) campaignMap.set(cName, new Map());
                        const adsetMap = campaignMap.get(cName);
                        if (!adsetMap.has(aName)) adsetMap.set(aName, []);
                        adsetMap.get(aName).push(r);
                    });

                    const wsData = [[
                        'Campaign Name', 'Ad Set Name', 'Ad Name', 'Spends',
                        'Impressions', 'Clicks', 'CTR (%)', 'CPM (₹)', 'Frequency',
                        'IN-QUALIFIED', 'LOST POST QUALIFIED', 'NON-QUALIFIED', 'TO BE QUALIFIED',
                        'Grand Total', 'QL %', 'NQ %', 'TBQ %', 'CPL', 'CPQL'
                    ]];
                    const merges = [];
                    const percentCells = [];

                    const sumRows = (rows) => rows.reduce((a, r) => ({
                        spend: a.spend + r.spend,
                        impressions: a.impressions + (Number(r.impressions) || 0),
                        clicks: a.clicks + (Number(r.clicks) || 0),
                        in_qualified: a.in_qualified + r.in_qualified,
                        lost_post_qualified: a.lost_post_qualified + r.lost_post_qualified,
                        non_qualified: a.non_qualified + r.non_qualified,
                        to_be_qualified: a.to_be_qualified + r.to_be_qualified,
                    }), {spend: 0, impressions: 0, clicks: 0, in_qualified: 0, lost_post_qualified: 0, non_qualified: 0, to_be_qualified: 0});

                    const pushDataRow = (campaignCell, adsetCell, r) => {
                        const c = calcRow(r);
                        const rowIdx = wsData.length;
                        wsData.push([
                            campaignCell, adsetCell, r.ad_name,
                            round2(r.spend),
                            Number(r.impressions) || 0, Number(r.clicks) || 0, c.ctr, c.cpm, c.frequency,
                            blankIfZero(r.in_qualified), blankIfZero(r.lost_post_qualified),
                            blankIfZero(r.non_qualified), blankIfZero(r.to_be_qualified),
                            blankIfZero(c.grandTotal),
                            c.ql, c.nq, c.tbq, c.cpl, c.cpql,
                        ]);
                        if (c.ql !== '') {percentCells.push({r: rowIdx, c: 14}, {r: rowIdx, c: 15}, {r: rowIdx, c: 16});}
                        return rowIdx;
                    };

                    const pushTotalRow = (labelCol, label, totals) => {
                        const c = calcRow(totals);
                        const rowIdx = wsData.length;
                        const row = new Array(19).fill('');
                        row[labelCol] = label;
                        row[3] = round2(totals.spend);
                        row[4] = totals.impressions;
                        row[5] = totals.clicks;
                        row[6] = c.ctr;
                        row[7] = c.cpm;
                        row[8] = c.frequency;
                        row[9] = blankIfZero(totals.in_qualified);
                        row[10] = blankIfZero(totals.lost_post_qualified);
                        row[11] = blankIfZero(totals.non_qualified);
                        row[12] = blankIfZero(totals.to_be_qualified);
                        row[13] = blankIfZero(c.grandTotal);
                        row[14] = c.ql; row[15] = c.nq; row[16] = c.tbq;
                        row[17] = c.cpl; row[18] = c.cpql;
                        wsData.push(row);
                        if (c.ql !== '') {percentCells.push({r: rowIdx, c: 14}, {r: rowIdx, c: 15}, {r: rowIdx, c: 16});}
                        return rowIdx;
                    };

                    const grandRows = [];
                    campaignMap.forEach((adsetMap, campaignName) => {
                        const campaignBlockStart = wsData.length;
                        const campaignRows = [];
                        let firstRowOfCampaign = true;

                        adsetMap.forEach((adRows, adsetName) => {
                            const adsetBlockStart = wsData.length;
                            adRows.forEach(r => {
                                pushDataRow(firstRowOfCampaign ? campaignName : '', wsData.length === adsetBlockStart ? adsetName : '', r);
                                firstRowOfCampaign = false;
                            });
                            const adsetBlockEnd = wsData.length - 1;
                            if (adsetBlockEnd > adsetBlockStart) {
                                merges.push({s: {r: adsetBlockStart, c: 1}, e: {r: adsetBlockEnd, c: 1}});
                            }
                            const adsetTotals = sumRows(adRows);
                            const totalRowIdx = pushTotalRow(1, `${adsetName} Total`, adsetTotals);
                            merges.push({s: {r: totalRowIdx, c: 1}, e: {r: totalRowIdx, c: 2}});
                            campaignRows.push(...adRows);
                        });

                        const campaignBlockEnd = wsData.length - 1;
                        if (campaignBlockEnd > campaignBlockStart) {
                            merges.push({s: {r: campaignBlockStart, c: 0}, e: {r: campaignBlockEnd, c: 0}});
                        }
                        const campaignTotals = sumRows(campaignRows);
                        const totalRowIdx = pushTotalRow(0, `${campaignName} Total`, campaignTotals);
                        merges.push({s: {r: totalRowIdx, c: 0}, e: {r: totalRowIdx, c: 2}});
                        grandRows.push(...campaignRows);
                    });

                    const grandTotals = sumRows(grandRows);
                    const grandRowIdx = pushTotalRow(0, 'Grand Total', grandTotals);
                    merges.push({s: {r: grandRowIdx, c: 0}, e: {r: grandRowIdx, c: 2}});

                    const ws = XLSX.utils.aoa_to_sheet(wsData);
                    ws['!merges'] = merges;
                    ws['!cols'] = [
                        {wch: 32}, {wch: 28}, {wch: 34}, {wch: 12},
                        {wch: 12}, {wch: 9}, {wch: 8}, {wch: 10}, {wch: 10},
                        {wch: 13}, {wch: 18}, {wch: 14}, {wch: 15},
                        {wch: 12}, {wch: 8}, {wch: 8}, {wch: 8},
                        {wch: 10}, {wch: 10},
                    ];
                    for (let r = 1; r < wsData.length; r++) {
                        const spendRef = XLSX.utils.encode_cell({r, c: 3});
                        if (ws[spendRef]) ws[spendRef].z = '#,##0';
                        const impRef = XLSX.utils.encode_cell({r, c: 4});
                        if (ws[impRef]) ws[impRef].z = '#,##0';
                        const clicksRef = XLSX.utils.encode_cell({r, c: 5});
                        if (ws[clicksRef]) ws[clicksRef].z = '#,##0';
                        const cpmRef = XLSX.utils.encode_cell({r, c: 7});
                        if (ws[cpmRef]) ws[cpmRef].z = '#,##0.00';
                        const freqRef = XLSX.utils.encode_cell({r, c: 8});
                        if (ws[freqRef]) ws[freqRef].z = '#,##0.00';
                    }
                    percentCells.forEach(({r, c}) => {
                        const ref = XLSX.utils.encode_cell({r, c});
                        if (ws[ref]) ws[ref].z = '0%';
                    });
                    const boldRows = new Set([0]);
                    wsData.forEach((row, idx) => {
                        if (idx > 0 && typeof row[0] === 'string' && row[0].endsWith(' Total')) boldRows.add(idx);
                        if (idx > 0 && typeof row[1] === 'string' && row[1].endsWith(' Total')) boldRows.add(idx);
                        if (idx > 0 && row[0] === 'Grand Total') boldRows.add(idx);
                    });

                    const thinBorder = {style: 'thin', color: {rgb: '000000'}};
                    const borderStyle = {top: thinBorder, bottom: thinBorder, left: thinBorder, right: thinBorder};

                    const HEADER_FILL = 'ADD8E6';
                    const TOTAL_ROW_FILL = 'BFBFBF';
                    const QL_GRAY = 'D9D9D9';
                    const QL_RED = 'FFC7CE';
                    const QL_GREEN = 'C6EFCE';
                    const QL_YELLOW = 'FFEB9C';
                    const qlFillColor = (val) => {
                        if (val === '' || val === undefined || val === null) return null;
                        const pct = Math.round(val * 100);
                        if (pct <= 0) return QL_GRAY;
                        if (pct >= 1 && pct <= 19) return QL_RED;
                        if (pct >= 100) return QL_YELLOW;
                        return QL_GREEN;
                    };
                    const QL_COL = 14;

                    const NAME_COL_FILLS = {
                        0: '5B9BD5',
                        1: '9DC3E6',
                        2: 'D6E4F0',
                    };
                    const NAME_COL_FONT = {0: {color: {rgb: 'FFFFFF'}}};

                    for (let r = 0; r < wsData.length; r++) {
                        for (let c = 0; c < 19; c++) {
                            const ref = XLSX.utils.encode_cell({r, c});
                            if (!ws[ref]) ws[ref] = {t: 's', v: ''};
                            const isBold = boldRows.has(r);

                            let fill;
                            const NO_FILL_COLS = new Set([15, 16, 17, 18]);
                            if (r === 0) {
                                fill = {patternType: 'solid', fgColor: {rgb: HEADER_FILL}, bgColor: {rgb: HEADER_FILL}};
                            } else if (c === QL_COL) {
                                const qlColor = qlFillColor(wsData[r][QL_COL]);
                                if (qlColor) fill = {patternType: 'solid', fgColor: {rgb: qlColor}, bgColor: {rgb: qlColor}};
                            } else if (NO_FILL_COLS.has(c)) {
                                fill = undefined;
                            } else if (isBold) {
                                fill = {patternType: 'solid', fgColor: {rgb: TOTAL_ROW_FILL}, bgColor: {rgb: TOTAL_ROW_FILL}};
                            } else if (NAME_COL_FILLS[c] !== undefined) {
                                fill = {patternType: 'solid', fgColor: {rgb: NAME_COL_FILLS[c]}, bgColor: {rgb: NAME_COL_FILLS[c]}};
                            }

                            let font;
                            if (r === 0) {
                                font = {bold: true};
                            } else if (isBold) {
                                font = {bold: true};
                            } else if (NAME_COL_FONT[c]) {
                                font = NAME_COL_FONT[c];
                            }

                            ws[ref].s = {
                                border: borderStyle,
                                font: font,
                                fill: fill,
                            };
                        }
                    }

                    const wb = XLSX.utils.book_new();
                    XLSX.utils.book_append_sheet(wb, ws, 'Analysis Report');
                    XLSX.writeFile(wb, `PerfomIQ_Google_Analysis_Report_${(state.dateRange || 'export').replace(/\s/g, '_')}.xlsx`);
                } catch (err) {
                    alert('Export failed: ' + err.message);
                } finally {
                    if (btn) {
                        btn.disabled = false;
                        btn.innerHTML = originalLabel;
                    }
                }
            };

            // 3. FUNNEL TAB
            if (state.activeTab === "funnel") {
                const funnelStagesHTML = state.funnel.map((s, i) => {
                    const w = Math.max(20, 100 - i * 12);
                    return `<div style="margin-bottom:10px;"><div style="display:flex; justify-content:space-between; margin-bottom:4px;"><span style="color:${C.textDim}; font-size:11px;">${s.stage}</span><span style="color:${C.text}; font-size:11px; font-family:'JetBrains Mono';">${fmtN(s.value)} ${i > 0 ? `(${pct(s.pct)} Conversion)` : ``}</span></div><div style="height:32px; background:${C.bg}; border-radius:6px; overflow:hidden;"><div style="height:100%; width:${w}%; background:linear-gradient(90deg, ${C.accent}cc, ${C.accent}66); border-radius:6px; display:flex; align-items:center; padding-left:10px;"><span style="color:${C.bg}; font-size:11px; font-weight:600;">${fmtN(s.value)}</span></div></div></div>`;
                }).join('');

                container.innerHTML = `
          <div style="display: flex; flex-direction: column; gap: 24px;" class="animate-in">
            <div style="margin-bottom: 20px;">
              <div style="color:${C.text}; font-size:18px; font-weight:700;">Portfolio Conversion Funnel</div>
            </div>
            <div style="display:grid; grid-template-columns: 1fr 1fr; gap:20px;">
              <div style="background:${C.card}; border:1px solid ${C.border}; border-radius:12px; padding:20px;">
                <div style="color:${C.text}; font-weight:600; font-size:14px; margin-bottom:20px;">Funnel Stages</div>
                ${funnelStagesHTML}
              </div>
              <div style="display:flex; flex-direction:column; gap:14px;">
                ${renderInsightCardHTML("🔻", "CRM Data Note", [
                    "Qualified Leads and Walk-ins are currently isolated from Google Ads fetch as per system architecture requirements.",
                    "Phase 2 integration will activate the bottom half of this funnel."
                ], C.blue)}
              </div>
            </div>
          </div>
        `;
            }

            // 4. AI INSIGHTS TAB
            if (state.activeTab === "insights") {
                const aiBtnHTML = `
                    <button class="btn" onclick="handleGenerateInsights(event)" style="display:flex; align-items:center; gap:6px; font-size:12px;">
                        🔄 <span id="insights-refresh-text">Regenerate insights</span>
                    </button>
                `;
                const summaryHeaderHTML = `
                    <div style="margin-bottom:20px; display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:12px;">
                      <div>
                        <div style="color:${C.text}; font-size:18px; font-weight:700; letter-spacing:-0.02em;">AI-Generated Portfolio Insights</div>
                        <div style="color:${C.textDim}; font-size:12.5px; margin-top:4px;">AI-powered audit generated from your actual Google Ads campaign performance</div>
                      </div>
                      ${aiBtnHTML}
                    </div>
                `;

                if (!state.insights && !state.loadingInsights) {
                    container.innerHTML = `
            <div style="display: flex; flex-direction: column; gap: 24px;" class="animate-in">
              ${summaryHeaderHTML}
            //   <div style="background:${C.card}; border:2px dashed ${C.border}; border-radius:16px; padding:48px 32px; text-align:center;">
            //     <div style="font-size:40px; margin-bottom:16px;">🤖</div>
            //     <div style="color:${C.text}; font-size:16px; font-weight:600; margin-bottom:8px;">Generate AI-Powered Insights</div>
            //     <button class="btn" onclick="handleGenerateInsights(event)">🤖 Analyze Google Data</button>
            //   </div>
            </div>
          `;
                } else if (state.loadingInsights) {
                    container.innerHTML = `
            <div style="display: flex; flex-direction: column; gap: 24px;" class="animate-in">
              ${summaryHeaderHTML}
              <div style="background:${C.card}; border:1px solid ${C.border}; border-radius:16px; padding:48px 32px; text-align:center;">
                <div class="pulse" style="font-size:40px; margin-bottom:16px;">🤖</div>
                <div style="color:${C.accent}; font-size:15px; font-weight:600;">Analyzing Campaign Portfolio…</div>
              </div>
            </div>
          `;
                } else if (state.insights) {
                    const isAI = state.insights._source === 'ai' && state.insights.overall_account;

                    if (isAI) {
                        const oa = state.insights.overall_account || {};
                        const camps = Array.isArray(state.insights.campaigns) ? state.insights.campaigns : [];

                        const healthColor = (score) => score >= 75 ? C.green : score >= 50 ? C.yellow : C.red;
                        const priorityColor = (p) => (p || '').toLowerCase() === 'high' ? C.red : (p || '').toLowerCase() === 'medium' ? C.yellow : C.green;
                        const renderList = (items) => (Array.isArray(items) && items.length) ?
                            `<ul style="margin:6px 0 0; padding-left:18px; color:${C.textDim}; font-size:12.5px; line-height:1.7;">
                                ${items.map(i => `<li style="margin-bottom:2px;">${i}</li>`).join('')}
                               </ul>` :
                            `<div style="color:${C.textDim}; font-size:12px; font-style:italic;">None noted</div>`;

                        container.innerHTML = `
            <div style="display:flex; flex-direction:column; gap:24px;" class="animate-in">
              ${summaryHeaderHTML}

              <div style="background:linear-gradient(135deg, ${C.accentLo}, ${C.blueLo}); border:1px solid ${C.accent}44; border-radius:14px; padding:24px;">
                <div style="display:flex; align-items:center; justify-content:space-between; gap:16px; flex-wrap:wrap;">
                  <div>
                    <div style="color:${C.accent}; font-size:11px; font-weight:600; text-transform:uppercase; letter-spacing:0.08em; margin-bottom:8px;">★ Overall Account Health</div>
                    <p style="color:${C.text}; font-size:14px; line-height:1.7; margin:0; max-width:640px;">${oa.summary || ''}</p>
                  </div>
                  <div style="text-align:center; flex-shrink:0;">
                    <div style="font-size:32px; font-weight:800; color:${healthColor(oa.health_score || 0)}; font-family:'Sora';">${oa.health_score ?? '—'}</div>
                    <div style="font-size:11px; font-weight:700; color:${healthColor(oa.health_score || 0)}; text-transform:uppercase; letter-spacing:0.05em; margin-top:2px;">${oa.status || ''}</div>
                  </div>
                </div>
              </div>

              <div style="display:flex; flex-direction:column; gap:16px;">
                ${camps.map(c => `
                  <div style="background:${C.card}; border:1px solid ${C.border}; border-radius:14px; padding:20px 24px;">
                    <div style="display:flex; align-items:center; justify-content:space-between; gap:12px; flex-wrap:wrap; margin-bottom:12px;">
                      <div style="display:flex; align-items:center; gap:10px;">
                        <span style="color:${C.text}; font-size:15px; font-weight:700;">${c.campaign_name || 'Unnamed Campaign'}</span>
                        <span style="background:${priorityColor(c.priority)}22; color:${priorityColor(c.priority)}; border:1px solid ${priorityColor(c.priority)}55; font-size:10px; font-weight:700; padding:2px 8px; border-radius:99px; text-transform:uppercase;">${c.priority || ''} priority</span>
                      </div>
                      <div style="display:flex; align-items:center; gap:8px;">
                        <span style="font-size:18px; font-weight:800; color:${healthColor(c.health_score || 0)}; font-family:'Sora';">${c.health_score ?? '—'}</span>
                        <span style="font-size:11px; font-weight:600; color:${healthColor(c.health_score || 0)};">${c.status || ''}</span>
                      </div>
                    </div>

                    ${c.executive_summary ? `<p style="color:${C.text}; font-size:13px; line-height:1.6; margin:0 0 14px;">${c.executive_summary}</p>` : ''}

                    <div style="display:grid; grid-template-columns:repeat(auto-fill,minmax(220px,1fr)); gap:16px;">
                      <div><div style="color:${C.green}; font-size:11px; font-weight:700; text-transform:uppercase; margin-bottom:4px;">🏆 Strengths</div>${renderList(c.strengths)}</div>
                      <div><div style="color:${C.red}; font-size:11px; font-weight:700; text-transform:uppercase; margin-bottom:4px;">⚠️ Weaknesses</div>${renderList(c.weaknesses)}</div>
                      <div><div style="color:${C.yellow}; font-size:11px; font-weight:700; text-transform:uppercase; margin-bottom:4px;">🔍 Root Cause</div>${renderList(c.root_cause)}</div>
                      <div><div style="color:${C.blue}; font-size:11px; font-weight:700; text-transform:uppercase; margin-bottom:4px;">🎨 Creative</div>${renderList(c.creative_recommendations)}</div>
                      <div><div style="color:${C.accent}; font-size:11px; font-weight:700; text-transform:uppercase; margin-bottom:4px;">👥 Audience</div>${renderList(c.audience_recommendations)}</div>
                      <div><div style="color:${C.blue}; font-size:11px; font-weight:700; text-transform:uppercase; margin-bottom:4px;">🖥️ Landing Page</div>${renderList(c.landing_page_recommendations)}</div>
                    </div>

                    ${c.budget_action ? `
                      <div style="margin-top:14px; padding:10px 14px; background:${C.bg}; border:1px solid ${C.border}; border-radius:8px;">
                        <span style="color:${C.accent}; font-size:11px; font-weight:700; text-transform:uppercase; margin-right:8px;">💸 Budget Action</span>
                        <span style="color:${C.text}; font-size:12.5px;">${c.budget_action}</span>
                      </div>
                    ` : ''}
                  </div>
                `).join('')}
              </div>
            </div>
          `;
                    } else {
                        container.innerHTML = `
            <div style="display: flex; flex-direction: column; gap: 24px;" class="animate-in">
              ${summaryHeaderHTML}
              <div style="background:linear-gradient(135deg, ${C.accentLo}, ${C.blueLo}); border:1px solid ${C.accent}44; border-radius:14px; padding:20px 24px;">
                <div style="color:${C.accent}; font-size:11px; font-weight:600; text-transform:uppercase;">★ Executive Summary</div>
                <p style="color:${C.text}; font-size:14px; line-height:1.7; margin:0;">${state.insights.executiveSummary}</p>
              </div>
              <div style="display:grid; grid-template-columns:repeat(auto-fill,minmax(300px,1fr)); gap:16px;">
                ${renderInsightCardHTML("🏆", "Key Wins", state.insights.keyWins, C.green)}
                ${renderInsightCardHTML("🚨", "Major Concerns", state.insights.majorConcerns, C.red)}
                ${renderInsightCardHTML("⚡", "Optimization", state.insights.optimizationOpportunities, C.accent)}
                ${renderInsightCardHTML("✅", "Next Steps", state.insights.actionableNextSteps, C.blue)}
              </div>
            </div>
          `;
                    }
                }
            }
        }

        // ── AJAX API Endpoint Fetcher ──
        window.fetchDashboardData = async () => {
            state.isLoading = true;
            state.ajaxError = null;
            showLoader();

            try {
                const fmt = (date) => `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;

                let since, until;
                if (state.tempPreset === 'custom' && state.tempStartDate && state.tempEndDate) {
                    since = fmt(state.tempStartDate);
                    until = fmt(state.tempEndDate);
                } else {
                    const dates = getPresetDates(state.tempPreset || 'last_30d');
                    since = dates.since;
                    until = dates.until;
                }

                const res = await fetch('googleapi.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        since,
                        until,
                        campaignsstatus: state.filterStatus
                    })
                });
                //const apiParams = new URLSearchParams();
                // const fmt = (date) => `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;

                // if (state.tempPreset === 'custom' && state.tempStartDate && state.tempEndDate) {
                //     apiParams.set('since', fmt(state.tempStartDate));
                //     apiParams.set('until', fmt(state.tempEndDate));
                // } else if (state.tempPreset && state.tempPreset !== 'custom') {
                //     apiParams.set('preset', state.tempPreset);
                // }

                // const apiUrl = `googleapi.php?${apiParams.toString()}`;
                // const res = await fetch(apiUrl);
                if (!res.ok) throw new Error(`HTTP Error: ${res.status}`);

                const data = await res.json();
                state.rawData = data;
                window.__psRange = { since, until };
                ProjectSync.renderBanner(data && data.campaign_filter);
                if (window.PQAwareUI) window.PQAwareUI.info(data && data.awareness);

                const mapped = mapPhpDataToDashboard(data);
                state.campaigns = mapped.campaigns;
                state.trends = mapped.trends;
                state.dateRange = mapped.dateRange;

                const headerDateEl = document.getElementById('header-last-qual-date');
                if (headerDateEl) {
                    headerDateEl.innerText = data.last_qualified_date ? data.last_qualified_date : 'N/A';
                }

                state.isLoading = false;
                hideLoader();
                updateFilteredStateAndRender();
                populateFilterSelects();

            } catch (err) {
                console.error('AJAX fetch error:', err);
                state.ajaxError = err.message;
                state.isLoading = false;
                hideLoader();
                renderDashboard();
            }
        };

        // ===m== Modern Upload Manager (2026 Standards) ===m==
        const UploadManager = {
            parsedData: [],
            extractedPayload: [],
            headers: [],
            CHUNK_SIZE: 500,
            stats: {
                success: 0,
                duplicate: 0,
                failed: 0
            },

            // Pagination & Meta state
            pageSize: 10,
            previewPage: 1,
            finalPage: 1,
            lastLeadDate: null,

            openModal() {
                this.resetState();
                document.getElementById('uploadModalOverlay').style.display = 'flex';
                this.initDragAndDrop();
            },

            closeModal() {
                document.getElementById('uploadModalOverlay').style.display = 'none';
                if (this.stats.success > 0 || this.stats.duplicate > 0) fetchDashboardData();
            },

            resetState() {
                this.parsedData = [];
                this.extractedPayload = [];
                this.headers = [];
                this.stats = {
                    success: 0,
                    duplicate: 0,
                    failed: 0
                };
                this.previewPage = 1;
                this.finalPage = 1;
                this.lastLeadDate = null;

                document.getElementById('uploadDropZone').style.display = 'block';
                document.getElementById('uploadPreviewArea').style.display = 'none';
                document.getElementById('uploadProgressArea').style.display = 'none';
                document.getElementById('uploadSummaryArea').style.display = 'none';
                document.getElementById('hiddenFileInput').value = '';
            },

            initDragAndDrop() {
                const dropZone = document.getElementById('uploadDropZone');
                const prevent = (e) => {
                    e.preventDefault();
                    e.stopPropagation();
                };
                ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
                    dropZone.addEventListener(eventName, prevent, false);
                });

                dropZone.addEventListener('dragover', () => dropZone.style.borderColor = C.blue);
                dropZone.addEventListener('dragleave', () => dropZone.style.borderColor = 'var(--pq-border)');
                dropZone.addEventListener('drop', (e) => {
                    dropZone.style.borderColor = 'var(--pq-border)';
                    const file = e.dataTransfer.files[0];
                    if (file) this.processFile(file);
                });
            },

            handleFileSelect(e) {
                const file = e.target.files[0];
                if (file) this.processFile(file);
            },

            processFile(file) {
                document.getElementById('uploadDropZone').style.display = 'none';
                const ext = file.name.split(".").pop().toLowerCase();

                if (ext === "csv") {
                    Papa.parse(file, {
                        header: true,
                        skipEmptyLines: true,
                        complete: (res) => this.prepareData(res.data)
                    });
                } else {
                    const reader = new FileReader();
                    reader.onload = (ev) => {
                        const wb = XLSX.read(ev.target.result, {
                            type: "array"
                        });
                        const ws = wb.Sheets[wb.SheetNames[0]];
                        this.prepareData(XLSX.utils.sheet_to_json(ws, {
                            defval: ""
                        }));
                    };
                    reader.readAsArrayBuffer(file);
                }
            },



            prepareData(rows) {
                if (!rows.length) {
                    alert("File is empty.");
                    this.resetState();
                    return;
                }
                this.parsedData = rows;
                this.headers = Object.keys(rows[0]);

                const normalizeKey = k => k.toLowerCase().trim().replace(/[\s\-]+/g, '_');
                const hNorm = this.headers.map(normalizeKey);

                const kMap = {
                    mobile: this.headers[hNorm.findIndex(k => k === 'mobile')],
                    gclid: this.headers[hNorm.findIndex(k => k === 'gclid')],
                    status: this.headers[hNorm.findIndex(k => k === 'status')],
                    sub: this.headers[hNorm.findIndex(k => k === 'sub_status' || k.includes('sub_status'))],
                    sv: this.headers[hNorm.findIndex(k => k === 'sitevisit_status' || k === 'site_visit' || k === 'sitevisit')],
                    sv_sub: this.headers[hNorm.findIndex(k => k === 'sitevisit_sub_status' || k.includes('sitevisit_sub'))]
                };

                if (!kMap.mobile && !kMap.gclid) {
                    alert("Could not find a valid ID column (Mobile or gclid).");
                    this.resetState();
                    return;
                }

                this.extractedPayload = rows.map(r => ({
                    mobile: kMap.mobile ? String(r[kMap.mobile] || '').trim() : '',
                    gclid: kMap.gclid ? String(r[kMap.gclid] || '').trim() : '',
                    status: kMap.status ? String(r[kMap.status] || '').trim() : '',
                    sub_status: kMap.sub ? String(r[kMap.sub] || '').trim() : '',
                    sitevisit_status: kMap.sv ? String(r[kMap.sv] || '').trim() : '',
                    sitevisit_sub_status: kMap.sv_sub ? String(r[kMap.sv_sub] || '').trim() : ''
                })).filter(r => r.mobile || r.gclid);

                this.renderPreviewTable();
            },

            renderPreviewTable() {
                // Generate Sticky Headers
                const thStyle = `padding:12px 14px; white-space:nowrap; background:var(--pq-surface); position:sticky; top:0; z-index:1; border-bottom:1px solid var(--pq-border); font-size:11px; text-transform:uppercase; color:var(--pq-text-dim);`;
                const head = `<tr>${this.headers.map(h => `<th style="${thStyle}">${h}</th>`).join('')}</tr>`;
                document.getElementById('previewTableHeader').innerHTML = head;

                // Update Title
                document.getElementById('previewTableTitle').innerHTML = `Data Preview <span style="color:var(--pq-text-dim); font-size:12px; font-weight:400;">[${this.parsedData.length} total rows]</span>`;

                document.getElementById('uploadPreviewArea').style.display = 'flex';
                this.renderPreviewPage(1);
            },

            renderPreviewPage(page) {
                this.previewPage = page;
                const start = (page - 1) * this.pageSize;
                const slice = this.parsedData.slice(start, start + this.pageSize);

                const tdStyle = `padding:10px 14px; white-space:nowrap; border-bottom:1px solid #1E2A4244; font-size:12.5px; color:var(--pq-text);`;
                const body = slice.map(row =>
                    `<tr>${this.headers.map(h => `<td style="${tdStyle}" class="mono">${row[h] || '—'}</td>`).join('')}</tr>`
                ).join('');

                document.getElementById('previewTableBody').innerHTML = body;

                // Info text
                const end = Math.min(start + this.pageSize, this.parsedData.length);
                document.getElementById('previewInfo').innerText = `Showing ${this.parsedData.length === 0 ? 0 : start + 1} to ${end} of ${this.parsedData.length} entries`;

                this.renderPagination('previewPagination', this.parsedData.length, this.previewPage, 'UploadManager.renderPreviewPage');
            },

            async startBatchUpload() {
                document.getElementById('uploadPreviewArea').style.display = 'none';
                document.getElementById('uploadProgressArea').style.display = 'flex';

                const totalChunks = Math.ceil(this.extractedPayload.length / this.CHUNK_SIZE);

                for (let i = 0; i < totalChunks; i++) {
                    const chunk = this.extractedPayload.slice(i * this.CHUNK_SIZE, (i + 1) * this.CHUNK_SIZE);

                    document.getElementById('progressText').innerText = `Uploading batch ${i + 1} of ${totalChunks}...`;
                    const percent = Math.round(((i) / totalChunks) * 100);
                    document.getElementById('progressBarFill').style.width = `${percent}%`;
                    document.getElementById('progressPercentage').innerText = `${percent}%`;

                    try {
                        const res = await fetch('googleapi.php?action=update_leads', {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/json'
                            },
                            body: JSON.stringify({
                                updates: chunk
                            })
                        });
                        if (!res.ok) throw new Error('API Error');
                        const data = await res.json();

                        this.stats.success += data.updated || 0;
                        this.stats.duplicate += data.duplicate || 0;
                        this.stats.failed += data.failed || 0;
                    } catch (e) {
                        this.stats.failed += chunk.length;
                    }
                }

                document.getElementById('progressBarFill').style.width = `100%`;
                document.getElementById('progressPercentage').innerText = `100%`;

                setTimeout(() => this.showSummary(), 400);
            },

            showSummary() {
                document.getElementById('uploadProgressArea').style.display = 'none';
                document.getElementById('uploadSummaryArea').style.display = 'flex';

                document.getElementById('statSuccess').innerText = this.stats.success;
                document.getElementById('statDuplicate').innerText = this.stats.duplicate;
                document.getElementById('statFailed').innerText = this.stats.failed;

                // Setup Final Table Headers
                const thStyle = `padding:12px 14px; white-space:nowrap; background:var(--pq-surface); position:sticky; top:0; z-index:1; border-bottom:1px solid var(--pq-border); font-size:11px; text-transform:uppercase; color:var(--pq-text-dim);`;
                const head = `<tr>${this.headers.map(h => `<th style="${thStyle}">${h}</th>`).join('')}</tr>`;
                document.getElementById('finalTableHeader').innerHTML = head;

                this.renderFinalPage(1);
            },

            renderFinalPage(page) {
                this.finalPage = page;
                const start = (page - 1) * this.pageSize;
                const slice = this.parsedData.slice(start, start + this.pageSize);

                const tdStyle = `padding:10px 14px; white-space:nowrap; border-bottom:1px solid #1E2A4244; font-size:12.5px; color:var(--pq-text);`;
                const body = slice.map(row =>
                    `<tr>${this.headers.map(h => `<td style="${tdStyle}" class="mono">${row[h] || '—'}</td>`).join('')}</tr>`
                ).join('');

                document.getElementById('finalTableBody').innerHTML = body;

                // Info text
                const end = Math.min(start + this.pageSize, this.parsedData.length);
                document.getElementById('finalInfo').innerText = `Showing ${this.parsedData.length === 0 ? 0 : start + 1} to ${end} of ${this.parsedData.length} entries`;

                this.renderPagination('finalPagination', this.parsedData.length, this.finalPage, 'UploadManager.renderFinalPage');
            },

            renderPagination(containerId, totalItems, currentPage, functionName) {
                const totalPages = Math.ceil(totalItems / this.pageSize);
                const container = document.getElementById(containerId);

                if (totalPages <= 1) {
                    container.innerHTML = '';
                    return;
                }

                const btnS = `background:var(--pq-card); color:var(--pq-text-dim); border:1px solid var(--pq-border); border-radius:6px; padding:4px 10px; font-size:11px; cursor:pointer; font-family:'Sora',sans-serif;`;
                const btnA = `background:#E8A820; color:var(--pq-bg); border:1px solid #E8A820; border-radius:6px; padding:4px 10px; font-size:11px; font-weight:700; cursor:pointer; font-family:'Sora',sans-serif;`;

                let btns = `<button style="${btnS}" onclick="${functionName}(${currentPage - 1})" ${currentPage === 1 ? 'disabled' : ''}>‹ Prev</button>`;

                const delta = 2;
                const lo = Math.max(1, currentPage - delta);
                const hi = Math.min(totalPages, currentPage + delta);

                if (lo > 1) {
                    btns += `<button style="${btnS}" onclick="${functionName}(1)">1</button>`;
                    if (lo > 2) btns += `<span style="color:var(--pq-muted); padding:0 4px;">…</span>`;
                }

                for (let p = lo; p <= hi; p++) {
                    btns += `<button style="${p === currentPage ? btnA : btnS}" onclick="${functionName}(${p})">${p}</button>`;
                }

                if (hi < totalPages) {
                    if (hi < totalPages - 1) btns += `<span style="color:var(--pq-muted); padding:0 4px;">…</span>`;
                    btns += `<button style="${btnS}" onclick="${functionName}(${totalPages})">${totalPages}</button>`;
                }

                btns += `<button style="${btnS}" onclick="${functionName}(${currentPage + 1})" ${currentPage === totalPages ? 'disabled' : ''}>Next ›</button>`;

                container.innerHTML = btns;
            },

            exportFinalData() {
                const worksheet = XLSX.utils.json_to_sheet(this.parsedData);
                const workbook = XLSX.utils.book_new();
                XLSX.utils.book_append_sheet(workbook, worksheet, "Processed Data");
                XLSX.writeFile(workbook, `Batch_Upload_Summary_${new Date().getTime()}.xlsx`);
            }
        };

        /*async function uploadCRMDataToDatabase(rows) {
            if (!rows || !rows.length) return;

            const normalizeKey = k => k.toLowerCase().trim().replace(/[\s\-]+/g, '_');

            const firstRow = rows[0];
            const rawKeys = Object.keys(firstRow);

            const idKey = rawKeys.find(k => {
                const norm = normalizeKey(k);
                // return norm === 'meta_id' || norm === 'uniqueid' || norm === 'leadgen_id' || norm === 'lead_id';
                return norm === 'mobile';
            });

            const statusKey = rawKeys.find(k => k.toLowerCase().trim() === 'status');

            const subStatusKey = rawKeys.find(k => normalizeKey(k) === 'sub_status') ||
                rawKeys.find(k => normalizeKey(k) === 'lead_sub_status') ||
                rawKeys.find(k => normalizeKey(k).includes('sub_status'));
            const sitevisitStatusKey = rawKeys.find(k => {
                const norm = normalizeKey(k);
                return norm === 'sitevisit_status' || norm === 'site_visit_status' || norm === 'site_visit' || norm === 'sitevisit';
            });
            const sitevisitSubStatusKey = rawKeys.find(k => {
                const norm = normalizeKey(k);
                return norm === 'sitevisit_sub_status' || norm === 'site_visit_sub_status' || norm === 'sitevisit_sub_status' || norm.includes('sitevisit_sub');
            });

            if (!idKey) {
                alert("Could not find a valid ID column [Mobile] in the file.");
                return;
            }

            const updates = [];
            rows.forEach(r => {
                const idVal = String(r[idKey] || '').trim();
                if (idVal !== '') {
                    const statusVal = statusKey ? String(r[statusKey] || '').trim() : '';
                    const subStatusVal = subStatusKey ? String(r[subStatusKey] || '').trim() : '';
                    const sitevisitStatusVal = sitevisitStatusKey ? String(r[sitevisitStatusKey] || '').trim() : '';
                    const sitevisitSubStatusVal = sitevisitSubStatusKey ? String(r[sitevisitSubStatusKey] || '').trim() : '';

                    updates.push({
                        id: idVal,
                        status: statusVal,
                        sub_status: subStatusVal,
                        sitevisit_status: sitevisitStatusVal,
                        sitevisit_sub_status: sitevisitSubStatusVal
                    });
                }
            });

            if (!updates.length) {
                alert("No valid rows found in the uploaded file.");
                return;
            }

            const statusText = document.getElementById('upload-status-text');
            if (statusText) {
                statusText.innerText = "Saving to DB…";
                statusText.style.color = "";
                statusText.classList.add('pulse');
            }

            try {
                const response = await fetch('googleapi.php?action=update_leads', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({ updates })
                });

                if (!response.ok) throw new Error('Failed to save CRM data');

                const res = await response.json();
                if (res.success) {
                    state.uploadStatus = "done";
                    if (statusText) {
                        statusText.innerText = `Saved ${res.updated} leads ✓`;
                        statusText.style.color = C.green;
                        statusText.classList.remove('pulse');
                    }
                    // Refresh the dashboard using the date filter
                    await fetchDashboardData();
                } else {
                    throw new Error('Database save returned success false');
                }
            } catch (err) {
                console.error('Error saving CRM data:', err);
                state.uploadStatus = "error";
                if (statusText) {
                    statusText.innerText = "Error Saving ❌";
                    statusText.style.color = '#EF4444';
                    statusText.classList.remove('pulse');
                }
                alert("Failed to save data: " + err.message);
            }
    }*/


        // ===m=== As soon as UI done then call fetchDashboardData ===m===
        document.addEventListener('DOMContentLoaded', () => {
            state.tempPreset = 'last_30d';
            const dates = getPresetDates('last_30d');
            state.tempStartDate = new Date(dates.since);
            state.tempEndDate = new Date(dates.until);
            state.calendarMonth = new Date(state.tempStartDate.getFullYear(), state.tempStartDate.getMonth(), 1);
            fetchDashboardData();
        });

        // Dummy Mock for DB addition (Matches manager's instructions)
        window.handleAddCampaignName = () => {
            showCampaignToast('⚠️ Saving to Campaigns Master database is disabled for this Phase.', 'warn');
        };

        window.showCampaignToast = (msg, type) => {
            const colors = {
                success: '#10B981',
                error: '#EF4444',
                warn: '#F59E0B'
            };
            const toast = document.createElement('div');
            toast.style.cssText = `position:fixed; bottom:28px; right:28px; z-index:99999; background:var(--pq-surface-2); border-left:4px solid ${colors[type]}; color:#F9FAFB; padding:14px 22px; border-radius:8px; font-family:'Sora',sans-serif; box-shadow:0 10px 32px rgba(0,0,0,0.5);`;
            toast.textContent = msg;
            document.body.appendChild(toast);
            setTimeout(() => toast.remove(), 4000);
        };
    </script>

    <!-- Upload Offline Data Modal -->
    <div id="uploadModalOverlay"
        style="display:none;position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(3,7,18,0.75);z-index:99999;align-items:center;justify-content:center;backdrop-filter:blur(4px);">
        <div
            style="background:var(--pq-surface); border:1px solid var(--pq-border); border-radius:12px; width:95%; max-width:1100px; max-height:90vh; display:flex; flex-direction:column; box-shadow:0 20px 40px rgba(0,0,0,0.6);">
            <div
                style="display:flex; justify-content:space-between; align-items:center; padding:20px 28px; border-bottom:1px solid var(--pq-border); background:var(--pq-bg); border-radius:12px 12px 0 0;">
                <h3 style="margin:0; font-size:16px; color:var(--pq-text);">Upload Data</h3>
                <button class="tab-btn" onclick="UploadManager.closeModal()"
                    style="color:var(--pq-text-dim); font-size:20px; line-height:1;">&times;</button>
            </div>

            <div style="padding:28px; overflow-y:auto; flex-grow:1; display:flex; flex-direction:column; gap:24px;">

                <!-- State 1: Drag & Drop Zone -->
                <div id="uploadDropZone"
                    style="border:2px dashed var(--pq-border); border-radius:12px; padding:48px 24px; text-align:center; background:var(--pq-card); transition:all 0.2s; cursor:pointer;"
                    onclick="document.getElementById('hiddenFileInput').click()">
                    <input type="file" id="hiddenFileInput" accept=".xlsx,.xls,.csv" style="display:none;"
                        onchange="UploadManager.handleFileSelect(event)">
                    <div style="font-size:32px; margin-bottom:12px;"></div>
                    <div style="color:var(--pq-text); font-size:14px; font-weight:600; margin-bottom:8px;">Click to upload or
                        drag and drop</div>
                    <div style="color:var(--pq-text-dim); font-size:12px;">CSV, XLS, or XLSX (Max 50MB)</div>
                </div>

                <!-- State 2: Preview Area -->
                <div id="uploadPreviewArea" style="display:none; flex-direction:column; gap:16px;">
                    <div
                        style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px;">
                        <span id="previewTableTitle" style="color:var(--pq-text); font-size:14px; font-weight:600;">Data
                            Preview</span>
                        <button class="btn" id="startBatchUploadBtn" onclick="UploadManager.startBatchUpload()">Start
                            Batch Upload</button>
                    </div>
                    <div
                        style="background:var(--pq-bg); border:1px solid var(--pq-border); border-radius:8px; overflow:auto; max-height:40vh;">
                        <table style="width:100%; text-align:left; border-collapse:collapse;">
                            <thead id="previewTableHeader"></thead>
                            <tbody id="previewTableBody"></tbody>
                        </table>
                    </div>
                    <!-- Preview Pagination -->
                    <div style="display:flex; align-items:center; justify-content:space-between;">
                        <span id="previewInfo" style="color:var(--pq-text-dim); font-size:11px;"></span>
                        <div id="previewPagination" style="display:flex; gap:4px;"></div>
                    </div>
                </div>

                <!-- State 3: Progress Area -->
                <div id="uploadProgressArea" style="display:none; flex-direction:column; gap:12px;">
                    <div
                        style="display:flex; justify-content:space-between; color:var(--pq-text); font-size:13px; font-weight:600;">
                        <span id="progressText">Uploading batch 1 of X...</span>
                        <span id="progressPercentage">0%</span>
                    </div>
                    <div style="width:100%; height:8px; background:var(--pq-border); border-radius:4px; overflow:hidden;">
                        <div id="progressBarFill"
                            style="height:100%; width:0%; background:#10B981; transition:width 0.3s ease;"></div>
                    </div>
                </div>

                <!-- State 4: Summary & Final Table Area -->
                <div id="uploadSummaryArea" style="display:none; flex-direction:column; gap:20px;">
                    <div style="display:grid; grid-template-columns:repeat(3, 1fr); gap:16px;">
                        <div
                            style="background:var(--pq-card); border:1px solid #10B98144; padding:16px; border-radius:8px; border-top:2px solid #10B981;">
                            <div style="color:var(--pq-text-dim); font-size:11px; text-transform:uppercase;">Uploaded</div>
                            <div id="statSuccess"
                                style="color:var(--pq-text); font-size:24px; font-weight:600; font-family:'JetBrains Mono'; margin-top:4px;">
                                0</div>
                        </div>
                        <div
                            style="background:var(--pq-card); border:1px solid #ffd00044; padding:16px; border-radius:8px; border-top:2px solid #f6d43bff;">
                            <div style="color:var(--pq-text-dim); font-size:11px; text-transform:uppercase;">Already Present</div>
                            <div id="statDuplicate"
                                style="color:var(--pq-text); font-size:24px; font-weight:600; font-family:'JetBrains Mono'; margin-top:4px;">
                                0</div>
                        </div>
                        <div
                            style="background:var(--pq-card); border:1px solid #EF444444; padding:16px; border-radius:8px; border-top:2px solid #EF4444;">
                            <div style="color:var(--pq-text-dim); font-size:11px; text-transform:uppercase;">Failed</div>
                            <div id="statFailed"
                                style="color:var(--pq-text); font-size:24px; font-weight:600; font-family:'JetBrains Mono'; margin-top:4px;">
                                0</div>
                        </div>
                    </div>

                    <div style="display:flex; justify-content:space-between; align-items:center;">
                        <span style="color:var(--pq-text); font-size:14px; font-weight:600;">Processed Data List</span>
                        <button class="btn" onclick="UploadManager.exportFinalData()"
                            style="background:#10B981; color:#fff;">Export Summary to Excel</button>
                    </div>
                    <div
                        style="background:var(--pq-bg); border:1px solid var(--pq-border); border-radius:8px; max-height:35vh; overflow:auto;">
                        <table style="width:100%; text-align:left; border-collapse:collapse;">
                            <thead id="finalTableHeader"></thead>
                            <tbody id="finalTableBody"></tbody>
                        </table>
                    </div>
                    <!-- Final Table Pagination -->
                    <div style="display:flex; align-items:center; justify-content:space-between;">
                        <span id="finalInfo" style="color:var(--pq-text-dim); font-size:11px;"></span>
                        <div id="finalPagination" style="display:flex; gap:4px;"></div>
                    </div>
                </div>

            </div>
        </div>
    </div>

    <!-- Leads Modal -->
    <div id="leadsModalOverlay"
        style="display:none;position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.6);z-index:99999;align-items:center;justify-content:center;backdrop-filter:blur(4px);">
        <div
            style="background:var(--pq-card); border:1px solid var(--pq-border); border-radius:12px; width:90%; max-width:1000px; max-height:85vh; display:flex; flex-direction:column; box-shadow:0 10px 32px rgba(0,0,0,0.5);">
            <div
                style="display:flex; justify-content:space-between; align-items:center; padding:16px 24px; border-bottom:1px solid var(--pq-border);">
                <h3 id="leadsModalTitle" style="margin:0; font-size:16px; color:#E8A820;">Leads Data</h3>
                <div style="display:flex; gap:12px;">
                    <button class="btn" onclick="exportLeadsToExcel()">Export Data</button>
                    <button class="btn btn-ghost" onclick="closeLeadsModal()" style="padding:10px 16px;">Close</button>
                </div>
            </div>
            <div style="display:flex; flex-direction:column; gap:16px; padding:24px; flex-grow:1; overflow:hidden;">
                <div
                    style="background:var(--pq-bg); border:1px solid var(--pq-border); border-radius:8px; max-height:50vh; overflow:auto;">
                    <table style="width:100%; text-align:left; border-collapse:collapse;">
                        <thead>
                            <tr>
                                <th style="position:sticky; top:0; background:var(--pq-surface); z-index:1;">Created Date</th>
                                <th style="position:sticky; top:0; background:var(--pq-surface); z-index:1;">Unique ID</th>
                                <th style="position:sticky; top:0; background:var(--pq-surface); z-index:1;">Campaign Name</th>
                                <th style="position:sticky; top:0; background:var(--pq-surface); z-index:1;">AdGroup Name</th>
                                <th style="position:sticky; top:0; background:var(--pq-surface); z-index:1;">Ad Name</th>
                                <th style="position:sticky; top:0; background:var(--pq-surface); z-index:1;">Lead Status</th>
                                <th style="position:sticky; top:0; background:var(--pq-surface); z-index:1;">Site Visits Status
                                </th>
                            </tr>
                        </thead>
                        <tbody id="leadsModalBody">
                        </tbody>
                    </table>
                </div>
                <!-- Leads Modal Pagination -->
                <div style="display:flex; align-items:center; justify-content:space-between;">
                    <span id="leadsModalInfo" style="color:var(--pq-text-dim); font-size:11px;"></span>
                    <div style="display:flex; align-items:center; gap:10px;">
                        <select onchange="LeadsModal.setPageSize(+this.value)"
                            style="background:var(--pq-card);color:var(--pq-text);border:1px solid var(--pq-border);border-radius:6px;padding:5px 8px;font-size:11px;outline:none;cursor:pointer;">
                            <option value="10">10</option>
                            <option value="25" selected>25</option>
                            <option value="50">50</option>
                            <option value="-1">All</option>
                        </select>
                        <div id="leadsModalPagination" style="display:flex; gap:4px;"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        let currentLeadsForExport = [];
        let currentLeadsTitle = "";

        window.openLeadsModalByCampaign = (encodedCampaignName, type) => {
            const campaignName = decodeURIComponent(encodedCampaignName);
            const c = state.filteredCampaigns.find(x => x.campaign === campaignName);
            if (!c) return;
            const leads = (c[type] || []).filter(l => !isTestLead(l));
            const titleMap = {
                qualified_leads: 'Qualified Leads',
                walkin_leads: 'Site Visits',
                leads_data: 'Leads'
            };
            const title = (titleMap[type] || 'Leads') + ' - ' + campaignName;
            showLeadsModal(leads, title);
        };

        window.openLeadsModalTotal = (type) => {
            let leads = [];
            const seen = new Set();
            state.filteredCampaigns.forEach(c => {
                (c[type] || []).forEach(l => {
                    if (isTestLead(l)) return;
                    const key = (l.mkey || l.mobile || '') + '|' + (l.gclid || '');
                    if (!seen.has(key)) {
                        seen.add(key);
                        leads.push(l);
                    }
                });
            });
            const totalTitleMap = {
                qualified_leads: 'Total Qualified Leads',
                walkin_leads: 'Total Site Visits',
                leads_data: 'Total Leads'
            };
            const title = totalTitleMap[type] || 'Total Leads';
            showLeadsModal(leads, title);
        };

        // ===m=== Leads Modal: paginated table, mirrors UploadManager preview pagination ===m===
        const LeadsModal = {
            data: [],
            page: 1,
            pageSize: 25,

            open(leads, title) {
                this.data = leads || [];
                this.page = 1;

                currentLeadsForExport = this.data; // export always exports the full filtered set, not just current page
                currentLeadsTitle = title;

                document.getElementById('leadsModalTitle').innerText = `${title} [${this.data.length}]`;
                document.getElementById('leadsModalOverlay').style.display = 'flex';
                this.renderPage(1);
            },

            setPageSize(size) {
                this.pageSize = size;
                this.renderPage(1);
            },

            // the server masks it by Users & Roles (stars + the last 5 digits, googleapi.php → pqContactRows)
            hashMobile(m) {
                return m || '—';
            },
            // hashMobile(m) {
            //     return m || '—';
            // },
            renderRow(l) {
                const uniqueIdHtml = l.gclid ?
                    `<span style="font-size:10px; color:#3B82F6; max-width:180px; display:inline-block; overflow:hidden; text-overflow:ellipsis;" title="${l.gclid}">${l.gclid}</span>` :
                    `<span style="font-size:11px; color:var(--pq-text-dim);">${this.hashMobile(l.mobile)}</span>`;

                return `
                    <tr>
                        <td class="mono" style="font-size:11px; padding:10px 14px; border-bottom:1px solid #1E2A4244; white-space:nowrap;">${l.createddate ? l.createddate.split(' ')[0] : '—'}</td>
                        <td style="padding:10px 14px; border-bottom:1px solid #1E2A4244;">${uniqueIdHtml}</td>
                        <td style="font-size:12px; color:var(--pq-text); padding:10px 14px; border-bottom:1px solid #1E2A4244; max-width:150px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;" title="${l.utm_campaignname || ''}">${l.utm_campaignname || '—'}</td>
                        <td style="font-size:11px; color:var(--pq-text-dim); padding:10px 14px; border-bottom:1px solid #1E2A4244; max-width:120px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;" title="${l.utm_adgroupname || ''}">${l.utm_adgroupname || '—'}</td>
                        <td style="font-size:11px; color:var(--pq-text-dim); padding:10px 14px; border-bottom:1px solid #1E2A4244; max-width:120px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;" title="${l.utm_adname || ''}">${l.utm_adname || '—'}</td>
                        <td style="padding:10px 14px; border-bottom:1px solid #1E2A4244;"><span class="badge" style="background:var(--pq-border); color:var(--pq-text-dim); padding:2px 6px; border-radius:4px; font-size:10px;">${l.lead_status || '—'}</span></td>
                        <td style="padding:10px 14px; border-bottom:1px solid #1E2A4244;"><span class="badge" style="background:var(--pq-border); color:var(--pq-text-dim); padding:2px 6px; border-radius:4px; font-size:10px;">${l.sitevisit_status || '—'}</span></td>
                    </tr>
                `;
            },

            renderPage(page) {
                this.page = page;
                const size = this.pageSize === -1 ? this.data.length : this.pageSize;
                const start = (page - 1) * size;
                const slice = size > 0 ? this.data.slice(start, start + size) : this.data;

                const body = slice.length ?
                    slice.map(l => this.renderRow(l)).join('') :
                    '<tr><td colspan="7" style="text-align:center; padding:20px; color:var(--pq-text-dim);">No data available</td></tr>';

                document.getElementById('leadsModalBody').innerHTML = body;

                const end = Math.min(start + size, this.data.length);
                document.getElementById('leadsModalInfo').innerText =
                    `Showing ${this.data.length === 0 ? 0 : start + 1} to ${this.data.length === 0 ? 0 : end} of ${this.data.length} entries`;

                this.renderPagination();
            },

            renderPagination() {
                const container = document.getElementById('leadsModalPagination');
                const totalPages = this.pageSize === -1 ? 1 : Math.ceil(this.data.length / this.pageSize);

                if (totalPages <= 1) {
                    container.innerHTML = '';
                    return;
                }

                const btnS = `background:var(--pq-card); color:var(--pq-text-dim); border:1px solid var(--pq-border); border-radius:6px; padding:4px 10px; font-size:11px; cursor:pointer; font-family:'Sora',sans-serif;`;
                const btnA = `background:#E8A820; color:var(--pq-bg); border:1px solid #E8A820; border-radius:6px; padding:4px 10px; font-size:11px; font-weight:700; cursor:pointer; font-family:'Sora',sans-serif;`;

                let btns = `<button style="${btnS}" onclick="LeadsModal.renderPage(${this.page - 1})" ${this.page === 1 ? 'disabled' : ''}>‹ Prev</button>`;

                const delta = 2;
                const lo = Math.max(1, this.page - delta);
                const hi = Math.min(totalPages, this.page + delta);

                if (lo > 1) {
                    btns += `<button style="${btnS}" onclick="LeadsModal.renderPage(1)">1</button>`;
                    if (lo > 2) btns += `<span style="color:var(--pq-muted); padding:0 4px;">…</span>`;
                }

                for (let p = lo; p <= hi; p++) {
                    btns += `<button style="${p === this.page ? btnA : btnS}" onclick="LeadsModal.renderPage(${p})">${p}</button>`;
                }

                if (hi < totalPages) {
                    if (hi < totalPages - 1) btns += `<span style="color:var(--pq-muted); padding:0 4px;">…</span>`;
                    btns += `<button style="${btnS}" onclick="LeadsModal.renderPage(${totalPages})">${totalPages}</button>`;
                }

                btns += `<button style="${btnS}" onclick="LeadsModal.renderPage(${this.page + 1})" ${this.page === totalPages ? 'disabled' : ''}>Next ›</button>`;

                container.innerHTML = btns;
            }
        };

        window.showLeadsModal = (leads, title) => LeadsModal.open(leads, title);

        window.closeLeadsModal = () => {
            document.getElementById('leadsModalOverlay').style.display = 'none';
        };

        window.exportLeadsToExcel = () => {
            if (!currentLeadsForExport || currentLeadsForExport.length === 0) {
                alert("No data to export.");
                return;
            }

            //const hashMobile = (m) => m && m.length >= 10 ? m.replace(/^(\d{5})(.*)(\d{5})$/, '*****$3') : '—';
            const hashMobile = (m) => m || '—';   // export rule applied on the server (mobile_export)

            // Map data to array of objects for XLSX matching the new UI
            const exportData = currentLeadsForExport.map(l => ({
                'Created Date': l.createddate ? l.createddate.split(' ')[0] : '—',
                'GCLID': l.gclid || '—',
                'Mobile': hashMobile(l.mobile_export ?? l.mobile),
                'Campaign Name': l.utm_campaignname || '—',
                'AdGroup Name': l.utm_adgroupname || '—',
                'Ad Name': l.utm_adname || '—',
                'Lead Status': l.lead_status || '—',
                'Site Visit Status': l.sitevisit_status || '—'
            }));

            const worksheet = XLSX.utils.json_to_sheet(exportData);
            const workbook = XLSX.utils.book_new();
            XLSX.utils.book_append_sheet(workbook, worksheet, "Leads Data");

            // Generate filename based on title
            const filename = currentLeadsTitle.replace(/[^a-z0-9]/gi, '_').toLowerCase() + '_data.xlsx';
            XLSX.writeFile(workbook, filename);
        };

        window.toggleExportDropdown = (e) => {
            if (e) e.stopPropagation();
            const btn = e ? (e.currentTarget || e.target) : null;
            const wrap = btn ? btn.closest('#export-dropdown-wrap') : null;
            const menu = wrap ? wrap.querySelector('.export-dropdown-menu-list, [id^="export-dropdown-menu"]') : document.getElementById('export-dropdown-menu');
            if (menu) {
                const isShown = menu.style.display === 'block';
                document.querySelectorAll('.export-dropdown-menu-list, [id^="export-dropdown-menu"]').forEach(m => m.style.display = 'none');
                menu.style.display = isShown ? 'none' : 'block';
            }
        };
        window.closeExportDropdown = () => {
            document.querySelectorAll('.export-dropdown-menu-list, [id^="export-dropdown-menu"]').forEach(m => m.style.display = 'none');
        };
        document.addEventListener('click', (e) => {
            const wrap = e.target.closest('#export-dropdown-wrap');
            if (!wrap) window.closeExportDropdown();
        });

        window.exportPortfolioPDF = async () => {
            // Same report as the main dashboard's "Export PDF" — js/portfolio_pdf.js (Meta + Google, saved campaigns only)
            const btn = document.getElementById('export-dropdown-btn');
            const label = btn ? btn.innerHTML : '';
            const urlParams = new URLSearchParams(window.location.search);
            let since = urlParams.get('since') || (typeof state !== 'undefined' ? (state.sinceDateStr || '') : '');
            let until = urlParams.get('until') || (typeof state !== 'undefined' ? (state.untilDateStr || '') : '');
            if ((!since || !until) && typeof getPresetDates === 'function' && typeof state !== 'undefined') {
                const pd = getPresetDates(state.selectedPreset || state.tempPreset || 'last_30d');
                since = since || pd.since; until = until || pd.until;
            }
            try {
                if (btn) btn.disabled = true;
                const done = await PortfolioPDF.export({ since, until, api: 'portfolio_report_api.php', logo: 'images/webzaa-logo.png', detail: 'adset',
                    onStatus: t => { if (btn) btn.innerHTML = '⏳ ' + t; } });
                if (done && typeof window.showCampaignToast === 'function') window.showCampaignToast('✅ PDF report downloaded.', 'success');
            } catch (err) {
                console.error('Portfolio PDF failed:', err);
                if (typeof window.showCampaignToast === 'function') window.showCampaignToast('❌ ' + err.message, 'error'); else alert(err.message);
            } finally {
                if (btn) { btn.disabled = false; btn.innerHTML = label; }
            }
        };


    </script>

    <!-- ══ Lead Details Popup Modal ════════════════════════════════════════════ -->
    <div id="lead-details-overlay" style="display:none; position:fixed; inset:0; z-index:10000;
           background:rgba(0,0,0,0.72); backdrop-filter:blur(5px);
           align-items:center; justify-content:center;" onclick="if(event.target===this) closeLeadDetailsPopup()">

        <div id="lead-details-modal" style="background:var(--pq-surface); border:1px solid var(--pq-border);
             border-radius:18px; width:900px; max-width:95vw; max-height:88vh;
             display:flex; flex-direction:column;
             box-shadow:0 28px 80px rgba(0,0,0,0.7), 0 0 0 1px #1E2A4280;
             opacity:0; transform:translateY(18px) scale(0.97);
             transition:all 0.22s cubic-bezier(0.34,1.56,0.64,1);">

            <div
                style="display:flex; align-items:center; gap:14px; padding:22px 26px; border-bottom:1px solid var(--pq-border); flex-shrink:0;">
                <div id="ldm-icon" style="width:40px; height:40px; border-radius:10px;
                     display:flex; align-items:center; justify-content:center; font-size:20px; flex-shrink:0;">
                </div>
                <div style="flex:1; min-width:0;">
                    <div id="ldm-title"
                        style="color:var(--pq-text); font-size:14px; font-weight:700; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">
                    </div>
                    <div id="ldm-subtitle" style="color:var(--pq-text-dim); font-size:11.5px; margin-top:2px;">
                    </div>
                </div>
                <div id="ldm-badge"
                    style="padding:5px 12px; border-radius:20px; font-size:11px; font-weight:700; flex-shrink:0;">
                </div>
                <button id="ldm-export-btn" onclick="exportLeadDetailsToExcel()" style="background:#E8A820; color:var(--pq-bg); border:none; border-radius:8px;
           padding:7px 14px; font-size:11.5px; font-weight:700; font-family:'Sora',sans-serif;
           cursor:pointer; display:flex; align-items:center; gap:5px; flex-shrink:0;
           transition:opacity 0.15s;" onmouseover="this.style.opacity='0.85'" onmouseout="this.style.opacity='1'">
                    📥 Export Excel
                </button>
                <button onclick="closeLeadDetailsPopup()" style="background:none; border:none; color:var(--pq-muted);
        font-size:22px; cursor:pointer; line-height:1; flex-shrink:0; padding:0 4px;"
                    onmouseover="this.style.color='var(--pq-text)'" onmouseout="this.style.color='var(--pq-muted)'">&#x2715;</button>
            </div>

            <div id="ldm-loading" style="display:flex; align-items:center; justify-content:center;
                 padding:60px; gap:12px; color:var(--pq-text-dim); font-size:13px;">
                <div style="width:20px; height:20px; border:2px solid var(--pq-border); border-top:2px solid #E8A820;
                     border-radius:50%; animation:spin 0.8s linear infinite;">
                </div>
                Loading lead records&hellip;
            </div>

            <div id="ldm-table-container" style="display:none; overflow-y:auto; flex:1; padding:0 4px 4px;">
                <div style="padding:14px 22px 10px; background:var(--pq-surface); border-bottom:1px solid #1E2A4244;">
                    <div style="position:relative; max-width:320px;">
                        <input id="ldm-search" type="text" placeholder="Search leads..."
                            oninput="filterLeadDetailsTable(this.value)" style="background:var(--pq-card); color:var(--pq-text); border:1px solid var(--pq-border); border-radius:8px;
                                      padding:7px 12px 7px 30px; font-family:'Sora',sans-serif; font-size:12px;
                                      outline:none; width:100%; box-sizing:border-box;" />
                        <span style="position:absolute; left:9px; top:50%; transform:translateY(-50%);
                                     color:var(--pq-muted); font-size:13px; pointer-events:none;">&#128269;</span>
                    </div>
                </div>
                <table style="width:100%; border-collapse:collapse;">
                    <thead>
                        <tr style="background:var(--pq-card); position:sticky; top:0; z-index:4;">
                            <th
                                style="padding:10px 14px; color:var(--pq-text-dim); font-size:10.5px; font-weight:700; text-transform:uppercase; letter-spacing:0.07em; text-align:left; white-space:nowrap; border-bottom:1px solid var(--pq-border);">
                                #</th>
                            <th
                                style="padding:10px 14px; color:var(--pq-text-dim); font-size:10.5px; font-weight:700; text-transform:uppercase; letter-spacing:0.07em; text-align:left; white-space:nowrap; border-bottom:1px solid var(--pq-border);">
                                Leadgen ID</th>
                            <th
                                style="padding:10px 14px; color:var(--pq-text-dim); font-size:10.5px; font-weight:700; text-transform:uppercase; letter-spacing:0.07em; text-align:left; white-space:nowrap; border-bottom:1px solid var(--pq-border);">
                                Created Date</th>
                            <th
                                style="padding:10px 14px; color:var(--pq-text-dim); font-size:10.5px; font-weight:700; text-transform:uppercase; letter-spacing:0.07em; text-align:left; border-bottom:1px solid var(--pq-border);">
                                Campaign</th>
                            <th
                                style="padding:10px 14px; color:var(--pq-text-dim); font-size:10.5px; font-weight:700; text-transform:uppercase; letter-spacing:0.07em; text-align:left; border-bottom:1px solid var(--pq-border);">
                                AdGroup</th>
                            <th
                                style="padding:10px 14px; color:var(--pq-text-dim); font-size:10.5px; font-weight:700; text-transform:uppercase; letter-spacing:0.07em; text-align:left; border-bottom:1px solid var(--pq-border);">
                                Ad Name</th>
                            <th
                                style="padding:10px 14px; color:var(--pq-text-dim); font-size:10.5px; font-weight:700; text-transform:uppercase; letter-spacing:0.07em; text-align:left; white-space:nowrap; border-bottom:1px solid var(--pq-border);">
                                Status</th>
                        </tr>
                    </thead>
                    <tbody id="ldm-tbody"></tbody>
                </table>
                <div id="ldm-no-results"
                    style="display:none; text-align:center; padding:40px; color:var(--pq-muted); font-size:13px;">No matching
                    lead records found.</div>
            </div>
            <div id="ldm-error" style="display:none; padding:40px; text-align:center; color:#EF4444; font-size:13px;">
            </div>
        </div>
    </div>

    <script>
        var _ldmAllLeads = [];
        window.openLeadDetailsPopup = async function (campaignName, type, adsetName, adName) {
            var overlay = document.getElementById('lead-details-overlay');
            var modal = document.getElementById('lead-details-modal');
            if (!overlay || !modal) return;

            document.getElementById('ldm-loading').style.display = 'flex';
            document.getElementById('ldm-table-container').style.display = 'none';
            document.getElementById('ldm-error').style.display = 'none';
            document.getElementById('ldm-tbody').innerHTML = '';
            var searchEl = document.getElementById('ldm-search');
            if (searchEl) searchEl.value = '';
            _ldmAllLeads = [];

            var typeConf = {
                qualified: {icon: String.fromCodePoint(0x1F3AF), title: 'Qualified Leads', badge: 'QUALIFIED', color: '#3B82F6'},
                sitevisit: {icon: String.fromCodePoint(0x1F3E0), title: 'Site Visit Leads', badge: 'SITE VISIT', color: '#10B981'},
                leads: {icon: String.fromCodePoint(0x1F4CB), title: 'All Leads', badge: 'LEADS', color: '#E8A820'}
            };
            var conf = typeConf[type] || typeConf.leads;
            var icon = document.getElementById('ldm-icon');
            var titleEl = document.getElementById('ldm-title');
            var subEl = document.getElementById('ldm-subtitle');
            var badge = document.getElementById('ldm-badge');

            icon.style.background = conf.color + '18';
            icon.style.border = '1px solid ' + conf.color + '44';
            icon.textContent = conf.icon;
            titleEl.textContent = conf.title;
            if (campaignName === 'ALL') {
                subEl.textContent = 'All Campaigns — Google Ads Total';
            } else {
                subEl.textContent = 'Campaign: ' + campaignName;
            }
            badge.textContent = conf.badge;
            badge.style.background = conf.color + '18';
            badge.style.border = '1px solid ' + conf.color + '55';
            badge.style.color = conf.color;

            overlay.style.display = 'flex';
            requestAnimationFrame(function () {
                modal.style.opacity = '1';
                modal.style.transform = 'translateY(0) scale(1)';
            });

            const params = new URLSearchParams();
            params.set('action', 'fetch_lead_details');
            params.set('campaign_name', campaignName === 'ALL' ? 'ALL' : campaignName);
            params.set('type', type);
            params.set('platform', 'google');
            params.set('campaign_field', 'utm_campaignname');
            params.set('adgroup_field', 'utm_adgroupname');
            params.set('ad_field', 'utm_adname');

            try {
                const res = await fetch(`api.php?${params.toString()}`);
                const data = await res.json();
                document.getElementById('ldm-loading').style.display = 'none';

                if (!data.success) {
                    const errEl = document.getElementById('ldm-error');
                    errEl.textContent = 'Error: ' + (data.error || 'Failed to load data.');
                    errEl.style.display = 'block';
                    return;
                }

                _ldmAllLeads = data.leads || [];
                badge.textContent = conf.badge + ' · ' + _ldmAllLeads.length;
                renderLeadDetailsTable(_ldmAllLeads);
                document.getElementById('ldm-table-container').style.display = 'block';
            } catch (err) {
                document.getElementById('ldm-loading').style.display = 'none';
                const errEl2 = document.getElementById('ldm-error');
                errEl2.textContent = 'AJAX error: ' + (err.message || 'Failed to load lead details.');
                errEl2.style.display = 'block';
            }
        };

        window.closeLeadDetailsPopup = function () {
            var overlay = document.getElementById('lead-details-overlay');
            var modal = document.getElementById('lead-details-modal');
            if (modal) {
                modal.style.opacity = '0';
                modal.style.transform = 'translateY(18px) scale(0.97)';
            }
            setTimeout(function () {if (overlay) overlay.style.display = 'none';}, 220);
        };

        function renderLeadDetailsTable(leads) {
            var tbody = document.getElementById('ldm-tbody');
            var noResults = document.getElementById('ldm-no-results');
            if (!leads || leads.length === 0) {
                tbody.innerHTML = '';
                if (noResults) noResults.style.display = 'block';
                return;
            }
            if (noResults) noResults.style.display = 'none';
            tbody.innerHTML = leads.map(function (lead, i) {
                var rowBg = i % 2 === 0 ? 'transparent' : '#161D2E18';
                var sc = (lead.lead_status || '').toUpperCase() === 'QUALIFIED' ? '#3B82F6' : 'var(--pq-text-dim)';
                var statusHtml = lead.lead_status
                    ? '<span style="color:' + sc + '; font-weight:600; font-size:11px;">' + ldmEsc(lead.lead_status) + '</span>'
                    : '<span style="color:var(--pq-muted);">&#8212;</span>';
                return '<tr style="background:' + rowBg + '; border-bottom:1px solid #1E2A4233;" '
                    + 'onmouseover="this.style.background=\'#E8A82012\'" '
                        + 'onmouseout="this.style.background=\'' + rowBg + '\'">'
                            + '<td style="padding:9px 14px; color:var(--pq-muted); font-size:11px; font-family:\'JetBrains Mono\',monospace; white-space:nowrap;">' + (i + 1) + '</td>'
                                + '<td style="padding:9px 14px; font-family:\'JetBrains Mono\',monospace; font-size:11.5px; color:#E8A820; white-space:nowrap;">' + ldmEsc(lead.leadgen_id || '&#8212;') + '</td>'
                                    + '<td style="padding:9px 14px; font-size:11.5px; color:var(--pq-text-dim); white-space:nowrap; font-family:\'JetBrains Mono\',monospace;">' + ldmEsc(lead.created_date || '&#8212;') + '</td>'
                                        + '<td style="padding:9px 14px; font-size:12px; color:var(--pq-text); max-width:180px;"><div style="white-space:nowrap;overflow:hidden;text-overflow:ellipsis;" title="' + ldmEsc(lead.campaign_name || '') + '">' + ldmEsc(lead.campaign_name || '&#8212;') + '</div></td>'
                                        + '<td style="padding:9px 14px; font-size:11.5px; color:var(--pq-text-dim); max-width:160px;"><div style="white-space:nowrap;overflow:hidden;text-overflow:ellipsis;" title="' + ldmEsc(lead.adset_name || '') + '">' + ldmEsc(lead.adset_name || '&#8212;') + '</div></td>'
                                        + '<td style="padding:9px 14px; font-size:11.5px; color:var(--pq-text-dim); max-width:160px;"><div style="white-space:nowrap;overflow:hidden;text-overflow:ellipsis;" title="' + ldmEsc(lead.ad_name || '') + '">' + ldmEsc(lead.ad_name || '&#8212;') + '</div></td>'
                                        + '<td style="padding:9px 14px; white-space:nowrap;">' + statusHtml + '</td>'
                                        + '</tr>';
            }).join('');
        }

        window.filterLeadDetailsTable = function (query) {
            if (!_ldmAllLeads.length) return;
            var q = query.trim().toLowerCase();
            var filtered = q
                ? _ldmAllLeads.filter(function (l) {
                    return (l.leadgen_id || '').toLowerCase().includes(q)
                        || (l.campaign_name || '').toLowerCase().includes(q)
                        || (l.adset_name || '').toLowerCase().includes(q)
                        || (l.ad_name || '').toLowerCase().includes(q)
                        || (l.created_date || '').toLowerCase().includes(q);
                })
                : _ldmAllLeads;
            renderLeadDetailsTable(filtered);
            var badge = document.getElementById('ldm-badge');
            if (badge) {
                var labelPart = badge.textContent.split('·')[0].trim();
                badge.textContent = labelPart + ' · ' + filtered.length;
            }
        };

        function ldmEsc(str) {
            if (!str && str !== 0) return '';
            return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
        }

        document.addEventListener('keydown', function (e) {
            if (e.key === 'Escape') {
                var o = document.getElementById('lead-details-overlay');
                if (o && o.style.display !== 'none') closeLeadDetailsPopup();
            }
        });

        window.exportLeadDetailsToExcel = function () {
            if (!_ldmAllLeads || !_ldmAllLeads.length) {
                alert('No lead data to export.');
                return;
            }

            var badge = document.getElementById('ldm-badge');
            var badgeLabel = badge ? badge.textContent.split('·')[0].trim() : 'LEADS';
            var exportTypeText = badgeLabel === 'QUALIFIED' ? 'Qualified Leads' : 'All Google Leads';
            var titleEl = document.getElementById('ldm-title');
            var subEl = document.getElementById('ldm-subtitle');
            var campaignLabel = (subEl ? subEl.textContent : 'Campaign').replace(/[^a-zA-Z0-9_\- ]/g, '');

            var wsData = [];
            wsData.push(['Export Type:', exportTypeText]);
            wsData.push(['Campaign:', campaignLabel]);
            wsData.push(['Total Records:', _ldmAllLeads.length]);
            wsData.push(['Exported At:', new Date().toLocaleString('en-IN')]);
            wsData.push([]);
            wsData.push(['#', 'Leadgen ID', 'Created Date', 'Campaign Name', 'AdGroup Name', 'Ad Name', 'Status']);

            _ldmAllLeads.forEach(function (l, idx) {
                wsData.push([
                    idx + 1,
                    l.leadgen_id || '',
                    l.created_date || '',
                    l.campaign_name || '',
                    l.adset_name || '',
                    l.ad_name || '',
                    l.lead_status || ''
                ]);
            });

            var wb = XLSX.utils.book_new();
            var ws = XLSX.utils.aoa_to_sheet(wsData);
            XLSX.utils.book_append_sheet(wb, ws, 'Google Leads');
            var filename = 'Google_Leads_' + campaignLabel.replace(/\s+/g, '_') + '.xlsx';
            XLSX.writeFile(wb, filename);
        };
    </script>
    <!-- Google daily / weekly / monthly reports + monthly deck -->
    <script src="js/report_picker.js?v=4"></script>   <!-- "All campaigns or select campaigns?" before every download -->
    <script src="js/portfolio_pdf.js?v=5"></script>   <!-- "Export PDF (Meta + Google)" -->
    <script src="js/performance_reports.js?v=4"></script>
    <script>
        // "⟳ Sync with Google" — only campaigns saved for this project are shown (js/project_sync.js)
        ProjectSync.init({
            platform: 'google', label: 'Google', groupWord: 'ad groups',
            getRange: () => window.__psRange || {},
            onSaved: () => { if (typeof handleRefresh === 'function') handleRefresh(); },
        });
    </script>
    <script src="../assets/js/target_report.js?v=1"></script>   <!-- Target vs Achieved card -->
</body>

</html>

</html>