<?php
// ai_insights_api.php — Real AI-powered campaign analysis (Groq) for dashboard.php's AI Insights tab.
header('Content-Type: application/json');

require_once dirname(__DIR__, 2) . '/app/bootstrap.php';
require_once dirname(__DIR__, 2) . '/app/Core/db.php';   // login + roles & permissions check

$input = file_get_contents("php://input");

if (empty($input)) {
    http_response_code(400);
    die(json_encode([
        "success" => false,
        "message" => "No campaign data received."
    ]));
}

$prompt = <<<PROMPT
You are a Senior Meta Ads Performance Marketing Consultant with 15+ years of experience managing Facebook and Instagram Lead Generation campaigns for the Real Estate industry.

Your responsibility is to analyze Meta Ads campaign performance using ONLY the campaign metrics provided. Never assume or invent missing values.

Analyze the following metrics where available:

- Spend
- Impressions
- Reach
- Frequency
- Clicks
- Link Clicks
- CTR
- CPC
- CPM
- Landing Page Views
- CPSV (Cost Per Site Visit)
- Leads
- CPL
- Qualified Leads
- CPQL
- Lead Quality %
- Campaign Status

For every campaign:

1. Calculate a Health Score (0-100).
2. Determine the overall campaign status.
3. Identify strengths.
4. Identify weaknesses.
5. Explain the root cause of poor performance.
6. Analyze CPSV:
   - Is the Cost Per Site Visit efficient?
   - Is it high or low?
   - Explain the likely reason.
7. Recommend whether to:
   - Increase Budget
   - Maintain Budget
   - Reduce Budget
   - Pause Campaign
8. Suggest Creative improvements.
9. Suggest Audience improvements.
10. Suggest Landing Page improvements.
11. Set Priority (High / Medium / Low).
12. Write a concise Executive Summary.

Also compare all campaigns and identify:

- Best Campaign
- Worst Campaign
- Campaign Ready for Scaling
- Campaign Wasting Budget
- Overall Account Health

Return ONLY valid JSON.

Required JSON format:

{
  "overall_account": {
    "health_score": 85,
    "status": "Good",
    "summary": "",
    "best_campaign": "",
    "worst_campaign": "",
    "budget_wastage": "",
    "scale_recommendation": "",
    "top_5_actions": []
  },
  "campaigns": [
    {
      "campaign_name": "",
      "health_score": 80,
      "status": "",
      "strengths": [],
      "weaknesses": [],
      "root_cause": [],
      "cpsv_analysis": {
        "current_cpsv": "",
        "status": "",
        "recommendation": ""
      },
      "budget_action": "",
      "creative_recommendations": [],
      "audience_recommendations": [],
      "landing_page_recommendations": [],
      "priority": "",
      "expected_improvement": {
        "ctr": "",
        "cpl": "",
        "cpsv": "",
        "qualified_leads": ""
      },
      "executive_summary": ""
    }
  ]
}

Rules

- Health Score must be between 0 and 100.
- Status must be one of:
  "Excellent"
  "Good"
  "Needs Attention"
  "Critical"
- Priority must be:
  "High"
  "Medium"
  "Low"
- Analyze CPSV whenever it is available.
- Explain if a high CPSV indicates inefficient traffic quality or a landing page issue.
- Recommend ways to reduce CPSV.
- Use only the supplied metrics.
- Never fabricate values.
- Ignore missing metrics.
- Return a maximum of 8 campaigns.
- Keep recommendations concise and actionable.
- Return ONLY valid JSON.
- Do not use Markdown.
- Do not include explanatory text outside the JSON.

Campaign Data:

$input
PROMPT;
$post = [
    "model" => GROQ_MODEL,
    "temperature" => 0.4,
    "response_format" => [
        "type" => "json_object"
    ],
    "messages" => [
        [
            "role" => "system",
            "content" => "You are an expert Performance Marketing Consultant for Meta and Google Ads."
        ],
        [
            "role" => "user",
            "content" => $prompt
        ]
    ]
];

$ch = curl_init(GROQ_URL);

curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST => true,
    CURLOPT_TIMEOUT => 60,
    CURLOPT_HTTPHEADER => [
        "Authorization: Bearer " . GROQ_API_KEY,
        "Content-Type: application/json"
    ],
    CURLOPT_POSTFIELDS => json_encode($post)
]);

$response = curl_exec($ch);

if (curl_errno($ch)) {
    echo json_encode([
        "success" => false,
        "error" => curl_error($ch)
    ]);
    curl_close($ch);
    exit;
}

$http = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

$result = json_decode($response, true);

if ($http != 200) {
    echo json_encode([
        "success" => false,
        "response" => $result
    ]);
    exit;
}

$content = trim($result['choices'][0]['message']['content'] ?? '');
$json = json_decode($content, true);

if (json_last_error() !== JSON_ERROR_NONE) {
    echo json_encode([
        "success" => false,
        "raw" => $content
    ]);
    exit;
}

echo json_encode([
    "success" => true,
    "analysis" => $json
]);
