<?php
/**
 * Standalone Meta CRM lead-status updater.
 *
 * POST /meta_update_leads.php
 * Content-Type: application/json
 *
 * {
 *   "updates": [
 *     {
 *       "leadgen_id": "123456789",
 *       "mobile": "9876543210",
 *       "status": "QUALIFIED"
 *     }
 *   ]
 * }
 *
 * Source requirement:
 *   Only leads whose campaignsource is 'Facebook Lead form' (case-insensitive) are eligible.
 *
 * Matching priority:
 *   1. leadgen_id
 *   2. mobile (fallback)
 *
 * The endpoint updates only lead_status. It intentionally does not
 * write sub-status/site-visit fields because those columns are not
 * part of the current lead schema.
 */

declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    header('Allow: POST');
    respond([
        'success' => false,
        'message' => 'Only POST requests are allowed.'
    ]);
}

// Keep errors out of the JSON response in production.
ini_set('display_errors', '0');
error_reporting(E_ALL);

try {
    require_once dirname(__DIR__, 2) . '/app/Core/db.php';

    $payload = json_decode(file_get_contents('php://input'), true);

    if (!is_array($payload)) {
        respond([
            'success' => false,
            'message' => 'Invalid JSON request body.'
        ], 400);
    }

    $updates = $payload['updates'] ?? null;

    if (!is_array($updates)) {
        respond([
            'success' => false,
            'message' => 'The "updates" field must be an array.'
        ], 400);
    }

    if (count($updates) === 0) {
        respond([
            'success' => false,
            'message' => 'No lead updates were supplied.'
        ], 400);
    }

    // Prevent accidental giant imports from consuming the request.
    $maxUpdates = 5000;
    if (count($updates) > $maxUpdates) {
        respond([
            'success' => false,
            'message' => "Maximum {$maxUpdates} `lead` updates are allowed per request."
        ], 400);
    }

    $databases = [];
    foreach (leadDbs('all') as $dbKeyName => $dbConnection) {   // every database in LEAD_DATABASES
        $databases[] = [
            'key' => $dbKeyName,
            'name' => leadDbLabel($dbKeyName),
            'connection' => $dbConnection
        ];
    }

    if (!$databases) {
        respond([
            'success' => false,
            'message' => 'No CRM database connections are available.'
        ], 500);
    }

    foreach ($databases as $database) {
        if ($database['connection']->connect_errno) {
            respond([
                'success' => false,
                'message' => 'CRM database connection failed.',
                'database' => $database['key']
            ], 500);
        }
    }

    $results = [];
    $summary = [
        'received' => count($updates),
        'updated' => 0,
        'not_found' => 0,
        'invalid' => 0,
        'errors' => 0,
        'matched_by_leadgen_id' => 0,
        'matched_by_mobile' => 0,
        'pseudo_updated' => 0,
        'official_updated' => 0
    ];

    // Prepared statements are created once per database and reused.
    $statements = [];

    foreach ($databases as $database) {
        /** @var mysqli $db */
        $db = $database['connection'];

        $findByLeadgen = $db->prepare(
            "SELECT id, leadgen_id, mobile, lead_status, campaignsource
             FROM `lead`
             WHERE leadgen_id = ?
               AND LOWER(TRIM(campaignsource)) = LOWER(?)
             LIMIT 1"
        );

        $findByMobile = $db->prepare(
            "SELECT id, leadgen_id, mobile, lead_status, campaignsource
             FROM `lead`
             WHERE (mobile = ?
                OR mobile = ?
                OR mobile = ?
                OR mobile = ?)
               AND LOWER(TRIM(campaignsource)) = LOWER(?)
             LIMIT 1"
        );

        $updateById = $db->prepare(
            "UPDATE `lead`
             SET lead_status = ?
             WHERE id = ?
             LIMIT 1"
        );

        if (!$findByLeadgen || !$findByMobile || !$updateById) {
            respond([
                'success' => false,
                'message' => 'Unable to prepare CRM lead statements.',
                'database' => $database['key']
            ], 500);
        }

        $statements[$database['key']] = [
            'find_by_leadgen' => $findByLeadgen,
            'find_by_mobile' => $findByMobile,
            'update_by_id' => $updateById
        ];
    }

    foreach ($updates as $index => $item) {
        if (!is_array($item)) {
            $summary['invalid']++;
            $results[] = [
                'index' => $index,
                'success' => false,
                'status' => 'invalid',
                'message' => 'Update item must be an object.'
            ];
            continue;
        }

        $leadgenId = normalizeIdentifier($item['leadgen_id'] ?? '');
        $mobile = normalizeMobile($item['mobile'] ?? '');
        $status = normalizeStatus($item['status'] ?? '');

        if ($status === '') {
            $summary['invalid']++;
            $results[] = [
                'index' => $index,
                'success' => false,
                'status' => 'invalid',
                'message' => 'A non-empty status is required.',
                'leadgen_id' => $leadgenId,
                'mobile' => $mobile
            ];
            continue;
        }

        if ($leadgenId === '' && $mobile === '') {
            $summary['invalid']++;
            $results[] = [
                'index' => $index,
                'success' => false,
                'status' => 'invalid',
                'message' => 'Either leadgen_id or mobile is required.'
            ];
            continue;
        }

        $matched = false;
        $matchedDatabase = null;
        $matchedBy = null;
        $matchedLead = null;
        $previousStatus = null;
        $updateError = null;

        // Search both databases. leadgen_id always has priority over mobile.
        foreach ($databases as $database) {
            $dbKey = $database['key'];
            $db = $database['connection'];
            $dbStatements = $statements[$dbKey];

            $row = null;
            $matchMethod = null;

            if ($leadgenId !== '') {
                $find = $dbStatements['find_by_leadgen'];
                $campaignSource = 'Facebook Lead form';
                $find->bind_param('ss', $leadgenId, $campaignSource);

                if (!$find->execute()) {
                    $updateError = $find->error;
                    continue;
                }

                $row = fetchLeadRow($find);

                if ($row) {
                    $matchMethod = 'leadgen_id';
                }
            }

            if (!$row && $mobile !== '') {
                $find = $dbStatements['find_by_mobile'];

                // Support common CRM storage formats:
                // 9876543210
                // 919876543210
                // +919876543210
                // p:+919876543210
                $mobile91 = '91' . $mobile;
                $mobilePlus91 = '+91' . $mobile;
                $mobilePPlus91 = 'p:+91' . $mobile;

                $campaignSource = 'Facebook Lead form';
                $find->bind_param(
                    'sssss',
                    $mobile,
                    $mobile91,
                    $mobilePlus91,
                    $mobilePPlus91,
                    $campaignSource
                );

                if (!$find->execute()) {
                    $updateError = $find->error;
                    continue;
                }

                $row = fetchLeadRow($find);

                if ($row) {
                    $matchMethod = 'mobile';
                }
            }

            if (!$row) {
                continue;
            }

            $matched = true;
            $matchedDatabase = $database;
            $matchedBy = $matchMethod;
            $matchedLead = $row;
            $previousStatus = $row['lead_status'] ?? null;
            $matchedCampaignSource = $row['campaignsource'] ?? null;

            $leadId = (string) ($row['id'] ?? '');
            if ($leadId === '') {
                $updateError = 'Matched lead has no internal id.';
                break;
            }

            $update = $dbStatements['update_by_id'];
            $update->bind_param('ss', $status, $leadId);

            if (!$update->execute()) {
                $updateError = $update->error;
                break;
            }

            $summary['updated']++;
            if ($matchedBy === 'leadgen_id') {
                $summary['matched_by_leadgen_id']++;
            } else {
                $summary['matched_by_mobile']++;
            }

            // per-database count (pseudo_updated / official_updated kept for older screens)
            $summary[$dbKey . '_updated'] = ($summary[$dbKey . '_updated'] ?? 0) + 1;
            $summary['updated_by_database'][$dbKey] = ($summary['updated_by_database'][$dbKey] ?? 0) + 1;

            $results[] = [
                'index' => $index,
                'success' => true,
                'status' => 'updated',
                'database' => $dbKey,
                'database_name' => $database['name'],
                'match_method' => $matchedBy,
                'leadgen_id' => $leadgenId,
                'mobile' => $mobile,
                'crm_lead_id' => $leadId,
                'previous_status' => $previousStatus,
                'campaign_source' => $matchedCampaignSource,
                'new_status' => $status,
                'rows_affected' => $update->affected_rows
            ];

            // A lead should only be updated once. This also prevents a duplicate
            // mobile number in both DBs from being changed in both databases.
            break;
        }

        if ($updateError !== null && !$matched) {
            $summary['errors']++;
            $results[] = [
                'index' => $index,
                'success' => false,
                'status' => 'error',
                'message' => 'Database error while matching the lead.',
                'leadgen_id' => $leadgenId,
                'mobile' => $mobile
            ];
            continue;
        }

        if ($matched && $updateError !== null) {
            $summary['errors']++;
            // The previous result is not appended until after a successful update,
            // so this branch is only relevant if a future code change alters that flow.
            $results[] = [
                'index' => $index,
                'success' => false,
                'status' => 'error',
                'message' => 'Database error while updating the lead.',
                'database' => $matchedDatabase['key'] ?? null,
                'leadgen_id' => $leadgenId,
                'mobile' => $mobile
            ];
            continue;
        }

        if (!$matched) {
            $summary['not_found']++;
            $results[] = [
                'index' => $index,
                'success' => false,
                'status' => 'not_found',
                'message' => 'No matching lead with campaignsource = Facebook Lead form was found in either CRM database.',
                'leadgen_id' => $leadgenId,
                'mobile' => $mobile
            ];
        }
    }

    foreach ($statements as $dbStatements) {
        foreach ($dbStatements as $statement) {
            if ($statement instanceof mysqli_stmt) {
                $statement->close();
            }
        }
    }

    $httpStatus = $summary['errors'] > 0 && $summary['updated'] === 0 ? 500 : 200;

    respond([
        'success' => $summary['errors'] === 0,
        'message' => buildSummaryMessage($summary),
        'summary' => $summary,
        'results' => $results
    ], $httpStatus);
} catch (Throwable $e) {
    error_log('meta_update_leads.php: ' . $e->getMessage());

    respond([
        'success' => false,
        'message' => 'Unexpected server error while updating CRM leads.'
    ], 500);
}

/**
 * Send a JSON response and stop execution.
 */
function respond(array $payload, int $statusCode = 200): void
{
    http_response_code($statusCode);
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

/**
 * Fetch one lead row without relying on mysqli_stmt::get_result().
 * This works even when PHP was built without the mysqlnd extension.
 */
function fetchLeadRow(mysqli_stmt $stmt): ?array
{
    $stmt->store_result();

    if ($stmt->num_rows < 1) {
        $stmt->free_result();
        return null;
    }

    $id = null;
    $leadgenId = null;
    $mobile = null;
    $leadStatus = null;
    $campaignSource = null;

    $stmt->bind_result($id, $leadgenId, $mobile, $leadStatus, $campaignSource);

    if (!$stmt->fetch()) {
        $stmt->free_result();
        return null;
    }

    $stmt->free_result();

    return [
        'id' => $id,
        'leadgen_id' => $leadgenId,
        'mobile' => $mobile,
        'lead_status' => $leadStatus,
        'campaignsource' => $campaignSource
    ];
}

/**
 * Normalize an identifier without changing its meaningful value.
 */
function normalizeIdentifier($value): string
{
    if (is_array($value) || is_object($value)) {
        return '';
    }

    return trim((string) $value);
}

/**
 * Normalize Indian/international mobile input for matching.
 *
 * We retain digits only and, for a leading +91 / 91 number, use the
 * last 10 digits. This lets Excel values such as +91 98765 43210
 * match a CRM value stored as 9876543210.
 */
function normalizeMobile($value): string
{
    if (is_array($value) || is_object($value)) {
        return '';
    }

    $mobile = trim((string) $value);
    if ($mobile === '') {
        return '';
    }

    $digits = preg_replace('/\D+/', '', $mobile);
    if ($digits === null || $digits === '') {
        return '';
    }

    if (strlen($digits) > 10 && substr($digits, -10) !== '') {
        return substr($digits, -10);
    }

    return $digits;
}

/**
 * Normalize CRM status while preserving the user's supplied wording.
 */
function normalizeStatus($value): string
{
    if (is_array($value) || is_object($value)) {
        return '';
    }

    $status = trim((string) $value);
    if ($status === '') {
        return '';
    }

    // Avoid control characters and keep the DB write bounded.
    $status = preg_replace('/[\x00-\x1F\x7F]/u', '', $status) ?? '';
    return mb_substr(trim($status), 0, 255);
}

function buildSummaryMessage(array $summary): string
{
    return sprintf(
        'Processed %d leads: %d updated, %d not found, %d invalid, %d errors.',
        $summary['received'],
        $summary['updated'],
        $summary['not_found'],
        $summary['invalid'],
        $summary['errors']
    );
}
