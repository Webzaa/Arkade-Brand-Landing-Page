<?php
/**
 * Moved: Meta and Google unmapped leads now live in one place — dashboard.php#unmapped
 * (public/unmapped_leads.php). Taboola keeps using unmapped.php?platform=taboola.
 */
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}
if (strtolower((string) ($_GET['platform'] ?? '')) !== 'taboola') {
if (($_SESSION['user_logged'] ?? '') !== 'Y') {
    header('Location: ../login.php');
    exit;
}
$pqTab = 'google';
?><!DOCTYPE html><html><head><meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1"><title>Unmapped Leads</title>
<script>try { localStorage.setItem('pq-unmapped-tab', <?= json_encode($pqTab) ?>); } catch (e) {}
location.replace('../dashboard.php#unmapped');</script></head>
<body style="font-family:sans-serif;padding:24px;">Opening <a href="../dashboard.php#unmapped">Unmapped Leads</a>…</body></html>
<?php exit; }
//ini_set('display_errors', '1');
//ini_set('display_startup_errors', '1');
//error_reporting(E_ALL);
require_once dirname(__DIR__, 2) . '/app/Core/db.php';
if (!isset($_SESSION["user_logged"]) || $_SESSION["user_logged"] != "Y") {
    header("Location: ../login.php");
    exit;
}
?>
<!DOCTYPE html>
<html>

<head>
    <title>Unmapped Leads</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css" />
    <style>
        /* Dark Theme for DateRangePicker */
        .daterangepicker {
            background-color: #1a1d27;
            border: 1px solid #2d3148;
            color: #fff;
        }

        .daterangepicker .calendar-table {
            background-color: #1a1d27;
            border: none;
        }

        .daterangepicker td.off,
        .daterangepicker td.off.in-range,
        .daterangepicker td.off.start-date,
        .daterangepicker td.off.end-date {
            background-color: #0f1117;
            color: #4a5568;
            border-color: transparent;
        }

        .daterangepicker td.available:hover,
        .daterangepicker th.available:hover {
            background-color: #2d3148;
        }

        .daterangepicker td.in-range {
            background-color: #2d3148;
            color: #fff;
        }

        .daterangepicker td.active,
        .daterangepicker td.active:hover {
            background-color: #4f46e5;
            color: #fff;
        }

        .daterangepicker .ranges li:hover {
            background-color: #2d3148;
        }

        .daterangepicker .ranges li.active {
            background-color: #4f46e5;
        }

        .daterangepicker .drp-buttons {
            border-top: 1px solid #2d3148;
        }

        .daterangepicker .cancelBtn {
            background-color: #1e2130;
            border: 1px solid #2d3148;
            color: #fff;
        }

        .daterangepicker .applyBtn {
            background-color: #4f46e5;
            border: none;
            color: #fff;
        }

        .daterangepicker select.monthselect,
        .daterangepicker select.yearselect {
            background: #0f1117;
            color: #fff;
            border: 1px solid #2d3148;
            padding: 2px;
            border-radius: 4px;
        }
    </style>
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            background: #0f1117;
            color: #fff;
            font-family: 'Segoe UI', sans-serif;
            padding: 24px;
        }

        .page-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 24px;
            flex-wrap: wrap;
            gap: 12px;
        }

        .page-header h2 {
            font-size: 20px;
            font-weight: 600;
        }

        .badge {
            background: #1e2130;
            color: #a0aec0;
            font-size: 13px;
            padding: 7px 10px;
            border-radius: 20px;
            margin-left: 10px;
        }

        .card {
            background: #1a1d27;
            border-radius: 12px;
            padding: 20px;
            border: 1px solid #2d3148;
        }

        .btn {
            padding: 8px 16px;
            border-radius: 6px;
            border: none;
            font-size: 12px;
            font-weight: 600;
            cursor: pointer;
            white-space: nowrap;
        }

        .btn-primary {
            background: #4f46e5;
            color: #fff;
        }

        .btn-primary:hover {
            background: #4338ca;
        }

        .btn-success {
            background: #16a34a;
            color: #fff;
        }

        .btn-ghost {
            background: #1e2130;
            color: #a0aec0;
            border: 1px solid #2d3148;
        }

        .btn-ghost:hover {
            background: #2d3148;
            color: #fff;
        }

        .btn.saved {
            background: #16a34a;
        }

        .status-active-test {
            background: #854d0e;
            color: #fef08a;
            border: 1px solid #ca8a04;
        }

        .status-active-junk {
            background: #7f1d1d;
            color: #fca5a5;
            border: 1px solid #dc2626;
        }

        /* Progress bar */
        .import-progress {
            display: none;
            margin-top: 16px;
        }

        .progress-bar-wrap {
            background: #1e2130;
            border-radius: 8px;
            height: 10px;
            overflow: hidden;
        }

        .progress-bar-fill {
            background: #4f46e5;
            height: 100%;
            width: 0%;
            transition: width 0.3s;
            border-radius: 8px;
        }

        .progress-label {
            font-size: 12px;
            color: #a0aec0;
            margin-top: 6px;
        }

        #unmappedTable_wrapper .dataTables_filter,
        #unmappedTable_wrapper .dataTables_length {
            margin-bottom: 16px;
        }

        #unmappedTable_wrapper .dataTables_filter input {
            background: #0f1117;
            border: 1px solid #2d3148;
            color: #fff;
            border-radius: 6px;
            padding: 6px 10px;
            margin-left: 8px;
        }

        #unmappedTable_wrapper .dataTables_length select {
            background: #0f1117;
            border: 1px solid #2d3148;
            color: #fff;
            border-radius: 6px;
            padding: 4px 8px;
        }

        #unmappedTable_wrapper .dataTables_info,
        #unmappedTable_wrapper .dataTables_length,
        #unmappedTable_wrapper .dataTables_filter {
            color: #a0aec0;
            font-size: 13px;
        }

        #unmappedTable_wrapper .dataTables_paginate .paginate_button {
            background: #0f1117 !important;
            color: #a0aec0 !important;
            border: 1px solid #2d3148 !important;
            border-radius: 6px !important;
            margin: 2px;
        }

        #unmappedTable_wrapper .dataTables_paginate .paginate_button.current {
            background: #4f46e5 !important;
            color: #fff !important;
            border-color: #4f46e5 !important;
        }

        #unmappedTable_wrapper .dataTables_paginate .paginate_button:hover {
            background: #2d3148 !important;
            color: #fff !important;
        }

        table#unmappedTable {
            width: 100% !important;
            border-collapse: collapse;
        }

        table#unmappedTable thead th {
            background: #0f1117;
            color: #a0aec0;
            font-size: 12px;
            font-weight: 600;
            text-transform: uppercase;
            padding: 12px 10px;
            border-bottom: 1px solid #2d3148;
            white-space: nowrap;
        }

        table#unmappedTable tbody tr {
            border-bottom: 1px solid #1e2130;
        }

        table#unmappedTable tbody tr:hover {
            background: #1e2130;
        }

        table#unmappedTable tbody td {
            padding: 10px;
            font-size: 13px;
            color: #e2e8f0;
            vertical-align: middle;
        }

        .uid-cell {
            font-family: monospace;
            font-size: 11px;
            color: #a0aec0;
            max-width: 140px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            display: block;
        }

        tr:hover .uid-copy-btn {
            display: inline-block !important;
        }

        select.dd {
            background: #0f1117;
            color: #fff;
            border: 1px solid #2d3148;
            padding: 6px 8px;
            border-radius: 6px;
            font-size: 12px;
            width: 100%;
            min-width: 150px;
        }

        select.dd:disabled {
            opacity: 0.35;
            cursor: not-allowed;
        }

        select.dd:focus {
            outline: none;
            border-color: #4f46e5;
        }

        .loading {
            color: #a0aec0;
            font-size: 14px;
            text-align: center;
            padding: 40px;
        }
    </style>
<?= function_exists('pqDatesTag') ? pqDatesTag('../') : '' ?>
</head>

<body>


    <!--  ===m=== Model Pop up for Junk + Test + Save -->
    <div class="modal fade" id="confirmModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content" style="background: #1a1d27; color: #fff; border: 1px solid #2d3148;">
                <div class="modal-header" style="border-bottom: 1px solid #2d3148;">
                    <h5 class="modal-title" style="font-size: 16px; font-weight: 600;">Confirm Action</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"
                        aria-label="Close"></button>
                </div>
                <div class="modal-body" style="font-size: 14px; color: #e2e8f0;">
                    Are you sure you want to <strong id="modalActionText"></strong> this lead [<span
                        id="modalLeadText"></span>]?
                </div>
                <div class="modal-footer" style="border-top: 1px solid #2d3148;">
                    <button type="button" class="btn btn-ghost" data-bs-dismiss="modal">No, Cancel</button>
                    <button type="button" class="btn btn-primary" id="confirmBtn">Yes, Proceed</button>
                </div>
            </div>
        </div>
    </div>

    <div class="page-header-wrapper" style="display: flex; flex-direction: column; gap: 16px; margin-bottom: 24px;">

        <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 12px;">

            <!-- <h2 style="font-size: 24px; font-weight: 600; margin: 0;">Unmapped Leads</h2> -->

            <div style="display: flex; align-items: center; gap: 12px; flex-wrap: wrap;">
                <h2 style="font-size: 24px; font-weight: 600; margin: 0;">Unmapped Leads</h2>
                <span class="badge" id="absoluteTotalCount" style="margin:0;">Total:
                    Loading...</span>
                <span class="badge" id="totalCount"
                    style="margin:0; background: #3730a3; color: #e0e7ff; border: 1px solid #4f46e5;">Selected:
                    Loading...</span>
            </div>

            <div style="display:flex; gap:8px; flex-wrap:wrap;">
                <button class="btn btn-ghost" onclick="downloadTemplate()">Download Import Format</button>
                <label class="btn btn-ghost" style="cursor:pointer; margin:0;">
                    ↑ Import CSV
                    <input type="file" id="importFile" accept=".csv" style="display:none;"
                        onchange="handleImport(event)">
                </label>
                <button class="btn btn-ghost" onclick="exportCSV()">↓ Export CSV</button>
                <?php if (count(leadDbKeys()) > 1) { $pqCur = (string) ($_GET['db'] ?? appDbKey()); ?>
                <label class="btn btn-ghost" style="display:inline-flex;align-items:center;gap:6px;cursor:default;">Database
                    <select onchange="(function(v){const u=new URL(location.href);u.searchParams.set('db',v);location.href=u.toString();})(this.value)"
                        style="background:transparent;color:inherit;border:1px solid currentColor;border-radius:6px;padding:2px 6px;font:inherit;">
                        <?php foreach (leadDbLabels() as $k => $lbl) { ?>
                            <option value="<?= htmlspecialchars($k) ?>" <?= $k === $pqCur ? 'selected' : '' ?>><?= htmlspecialchars($lbl) ?></option>
                        <?php } ?>
                    </select>
                </label>
                <?php } ?>
                <button class="btn btn-ghost" onclick="window.opener ? window.close() : (window.history.length > 1 ? window.history.back() : window.location.href='../dashboard.php')">‹ Back to Dashboard</button>
            </div>
        </div>

        <div
            style="display: flex; flex-wrap: wrap; align-items: center; gap: 16px; background: #1a1d27; padding: 14px 16px; border-radius: 8px; border: 1px solid #2d3148;">

            <!-- ===m=== Badges ===m=== -->
            <!-- <div style="display: flex; gap: 8px;">
                <span class="badge" id="absoluteTotalCount"
                    style="margin:0; background: #3730a3; color: #e0e7ff; border: 1px solid #4f46e5;">Total:
                    Loading...</span>
                <span class="badge" id="totalCount" style="margin:0;">Selected: Loading...</span>
            </div> -->

            <!-- ===m=== Divider ===m=== -->
            <!-- <div style="width: 1px; height: 24px; background: #2d3148; display: block;"></div> -->

            <!-- ===m=== Filters ===m=== -->
            <div style="display: flex; flex-wrap: wrap; align-items: center; gap: 26rem;">
                <div style="display:flex; align-items:center; gap:6px;">
                    <span style="font-size: 11px; color: #a0aec0; font-weight: 600; letter-spacing: 0.5px;">DATE:</span>
                    <input type="text" id="dateFilter"
                        style="background: #0f1117; border: 1px solid #2d3148; color: #fff; border-radius: 6px; padding: 6px 10px; font-size: 13px; width: 195px; cursor: pointer;"
                        readonly>
                </div>

                <!-- <div style="display:flex; align-items:center; gap:6px;">
                    <span
                        style="font-size: 11px; color: #a0aec0; font-weight: 600; letter-spacing: 0.5px;">CAMPAIGNSOURCE:</span>
                    <select id="sourceFilter"
                        style="background: #0f1117; border: 1px solid #2d3148; color: #fff; border-radius: 6px; padding: 6px 10px; font-size: 13px; min-width: 120px;"
                        onchange="applyFilters()">
                        <option value="">All Sources</option>
                    </select>
                </div> -->

                <div style="display:flex; align-items:center; gap:6px;">
                    <span style="font-size: 11px; color: #a0aec0; font-weight: 600; letter-spacing: 0.5px;">LEAD
                        STATUS:</span>
                    <select id="statusFilter"
                        style="background: #0f1117; border: 1px solid #2d3148; color: #fff; border-radius: 6px; padding: 6px 10px; font-size: 13px; min-width: 120px;"
                        onchange="applyFilters()">
                        <option value="">All Statuses</option>
                    </select>
                </div>
            </div>

            <!-- ===m=== Divider ===m=== -->
            <div style="width: 1px; height: 24px; background: #2d3148; display: block;"></div>

            <!-- ===m=== Global Search ===m==== -->
            <div style="display: flex; flex-wrap: wrap; align-items: center; gap: 8px; flex-grow: 1;">
                <span style="font-size: 11px; color: #a0aec0; font-weight: 600; letter-spacing: 0.5px;">GLOBAL
                    SEARCH:</span>
                <input type="text" id="globalSearchInput" placeholder="Enter Mobile OR GCLID..."
                    style="background: #0f1117; border: 1px solid #2d3148; color: #fff; border-radius: 6px; padding: 6px 10px; font-size: 13px; flex-grow: 1; min-width: 150px; max-width: 250px;">
                <button class="btn btn-primary" onclick="executeGlobalSearch()"
                    style="padding: 6px 12px;">Search</button>
                <button class="btn btn-ghost" onclick="clearGlobalSearch()" style="padding: 6px 12px;">Clear</button>
            </div>

        </div>
    </div>

    <!-- ===m=== Import progress bar ===m=== -->
    <div class="import-progress" id="importProgress">
        <div class="progress-bar-wrap">
            <div class="progress-bar-fill" id="progressFill"></div>
        </div>
        <div class="progress-label" id="progressLabel">Importing 0 / 0...</div>
    </div>

    <div class="card" style="margin-top: 16px;">
        <table id="unmappedTable">
            <thead>
                <tr id="tableHeaders">
                    <th>Unique ID</th>
                    <th>Lead Created</th>
                    <th>Campaign Name</th>
                    <th>Ad Group</th>
                    <th>Ad Name</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody id="unmappedBody">
                <tr>
                    <td colspan="7" class="loading">Loading...</td>
                </tr>
            </tbody>
        </table>
    </div>

    <script src="https://unpkg.com/xlsx@0.18.5/dist/xlsx.full.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="https://cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>
    <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js"></script>
    <script>
        // Send the chosen lead database (?db=…) with every call to this page's API
        (function () {
            const db = new URLSearchParams(location.search).get('db');
            if (!db) return;
            const orig = window.fetch;
            window.fetch = function (u, o) {
                if (typeof u === 'string' && /^unmapped(_meta)?_api\.php/.test(u)) {
                    u += (u.includes('?') ? '&' : '?') + 'db=' + encodeURIComponent(db);
                }
                return orig.call(this, u, o);
            };
        })();
    </script>
    <script>
        const urlParams = new URLSearchParams(window.location.search);
        const platform = urlParams.get('platform') || '';

        let campaigns = [],
            adgroups = [],
            ads = [],
            allLeads = [],
            dtTable = null;
        let allTimeCount = 0; // Added variable to track all-time count

        // ===m=== Copy Option ===m===
        function copyUID(uid, btn) {
            navigator.clipboard.writeText(uid).then(() => {
                btn.textContent = '✓';
                btn.style.color = '#16a34a';
                btn.style.borderColor = '#16a34a';

                setTimeout(() => {
                    btn.textContent = '⎘';
                    btn.style.color = '#a0aec0';
                    btn.style.borderColor = '#2d3148';
                }, 1500);
            });
        }

        // ===m=== Load master data & Initialize Date Picker ===m===
        async function init() {
            const trHead = document.getElementById('tableHeaders');
            if (platform.toLowerCase() === 'taboola') {
                document.title = "Unmapped Taboola Leads";
                const h2El = document.querySelector('.page-header-wrapper h2');
                if (h2El) h2El.innerText = "Unmapped Taboola Leads";

                if (trHead) {
                    trHead.innerHTML = `
                        <th>Unique ID</th>
                        <th>Lead Created</th>
                        <th>Ad Creative</th>
                        <th>Campaign Name</th>
                        <th>Adset</th>
                        <th>Ad Name</th>
                        <th>Status</th>
                        <th>Action</th>
                    `;
                }
            } else {
                if (trHead) {
                    trHead.innerHTML = `
                        <th>Unique ID</th>
                        <th>Lead Created</th>
                        <th>Campaign Name</th>
                        <th>Ad Group</th>
                        <th>Ad Name</th>
                        <th>Status</th>
                        <th>Action</th>
                    `;
                }
            }

            const masterRes = await fetch(`unmapped_api.php?action=master&platform=${platform}`);
            const masterData = await masterRes.json();

            campaigns = masterData.campaigns || [];
            adgroups = masterData.adgroups || [];
            ads = masterData.ads || [];

            // const sourceSelect = document.getElementById('sourceFilter');
            // if (masterData.sources) {
            //     masterData.sources.forEach(s => {
            //         sourceSelect.innerHTML += `<option value="${s}">${s}</option>`;
            //     });
            // }

            const statusSelect = document.getElementById('statusFilter');
            if (masterData.statuses) {
                masterData.statuses.forEach(s => {
                    statusSelect.innerHTML += `<option value="${s}">${s}</option>`;
                });
            }

            // Set All-Time Total
            allTimeCount = parseInt(masterData.total_all_time) || 0;
            document.getElementById('absoluteTotalCount').textContent = 'Total Leads: ' + allTimeCount;

            let start = moment().subtract(29, 'days');
            let end = moment();

            $('#dateFilter').daterangepicker({
                startDate: start,
                endDate: end,
                alwaysShowCalendars: true,
                locale: {
                    format: 'DD/MM/YYYY' // Forces a clean visual format in your input box
                },
                ranges: {
                    'Today': [moment(), moment()],
                    'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
                    'Last 7 Days': [moment().subtract(6, 'days'), moment()],
                    'Last 30 Days': [moment().subtract(29, 'days'), moment()],
                    'This Month': [moment().startOf('month'), moment().endOf('month')],
                    'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')],
                    'Last 1 Year': [moment().subtract(1, 'year').add(1, 'day'), moment()],
                    'All Time': [moment(window.PQ_ALL_SINCE || moment().subtract(1, 'year').format('YYYY-MM-DD'), 'YYYY-MM-DD'), moment()]   // from the project's first lead (app/Core/access.php pqAllTimeSince)
                }
            });

            // THIS LISTENER IS 100% RELIABLE - Triggers every time you apply a date
            $('#dateFilter').on('apply.daterangepicker', function (ev, picker) {
                loadLeads(picker.startDate.format('YYYY-MM-DD'), picker.endDate.format('YYYY-MM-DD'));
            });

            // Call it manually once on page load to fetch the initial 30 days
            loadLeads(start.format('YYYY-MM-DD'), end.format('YYYY-MM-DD'));
        }

        // Function to fetch leads based on date range or global search
        async function loadLeads(startDate, endDate, searchQuery = '') {

            try {

                if (searchQuery) {
                    document.getElementById('totalCount').textContent = 'Search Results: Loading...';
                } else {
                    document.getElementById('totalCount').textContent = 'Selected Range: Loading...';
                }

                // Destroy existing DataTable
                if ($.fn.DataTable.isDataTable('#unmappedTable')) {
                    $('#unmappedTable').DataTable().clear().destroy();
                }

                const isTaboola = platform.toLowerCase() === 'taboola';
                const colSpan = isTaboola ? 8 : 7;

                const tbody = document.getElementById('unmappedBody');
                tbody.innerHTML = `
            <tr>
                <td colspan="${colSpan}" class="loading">Loading data...</td>
            </tr>
        `;
                // const source = document.getElementById('sourceFilter').value;
                const status = document.getElementById('statusFilter').value;

                // const url = `unmapped_api.php?action=unmapped&start=${encodeURIComponent(startDate)}&end=${encodeURIComponent(endDate)}&search=${encodeURIComponent(searchQuery)}&source=${encodeURIComponent(source)}&status=${encodeURIComponent(status)}`;
                const url = `unmapped_api.php?action=unmapped&start=${encodeURIComponent(startDate)}&end=${encodeURIComponent(endDate)}&search=${encodeURIComponent(searchQuery)}&status=${encodeURIComponent(status)}&platform=${platform}`;

                console.log("Fetching:", url);

                const res = await fetch(url);

                if (!res.ok) {
                    throw new Error("HTTP Error : " + res.status);
                }

                const data = await res.json();

                console.log(data);

                allLeads = Array.isArray(data.leads) ? data.leads : [];

                // Remove loading row
                tbody.innerHTML = '';

                renderTable(allLeads);

            } catch (err) {
                console.error(err);

                const isTaboola = platform.toLowerCase() === 'taboola';
                const colSpan = isTaboola ? 8 : 7;

                document.getElementById('unmappedBody').innerHTML = `
            <tr>
                <td colspan="${colSpan}" class="loading">
                    Failed to load data.
                </td>
            </tr>
        `;
            }
        }

        function applyFilters() {
            const query = document.getElementById('globalSearchInput').value.trim();
            let sd = '', ed = '';

            if (!query) {
                const picker = $('#dateFilter').data('daterangepicker');
                if (picker) {
                    sd = picker.startDate.format('YYYY-MM-DD');
                    ed = picker.endDate.format('YYYY-MM-DD');
                }
            }
            loadLeads(sd, ed, query);
        }

        function executeGlobalSearch() {
            applyFilters();
        }

        function clearGlobalSearch() {
            document.getElementById('globalSearchInput').value = '';
            // document.getElementById('sourceFilter').value = ''; 
            document.getElementById('statusFilter').value = '';

            applyFilters();
        }

        // function executeGlobalSearch() {
        //     const query = document.getElementById('globalSearchInput').value.trim();
        //     if (!query) return;
        //     loadLeads('', '', query);
        // }

        // function clearGlobalSearch() {
        //     document.getElementById('globalSearchInput').value = '';
        //     const picker = $('#dateFilter').data('daterangepicker');
        //     loadLeads(picker.startDate.format('YYYY-MM-DD'), picker.endDate.format('YYYY-MM-DD'));
        // }

        function renderTable(leads) {
            const tbody = document.getElementById('unmappedBody');
            tbody.innerHTML = '';
            document.getElementById('totalCount').textContent = 'Selected Range: ' + leads.length + ' rows';

            if (!leads.length) {
                tbody.innerHTML = '';
                initDT();
                return;
            }

            const isTaboola = platform.toLowerCase() === 'taboola';

            const campOptions = campaigns.map(c =>
                `<option value="${c.campaign_id}" data-name="${c.campaign_name}">${c.campaign_name}</option>`
            ).join('');

            // For Taboola: adset dropdown (independent of campaign)
            const adsetOptions = adgroups.map(ag =>
                `<option value="${ag.adgroup_id}" data-name="${ag.adgroup_name}">${ag.adgroup_name}</option>`
            ).join('');

            leads.forEach((lead, i) => {
                const uid = lead.gclid || lead.mobile || '';   // mobile is masked by the server for some users
                const rawDate = lead.createddate ? lead.createddate.split(' ')[0] : '';
                const displayDate = rawDate ? rawDate.split('-').reverse().join('-') : '—';
                const isTest = uid.toLowerCase().includes('test') || !!lead.is_test;
                const autoStatus = isTest ? 'TEST' : '';

                const tr = document.createElement('tr');

                if (isTaboola) {
                    // ── Taboola row: show adcreative (read-only) + campaign dropdown + adset dropdown ──
                    const creativeDisplay = lead.adcreative || '—';
                    const adsetDisplay    = lead.adset     || '—';
                    tr.innerHTML = `
<td>
    <div style="display:flex; align-items:center; gap:6px;">
        <span class="uid-cell" title="${uid}">${uid}</span>
        <button onclick="copyUID('${uid}', this)" title="Copy" class="uid-copy-btn"
            style="display:none; background:none; border:1px solid #2d3148; color:#a0aec0;
                   border-radius:4px; padding:2px 6px; font-size:10px; cursor:pointer; white-space:nowrap;"
        >⎘</button>
    </div>
</td>
<td data-sort="${rawDate}">${displayDate}</td>
<td style="color:#93c5fd; font-size:12px; font-weight:600;">${creativeDisplay}</td>
<td>
    <select class="dd" id="camp_${i}" onchange="onCampChange(${i})">
        <option value="">-- Campaign --</option>
        ${campOptions}
    </select>
</td>
<td>
    <select class="dd" id="ag_${i}">
        <option value="">-- Adset --</option>
        ${adsetOptions}
    </select>
</td>
<td style="color:#94a3b8; font-size:12px;">${adsetDisplay}</td>
<td>
    <div style="display:flex; gap:6px; flex-wrap:wrap;">
        <button id="testbtn_${i}" onclick="openConfirmModal('TEST', '${lead.ref || lead.mobile}', ${i})"
            class="btn ${autoStatus === 'TEST' ? 'status-active-test' : 'btn-ghost'}"
            style="font-size:11px; padding:5px 10px;">Test</button>
        <button id="junkbtn_${i}" onclick="openConfirmModal('JUNK', '${lead.ref || lead.mobile}', ${i})"
            class="btn btn-ghost" style="font-size:11px; padding:5px 10px;">Junk</button>
    </div>
</td>
<td>
    <button class="btn btn-primary" id="savebtn_${i}" onclick="openConfirmModal('SAVE', '${lead.ref || lead.mobile}', ${i})">Save</button>
</td>`;
                } else {
                    // ── Google row (existing rendering) ──
                    tr.innerHTML = `
<td>
    <div style="display:flex; align-items:center; gap:6px;">
        <span class="uid-cell" title="${uid}">${uid}</span>
        <button onclick="copyUID('${uid}', this)" title="Copy" class="uid-copy-btn"
            style="display:none; background:none; border:1px solid #2d3148; color:#a0aec0;
                   border-radius:4px; padding:2px 6px; font-size:10px; cursor:pointer; white-space:nowrap;"
        >⎘</button>
    </div>
</td>
<td data-sort="${rawDate}">${displayDate}</td>
<td>
    <select class="dd" id="camp_${i}" onchange="onCampChange(${i})">
        <option value="">Campaign</option>
        ${campOptions}
    </select>
</td>
<td>
    <select class="dd" id="ag_${i}" disabled onchange="onAgChange(${i})">
        <option value="">Ad Group</option>
    </select>
</td>
<td>
    <select class="dd" id="ad_${i}" disabled>
        <option value="">Ad Name</option>
    </select>
</td>
<td>
    <div style="display:flex; gap:6px; flex-wrap:wrap;">
        <button id="testbtn_${i}" onclick="openConfirmModal('TEST', '${lead.ref || lead.mobile}', ${i})"
            class="btn ${autoStatus === 'TEST' ? 'status-active-test' : 'btn-ghost'}"
            style="font-size:11px; padding:5px 10px;">Test</button>
        <button id="junkbtn_${i}" onclick="openConfirmModal('JUNK', '${lead.ref || lead.mobile}', ${i})"
            class="btn btn-ghost" style="font-size:11px; padding:5px 10px;">Junk</button>
    </div>
</td>
<td>
    <button class="btn btn-primary" id="savebtn_${i}" onclick="openConfirmModal('SAVE', '${lead.ref || lead.mobile}', ${i})">Save</button>
</td>`;
                }

                tbody.appendChild(tr);
                if (autoStatus === 'TEST') {
                    updateStatus(lead.ref || lead.mobile, 'TEST', i, true);
                }
            });

            initDT();
        }

        function initDT() {
            if ($.fn.DataTable.isDataTable('#unmappedTable')) {
                $('#unmappedTable').DataTable().clear().destroy();
            }

            // Taboola table has one extra column (Ad Creative), so non-sortable targets differ
            const isTaboola = platform.toLowerCase() === 'taboola';
            const nonSortable = isTaboola ? [2, 3, 4, 5, 6, 7] : [2, 3, 4, 5, 6];

            dtTable = $('#unmappedTable').DataTable({
                destroy: true,
                pageLength: 10,
                lengthMenu: [10, 25, 50, 100],
                order: [[1, 'desc']],
                columnDefs: [{ orderable: false, targets: nonSortable }],
                language: { emptyTable: "No unmapped leads found." }
            });
        }
        function onCampChange(i) {
            const isTaboola = platform.toLowerCase() === 'taboola';
            const campId = document.getElementById('camp_' + i).value;
            const agSel  = document.getElementById('ag_'   + i);

            if (isTaboola) {
                // Taboola: adset is independent — just enable it when a campaign is chosen
                if (agSel) agSel.disabled = !campId;
                return;
            }

            // Google: cascade adgroup + ad dropdowns
            const adSel = document.getElementById('ad_' + i);
            agSel.innerHTML = '<option value="">-- Ad Group --</option>';
            adSel.innerHTML = '<option value="">-- Ad Name --</option>';
            adSel.disabled = true;

            if (!campId) {
                agSel.disabled = true;
                return;
            }

            adgroups.filter(ag => ag.campaign_id === campId).forEach(ag => {
                agSel.innerHTML += `<option value="${ag.adgroup_id}" data-name="${ag.adgroup_name}">${ag.adgroup_name}</option>`;
            });
            agSel.disabled = false;
        }

        function onAgChange(i) {
            const agId = document.getElementById('ag_' + i).value;
            const adSel = document.getElementById('ad_' + i);

            adSel.innerHTML = '<option value="">-- Ad Name --</option>';
            if (!agId) {
                adSel.disabled = true;
                return;
            }

            // ads.filter(a => a.adgroup_id === agId).forEach(a => {
            //     adSel.innerHTML += `<option value="${a.ad_id}" data-name="${a.ad_name}">${a.ad_name}</option>`;
            // });
            // adSel.disabled = false;
            const filtered = ads.filter(a => a.adgroup_id === agId);
            if (!filtered.length) {
                adSel.innerHTML += `<option value="" disabled>— No Ads Found —</option>`;
            } else {
                filtered.forEach(a => {
                    const name = a.ad_name || 'Unnamed Ad';
                    adSel.innerHTML += `<option value="${a.ad_id}" data-name="${name}">${name}</option>`;
                });
            }
            adSel.disabled = false;
        }

        async function updateStatus(unique_id, status, i, silent = false) {
            const testBtn = document.getElementById('testbtn_' + i);
            const junkBtn = document.getElementById('junkbtn_' + i);

            const res = await fetch('unmapped_api.php?action=update_status', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    mobile: unique_id,
                    status,
                    platform: platform
                })
            });
            const data = await res.json();

            if (data.success) {
                if (status === 'TEST') {
                    if (testBtn) testBtn.className = 'btn status-active-test';
                    if (junkBtn) junkBtn.className = 'btn btn-ghost';
                } else {
                    if (junkBtn) junkBtn.className = 'btn status-active-junk';
                    if (testBtn) testBtn.className = 'btn btn-ghost';
                }

                if (!silent) {
                    setTimeout(() => {
                        const row = testBtn?.closest('tr') || junkBtn?.closest('tr');
                        if (row && dtTable) {
                            dtTable.row(row).remove().draw();

                            // Decrease both counters
                            allTimeCount--;
                            document.getElementById('absoluteTotalCount').textContent = 'Total All-Time: ' + allTimeCount;
                            document.getElementById('totalCount').textContent = 'Selected Range: ' + dtTable.rows().count() + ' rows';
                        }
                    }, 600);
                }
            } else if (!silent) {
                alert('Error: ' + (data.error || 'Unknown'));
            }
        }

        async function saveRow(i, unique_id) {
            const campEl = document.getElementById('camp_' + i);
            const agEl   = document.getElementById('ag_'   + i);
            const adEl   = document.getElementById('ad_'   + i);
            const btn    = document.getElementById('savebtn_' + i);

            if (!campEl.value) {
                alert('Please select a Campaign.');
                return;
            }

            btn.textContent = 'Saving...';
            btn.disabled = true;

            const isTaboola = platform.toLowerCase() === 'taboola';

            // For Taboola: adset maps to adgroup_name; no ad_name cascade needed.
            // For Google: cascaded adgroup -> ad_name.
            const agName = agEl && agEl.selectedIndex > 0
                ? agEl.options[agEl.selectedIndex].dataset.name || agEl.value
                : '';
            const adName = (!isTaboola && adEl && adEl.selectedIndex > 0)
                ? adEl.options[adEl.selectedIndex].dataset.name || adEl.value
                : '';

            const res = await fetch('unmapped_api.php?action=save', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    unique_id,
                    campaign_id:   campEl.value,
                    campaign_name: campEl.options[campEl.selectedIndex].dataset.name,
                    adgroup_id:    agEl && agEl.selectedIndex > 0 ? agEl.value : '',
                    adgroup_name:  agName,
                    ad_id:         !isTaboola && adEl && adEl.selectedIndex > 0 ? adEl.value : '',
                    ad_name:       adName,
                    platform
                })
            });
            const data = await res.json();

            if (data.success) {
                btn.textContent = '✓ Saved';
                btn.classList.add('saved');
                setTimeout(() => {
                    const row = btn.closest('tr');
                    dtTable.row(row).remove().draw();
                    allTimeCount--;
                    document.getElementById('absoluteTotalCount').textContent = 'Total All-Time: ' + allTimeCount;
                    document.getElementById('totalCount').textContent = 'Selected Range: ' + dtTable.rows().count() + ' rows';
                }, 800);
            } else {
                btn.textContent = 'Save';
                btn.disabled = false;
                alert('Error: ' + (data.error || 'Unknown'));
            }
        }
        //     if (data.success) {
        //         btn.textContent = '✓ Saved';
        //         btn.classList.add('saved');
        //     } else {
        //         btn.textContent = 'Save';
        //         btn.disabled = false;
        //         alert('Error: ' + (data.error || 'Unknown'));
        //     }
        // }

        // ===m=== Download blank import template ===m===
        function downloadTemplate() {
            const headers = ['gclid', 'mobile', 'campaign_name', 'adgroup_name', 'ad_name'];
            const example = ['GCL-abc123xyz', '9876543210', 'Campaign Name', 'Ad Group Name', 'Ad Name'];

            const ws = XLSX.utils.aoa_to_sheet([headers, example]);
            ws['!cols'] = [{
                wch: 30
            }, {
                wch: 20
            }, {
                wch: 30
            }, {
                wch: 25
            }, {
                wch: 25
            }];

            const wb = XLSX.utils.book_new();
            XLSX.utils.book_append_sheet(wb, ws, 'Import Template');
            XLSX.writeFile(wb, 'unmapped_import_template.xlsx');
        }

        // ===m=== Export all leads to CSV ===m===
        function exportCSV() {
            if (!allLeads.length) {
                alert('No data to export.');
                return;
            }

            const headers = ['gclid', 'mobile', 'createddate'];
            const rows = allLeads.map(l => [l.gclid || '', l.mobile_export ?? l.mobile ?? '', l.createddate || '']);   // export rule: Users & Roles

            const ws = XLSX.utils.aoa_to_sheet([headers, ...rows]);
            ws['!cols'] = [{
                wch: 30
            }, {
                wch: 20
            }, {
                wch: 20
            }];

            const wb = XLSX.utils.book_new();
            XLSX.utils.book_append_sheet(wb, ws, 'Unmapped Leads');
            XLSX.writeFile(wb, 'unmapped_leads_' + new Date().toISOString().split('T')[0] + '.xlsx');
        }

        // ===m=== Import CSV and batch update in chunks of 50 ===m===
        function handleImport(event) {
            const file = event.target.files[0];
            if (!file) return;

            const reader = new FileReader();
            reader.onload = async (e) => {
                const lines = e.target.result.trim().split('\n');
                const header = lines[0].split(',').map(h => h.replace(/"/g, '').trim().toLowerCase());
                const rows = lines.slice(1).map(line => {
                    const vals = line.split(',').map(v => v.replace(/"/g, '').trim());
                    const obj = {};
                    header.forEach((h, i) => obj[h] = vals[i] || '');
                    return obj;
                }).filter(r => (r.gclid || r.mobile) && r.campaign_name);

                if (!rows.length) {
                    alert('No valid rows found. Make sure CSV has gclid or mobile, and campaign_name columns.');
                    return;
                }

                const BATCH = 50;
                const total = rows.length;
                let done = 0;

                const progress = document.getElementById('importProgress');
                const fill = document.getElementById('progressFill');
                const label = document.getElementById('progressLabel');
                progress.style.display = 'block';

                for (let i = 0; i < total; i += BATCH) {
                    const batch = rows.slice(i, i + BATCH);
                    await fetch('unmapped_api.php?action=import', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({
                            rows: batch,
                            platform: platform
                        })
                    });

                    done += batch.length;
                    const pct = Math.round((done / total) * 100);
                    fill.style.width = pct + '%';
                    label.textContent = `Importing ${done} / ${total} rows (${pct}%)`;
                }

                label.textContent = `✓ Import complete — ${done} rows processed.`;
                fill.style.background = '#16a34a';

                // Reload table after import
                setTimeout(async () => {
                    progress.style.display = 'none';
                    fill.style.background = '#4f46e5';
                    fill.style.width = '0%';
                    const res = await fetch(`unmapped_api.php?action=unmapped&platform=${platform}`);
                    const data = await res.json();
                    allLeads = data.leads || [];
                    if (dtTable) {
                        dtTable.destroy();
                        dtTable = null;
                    }
                    renderTable(allLeads);
                }, 2000);
            };
            reader.readAsText(file);
            event.target.value = ''; // reset input
        }


        // ===m=== Modal Pop Up ===m===
        let pendingAction = null;
        let confirmModalInstance = null;

        function openConfirmModal(action, unique_id, index) {
            // If saving, validate dropdown before opening modal
            if (action === 'SAVE') {
                const campEl = document.getElementById('camp_' + index);
                if (!campEl.value) {
                    alert('Please select a Campaign before saving.');
                    return;
                }
            }

            // Set pending action
            pendingAction = {
                action,
                unique_id,
                index
            };

            // Update text in modal
            document.getElementById('modalActionText').textContent = action.toLowerCase();
            document.getElementById('modalLeadText').textContent = unique_id;

            // Initialize and show modal
            if (!confirmModalInstance) {
                confirmModalInstance = new bootstrap.Modal(document.getElementById('confirmModal'));
            }
            confirmModalInstance.show();
        }

        // Handle the "Yes, Proceed" button click inside the modal
        document.getElementById('confirmBtn').addEventListener('click', function () {
            if (!pendingAction) return;

            // Hide the modal
            confirmModalInstance.hide();

            // Execute the appropriate function
            if (pendingAction.action === 'TEST' || pendingAction.action === 'JUNK') {
                updateStatus(pendingAction.unique_id, pendingAction.action, pendingAction.index);
            } else if (pendingAction.action === 'SAVE') {
                saveRow(pendingAction.index, pendingAction.unique_id);
            }

            // Clear pending action
            pendingAction = null;
        });

        init();
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>
