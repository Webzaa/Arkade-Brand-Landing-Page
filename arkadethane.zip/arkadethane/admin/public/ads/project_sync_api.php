<?php
/**
 * project_sync_api.php?platform=meta|google — backs the "⟳ Sync" buttons on the Meta and Google dashboards.
 *
 *   GET  ?action=list&since=YYYY-MM-DD&until=YYYY-MM-DD
 *        Every campaign in the ad account + spend in the period + whether it is in this project + leads.
 *   POST ?action=from_leads      (Meta only) campaigns found from the leads' ad_id — nothing is saved
 *   POST ?action=save            body {"add": [ids], "remove": [ids]}  add with ad sets + ads / remove
 *   POST ?action=refresh         re-read names, statuses, ad sets and ads of the linked campaigns
 *
 * Saved in campaigns / adgroups / ads (app/Ads/master_tables.php). Login required.
 */
session_start();
header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');

require_once dirname(__DIR__, 2) . '/app/Ads/meta_sync.php';
require_once dirname(__DIR__, 2) . '/app/Ads/google_sync.php';

function psReply(array $payload, int $status = 200): never
{
    http_response_code($status);
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

if (($_SESSION['user_logged'] ?? '') !== 'Y') {
    psReply(['success' => false, 'error' => 'Please sign in again.'], 401);
}
session_write_close();   // don't block the dashboard's other requests while the ad platform is slow
@set_time_limit(300);

$platform = strtolower((string) ($_GET['platform'] ?? ''));
if (!in_array($platform, MASTER_PLATFORMS, true)) {
    psReply(['success' => false, 'error' => 'Unknown platform.'], 400);
}
$ready = [
    'meta'    => fn() => defined('META_ACCESS_TOKEN') && trim((string) META_ACCESS_TOKEN) !== '' && metaAccountIds(),
    'google'  => fn() => googleAdsConfigured(),
][$platform];
if (!$ready()) {
    psReply(['success' => false, 'error' => ucfirst($platform) . ' API credentials are not set in config/config.php.'], 500);
}

$db = masterDb();
if (!$db) {
    psReply(['success' => false, 'error' => 'The campaign database (' . leadDbLabel(masterTablesDbKey()) . ') is not reachable.'], 500);
}

$action = (string) ($_GET['action'] ?? '');
$isPost = ($_SERVER['REQUEST_METHOD'] ?? '') === 'POST';
$input = json_decode((string) file_get_contents('php://input'), true);
$input = is_array($input) ? $input : [];
$validDate = fn($d) => is_string($d) && preg_match('/^\d{4}-\d{2}-\d{2}$/', $d) ? $d : null;
$cleanIds = fn($list) => array_values(array_filter(array_map(fn($v) => preg_replace('/\D+/', '', (string) $v), (array) $list), fn($v) => $v !== '' && strlen($v) <= 25));

$syncIds = function (array $ids) use ($platform, $db): array {
    return match ($platform) {
        'meta'    => metaSyncCampaignStructure($db, $ids),
        'google'  => googleSyncCampaignStructure($db, $ids),
    };
};

try {
    if ($action === 'list') {
        $since = $validDate($_GET['since'] ?? null) ?? date('Y-m-d', strtotime('-30 days'));
        $until = $validDate($_GET['until'] ?? null) ?? date('Y-m-d');
        $errors = [];
        if ($platform === 'meta') {
            $res = metaListAccountCampaigns($since, $until);
            $list = $res['campaigns'];
            $errors = $res['errors'];
            $counts = ['by_id' => [], 'by_name' => metaLeadCountsByCampaignName()];
        } else {
            $list = googleListAccountCampaigns($since, $until);
            $counts = googleLeadCounts();
        }
        $s = projectStructure($platform);
        $awObjectives = ['OUTCOME_AWARENESS', 'BRAND_AWARENESS', 'REACH', 'VIDEO_VIEWS', 'OUTCOME_ENGAGEMENT', 'POST_ENGAGEMENT', 'PAGE_LIKES', 'EVENT_RESPONSES'];
        $awBidding = ['TARGET_CPM', 'MANUAL_CPM', 'MANUAL_CPV', 'TARGET_CPV', 'TARGET_IMPRESSION_SHARE'];
        foreach ($list as &$c) {
            $c['in_project'] = isset($s['campaigns'][$c['id']]);
            $c['campaign_type'] = $s['types'][$c['id']] ?? null;   // performance | awareness (only for campaigns in the project)
            // what the platform says the campaign is built for — a hint for the execution team, never applied by itself
            $c['awareness_hint'] = $platform === 'meta'
                ? in_array(strtoupper((string) ($c['objective'] ?? '')), $awObjectives, true)
                : in_array(strtoupper((string) ($c['bidding'] ?? '')), $awBidding, true);
            $c['leads'] = max($counts['by_id'][masterNorm($c['id'])] ?? 0, $counts['by_name'][masterNorm($c['name'])] ?? 0);
            $c['spend'] = round((float) $c['spend'], 2);
            if ($c['in_project'] && $s['campaigns'][$c['id']] !== $c['name']) {
                $c['saved_name'] = $s['campaigns'][$c['id']];   // renamed in the ad platform since the last sync
            }
        }
        unset($c);
        usort($list, fn($a, $b) => [$b['in_project'], $b['leads'] > 0, $b['spend']] <=> [$a['in_project'], $a['leads'] > 0, $a['spend']]);
        psReply(['success' => true, 'platform' => $platform, 'since' => $since, 'until' => $until,
                 'campaigns' => $list, 'project_count' => $s['count'], 'errors' => $errors]);
    }

    if ($action === 'from_leads' && $isPost) {
        if ($platform !== 'meta') {
            psReply(['success' => true, 'campaigns' => [], 'ads_checked' => 0]);   // Google / Taboola leads carry the campaign ID / name already
        }
        $res = metaCampaignsFromLeads();
        psReply(['success' => true, 'campaigns' => array_values($res['campaigns']), 'ads_checked' => $res['ads_checked']]);
    }

    if ($action === 'save' && $isPost) {
        $add = $cleanIds($input['add'] ?? []);
        $remove = array_values(array_diff($cleanIds($input['remove'] ?? []), $add));
        // campaign type per campaign: {id: "performance" | "awareness"}
        $types = [];
        foreach ((array) ($input['types'] ?? []) as $id => $type) {
            $id = preg_replace('/\D+/', '', (string) $id);
            if ($id !== '' && strlen($id) <= 25 && in_array($type, ['performance', 'awareness'], true) && !in_array($id, $remove, true)) {
                $types[$id] = $type;
            }
        }
        if (!$add && !$remove && !$types) {
            psReply(['success' => false, 'error' => 'Nothing to change.'], 400);
        }
        $removed = $remove ? masterRemoveCampaigns($db, $platform, $remove) : 0;
        $synced = $add ? $syncIds($add) : ['campaigns' => 0, 'adgroups' => 0, 'ads' => 0, 'leads_filled' => 0, 'errors' => []];
        $typed = $types ? masterSetCampaignTypes($db, $platform, $types) : 0;
        masterClearDashboardCache();
        psReply(['success' => true, 'removed' => $removed, 'types_changed' => $typed] + $synced);
    }

    if ($action === 'refresh' && $isPost) {
        $ids = array_map('strval', array_keys(projectStructure($platform)['campaigns']));
        if (!$ids) {
            psReply(['success' => false, 'error' => 'No campaigns in this project yet — pick some first.'], 400);
        }
        $synced = $syncIds($ids);
        masterClearDashboardCache();
        psReply(['success' => true] + $synced);
    }

    psReply(['success' => false, 'error' => 'Unknown action.'], 400);
} catch (Throwable $e) {
    error_log('[project_sync_api ' . $platform . '] ' . $e->getMessage());
    psReply(['success' => false, 'error' => $e->getMessage()], 500);
}
