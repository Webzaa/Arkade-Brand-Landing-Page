<?php
/**
 * ott_api.php — backend of ottdashboard.php (MANUAL platforms: OTT Video, Display, MyGate, … — numbers entered /
 * pasted by hand; tables ad_platforms + ad_platform_daily). Every action takes &p=<platform key> (default ott = OTT Video).
 *
 *   GET  ?action=platforms                         → the manual platforms [{key, name, color, lead_sources}]
 *   GET  ?action=list&p=&since=&until=&campaign=   → rows (+ leads per day), totals, campaigns, columns
 *   GET  ?action=summary&p=&since=&until=          → All Platforms format: {campaigns:[…], trend:[…]}
 *   POST ?action=save&p=     {rows:[{date, campaign, impressions, clicks, reach, views, spend, extra:{}}]}  (insert or replace by date + campaign)
 *   POST ?action=delete&p=   {ids:[…]}
 *   POST ?action=columns&p=  {order:[…], hidden:[…], custom:[…]}
 *   POST ?action=platform    {key?, name, color, lead_sources}   add (no key) or edit a platform
 *   POST ?action=platform_delete {key}                          remove a platform and all its rows
 *   GET  ?action=awareness&p=                      → awareness setting + spend per month / campaign (for the editor)
 *   POST ?action=awareness&p=  {mode: none|all|campaigns|amount, campaigns:[…], amounts:{"YYYY-MM": n}}
 * list / summary follow the All / Performance / Awareness tab (cookie pq_view, ?view=): 'all' = rows as saved,
 * otherwise each row's share of that type (see ottViewRows). Both return 'awareness' {view, tabs, tagged, spend, …}.
 * Users & Roles → Campaign types: a platform that is all awareness (or all performance) is hidden from roles that
 * may not see that type — 'platforms' leaves it out and every other action answers 403.
 * Logic: app/Ads/ott.php
 */
ob_start();
ini_set('display_errors', '0');
session_start();

function ottJson(array $p, int $code = 200): never
{
    while (ob_get_level()) {
        ob_end_clean();
    }
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    header('X-Content-Type-Options: nosniff');
    echo json_encode($p, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}
if (($_SESSION['user_logged'] ?? '') !== 'Y') {
    ottJson(['success' => false, 'error' => 'Please sign in again.'], 401);
}
$user = (string) ($_SESSION['username'] ?? $_SESSION['user'] ?? 'user');
session_write_close();

require_once dirname(__DIR__, 2) . '/app/Ads/ott.php';

$action = (string) ($_GET['action'] ?? '');
$isPost = ($_SERVER['REQUEST_METHOD'] ?? '') === 'POST';
$in = $isPost ? (json_decode((string) file_get_contents('php://input'), true) ?: []) : [];
$date = fn($v) => (is_string($v) && preg_match('/^\d{4}-\d{2}-\d{2}$/', $v)) ? $v : '';
$pf = (string) ($_GET['p'] ?? 'ott');

try {
    if ($action === 'platforms') {
        ottJson(['success' => true, 'platforms' => array_map('ottPlatformPublic', ottVisiblePlatforms())]);
    }
    if ($action === 'platform' && $isPost) {
        ottJson(['success' => true, 'platform' => ottSavePlatform($in), 'platforms' => array_map('ottPlatformPublic', ottVisiblePlatforms())]);
    }
    if ($action === 'platform_delete' && $isPost) {
        $n = ottDeletePlatform((string) ($in['key'] ?? ''));
        ottJson(['success' => true, 'deleted_rows' => $n, 'platforms' => array_map('ottPlatformPublic', ottVisiblePlatforms())]);
    }
    $plat = ottPlatform($pf);
    if (!ottPlatformVisible($plat)) {
        ottJson(['success' => false, 'error' => 'Your role can\'t see ' . $plat['name'] . ' (Users & Roles → Campaign types).', 'no_access' => true], 403);
    }
    if ($action === 'awareness') {
        if (!pqCanSeeType('awareness') || !pqCanSeeType('performance')) {   // the split needs the whole spend
            ottJson(['success' => false, 'error' => 'Setting the awareness split needs both campaign types (Users & Roles → Campaign types).', 'no_access' => true], 403);
        }
        if ($isPost) {
            ottSaveAwareness($pf, $in, $user);
            $plat = ottPlatform($pf);
        }
        ottJson(['success' => true, 'awareness' => $plat['awareness']] + ottSpendBreakdown($pf));
    }
    if ($action === 'list') {
        $since = $date($_GET['since'] ?? '');
        $until = $date($_GET['until'] ?? '');
        $campaign = trim((string) ($_GET['campaign'] ?? ''));
        $rows = ottRows($pf, $since, $until, $campaign);
        $leads = ottLeadsByDay($pf, $since, $until);
        $split = ottAwarenessSplit($plat, $rows);
        $info = ottAwarenessInfo($plat, $rows, $split);
        foreach ($rows as $i => &$r) {
            $r['aw'] = round($split[$i], 2);
        }
        unset($r);
        [$rows, $leadsHere] = ottViewRows($plat, $rows, $split, $info['view']);
        if (!$leadsHere) {
            $leads = [];
        }
        if (!pqCanSeeType('awareness')) {
            foreach ($rows as &$r) {
                unset($r['aw']);
            }
            unset($r);
        }
        ottJson(['success' => true, 'awareness' => $info, 'platform' => $plat['name'], 'platform_info' => ottPlatformPublic($plat), 'rows' => $rows, 'leads' => $leads,
                 'totals' => ottTotals($rows, $campaign === '' ? $leads : []), 'campaigns' => ottCampaigns($pf),
                 'columns' => ottColumns($pf), 'builtin' => OTT_COLUMNS, 'lead_sources' => $plat['lead_sources']]);
    }
    if ($action === 'summary') {
        // same shape as the Meta / Google APIs, so All Platforms can add OTT like any other platform
        $since = $date($_GET['since'] ?? '');
        $until = $date($_GET['until'] ?? '');
        $rows = ottRows($pf, $since, $until);
        $leads = ottLeadsByDay($pf, $since, $until);
        // All / Performance / Awareness tab (same as Meta / Google): only that type's share of each row
        $split = ottAwarenessSplit($plat, $rows);
        $awareness = ottAwarenessInfo($plat, $rows, $split);
        [$rows, $leadsHere] = ottViewRows($plat, $rows, $split, $awareness['view']);
        if (!$leadsHere) {
            $leads = [];
        }
        $byCamp = [];
        foreach ($rows as $r) {
            $c = &$byCamp[$r['campaign']];
            $c ??= ['name' => $r['campaign'], 'spend' => 0.0, 'impressions' => 0, 'clicks' => 0, 'leads' => 0, 'qualified' => 0, 'walkins' => 0, 'views' => 0, 'reach' => 0];
            $c['spend'] += $r['spend'];
            $c['impressions'] += $r['impressions'];
            $c['clicks'] += $r['clicks'];
            $c['views'] += $r['views'];
            $c['reach'] += $r['reach'];
            unset($c);
        }
        $campaigns = array_values($byCamp);
        if ($leads) {      // OTT leads are not tied to a campaign: put them on the first one (or their own row)
            $lt = ['leads' => 0, 'qualified' => 0, 'walkins' => 0];
            foreach ($leads as $l) {
                $lt['leads'] += $l['leads'];
                $lt['qualified'] += $l['qualified'];
                $lt['walkins'] += $l['sitevisits'];
            }
            if ($campaigns) {
                foreach ($lt as $k => $v) {
                    $campaigns[0][$k] += $v;
                }
            } else {
                $campaigns[] = ['name' => $plat['name'], 'spend' => 0, 'impressions' => 0, 'clicks' => 0] + $lt;
            }
        }
        $trend = [];
        foreach ($rows as $r) {
            $t = &$trend[$r['date']];
            $t ??= ['date' => $r['date'], 'spend' => 0.0, 'leads' => 0];
            $t['spend'] += $r['spend'];
            unset($t);
        }
        foreach ($leads as $d => $l) {
            $trend[$d] ??= ['date' => $d, 'spend' => 0.0, 'leads' => 0];
            $trend[$d]['leads'] += $l['leads'];
        }
        ksort($trend);
        ottJson(['success' => true, 'campaigns' => $campaigns, 'trend' => array_values($trend), 'has_data' => (bool) ($rows || $leads), 'awareness' => $awareness]);
    }
    if ($action === 'save' && $isPost) {
        $rows = array_slice((array) ($in['rows'] ?? []), 0, 3000);
        if (!$rows) {
            ottJson(['success' => false, 'error' => 'No rows to save.'], 400);
        }
        ottJson(['success' => true] + ottSaveRows($pf, $rows, $user));
    }
    if ($action === 'delete' && $isPost) {
        ottJson(['success' => true, 'deleted' => ottDeleteRows($pf, (array) ($in['ids'] ?? []))]);
    }
    if ($action === 'columns' && $isPost) {
        ottJson(['success' => true, 'columns' => ottSaveColumns($pf, $in)]);
    }
    ottJson(['success' => false, 'error' => 'Unknown action.'], 400);
} catch (InvalidArgumentException $e) {
    ottJson(['success' => false, 'error' => $e->getMessage()], 400);
} catch (Throwable $e) {
    error_log('[ott_api] ' . $e->getMessage() . ' @ ' . $e->getFile() . ':' . $e->getLine());
    ottJson(['success' => false, 'error' => $e->getMessage()], 500);
}
