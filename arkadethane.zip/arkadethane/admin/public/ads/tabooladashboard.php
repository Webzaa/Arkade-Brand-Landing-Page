<?php
// ===m=== Uncomment Below for Error Reporting ===m===
// ini_set('display_errors', 1);
// ini_set('display_startup_errors', 1);
// error_reporting(E_ALL);
// ===m=== Uncomment Above for Error Reporting ===m===

session_start();
require_once dirname(__DIR__, 2) . '/app/Core/db.php';
if (!isset($_SESSION["user_logged"]) || $_SESSION["user_logged"] != "Y") {
    header("Location: ../login.php");
    exit;
}

// Platform pages live inside the PerformIQ shell (../dashboard.php). Opened directly,
// send the user to the shell on this platform's section. ?standalone=1 skips that.
$pqEmbed = isset($_GET['embed']) && $_GET['embed'] === '1';
if (!$pqEmbed && !isset($_GET['standalone'])) {
    header('Location: ../dashboard.php#taboola');
    exit;
}
$title = DASHBOARD_TITLE;

// Last lead received for Taboola (matched by utm_campaignsource = 'taboola')
$lastTaboolaLeadDate = null;
foreach (leadDbs('all') as $leadDbConn) if (($leadRes = $leadDbConn->query(
    "SELECT MAX(createddate) AS last_dt FROM `lead`
     WHERE LOWER(TRIM(COALESCE(campaignsource,''))) LIKE '%taboola%'
       AND ((lead_status IS NOT NULL AND TRIM(lead_status) <> '')
            OR (sitevisit_status IS NOT NULL AND TRIM(sitevisit_status) <> ''))"
))) {
    $leadRow = $leadRes->fetch_assoc();
    if (!empty($leadRow['last_dt']) && ($lastTaboolaLeadDate === null || $leadRow['last_dt'] > $lastTaboolaLeadDate)) {
        $lastTaboolaLeadDate = $leadRow['last_dt'];
    }
}
?>
<!DOCTYPE html>
<html lang="en" class="<?= $pqEmbed ? 'pq-embed' : '' ?>">

<head>
<?= function_exists('pqDatesTag') ? pqDatesTag('../') : '' ?>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>
        <?= htmlspecialchars($title) ?> | Taboola
    </title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Sora:wght@300;400;500;600;700&family=JetBrains+Mono:wght@300;400;500;600&display=swap"
        rel="stylesheet">

    <script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>
    <script src="https://unpkg.com/xlsx@0.18.5/dist/xlsx.full.min.js"></script>
    <script src="https://unpkg.com/papaparse@5.4.1/papaparse.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <script>
        // Theme (shared with the PerformIQ shell via localStorage) — applied before paint
        (function () {
            var t = 'dark';
            try { t = localStorage.getItem('performiq-theme') || 'dark'; } catch (e) {}
            document.documentElement.setAttribute('data-theme', t === 'light' ? 'light' : 'dark');
        })();
    </script>
    <style>
        :root, :root[data-theme="dark"] {
            --pq-bg: #0B0F1A; --pq-surface: #111827; --pq-card: #161D2E; --pq-border: #1E2A42;
            --pq-text: #E2E8F0; --pq-text-dim: #94A3B8; --pq-muted: #4B5563; --pq-line: #334155;
            --pq-surface-2: #1F2937;
            color-scheme: dark;
        }
        :root[data-theme="light"] {
            --pq-bg: #F4F6FA; --pq-surface: #FFFFFF; --pq-card: #F8FAFC; --pq-border: #E2E8F0;
            --pq-text: #0F172A; --pq-text-dim: #475569; --pq-muted: #94A3B8; --pq-line: #CBD5E1;
            --pq-surface-2: #F1F5F9;
            color-scheme: light;
        }
        :root[data-theme="light"] .loader-text { color: #0F172A; }
        :root[data-theme="light"] .loader-dashboard { background: rgba(244, 246, 250, 0.7); }
        #theme-toggle { display: flex; align-items: center; gap: 6px; font-size: 12px; }

        /* ===== Embedded inside the PerformIQ shell (dashboard.php) ===== */
        .pq-embed .pq-brand,
        .pq-embed .pq-platform-switch,
        .pq-embed #theme-toggle,
        .pq-embed .pq-footer,
        .pq-embed .pq-refreshed,
        .pq-embed #refresh-btn,
        .pq-embed header span:has(> .live-dot) { display: none !important; }   /* shell top bar has Refresh */
        .pq-embed header { position: static !important; }
        .pq-embed header { padding: 0 24px !important; }
        .pq-embed header > div { height: 52px !important; justify-content: flex-end !important; max-width: none !important; }
        .pq-embed nav { padding: 0 24px !important; }
        .pq-embed nav > div, .pq-embed main { max-width: none !important; }
        .pq-embed main { padding: 20px 24px !important; }
        .pq-embed main { padding-top: 20px !important; }
    </style>

    <style>
        body {
            background-color: var(--pq-bg);
            margin: 0;
            padding: 0;
            color: var(--pq-text);
            font-family: 'Sora', sans-serif;
        }

        ::-webkit-scrollbar {
            width: 6px;
            height: 6px;
        }

        ::-webkit-scrollbar-track {
            background: var(--pq-surface);
        }

        ::-webkit-scrollbar-thumb {
            background: var(--pq-border);
            border-radius: 3px;
        }

        ::-webkit-scrollbar-thumb:hover {
            background: var(--pq-muted);
        }

        .mono {
            font-family: "JetBrains Mono", monospace;
        }

        .tab-btn {
            background: none;
            border: none;
            cursor: pointer;
            outline: none;
        }

        .tab-btn:hover {
            opacity: 0.85;
        }

        table {
            border-collapse: collapse;
            width: 100%;
        }

        th {
            color: var(--pq-text-dim);
            font-size: 11px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.07em;
            padding: 10px 14px;
            border-bottom: 1px solid var(--pq-border);
            text-align: left;
            white-space: nowrap;
            cursor: pointer;
            user-select: none;
        }

        th:hover {
            color: var(--pq-text);
        }

        td {
            color: var(--pq-text);
            font-size: 12.5px;
            padding: 10px 14px;
            border-bottom: 1px solid #1E2A4244;
            vertical-align: middle;
        }

        tr:hover td {
            background: #3B82F618;
        }

        .btn {
            background: #3B82F6;
            color: #fff;
            border: none;
            border-radius: 8px;
            padding: 10px 20px;
            font-family: "Sora";
            font-size: 13px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s;
            letter-spacing: 0.02em;
        }

        .btn:hover {
            opacity: 0.88;
            transform: translateY(-1px);
        }

        .btn:disabled {
            background: var(--pq-muted);
            color: var(--pq-text);
            cursor: not-allowed;
            opacity: 0.6;
        }

        .btn-ghost {
            background: var(--pq-card);
            color: var(--pq-text);
            border: 1px solid var(--pq-border);
        }

        .btn-ghost:hover {
            border-color: #3B82F6;
            color: #3B82F6;
            background: #3B82F618;
        }

        select {
            background: var(--pq-card);
            color: var(--pq-text);
            border: 1px solid var(--pq-border);
            border-radius: 8px;
            padding: 8px 12px;
            font-family: "Sora";
            font-size: 12px;
            outline: none;
            cursor: pointer;
        }

        select:focus {
            border-color: #3B82F6;
        }

        input {
            background: var(--pq-card);
            color: var(--pq-text);
            border: 1px solid var(--pq-border);
            border-radius: 8px;
            padding: 8px 12px;
            font-family: "Sora";
            font-size: 12px;
            outline: none;
            width: 100%;
            box-sizing: border-box;
        }

        input:focus {
            border-color: #3B82F6;
        }

        @keyframes pulse {

            0%,
            100% {
                opacity: 1
            }

            50% {
                opacity: 0.5
            }
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(8px)
            }

            to {
                opacity: 1;
                transform: translateY(0)
            }
        }

        @keyframes shimmer {
            0% {
                background-position: 200% 0
            }

            100% {
                background-position: -200% 0
            }
        }

        .animate-in {
            animation: fadeIn 0.35s ease forwards;
        }

        .pulse {
            animation: pulse 1.5s ease infinite;
        }

        .live-dot {
            display: inline-block;
            width: 6px;
            height: 6px;
            border-radius: 50%;
            background: #10B981;
            margin-right: 6px;
            animation: pulse 1.5s ease-in-out infinite;
        }

        .loader-dashboard {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(3, 7, 18, 0.65);
            backdrop-filter: blur(3px);
            display: none;
            justify-content: center;
            align-items: center;
            flex-direction: column;
            z-index: 99999;
        }

        .loader-spinner {
            width: 60px;
            height: 60px;
            border: 4px solid rgba(255, 255, 255, 0.15);
            border-top: 4px solid #3B82F6;
            border-radius: 50%;
            animation: spin 1s linear infinite;
            position: absolute;
            left: 45%;
            top: 45%;
        }

        .loader-text {
            margin-top: 15px;
            color: #fff;
            font-size: 14px;
            font-weight: 600;
            position: absolute;
            left: 40%;
            top: 56%;
        }

        @keyframes spin {
            0% {
                transform: rotate(0deg);
            }

            100% {
                transform: rotate(360deg);
            }
        }

        .sorted-asc::after {
            content: " ▲";
            color: #3B82F6;
            font-size: 9px;
        }

        .sorted-desc::after {
            content: " ▼";
            color: #3B82F6;
            font-size: 9px;
        }
    </style>

    <!-- Builds the "Export PDF (Meta + Google + Taboola)" report as a downloadable PDF client-side. -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>
<?= function_exists('pqContactJs') ? pqContactJs() : '' ?>
<script>
/* Users & Roles → full email / mobile on screen and in exports, separately (app/Core/db.php pqContact) */
window.pqShow = function (v, type, where) {
    v = String(v == null ? '' : v).trim();
    if (!v) return '';
    var c = window.PQ_CONTACT || { screen: {}, export: {} };
    if ((c[where === 'export' ? 'export' : 'screen'] || {})[type]) return v;
    if (type === 'email') { var p = v.split('@'); return p.length < 2 ? '*****' : p[0].slice(0, 2) + '******@' + p.slice(1).join('@'); }
    if (v.indexOf('*') >= 0) return v;   // masked already (server)
    var d = v.replace(/\D+/g, '');   // mobile: stars + the last 5 digits (pqMaskMobile)
    return d.length <= 5 ? '*'.repeat(Math.max(5, d.length)) : '*'.repeat(d.length - 5) + d.slice(-5);
};
window.esc_pq = function (v) { return String(v == null ? '' : v).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); };
</script>
<style>
    /* phone / small tablet: side-by-side panels stack (charts, insight cards, comparison panels) */
    @media (max-width: 760px) {
        [style*="grid-template-columns: repeat(3, 1fr)"], [style*="grid-template-columns:repeat(3, 1fr)"], [style*="grid-template-columns:repeat(3,1fr)"],
        [style*="grid-template-columns: 1fr 1fr"], [style*="grid-template-columns:1fr 1fr"],
        [style*="grid-template-columns: 1.2fr 0.8fr"], [style*="grid-template-columns:1.2fr 0.8fr"] { grid-template-columns: 1fr !important; }
        [style*="minmax(300px"] { grid-template-columns: 1fr !important; }
        main[style*="padding:28px"], main[style*="padding: 28px"] { padding: 14px !important; }
        table { max-width: none; }
    }
</style>
</head>

<body>
    <div id="loader-dashboard" class="loader-dashboard">
        <div class="loader-spinner"></div>
        <div class="loader-text">Loading Taboola data…</div>
    </div>

    <div id="app" style="min-height:100vh; background:var(--pq-bg);">

        <!-- HEADER -->
        <header
            style="background:var(--pq-surface); border-bottom:1px solid var(--pq-border); padding:0 28px; position:sticky; top:0; z-index:100;">
            <div
                style="display:flex; align-items:center; justify-content:space-between; height:60px; max-width:1600px; margin:0 auto;">
                <div class="pq-brand" style="display:flex; align-items:center; gap:14px;">
                    <div
                        style="width:32px; height:32px; border-radius:8px; background:#3B82F6; display:flex; align-items:center; justify-content:center; font-size:13px; font-weight:700; color:#fff; font-family:'Sora';">
                        T</div>
                    <div>
                        <div
                            style="color:var(--pq-text); font-family:'Sora'; font-weight:700; font-size:15px; letter-spacing:-0.02em;">
                            PerformIQ</div>
                        <div
                            style="color:var(--pq-text-dim); font-size:10px; font-family:'Sora'; letter-spacing:0.05em; text-transform:uppercase;">
                            Taboola Native Ads Dashboard</div>
                    </div>
                </div>

                <div style="display:flex; align-items:center; gap:12px;">
                    <!-- Platform switcher -->
                    <div class="pq-platform-switch" style="display:flex; align-items:center; gap:8px;">
                        <span
                            style="color:var(--pq-text-dim); font-size:11px; font-weight:600; text-transform:uppercase; letter-spacing:0.05em; white-space:nowrap;">Platform:</span>
                        <div
                            style="display:flex; gap:4px; align-items:center; background:var(--pq-bg); border:1px solid var(--pq-border); border-radius:8px; padding:3px;">
                            <button onclick="window.location.href='../dashboard.php#meta'" style="display:inline-flex; align-items:center; gap:5px;
                                       background:transparent; color:var(--pq-text-dim);
                                       border:1px solid transparent; border-radius:6px;
                                       padding:5px 12px; font-size:11px; font-weight:500;
                                       font-family:'Sora',sans-serif; letter-spacing:0.04em;
                                       text-transform:uppercase; cursor:pointer; white-space:nowrap;
                                       transition:all 0.15s;"
                                onmouseover="this.style.color='#1877F2'; this.style.borderColor='#1877F244';"
                                onmouseout="this.style.color='var(--pq-text-dim)'; this.style.borderColor='transparent';">
                                Meta
                            </button>
                            <button onclick="window.location.href='../dashboard.php#google'" style="display:inline-flex; align-items:center; gap:5px;
                                       background:transparent; color:var(--pq-text-dim);
                                       border:1px solid transparent; border-radius:6px;
                                       padding:5px 12px; font-size:11px; font-weight:500;
                                       font-family:'Sora',sans-serif; letter-spacing:0.04em;
                                       text-transform:uppercase; cursor:pointer; white-space:nowrap;
                                       transition:all 0.15s;"
                                onmouseover="this.style.color='#4285F4'; this.style.borderColor='#4285F444';"
                                onmouseout="this.style.color='var(--pq-text-dim)'; this.style.borderColor='transparent';">
                                Google
                            </button>
                            <button style="display:inline-flex; align-items:center; gap:5px;
                                       background:#3B82F618; color:#3B82F6;
                                       border:1px solid #3B82F644; border-radius:6px;
                                       padding:5px 12px; font-size:11px; font-weight:700;
                                       font-family:'Sora',sans-serif; letter-spacing:0.04em;
                                       text-transform:uppercase; cursor:default; white-space:nowrap;">
                                Taboola
                            </button>
                        </div>
                    </div>
                    <span
                        style="color:#10B981; background:#10B98118; border:1px solid #10B98144; padding:4px 10px; border-radius:99px; font-size:10px; font-weight:600; display:flex; align-items:center;">
                        <span class="live-dot"></span>LIVE DATA
                    </span>
                    <span class="pq-refreshed" style="color:var(--pq-text); font-size:11px;">
                        Refreshed:
                        <span id="header-refreshed-at">—</span>
                    </span>
                    <!-- Last Lead Date Badge -->
                    <span id="header-last-lead-badge"
                        style="color:var(--pq-text-dim); font-size:11px; display:flex; align-items:center; gap:5px; padding:4px 10px; border:1px solid #33415544; border-radius:99px; white-space:nowrap;">
                        <span style="font-size:8px; color:#3B82F6;">●</span>
                        Last Lead:
                        <span id="header-last-lead-value" style="color:var(--pq-text); font-weight:600;">
                            <?= $lastTaboolaLeadDate ? htmlspecialchars((new DateTime($lastTaboolaLeadDate))->format('d M Y, h:i A')) : '—' ?>
                        </span>
                    </span>
                    <button class="btn btn-ghost" onclick="handleRefresh()"
                        style="display:flex; align-items:center; gap:6px; font-size:12px;" id="refresh-btn">
                        <span id="refresh-icon">↻</span>
                        <span id="refresh-btn-text">Refresh</span>
                    </button>
                    <button class="btn btn-ghost" onclick="UploadManager.openModal()"
                        style="display:flex; align-items:center; gap:6px; font-size:12px;">
                        <span>⬆</span>
                        <span>Upload Offline Data</span>
                    </button>
                    <!-- <button class="btn" onclick="handleGenerateInsights(event)"
                        style="display:flex; align-items:center; gap:6px; font-size:12px;">
                        <span>🤖</span>
                        <span id="ai-insights-btn-text">Generate AI Insights</span>
                    </button> -->
                </div>
            </div>
        </header>

        <!-- NAV TABS -->
        <nav style="background:var(--pq-surface); border-bottom:1px solid var(--pq-border); padding:0 28px;">
            <div id="tabs-container" style="display:flex; gap:4px; max-width:1600px; margin:0 auto; overflow-x:auto;">
                <!-- Inject dynamic tab buttons here -->
            </div>
        </nav>

        <!-- MAIN CONTENT -->
        <main style="max-width:1600px; margin:0 auto; padding:28px;" class="animate-in">

            <div id="error-banner"
                style="display:none; background:#EF444418; border:1px solid #EF444444; color:#EF4444; border-radius:12px; padding:12px 18px; margin-bottom:24px; font-size:13px;">
                ⚠️ <strong>Error:</strong> <span id="error-message"></span>
            </div>

            <!-- GLOBAL FILTERS ROW -->
            <div id="filters-container"
                style="display:flex; flex-wrap:wrap; gap:20px; align-items:center; background:var(--pq-surface); border:1px solid var(--pq-border); border-radius:12px; padding:16px 20px; margin-bottom:24px; position:relative;">
                <div style="display:flex; flex-direction:column; gap:6px; position:relative;">
                    <span
                        style="color:var(--pq-text-dim); font-size:11px; font-weight:600; text-transform:uppercase; letter-spacing:0.05em;">Date:</span>
                    <div onclick="toggleDatePicker(event)"
                        style="background:var(--pq-card); color:var(--pq-text); border:1px solid var(--pq-border); border-radius:8px; padding:8px 12px; font-size:12.5px; cursor:pointer; display:flex; align-items:center; justify-content:space-between; min-width:220px; user-select:none;">
                        <span id="date-range-display">📅 Loading…</span>
                        <span style="font-size:10px; opacity:0.6;">▼</span>
                    </div>
                    <div id="date-picker-popup"
                        style="display:none; position:absolute; top:100%; left:0; margin-top:8px; background:var(--pq-surface); border:1px solid var(--pq-border); border-radius:12px; box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.5), 0 8px 10px -6px rgba(0, 0, 0, 0.5); flex-direction:column; z-index:1000; padding:16px; width:700px;">
                    </div>
                </div>
                <!-- Status Filter Tabs (pill buttons) -->
                <div style="display:flex; flex-direction:column; gap:8px;">
                    <span
                        style="color:var(--pq-text-dim); font-size:11px; font-weight:600; text-transform:uppercase; letter-spacing:0.05em;">Status:</span>
                    <div id="status-tab-group"
                        style="display:flex; gap:4px; align-items:center; background:var(--pq-surface); border:1px solid var(--pq-border); border-radius:8px; padding:3px;">
                        <button id="status-tab-all" onclick="handleStatusFilterChange('all')" style="background:var(--pq-card); color:var(--pq-text); border:1px solid var(--pq-border);
                                   border-radius:6px; padding:6px 14px; font-size:11.5px; font-weight:700;
                                   font-family:'Sora',sans-serif; cursor:pointer; transition:all 0.15s;
                                   outline:none; white-space:nowrap;">
                            All
                        </button>
                        <button id="status-tab-active" onclick="handleStatusFilterChange('active')" style="background:transparent; color:var(--pq-text-dim); border:1px solid transparent;
                                   border-radius:6px; padding:6px 14px; font-size:11.5px; font-weight:400;
                                   font-family:'Sora',sans-serif; cursor:pointer; transition:all 0.15s;
                                   outline:none; white-space:nowrap;">
                            🟢 Active
                        </button>
                        <button id="status-tab-inactive" onclick="handleStatusFilterChange('inactive')" style="background:transparent; color:var(--pq-text-dim); border:1px solid transparent;
                                   border-radius:6px; padding:6px 14px; font-size:11.5px; font-weight:400;
                                   font-family:'Sora',sans-serif; cursor:pointer; transition:all 0.15s;
                                   outline:none; white-space:nowrap;">
                            🔴 Inactive
                        </button>
                    </div>
                </div>

                <div style="display:flex; flex-direction:column; gap:6px; flex-grow:1; min-width:200px;">
                    <span
                        style="color:var(--pq-text-dim); font-size:11px; font-weight:600; text-transform:uppercase; letter-spacing:0.05em;">Search:</span>
                    <div style="position:relative;">
                        <input id="search-query" type="text" placeholder="Search by campaign name..."
                            oninput="handleSearchInput(this)" />
                        <button id="search-clear-btn" onclick="clearSearchInput()"
                            style="display:none; position:absolute; right:10px; top:50%; transform:translateY(-50%); background:none; border:none; color:var(--pq-text-dim); cursor:pointer; font-size:14px;">✕</button>
                    </div>
                </div>
            </div>

            <div id="tab-content-container">
            </div>
        </main>

        <!-- FOOTER -->
        <footer class="pq-footer" style="border-top:1px solid var(--pq-border); padding:16px 28px; margin-top:40px; background:var(--pq-surface);">
            <div
                style="max-width:1600px; margin:0 auto; display:flex; justify-content:space-between; align-items:center;">
                <span id="footer-text-left" style="color:var(--pq-muted); font-size:11px;">
                    PerfomIQ · Loading…
                </span>
                <span style="color:var(--pq-muted); font-size:11px;">
                    Live Taboola Backstage API Integration · Powered by PHP & Pure JS
                </span>
            </div>
        </footer>
    </div>

    <!-- Leads Modal -->
    <div id="leadsModalOverlay"
        style="display:none;position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.6);z-index:99999;align-items:center;justify-content:center;backdrop-filter:blur(4px);">
        <div
            style="background:var(--pq-card); border:1px solid var(--pq-border); border-radius:12px; width:90%; max-width:1000px; max-height:85vh; display:flex; flex-direction:column; box-shadow:0 10px 32px rgba(0,0,0,0.5);">
            <div
                style="display:flex; justify-content:space-between; align-items:center; padding:16px 24px; border-bottom:1px solid var(--pq-border);">
                <h3 id="leadsModalTitle" style="margin:0; font-size:16px; color:#3B82F6;">Leads Data</h3>
                <div style="display:flex; gap:12px;">
                    <button class="btn" onclick="exportLeadsToExcel()">Export Data</button>
                    <button class="btn btn-ghost" onclick="closeLeadsModal()" style="padding:10px 16px;">Close</button>
                </div>
            </div>
            <div style="padding:24px; overflow-y:auto; flex-grow:1;">
                <table style="width:100%; text-align:left; border-collapse:collapse;">
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Name</th>
                            <th>Mobile</th>
                            <th>Email</th>
                            <th>Lead Status</th>
                            <th>SV Status</th>
                            <th>UTM C</th>
                        </tr>
                    </thead>
                    <tbody id="leadsModalBody">
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <script>
        window.handleStatusFilterChange = (status) => {
            state.filterStatus = status;
            ['all', 'active', 'inactive'].forEach(s => {
                const btn = document.getElementById(`status-tab-${s}`);
                if (!btn) return;
                const isActive = s === status;
                btn.style.background = isActive ? 'var(--pq-card)' : 'transparent';
                btn.style.color = isActive ? 'var(--pq-text)' : 'var(--pq-text-dim)';
                btn.style.border = isActive ? '1px solid var(--pq-border)' : '1px solid transparent';
                btn.style.fontWeight = isActive ? '700' : '400';
            });
            fetchDashboardData();
        };
    </script>

    <script>
        window.unmappedLeadsCount = "...";

        async function loadUnmappedCount() {
            try {
                const res = await fetch('unmapped_api.php?action=master&platform=taboola');
                const data = await res.json();
                const count = data.total_all_time !== undefined ? data.total_all_time : 0;
                window.unmappedLeadsCount = count;
                const badges = document.querySelectorAll('#unmappedBadge');
                badges.forEach(badge => {
                    badge.textContent = count;
                });
            } catch (err) {
                console.error("Failed to fetch unmapped leads:", err);
            }
        }

        function openUnmapped() {
            window.open('unmapped.php?platform=taboola', '_blank');
        }

        document.addEventListener('DOMContentLoaded', () => {
            loadUnmappedCount();
        });
    </script>

    <script>
        // ── Loader helpers ──
        function showLoader() { const loader = document.getElementById('loader-dashboard'); if (loader) loader.style.display = 'flex'; }
        function hideLoader() { const loader = document.getElementById('loader-dashboard'); if (loader) loader.style.display = 'none'; }

        window.handleRefresh = async () => {
            const btn = document.getElementById('refresh-btn');
            const icon = document.getElementById('refresh-icon');
            const text = document.getElementById('refresh-btn-text');

            if (btn) btn.disabled = true;
            if (text) text.innerText = 'Refreshing…';
            if (icon) { icon.style.display = 'inline-block'; icon.style.animation = 'spin 1s linear infinite'; }
            await fetchDashboardData();
            if (btn) btn.disabled = false;
            if (text) text.innerText = 'Refresh';
            if (icon) icon.style.animation = 'none';
        };

        // ── Design tokens ──
        // ── Theme-aware palette: values follow <html data-theme="dark|light"> ──
        // Charts read these as real hex (SVG/canvas can't use CSS vars), so the
        // dashboard re-renders when the theme is toggled.
        const THEME_PALETTES = {
            dark: {
                mode: "dark", bg: "#0B0F1A", surface: "#111827", card: "#161D2E", border: "#1E2A42",
                accent: "#E8A820", muted: "#4B5563", text: "#E2E8F0", textDim: "#94A3B8", textFaint: "#4B5563",
            },
            light: {
                mode: "light", bg: "#F4F6FA", surface: "#FFFFFF", card: "#F8FAFC", border: "#E2E8F0",
                accent: "#B7791F", muted: "#94A3B8", text: "#0F172A", textDim: "#475569", textFaint: "#94A3B8",
            },
        };
        const getTheme = () => document.documentElement.getAttribute('data-theme') === 'light' ? 'light' : 'dark';
        const C = {
            accentLo: "#E8A82018",
            blue: "#3B82F6",
            blueLo: "#3B82F618",
            green: "#10B981",
            greenLo: "#10B98118",
            red: "#EF4444",
            redLo: "#EF444418",
            yellow: "#F59E0B",
        };
        Object.keys(THEME_PALETTES.dark).forEach(k => {
            Object.defineProperty(C, k, {enumerable: true, get: () => THEME_PALETTES[getTheme()][k]});
        });

        // ── Dark / Light theme (driven by the PerformIQ shell) ─────────────────────────
        function updateThemeToggleLabel() {
            const isLight = getTheme() === 'light';
            const icon = document.getElementById('theme-toggle-icon');
            const text = document.getElementById('theme-toggle-text');
            if (icon) icon.textContent = isLight ? '🌙' : '☀️';
            if (text) text.textContent = isLight ? 'Dark' : 'Light';
        }
        window.setTheme = (theme, persist = true) => {
            theme = theme === 'light' ? 'light' : 'dark';
            if (getTheme() === theme && !persist) return;
            document.documentElement.setAttribute('data-theme', theme);
            if (persist) { try { localStorage.setItem('performiq-theme', theme); } catch (e) {} }
            updateThemeToggleLabel();
            try { renderDashboard(); } catch (e) { console.warn('re-render after theme change failed', e); }
        };
        window.toggleTheme = () => setTheme(getTheme() === 'light' ? 'dark' : 'light');
        // Shell (or another tab) changed the theme
        window.addEventListener('storage', (e) => {
            if (e.key === 'performiq-theme') setTheme(e.newValue, false);
        });
        document.addEventListener('DOMContentLoaded', updateThemeToggleLabel);
        const PLATFORM_COLORS = { Meta: "#1877F2", Google: "#4285F4", LinkedIn: "#0A66C2", DV360: "#34A853", Taboola: "#3B82F6", Website: "#10B981", Other: "#8B5CF6" };
        const PIE_COLORS = ["#3B82F6", "#3B82F6", "#10B981", "#EF4444", "#8B5CF6", "#F59E0B", "#06B6D4"];

        // ── Global App State ──
        const state = {
            activeTab: 'executive', isLoading: true, ajaxError: null, rawData: null,
            campaigns: [], filteredCampaigns: [], trends: [], funnel: [],
            projectName: 'Loading…', dateRange: 'Loading…', insights: null, loadingInsights: false, uploadStatus: null,
            filterPlatform: 'All', filterStatus: 'all', searchQuery: '',
            isDatePickerOpen: false, tempPreset: 'last_30d', tempStartDate: null, tempEndDate: null, hoverDate: null, calendarMonth: new Date(),
            dtPage: 1, dtPageSize: 5, dtSortCol: '', dtSortDir: 1, dtSearch: '',
            // CRM totals (all Taboola leads in range, regardless of utm_campaignname)
            totalQualifiedCrm: 0, totalWalkinsCrm: 0,
            allQualLeads: [], allWalkLeads: []
        };

        const TABS = [
            { id: "executive", label: "Executive Summary", icon: "🎯" },
            { id: "campaigns", label: "Campaigns", icon: "📊" },
            { id: "trend", label: "Spend Trend", icon: "📈" },
            { id: "funnel", label: "Funnel Analysis", icon: "🔻" },
            { id: "insights", label: "AI Insights", icon: "🤖" },
        ];

        // ── Formatting Helpers ──
        const fmt = (n, prefix = "₹") => (!n && n !== 0) ? `${prefix}0` : `${prefix}${Math.round(n).toLocaleString("en-IN")}`;
        const fmtD = (n, prefix = "₹") => (!n && n !== 0) ? `${prefix}0.00` : `${prefix}${n.toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
        const fmtN = n => (!n && n !== 0) ? "0" : Math.round(n).toLocaleString("en-IN");
        const pct = n => `${(n || 0).toFixed(1)}%`;
        const fmtSpend = n => fmtD(n);
        const fmtImpressions = n => fmtN(n);
        const fmtCTR = n => `${(n || 0).toFixed(2)}%`;
        const fmtCPM = n => fmtD(n);
        const fmtCPL = n => fmtD(n);
        const statusColor = s => s === "good" ? C.green : s === "warn" ? C.yellow : C.red;
        const statusLabel = s => s === "good" ? "▲ Strong" : s === "warn" ? "◆ Review" : "▼ Poor";

        // ── Mapping Data (Taboola adaptation) ──
        const mapPhpDataToDashboard = (phpData) => {
            const phpCamps = phpData.campaigns || [];
            const phpTrends = phpData.trend || [];

            const mappedCampaigns = phpCamps.map((c) => {
                const name = c.name || "Unknown Campaign";
                const platform = c.platform || "Taboola";

                const spend = Number(c.spend || 0);
                const impressions = Number(c.impressions || 0);
                const clicks = Number(c.clicks || 0);
                const leads = Number(c.leads || 0);

                const qualified = Number(c.qualified || 0);
                const walkins = Number(c.walkins || 0);

                const cpl = Number(c.cpl || 0);
                const cpql = Number(c.cpql || 0);
                const cpsv = Number(c.cpsv || 0);

                const cpc = clicks > 0 ? Number((spend / clicks).toFixed(2)) : 0;
                const ctr = Number(c.ctr || 0);
                const cpm = Number(c.cpm || 0);

                let status = "warn";
                if (leads > 0 && cpl < 500) status = "good";
                else if (cpl > 1200 || (spend > 10000 && leads === 0)) status = "bad";

                return {
                    campaign: name, campaignStatus: c.campStatus || "", platform, spend, impressions, clicks, leads,
                    qualified, walkins, bookings: 0, cpl, cpql, cpsv, cpc, ctr, cpm, status, subsource: "Taboola",
                    qualified_leads: c.qualified_leads || [], walkin_leads: c.walkin_leads || []
                };
            });

            const sumImpr   = mappedCampaigns.reduce((a, c) => a + c.impressions, 0);
            const sumClicks = mappedCampaigns.reduce((a, c) => a + c.clicks, 0);
            const sumLeads  = mappedCampaigns.reduce((a, c) => a + c.leads, 0);

            // Use the backend-precomputed totals (all Taboola leads in date range,
            // regardless of utm_campaignname) for qualified / walk-in counts.
            const sumQual = Number(phpData.total_qualified_crm || 0);
            const sumWalk = Number(phpData.total_walkins_crm   || 0);

            // Flatten per-campaign arrays as fallback for modal drill-down.
            const allQualLeads  = phpData.all_qualified_leads || [];
            const allWalkLeads  = phpData.all_walkin_leads    || [];

            const finalFunnel = [
                { stage: "Impressions",     value: sumImpr,   pct: 100 },
                { stage: "Clicks",          value: sumClicks, pct: sumImpr   > 0 ? Number((sumClicks / sumImpr   * 100).toFixed(2)) : 0 },
                { stage: "Leads",           value: sumLeads,  pct: sumClicks > 0 ? Number((sumLeads  / sumClicks * 100).toFixed(2)) : 0 },
                { stage: "Qualified Leads", value: sumQual,   pct: sumLeads  > 0 ? Number((sumQual   / sumLeads  * 100).toFixed(2)) : 0 },
                { stage: "Walk-ins",        value: sumWalk,   pct: sumQual   > 0 ? Number((sumWalk   / sumQual   * 100).toFixed(2)) : 0 },
                { stage: "Bookings",        value: 0,         pct: 0 },
            ];

            return {
                campaigns: mappedCampaigns,
                trends: phpTrends,
                funnel: finalFunnel,
                projectName: "Taboola Native Ads Portfolio",
                dateRange: phpData.date_preset || "last 30 days",
                // Expose CRM totals for KPI cards and modal drill-down
                totalQualifiedCrm: sumQual,
                totalWalkinsCrm:   sumWalk,
                allQualLeads,
                allWalkLeads,
            };
        };


        // ── UI Components Generators ──
        const renderInsightCardHTML = (icon, label, items = [], color = C.accent) => {
            const listHTML = items.map(item => `<div style="display:flex; gap:8px; align-items:flex-start;"><span style="color:${color}; font-size:10px; margin-top:5px; flex-shrink:0;">◆</span><span style="color:${C.text}; font-size:12.5px; line-height:1.6;">${item}</span></div>`).join('');
            return `<div style="background:${C.card}; border:1px solid ${C.border}; border-radius:12px; padding:16px 18px; display:flex; flex-direction:column; gap:8px;"><div style="display:flex; align-items:center; gap:8px; margin-bottom:4px;"><span style="font-size:16px;">${icon}</span><span style="color:${color}; font-family:'Sora'; font-weight:600; font-size:12px; text-transform:uppercase; letter-spacing:0.08em;">${label}</span></div>${items.length === 0 ? `<span style="color:${C.textFaint}; font-size:12px;">No insights available.</span>` : listHTML}</div>`;
        };

        const renderKpiCardHTML = (label, value, sub, delta, status) => {
            const borderVal = status ? `${statusColor(status)}44` : C.border;
            const topBar = status ? `<div style="position:absolute; top:0; left:0; right:0; height:2px; background:${statusColor(status)};"></div>` : '';
            const statusTag = status ? `<div style="position:absolute; top:16px; right:16px; display:flex; align-items:center; gap:4px; font-size:10px; color:${statusColor(status)}; font-weight:600;">${statusLabel(status)}</div>` : '';
            return `<div style="background:${C.card}; border:1px solid borderVal; border-radius:12px; padding:18px 20px; position:relative; overflow:hidden;">${topBar}<div style="color:${C.textDim}; font-size:11px; font-family:'Sora'; font-weight:500; text-transform:uppercase; letter-spacing:0.07em; margin-bottom:8px; padding-right:48px; line-height:1.3;">${label}</div><div style="color:${C.text}; font-family:'JetBrains Mono'; font-size:20px; font-weight:500;">${value}</div>${sub ? `<div style="margin-top:6px; color:${C.textDim}; font-size:11px;">${sub}</div>` : ''}${statusTag}</div>`;
        };

        const activeCharts = {};
        function renderChart(elId, type, options) {
            if (activeCharts[elId]) { activeCharts[elId].destroy(); activeCharts[elId] = null; }
            const el = document.getElementById(elId);
            if (!el) return;
            const chart = new ApexCharts(el, options);
            chart.render();
            activeCharts[elId] = chart;
        }

        // ── Vanilla Custom Date Picker Logic ──
        function getQueryParam(name) {
            const urlParams = new URLSearchParams(window.location.search);
            return urlParams.get(name);
        }

        function getPresetDates(presetName) {
            const today = new Date(); today.setHours(0, 0, 0, 0);
            let since = new Date();
            let until = new Date();
            switch (presetName) {
                case 'today': break;
                case 'yesterday': since.setDate(today.getDate() - 1); until.setDate(today.getDate() - 1); break;
                case 'last_7d': since.setDate(today.getDate() - 7); until.setDate(today.getDate() - 1); break;
                case 'last_30d': since.setDate(today.getDate() - 30); until.setDate(today.getDate() - 1); break;
                case 'this_month': since = new Date(today.getFullYear(), today.getMonth(), 1); until = today; break;
                case 'last_month': since = new Date(today.getFullYear(), today.getMonth() - 1, 1); until = new Date(today.getFullYear(), today.getMonth(), 0); break;
            }
            return { since: since.toISOString().split('T')[0], until: until.toISOString().split('T')[0] };
        }

        function parsedInitialDates() {
            const initialSince = getQueryParam('since');
            const initialUntil = getQueryParam('until');
            const initialPreset = getQueryParam('preset');
            if (initialSince && initialUntil) return { since: new Date(initialSince), until: new Date(initialUntil) };
            const presetVal = initialPreset || 'last_30d';
            const dates = getPresetDates(presetVal);
            return { since: new Date(dates.since), until: new Date(dates.until) };
        }

        const generateCalendarCells = (year, month) => {
            const cells = [];
            const daysInMonth = new Date(year, month + 1, 0).getDate();
            const firstDay = new Date(year, month, 1).getDay();
            const prevMonth = month === 0 ? 11 : month - 1;
            const prevYear = month === 0 ? year - 1 : year;
            const daysInPrevMonth = new Date(prevYear, prevMonth + 1, 0).getDate();
            for (let i = firstDay - 1; i >= 0; i--) { const day = daysInPrevMonth - i; cells.push({ date: new Date(prevYear, prevMonth, day), isCurrentMonth: false, dayNumber: day }); }
            for (let i = 1; i <= daysInMonth; i++) { cells.push({ date: new Date(year, month, i), isCurrentMonth: true, dayNumber: i }); }
            const remaining = 42 - cells.length;
            const nextMonth = month === 11 ? 0 : month + 1;
            const nextYear = month === 11 ? year + 1 : year;
            for (let i = 1; i <= remaining; i++) { cells.push({ date: new Date(nextYear, nextMonth, i), isCurrentMonth: false, dayNumber: i }); }
            return cells;
        };

        window.toggleDatePicker = (e) => {
            if (e) e.stopPropagation();
            state.isDatePickerOpen = !state.isDatePickerOpen;
            const popup = document.getElementById('date-picker-popup');
            if (state.isDatePickerOpen) { popup.style.display = 'flex'; renderDatePickerPopup(); }
            else { popup.style.display = 'none'; }
        };

        window.handlePrevMonth = (e) => { e.stopPropagation(); state.calendarMonth = new Date(state.calendarMonth.getFullYear(), state.calendarMonth.getMonth() - 1, 1); renderDatePickerPopup(); };
        window.handleNextMonth = (e) => { e.stopPropagation(); state.calendarMonth = new Date(state.calendarMonth.getFullYear(), state.calendarMonth.getMonth() + 1, 1); renderDatePickerPopup(); };

        window.handlePresetClick = (presetId) => {
            // "Last 1 Year" / "All Time" (assets/js/date_presets.js): sent as dates, never as a Meta / Google preset
            const extra = window.PQDates && PQDates.range(presetId);
            if (extra) {
                state.presetAlias = presetId;
                state.tempPreset = 'custom';
                state.tempStartDate = new Date(extra.since);
                state.tempEndDate = new Date(extra.until);
                renderDatePickerPopup();
                return;
            }
            state.presetAlias = null;
            state.tempPreset = presetId;
            if (presetId !== 'custom') {
                const dates = getPresetDates(presetId);
                state.tempStartDate = new Date(dates.since);
                state.tempEndDate = new Date(dates.until);
            }
            renderDatePickerPopup();
        };

        window.handleCellClick = (el) => {
            state.presetAlias = null;
            const date = new Date(el.getAttribute('data-date'));
            state.tempPreset = 'custom';
            if (!state.tempStartDate || (state.tempStartDate && state.tempEndDate)) { state.tempStartDate = date; state.tempEndDate = null; }
            else if (state.tempStartDate && !state.tempEndDate) { if (date < state.tempStartDate) state.tempStartDate = date; else state.tempEndDate = date; }
            renderDatePickerPopup();
        };

        window.handleCellMouseEnter = (el) => {
            const date = new Date(el.getAttribute('data-date'));
            if (state.tempStartDate && !state.tempEndDate) {
                state.hoverDate = date;
                document.querySelectorAll('.calendar-cell').forEach(cell => {
                    const cDate = new Date(cell.getAttribute('data-date'));
                    const isStart = state.tempStartDate && cDate.toDateString() === state.tempStartDate.toDateString();
                    let inRange = cDate > state.tempStartDate && cDate < date;
                    if (!isStart) {
                        if (inRange) { cell.style.background = C.accentLo; cell.style.color = C.accent; }
                        else { cell.style.background = 'transparent'; cell.style.color = cell.classList.contains('current-month') ? C.text : C.textDim + "44"; }
                    }
                });
            }
        };

        window.handleDatePickerCancel = (e) => { e.stopPropagation(); state.isDatePickerOpen = false; document.getElementById('date-picker-popup').style.display = 'none'; const parsed = parsedInitialDates(); state.tempStartDate = parsed.since; state.tempEndDate = parsed.until; state.tempPreset = getQueryParam('since') ? 'custom' : (getQueryParam('preset') || 'last_30d'); };

        window.handleDatePickerApply = (e) => {
            e.stopPropagation(); state.isDatePickerOpen = false; document.getElementById('date-picker-popup').style.display = 'none';
            if (state.tempPreset === 'custom') { if (state.tempStartDate && state.tempEndDate) fetchDashboardData(); } else { fetchDashboardData(); }
        };

        // ── PerformIQ: one date filter for every dashboard (main dashboard top bar) + "Target vs Achieved" card ──
        (function () {
            const PQ_PLATFORM = 'taboola';
            const EMBED = /[?&]embed=1(&|$)/.test(location.search);
            const f2 = d => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
            const rangeNow = () => {
                if (state.tempPreset === 'custom' && state.tempStartDate && state.tempEndDate) return { since: f2(state.tempStartDate), until: f2(state.tempEndDate) };
                const d = getPresetDates(state.tempPreset || 'last_30d');
                return { since: d.since, until: d.until };
            };
            let tg = null;
            const tgUpdate = () => { if (tg) { try { tg.update(rangeNow()); } catch (e) { /* dates not ready yet */ } } };
            const origApply = window.handleDatePickerApply;
            window.handleDatePickerApply = (e) => { origApply(e); tgUpdate(); };
            // the main dashboard sends its dates to every embedded dashboard
            window.addEventListener('message', (e) => {
                const d = e.data;
                if (!d || d.type !== 'pq-range' || e.source !== window.parent || !d.since || !d.until) return;
                const cur = rangeNow();
                if (cur.since === d.since && cur.until === d.until && state.rawData) { tgUpdate(); return; }
                state.tempPreset = 'custom';
                state.tempStartDate = new Date(d.since + 'T00:00:00');
                state.tempEndDate = new Date(d.until + 'T00:00:00');
                window.fetchDashboardData();
                tgUpdate();
            });
            const ready = fn => document.readyState === 'loading' ? document.addEventListener('DOMContentLoaded', fn) : fn();
            ready(() => {
                if (EMBED) {                                   // one date filter: the main dashboard's
                    const l = document.getElementById('date-range-display');
                    const box = l && l.closest('div[style*="flex-direction:column"]');
                    if (box) box.style.display = 'none';
                }
                if (window.PQTargets && !(window.PQ_CAN && window.PQ_CAN.targets === false)) {
                    const host = document.createElement('div');
                    host.id = 'pq-targets';
                    const after = document.getElementById('filters-container');
                    if (after) after.after(host); else document.body.prepend(host);
                    tg = PQTargets.mount(host, { api: '../targets_api.php', platform: PQ_PLATFORM, editUrl: '../dashboard.php#targets' });
                    setTimeout(tgUpdate, 0);
                }
            });
        })();

        const renderCalendarHTML = (monthDate, isLeft) => {
            const year = monthDate.getFullYear(); const month = monthDate.getMonth(); const monthName = monthDate.toLocaleString('default', { month: 'long' });
            const cells = generateCalendarCells(year, month);
            const weekDays = ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'];
            const prevBtn = isLeft ? `<button onclick="handlePrevMonth(event)" style="position: absolute; left: 0; background: none; border: none; color: ${C.text}; cursor: pointer; font-weight: bold; outline:none;">◀</button>` : '';
            const nextBtn = !isLeft ? `<button onclick="handleNextMonth(event)" style="position: absolute; right: 0; background: none; border: none; color: ${C.text}; cursor: pointer; font-weight: bold; outline:none;">▶</button>` : '';
            const weekHeaders = weekDays.map(d => `<span style="color: ${C.textDim}; font-size: 10px; font-weight: 600;">${d}</span>`).join('');
            const cellElements = cells.map((cell) => {
                const isSelectedStart = state.tempStartDate && cell.date.toDateString() === state.tempStartDate.toDateString();
                const isSelectedEnd = state.tempEndDate && cell.date.toDateString() === state.tempEndDate.toDateString();
                let isInRange = false;
                if (state.tempStartDate && state.tempEndDate) isInRange = cell.date > state.tempStartDate && cell.date < state.tempEndDate;
                else if (state.tempStartDate && state.hoverDate) isInRange = (cell.date > state.tempStartDate && cell.date < state.hoverDate) || (cell.date < state.tempStartDate && cell.date > state.hoverDate);
                const isSelected = isSelectedStart || isSelectedEnd;
                let bg = "transparent", color = cell.isCurrentMonth ? C.text : C.textDim + "44", borderRadius = "4px";
                if (isSelected) { bg = C.accent; color = "#ffffff"; borderRadius = "50%"; } else if (isInRange) { bg = C.accentLo; color = C.accent; }
                return `<div class="calendar-cell ${cell.isCurrentMonth ? 'current-month' : ''}" data-date="${cell.date.toISOString()}" onmouseenter="handleCellMouseEnter(this)" onclick="handleCellClick(this)" style="height: 28px; display: flex; align-items: center; justify-content: center; font-size: 11px; cursor: pointer; background: ${bg}; color: ${color}; border-radius: ${borderRadius}; font-weight: ${isSelected ? 'bold' : 'normal'};">${cell.dayNumber}</div>`;
            }).join('');
            return `<div style="width: 240px;"><div style="display: flex; justify-content: center; align-items: center; margin-bottom: 12px; position: relative;">${prevBtn}<span style="color: ${C.text}; font-weight: 600; font-size: 13px;">${monthName} ${year}</span>${nextBtn}</div><div style="display: grid; grid-template-columns: repeat(7, 1fr); gap: 4px; margin-bottom: 8px; text-align: center;">${weekHeaders}</div><div style="display: grid; grid-template-columns: repeat(7, 1fr); gap: 4px;">${cellElements}</div></div>`;
        };

        function renderDatePickerPopup() {
            const popup = document.getElementById('date-picker-popup'); if (!popup) return;
            const leftMonth = state.calendarMonth; const rightMonth = new Date(state.calendarMonth.getFullYear(), state.calendarMonth.getMonth() + 1, 1);
            const formatDateDMY = (date) => { if (!date) return ''; return `${String(date.getDate()).padStart(2, '0')}/${String(date.getMonth() + 1).padStart(2, '0')}/${date.getFullYear()}`; };
            const PRESETS = [{ id: 'today', label: 'Today' }, { id: 'yesterday', label: 'Yesterday' }, { id: 'last_7d', label: 'Last 7 Days' }, { id: 'last_30d', label: 'Last 30 Days' }, { id: 'this_month', label: 'This Month' }, { id: 'last_month', label: 'Last Month' }, { id: 'last_1y', label: 'Last 1 Year' }, { id: 'all_time', label: 'All Time' }, { id: 'custom', label: 'Custom Range' }];
            const presetsHTML = PRESETS.map(p => `<button onclick="handlePresetClick('${p.id}')" style="background: ${(state.presetAlias ? state.presetAlias === p.id : state.tempPreset === p.id) ? C.accent : 'transparent'}; color: ${(state.presetAlias ? state.presetAlias === p.id : state.tempPreset === p.id) ? '#ffffff' : C.text}; border: none; border-radius: 6px; padding: 8px 12px; text-align: left; cursor: pointer; font-size: 12px; font-weight: ${(state.presetAlias ? state.presetAlias === p.id : state.tempPreset === p.id) ? 600 : 400}; outline: none;">${p.label}</button>`).join('');
            const displayRange = state.tempStartDate ? (state.tempEndDate ? `${formatDateDMY(state.tempStartDate)} - ${formatDateDMY(state.tempEndDate)}` : `${formatDateDMY(state.tempStartDate)} - Select End Date`) : "Select Date Range";
            popup.innerHTML = `<div style="display: flex; gap: 20px;"><div style="display: flex; flex-direction: column; gap: 4px; border-right: 1px solid ${C.border}; padding-right: 16px; width: 140px;">${presetsHTML}</div><div style="display: flex; gap: 24px; flex-grow: 1;">${renderCalendarHTML(leftMonth, true)}${renderCalendarHTML(rightMonth, false)}</div></div><div style="display: flex; justify-content: space-between; align-items: center; border-top: 1px solid ${C.border}; margin-top: 16px; padding-top: 16px;"><span style="color: ${C.text}; font-size: 12px; font-family: 'JetBrains Mono';">${displayRange}</span><div style="display: flex; gap: 10px;"><button onclick="handleDatePickerCancel(event)" style="background: ${C.card}; color: ${C.text}; border: 1px solid ${C.border}; border-radius: 6px; padding: 6px 16px; font-size: 12px; font-weight: 600; cursor: pointer;">CANCEL</button><button onclick="handleDatePickerApply(event)" ${(!state.tempStartDate || !state.tempEndDate) ? 'disabled' : ''} style="background: ${(!state.tempStartDate || !state.tempEndDate) ? C.muted : C.accent}; color: #ffffff; border: none; border-radius: 6px; padding: 6px 16px; font-size: 12px; font-weight: 600; cursor: ${(!state.tempStartDate || !state.tempEndDate) ? 'not-allowed' : 'pointer'};">APPLY</button></div></div>`;
        }

        document.addEventListener("mousedown", (event) => {
            const popup = document.getElementById('date-picker-popup');
            const trigger = event.target.closest('[onclick="toggleDatePicker(event)"]');
            if (popup && !popup.contains(event.target) && !trigger && state.isDatePickerOpen) { state.isDatePickerOpen = false; popup.style.display = 'none'; }
        });

        // ── Client-side filtering logic ──
        window.handleSearchInput = (el) => { state.searchQuery = el.value; document.getElementById('search-clear-btn').style.display = el.value ? 'block' : 'none'; updateFilteredStateAndRender(); };
        window.clearSearchInput = () => { state.searchQuery = ""; const input = document.getElementById('search-query'); if (input) input.value = ""; document.getElementById('search-clear-btn').style.display = 'none'; updateFilteredStateAndRender(); };

        function updateFilteredStateAndRender() {
            const filtered = state.campaigns.filter(c => {
                if (state.searchQuery && !c.campaign.toLowerCase().includes(state.searchQuery.toLowerCase())) return false;
                return true;
            });
            state.filteredCampaigns = filtered;
            renderDashboard();
        }

        // ── Tab Navigation ──
        window.handleTabChange = (tabId) => { state.activeTab = tabId; renderDashboard(); };

        // ── AI Insights (real AI via Groq + Taboola-specific prompt, with local fallback) ──
        window.handleGenerateInsights = async (e) => {
            if (e) e.preventDefault();
            state.loadingInsights = true;
            state.activeTab = "insights";
            renderDashboard();

            const totalSpend   = state.filteredCampaigns.reduce((a, c) => a + c.spend, 0);
            const totalLeads   = state.filteredCampaigns.reduce((a, c) => a + c.leads, 0);
            const totalWalkins = state.filteredCampaigns.reduce((a, c) => a + c.walkins, 0);
            const totalQual    = state.filteredCampaigns.reduce((a, c) => a + c.qualified, 0);
            const avgCPL       = totalLeads > 0 ? Math.round(totalSpend / totalLeads) : 0;

            const refreshText  = document.getElementById('insights-refresh-text');
            const globalBtnText = document.getElementById('ai-insights-btn-text');
            if (refreshText)   refreshText.innerText  = "Analyzing…";
            if (globalBtnText) globalBtnText.innerText = "Analyzing…";

            // Build Taboola-specific payload (top 25 campaigns by spend)
            const payload = {
                platform: "Taboola",
                summary: {
                    total_spend:     totalSpend,
                    total_leads:     totalLeads,
                    total_walkins:   totalWalkins,
                    total_qualified: totalQual,
                    avg_cpl:         avgCPL,
                    date_range:      state.dateRange || null
                },
                campaigns: [...state.filteredCampaigns]
                    .sort((a, b) => b.spend - a.spend)
                    .slice(0, 25)
                    .map(c => ({
                        campaign_name: c.campaign || 'Unknown Campaign',
                        status:        c.campaignStatus || '',
                        spend:         c.spend,
                        impressions:   c.impressions,
                        clicks:        c.clicks,
                        ctr:           c.ctr,
                        cpm:           c.cpm,
                        cpc:           c.cpc,
                        leads:         c.leads,
                        cpl:           c.leads > 0 ? Math.round(c.spend / c.leads) : 0,
                        qualified:     c.qualified,
                        cpql:          c.cpql,
                        walkins:       c.walkins,
                        cpsv:          c.cpsv
                    }))
            };

            try {
                const res  = await fetch('taboola_insights_api.php', {
                    method:  'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body:    JSON.stringify(payload)
                });
                const data = await res.json();

                if (data.success && data.analysis) {
                    state.insights = { ...data.analysis, _source: 'ai' };
                } else {
                    console.warn('AI Insights failed, falling back to local insights:', data);
                    state.insights = generateLocalTaboolaInsights(
                        state.filteredCampaigns, totalSpend, totalLeads, avgCPL
                    );
                    state.insights._source = 'local';
                }
            } catch (err) {
                console.error('AI Insights request error, falling back to local insights:', err);
                state.insights = generateLocalTaboolaInsights(
                    state.filteredCampaigns, totalSpend, totalLeads, avgCPL
                );
                state.insights._source = 'local';
            }

            state.loadingInsights = false;
            if (globalBtnText) globalBtnText.innerText = "Generate AI Insights";
            renderDashboard();
        };

        // ── Local Taboola fallback (used when Groq is unavailable) ──
        function generateLocalTaboolaInsights(campaigns, totalSpend, totalLeads, avgCPL) {
            const sorted   = [...campaigns].sort((a, b) => b.spend - a.spend);
            const best     = sorted.find(c => c.leads > 0) || sorted[0];
            const worst    = [...campaigns].sort((a, b) => (b.spend / (b.leads || 0.001)) - (a.spend / (a.leads || 0.001)))[0];
            const highCTR  = campaigns.filter(c => c.ctr >= 0.5).length;
            const lowCTR   = campaigns.filter(c => c.ctr < 0.3 && c.spend > 5000).length;
            return {
                executiveSummary: `Taboola Native Ads portfolio: ₹${fmtN(totalSpend)} spent, ${fmtN(totalLeads)} leads at avg CPL ₹${fmtN(avgCPL)}. ${highCTR} campaigns above native benchmark CTR.`,
                keyWins: [
                    best ? `Best performer: "${best.campaign}" delivering leads at ₹${fmtN(best.cpl)} CPL.` : 'Monitor active campaigns for CTR trends.',
                    `${highCTR} campaign(s) achieve CTR ≥ 0.5% (above native benchmark).`
                ],
                majorConcerns: [
                    lowCTR > 0 ? `${lowCTR} campaign(s) have CTR < 0.3% with significant spend — likely creative fatigue or publisher mismatch.` : 'CTR levels are within acceptable range.',
                    worst ? `"${worst.campaign}" has the highest CPL — review publisher site exclusions and thumbnail creative.` : 'Review underperforming campaigns regularly.'
                ],
                optimizationOpportunities: [
                    'A/B test thumbnail images — high-emotion real estate visuals outperform generic renders.',
                    'Exclude low-converting publisher sites to improve lead quality.',
                    'Test shorter, curiosity-driven headlines (under 60 chars) to boost CTR.'
                ],
                actionableNextSteps: [
                    'Refresh thumbnails for campaigns with CTR < 0.3%.',
                    'Review publisher site exclusion list weekly.',
                    'Increase budget on top-CTR campaigns by 15–20% WoW.'
                ]
            };
        }

        // pagination start
        function dtGetFiltered() {
            let d = state.filteredCampaigns;
            if (state.dtSearch) d = d.filter(c => c.campaign.toLowerCase().includes(state.dtSearch.toLowerCase()));
            if (state.dtSortCol) {
                const k = state.dtSortCol, dir = state.dtSortDir;
                d = [...d].sort((a, b) => {
                    const av = typeof a[k] === 'string' ? a[k] : +a[k];
                    const bv = typeof b[k] === 'string' ? b[k] : +b[k];
                    return av < bv ? -dir : av > bv ? dir : 0;
                });
            }
            return d;
        }

        window.dtSort = (col) => {
            if (state.dtSortCol === col) state.dtSortDir *= -1;
            else { state.dtSortCol = col; state.dtSortDir = 1; }
            state.dtPage = 1;
            document.querySelectorAll('#camps-table th').forEach(th => {
                th.classList.remove('sorted-asc', 'sorted-desc');
                if (th.dataset.col === col) th.classList.add(state.dtSortDir === 1 ? 'sorted-asc' : 'sorted-desc');
            });
            renderCampaignsTable();
        };

        window.dtGoTo = (p) => { state.dtPage = p; renderCampaignsTable(); };
        window.dtSetPageSize = (n) => { state.dtPageSize = n; state.dtPage = 1; renderCampaignsTable(); };
        window.dtSetSearch = (v) => { state.dtSearch = v; state.dtPage = 1; renderCampaignsTable(); };

        function renderCampaignsTable() {
            const all = dtGetFiltered();
            const ps = state.dtPageSize === -1 ? all.length : state.dtPageSize;
            const total = all.length;
            const pages = Math.max(1, Math.ceil(total / ps));
            if (state.dtPage > pages) state.dtPage = pages;
            const start = (state.dtPage - 1) * ps;
            const slice = all.slice(start, Math.min(start + ps, total));

            const tableRowsHTML = slice.map(c => `
                <tr>
                  <td><span style="display:inline-block;width:9px;height:9px;border-radius:50%;background:${c.campaignStatus === 'RUNNING' ? C.green : c.campaignStatus === 'PAUSED' ? C.red : C.yellow};" title="${c.campaignStatus}"></span></td>
                  <td style="font-weight:500;max-width:200px;"><div style="white-space:nowrap;overflow:hidden;text-overflow:ellipsis;" title="${c.campaign}">${c.campaign}</div></td>
                  <td><span class="badge" style="background:${(PLATFORM_COLORS[c.platform] || PLATFORM_COLORS.Other)}20;color:${PLATFORM_COLORS[c.platform] || PLATFORM_COLORS.Other};border:1px solid ${(PLATFORM_COLORS[c.platform] || PLATFORM_COLORS.Other)}44;border-radius:4px;padding:2px 8px;font-size:10px;font-weight:600;text-transform:uppercase;">${c.platform}</span></td>
                  <td class="mono">${fmtSpend(c.spend)}</td>
                  <td class="mono">${fmtImpressions(c.impressions)}</td>
                  <td class="mono">${fmtN(c.clicks)}</td>
                  <td class="mono" style="color:${c.ctr >= 1.5 ? C.green : c.ctr >= 0.8 ? C.yellow : C.red}">${fmtCTR(c.ctr)}</td>
                  <td class="mono">${fmtCPM(c.cpm || 0)}</td>
                  <td class="mono" style="color:${C.accent};font-weight:600;">${c.leads}</td>
                  <td class="mono" style="color:${c.cpl > 0 && c.cpl < 1000 ? C.green : C.yellow};font-weight:600;">${fmtCPL(c.cpl || 0)}</td>
                  <td class="mono" style="color:${C.blue};font-weight:600;${c.qualified > 0 ? 'cursor:pointer;text-decoration:underline;' : ''}" ${c.qualified > 0 ? `onclick="openLeadsModalByCampaign('${encodeURIComponent(c.campaign)}', 'qualified_leads')"` : ''}>${fmtN(c.qualified)}</td>
                  <td class="mono" style="color:${C.textDim};">${fmtCPL(c.cpql)}</td>
                  <td class="mono" style="color:${C.green};font-weight:600;${c.walkins > 0 ? 'cursor:pointer;text-decoration:underline;' : ''}" ${c.walkins > 0 ? `onclick="openLeadsModalByCampaign('${encodeURIComponent(c.campaign)}', 'walkin_leads')"` : ''}>${fmtN(c.walkins)}</td>
                  <td class="mono" style="color:${C.textDim};">${fmtCPL(c.cpsv)}</td>
                </tr>`).join('');

            const tSpend = all.reduce((a, c) => a + c.spend, 0);
            const tImpr = all.reduce((a, c) => a + c.impressions, 0);
            const tClk = all.reduce((a, c) => a + c.clicks, 0);
            const tLeads = all.reduce((a, c) => a + c.leads, 0);
            const tQual = all.reduce((a, c) => a + c.qualified, 0);
            const tWalk = all.reduce((a, c) => a + c.walkins, 0);
            const tCTR = tImpr > 0 ? tClk / tImpr * 100 : 0;
            const tCPM = tImpr > 0 ? tSpend / tImpr * 1000 : 0;
            const totalRowHTML = `
                <tr style="background:${C.accentLo};border-top:2px solid ${C.accent}44;">
                  <td></td>
                  <td style="font-weight:700;color:${C.accent};font-size:12.5px;">TOTAL <span style="color:${C.textDim};font-size:10px;font-weight:400;">${total} campaigns</span></td>
                  <td></td>
                  <td class="mono" style="font-weight:700;color:${C.accent};">${fmtSpend(tSpend)}</td>
                  <td class="mono" style="font-weight:700;color:${C.accent};">${fmtImpressions(tImpr)}</td>
                  <td class="mono" style="font-weight:700;color:${C.accent};">${fmtN(tClk)}</td>
                  <td class="mono" style="font-weight:700;color:${tCTR >= 1.5 ? C.green : tCTR >= 0.8 ? C.yellow : C.red};">${fmtCTR(tCTR)}</td>
                  <td class="mono" style="font-weight:700;color:${C.accent};">${fmtCPM(tCPM)}</td>
                  <td class="mono" style="font-weight:700;color:${C.accent};">${fmtN(tLeads)}</td>
                  <td class="mono" style="font-weight:700;color:${tLeads > 0 && tSpend / tLeads < 1000 ? C.green : C.yellow};">${fmtCPL(tLeads > 0 ? tSpend / tLeads : 0)}</td>
                  <td class="mono" style="font-weight:700;color:${C.blue};${tQual > 0 ? 'cursor:pointer;text-decoration:underline;' : ''}" ${tQual > 0 ? `onclick="openLeadsModalTotal('qualified_leads')"` : ''}>${tQual > 0 ? fmtN(tQual) : '—'}</td>
                  <td class="mono" style="font-weight:700;">${tQual > 0 ? fmtCPL(tSpend / tQual) : '—'}</td>
                  <td class="mono" style="font-weight:700;color:${C.green};${tWalk > 0 ? 'cursor:pointer;text-decoration:underline;' : ''}" ${tWalk > 0 ? `onclick="openLeadsModalTotal('walkin_leads')"` : ''}>${tWalk > 0 ? fmtN(tWalk) : '—'}</td>
                  <td class="mono" style="font-weight:700;">${tWalk > 0 ? fmtCPL(tSpend / tWalk) : '—'}</td>
                </tr>`;

            const bodyEl = document.getElementById('dt-body');
            const footEl = document.getElementById('dt-foot');
            if (bodyEl) bodyEl.innerHTML = tableRowsHTML || `<tr><td colspan="14" style="text-align:center;color:${C.textDim};padding:24px;">No campaigns match filters.</td></tr>`;
            if (footEl) footEl.innerHTML = totalRowHTML;

            const s = total === 0 ? 0 : start + 1;
            const e = Math.min(start + ps, total);
            const infoEl = document.getElementById('dt-info');
            if (infoEl) infoEl.innerText = `Showing ${s} to ${e} of ${total} entries${state.dtSearch ? ' (filtered)' : ''}`;

            const pg = document.getElementById('dt-pagination');
            if (!pg) return;
            if (state.dtPageSize === -1 || pages <= 1) { pg.innerHTML = ''; return; }
            const btnS = `background:var(--pq-card);color:var(--pq-text-dim);border:1px solid var(--pq-border);border-radius:6px;padding:4px 10px;font-size:11px;cursor:pointer;font-family:'Sora',sans-serif;`;
            const btnA = `background:#3B82F6;color:#ffffff;border:1px solid #3B82F6;border-radius:6px;padding:4px 10px;font-size:11px;font-weight:700;cursor:pointer;font-family:'Sora',sans-serif;`;
            const delta = 2, lo = Math.max(1, state.dtPage - delta), hi = Math.min(pages, state.dtPage + delta);
            let btns = `<button style="${btnS}" onclick="dtGoTo(${state.dtPage - 1})" ${state.dtPage === 1 ? 'disabled' : ''}>‹ Prev</button>`;
            if (lo > 1) { btns += `<button style="${btnS}" onclick="dtGoTo(1)">1</button>`; if (lo > 2) btns += `<span style="color:var(--pq-muted);padding:0 4px">…</span>`; }
            for (let p = lo; p <= hi; p++) btns += `<button style="${p === state.dtPage ? btnA : btnS}" onclick="dtGoTo(${p})">${p}</button>`;
            if (hi < pages) { if (hi < pages - 1) btns += `<span style="color:var(--pq-muted);padding:0 4px">…</span>`; btns += `<button style="${btnS}" onclick="dtGoTo(${pages})">${pages}</button>`; }
            btns += `<button style="${btnS}" onclick="dtGoTo(${state.dtPage + 1})" ${state.dtPage === pages ? 'disabled' : ''}>Next ›</button>`;
            pg.innerHTML = btns;
        }
        // pagination end

        // ── Main UI Skeleton ──
        function renderSkeleton() {
            const container = document.getElementById('tab-content-container');
            if (!container) return;
            const filters = document.getElementById('filters-container');
            if (filters) filters.style.display = 'none';
            container.innerHTML = `<div style="padding: 28px 0; max-width: 1600px; margin: 0 auto;"><div style="display:grid; grid-template-columns:repeat(auto-fill,minmax(180px,1fr)); gap:14px; margin-bottom:24px;">${Array(8).fill().map(() => `<div style="background:${C.card}; border:1px solid ${C.border}; border-radius:12px; padding:18px 20px;"><div style="width:60%; height:11px; border-radius:4px; background:linear-gradient(90deg, ${C.card} 25%, ${C.surface} 50%, ${C.card} 75%); background-size:200% 100%; animation:shimmer 1.4s infinite linear;"></div><div style="margin-top:12px; width:80%; height:24px; border-radius:4px; background:linear-gradient(90deg, ${C.card} 25%, ${C.surface} 50%, ${C.card} 75%); background-size:200% 100%; animation:shimmer 1.4s infinite linear;"></div></div>`).join('')}</div></div>`;
        }

        // ── Main UI Rendering Orchestration ──
        function renderDashboard() {
            if (state.isLoading) { renderSkeleton(); return; }

            const filters = document.getElementById('filters-container');
            if (filters) filters.style.display = 'flex';

            const rangeDisplay = document.getElementById('date-range-display');
            if (rangeDisplay) {
                const fmt = d => d ? `${String(d.getDate()).padStart(2, '0')}/${String(d.getMonth() + 1).padStart(2, '0')}/${d.getFullYear()}` : '';
                if (state.tempPreset && state.tempPreset !== 'custom') {
                    const presetLabels = { today: 'Today', yesterday: 'Yesterday', last_7d: 'Last 7 Days', last_30d: 'Last 30 Days', this_month: 'This Month', last_month: 'Last Month' };
                    rangeDisplay.innerText = `📅 ${presetLabels[state.tempPreset] || state.tempPreset}`;
                } else if (state.tempStartDate && state.tempEndDate) {
                    rangeDisplay.innerText = `📅 ${fmt(state.tempStartDate)} – ${fmt(state.tempEndDate)}`;
                } else {
                    rangeDisplay.innerText = `📅 ${state.dateRange}`;
                }
            }

            const footerLeft = document.getElementById('footer-text-left');
            if (footerLeft) footerLeft.innerText = `PerfomIQ · ${state.projectName} · ${state.dateRange}`;

            const totalSpend = state.filteredCampaigns.reduce((a, c) => a + c.spend, 0);
            const totalLeads = state.filteredCampaigns.reduce((a, c) => a + c.leads, 0);

            // Use backend-precomputed CRM totals (all Taboola leads in range,
            // regardless of utm_campaignname) so uploaded qualified leads always show.
            const sumQual = state.totalQualifiedCrm || 0;
            const sumWalk = state.totalWalkinsCrm   || 0;

            const avgCPL  = totalLeads > 0 ? totalSpend / totalLeads : 0;
            const avgCpql = sumQual    > 0 ? totalSpend / sumQual    : 0;
            const avgCpsv = sumWalk    > 0 ? totalSpend / sumWalk    : 0;


            const tabsContainer = document.getElementById('tabs-container');
            if (tabsContainer) {
                tabsContainer.innerHTML = TABS.map(t => `<button class="tab-btn" onclick="handleTabChange('${t.id}')" style="padding: 14px 16px; display: flex; align-items: center; gap: 6px; color: ${state.activeTab === t.id ? C.accent : C.textDim}; border-bottom: ${state.activeTab === t.id ? `2px solid ${C.accent}` : '2px solid transparent'}; font-size: 12.5px; font-family: 'Sora'; font-weight: ${state.activeTab === t.id ? 600 : 400};"><span>${t.icon}</span>${t.label}</button>`).join('');
            }

            const container = document.getElementById('tab-content-container');
            if (!container) return;

            // 1. EXECUTIVE SUMMARY TAB
            if (state.activeTab === "executive") {
                container.innerHTML = `
          <div style="display: flex; flex-direction: column; gap: 24px;" class="animate-in">
            <div style="background: linear-gradient(135deg, ${C.card} 0%, #171020 100%); border: 1px solid ${C.border}; border-radius: 16px; padding: 24px 28px; display: flex; justify-content: space-between; align-items: center;">
              <div>
                <div style="color: ${C.accent}; font-size: 11px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.1em; margin-bottom: 6px;">Taboola Native Ads Portfolio</div>
                <div style="color: ${C.textDim}; font-size: 13px; margin-top: 4px;">Reporting: ${state.dateRange}</div>
              </div>
              <div style="font-size:32px;">📰</div>
            </div>
            <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(180px, 1fr)); gap: 14px; margin-bottom: 24px;">
              ${renderKpiCardHTML("Total Spend", fmtSpend(totalSpend), "Live Ad Spend", null, totalSpend > 10000 ? "good" : "warn")}
              ${renderKpiCardHTML("Total Leads", fmtN(totalLeads), `${state.campaigns.length} Active Camps`, null, totalLeads > 0 ? "good" : "warn")}
              ${renderKpiCardHTML("Average CPL", fmtCPL(avgCPL), "Portfolio CPL", null, avgCPL > 0 ? "good" : "warn")}
              ${renderKpiCardHTML("Qualified Leads", fmtN(sumQual), `${state.filteredCampaigns.length} Active Camps`, null, sumQual > 0 ? "good" : "warn")}
              ${renderKpiCardHTML("CPQL", sumQual > 0 ? fmtCPL(avgCpql) : "—", "Cost Per Qualified Lead", null, sumQual > 0 ? (avgCpql < 2000 ? "good" : "warn") : null)}
              ${renderKpiCardHTML("Site Visits", fmtN(sumWalk), "Walk-ins / Site Visits", null, sumWalk > 0 ? "good" : "warn")}
              ${renderKpiCardHTML("CPSV", sumWalk > 0 ? fmtCPL(avgCpsv) : "—", "Cost Per Site Visit", null, sumWalk > 0 ? (avgCpsv < 5000 ? "good" : "warn") : null)}
            </div>
            <div style="display: grid; grid-template-columns: 1fr; gap: 20px; margin-bottom: 24px;">
              <div style="background: ${C.card}; border: 1px solid ${C.border}; border-radius: 12px; padding: 20px;">
                <div style="color: ${C.text}; font-weight: 600; font-size: 14px; margin-bottom: 16px;">Portfolio Spend Distribution</div>
                <div id="spend-pie-chart"></div>
              </div>
            </div>
          </div>
        `;

                if (state.filteredCampaigns.length > 0 && totalSpend > 0) {
                    setTimeout(() => {
                        renderChart("spend-pie-chart", "donut", {
                            chart: { type: 'donut', height: 250, background: 'transparent', foreColor: C.textDim, fontFamily: 'Sora, sans-serif' },
                            series: state.filteredCampaigns.map(c => c.spend),
                            labels: state.filteredCampaigns.map(c => c.campaign),
                            colors: state.filteredCampaigns.map((_, i) => PIE_COLORS[i % PIE_COLORS.length]),
                            stroke: { show: false },
                            plotOptions: { pie: { donut: { size: '60%', labels: { show: true, name: { show: true }, value: { show: true, formatter: v => fmt(v) } } } } },
                            legend: { position: 'bottom', fontSize: '11px' },
                            theme: { mode: 'dark' }
                        });
                    }, 50);
                }
            }

            // 2. CAMPAIGNS TAB
            if (state.activeTab === "campaigns") {
                container.innerHTML = `
                  <div style="display:flex;flex-direction:column;gap:24px;" class="animate-in">
                                        <div style="margin-bottom:20px;display:flex;justify-content:space-between;align-items:center;">
                      <div>
                        <div style="color:${C.text};font-size:18px;font-weight:700;">Campaign Performance Analysis</div>
                        <div style="color:${C.textDim};font-size:12.5px;margin-top:4px;">Live Taboola API campaigns</div>
                      </div>
                      <div style="display:flex;align-items:center;gap:10px;">
                        <div style="display:flex;align-items:center;background:var(--pq-card);border:1px solid var(--pq-border);border-radius:8px;overflow:hidden;">
                          <input id="campaign-name-input" type="text" placeholder="Enter Campaign Name…" style="background:transparent;border:none;color:var(--pq-text);padding:9px 14px;outline:none;width:380px;"/>
                          <button onclick="handleAddCampaignName()" style="background:#3B82F6;color:#fff;border:none;padding:9px 16px;cursor:pointer;font-weight:600;font-family:'Sora';">＋ ADD</button>
                        </div>
                        <div id="export-dropdown-wrap" style="position:relative; display:inline-block; z-index:1000;">
                    <button id="export-dropdown-btn" onclick="toggleExportDropdown(event)" style="background:${C.accent}; color:#fff; border:none; padding:10px 16px; border-radius:8px; cursor:pointer; font-size:12px; font-weight:600; display:flex; align-items:center; gap:6px; font-family:'Sora'; white-space:nowrap;"> 📥 Export <span style="font-size:9px; margin-left:2px;">⮟</span> </button>
                    <div class="export-dropdown-menu-list" id="export-dropdown-menu-taboola" style="display:none; position:absolute; top:calc(100% + 6px); right:0; background:var(--pq-card); border:1px solid #2d3148; border-radius:8px; min-width:210px; box-shadow:0 10px 28px rgba(0,0,0,0.45); z-index:1000; overflow:hidden;">
                      <button onclick="closeExportDropdown(); exportCampaignsToExcel('campaign')" style="width:100%; text-align:left; background:none; border:none; color:var(--pq-text); padding:11px 14px; font-size:12px; font-family:'Sora'; cursor:pointer; display:flex; align-items:center; gap:8px;" onmouseover="this.style.background='var(--pq-border)'" onmouseout="this.style.background='none'"> 📥 Export Campaign Report </button>
                      <button onclick="closeExportDropdown(); exportPortfolioPDF()" style="width:100%; text-align:left; background:none; border:none; color:var(--pq-text); padding:11px 14px; font-size:12px; font-family:'Sora'; cursor:pointer; display:flex; align-items:center; gap:8px; border-top:1px solid #2d3148;" onmouseover="this.style.background='var(--pq-border)'" onmouseout="this.style.background='none'"> 🧾 Export PDF (Meta + Google) </button>
                      <button onclick="closeExportDropdown(); exportPivotReport()" style="width:100%; text-align:left; background:none; border:none; color:var(--pq-text); padding:11px 14px; font-size:12px; font-family:'Sora'; cursor:pointer; display:flex; align-items:center; gap:8px; border-top:1px solid #2d3148;" onmouseover="this.style.background='var(--pq-border)'" onmouseout="this.style.background='none'"> 📊 Export Analysis Report </button>
                    </div>
                  </div>
                        <button onclick="openUnmapped()" style="background:#1a1d27;color:#fff;border:1px solid #2d3148;padding:8px 16px;border-radius:8px;cursor:pointer;font-size:13px;font-weight:600;display:flex;align-items:center;gap:8px;">
                          Unmapped Leads <span id="unmappedBadge" style="background:#e53e3e;color:#fff;border-radius:10px;padding:2px 8px;font-size:11px;">${window.unmappedLeadsCount}</span>
                        </button>
                      </div>
                    </div>
                      <div style="display:flex;align-items:center;gap:10px;">
                        <div style="display:flex;align-items:center;background:var(--pq-card);border:1px solid var(--pq-border);border-radius:8px;overflow:hidden;">
                          <input id="campaign-name-input" type="text" placeholder="Enter Campaign Name…" style="background:transparent;border:none;color:var(--pq-text);padding:9px 14px;outline:none;width:380px;"/>
                          <button onclick="handleAddCampaignName()" style="background:#3B82F6;color:#fff;border:none;padding:9px 16px;cursor:pointer;font-weight:600;font-family:'Sora';">＋ ADD</button>
                        </div>
                        <div id="export-dropdown-wrap" style="position:relative; display:inline-block; z-index:1000;">
                    <button id="export-dropdown-btn" onclick="toggleExportDropdown(event)" style="background:${C.accent}; color:#fff; border:none; padding:10px 16px; border-radius:8px; cursor:pointer; font-size:12px; font-weight:600; display:flex; align-items:center; gap:6px; font-family:'Sora'; white-space:nowrap;"> 📥 Export <span style="font-size:9px; margin-left:2px;">⮟</span> </button>
                    <div class="export-dropdown-menu-list" id="export-dropdown-menu-taboola" style="display:none; position:absolute; top:calc(100% + 6px); right:0; background:var(--pq-card); border:1px solid #2d3148; border-radius:8px; min-width:210px; box-shadow:0 10px 28px rgba(0,0,0,0.45); z-index:1000; overflow:hidden;">
                      <button onclick="closeExportDropdown(); exportCampaignsToExcel('campaign')" style="width:100%; text-align:left; background:none; border:none; color:var(--pq-text); padding:11px 14px; font-size:12px; font-family:'Sora'; cursor:pointer; display:flex; align-items:center; gap:8px;" onmouseover="this.style.background='var(--pq-border)'" onmouseout="this.style.background='none'"> 📥 Export Campaign Report </button>
                      <button onclick="closeExportDropdown(); exportPortfolioPDF()" style="width:100%; text-align:left; background:none; border:none; color:var(--pq-text); padding:11px 14px; font-size:12px; font-family:'Sora'; cursor:pointer; display:flex; align-items:center; gap:8px; border-top:1px solid #2d3148;" onmouseover="this.style.background='var(--pq-border)'" onmouseout="this.style.background='none'"> 🧾 Export PDF (Meta + Google) </button>
                      <button onclick="closeExportDropdown(); exportPivotReport()" style="width:100%; text-align:left; background:none; border:none; color:var(--pq-text); padding:11px 14px; font-size:12px; font-family:'Sora'; cursor:pointer; display:flex; align-items:center; gap:8px; border-top:1px solid #2d3148;" onmouseover="this.style.background='var(--pq-border)'" onmouseout="this.style.background='none'"> 📊 Export Analysis Report </button>
                    </div>
                  </div>
                        <button onclick="openUnmapped()" style="background:#1a1d27;color:#fff;border:1px solid #2d3148;padding:8px 16px;border-radius:8px;cursor:pointer;font-size:13px;font-weight:600;display:flex;align-items:center;gap:8px;">
                          Unmapped Leads <span id="unmappedBadge" style="background:#e53e3e;color:#fff;border-radius:10px;padding:2px 8px;font-size:11px;">${window.unmappedLeadsCount}</span>
                        </button>
                      </div>
                    </div>

                    <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px;">
                      <div style="display:flex;align-items:center;gap:8px;">
                        <span style="color:${C.textDim};font-size:11px;">Show</span>
                        <select onchange="dtSetPageSize(+this.value)" style="background:var(--pq-card);color:var(--pq-text);border:1px solid var(--pq-border);border-radius:6px;padding:5px 8px;font-size:11px;outline:none;cursor:pointer;">
                          <option value="5" selected>5</option>
                          <option value="10">10</option>
                          <option value="25">25</option>
                          <option value="50">50</option>
                          <option value="-1">All</option>
                        </select>
                        <span style="color:${C.textDim};font-size:11px;">entries</span>
                      </div>
                    </div>

                    <div style="background:${C.card};border:1px solid ${C.border};border-radius:12px;overflow:auto;">
                      <table id="camps-table">
                        <thead><tr>
                          <th data-col="status" onclick="dtSort('status')">Status<span class="sort-icon"></span></th>
                          <th data-col="campaign" onclick="dtSort('campaign')">Campaign<span class="sort-icon"></span></th>
                          <th>Channel</th>
                          <th data-col="spend" onclick="dtSort('spend')">Spend<span class="sort-icon"></span></th>
                          <th data-col="impressions" onclick="dtSort('impressions')">Impressions<span class="sort-icon"></span></th>
                          <th data-col="clicks" onclick="dtSort('clicks')">Clicks<span class="sort-icon"></span></th>
                          <th data-col="ctr" onclick="dtSort('ctr')">CTR<span class="sort-icon"></span></th>
                          <th data-col="cpm" onclick="dtSort('cpm')">CPM<span class="sort-icon"></span></th>
                          <th data-col="leads" onclick="dtSort('leads')">Leads<span class="sort-icon"></span></th>
                          <th data-col="cpl" onclick="dtSort('cpl')">CPL<span class="sort-icon"></span></th>
                          <th data-col="qualified" onclick="dtSort('qualified')" style="color:${C.blue};">Qualified Leads<span class="sort-icon"></span></th>
                          <th data-col="cpql" onclick="dtSort('cpql')" style="color:${C.blue};">CPQL<span class="sort-icon"></span></th>
                          <th data-col="walkins" onclick="dtSort('walkins')" style="color:${C.green};">Site Visits<span class="sort-icon"></span></th>
                          <th data-col="cpsv" onclick="dtSort('cpsv')" style="color:${C.green};">CPSV<span class="sort-icon"></span></th>
                        </tr></thead>
                        <tbody id="dt-body"></tbody>
                        <tfoot id="dt-foot"></tfoot>
                      </table>
                    </div>

                    <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px;margin:14px 0;">
                      <span id="dt-info" style="color:${C.textDim};font-size:11px;"></span>
                      <div id="dt-pagination" style="display:flex;align-items:center;gap:4px;flex-wrap:wrap;"></div>
                    </div>

                    <div style="background:${C.card};border:1px solid ${C.border};border-radius:12px;padding:20px;">
                      <div style="color:${C.text};font-weight:600;font-size:14px;margin-bottom:16px;">Cost Per Lead (CPL) Comparison</div>
                      <div id="cpl-comparison-chart"></div>
                    </div>
                  </div>
                `;

                state.dtSearch = '';
                state.dtPage = 1;
                renderCampaignsTable();

                if (state.filteredCampaigns.length > 0) {
                    setTimeout(() => {
                        renderChart("cpl-comparison-chart", "bar", {
                            chart: { type: 'bar', height: 240, background: 'transparent', foreColor: C.textDim, fontFamily: 'Sora, sans-serif', toolbar: { show: false } },
                            series: [{ name: 'CPL (₹)', data: state.filteredCampaigns.map(c => c.cpl) }],
                            xaxis: { categories: state.filteredCampaigns.map(c => c.campaign), labels: { rotate: -45, trim: true, style: { fontSize: '9px' } } },
                            colors: state.filteredCampaigns.map(c => c.status === "good" ? C.green : C.yellow),
                            plotOptions: { bar: { distributed: true, borderRadius: 4, columnWidth: '50%' } },
                            legend: { show: false },
                            grid: { borderColor: C.border }
                        });
                    }, 50);
                }
            }

            window.exportCampaignsToExcel = (type = 'campaign') => {
                if (!state.filteredCampaigns.length) {
                    alert('No campaign data to export.');
                    return;
                }

                const rows = state.filteredCampaigns.map(c => ({
                    'Campaign': c.campaign,
                    'Channel': c.platform,
                    'Spend (₹)': c.spend,
                    'Impressions': c.impressions,
                    'Clicks': c.clicks,
                    'CTR (%)': c.ctr,
                    'CPM (₹)': c.cpm,
                    'Leads': c.leads,
                    'CPL (₹)': c.cpl,
                    'Qualified Leads': c.qualified,
                    'CPQL (₹)': c.cpql,
                    'Site Visits': c.walkins,
                    'CPSV (₹)': c.cpsv,
                }));

                const tSpend = state.filteredCampaigns.reduce((a, c) => a + c.spend, 0);
                const tLeads = state.filteredCampaigns.reduce((a, c) => a + c.leads, 0);
                const tQual = state.filteredCampaigns.reduce((a, c) => a + c.qualified, 0);
                const tWalkins = state.filteredCampaigns.reduce((a, c) => a + c.walkins, 0);

                rows.push({
                    'Campaign': 'TOTAL',
                    'Channel': '',
                    'Spend (₹)': tSpend,
                    'Impressions': state.filteredCampaigns.reduce((a, c) => a + c.impressions, 0),
                    'Clicks': state.filteredCampaigns.reduce((a, c) => a + c.clicks, 0),
                    'CTR (%)': '',
                    'CPM (₹)': '',
                    'Leads': tLeads,
                    'CPL (₹)': tLeads > 0 ? +(tSpend / tLeads).toFixed(2) : 0,
                    'Qualified Leads': tQual,
                    'CPQL (₹)': tQual > 0 ? +(tSpend / tQual).toFixed(2) : 0,
                    'Site Visits': tWalkins,
                    'CPSV (₹)': tWalkins > 0 ? +(tSpend / tWalkins).toFixed(2) : 0,
                });

                const ws = XLSX.utils.json_to_sheet(rows);
                const wb = XLSX.utils.book_new();
                XLSX.utils.book_append_sheet(wb, ws, 'Campaigns');
                const filePrefix = type === 'analysis' ? 'PerfomIQ_Taboola_Analysis_Report_' : 'PerfomIQ_Taboola_Campaign_Report_';
                XLSX.writeFile(wb, `${filePrefix}${state.dateRange.replace(/\s/g, '_')}.xlsx`);
            };

            window.exportPivotReport = () => {
                window.exportCampaignsToExcel('analysis');
            };

            // 3. TREND TAB
            if (state.activeTab === "trend") {
                container.innerHTML = `
                  <div class="animate-in" style="display:flex;flex-direction:column;gap:20px;">
                    <div style="background:${C.card};border:1px solid ${C.border};border-radius:12px;padding:20px;">
                      <div style="color:${C.text};font-weight:600;font-size:14px;margin-bottom:16px;">Daily Spend</div>
                      <div id="trend-spend-chart"></div>
                    </div>
                    <div style="background:${C.card};border:1px solid ${C.border};border-radius:12px;padding:20px;">
                      <div style="color:${C.text};font-weight:600;font-size:14px;margin-bottom:16px;">Daily Clicks</div>
                      <div id="trend-clicks-chart"></div>
                    </div>
                  </div>
                `;

                if (state.trends.length > 0) {
                    const cats = state.trends.map(r => r.date.split(' ')[0]);
                    setTimeout(() => {
                        renderChart('trend-spend-chart', 'line', {
                            chart: { type: 'area', height: 220, background: 'transparent', foreColor: C.textDim, fontFamily: 'Sora,sans-serif', toolbar: { show: false } },
                            series: [{ name: 'Spend (₹)', data: state.trends.map(r => +r.spend.toFixed(0)) }],
                            xaxis: { categories: cats, labels: { style: { fontSize: '10px' }, rotate: -45 } },
                            yaxis: { labels: { formatter: v => fmt(v), style: { fontSize: '10px' } } },
                            colors: [C.accent], stroke: { curve: 'smooth', width: 2 },
                            fill: { type: 'gradient', gradient: { shadeIntensity: 1, opacityFrom: 0.25, opacityTo: 0, stops: [0, 100] } },
                            tooltip: { theme: C.mode }, grid: { borderColor: C.border }, theme: { mode: 'dark' }
                        });
                        renderChart('trend-clicks-chart', 'line', {
                            chart: { type: 'area', height: 220, background: 'transparent', foreColor: C.textDim, fontFamily: 'Sora,sans-serif', toolbar: { show: false } },
                            series: [{ name: 'Clicks', data: state.trends.map(r => r.clicks) }],
                            xaxis: { categories: cats, labels: { style: { fontSize: '10px' }, rotate: -45 } },
                            yaxis: { labels: { formatter: v => fmtN(v), style: { fontSize: '10px' } } },
                            colors: [C.blue], stroke: { curve: 'smooth', width: 2 },
                            fill: { type: 'gradient', gradient: { shadeIntensity: 1, opacityFrom: 0.25, opacityTo: 0, stops: [0, 100] } },
                            tooltip: { theme: C.mode }, grid: { borderColor: C.border }, theme: { mode: 'dark' }
                        });
                    }, 50);
                } else {
                    document.getElementById('trend-spend-chart').innerHTML = `<div style="color:${C.textDim};padding:40px;text-align:center;">No trend data available for this period.</div>`;
                }
            }

            // 4. FUNNEL TAB
            if (state.activeTab === "funnel") {
                const funnelStagesHTML = state.funnel.map((s, i) => {
                    const w = Math.max(20, 100 - i * 12);
                    return `<div style="margin-bottom:10px;"><div style="display:flex; justify-content:space-between; margin-bottom:4px;"><span style="color:${C.textDim}; font-size:11px;">${s.stage}</span><span style="color:${C.text}; font-size:11px; font-family:'JetBrains Mono';">${fmtN(s.value)} ${i > 0 ? `(${pct(s.pct)} Conversion)` : ``}</span></div><div style="height:32px; background:${C.bg}; border-radius:6px; overflow:hidden;"><div style="height:100%; width:${w}%; background:linear-gradient(90deg, ${C.accent}cc, ${C.accent}66); border-radius:6px; display:flex; align-items:center; padding-left:10px;"><span style="color:#ffffff; font-size:11px; font-weight:600;">${fmtN(s.value)}</span></div></div></div>`;
                }).join('');

                container.innerHTML = `
          <div style="display: flex; flex-direction: column; gap: 24px;" class="animate-in">
            <div style="margin-bottom: 20px;">
              <div style="color:${C.text}; font-size:18px; font-weight:700;">Portfolio Conversion Funnel</div>
            </div>
            <div style="display:grid; grid-template-columns: 1fr 1fr; gap:20px;">
              <div style="background:${C.card}; border:1px solid ${C.border}; border-radius:12px; padding:20px;">
                <div style="color:${C.text}; font-weight:600; font-size:14px; margin-bottom:20px;">Funnel Stages</div>
                ${funnelStagesHTML}
              </div>
              <div style="display:flex; flex-direction:column; gap:14px;">
                ${renderInsightCardHTML("🔻", "CRM Data Note", [
                    "Qualified Leads and Walk-ins are isolated from the Taboola backstage fetch and matched based on CRM database records.",
                    "Phase 2 integration will automate direct synchronization of CRM parameters."
                ], C.blue)}
              </div>
            </div>
          </div>
        `;
            }

            // 5. AI INSIGHTS TAB
            if (state.activeTab === "insights") {
                const aiBtnHTML = `
            <button class="btn" onclick="handleGenerateInsights(event)" style="display:flex; align-items:center; gap:6px; font-size:12px;">
              🔄 <span id="insights-refresh-text">Regenerate Insights</span>
            </button>`;

                const summaryHeaderHTML = `
            <div style="margin-bottom:20px; display:flex; justify-content:space-between; align-items:center;">
              <div>
                <div style="color:${C.text}; font-size:18px; font-weight:700; letter-spacing:-0.02em;">AI-Generated Taboola Native Ads Insights</div>
                <div style="color:${C.textDim}; font-size:12.5px; margin-top:4px;">AI-powered audit generated from your actual Taboola campaign performance data</div>
              </div>
              ${aiBtnHTML}
            </div>`;

                if (!state.insights && !state.loadingInsights) {
                    container.innerHTML = `
            <div style="display:flex; flex-direction:column; gap:24px;" class="animate-in">
              ${summaryHeaderHTML}
              <div style="background:${C.card}; border:2px dashed ${C.border}; border-radius:16px; padding:48px 32px; text-align:center;">
                <div style="font-size:40px; margin-bottom:16px;">🤖</div>
                <div style="color:${C.text}; font-size:16px; font-weight:600; margin-bottom:8px;">Generate AI-Powered Taboola Insights</div>
                <div style="color:${C.textDim}; font-size:13px; margin-bottom:24px; max-width:440px; margin:0 auto 24px;">
                  Click below to have PerformIQ analyze your Taboola Native Ads campaigns — CTR benchmarks, publisher performance, creative fatigue, and CPL optimization.
                </div>
                <button class="btn" onclick="handleGenerateInsights(event)">🤖 Analyze Taboola Campaign Data</button>
              </div>
            </div>`;

                } else if (state.loadingInsights) {
                    container.innerHTML = `
            <div style="display:flex; flex-direction:column; gap:24px;" class="animate-in">
              ${summaryHeaderHTML}
              <div style="background:${C.card}; border:1px solid ${C.border}; border-radius:16px; padding:48px 32px; text-align:center;">
                <div class="pulse" style="font-size:40px; margin-bottom:16px;">🤖</div>
                <div style="color:${C.accent}; font-size:15px; font-weight:600;">Analyzing Taboola Native Ads Portfolio…</div>
                <div style="color:${C.textDim}; font-size:12px; margin-top:8px;">Evaluating CTR benchmarks, publisher performance, creative health, and CPL efficiency.</div>
              </div>
            </div>`;

                } else if (state.insights) {
                    const isAI = state.insights._source === 'ai' && state.insights.overall_account;

                    if (isAI) {
                        const oa    = state.insights.overall_account || {};
                        const camps = Array.isArray(state.insights.campaigns) ? state.insights.campaigns : [];

                        const healthColor   = (score) => score >= 75 ? C.green : score >= 50 ? C.yellow : C.red;
                        const priorityColor = (p) => (p || '').toLowerCase() === 'high' ? C.red : (p || '').toLowerCase() === 'medium' ? C.yellow : C.green;
                        const renderList    = (items, color) => (Array.isArray(items) && items.length)
                            ? `<ul style="margin:6px 0 0; padding-left:18px; color:${C.textDim}; font-size:12.5px; line-height:1.7;">${items.map(i => `<li style="margin-bottom:2px;">${i}</li>`).join('')}</ul>`
                            : `<div style="color:${C.textDim}; font-size:12px; font-style:italic;">None noted</div>`;

                        container.innerHTML = `
            <div style="display:flex; flex-direction:column; gap:24px;" class="animate-in">
              ${summaryHeaderHTML}

              <div style="background:linear-gradient(135deg, ${C.accentLo}, ${C.blueLo}); border:1px solid ${C.accent}44; border-radius:14px; padding:24px;">
                <div style="display:flex; align-items:center; justify-content:space-between; gap:16px; flex-wrap:wrap;">
                  <div>
                    <div style="color:${C.accent}; font-size:11px; font-weight:600; text-transform:uppercase; letter-spacing:0.08em; margin-bottom:8px;">★ Overall Taboola Account Health</div>
                    <p style="color:${C.text}; font-size:14px; line-height:1.7; margin:0; max-width:640px;">${oa.summary || ''}</p>
                    ${oa.top_5_actions && oa.top_5_actions.length ? `
                    <div style="margin-top:14px;">
                      <div style="color:${C.accent}; font-size:11px; font-weight:700; text-transform:uppercase; margin-bottom:6px;">Top Actions</div>
                      ${renderList(oa.top_5_actions, C.accent)}
                    </div>` : ''}
                  </div>
                  <div style="text-align:center; flex-shrink:0;">
                    <div style="font-size:32px; font-weight:800; color:${healthColor(oa.health_score || 0)}; font-family:'Sora';">${oa.health_score ?? '—'}</div>
                    <div style="font-size:11px; font-weight:700; color:${healthColor(oa.health_score || 0)}; text-transform:uppercase; letter-spacing:0.05em; margin-top:2px;">${oa.status || ''}</div>
                  </div>
                </div>
                ${(oa.best_campaign || oa.worst_campaign || oa.scale_recommendation) ? `
                <div style="display:grid; grid-template-columns:repeat(auto-fill,minmax(200px,1fr)); gap:12px; margin-top:16px; padding-top:16px; border-top:1px solid ${C.border}44;">
                  ${oa.best_campaign  ? `<div style="background:${C.greenLo}; border:1px solid ${C.green}44; border-radius:8px; padding:10px 14px;"><div style="color:${C.green}; font-size:10px; font-weight:700; text-transform:uppercase; margin-bottom:4px;">🏆 Best Campaign</div><div style="color:${C.text}; font-size:12px;">${oa.best_campaign}</div></div>` : ''}
                  ${oa.worst_campaign ? `<div style="background:${C.redLo}; border:1px solid ${C.red}44; border-radius:8px; padding:10px 14px;"><div style="color:${C.red}; font-size:10px; font-weight:700; text-transform:uppercase; margin-bottom:4px;">⚠️ Needs Review</div><div style="color:${C.text}; font-size:12px;">${oa.worst_campaign}</div></div>` : ''}
                  ${oa.scale_recommendation ? `<div style="background:${C.accentLo}; border:1px solid ${C.accent}44; border-radius:8px; padding:10px 14px;"><div style="color:${C.accent}; font-size:10px; font-weight:700; text-transform:uppercase; margin-bottom:4px;">🚀 Scale This</div><div style="color:${C.text}; font-size:12px;">${oa.scale_recommendation}</div></div>` : ''}
                  ${oa.budget_wastage ? `<div style="background:#F59E0B18; border:1px solid #F59E0B44; border-radius:8px; padding:10px 14px;"><div style="color:#F59E0B; font-size:10px; font-weight:700; text-transform:uppercase; margin-bottom:4px;">💸 Budget Wastage</div><div style="color:${C.text}; font-size:12px;">${oa.budget_wastage}</div></div>` : ''}
                </div>` : ''}
              </div>

              <div style="display:flex; flex-direction:column; gap:16px;">
                ${camps.map(c => `
                  <div style="background:${C.card}; border:1px solid ${C.border}; border-radius:14px; padding:20px 24px;">
                    <div style="display:flex; align-items:center; justify-content:space-between; gap:12px; flex-wrap:wrap; margin-bottom:12px;">
                      <div style="display:flex; align-items:center; gap:10px;">
                        <span style="color:${C.text}; font-size:15px; font-weight:700;">${c.campaign_name || 'Unnamed Campaign'}</span>
                        <span style="background:${priorityColor(c.priority)}22; color:${priorityColor(c.priority)}; border:1px solid ${priorityColor(c.priority)}55; font-size:10px; font-weight:700; padding:2px 8px; border-radius:99px; text-transform:uppercase;">${c.priority || ''} priority</span>
                      </div>
                      <div style="display:flex; align-items:center; gap:8px;">
                        <span style="font-size:18px; font-weight:800; color:${healthColor(c.health_score || 0)}; font-family:'Sora';">${c.health_score ?? '—'}</span>
                        <span style="font-size:11px; font-weight:600; color:${healthColor(c.health_score || 0)};">${c.status || ''}</span>
                      </div>
                    </div>

                    ${c.executive_summary ? `<p style="color:${C.text}; font-size:13px; line-height:1.6; margin:0 0 14px;">${c.executive_summary}</p>` : ''}

                    <div style="display:grid; grid-template-columns:repeat(auto-fill,minmax(220px,1fr)); gap:16px;">
                      <div><div style="color:${C.green}; font-size:11px; font-weight:700; text-transform:uppercase; margin-bottom:4px;">🏆 Strengths</div>${renderList(c.strengths, C.green)}</div>
                      <div><div style="color:${C.red}; font-size:11px; font-weight:700; text-transform:uppercase; margin-bottom:4px;">⚠️ Weaknesses</div>${renderList(c.weaknesses, C.red)}</div>
                      <div><div style="color:${C.yellow}; font-size:11px; font-weight:700; text-transform:uppercase; margin-bottom:4px;">🔍 Root Cause</div>${renderList(c.root_cause, C.yellow)}</div>
                      <div><div style="color:${C.blue}; font-size:11px; font-weight:700; text-transform:uppercase; margin-bottom:4px;">🖼️ Creative / Thumbnail</div>${renderList(c.creative_recommendations, C.blue)}</div>
                      <div><div style="color:${C.accent}; font-size:11px; font-weight:700; text-transform:uppercase; margin-bottom:4px;">🌐 Publisher / Audience</div>${renderList(c.audience_recommendations, C.accent)}</div>
                      <div><div style="color:${C.blue}; font-size:11px; font-weight:700; text-transform:uppercase; margin-bottom:4px;">🖥️ Landing Page</div>${renderList(c.landing_page_recommendations, C.blue)}</div>
                    </div>

                    ${(c.ctr_analysis || c.cpl_analysis) ? `
                    <div style="display:grid; grid-template-columns:repeat(auto-fill,minmax(200px,1fr)); gap:10px; margin-top:14px;">
                      ${c.ctr_analysis ? `
                      <div style="padding:10px 14px; background:${C.bg}; border:1px solid ${C.border}; border-radius:8px;">
                        <div style="color:${C.accent}; font-size:10px; font-weight:700; text-transform:uppercase; margin-bottom:4px;">📊 CTR Analysis</div>
                        <div style="color:${C.text}; font-size:12px; margin-bottom:4px;">CTR: <strong>${c.ctr_analysis.current_ctr || '—'}</strong> <span style="color:${C.textDim}; font-size:10px;">(Benchmark: ${c.ctr_analysis.benchmark || '0.3%–1.0%'})</span></div>
                        <div style="color:${C.textDim}; font-size:11.5px;">${c.ctr_analysis.recommendation || ''}</div>
                      </div>` : ''}
                      ${c.cpl_analysis ? `
                      <div style="padding:10px 14px; background:${C.bg}; border:1px solid ${C.border}; border-radius:8px;">
                        <div style="color:${C.yellow}; font-size:10px; font-weight:700; text-transform:uppercase; margin-bottom:4px;">💰 CPL Analysis</div>
                        <div style="color:${C.text}; font-size:12px; margin-bottom:4px;">CPL: <strong>${c.cpl_analysis.current_cpl || '—'}</strong></div>
                        <div style="color:${C.textDim}; font-size:11.5px;">${c.cpl_analysis.recommendation || ''}</div>
                      </div>` : ''}
                    </div>` : ''}

                    ${c.budget_action ? `
                    <div style="margin-top:14px; padding:10px 14px; background:${C.bg}; border:1px solid ${C.border}; border-radius:8px;">
                      <span style="color:${C.accent}; font-size:11px; font-weight:700; text-transform:uppercase; margin-right:8px;">💸 Budget Action</span>
                      <span style="color:${C.text}; font-size:12.5px;">${c.budget_action}</span>
                    </div>` : ''}
                  </div>
                `).join('')}
              </div>
            </div>`;

                    } else {
                        // Local fallback display
                        container.innerHTML = `
            <div style="display:flex; flex-direction:column; gap:24px;" class="animate-in">
              ${summaryHeaderHTML}
              ${state.insights.executiveSummary ? `
                <div style="background:linear-gradient(135deg, ${C.accentLo}, ${C.blueLo}); border:1px solid ${C.accent}44; border-radius:14px; padding:20px 24px;">
                  <div style="color:${C.accent}; font-size:11px; font-weight:600; text-transform:uppercase; letter-spacing:0.08em; margin-bottom:8px;">★ Executive Summary</div>
                  <p style="color:${C.text}; font-size:14px; line-height:1.7; margin:0;">${state.insights.executiveSummary}</p>
                </div>` : ''}
              <div style="display:grid; grid-template-columns:repeat(auto-fill,minmax(300px,1fr)); gap:16px;">
                ${renderInsightCardHTML("🏆", "Key Wins", state.insights.keyWins, C.green)}
                ${renderInsightCardHTML("🚨", "Major Concerns", state.insights.majorConcerns, C.red)}
                ${renderInsightCardHTML("⚡", "Optimization Opportunities", state.insights.optimizationOpportunities, C.accent)}
                ${renderInsightCardHTML("✅", "Actionable Next Steps", state.insights.actionableNextSteps, C.blue)}
              </div>
            </div>`;
                    }
                }
            }
        }

        // ── AJAX API Endpoint Fetcher ──
        window.fetchDashboardData = async () => {
            state.isLoading = true;
            state.ajaxError = null;
            showLoader();

            try {
                const fmt = (date) => `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;

                let since, until;
                if (state.tempPreset === 'custom' && state.tempStartDate && state.tempEndDate) {
                    since = fmt(state.tempStartDate);
                    until = fmt(state.tempEndDate);
                } else {
                    const dates = getPresetDates(state.tempPreset || 'last_30d');
                    since = dates.since;
                    until = dates.until;
                }

                const res = await fetch('taboolaapi.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ since, until, campaignsstatus: state.filterStatus })
                });

                if (!res.ok) throw new Error(`HTTP Error: ${res.status}`);

                const data = await res.json();
                state.rawData = data;

                const mapped = mapPhpDataToDashboard(data);
                state.campaigns  = mapped.campaigns;
                state.trends     = mapped.trends;
                state.dateRange  = mapped.dateRange;
                state.funnel     = mapped.funnel;
                // Store CRM totals for KPI cards and lead modals
                state.totalQualifiedCrm = mapped.totalQualifiedCrm || 0;
                state.totalWalkinsCrm   = mapped.totalWalkinsCrm   || 0;
                state.allQualLeads      = mapped.allQualLeads       || [];
                state.allWalkLeads      = mapped.allWalkLeads       || [];

                const refreshedEl = document.getElementById('header-refreshed-at');
                if (refreshedEl) refreshedEl.innerText = data.fetched_at || '—';

                state.isLoading = false;
                hideLoader();
                updateFilteredStateAndRender();

            } catch (err) {
                console.error('AJAX fetch error:', err);
                state.ajaxError = err.message;
                state.isLoading = false;
                hideLoader();
                renderDashboard();

                const banner = document.getElementById('error-banner');
                const msg = document.getElementById('error-message');
                if (banner && msg) {
                    msg.innerText = err.message;
                    banner.style.display = 'block';
                }
            }
        };

        // ===m== Upload Offline Data (mirrors googledashboard.php UploadManager; matches by mobile or gclid, no leadgen_id) ===m==
        const UploadManager = {
            parsedData: [],
            extractedPayload: [],
            headers: [],
            CHUNK_SIZE: 500,
            stats: { success: 0, duplicate: 0, failed: 0 },

            // Pagination & Meta state
            pageSize: 10,
            previewPage: 1,
            finalPage: 1,
            lastLeadDate: null,

            openModal() {
                this.resetState();
                document.getElementById('uploadModalOverlay').style.display = 'flex';
                this.initDragAndDrop();
            },

            closeModal() {
                document.getElementById('uploadModalOverlay').style.display = 'none';
                if (this.stats.success > 0 || this.stats.duplicate > 0) fetchDashboardData();
            },

            resetState() {
                this.parsedData = [];
                this.extractedPayload = [];
                this.headers = [];
                this.stats = { success: 0, duplicate: 0, failed: 0 };
                this.previewPage = 1;
                this.finalPage = 1;
                this.lastLeadDate = null;

                document.getElementById('uploadDropZone').style.display = 'block';
                document.getElementById('uploadPreviewArea').style.display = 'none';
                document.getElementById('uploadProgressArea').style.display = 'none';
                document.getElementById('uploadSummaryArea').style.display = 'none';
                document.getElementById('hiddenFileInput').value = '';
            },

            initDragAndDrop() {
                const dropZone = document.getElementById('uploadDropZone');
                const prevent = (e) => { e.preventDefault(); e.stopPropagation(); };
                ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
                    dropZone.addEventListener(eventName, prevent, false);
                });

                dropZone.addEventListener('dragover', () => dropZone.style.borderColor = C.blue);
                dropZone.addEventListener('dragleave', () => dropZone.style.borderColor = 'var(--pq-border)');
                dropZone.addEventListener('drop', (e) => {
                    dropZone.style.borderColor = 'var(--pq-border)';
                    const file = e.dataTransfer.files[0];
                    if (file) this.processFile(file);
                });
            },

            handleFileSelect(e) {
                const file = e.target.files[0];
                if (file) this.processFile(file);
            },

            processFile(file) {
                document.getElementById('uploadDropZone').style.display = 'none';
                const ext = file.name.split(".").pop().toLowerCase();

                if (ext === "csv") {
                    Papa.parse(file, { header: true, skipEmptyLines: true, complete: (res) => this.prepareData(res.data) });
                } else {
                    const reader = new FileReader();
                    reader.onload = (ev) => {
                        const wb = XLSX.read(ev.target.result, { type: "array" });
                        const ws = wb.Sheets[wb.SheetNames[0]];
                        this.prepareData(XLSX.utils.sheet_to_json(ws, { defval: "" }));
                    };
                    reader.readAsArrayBuffer(file);
                }
            },

            prepareData(rows) {
                if (!rows.length) { alert("File is empty."); this.resetState(); return; }
                this.parsedData = rows;
                this.headers = Object.keys(rows[0]);

                const normalizeKey = k => k.toLowerCase().trim().replace(/[\s\-]+/g, '_');
                const hNorm = this.headers.map(normalizeKey);

                const kMap = {
                    mobile: this.headers[hNorm.findIndex(k => k === 'mobile')],
                    gclid: this.headers[hNorm.findIndex(k => k === 'gclid')],
                    status: this.headers[hNorm.findIndex(k => k === 'status')],
                    sub: this.headers[hNorm.findIndex(k => k === 'sub_status' || k.includes('sub_status'))],
                    sv: this.headers[hNorm.findIndex(k => k === 'sitevisit_status' || k === 'site_visit' || k === 'sitevisit')],
                    sv_sub: this.headers[hNorm.findIndex(k => k === 'sitevisit_sub_status' || k.includes('sitevisit_sub'))]
                };

                if (!kMap.mobile && !kMap.gclid) {
                    alert("Could not find a valid ID column (Mobile or gclid).");
                    this.resetState();
                    return;
                }

                this.extractedPayload = rows.map(r => ({
                    mobile: kMap.mobile ? String(r[kMap.mobile] || '').trim() : '',
                    gclid: kMap.gclid ? String(r[kMap.gclid] || '').trim() : '',
                    status: kMap.status ? String(r[kMap.status] || '').trim() : '',
                    sub_status: kMap.sub ? String(r[kMap.sub] || '').trim() : '',
                    sitevisit_status: kMap.sv ? String(r[kMap.sv] || '').trim() : '',
                    sitevisit_sub_status: kMap.sv_sub ? String(r[kMap.sv_sub] || '').trim() : ''
                })).filter(r => r.mobile || r.gclid);

                this.renderPreviewTable();
            },

            renderPreviewTable() {
                const thStyle = `padding:12px 14px; white-space:nowrap; background:var(--pq-surface); position:sticky; top:0; z-index:1; border-bottom:1px solid var(--pq-border); font-size:11px; text-transform:uppercase; color:var(--pq-text-dim);`;
                const head = `<tr>${this.headers.map(h => `<th style="${thStyle}">${h}</th>`).join('')}</tr>`;
                document.getElementById('previewTableHeader').innerHTML = head;

                document.getElementById('previewTableTitle').innerHTML = `Data Preview <span style="color:var(--pq-text-dim); font-size:12px; font-weight:400;">[${this.parsedData.length} total rows]</span>`;

                document.getElementById('uploadPreviewArea').style.display = 'flex';
                this.renderPreviewPage(1);
            },

            renderPreviewPage(page) {
                this.previewPage = page;
                const start = (page - 1) * this.pageSize;
                const slice = this.parsedData.slice(start, start + this.pageSize);

                const tdStyle = `padding:10px 14px; white-space:nowrap; border-bottom:1px solid #1E2A4244; font-size:12.5px; color:var(--pq-text);`;
                const body = slice.map(row =>
                    `<tr>${this.headers.map(h => `<td style="${tdStyle}" class="mono">${row[h] || '—'}</td>`).join('')}</tr>`
                ).join('');

                document.getElementById('previewTableBody').innerHTML = body;

                const end = Math.min(start + this.pageSize, this.parsedData.length);
                document.getElementById('previewInfo').innerText = `Showing ${this.parsedData.length === 0 ? 0 : start + 1} to ${end} of ${this.parsedData.length} entries`;

                this.renderPagination('previewPagination', this.parsedData.length, this.previewPage, 'UploadManager.renderPreviewPage');
            },

            async startBatchUpload() {
                document.getElementById('uploadPreviewArea').style.display = 'none';
                document.getElementById('uploadProgressArea').style.display = 'flex';

                const totalChunks = Math.ceil(this.extractedPayload.length / this.CHUNK_SIZE);

                for (let i = 0; i < totalChunks; i++) {
                    const chunk = this.extractedPayload.slice(i * this.CHUNK_SIZE, (i + 1) * this.CHUNK_SIZE);

                    document.getElementById('progressText').innerText = `Uploading batch ${i + 1} of ${totalChunks}...`;
                    const percent = Math.round(((i) / totalChunks) * 100);
                    document.getElementById('progressBarFill').style.width = `${percent}%`;
                    document.getElementById('progressPercentage').innerText = `${percent}%`;

                    try {
                        const res = await fetch('taboolaapi.php?action=update_leads', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({ updates: chunk })
                        });
                        if (!res.ok) throw new Error('API Error');
                        const data = await res.json();

                        this.stats.success += data.updated || 0;
                        this.stats.duplicate += data.duplicate || 0;
                        this.stats.failed += data.failed || 0;
                    } catch (e) {
                        this.stats.failed += chunk.length;
                    }
                }

                document.getElementById('progressBarFill').style.width = `100%`;
                document.getElementById('progressPercentage').innerText = `100%`;

                setTimeout(() => this.showSummary(), 400);
            },

            showSummary() {
                document.getElementById('uploadProgressArea').style.display = 'none';
                document.getElementById('uploadSummaryArea').style.display = 'flex';

                document.getElementById('statSuccess').innerText = this.stats.success;
                document.getElementById('statDuplicate').innerText = this.stats.duplicate;
                document.getElementById('statFailed').innerText = this.stats.failed;

                const thStyle = `padding:12px 14px; white-space:nowrap; background:var(--pq-surface); position:sticky; top:0; z-index:1; border-bottom:1px solid var(--pq-border); font-size:11px; text-transform:uppercase; color:var(--pq-text-dim);`;
                const head = `<tr>${this.headers.map(h => `<th style="${thStyle}">${h}</th>`).join('')}</tr>`;
                document.getElementById('finalTableHeader').innerHTML = head;

                this.renderFinalPage(1);

                // Refresh last lead date after a successful upload
                if (this.stats.success > 0) {
                    this.refreshLastLeadDate();
                }
            },

            async refreshLastLeadDate() {
                try {
                    const res  = await fetch('taboolaapi.php?action=last_lead_date');
                    const data = await res.json();
                    if (data.last_lead_date) {
                        const d = new Date(data.last_lead_date);
                        const formatted = d.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' })
                                        + ', ' + d.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', hour12: true });
                        const headerEl = document.getElementById('header-last-lead-value');
                        const modalEl  = document.getElementById('modal-last-lead-value');
                        if (headerEl) headerEl.innerText = formatted;
                        if (modalEl)  modalEl.innerText  = formatted;
                    }
                } catch (e) {
                    // silently fail — date will refresh on next page load
                }
            },

            renderFinalPage(page) {
                this.finalPage = page;
                const start = (page - 1) * this.pageSize;
                const slice = this.parsedData.slice(start, start + this.pageSize);

                const tdStyle = `padding:10px 14px; white-space:nowrap; border-bottom:1px solid #1E2A4244; font-size:12.5px; color:var(--pq-text);`;
                const body = slice.map(row =>
                    `<tr>${this.headers.map(h => `<td style="${tdStyle}" class="mono">${row[h] || '—'}</td>`).join('')}</tr>`
                ).join('');

                document.getElementById('finalTableBody').innerHTML = body;

                const end = Math.min(start + this.pageSize, this.parsedData.length);
                document.getElementById('finalInfo').innerText = `Showing ${this.parsedData.length === 0 ? 0 : start + 1} to ${end} of ${this.parsedData.length} entries`;

                this.renderPagination('finalPagination', this.parsedData.length, this.finalPage, 'UploadManager.renderFinalPage');
            },

            renderPagination(containerId, totalItems, currentPage, functionName) {
                const totalPages = Math.ceil(totalItems / this.pageSize);
                const container = document.getElementById(containerId);

                if (totalPages <= 1) {
                    container.innerHTML = '';
                    return;
                }

                const btnS = `background:var(--pq-card); color:var(--pq-text-dim); border:1px solid var(--pq-border); border-radius:6px; padding:4px 10px; font-size:11px; cursor:pointer; font-family:'Sora',sans-serif;`;
                const btnA = `background:#E8A820; color:var(--pq-bg); border:1px solid #E8A820; border-radius:6px; padding:4px 10px; font-size:11px; font-weight:700; cursor:pointer; font-family:'Sora',sans-serif;`;

                let btns = `<button style="${btnS}" onclick="${functionName}(${currentPage - 1})" ${currentPage === 1 ? 'disabled' : ''}>‹ Prev</button>`;

                const delta = 2;
                const lo = Math.max(1, currentPage - delta);
                const hi = Math.min(totalPages, currentPage + delta);

                if (lo > 1) {
                    btns += `<button style="${btnS}" onclick="${functionName}(1)">1</button>`;
                    if (lo > 2) btns += `<span style="color:var(--pq-muted); padding:0 4px;">…</span>`;
                }

                for (let p = lo; p <= hi; p++) {
                    btns += `<button style="${p === currentPage ? btnA : btnS}" onclick="${functionName}(${p})">${p}</button>`;
                }

                if (hi < totalPages) {
                    if (hi < totalPages - 1) btns += `<span style="color:var(--pq-muted); padding:0 4px;">…</span>`;
                    btns += `<button style="${btnS}" onclick="${functionName}(${totalPages})">${totalPages}</button>`;
                }

                btns += `<button style="${btnS}" onclick="${functionName}(${currentPage + 1})" ${currentPage === totalPages ? 'disabled' : ''}>Next ›</button>`;

                container.innerHTML = btns;
            },

            exportFinalData() {
                const worksheet = XLSX.utils.json_to_sheet(this.parsedData);
                const workbook = XLSX.utils.book_new();
                XLSX.utils.book_append_sheet(workbook, worksheet, "Processed Data");
                XLSX.writeFile(workbook, `Batch_Upload_Summary_${new Date().getTime()}.xlsx`);
            }
        };

        document.addEventListener('DOMContentLoaded', () => {
            const parsed = parsedInitialDates();
            state.tempStartDate = parsed.since;
            state.tempEndDate = parsed.until;
            state.tempPreset = getQueryParam('since') ? 'custom' : (getQueryParam('preset') || 'last_30d');
            state.calendarMonth = new Date(state.tempStartDate.getFullYear(), state.tempStartDate.getMonth(), 1);
            fetchDashboardData();
        });

        window.handleAddCampaignName = () => {
            showCampaignToast('⚠️ Saving to Campaigns Master database is disabled for this Phase.', 'warn');
        };

        window.showCampaignToast = (msg, type) => {
            const colors = { success: '#10B981', error: '#EF4444', warn: '#F59E0B' };
            const toast = document.createElement('div');
            toast.style.cssText = `position:fixed; bottom:28px; right:28px; z-index:99999; background:var(--pq-surface-2); border-left:4px solid ${colors[type]}; color:#F9FAFB; padding:14px 22px; border-radius:8px; font-family:'Sora',sans-serif; box-shadow:0 10px 32px rgba(0,0,0,0.5);`;
            toast.textContent = msg;
            document.body.appendChild(toast);
            setTimeout(() => toast.remove(), 4000);
        };
    </script>

    <!-- Leads Modal Details scripts -->
    <script>
        let currentLeadsForExport = [];
        let currentLeadsTitle = "";

        window.openLeadsModalByCampaign = (encodedCampaignName, type) => {
            const campaignName = decodeURIComponent(encodedCampaignName);
            const c = state.filteredCampaigns.find(x => x.campaign === campaignName);
            if (!c) return;
            const leads = c[type] || [];
            const title = (type === 'qualified_leads' ? 'Qualified Leads' : 'Site Visits') + ' - ' + campaignName;
            showLeadsModal(leads, title);
        };

        window.openLeadsModalTotal = (type) => {
            // Use the pre-fetched all-leads arrays from state if available,
            // falling back to concatenating per-campaign arrays.
            let leads = [];
            if (type === 'qualified_leads') {
                leads = state.allQualLeads && state.allQualLeads.length
                    ? state.allQualLeads
                    : state.filteredCampaigns.flatMap(c => c.qualified_leads || []);
            } else {
                leads = state.allWalkLeads && state.allWalkLeads.length
                    ? state.allWalkLeads
                    : state.filteredCampaigns.flatMap(c => c.walkin_leads || []);
            }
            const title = (type === 'qualified_leads' ? 'Total Qualified Leads' : 'Total Site Visits');
            showLeadsModal(leads, title);
        };

        window.showLeadsModal = (leads, title) => {
            currentLeadsForExport = leads;
            currentLeadsTitle = title;
            document.getElementById('leadsModalTitle').innerText = title + ' [' + leads.length + ']';

            let html = '';
            if (leads.length === 0) {
                html = '<tr><td colspan="7" style="text-align:center; padding:20px; color:var(--pq-text-dim);">No data available</td></tr>';
            } else {
                html = leads.map(l => `
                    <tr>
                        <td class="mono" style="font-size:11px; padding:10px 14px; border-bottom:1px solid #1E2A4244;">${l.createddate ? l.createddate.split(' ')[0] : '—'}</td>
                        <td style="font-size:12px; color:var(--pq-text); padding:10px 14px; border-bottom:1px solid #1E2A4244;">${l.name || '—'}</td>
                        <td class="mono" style="font-size:11px; color:var(--pq-text-dim); padding:10px 14px; border-bottom:1px solid #1E2A4244;">${esc_pq(pqShow(l.mobile, 'mobile')) || '—'}</td>
                        <td style="font-size:11px; color:var(--pq-text-dim); padding:10px 14px; border-bottom:1px solid #1E2A4244;">${esc_pq(pqShow(l.email, 'email')) || '—'}</td>
                        <td style="padding:10px 14px; border-bottom:1px solid #1E2A4244;"><span class="badge" style="background:var(--pq-border); color:var(--pq-text-dim); padding:2px 6px; border-radius:4px; font-size:10px;">${l.lead_status || '—'}</span></td>
                        <td style="padding:10px 14px; border-bottom:1px solid #1E2A4244;"><span class="badge" style="background:var(--pq-border); color:var(--pq-text-dim); padding:2px 6px; border-radius:4px; font-size:10px;">${l.sitevisit_status || '—'}</span></td>
                        <td style="font-size:11px; color:var(--pq-text-dim); max-width:150px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; padding:10px 14px; border-bottom:1px solid #1E2A4244;" title="${l.utmC || ''}">${l.utmC || '—'}</td>
                    </tr>
                `).join('');
            }
            document.getElementById('leadsModalBody').innerHTML = html;
            document.getElementById('leadsModalOverlay').style.display = 'flex';
        };

        window.closeLeadsModal = () => {
            document.getElementById('leadsModalOverlay').style.display = 'none';
        };

        window.exportLeadsToExcel = () => {
            if (!currentLeadsForExport || currentLeadsForExport.length === 0) {
                alert("No data to export.");
                return;
            }

            const exportData = currentLeadsForExport.map(l => ({
                'Date': l.createddate || '',
                'Name': l.name || '',
                'Mobile': pqShow(l.mobile_export ?? l.mobile, 'mobile', 'export'),
                'Email': pqShow(l.email_export ?? l.email, 'email', 'export'),
                'Lead Status': l.lead_status || '',
                'Site Visit Status': l.sitevisit_status || '',
                'Campaign (UTM C)': l.utmC || ''
            }));

            const worksheet = XLSX.utils.json_to_sheet(exportData);
            const workbook = XLSX.utils.book_new();
            XLSX.utils.book_append_sheet(workbook, worksheet, "Leads Data");

            const filename = currentLeadsTitle.replace(/[^a-z0-9]/gi, '_').toLowerCase() + '_data.xlsx';
            XLSX.writeFile(workbook, filename);
        };
    
                window.toggleExportDropdown = (e) => {
            if (e) e.stopPropagation();
            const btn = e ? (e.currentTarget || e.target) : null;
            const wrap = btn ? btn.closest('#export-dropdown-wrap') : null;
            const menu = wrap ? wrap.querySelector('.export-dropdown-menu-list, [id^="export-dropdown-menu"]') : document.getElementById('export-dropdown-menu');
            if (menu) {
                const isShown = menu.style.display === 'block';
                document.querySelectorAll('.export-dropdown-menu-list, [id^="export-dropdown-menu"]').forEach(m => m.style.display = 'none');
                menu.style.display = isShown ? 'none' : 'block';
            }
        };
        window.closeExportDropdown = () => {
            document.querySelectorAll('.export-dropdown-menu-list, [id^="export-dropdown-menu"]').forEach(m => m.style.display = 'none');
        };
        document.addEventListener('click', (e) => {
            const wrap = e.target.closest('#export-dropdown-wrap');
            if (!wrap) window.closeExportDropdown();
        });

        window.exportPortfolioPDF = async () => {
            // Same report as the main dashboard's "Export PDF" — js/portfolio_pdf.js (Meta + Google, saved campaigns only)
            const btn = document.getElementById('export-dropdown-btn');
            const label = btn ? btn.innerHTML : '';
            const urlParams = new URLSearchParams(window.location.search);
            let since = urlParams.get('since') || (typeof state !== 'undefined' ? (state.sinceDateStr || '') : '');
            let until = urlParams.get('until') || (typeof state !== 'undefined' ? (state.untilDateStr || '') : '');
            if ((!since || !until) && typeof getPresetDates === 'function' && typeof state !== 'undefined') {
                const pd = getPresetDates(state.selectedPreset || state.tempPreset || 'last_30d');
                since = since || pd.since; until = until || pd.until;
            }
            try {
                if (btn) btn.disabled = true;
                const done = await PortfolioPDF.export({ since, until, api: 'portfolio_report_api.php', logo: 'images/webzaa-logo.png', detail: 'adset',
                    onStatus: t => { if (btn) btn.innerHTML = '⏳ ' + t; } });
                if (done && typeof window.showCampaignToast === 'function') window.showCampaignToast('✅ PDF report downloaded.', 'success');
            } catch (err) {
                console.error('Portfolio PDF failed:', err);
                if (typeof window.showCampaignToast === 'function') window.showCampaignToast('❌ ' + err.message, 'error'); else alert(err.message);
            } finally {
                if (btn) { btn.disabled = false; btn.innerHTML = label; }
            }
        };
</script>
    <!-- Upload Offline Data Modal -->
    <div id="uploadModalOverlay"
        style="display:none;position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(3,7,18,0.75);z-index:99999;align-items:center;justify-content:center;backdrop-filter:blur(4px);">
        <div
            style="background:var(--pq-surface); border:1px solid var(--pq-border); border-radius:12px; width:95%; max-width:1100px; max-height:90vh; display:flex; flex-direction:column; box-shadow:0 20px 40px rgba(0,0,0,0.6);">
            <div
                style="display:flex; justify-content:space-between; align-items:center; padding:20px 28px; border-bottom:1px solid var(--pq-border); background:var(--pq-bg); border-radius:12px 12px 0 0;">
                <div style="display:flex; align-items:center; gap:16px;">
                    <h3 style="margin:0; font-size:16px; color:var(--pq-text);">Upload Offline Data</h3>
                    <span style="display:flex; align-items:center; gap:6px; background:#3B82F618; border:1px solid #3B82F644; border-radius:99px; padding:4px 12px; font-size:11px; font-weight:500; color:var(--pq-text-dim); white-space:nowrap;">
                        <span style="font-size:8px; color:#3B82F6;">●</span>
                        Last Lead Uploaded:
                        <span id="modal-last-lead-value" style="color:var(--pq-text); font-weight:700; font-family:'JetBrains Mono'; font-size:11px;">
                            <?= $lastTaboolaLeadDate ? htmlspecialchars((new DateTime($lastTaboolaLeadDate))->format('d M Y, h:i A')) : '—' ?>
                        </span>
                    </span>
                </div>
                <button class="tab-btn" onclick="UploadManager.closeModal()"
                    style="color:var(--pq-text-dim); font-size:20px; line-height:1;">&times;</button>
            </div>

            <div style="padding:28px; overflow-y:auto; flex-grow:1; display:flex; flex-direction:column; gap:24px;">

                <!-- State 1: Drag & Drop Zone -->
                <div id="uploadDropZone"
                    style="border:2px dashed var(--pq-border); border-radius:12px; padding:48px 24px; text-align:center; background:var(--pq-card); transition:all 0.2s; cursor:pointer;"
                    onclick="document.getElementById('hiddenFileInput').click()">
                    <input type="file" id="hiddenFileInput" accept=".xlsx,.xls,.csv" style="display:none;"
                        onchange="UploadManager.handleFileSelect(event)">
                    <div style="font-size:32px; margin-bottom:12px;"></div>
                    <div style="color:var(--pq-text); font-size:14px; font-weight:600; margin-bottom:8px;">Click to upload or
                        drag and drop</div>
                    <div style="color:var(--pq-text-dim); font-size:12px;">CSV, XLS, or XLSX (Max 50MB)</div>
                </div>

                <!-- State 2: Preview Area -->
                <div id="uploadPreviewArea" style="display:none; flex-direction:column; gap:16px;">
                    <div
                        style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px;">
                        <span id="previewTableTitle" style="color:var(--pq-text); font-size:14px; font-weight:600;">Data
                            Preview</span>
                        <button class="btn" id="startBatchUploadBtn" onclick="UploadManager.startBatchUpload()">Start
                            Batch Upload</button>
                    </div>
                    <div
                        style="background:var(--pq-bg); border:1px solid var(--pq-border); border-radius:8px; overflow:auto; max-height:40vh;">
                        <table style="width:100%; text-align:left; border-collapse:collapse;">
                            <thead id="previewTableHeader"></thead>
                            <tbody id="previewTableBody"></tbody>
                        </table>
                    </div>
                    <!-- Preview Pagination -->
                    <div style="display:flex; align-items:center; justify-content:space-between;">
                        <span id="previewInfo" style="color:var(--pq-text-dim); font-size:11px;"></span>
                        <div id="previewPagination" style="display:flex; gap:4px;"></div>
                    </div>
                </div>

                <!-- State 3: Progress Area -->
                <div id="uploadProgressArea" style="display:none; flex-direction:column; gap:12px;">
                    <div
                        style="display:flex; justify-content:space-between; color:var(--pq-text); font-size:13px; font-weight:600;">
                        <span id="progressText">Uploading batch 1 of X...</span>
                        <span id="progressPercentage">0%</span>
                    </div>
                    <div style="width:100%; height:8px; background:var(--pq-border); border-radius:4px; overflow:hidden;">
                        <div id="progressBarFill"
                            style="height:100%; width:0%; background:#10B981; transition:width 0.3s ease;"></div>
                    </div>
                </div>

                <!-- State 4: Summary & Final Table Area -->
                <div id="uploadSummaryArea" style="display:none; flex-direction:column; gap:20px;">
                    <div style="display:grid; grid-template-columns:repeat(3, 1fr); gap:16px;">
                        <div
                            style="background:var(--pq-card); border:1px solid #10B98144; padding:16px; border-radius:8px; border-top:2px solid #10B981;">
                            <div style="color:var(--pq-text-dim); font-size:11px; text-transform:uppercase;">Uploaded</div>
                            <div id="statSuccess"
                                style="color:var(--pq-text); font-size:24px; font-weight:600; font-family:'JetBrains Mono'; margin-top:4px;">
                                0</div>
                        </div>
                        <div
                            style="background:var(--pq-card); border:1px solid #ffd00044; padding:16px; border-radius:8px; border-top:2px solid #f6d43bff;">
                            <div style="color:var(--pq-text-dim); font-size:11px; text-transform:uppercase;">Already Present</div>
                            <div id="statDuplicate"
                                style="color:var(--pq-text); font-size:24px; font-weight:600; font-family:'JetBrains Mono'; margin-top:4px;">
                                0</div>
                        </div>
                        <div
                            style="background:var(--pq-card); border:1px solid #EF444444; padding:16px; border-radius:8px; border-top:2px solid #EF4444;">
                            <div style="color:var(--pq-text-dim); font-size:11px; text-transform:uppercase;">Failed</div>
                            <div id="statFailed"
                                style="color:var(--pq-text); font-size:24px; font-weight:600; font-family:'JetBrains Mono'; margin-top:4px;">
                                0</div>
                        </div>
                    </div>

                    <div style="display:flex; justify-content:space-between; align-items:center;">
                        <span style="color:var(--pq-text); font-size:14px; font-weight:600;">Processed Data List</span>
                        <button class="btn" onclick="UploadManager.exportFinalData()"
                            style="background:#10B981; color:#fff;">Export Summary to Excel</button>
                    </div>
                    <div
                        style="background:var(--pq-bg); border:1px solid var(--pq-border); border-radius:8px; max-height:35vh; overflow:auto;">
                        <table style="width:100%; text-align:left; border-collapse:collapse;">
                            <thead id="finalTableHeader"></thead>
                            <tbody id="finalTableBody"></tbody>
                        </table>
                    </div>
                    <!-- Final Table Pagination -->
                    <div style="display:flex; align-items:center; justify-content:space-between;">
                        <span id="finalInfo" style="color:var(--pq-text-dim); font-size:11px;"></span>
                        <div id="finalPagination" style="display:flex; gap:4px;"></div>
                    </div>
                </div>

            </div>
        </div>
    </div>

    <script src="../assets/js/target_report.js?v=1"></script>   <!-- Target vs Achieved card -->
    <script src="js/portfolio_pdf.js?v=5"></script>   <!-- "Export PDF (Meta + Google)" -->
</body>

</html>
