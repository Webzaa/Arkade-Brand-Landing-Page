<?php

ob_start(); // Buffer all output to prevent PHP notices corrupting JSON

ini_set('display_errors', 0); // Suppress errors in output (log them instead)
ini_set('display_startup_errors', '0');
error_reporting(E_ALL);
ini_set('log_errors', 1);

session_start();
require_once dirname(__DIR__, 2) . '/app/Core/db.php';
require_once dirname(__DIR__, 2) . '/app/Ads/master_tables.php';   // project campaigns / ad groups / ads (saved in DB)
require_once dirname(__DIR__, 2) . '/app/Ads/platform_metrics.php';   // extra Google metrics for the ▥ Columns panel (optional request)
// Returns spend and lead data — logged-in users (or this server's own internal calls) only.
if (($_SESSION['user_logged'] ?? '') !== 'Y' && !pqInternalRequest()) {
    http_response_code(401);
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Not logged in', 'valid' => false]);
    exit;
}
session_write_close();

/**
 * Return all CRM database connections — every database in LEAD_DATABASES (config/config.php).
 */
function getCrmDatabases(): array
{
    return leadDbs('all');
}

/**
 * Clear cached Meta/Google responses after CRM updates.
 */
function clearMetaCache(): void
{
    $cacheDir = CACHE_PATH;

    if (!is_dir($cacheDir)) {
        return;
    }

    $files = glob($cacheDir . '/meta_*.json');
    if (is_array($files)) {
        foreach ($files as $file) {
            if (is_file($file)) {
                @unlink($file);
            }
        }
    }
}

header('Content-Type: application/json');

// ===m=== Upload CSV Started===m===
// $action = isset($_GET['action']) ? $_GET['action'] : '';
$input = json_decode(file_get_contents('php://input'), true) ?? [];
$action = isset($_GET['action']) ? $_GET['action'] : (isset($input['action']) ? $input['action'] : '');
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'update_leads') {
    $updates = isset($input['updates']) && is_array($input['updates']) ? $input['updates'] : [];

    $success_count = 0;
    $duplicate_count = 0;
    $failed_count = 0;

    $databases = getCrmDatabases();

    foreach ($updates as $up) {
        $mobile = isset($up['mobile']) ? trim((string) $up['mobile']) : '';
        $gclid = isset($up['gclid']) ? trim((string) $up['gclid']) : '';
        $status = isset($up['status']) ? trim((string) $up['status']) : '';
        $sub_status = isset($up['sub_status']) ? trim((string) $up['sub_status']) : '';

        if ($gclid === '' && $mobile === '') {
            $failed_count++;
            continue;
        }

        $matched = false;
        $updated = false;

        foreach ($databases as $dbKey => $db) {
            // The confirmed lead schema has lead_status, but does not contain
            // lead_sub_status/sitevisit_status/sitevisit_sub_status.
            $checkStmt = $db->prepare(
                "SELECT id, lead_status
                 FROM `lead`
                 WHERE (
                    (gclid IS NOT NULL AND gclid <> '' AND ? <> '' AND gclid = ?)
                    OR
                    (mobile IS NOT NULL AND mobile <> '' AND ? <> '' AND RIGHT(mobile, 10) = RIGHT(?, 10))
                 )
                 LIMIT 1"
            );

            if (!$checkStmt) {
                continue;
            }

            $checkStmt->bind_param("ssss", $gclid, $gclid, $mobile, $mobile);
            $checkStmt->execute();
            $result = $checkStmt->get_result();

            if ($result && ($row = $result->fetch_assoc())) {
                $matched = true;
                $id = (int) $row['id'];

                $updateStmt = $db->prepare(
                    "UPDATE `lead` SET lead_status = ? WHERE id = ?"
                );

                if ($updateStmt) {
                    $updateStmt->bind_param("si", $status, $id);

                    if ($updateStmt->execute()) {
                        if ($updateStmt->affected_rows > 0) {
                            $updated = true;
                        } else {
                            $duplicate_count++;
                        }
                    } else {
                        $failed_count++;
                    }

                    $updateStmt->close();
                } else {
                    $failed_count++;
                }

                $checkStmt->close();
                break;
            }

            $checkStmt->close();
        }

        if (!$matched) {
            $failed_count++;
        } elseif ($updated) {
            $success_count++;
        }
    }

    clearMetaCache();

    echo json_encode([
        'success' => true,
        'updated' => $success_count,
        'duplicate' => $duplicate_count,
        'failed' => $failed_count,
        'databases_checked' => array_keys($databases)
    ]);
    exit;
}

// ===m=== Upload CSV Ended ===m===

function syncAdsetsToCampaigns(array $databases, $accessToken)
{
    foreach ($databases as $dbKey => $conn) {
        // ===m=== Get unique adsets from lead table where utm_campaignname is empty ===m===
        $sql = "SELECT DISTINCT adset FROM `lead` WHERE adset IS NOT NULL AND adset != '' AND (utm_campaignname IS NULL OR utm_campaignname = '')";
        $result = $conn->query($sql);

        if ($result && $result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $adsetName = $row['adset'];

                // ===m=== Create space and underscore variations ===m===
                $adsetUnderscore = str_replace(' ', '_', $adsetName);
                $adsetSpace = str_replace('_', ' ', $adsetName);

                // ===m=== Create Capitalized variations because Google API is Case-Sensitive! ===m===
                $adsetUcFirst = ucfirst(strtolower($adsetSpace)); // Creates "All merge"
                $adsetUcWords = ucwords(strtolower($adsetSpace)); // Creates "All Merge"

                // ===m=== Ask Google for ALL variations of the spelling ===m===
                $gaqlQuery = "SELECT ad_group.id, ad_group.name, campaign.id, campaign.name 
                          FROM ad_group 
                          WHERE ad_group.name IN (
                              '" . addslashes($adsetSpace) . "', 
                              '" . addslashes($adsetUnderscore) . "',
                              '" . addslashes($adsetUcFirst) . "',
                              '" . addslashes($adsetUcWords) . "'
                          )";

                $apiUrl = "https://googleads.googleapis.com/v24/customers/" . GOOGLE_CUSTOMER_ID . "/googleAds:searchStream";
                $ch = curl_init($apiUrl);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($ch, CURLOPT_POST, true);
                curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode(['query' => $gaqlQuery]));
                curl_setopt($ch, CURLOPT_HTTPHEADER, [
                    'Authorization: Bearer ' . $accessToken,
                    'developer-token: ' . GOOGLE_DEVELOPER_TOKEN,
                    'Content-Type: application/json'
                ]);

                $apiResponse = curl_exec($ch);
                curl_close($ch);

                $apiJson = json_decode($apiResponse, true);

                if (!empty($apiJson) && isset($apiJson[0]['results']) && count($apiJson[0]['results']) > 0) {

                    $foundCampaigns = [];
                    foreach ($apiJson[0]['results'] as $apiResult) {
                        $cName = $apiResult['campaign']['name'] ?? '';
                        if (!empty($cName)) {
                            $foundCampaigns[] = $cName;
                        }
                    }

                    $uniqueCampaigns = array_values(array_unique($foundCampaigns));

                    if (count($uniqueCampaigns) === 1) {
                        // ===m=== Only 1 campaign — simple update ===m===
                        $updateSql = "UPDATE `lead` SET utm_campaignname = '" . $conn->real_escape_string($uniqueCampaigns[0]) . "'
                                  WHERE adset = '" . $conn->real_escape_string($adsetName) . "'
                                  AND (utm_campaignname IS NULL OR utm_campaignname = '')";
                        $conn->query($updateSql);

                    } elseif (count($uniqueCampaigns) > 1) {
                        // ===m=== Multiple campaigns — assign first to existing rows, duplicate for the rest ===m===

                        // Step 1: Assign first campaign to existing rows
                        $firstCampaign = $uniqueCampaigns[0];
                        $updateSql = "UPDATE `lead` SET utm_campaignname = '" . $conn->real_escape_string($firstCampaign) . "'
                                  WHERE adset = '" . $conn->real_escape_string($adsetName) . "'
                                  AND (utm_campaignname IS NULL OR utm_campaignname = '')";
                        $conn->query($updateSql);

                        // Step 2: For each extra campaign, duplicate those rows with the new utm_campaignname
                        for ($i = 1; $i < count($uniqueCampaigns); $i++) {
                            $extraCampaign = $uniqueCampaigns[$i];

                            $fetchSql = "SELECT * FROM `lead` WHERE adset = '" . $conn->real_escape_string($adsetName) . "'
                                     AND utm_campaignname = '" . $conn->real_escape_string($firstCampaign) . "'";
                            $leads = $conn->query($fetchSql);

                            if ($leads && $leads->num_rows > 0) {
                                $fields = [];
                                foreach ($leads->fetch_fields() as $field) {
                                    $fields[] = $field->name;
                                }
                                $leads->data_seek(0);

                                while ($lead = $leads->fetch_assoc()) {
                                    $cols = [];
                                    $vals = [];
                                    foreach ($fields as $f) {
                                        if ($f === 'id')
                                            continue;
                                        $cols[] = "`$f`";
                                        if ($f === 'utm_campaignname') {
                                            $vals[] = "'" . $conn->real_escape_string($extraCampaign) . "'";
                                        } else {
                                            $val = $lead[$f];
                                            $vals[] = ($val === null) ? 'NULL' : "'" . $conn->real_escape_string($val) . "'";
                                        }
                                    }
                                    $mobileVal = $conn->real_escape_string($lead['mobile']);
                                    $checkSql = "SELECT id FROM `lead` WHERE mobile = '{$mobileVal}' AND utm_campaignname = '" . $conn->real_escape_string($extraCampaign) . "' LIMIT 1";
                                    $checkResult = $conn->query($checkSql);
                                    if (!$checkResult || $checkResult->num_rows === 0) {
                                        $insertSql = "INSERT INTO lead (" . implode(', ', $cols) . ") VALUES (" . implode(', ', $vals) . ")";
                                        $conn->query($insertSql);
                                    }
                                    //$insertSql = "INSERT INTO `lead` (" . implode(', ', $cols) . ") VALUES (" . implode(', ', $vals) . ")";
                                    //$conn->query($insertSql);
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

$tokenUrl = 'https://oauth2.googleapis.com/token';

$tokenData = http_build_query([
    'client_id' => GOOGLE_CLIENT_ID,
    'client_secret' => GOOGLE_CLIENT_SECRET,
    'refresh_token' => GOOGLE_REFRESH_TOKEN,
    'grant_type' => 'refresh_token'
]);

$ch = curl_init($tokenUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $tokenData);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Content-Type: application/x-www-form-urlencoded'
]);

$tokenResponse = curl_exec($ch);
curl_close($ch);

$tokenJson = json_decode($tokenResponse, true);

if (!isset($tokenJson['access_token'])) {
    ob_clean();
    echo json_encode(['error' => 'Failed to retrieve Google Access Token.']);
    exit;
}

$accessToken = $tokenJson['access_token'];

// Handle fetch_pivot_report for Excel Analysis Export
if ($action === 'fetch_pivot_report') {
    set_time_limit(300);

    $reqSince = isset($_GET['since']) ? $_GET['since'] : (isset($input['since']) ? $input['since'] : date('Y-m-d', strtotime('-30 days')));
    $reqUntil = isset($_GET['until']) ? $_GET['until'] : (isset($input['until']) ? $input['until'] : date('Y-m-d'));

    $reqStatus = isset($_GET['status_filter']) ? $_GET['status_filter'] : (isset($_GET['campaignsstatus']) ? $_GET['campaignsstatus'] : (isset($input['campaignsstatus']) ? $input['campaignsstatus'] : 'all'));

    $statusConds = [
        'active' => "campaign.status = 'ENABLED' AND",
        'inactive' => "campaign.status = 'PAUSED' AND",
    ];
    $pivotStatusFilter = isset($statusConds[strtolower($reqStatus)]) ? $statusConds[strtolower($reqStatus)] : "";

    $gaqlPivot = "SELECT campaign.id,
                         campaign.name,
                         ad_group.id,
                         ad_group.name,
                         ad_group_ad.ad.id,
                         ad_group_ad.ad.name,
                         metrics.cost_micros,
                         metrics.impressions,
                         metrics.clicks
                  FROM ad_group_ad
                  WHERE {$pivotStatusFilter}
                  segments.date BETWEEN '{$reqSince}' AND '{$reqUntil}'";

    $apiUrl = "https://googleads.googleapis.com/v24/customers/" . GOOGLE_CUSTOMER_ID . "/googleAds:searchStream";

    // Build complete Campaign ID -> Name map for Google Ads account
    $campIdNameMap = [];
    $chCampMap = curl_init($apiUrl);
    curl_setopt($chCampMap, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($chCampMap, CURLOPT_POST, true);
    curl_setopt($chCampMap, CURLOPT_POSTFIELDS, json_encode(['query' => "SELECT campaign.id, campaign.name FROM campaign"]));
    curl_setopt($chCampMap, CURLOPT_HTTPHEADER, [
        'Authorization: Bearer ' . $accessToken,
        'developer-token: ' . GOOGLE_DEVELOPER_TOKEN,
        'Content-Type: application/json'
    ]);
    $campMapRes = curl_exec($chCampMap);
    curl_close($chCampMap);
    $campMapJson = json_decode($campMapRes, true);
    if (!empty($campMapJson) && is_array($campMapJson)) {
        foreach ($campMapJson as $chunk) {
            if (!isset($chunk['results']) || !is_array($chunk['results']))
                continue;
            foreach ($chunk['results'] as $cr) {
                $cid = (string) ($cr['campaign']['id'] ?? '');
                $cname = $cr['campaign']['name'] ?? '';
                if ($cid !== '' && $cname !== '') {
                    $campIdNameMap[$cid] = $cname;
                }
            }
        }
    }

    $chAd = curl_init($apiUrl);
    curl_setopt($chAd, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($chAd, CURLOPT_POST, true);
    curl_setopt($chAd, CURLOPT_POSTFIELDS, json_encode(['query' => $gaqlPivot]));
    curl_setopt($chAd, CURLOPT_HTTPHEADER, [
        'Authorization: Bearer ' . $accessToken,
        'developer-token: ' . GOOGLE_DEVELOPER_TOKEN,
        'Content-Type: application/json'
    ]);

    $adResponse = curl_exec($chAd);
    curl_close($chAd);

    $adJson = json_decode($adResponse, true);

    $adRowsMap = [];
    if (!empty($adJson) && is_array($adJson)) {
        foreach ($adJson as $chunk) {
            if (!isset($chunk['results']) || !is_array($chunk['results']))
                continue;
            foreach ($chunk['results'] as $r) {
                $cId = (string) ($r['campaign']['id'] ?? '');
                $cName = $r['campaign']['name'] ?? 'Unknown Campaign';
                $aName = $r['adGroup']['name'] ?? 'Unknown Ad Group';
                $adName = !empty($r['adGroupAd']['ad']['name']) ? $r['adGroupAd']['ad']['name'] : ('Ad #' . ($r['adGroupAd']['ad']['id'] ?? 'Unknown'));

                if ($cId !== '') {
                    $campIdNameMap[$cId] = $cName;
                }

                // Only this project's saved campaign → ad group → ad, with saved (database) names.
                $probe = [[
                    'campaign_id' => $cId, 'campaign_name' => $cName,
                    'adgroup_id' => (string) ($r['adGroup']['id'] ?? ''), 'adset_name' => $aName,
                    'ad_id' => (string) ($r['adGroupAd']['ad']['id'] ?? ''), 'ad_name' => $adName,
                ]];
                [$probe] = filterProjectAdRows('google', $probe, [
                    'campaign_id' => 'campaign_id', 'campaign_name' => 'campaign_name',
                    'adgroup_id' => 'adgroup_id', 'adgroup_name' => 'adset_name',
                    'ad_id' => 'ad_id', 'ad_name' => 'ad_name',
                ]);
                if (!$probe) {
                    continue;
                }
                $p0 = $probe[0];
                [$cId, $cName, $aName, $adName] = [$p0['campaign_id'], $p0['campaign_name'], $p0['adset_name'], $p0['ad_name']];

                $key = strtolower(trim($cName)) . '|' . strtolower(trim($aName)) . '|' . strtolower(trim($adName));
                if (!isset($adRowsMap[$key])) {
                    $adRowsMap[$key] = [
                        'campaign_id' => $cId,
                        'campaign_name' => $cName,
                        'adgroup_id' => $p0['adgroup_id'],
                        'adset_name' => $aName,
                        'ad_id' => $p0['ad_id'],
                        'ad_name' => $adName,
                        'spend' => 0.0,
                        'impressions' => 0,
                        'clicks' => 0,
                        'frequency' => 0.0,
                    ];
                }
                $adRowsMap[$key]['spend'] += (isset($r['metrics']['costMicros']) ? (float) $r['metrics']['costMicros'] / 1000000 : 0);
                $adRowsMap[$key]['impressions'] += (isset($r['metrics']['impressions']) ? (int) $r['metrics']['impressions'] : 0);
                $adRowsMap[$key]['clicks'] += (isset($r['metrics']['clicks']) ? (int) $r['metrics']['clicks'] : 0);
            }
        }
    }

    $databases = getCrmDatabases();
    $crmStatusMap = [];

    $sqlStatus = "SELECT
                    MAX(utm_campaignid) AS utm_campaignid,
                    COALESCE(NULLIF(TRIM(utm_campaignname), ''), NULLIF(TRIM(campaign_name), ''), 'Unknown') AS campaign_name,
                    COALESCE(NULLIF(TRIM(utm_adgroupname), ''), NULLIF(TRIM(adset_name), ''), NULLIF(TRIM(adset), ''), 'Unknown') AS adset_name,
                    COALESCE(NULLIF(TRIM(utm_adname), ''), NULLIF(TRIM(ad_name), ''), 'Unknown') AS ad_name,
                    campaignsource,
                    COUNT(*) AS total_leads,
                    SUM(CASE WHEN TRIM(UPPER(COALESCE(lead_status,''))) IN ('QUALIFIED','HOT','WARM','INTERESTED') THEN 1 ELSE 0 END) AS in_qualified,
                    SUM(CASE WHEN TRIM(UPPER(COALESCE(lead_status,''))) = 'LOST POST QUALIFIED' THEN 1 ELSE 0 END) AS lost_post_qualified,
                    SUM(CASE WHEN TRIM(UPPER(COALESCE(lead_status,''))) = 'NON-QUALIFIED' THEN 1 ELSE 0 END) AS non_qualified,
                    SUM(CASE WHEN TRIM(UPPER(COALESCE(lead_status,''))) = 'TO BE QUALIFIED' THEN 1 ELSE 0 END) AS to_be_qualified
                FROM `lead`
                WHERE createddate >= ? AND createddate < DATE_ADD(?, INTERVAL 1 DAY)
                  AND (
                    LOWER(TRIM(COALESCE(campaignsource, ''))) IN ('google', 'googledg', 'website')
                    OR (utm_campaignname IS NOT NULL AND TRIM(utm_campaignname) <> '')
                    OR (utm_campaignid IS NOT NULL AND TRIM(utm_campaignid) <> '')
                  )
                  AND (lead_status IS NULL OR UPPER(TRIM(lead_status)) NOT IN ('TEST', 'JUNK'))
                  AND (name IS NULL OR LOWER(TRIM(name)) NOT LIKE '%test%')
                  AND (email IS NULL OR LOWER(TRIM(email)) NOT LIKE '%test%')
                  AND (mobile IS NULL OR (
                      LOWER(TRIM(mobile)) NOT LIKE '%test%'
                      AND TRIM(mobile) NOT IN ('9999999999', '8888888888', '0000000000', '1234567890', '1111111111')
                  ))
                GROUP BY utm_campaignid, campaign_name, adset_name, ad_name, campaignsource";

    foreach ($databases as $dbKey => $db) {
        $stmtStatus = $db->prepare($sqlStatus);
        if ($stmtStatus) {
            $stmtStatus->bind_param('ss', $reqSince, $reqUntil);
            $stmtStatus->execute();
            $resStatus = $stmtStatus->get_result();
            if ($resStatus) {
                while ($r = $resStatus->fetch_assoc()) {
                    $cSrc = strtolower(trim($r['campaignsource'] ?? ''));
                    if ($cSrc === 'website') {
                        $r['campaign_name'] = 'Website';
                        $r['adset_name'] = 'Website';
                        $r['ad_name'] = 'Website';
                    } else {
                        $cId = trim((string) ($r['utm_campaignid'] ?? ''));
                        $savedGoogle = projectStructure('google')['campaigns'];
                        if ($cId !== '' && isset($savedGoogle[$cId])) {
                            $r['campaign_name'] = $savedGoogle[$cId];   // saved (database) name
                        } elseif ($cId !== '' && isset($campIdNameMap[$cId])) {
                            $r['campaign_name'] = $campIdNameMap[$cId];
                        } else {
                            // Fallback string matching for DB names vs display names
                            $lowerCamp = strtolower(trim($r['campaign_name']));
                            $aliases = defined('GOOGLE_CAMPAIGN_ALIASES') ? GOOGLE_CAMPAIGN_ALIASES : [];
                            if (isset($aliases[$lowerCamp])) {
                                $r['campaign_name'] = $aliases[$lowerCamp];
                            }
                        }
                    }

                    $key = strtolower(trim($r['campaign_name'])) . '|' . strtolower(trim($r['adset_name'])) . '|' . strtolower(trim($r['ad_name']));
                    if (!isset($crmStatusMap[$key])) {
                        $crmStatusMap[$key] = [
                            'campaign_id' => $r['utm_campaignid'] ?? '',
                            'campaign_name' => $r['campaign_name'],
                            'adset_name' => $r['adset_name'],
                            'ad_name' => $r['ad_name'],
                            'total_leads' => 0,
                            'leads' => 0,
                            'qualified' => 0,
                            'in_qualified' => 0,
                            'lost_post_qualified' => 0,
                            'non_qualified' => 0,
                            'to_be_qualified' => 0
                        ];
                    }
                    $crmStatusMap[$key]['total_leads'] += (int) ($r['total_leads'] ?? 0);
                    $crmStatusMap[$key]['leads'] += (int) ($r['total_leads'] ?? 0);
                    $crmStatusMap[$key]['qualified'] += ((int) $r['in_qualified'] + (int) $r['lost_post_qualified']);
                    $crmStatusMap[$key]['in_qualified'] += (int) $r['in_qualified'];
                    $crmStatusMap[$key]['lost_post_qualified'] += (int) $r['lost_post_qualified'];
                    $crmStatusMap[$key]['non_qualified'] += (int) $r['non_qualified'];
                    $crmStatusMap[$key]['to_be_qualified'] += (int) $r['to_be_qualified'];
                }
            }
            $stmtStatus->close();
        }
    }

    $finalRows = [];
    $processedCrmKeys = [];

    // Map by exact key or fallback to campaign|adset
    $crmByCampAdset = [];
    foreach ($crmStatusMap as $k => $crmVal) {
        $parts = explode('|', $k);
        $campAdsetKey = ($parts[0] ?? '') . '|' . ($parts[1] ?? '');
        if (!isset($crmByCampAdset[$campAdsetKey])) {
            $crmByCampAdset[$campAdsetKey] = [
                'total_leads' => 0,
                'leads' => 0,
                'qualified' => 0,
                'in_qualified' => 0,
                'lost_post_qualified' => 0,
                'non_qualified' => 0,
                'to_be_qualified' => 0
            ];
        }
        $crmByCampAdset[$campAdsetKey]['total_leads'] += $crmVal['total_leads'];
        $crmByCampAdset[$campAdsetKey]['leads'] += $crmVal['leads'];
        $crmByCampAdset[$campAdsetKey]['qualified'] += $crmVal['qualified'];
        $crmByCampAdset[$campAdsetKey]['in_qualified'] += $crmVal['in_qualified'];
        $crmByCampAdset[$campAdsetKey]['lost_post_qualified'] += $crmVal['lost_post_qualified'];
        $crmByCampAdset[$campAdsetKey]['non_qualified'] += $crmVal['non_qualified'];
        $crmByCampAdset[$campAdsetKey]['to_be_qualified'] += $crmVal['to_be_qualified'];
    }

    // extra metrics per ad (interactions, video views, conversions …) — separate, optional request
    $pmAds = pmGoogleFetch($apiUrl, $accessToken, 'ad_group_ad', "{$pivotStatusFilter} segments.date BETWEEN '{$reqSince}' AND '{$reqUntil}'");

    foreach ($adRowsMap as $key => $adRow) {
        $adRow['pm'] = $pmAds[(string) ($adRow['ad_id'] ?? '')] ?? [];
        if (isset($crmStatusMap[$key])) {
            $crm = $crmStatusMap[$key];
            $processedCrmKeys[$key] = true;
        } else {
            $parts = explode('|', $key);
            $campAdsetKey = ($parts[0] ?? '') . '|' . ($parts[1] ?? '');
            if (isset($crmByCampAdset[$campAdsetKey])) {
                $crm = $crmByCampAdset[$campAdsetKey];
                // Mark associated CRM keys as processed
                foreach ($crmStatusMap as $ck => $cv) {
                    if (strpos($ck, $campAdsetKey . '|') === 0) {
                        $processedCrmKeys[$ck] = true;
                    }
                }
                unset($crmByCampAdset[$campAdsetKey]);
            } else {
                $crm = [
                    'total_leads' => 0,
                    'leads' => 0,
                    'qualified' => 0,
                    'in_qualified' => 0,
                    'lost_post_qualified' => 0,
                    'non_qualified' => 0,
                    'to_be_qualified' => 0
                ];
            }
        }

        $finalRows[] = array_merge($adRow, $crm);
    }

    foreach ($crmStatusMap as $key => $crm) {
        if (!isset($processedCrmKeys[$key])) {
            $parts = explode('|', $key);
            $cName = !empty($crm['campaign_name']) ? $crm['campaign_name'] : (!empty($parts[0]) ? ucwords($parts[0]) : 'Unknown Campaign');
            $aName = !empty($crm['adset_name']) ? $crm['adset_name'] : (!empty($parts[1]) ? ucwords($parts[1]) : 'Unknown Ad Group');
            $adName = !empty($crm['ad_name']) ? $crm['ad_name'] : (!empty($parts[2]) ? ucwords($parts[2]) : 'Unknown Ad');

            if (strtolower($cName) === 'website') {
                $cName = 'Website';
                $aName = 'Website';
                $adName = 'Website';
            }

            $cId = $crm['campaign_id'] ?? '';
            if ($cName !== 'Website') {
                $pcid = projectCampaignId('google', (string) $cId, $cName);
                if ($pcid === null) {
                    continue;   // leads of campaigns that aren't linked to this project
                }
                $gs = projectStructure('google');
                $cId = $pcid;
                $cName = $gs['campaigns'][$pcid];
                $pgid = projectAdgroupId('google', $pcid, '', $aName);
                if ($pgid !== null) {
                    $aName = $gs['adgroups'][$pgid]['name'];
                    $paid = projectAdId('google', $pgid, '', $adName);
                    if ($paid !== null) {
                        $adName = $gs['ads'][$paid]['name'];
                    }
                }
            }

            $finalRows[] = array_merge([
                'campaign_id' => $cId,
                'campaign_name' => $cName,
                'adset_name' => $aName,
                'ad_name' => $adName,
                'spend' => 0.0,
                'impressions' => 0,
                'clicks' => 0,
                'frequency' => 0.0,
            ], $crm);
        }
    }

    // All / Performance / Awareness tab, Users & Roles → Campaign types
    $finalRows = array_values(array_filter($finalRows, fn($r) => pqViewShows(pqCampaignType('google', (string) ($r['campaign_id'] ?? ''), (string) ($r['campaign_name'] ?? '')))));
    ob_clean();
    echo json_encode([
        'success' => true,
        'rows' => $finalRows
    ]);
    exit;
}

// Only sync adsets when explicitly requested (e.g. action=sync_adsets)
if ($action === 'sync_adsets') {
    syncAdsetsToCampaigns(getCrmDatabases(), $accessToken);
}

$since = isset($input['since']) ? $input['since'] : date('Y-m-d', strtotime('-30 days'));
$until = isset($input['until']) ? $input['until'] : date('Y-m-d');

$campaignsstatus = isset($input['campaignsstatus']) ? $input['campaignsstatus'] : 'all';
$statusConditions = [
    'active' => "campaign.status = 'ENABLED' AND",
    'inactive' => "campaign.status = 'PAUSED' AND",
];
$statusFilter = isset($statusConditions[$campaignsstatus])
    ? $statusConditions[$campaignsstatus]
    : "";

$query = "SELECT campaign.id,
                 campaign.name,
                 campaign.status,
                 campaign.advertising_channel_type,
                 metrics.cost_micros,
                 metrics.impressions,
                 metrics.clicks,
                 metrics.ctr,
                 metrics.average_cpm,
                 metrics.conversions
          FROM campaign
          WHERE {$statusFilter}
          segments.date BETWEEN '{$since}' AND '{$until}'";

$apiUrl = "https://googleads.googleapis.com/v24/customers/" . GOOGLE_CUSTOMER_ID . "/googleAds:searchStream";
//echo $apiUrl;
$ch2 = curl_init($apiUrl);
curl_setopt($ch2, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch2, CURLOPT_POST, true);
curl_setopt($ch2, CURLOPT_POSTFIELDS, json_encode(['query' => $query]));
curl_setopt($ch2, CURLOPT_HTTPHEADER, [
    'Authorization: Bearer ' . $accessToken,
    'developer-token: ' . GOOGLE_DEVELOPER_TOKEN,
    'Content-Type: application/json'
]);

$apiResponse = curl_exec($ch2);
curl_close($ch2);


$apiJson = json_decode($apiResponse, true);
//print_r($apiJson);
if (isset($apiJson[0]['error'])) {
    ob_clean();
    echo json_encode(['error' => 'Google Ads API Error: ' . $apiJson[0]['error']['message']]);
    exit;
}

// ===m=== Fetch avg. impression frequency per user, per campaign ===m===
// This is a SEPARATE query (not merged into the main insights query above) because:
//  1. It's only available for Display, Video, Discovery, and App campaigns — Search
//     campaigns simply won't have this metric and will read as 0, which is expected.
//  2. Per Google's docs this metric "cannot be aggregated" — summing per-day values
//     would NOT give the correct frequency for the full date range, so it must be
//     queried as a single figure for the whole range (no segments.date breakdown).
//  3. It's restricted to date ranges of 92 days or less; outside that we skip the
//     request entirely and every campaign's frequency falls back to 0.
$freqByCampaign = [];
$sinceDt = new DateTime($since);
$untilDt = new DateTime($until);
$daySpan = (int) $sinceDt->diff($untilDt)->days;
if ($daySpan <= 92) {
    $freqQuery = "SELECT campaign.id, metrics.average_impression_frequency_per_user
                  FROM campaign
                  WHERE {$statusFilter}
                  segments.date BETWEEN '{$since}' AND '{$until}'";

    $chFreq = curl_init($apiUrl);
    curl_setopt($chFreq, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($chFreq, CURLOPT_POST, true);
    curl_setopt($chFreq, CURLOPT_POSTFIELDS, json_encode(['query' => $freqQuery]));
    curl_setopt($chFreq, CURLOPT_HTTPHEADER, [
        'Authorization: Bearer ' . $accessToken,
        'developer-token: ' . GOOGLE_DEVELOPER_TOKEN,
        'Content-Type: application/json'
    ]);
    $freqResponse = curl_exec($chFreq);
    curl_close($chFreq);
    $freqJson = json_decode($freqResponse, true);

    // Non-fatal: if this query errors (e.g. account has no eligible campaign types),
    // we just leave $freqByCampaign empty and every campaign shows 0 — the main
    // dashboard data above is unaffected.
    if (!isset($freqJson[0]['error']) && !empty($freqJson) && is_array($freqJson)) {
        foreach ($freqJson as $freqChunk) {
            if (!isset($freqChunk['results']) || !is_array($freqChunk['results'])) {
                continue;
            }
            foreach ($freqChunk['results'] as $freqResult) {
                $fCampId = $freqResult['campaign']['id'] ?? null;
                if ($fCampId === null) {
                    continue;
                }
                // Not summed across rows — later rows for the same campaign.id would only
                // occur if Google still segments internally, in which case we keep the
                // last value rather than adding them (adding would double-count).
                $freqByCampaign[$fCampId] = (float) ($freqResult['metrics']['averageImpressionFrequencyPerUser'] ?? 0);
            }
        }
    }
}

// ===m=== Extra metrics per campaign (interactions, video views, conversions …) for the ▥ Columns panel ===m===
// Separate, optional request: a field Google rejects is dropped and retried; on failure campaigns just get no 'pm'.
$pmCampaign = pmGoogleFetch($apiUrl, $accessToken, 'campaign', "{$statusFilter} segments.date BETWEEN '{$since}' AND '{$until}'");
// daily / lifetime budget per project campaign (▥ Columns → "Daily budget"); never blocks the dashboard
$budgetPm = [];
try {
    require_once dirname(__DIR__, 2) . '/app/Ads/creatives.php';
    $budgetPm = crBudgetPm('google', array_keys(projectStructure('google')['campaigns']));
} catch (Throwable $e) {
    error_log('[googleapi] budgets: ' . $e->getMessage());
}

// ===m=== Fetch CRM Data from DB once to map to campaigns ===m===
$crmData = [];
$totalByCampaign = [];
$dbLeadsRaw = [];

$databases = getCrmDatabases();

// ===m=== Common SQL condition to exclude test / junk leads ===m===
$testExclusionSql = "
    AND (lead_status IS NULL OR UPPER(TRIM(lead_status)) NOT IN ('TEST', 'JUNK'))
    AND (name IS NULL OR LOWER(TRIM(name)) NOT LIKE '%test%')
    AND (email IS NULL OR LOWER(TRIM(email)) NOT LIKE '%test%')
    AND (mobile IS NULL OR (
        LOWER(TRIM(mobile)) NOT LIKE '%test%'
        AND TRIM(mobile) NOT IN ('9999999999', '8888888888', '0000000000', '1234567890', '1111111111')
    ))
";

$crmSql = "SELECT
            mobile,
            MAX(gclid) AS gclid,
            MAX(utm_adgroupname) AS utm_adgroupname,
            MAX(utm_adname) AS utm_adname,
            MAX(name) AS name,
            MAX(email) AS email,
            MAX(utm_campaignname) AS utm_campaignname,
            MAX(utm_campaignid) AS utm_campaignid,
            MAX(campaignsource) AS campaignsource,
            MAX(utmC) AS utmC,
            MAX(lead_status) AS lead_status,
            MAX(sitevisit_status) AS sitevisit_status,
            MAX(createddate) AS createddate
          FROM `lead`
          WHERE (
                (utm_campaignname IS NOT NULL AND TRIM(utm_campaignname) <> '')
                OR LOWER(TRIM(campaignsource)) = 'website'
                OR LOWER(TRIM(campaignsource)) IN ('google', 'googledg')
          )
          AND createddate >= ?
          AND createddate < DATE_ADD(?, INTERVAL 1 DAY)
          {$testExclusionSql}
          GROUP BY mobile
          ORDER BY MAX(createddate) DESC";

$totalSql = "SELECT
                MAX(utm_campaignid) AS utm_campaignid,
                COUNT(*) AS total_leads,
                SUM(
                    CASE
                        WHEN LOWER(TRIM(lead_status)) IN ('qualified','hot','warm','interested','lost post qualified','lost post qualification')
                        THEN 1 ELSE 0
                    END
                ) AS total_qualified,
                SUM(
                    CASE
                        WHEN LOWER(TRIM(sitevisit_status)) IN ('visit done','visited','site visit done','site visit','walkin','walk-in','done','yes','conducted')
                        THEN 1 ELSE 0
                    END
                ) AS total_sitevisit
             FROM `lead`
             WHERE utm_campaignid IS NOT NULL
               AND TRIM(utm_campaignid) <> ''
               AND createddate >= ?
               AND createddate < DATE_ADD(?, INTERVAL 1 DAY)
               {$testExclusionSql}
             GROUP BY utm_campaignid";

$dbLeadsSql = "SELECT
                    mobile,
                    MAX(gclid) AS gclid,
                    MAX(utm_adgroupname) AS utm_adgroupname,
                    MAX(utm_adname) AS utm_adname,
                    MAX(name) AS name,
                    MAX(email) AS email,
                    MAX(utm_campaignname) AS utm_campaignname,
                    MAX(utm_campaignid) AS utm_campaignid,
                    MAX(campaignsource) AS campaignsource,
                    MAX(lead_status) AS lead_status,
                    MAX(sitevisit_status) AS sitevisit_status,
                    MAX(createddate) AS createddate,
                    COUNT(*) AS entries
               FROM `lead`
               WHERE (
                     (utm_campaignname IS NOT NULL AND TRIM(utm_campaignname) <> '')
                     OR LOWER(TRIM(campaignsource)) = 'website'
                     OR LOWER(TRIM(campaignsource)) IN ('google', 'googledg')
               )
               AND createddate >= ?
               AND createddate < DATE_ADD(?, INTERVAL 1 DAY)
               {$testExclusionSql}
               GROUP BY mobile";

foreach ($databases as $dbKey => $db) {
    // CRM lead details
    $stmt = $db->prepare($crmSql);
    if ($stmt) {
        $stmt->bind_param("ss", $since, $until);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result) {
            while ($row = $result->fetch_assoc()) {
                $row['database'] = $dbKey;
                $crmData[] = $row;
            }
        }
        $stmt->close();
    }

    // Campaign totals
    $stmt = $db->prepare($totalSql);
    if ($stmt) {
        $stmt->bind_param("ss", $since, $until);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result) {
            while ($row = $result->fetch_assoc()) {
                $campaignId = trim((string) ($row['utm_campaignid'] ?? ''));
                if ($campaignId === '') {
                    continue;
                }

                if (!isset($totalByCampaign[$campaignId])) {
                    $totalByCampaign[$campaignId] = [
                        'utm_campaignid' => $campaignId,
                        'total_leads' => 0,
                        'total_qualified' => 0,
                        'total_sitevisit' => 0
                    ];
                }

                $totalByCampaign[$campaignId]['total_leads'] += (int) ($row['total_leads'] ?? 0);
                $totalByCampaign[$campaignId]['total_qualified'] += (int) ($row['total_qualified'] ?? 0);
                $totalByCampaign[$campaignId]['total_sitevisit'] += (int) ($row['total_sitevisit'] ?? 0);
            }
        }
        $stmt->close();
    }

    // Raw CRM leads used for campaign-level matching
    $stmt = $db->prepare($dbLeadsSql);
    if ($stmt) {
        $stmt->bind_param("ss", $since, $until);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result) {
            while ($row = $result->fetch_assoc()) {
                $row['database'] = $dbKey;
                $dbLeadsRaw[] = $row;
            }
        }
        $stmt->close();
    }
}

$campaigns = [];
$trend = [];

// ===m=== STEP 1: Aggregate raw API rows by campaign.id ===m===
// Google Ads implicitly segments results by day because segments.date is used
// in WHERE (even though it isn't SELECTed). This collapses all day-rows for
// the same campaign into a single bucket BEFORE we touch CRM matching.
$rawCampaigns = [];

if (!empty($apiJson) && is_array($apiJson)) {
    foreach ($apiJson as $chunk) {
        if (!isset($chunk['results']) || !is_array($chunk['results'])) {
            continue;
        }

        foreach ($chunk['results'] as $result) {
            $campId = $result['campaign']['id'] ?? ($result['campaign']['name'] ?? 'unknown');
            $campName = $result['campaign']['name'] ?? 'Unknown';
            $campStatus = $result['campaign']['status'] ?? '';

            if (!isset($rawCampaigns[$campId])) {
                $rawCampaigns[$campId] = [
                    'id' => $campId,
                    'name' => $campName,
                    'campStatus' => $campStatus,
                    'costMicros' => 0,
                    'impressions' => 0,
                    'clicks' => 0,
                    'leads' => 0,
                ];
            }

            $rawCampaigns[$campId]['costMicros'] += isset($result['metrics']['costMicros']) ? (float) $result['metrics']['costMicros'] : 0;
            $rawCampaigns[$campId]['impressions'] += isset($result['metrics']['impressions']) ? (int) $result['metrics']['impressions'] : 0;
            $rawCampaigns[$campId]['clicks'] += isset($result['metrics']['clicks']) ? (int) $result['metrics']['clicks'] : 0;
            $rawCampaigns[$campId]['leads'] += isset($result['metrics']['conversions']) ? (int) $result['metrics']['conversions'] : 0;
        }
    }
}

// ===m=== STEP 2: Build ONE final entry per unique campaign; CRM matched exactly once ===m===
foreach ($rawCampaigns as $raw) {
    $campId = $raw['id'];
    $campName = $raw['name'];
    $campStatus = $raw['campStatus'];
    $spend = $raw['costMicros'] / 1000000;

    $impressions = $raw['impressions'];
    $clicks = $raw['clicks'];
    // $leads = $raw['leads'];

    // $cpl = $leads > 0 ? round($spend / $leads, 2) : 0;
    $ctr = $impressions > 0 ? round(($clicks / $impressions) * 100, 2) : 0;
    $cpm = $impressions > 0 ? round(($spend / $impressions) * 1000, 2) : 0;

    // ===m=== NEW: Calculate CRM Metrics (now runs once per campaign, not once per day) ===m===
    $qualifiedCount = 0;
    $siteVisitCount = 0;
    $qualifiedLeads = [];
    $walkinLeads = [];

    foreach ($crmData as $crm) {
        // ===m=== Match by campaign ID (stable) or by utm_campaignname ===m===
        $dbCampaignIds = array_map('trim', explode(',', $crm['utm_campaignid'] ?? ''));
        $isExactMatch = false;
        foreach ($dbCampaignIds as $dbCampId) {
            if ($dbCampId !== '' && (string) $dbCampId === (string) $campId) {
                $isExactMatch = true;
                break;
            }
        }

        if (!$isExactMatch && !empty($crm['utm_campaignname'])) {
            $normCrmName = preg_replace('/[^a-z0-9]/', '', strtolower(trim($crm['utm_campaignname'])));
            $normCampName = preg_replace('/[^a-z0-9]/', '', strtolower(trim($campName)));
            if ($normCrmName !== '' && ($normCrmName === $normCampName || strpos($normCampName, $normCrmName) !== false || strpos($normCrmName, $normCampName) !== false)) {
                $isExactMatch = true;
            }
        }

        if ($isExactMatch) {
            $lStatus = strtolower(trim($crm['lead_status'] ?? ''));
            $svStatus = strtolower(trim($crm['sitevisit_status'] ?? ''));
            $svSubStatus = strtolower(trim($crm['sitevisit_sub_status'] ?? ''));
            $lSubStatus = strtolower(trim($crm['lead_sub_status'] ?? ''));

            if (in_array($lStatus, ['qualified', 'hot', 'warm', 'interested', 'lost post qualified', 'lost post qualification'])) {
                $qualifiedCount++;
                $qualifiedLeads[] = $crm;
            }

            if (
                in_array($svStatus, ['visit done', 'VISIT DONE', 'visited', 'site visit done', 'site visit', 'walkin', 'walk-in', 'done', 'yes', 'conducted']) ||
                in_array($svSubStatus, ['visit done', 'visited', 'site visit done']) ||
                in_array($lSubStatus, ['visit done', 'visited', 'site visit done'])
            ) {
                $siteVisitCount++;
                $walkinLeads[] = $crm;
            }
        }
    }

    // ===m=== Leads & CPL: raw (non-distinct-by-name) leads from `lead` table, campaignsource Google/Website only ===m===
    $matchedLeadsData = [];
    foreach ($dbLeadsRaw as $lRow) {
        // ===m=== Match by campaign ID (stable) or by utm_campaignname ===m===
        $dbCampaignIdsRaw = array_map('trim', explode(',', $lRow['utm_campaignid'] ?? ''));
        $rowMatched = false;
        foreach ($dbCampaignIdsRaw as $dbCampIdRaw) {
            if ($dbCampIdRaw !== '' && (string) $dbCampIdRaw === (string) $campId) {
                $matchedLeadsData[] = $lRow;
                $rowMatched = true;
                break;
            }
        }

        if (!$rowMatched && !empty($lRow['utm_campaignname'])) {
            $normCrm = preg_replace('/[^a-z0-9]/', '', strtolower(trim($lRow['utm_campaignname'])));
            $normCamp = preg_replace('/[^a-z0-9]/', '', strtolower(trim($campName)));
            if ($normCrm !== '' && ($normCrm === $normCamp || strpos($normCamp, $normCrm) !== false || strpos($normCrm, $normCamp) !== false)) {
                $matchedLeadsData[] = $lRow;
                $rowMatched = true;
            }
        }
    }
    $leads = count($matchedLeadsData);
    $cpl = $leads > 0 ? round($spend / $leads, 2) : 0;

    $cpql = $qualifiedCount > 0 ? round($spend / $qualifiedCount, 2) : 0;
    $cpsv = $siteVisitCount > 0 ? round($spend / $siteVisitCount, 2) : 0;

    $status = 'warn';
    if ($leads > 0 && $cpl < 500) {
        $status = 'good';
    } elseif ($cpl > 1200 || ($spend > 5000 && $leads == 0)) {
        $status = 'bad';
    }

    $inQual = 0;
    $lostQual = 0;
    $nonQual = 0;
    $toBeQual = 0;
    foreach ($matchedLeadsData as $lRow) {
        $st = strtoupper(trim($lRow['lead_status'] ?? ''));
        if ($st === 'QUALIFIED' || in_array(strtolower($st), ['hot', 'warm', 'interested'])) {
            $inQual++;
        } elseif ($st === 'LOST POST QUALIFIED' || $st === 'LOST POST QUALIFICATION') {
            $lostQual++;
        } elseif ($st === 'NON-QUALIFIED' || $st === 'NON QUALIFIED') {
            $nonQual++;
        } elseif ($st === 'TO BE QUALIFIED') {
            $toBeQual++;
        }
    }

    $campaigns[] = [
        'id' => $campId,
        'name' => $campName,
        'campStatus' => $campStatus,
        'platform' => 'Google',
        'spend' => $spend,
        'impressions' => $impressions,
        'clicks' => $clicks,
        'ctr' => $ctr,
        'cpm' => $cpm,
        'frequency' => round($freqByCampaign[$campId] ?? 0, 2),
        'pm' => array_merge($pmCampaign[(string) $campId] ?? [], $budgetPm[(string) $campId] ?? []),
        'daily_budget' => $budgetPm[(string) $campId]['pm_daily_budget'] ?? null,
        'lifetime_budget' => $budgetPm[(string) $campId]['pm_lifetime_budget'] ?? null,
        'reach' => (int) round($pmCampaign[(string) $campId]['pm_unique_users'] ?? 0),   // unique users (YouTube / display)
        'leads' => $leads,
        'leads_data' => $matchedLeadsData,
        'cpl' => $cpl,
        'qualified' => $qualifiedCount,
        'in_qualified' => $inQual,
        'lost_post_qualified' => $lostQual,
        'non_qualified' => $nonQual,
        'to_be_qualified' => $toBeQual,
        'walkins' => $siteVisitCount,
        'qualified_leads' => $qualifiedLeads,
        'walkin_leads' => $walkinLeads,
        'cpql' => $cpql,
        'cpsv' => $cpsv
    ];
}

// ===m=== NEW: Add Website / Unassigned Campaign ===m===
$websiteQualifiedCount = 0;
$websiteSiteVisitCount = 0;
$websiteQualifiedLeads = [];
$websiteWalkinLeads = [];

foreach ($crmData as $crm) {
    $cSource = strtolower(trim($crm['campaignsource'] ?? ''));
    $cName = strtolower(trim($crm['utm_campaignname'] ?? $crm['campaign_name'] ?? ''));
    $cId = trim($crm['utm_campaignid'] ?? '');
    // Google lead under a campaign that is not in this project → also "Website / Direct" (see pqGoogleCampaignIsWebsite)
    $cGoogle = in_array($cSource, ['google', 'googledg', 'google ads', 'adwords'], true) || trim((string) ($crm['gclid'] ?? '')) !== '';

    if ($cSource === 'website' || $cName === 'website' || ($cId === '' && $cName === '') || ($cGoogle && pqGoogleCampaignIsWebsite($cId, $crm['utm_campaignname'] ?? ''))) {
        $lStatus = strtolower(trim($crm['lead_status'] ?? ''));
        $svStatus = strtolower(trim($crm['sitevisit_status'] ?? ''));
        $svSubStatus = strtolower(trim($crm['sitevisit_sub_status'] ?? ''));
        $lSubStatus = strtolower(trim($crm['lead_sub_status'] ?? ''));

        if (in_array($lStatus, ['qualified', 'hot', 'warm', 'interested', 'lost post qualified', 'lost post qualification'])) {
            $websiteQualifiedCount++;
            $websiteQualifiedLeads[] = $crm;
        }

        if (
            in_array($svStatus, ['visit done', 'visited', 'site visit done', 'site visit', 'walkin', 'walk-in', 'done', 'yes', 'conducted']) ||
            in_array($svSubStatus, ['visit done', 'visited', 'site visit done']) ||
            in_array($lSubStatus, ['visit done', 'visited', 'site visit done'])
        ) {
            $websiteSiteVisitCount++;
            $websiteWalkinLeads[] = $crm;
        }
    }
}

// ===m=== Leads count for Website card ===m===
$websiteLeadsData = [];
$webInQual = 0;
$webLostQual = 0;
$webNonQual = 0;
$webToBeQual = 0;
foreach ($dbLeadsRaw as $lRow) {
    $cSrc = strtolower(trim($lRow['campaignsource'] ?? ''));
    $cName = strtolower(trim($lRow['utm_campaignname'] ?? ''));
    $cId = trim($lRow['utm_campaignid'] ?? '');
    $cGoogle = in_array($cSrc, ['google', 'googledg', 'google ads', 'adwords'], true) || trim((string) ($lRow['gclid'] ?? '')) !== '';

    if ($cSrc === 'website' || $cName === 'website' || ($cId === '' && $cName === '') || ($cGoogle && pqGoogleCampaignIsWebsite($cId, $lRow['utm_campaignname'] ?? ''))) {
        $websiteLeadsData[] = $lRow;
        $st = strtoupper(trim($lRow['lead_status'] ?? ''));
        if ($st === 'QUALIFIED' || in_array(strtolower($st), ['hot', 'warm', 'interested'])) {
            $webInQual++;
        } elseif ($st === 'LOST POST QUALIFIED' || $st === 'LOST POST QUALIFICATION') {
            $webLostQual++;
        } elseif ($st === 'NON-QUALIFIED' || $st === 'NON QUALIFIED') {
            $webNonQual++;
        } elseif ($st === 'TO BE QUALIFIED') {
            $webToBeQual++;
        }
    }
}
// leads = every form entry (people with 2 entries count 2); qualified / site visits above stay one per person
$websiteLeadsCount = (defined('DASHBOARD_LEADS_AS_PEOPLE') && DASHBOARD_LEADS_AS_PEOPLE)
    ? count($websiteLeadsData)
    : (int) array_sum(array_map(fn($r) => max(1, (int) ($r['entries'] ?? 1)), $websiteLeadsData));

if ($websiteLeadsCount > 0 || $websiteQualifiedCount > 0 || $websiteSiteVisitCount > 0) {
    $campaigns[] = [
        'name' => 'Website / Direct',
        'campStatus' => 'ENABLED',
        'platform' => 'Website',
        'spend' => 0,
        'impressions' => 0,
        'clicks' => 0,
        'ctr' => 0,
        'cpm' => 0,
        'frequency' => 0,
        'leads' => $websiteLeadsCount,
        'leads_data' => $websiteLeadsData,
        'cpl' => 0,
        'qualified' => $websiteQualifiedCount,
        'in_qualified' => $webInQual,
        'lost_post_qualified' => $webLostQual,
        'non_qualified' => $webNonQual,
        'to_be_qualified' => $webToBeQual,
        'walkins' => $websiteSiteVisitCount,
        'qualified_leads' => $websiteQualifiedLeads,
        'walkin_leads' => $websiteWalkinLeads,
        'cpql' => 0,
        'cpsv' => 0
    ];
}
// Merge aggregated totals by utm_campaignid into $campaigns
foreach ($totalByCampaign as $tid => $trow) {
    $found = false;
    foreach ($campaigns as &$c) {
        if (isset($c['id']) && (string) $c['id'] === (string) $tid) {
            $c['leads'] = (int) $trow['total_leads'];
            $c['qualified'] = (int) $trow['total_qualified'];
            $c['walkins'] = (int) $trow['total_sitevisit'];
            $found = true;
            break;
        }
    }
    unset($c);
    if (!$found) {
        $campaigns[] = [
            'id' => $tid,
            'name' => 'Campaign ID ' . $tid,
            'campStatus' => '',
            'platform' => 'Database',
            'pm' => $budgetPm[(string) $tid] ?? [],
            'daily_budget' => $budgetPm[(string) $tid]['pm_daily_budget'] ?? null,
            'lifetime_budget' => $budgetPm[(string) $tid]['pm_lifetime_budget'] ?? null,
            'spend' => 0,
            'impressions' => 0,
            'clicks' => 0,
            'ctr' => 0,
            'cpm' => 0,
            'leads' => (int) $trow['total_leads'],
            'leads_data' => [],
            'cpl' => 0,
            'qualified' => (int) $trow['total_qualified'],
            'walkins' => (int) $trow['total_sitevisit'],
            'qualified_leads' => [],
            'walkin_leads' => [],
            'cpql' => 0,
            'cpsv' => 0
        ];
    }
}
// Only this project's saved Google campaigns (campaigns table), with saved names.
// The "Website" row (website leads) comes purely from the lead table and is kept.
[$campaigns, $campaignFilter] = applyProjectCampaignFilter('google', $campaigns, 'id', ['name'],
    fn(array $c): bool => strtolower((string) ($c['platform'] ?? '')) === 'website');

$lastQualDate = null;
$lastQualTimestamp = null;

$lastQualSql = "SELECT MAX(createddate) AS last_date
                FROM `lead`
                WHERE LOWER(TRIM(lead_status)) = 'qualified'
                  AND LOWER(TRIM(campaignsource)) IN ('website', 'google', 'googledg')
                  {$testExclusionSql}";

foreach ($databases as $db) {
    $lastQualRes = $db->query($lastQualSql);
    if ($lastQualRes && ($lqRow = $lastQualRes->fetch_assoc())) {
        $candidate = $lqRow['last_date'] ?? null;
        if ($candidate && ($lastQualTimestamp === null || strtotime($candidate) > strtotime($lastQualTimestamp))) {
            $lastQualTimestamp = $candidate;
        }
    }
}

if ($lastQualTimestamp) {
    $lastQualDate = date('d M Y', strtotime($lastQualTimestamp));
}

// All / Performance / Awareness tab (and Users & Roles → Campaign types): only the campaigns of the view
[$campaigns, $awareness] = pqApplyView('google', $campaigns, 'id', ['name']);

// Lead mobile / email masked here by Users & Roles (stars + last 5 digits; `mobile_export` for the Excel), never in the browser
foreach ($campaigns as &$c_) {
    foreach (['qualified_leads', 'walkin_leads'] as $k_) {
        if (isset($c_[$k_]) && is_array($c_[$k_])) {
            $c_[$k_] = pqContactRows($c_[$k_]);
        }
    }
}
unset($c_);

ob_clean();
echo json_encode([
    'fetched_at' => date('d M Y, h:i A'),
    'date_preset' => 'Google Ads Fetch',
    'api_error' => null,
    'campaigns' => $campaigns,
    'campaign_filter' => $campaignFilter,
    'awareness' => $awareness,
    'last_qualified_date' => $lastQualDate,
    'trend' => []
]);
?>