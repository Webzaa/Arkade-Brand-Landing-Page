<?php
// ob_start();
// ob_clean();
//ini_set('display_errors', '1');
//ini_set('display_startup_errors', '1');
//error_reporting(E_ALL);

require_once dirname(__DIR__, 2) . '/app/Core/db.php';
session_start();
if (($_SESSION['user_logged'] ?? '') !== 'Y') {   // it changes leads — logged-in users only
    http_response_code(401);
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'error' => 'Not logged in']);
    exit;
}
session_write_close();

// Work on ONE lead database at a time: ?db=<LEAD_DATABASES key> (default: APP_DB),
// chosen with the Database picker on the page. Master tables come from MASTER_TABLES_DB.
$pqDbKey = (string) ($_GET['db'] ?? '');
if ($pqDbKey === '' || $pqDbKey === 'all' || !isLeadDbChoice($pqDbKey)) {
    $pqDbKey = appDbKey();
}
$masterConn = leadDb(masterTablesDbKey()) ?? $conn;
$pqSelectedDb = leadDb($pqDbKey);
if (!$pqSelectedDb) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'error' => leadDbLabel($pqDbKey) . ' database is not reachable']);
    exit;
}
$conn = $pqSelectedDb;
header('Content-Type: application/json');

function clearMetaCache()
{
    $cacheDir = CACHE_PATH;
    if (is_dir($cacheDir)) {
        $files = glob($cacheDir . '/meta_*.json');
        if (is_array($files)) {
            foreach ($files as $file) {
                if (is_file($file)) {
                    @unlink($file);
                }
            }
        }
    }
}

$action = $_GET['action'] ?? '';

// Meta (Facebook / Instagram / Facebook Lead Form) leads are identified by campaignsource values
// like fb / ig / facebook lead form — matched case-insensitively.
// Unlike Google, the `lead` table already carries campaign_name / adset_name /
// ad_name / leadgen_id directly (no separate campaigns/adgroups/ads sync table
// for Meta), so the master dropdown lists are built from DISTINCT values that
// already exist on previously-mapped Meta leads.
$metaSourceSQL = "LOWER(TRIM(campaignsource)) IN ('fb','ig','facebook lead form')";

// ===m=== master: campaign/adset/ad names for dropdowns (built from lead table itself) ===m===
if ($action === 'master') {
    $camps = $ags = $ads = [];

    // Dropdowns = this project's saved campaigns / ad sets / ads (master tables, saved names).
    // The name is used as the id, as before, because the lead table stores names.
    require_once dirname(__DIR__, 2) . '/app/Ads/master_tables.php';
    $structure = projectStructure('meta');
    foreach ($structure['campaigns'] as $cid => $cname) {
        $camps[] = ['campaign_id' => $cname, 'campaign_name' => $cname, 'platform' => 'meta'];
    }
    foreach ($structure['adgroups'] as $gid => $g) {
        $ags[] = ['adgroup_id' => $g['name'], 'campaign_id' => $structure['campaigns'][$g['campaign_id']] ?? '', 'adgroup_name' => $g['name'], 'platform' => 'meta'];
    }
    foreach ($structure['ads'] as $aid => $a) {
        $ads[] = ['ad_id' => $a['name'], 'adgroup_id' => $structure['adgroups'][$a['adgroup_id']]['name'] ?? '', 'ad_name' => $a['name'], 'platform' => 'meta'];
    }
    usort($camps, fn($x, $y) => strcasecmp($x['campaign_name'], $y['campaign_name']));
    usort($ags, fn($x, $y) => strcasecmp($x['adgroup_name'], $y['adgroup_name']));
    usort($ads, fn($x, $y) => strcasecmp($x['ad_name'], $y['ad_name']));

    $ls_res = $conn->query("SELECT DISTINCT lead_status
                             FROM `lead`
                             WHERE $metaSourceSQL
                               AND lead_status IS NOT NULL AND TRIM(lead_status) != ''
                             ORDER BY lead_status ASC");
    $statuses = [];
    if ($ls_res) {
        while ($row = $ls_res->fetch_assoc())
            $statuses[] = $row['lead_status'];
    }

    $countQuery = $conn->query("SELECT COUNT(*) as total FROM (
                                    SELECT mobile
                                    FROM `lead`
                                    WHERE (campaign_name IS NULL OR TRIM(campaign_name) = '')
                                      AND (adset_name IS NULL OR TRIM(adset_name) = '')
                                      AND (ad_name IS NULL OR TRIM(ad_name) = '')
                                      AND (leadgen_id IS NULL OR TRIM(leadgen_id) = '')
                                      AND (lead_status IS NULL OR UPPER(TRIM(lead_status)) NOT IN ('TEST', 'JUNK'))
                                      AND (name IS NULL OR LOWER(TRIM(name)) NOT LIKE '%test%')
                                      AND (email IS NULL OR LOWER(TRIM(email)) NOT LIKE '%test%')
                                      AND (mobile IS NULL OR (
                                          LOWER(TRIM(mobile)) NOT LIKE '%test%'
                                          AND TRIM(mobile) NOT IN ('9999999999', '8888888888', '0000000000', '1234567890', '1111111111')
                                      ))
                                      AND $metaSourceSQL
                                    GROUP BY mobile
                                 ) as sub");

    $totalUnmapped = $countQuery ? $countQuery->fetch_assoc()['total'] : 0;

    echo json_encode([
        'campaigns' => $camps,
        'adgroups' => $ags,
        'ads' => $ads,
        'statuses' => $statuses,
        'total_all_time' => $totalUnmapped
    ]);
    exit;
}

// ===m=== unmapped: Meta leads with no campaign_name, fetch leadgen_id + mobile + createddate ===m===
if ($action === 'unmapped') {
    $leads = [];

    $search = !empty($_GET['search']) ? $conn->real_escape_string($_GET['search']) : '';
    $status_filter = !empty($_GET['status']) ? $conn->real_escape_string($_GET['status']) : '';

    $where = "WHERE (campaign_name IS NULL OR TRIM(campaign_name) = '')
              AND (adset_name IS NULL OR TRIM(adset_name) = '')
              AND (ad_name IS NULL OR TRIM(ad_name) = '')
              AND (leadgen_id IS NULL OR TRIM(leadgen_id) = '')
              AND (lead_status IS NULL OR UPPER(TRIM(lead_status)) NOT IN ('TEST','JUNK'))
              AND (name IS NULL OR LOWER(TRIM(name)) NOT LIKE '%test%')
              AND (email IS NULL OR LOWER(TRIM(email)) NOT LIKE '%test%')
              AND (mobile IS NULL OR (
                  LOWER(TRIM(mobile)) NOT LIKE '%test%'
                  AND TRIM(mobile) NOT IN ('9999999999', '8888888888', '0000000000', '1234567890', '1111111111')
              ))
              AND $metaSourceSQL";

    if ($status_filter !== '') {
        $where .= " AND lead_status = '{$status_filter}' ";
    } else {
        $where .= " AND (lead_status IS NULL OR UPPER(TRIM(lead_status)) NOT IN ('TEST','JUNK')) ";
    }

    if ($search !== '') {
        $where .= " AND (mobile LIKE '{$search}%' OR leadgen_id = '{$search}')";
        $start_datetime = '';
        $end_datetime = '';
    } else {
        $start_date = !empty($_GET['start'])
            ? $conn->real_escape_string($_GET['start'])
            : date('Y-m-d', strtotime('-30 days'));

        $end_date = !empty($_GET['end'])
            ? $conn->real_escape_string($_GET['end'])
            : date('Y-m-d');

        $start_datetime = $start_date . " 00:00:00";
        $end_datetime = $end_date . " 23:59:59";

        $where .= "
            AND createddate >= '{$start_datetime}'
            AND createddate <= '{$end_datetime}'
        ";
    }

    $sql = "SELECT l.mobile, l.leadgen_id, l.createddate, l.campaignsource
            FROM `lead` l
            INNER JOIN (
                SELECT mobile, campaignsource, MAX(createddate) AS latest_created
                FROM `lead` $where
                GROUP BY mobile, campaignsource
            ) x ON l.mobile = x.mobile AND l.campaignsource = x.campaignsource AND l.createddate = x.latest_created
            ORDER BY l.createddate DESC LIMIT 1000";

    $r = $conn->query($sql);

    if (!$r) {
        echo json_encode([
            'success' => false,
            'error' => 'Could not load the leads.'
        ]);
        error_log('[unmapped_meta_api] ' . $conn->error);
        exit;
    }

    while ($row = $r->fetch_assoc()) {
        $leads[] = $row;
    }

    echo json_encode([
        'success' => true,
        'leads' => pqLeadRowsForBrowser($leads),   // mobile masked by Users & Roles; `ref` is the row key
        'count' => count($leads),
        'start' => $start_datetime,
        'end' => $end_datetime
    ]);

    exit;
}

// ===m=== update status: mark as test or junk ===m===
if ($action === 'update_status' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    $mobile = $conn->real_escape_string(pqLeadMobile($input['mobile'] ?? ''));
    $status = $conn->real_escape_string($input['status'] ?? '');

    if (!$mobile || !in_array($status, ['TEST', 'JUNK'])) {
        echo json_encode(['error' => 'Invalid input']);
        exit;
    }

    $result = $conn->query("UPDATE `lead` SET lead_status = '$status' WHERE mobile = '$mobile' AND $metaSourceSQL");
    if (!$result) {
        echo json_encode(['error' => $conn->error]);
        exit;
    }

    clearMetaCache();

    echo json_encode(['success' => true, 'affected' => $conn->affected_rows]);
    exit;
}

// ===m=== save: update single lead mapping ===m===
if ($action === 'save' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    if (!$input) {
        echo json_encode(['error' => 'Invalid input']);
        exit;
    }

    $unique_id = $conn->real_escape_string($input['unique_id'] ?? $input['mobile'] ?? '');
    $leadgen_id = $conn->real_escape_string($input['leadgen_id'] ?? '');
    $campaign_name = $conn->real_escape_string($input['campaign_name'] ?? '');
    $adset_name = $conn->real_escape_string($input['adgroup_name'] ?? '');
    $ad_name = $conn->real_escape_string($input['ad_name'] ?? '');

    $setParts = [
        "campaign_name = '$campaign_name'",
        "adset_name    = '$adset_name'",
        "ad_name       = '$ad_name'"
    ];
    if ($leadgen_id !== '') {
        $setParts[] = "leadgen_id = '$leadgen_id'";
    }

    $sql = "UPDATE `lead` SET " . implode(', ', $setParts) . "
                             WHERE (leadgen_id = '$unique_id' OR mobile = '$unique_id')
                               AND $metaSourceSQL
                               AND (campaign_name IS NULL OR campaign_name = '')";
    $result = $conn->query($sql);

    // Logging for debugging
    $logData = date('[Y-m-d H:i:s] ') . "SAVE ACTION:\n"
        . "  Payload: " . json_encode($input) . "\n"
        . "  SQL: $sql\n"
        . "  Result: " . ($result ? "Success" : "Failed: " . $conn->error) . "\n"
        . "  Affected Rows: " . $conn->affected_rows . "\n\n";
    @file_put_contents(LOG_PATH . '/unmapped_meta_debug.log', $logData, FILE_APPEND);

    if (!$result) {
        echo json_encode(['error' => $conn->error]);
        exit;
    }

    clearMetaCache();

    echo json_encode(['success' => true, 'affected' => $conn->affected_rows]);
    exit;
}

// ===m=== import: batch CSV update ===m===
if ($action === 'import' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    $rows = $input['rows'] ?? [];

    if (empty($rows)) {
        echo json_encode(['error' => 'No rows provided']);
        exit;
    }

    $success = $failed = 0;
    foreach ($rows as $row) {
        $leadgen_id = $conn->real_escape_string(trim($row['leadgen_id'] ?? $row['gclid'] ?? ''));
        $mobile = $conn->real_escape_string(trim($row['mobile'] ?? ''));
        $campaign_name = $conn->real_escape_string(trim($row['campaign_name'] ?? ''));

        if ((!$leadgen_id && !$mobile) || !$campaign_name) {
            $failed++;
            continue;
        }

        $adset_name = $conn->real_escape_string(trim($row['adgroup_name'] ?? $row['adset_name'] ?? ''));
        $ad_name = $conn->real_escape_string(trim($row['ad_name'] ?? ''));

        $setParts = [
            "campaign_name = '$campaign_name'",
            "adset_name    = '$adset_name'",
            "ad_name       = '$ad_name'"
        ];
        if ($leadgen_id !== '') {
            $setParts[] = "leadgen_id = '$leadgen_id'";
        }

        $whereClause = [];
        if ($leadgen_id)
            $whereClause[] = "leadgen_id = '$leadgen_id'";
        if ($mobile)
            $whereClause[] = "mobile = '$mobile'";
        $where = implode(' OR ', $whereClause);

        $result = $conn->query("UPDATE `lead` SET " . implode(', ', $setParts) . "
                                 WHERE ($where) AND (campaign_name IS NULL OR campaign_name = '')");
        $result ? $success++ : $failed++;
    }

    clearMetaCache();

    echo json_encode(['success' => true, 'updated' => $success, 'failed' => $failed]);
    exit;
}

echo json_encode(['error' => 'Unknown action']);
