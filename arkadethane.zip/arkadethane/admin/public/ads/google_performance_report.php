<?php

declare(strict_types=1);

/**
 * Google Ads performance report: daily / weekly / monthly comparisons.
 *
 *   GET google_performance_report.php?period=daily|weekly|monthly[&as_of=YYYY-MM-DD][&debug=1]
 *
 *   daily   : yesterday vs the day before
 *   weekly  : last full Mon–Sun week vs the week before
 *   monthly : last full calendar month vs the month before
 *
 * Spend / impressions / clicks come from the Google Ads API (campaign level, daily rows).
 * Leads / qualified / site visits come from the CRM `lead` table in both databases
 * (every database in LEAD_DATABASES), filtered to Google sources, de-duplicated across the
 * two databases, counted by lead created date, and matched to Google campaigns by
 * UTM campaign ID (falling back to UTM campaign name).
 *
 * Returns the same JSON shape as meta_performance_report.php, so performance_reports.js
 * renders both.
 */

date_default_timezone_set('Asia/Kolkata');

header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');
header('Cache-Control: no-store, max-age=0');

/** Set to false once everything works; ?debug=1 then stops exposing error details. */
const GPERF_DEBUG_ALLOWED = true;

/** lead_status values that count as a Qualified Lead (compared upper-cased and trimmed). */
const GPERF_QUALIFIED_STATUSES = ['QUALIFIED', 'IN-QUALIFIED', 'LOST POST QUALIFIED', 'LOST POST QUALIFICATION'];

/** sitevisit_status values that count as a Site Visit (compared upper-cased and trimmed). */
const GPERF_SITE_VISIT_STATUSES = ['VISITED', 'VISIT DONE', 'SITE VISIT DONE'];

/** Google Ads API version used when config.php does not define GOOGLE_ADS_API_VERSION. */
const GPERF_DEFAULT_API_VERSION = 'v24';

/**
 * "Select campaigns" (?campaigns=ID,ID…, js/report_picker.js): narrows the project's campaigns to the chosen ones,
 * so spend and leads of every other campaign are left out like another project's. Returns {names} or null (= all).
 */
function gperfOnlyCampaigns(array &$master): ?array
{
    $raw = trim((string) ($_GET['campaigns'] ?? ''));
    // All / Performance / Awareness tab (cookie pq_view) + Users & Roles → Campaign types (cron / emails: every campaign)
    $view = PHP_SAPI === 'cli' || !function_exists('pqCampaignView') ? 'all' : pqCampaignView();
    if (($raw === '' && $view === 'all') || PHP_SAPI === 'cli') {
        return null;
    }
    $keep = [];
    if ($raw === '') {
        $keep = array_fill_keys(array_map('strval', array_keys($master['campaigns'])), true);
    } else {
        foreach (array_slice(explode(',', $raw), 0, 500) as $id) {
            $id = trim($id);
            if ($id !== '' && isset($master['campaigns'][$id])) {
                $keep[$id] = true;
            }
        }
        if (!$keep) {
            throw new InvalidArgumentException('None of the chosen campaigns is saved for this project any more. Choose again.');
        }
    }
    if ($view !== 'all') {
        $keep = array_filter($keep, fn($v, $id) => pqViewShows(pqCampaignType('google', (string) $id), $view), ARRAY_FILTER_USE_BOTH);
        if (!$keep) {
            throw new InvalidArgumentException('There are no ' . $view . ' campaigns' . ($raw !== '' ? ' among the chosen ones' : '') . ' — switch the tab to All, or choose other campaigns.');
        }
    }
    $master['campaigns'] = array_intersect_key($master['campaigns'], $keep);
    foreach (['name_to_campaign', 'ad_to_campaign'] as $k) {
        if (isset($master[$k])) {
            $master[$k] = array_filter($master[$k], fn($cid) => isset($keep[(string) $cid]));
        }
    }
    return ['names' => array_values(array_map('strval', $master['campaigns'])), 'view' => $view, 'all_campaigns' => $raw === ''];
}

function gperfJson(array $payload, int $status = 200): never
{
    // Users & Roles → "Hide numbers": a logged-in user's report leaves out what their role hides (cron / emails: unchanged)
    if (PHP_SAPI !== 'cli' && function_exists('pqStripHiddenMetrics')) {   // no admin session / Super Admin → nothing hidden
        $payload = pqStripHiddenMetrics($payload);
    }
    http_response_code($status);
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PARTIAL_OUTPUT_ON_ERROR);
    exit;
}

// Login check: dashboard users, OTP-verified report links (report_view.php),
// or the cron runner on the command line (send_performance_reports.php).
require_once dirname(__DIR__, 2) . '/app/Reports/report_access.php';
reportBootstrap('google');

$debugMode = PHP_SAPI === 'cli' || (GPERF_DEBUG_ALLOWED && (($_GET['debug'] ?? '') === '1'));

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

try {
    require_once dirname(__DIR__, 2) . '/app/Core/db.php';
    require_once dirname(__DIR__, 2) . '/app/Ads/master_tables.php';   // campaign types (All / Performance / Awareness)
} catch (Throwable $e) {
    error_log('[Google Performance Report] config.php failed: ' . $e->getMessage());
    gperfJson([
        'success' => false,
        'error' => 'Configuration could not be loaded.',
        'debug' => $debugMode ? ['message' => $e->getMessage()] : null,
    ], 500);
}

// Users & Roles: a signed-in user needs the Reports permission (report links with OTP and cron are not affected)
if (PHP_SAPI !== 'cli' && ($_SESSION['user_logged'] ?? '') === 'Y' && function_exists('pqCan') && !pqCan('reports')) {
    gperfJson(['success' => false, 'error' => "Your role doesn't include Reports. Ask a Super Admin for access.", 'no_access' => true], 403);
}
$dbConnections = leadDbs('all');   // every database in LEAD_DATABASES
if (!$dbConnections) {
    gperfJson(['success' => false, 'error' => 'No CRM database connection is available.'], 500);
}

/* ======================================================================
 * Helpers
 * ====================================================================== */

function gperfResolvePeriods(string $period, DateTimeImmutable $today): array
{
    switch ($period) {
        case 'daily':
            $curStart = $today->modify('-1 day');
            $curEnd = $curStart;
            $prevStart = $today->modify('-2 days');
            $prevEnd = $prevStart;
            $label = static fn(DateTimeImmutable $s, DateTimeImmutable $e): string => $s->format('d M Y');
            break;

        case 'weekly':
            $thisMonday = $today->modify('monday this week');
            $curStart = $thisMonday->modify('-7 days');
            $curEnd = $thisMonday->modify('-1 day');
            $prevStart = $thisMonday->modify('-14 days');
            $prevEnd = $thisMonday->modify('-8 days');
            $label = static fn(DateTimeImmutable $s, DateTimeImmutable $e): string =>
                $s->format('Y') === $e->format('Y')
                ? $s->format('d M') . ' – ' . $e->format('d M Y')
                : $s->format('d M Y') . ' – ' . $e->format('d M Y');
            break;

        case 'monthly':
            $firstOfThisMonth = $today->modify('first day of this month');
            $curStart = $firstOfThisMonth->modify('-1 month');
            $curEnd = $firstOfThisMonth->modify('-1 day');
            $prevStart = $firstOfThisMonth->modify('-2 months');
            $prevEnd = $curStart->modify('-1 day');
            $label = static fn(DateTimeImmutable $s, DateTimeImmutable $e): string => $s->format('F Y');
            break;

        default:
            throw new InvalidArgumentException('period must be daily, weekly or monthly.');
    }

    $build = static fn(DateTimeImmutable $s, DateTimeImmutable $e): array => [
        'since' => $s->format('Y-m-d'),
        'until' => $e->format('Y-m-d'),
        'label' => $label($s, $e),
        'days' => $s->diff($e)->days + 1,
    ];

    return [
        'current' => $build($curStart, $curEnd),
        'previous' => $build($prevStart, $prevEnd),
    ];
}

function gperfNormaliseName(string $name): string
{
    $name = html_entity_decode(rawurldecode(trim($name)), ENT_QUOTES | ENT_HTML5, 'UTF-8');
    $name = function_exists('mb_strtolower') ? mb_strtolower($name, 'UTF-8') : strtolower($name);
    $name = preg_replace('/[^\p{L}\p{N}]+/u', ' ', $name) ?? $name;
    return trim(preg_replace('/\s+/u', ' ', $name) ?? $name);
}

function gperfEmptyMetrics(): array
{
    return ['spend' => 0.0, 'impressions' => 0, 'clicks' => 0, 'leads' => 0, 'qualified' => 0, 'site_visits' => 0];
}

function gperfDerive(array $m): array
{
    $ratio = static fn(float $a, float $b, float $mul = 1.0): ?float => $b > 0 ? round($a / $b * $mul, 2) : null;

    $spend = (float) $m['spend'];
    $m['ctr'] = $ratio((float) $m['clicks'], (float) $m['impressions'], 100);
    $m['cpc'] = $ratio($spend, (float) $m['clicks']);
    $m['cpm'] = $ratio($spend, (float) $m['impressions'], 1000);
    $m['cpl'] = $ratio($spend, (float) $m['leads']);
    $m['cpql'] = $ratio($spend, (float) $m['qualified']);
    $m['cpsv'] = $ratio($spend, (float) $m['site_visits']);
    $m['qualified_rate'] = $ratio((float) $m['qualified'], (float) $m['leads'], 100);
    $m['site_visit_rate'] = $ratio((float) $m['site_visits'], (float) $m['qualified'], 100);
    $m['spend'] = round($spend, 2);
    return $m;
}

function gperfChanges(array $cur, array $prev): array
{
    $keys = [
        'spend',
        'impressions',
        'clicks',
        'ctr',
        'cpc',
        'cpm',
        'leads',
        'cpl',
        'qualified',
        'cpql',
        'site_visits',
        'cpsv',
        'qualified_rate',
        'site_visit_rate'
    ];
    $out = [];
    foreach ($keys as $k) {
        $c = $cur[$k] ?? null;
        $p = $prev[$k] ?? null;
        if ($c === null || $p === null) {
            $out[$k] = null;
        } elseif ((float) $p == 0.0) {
            $out[$k] = ((float) $c == 0.0) ? 0.0 : null;
        } else {
            $out[$k] = round((((float) $c - (float) $p) / abs((float) $p)) * 100, 2);
        }
    }
    return $out;
}

/** POST helper for the OAuth and Google Ads endpoints. */
function gperfHttpPost(string $url, array $headers, string $body, int $timeout = 60): array
{
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $body,
        CURLOPT_HTTPHEADER => $headers,
        CURLOPT_CONNECTTIMEOUT => 10,
        CURLOPT_TIMEOUT => $timeout,
    ]);
    $response = curl_exec($ch);
    $curlError = curl_error($ch);
    $status = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
    unset($ch);

    if ($response === false) {
        throw new RuntimeException('HTTP request failed: ' . $curlError);
    }
    $json = json_decode((string) $response, true);
    if (!is_array($json)) {
        throw new RuntimeException('Invalid JSON response (HTTP ' . $status . ').');
    }
    if ($status < 200 || $status >= 300) {
        $message = $json['error']['message']
            ?? $json[0]['error']['message']
            ?? $json['error_description']
            ?? (is_string($json['error'] ?? null) ? $json['error'] : null)
            ?? 'Unknown API error';
        throw new RuntimeException('API request failed (HTTP ' . $status . '): ' . $message);
    }
    return $json;
}

/** First column (from candidates) that exists in the table, using the table's own spelling. */
function gperfFindColumn(array $available, array $candidates): ?string
{
    $byLower = [];
    foreach ($available as $col) {
        $byLower[strtolower($col)] = $col;
    }
    foreach ($candidates as $candidate) {
        if (isset($byLower[strtolower($candidate)])) {
            return $byLower[strtolower($candidate)];
        }
    }
    return null;
}

/**
 * Google campaigns from the `campaigns` master table (platform = 'google'), from the database chosen
 * by MASTER_TABLES_DB (default: first database that has the table). Returns null when there are none,
 * in which case the report is not filtered.
 *
 * @return array{campaigns: array<string,string>, name_to_campaign: array<string,string>, db: string}|null
 */
function gperfLoadMaster(array $dbConnections): ?array
{
    $order = array_keys($dbConnections);
    if (defined('MASTER_TABLES_DB') && isset($dbConnections[(string) MASTER_TABLES_DB])) {
        $order = [(string) MASTER_TABLES_DB];
    }
    foreach ($order as $dbName) {
        $db = $dbConnections[$dbName];
        try {
            $res = $db->query("SHOW TABLES LIKE 'campaigns'");
            $has = $res->num_rows > 0;
            $res->free();
            if (!$has) {
                continue;
            }
            $campaigns = [];
            $nameTo = [];
            $res = $db->query("SELECT TRIM(campaign_id), campaign_name FROM `campaigns` WHERE LOWER(platform) = 'google' AND TRIM(campaign_id) <> ''");
            while ($row = $res->fetch_row()) {
                $id = (string) (preg_replace('/\D+/', '', (string) $row[0]) ?? '');
                if ($id === '') {
                    continue;
                }
                $campaigns[$id] = (string) $row[1];
                $n = gperfNormaliseName((string) $row[1]);
                if ($n !== '') {
                    $nameTo[$n] = $id;
                }
            }
            $res->free();
            if ($campaigns) {
                return ['campaigns' => $campaigns, 'name_to_campaign' => $nameTo, 'db' => $dbName];
            }
        } catch (Throwable $e) {
            error_log('[Google Performance Report] master tables in ' . $dbName . ': ' . $e->getMessage());
        }
    }
    return null;
}

function gperfQuoteIdent(string $col): string
{
    return '`' . str_replace('`', '``', $col) . '`';
}

/* ======================================================================
 * Main
 * ====================================================================== */

$warnings = [];

try {
    $tz = new DateTimeZone('Asia/Kolkata');

    $period = strtolower(trim((string) ($_GET['period'] ?? 'daily')));
    if (!in_array($period, ['daily', 'weekly', 'monthly'], true)) {
        throw new InvalidArgumentException('period must be daily, weekly or monthly.');
    }

    $today = new DateTimeImmutable('today', $tz);
    if (!empty($_GET['as_of'])) {
        $raw = (string) $_GET['as_of'];
        $parsed = DateTimeImmutable::createFromFormat('!Y-m-d', $raw, $tz);
        if (!$parsed || $parsed->format('Y-m-d') !== $raw) {
            throw new InvalidArgumentException('as_of must be a date in YYYY-MM-DD format.');
        }
        if ($parsed > $today) {
            throw new InvalidArgumentException('as_of cannot be in the future.');
        }
        $today = $parsed;
    }

    $periods = gperfResolvePeriods($period, $today);

    // ?month=YYYY-MM (monthly only): report that calendar month — the current month runs to today —
    // against the full month before it. Used by the "this month to date" deck.
    if ($period === 'monthly' && !empty($_GET['month'])) {
        $rawMonth = (string) $_GET['month'];
        $m0 = DateTimeImmutable::createFromFormat('!Y-m-d', $rawMonth . '-01', $tz);
        if (!$m0 || $m0->format('Y-m') !== $rawMonth) {
            throw new InvalidArgumentException('month must be in YYYY-MM format.');
        }
        $realToday = new DateTimeImmutable('today', $tz);
        if ($m0 > $realToday) {
            throw new InvalidArgumentException('month cannot be in the future.');
        }
        $mEnd = $m0->modify('last day of this month');
        $partial = $mEnd > $realToday;
        $mEnd = $partial ? $realToday : $mEnd;
        $pStart = $m0->modify('-1 month');
        $pEnd = $m0->modify('-1 day');
        $periods = [
            'current' => ['since' => $m0->format('Y-m-d'), 'until' => $mEnd->format('Y-m-d'),
                          'label' => $m0->format('F Y') . ($partial ? ' (to ' . $mEnd->format('j M') . ')' : ''),
                          'days' => $m0->diff($mEnd)->days + 1],
            'previous' => ['since' => $pStart->format('Y-m-d'), 'until' => $pEnd->format('Y-m-d'),
                           'label' => $pStart->format('F Y'), 'days' => $pStart->diff($pEnd)->days + 1],
        ];
    }
    $rangeSince = $periods['previous']['since'];
    $rangeUntil = $periods['current']['until'];

    $bucketOf = static function (string $date) use ($periods): ?string {
        foreach (['current', 'previous'] as $b) {
            if ($date >= $periods[$b]['since'] && $date <= $periods[$b]['until']) {
                return $b;
            }
        }
        return null;
    };

    /* ---------- Google Ads configuration ---------- */
    foreach (['GOOGLE_DEVELOPER_TOKEN', 'GOOGLE_CLIENT_ID', 'GOOGLE_CLIENT_SECRET', 'GOOGLE_REFRESH_TOKEN'] as $constant) {
        if (!defined($constant) || trim((string) constant($constant)) === '') {
            throw new RuntimeException('Missing Google Ads configuration constant in config.php: ' . $constant);
        }
    }
    if (defined('GOOGLE_CUSTOMER_IDS') && is_array(GOOGLE_CUSTOMER_IDS)) {
        $customerIds = GOOGLE_CUSTOMER_IDS;
    } elseif (defined('GOOGLE_CUSTOMER_ID')) {
        $customerIds = [GOOGLE_CUSTOMER_ID];
    } else {
        throw new RuntimeException('GOOGLE_CUSTOMER_ID is not configured in config.php.');
    }
    $customerIds = array_values(array_unique(array_filter(array_map(
        static fn($id): string => (string) preg_replace('/\D+/', '', (string) $id),
        $customerIds
    ), static fn(string $id): bool => $id !== '')));
    if (!$customerIds) {
        throw new RuntimeException('Google Ads customer ID is invalid.');
    }
    if (!function_exists('curl_init')) {
        throw new RuntimeException('PHP cURL extension is required for Google Ads API requests.');
    }
    $apiVersion = defined('GOOGLE_ADS_API_VERSION') && trim((string) GOOGLE_ADS_API_VERSION) !== ''
        ? trim((string) GOOGLE_ADS_API_VERSION)
        : GPERF_DEFAULT_API_VERSION;
    if ($apiVersion[0] !== 'v') {
        $apiVersion = 'v' . $apiVersion;
    }
    $loginCustomerId = defined('GOOGLE_LOGIN_CUSTOMER_ID')
        ? (string) preg_replace('/\D+/', '', (string) GOOGLE_LOGIN_CUSTOMER_ID)
        : '';

    /* ---------- Containers ---------- */
    $totals = ['current' => gperfEmptyMetrics(), 'previous' => gperfEmptyMetrics()];
    $campaigns = [];      // keyed by Google campaign ID
    $nameIndex = [];      // normalised campaign name => campaign ID
    $unmatched = [];
    $unattributed = [
        'current' => ['leads' => 0, 'qualified' => 0, 'site_visits' => 0],
        'previous' => ['leads' => 0, 'qualified' => 0, 'site_visits' => 0],
    ];

    $series = [];
    $cursor = new DateTimeImmutable($rangeSince, $tz);
    $last = new DateTimeImmutable($rangeUntil, $tz);
    while ($cursor <= $last) {
        $ds = $cursor->format('Y-m-d');
        $series[$ds] = ['date' => $ds, 'label' => $cursor->format('d M'), 'bucket' => $bucketOf($ds)] + gperfEmptyMetrics();
        $cursor = $cursor->modify('+1 day');
    }

    /* ---------- 1. Google Ads spend / impressions / clicks ---------- */
    $token = gperfHttpPost('https://oauth2.googleapis.com/token', ['Content-Type: application/x-www-form-urlencoded'], http_build_query([
        'client_id' => GOOGLE_CLIENT_ID,
        'client_secret' => GOOGLE_CLIENT_SECRET,
        'refresh_token' => GOOGLE_REFRESH_TOKEN,
        'grant_type' => 'refresh_token',
    ]), 30);
    if (empty($token['access_token'])) {
        throw new RuntimeException('Google OAuth did not return an access token.');
    }

    $headers = [
        'Authorization: Bearer ' . (string) $token['access_token'],
        'developer-token: ' . (string) GOOGLE_DEVELOPER_TOKEN,
        'Content-Type: application/json',
        'Accept: application/json',
    ];
    if ($loginCustomerId !== '') {
        $headers[] = 'login-customer-id: ' . $loginCustomerId;
    }

    // Dates are generated above (never user text), so they are safe inside GAQL.
    $gaql = "SELECT campaign.id, campaign.name, segments.date, metrics.cost_micros, metrics.clicks, metrics.impressions "
        . "FROM campaign WHERE segments.date BETWEEN '{$rangeSince}' AND '{$rangeUntil}'";

    $adsErrors = [];
    $adsRowsReceived = 0;

    // Only campaigns saved for this project (campaigns table, platform = 'google') — none saved means none reported.
    $master = gperfLoadMaster($dbConnections);
    if (!$master) {
        $master = ['campaigns' => [], 'name_to_campaign' => [], 'db' => null];
        $warnings[] = 'No Google campaigns are linked to this project yet. Open the Google dashboard → ⟳ Sync with Google.';
    }
    // "Select campaigns" before the download (?campaigns=ID,ID — js/report_picker.js): only those campaigns
    $selection = gperfOnlyCampaigns($master);
    $excludedCampaigns = [];
    $excludedLeads = [];

    foreach ($customerIds as $customerId) {
        try {
            $apiUrl = 'https://googleads.googleapis.com/' . rawurlencode($apiVersion)
                . '/customers/' . rawurlencode($customerId) . '/googleAds:searchStream';
            $response = gperfHttpPost($apiUrl, $headers, json_encode(['query' => $gaql], JSON_UNESCAPED_SLASHES) ?: '{}', 90);

            foreach ($response as $batch) {
                foreach (($batch['results'] ?? []) as $row) {
                    $c = $row['campaign'] ?? [];
                    $date = (string) ($row['segments']['date'] ?? '');
                    $id = (string) ($c['id'] ?? '');
                    $b = $bucketOf($date);
                    if ($id === '' || $b === null) {
                        continue;
                    }
                    $adsRowsReceived++;

                    $name = trim((string) ($c['name'] ?? ('Campaign ' . $id)));
                    if (isset($master['campaigns'][$id]) && $master['campaigns'][$id] !== '') {
                        $name = $master['campaigns'][$id];   // saved (database) name
                    }
                    if ($master && !isset($master['campaigns'][$id])) {
                        $excludedCampaigns[$name] = round(($excludedCampaigns[$name] ?? 0) + ((float) ($row['metrics']['costMicros'] ?? 0)) / 1000000, 2);
                        continue;
                    }
                    if (!isset($campaigns[$id])) {
                        $campaigns[$id] = [
                            'campaign_id' => $id,
                            'campaign_name' => $name,
                            'current' => gperfEmptyMetrics(),
                            'previous' => gperfEmptyMetrics(),
                        ];
                        $nameIndex[gperfNormaliseName($name)] = $id;
                    }

                    $vals = [
                        'spend' => ((float) ($row['metrics']['costMicros'] ?? 0)) / 1000000,
                        'impressions' => (int) ($row['metrics']['impressions'] ?? 0),
                        'clicks' => (int) ($row['metrics']['clicks'] ?? 0),
                    ];
                    foreach ($vals as $f => $v) {
                        $campaigns[$id][$b][$f] += $v;
                        $totals[$b][$f] += $v;
                        if (isset($series[$date])) {
                            $series[$date][$f] += $v;
                        }
                    }
                }
            }
        } catch (Throwable $e) {
            $adsErrors[$customerId] = $e->getMessage();
            error_log('[Google Performance Report] Google Ads customer ' . $customerId . ': ' . $e->getMessage());
        }
    }

    if (count($adsErrors) === count($customerIds)) {
        throw new RuntimeException('Google Ads API failed for all customer IDs. First error: ' . reset($adsErrors));
    }
    if ($adsErrors) {
        $warnings[] = 'Google Ads spend is incomplete: ' . count($adsErrors) . ' customer ID(s) failed.';
    }

    /* ---------- 2. CRM leads from both databases (de-duplicated) ---------- */
    $qualifiedSet = array_fill_keys(GPERF_QUALIFIED_STATUSES, true);
    $siteVisitSet = array_fill_keys(GPERF_SITE_VISIT_STATUSES, true);
    $testMobiles = ['9999999999', '8888888888', '0000000000', '1234567890', '1111111111'];

    $leads = [];          // identity => lead
    $dbErrors = [];
    $dbStats = [];

    $startSql = $rangeSince . ' 00:00:00';
    $endSql = (new DateTimeImmutable($rangeUntil, $tz))->modify('+1 day')->format('Y-m-d') . ' 00:00:00';

    foreach ($dbConnections as $dbName => $db) {
        try {
            $available = [];
            $colsRes = $db->query('SHOW COLUMNS FROM `lead`');
            while ($col = $colsRes->fetch_assoc()) {
                $available[] = (string) $col['Field'];
            }
            $colsRes->free();

            $cols = [
                'lead_id' => gperfFindColumn($available, ['id', 'lead_id']),
                'lead_date' => gperfFindColumn($available, ['createddate', 'created_at', 'created_date']),
                'mobile' => gperfFindColumn($available, ['mobile', 'phone', 'phone_number']),
                'email' => gperfFindColumn($available, ['email', 'email_id']),
                'lead_name' => gperfFindColumn($available, ['name', 'full_name', 'lead_name']),
                'source' => gperfFindColumn($available, ['campaignsource', 'campaign_source', 'source', 'lead_source']),
                'utm_campaign_id' => gperfFindColumn($available, ['utm_campaign_id', 'utm_campaignid', 'utmcampaignid']),
                'utm_campaignname' => gperfFindColumn($available, ['utm_campaignname', 'utm_campaign_name', 'utm_campaign']),
                'campaign_name' => gperfFindColumn($available, ['campaign_name', 'campaignname']),
                'leadgen_id' => gperfFindColumn($available, ['leadgen_id', 'leadgenid', 'unique_id', 'uniqueid']),
                'lead_status' => gperfFindColumn($available, ['lead_status', 'status']),
                'sitevisit_status' => gperfFindColumn($available, ['sitevisit_status', 'site_visit_status']),
                'duplicate' => gperfFindColumn($available, ['duplicate', 'is_duplicate']),
            ];

            if (!$cols['lead_date']) {
                throw new RuntimeException('No created-date column found in the lead table.');
            }
            if (!$cols['source'] && !$cols['utm_campaign_id'] && !$cols['utm_campaignname']) {
                throw new RuntimeException('No source or UTM campaign column found in the lead table.');
            }

            $select = [];
            foreach ($cols as $alias => $col) {
                if ($col !== null) {
                    $select[] = gperfQuoteIdent($col) . ' AS `' . $alias . '`';
                }
            }

            $dateSql = gperfQuoteIdent($cols['lead_date']);
            $where = [
                "{$dateSql} >= '" . $db->real_escape_string($startSql) . "'",
                "{$dateSql} < '" . $db->real_escape_string($endSql) . "'",
            ];
            if ($cols['source']) {
                $where[] = 'LOWER(TRIM(COALESCE(' . gperfQuoteIdent($cols['source']) . ", ''))) LIKE '%google%'";
            } else {
                $evidence = [];
                foreach (['utm_campaign_id', 'utm_campaignname'] as $k) {
                    if ($cols[$k]) {
                        $evidence[] = 'COALESCE(' . gperfQuoteIdent($cols[$k]) . ", '') <> ''";
                    }
                }
                $where[] = '(' . implode(' OR ', $evidence) . ')';
            }
            if ($cols['lead_status']) {
                $where[] = 'LOWER(TRIM(COALESCE(' . gperfQuoteIdent($cols['lead_status']) . ", ''))) NOT IN ('test', 'junk', 'invalid')";
            }
            if ($cols['duplicate']) {
                $where[] = 'LOWER(TRIM(COALESCE(' . gperfQuoteIdent($cols['duplicate']) . ", ''))) NOT IN ('yes', '1', 'true', 'duplicate')";
            }

            $sql = 'SELECT ' . implode(', ', $select) . ' FROM `lead` WHERE ' . implode(' AND ', $where);
            $res = $db->query($sql);

            $read = 0;
            while ($row = $res->fetch_assoc()) {
                $read++;
                $date = substr((string) ($row['lead_date'] ?? ''), 0, 10);
                if ($bucketOf($date) === null) {
                    continue;
                }

                $name = strtolower(trim((string) ($row['lead_name'] ?? '')));
                $email = strtolower(trim((string) ($row['email'] ?? '')));
                $mobile = (string) (preg_replace('/\D+/', '', (string) ($row['mobile'] ?? '')) ?? '');
                $mobile10 = substr($mobile, -10);
                if (
                    ($name !== '' && str_contains($name, 'test'))
                    || ($email !== '' && str_contains($email, 'test'))
                    || ($mobile10 !== '' && in_array($mobile10, $testMobiles, true))
                ) {
                    continue;
                }

                $leadgen = trim((string) ($row['leadgen_id'] ?? ''));
                $id = trim((string) ($row['lead_id'] ?? ''));
                if ($leadgen !== '') {
                    $identity = 'leadgen:' . $leadgen;
                } elseif ($mobile10 !== '') {
                    $identity = 'mobile:' . $mobile10;
                } elseif ($email !== '') {
                    $identity = 'email:' . $email;
                } else {
                    $identity = $dbName . ':id:' . ($id !== '' ? $id : md5(json_encode($row) ?: uniqid('', true)));
                }

                $utmId = (string) (preg_replace('/\D+/', '', (string) ($row['utm_campaign_id'] ?? '')) ?? '');
                $utmName = trim((string) ($row['utm_campaignname'] ?? ''));
                if ($utmName === '') {
                    $utmName = trim((string) ($row['campaign_name'] ?? ''));
                }
                $isQualified = isset($qualifiedSet[strtoupper(trim((string) ($row['lead_status'] ?? '')))]);
                $isSiteVisit = isset($siteVisitSet[strtoupper(trim((string) ($row['sitevisit_status'] ?? '')))]);

                if (!isset($leads[$identity])) {
                    $leads[$identity] = [
                        'date' => $date,
                        'utm_id' => $utmId,
                        'utm_name' => $utmName,
                        'qualified' => $isQualified,
                        'site_visit' => $isSiteVisit,
                    ];
                } else {
                    // Same lead in both databases: keep the earliest date, fill in a missing
                    // campaign ID/name, and count it as qualified / visited if either copy says so.
                    $l = &$leads[$identity];
                    if ($date < $l['date']) {
                        $l['date'] = $date;
                    }
                    if ($l['utm_id'] === '' && $utmId !== '') {
                        $l['utm_id'] = $utmId;
                    }
                    if ($l['utm_name'] === '' && $utmName !== '') {
                        $l['utm_name'] = $utmName;
                    }
                    $l['qualified'] = $l['qualified'] || $isQualified;
                    $l['site_visit'] = $l['site_visit'] || $isSiteVisit;
                    unset($l);
                }
            }
            $res->free();

            $dbStats[$dbName] = [
                'rows_read' => $read,
                'source_column' => $cols['source'],
                'utm_campaign_id_column' => $cols['utm_campaign_id'],
                'utm_campaignname_column' => $cols['utm_campaignname'],
                'lead_status_column' => $cols['lead_status'],
                'sitevisit_status_column' => $cols['sitevisit_status'],
            ];
            if (!$cols['lead_status']) {
                $warnings[] = "The {$dbName} lead table has no lead_status column, so qualified leads from it are 0.";
            }
            if (!$cols['sitevisit_status']) {
                $warnings[] = "The {$dbName} lead table has no sitevisit_status column, so site visits from it are 0.";
            }
        } catch (Throwable $e) {
            $dbErrors[$dbName] = $e->getMessage();
            error_log('[Google Performance Report] CRM database ' . $dbName . ': ' . $e->getMessage());
        }
    }

    if (count($dbErrors) === count($dbConnections)) {
        throw new RuntimeException('CRM lead query failed on every database. First error: ' . reset($dbErrors));
    }
    if ($dbErrors) {
        $warnings[] = 'CRM counts are incomplete: database(s) failed: ' . implode(', ', array_keys($dbErrors)) . '.';
    }

    /* ---------- 3. Attribute leads to Google campaigns ---------- */
    $matchedById = 0;
    $matchedByName = 0;

    foreach ($leads as $lead) {
        $b = $bucketOf($lead['date']);
        if ($b === null) {
            continue;
        }
        $vals = ['leads' => 1, 'qualified' => $lead['qualified'] ? 1 : 0, 'site_visits' => $lead['site_visit'] ? 1 : 0];

        $campaignId = null;
        if ($lead['utm_id'] !== '' && isset($campaigns[$lead['utm_id']])) {
            $campaignId = $lead['utm_id'];
            $matchedById++;
        } elseif ($master && $lead['utm_id'] !== '' && isset($master['campaigns'][$lead['utm_id']])) {
            $campaignId = $lead['utm_id'];   // in the master table, but no spend in these periods
            $matchedById++;
        } elseif ($lead['utm_name'] !== '') {
            $norm = gperfNormaliseName($lead['utm_name']);
            if ($norm !== '' && isset($nameIndex[$norm])) {
                $campaignId = $nameIndex[$norm];
                $matchedByName++;
            } elseif ($master && $norm !== '' && isset($master['name_to_campaign'][$norm])) {
                $campaignId = $master['name_to_campaign'][$norm];
                $matchedByName++;
            }
        }

        if ($master) {
            // Only campaigns in the master table count — other leads are left out entirely.
            if ($campaignId === null || !isset($master['campaigns'][$campaignId])) {
                $label = $lead['utm_name'] !== '' ? $lead['utm_name'] : ($lead['utm_id'] !== '' ? 'Campaign ID ' . $lead['utm_id'] : '(no campaign on lead)');
                $excludedLeads[$label] = ($excludedLeads[$label] ?? 0) + 1;
                continue;
            }
            if (!isset($campaigns[$campaignId])) {
                $campaigns[$campaignId] = [
                    'campaign_id' => $campaignId,
                    'campaign_name' => $master['campaigns'][$campaignId],
                    'current' => gperfEmptyMetrics(),
                    'previous' => gperfEmptyMetrics(),
                ];
            }
        }

        foreach ($vals as $f => $v) {
            $totals[$b][$f] += $v;
            if (isset($series[$lead['date']])) {
                $series[$lead['date']][$f] += $v;
            }
        }

        if ($campaignId !== null) {
            foreach ($vals as $f => $v) {
                $campaigns[$campaignId][$b][$f] += $v;
            }
        } else {
            $label = $lead['utm_name'] !== '' ? $lead['utm_name']
                : ($lead['utm_id'] !== '' ? 'Campaign ID ' . $lead['utm_id'] : '(no campaign on lead)');
            $uKey = gperfNormaliseName($label) ?: '(blank)';
            if (!isset($unmatched[$uKey])) {
                $unmatched[$uKey] = [
                    'crm_campaign_name' => $label,
                    'current' => ['leads' => 0, 'qualified' => 0, 'site_visits' => 0],
                    'previous' => ['leads' => 0, 'qualified' => 0, 'site_visits' => 0],
                ];
            }
            foreach ($vals as $f => $v) {
                $unmatched[$uKey][$b][$f] += $v;
                $unattributed[$b][$f] += $v;
            }
        }
    }

    if ($unattributed['current']['leads'] > 0 || $unattributed['previous']['leads'] > 0) {
        $warnings[] = 'Some CRM leads did not match a Google Ads campaign (by UTM campaign ID or name). They are included in totals but not in the campaign table.';
    }

    /* ---------- 4. Derived metrics and output ---------- */
    $curTotals = gperfDerive($totals['current']);
    $prevTotals = gperfDerive($totals['previous']);

    $campaignRows = [];
    foreach ($campaigns as $c) {
        $cur = gperfDerive($c['current']);
        $prev = gperfDerive($c['previous']);
        $campaignRows[] = [
            'campaign_id' => $c['campaign_id'],
            'campaign_name' => $c['campaign_name'],
            'current' => $cur,
            'previous' => $prev,
            'changes' => gperfChanges($cur, $prev),
        ];
    }
    usort($campaignRows, static fn(array $a, array $b): int =>
        [$b['current']['spend'], $b['previous']['spend']] <=> [$a['current']['spend'], $a['previous']['spend']]);

    $seriesOut = array_map(static function (array $d): array {
        $d['spend'] = round((float) $d['spend'], 2);
        return $d;
    }, array_values($series));


    // Linked campaigns but nothing in the reported period → say so instead of a page of zeros.
    if (!empty($master['campaigns']) && (float) ($curTotals['spend'] ?? 0) <= 0 && (int) ($curTotals['leads'] ?? 0) === 0) {
        $warnings[] = 'None of the ' . count($master['campaigns']) . ' Google campaign(s) linked to this project had spend or leads in '
            . $periods['current']['label'] . '. Check the month, or the linked campaigns (⟳ Sync with Google).';
    }

    gperfJson([
        'success' => true,
        'selection' => $selection ?? null,
        'platform' => 'Google',
        'period' => $period,
        'as_of' => $today->format('Y-m-d'),
        'timezone' => 'Asia/Kolkata',
        'generated_at' => (new DateTimeImmutable('now', $tz))->format('d M Y, h:i A'),
        'current' => $periods['current'] + ['totals' => $curTotals],
        'previous' => $periods['previous'] + ['totals' => $prevTotals],
        'changes' => gperfChanges($curTotals, $prevTotals),
        'campaigns' => $campaignRows,
        'daily_series' => $seriesOut,
        'unattributed' => [
            'current' => $unattributed['current'],
            'previous' => $unattributed['previous'],
            'campaigns' => array_values($unmatched),
        ],
        'definitions' => [
            'leads' => 'CRM leads with a Google source (test/junk/duplicate excluded), de-duplicated across both databases, by lead created date.',
            'qualified' => 'lead_status in: ' . implode(', ', GPERF_QUALIFIED_STATUSES),
            'site_visits' => 'sitevisit_status in: ' . implode(', ', GPERF_SITE_VISIT_STATUSES),
            'spend' => 'Google Ads API cost, campaign level, account time zone days.',
            'matching' => 'Leads are matched to campaigns by UTM campaign ID, then by UTM campaign name.',
        ],
        'warnings' => $warnings,
        'diagnostics' => [
            'google_customers_queried' => count($customerIds),
            'google_rows_received' => $adsRowsReceived,
            'campaign_filter' => $master ? 'master_table' : 'none',
            'master_db' => $master['db'] ?? null,
            'master_campaigns' => $master ? count($master['campaigns']) : 0,
            'excluded_campaigns' => $excludedCampaigns,
            'excluded_leads' => $excludedLeads,
            'google_errors' => $adsErrors,
            'crm_unique_leads' => count($leads),
            'crm_matched_by_id' => $matchedById,
            'crm_matched_by_name' => $matchedByName,
            'crm_databases' => $dbStats,
            'crm_errors' => $dbErrors,
        ],
    ]);
} catch (InvalidArgumentException $e) {
    gperfJson(['success' => false, 'error' => $e->getMessage()], 400);
} catch (Throwable $e) {
    error_log('[Google Performance Report] ' . get_class($e) . ': ' . $e->getMessage() . ' @ ' . $e->getFile() . ':' . $e->getLine());
    gperfJson([
        'success' => false,
        'error' => 'Unable to build the Google Ads performance report. Check server logs for details.',
        'warnings' => $warnings,
        'debug' => $debugMode ? [
            'type' => get_class($e),
            'message' => $e->getMessage(),
            'line' => $e->getLine(),
        ] : null,
    ], 500);
}