<?php
// ob_start();
// ob_clean();
//ini_set('display_errors', '1');
//ini_set('display_startup_errors', '1');
//error_reporting(E_ALL);
session_start();
require_once dirname(__DIR__, 2) . '/app/Core/db.php';
require_once dirname(__DIR__, 2) . '/app/Ads/master_tables.php';

// Work on ONE lead database at a time: ?db=<LEAD_DATABASES key> (default: APP_DB),
// chosen with the Database picker on the page. Master tables come from MASTER_TABLES_DB.
$pqDbKey = (string) ($_GET['db'] ?? '');
if ($pqDbKey === '' || $pqDbKey === 'all' || !isLeadDbChoice($pqDbKey)) {
    $pqDbKey = appDbKey();
}
$masterConn = leadDb(masterTablesDbKey()) ?? $conn;
$pqSelectedDb = leadDb($pqDbKey);
if (!$pqSelectedDb) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'error' => leadDbLabel($pqDbKey) . ' database is not reachable']);
    exit;
}
$conn = $pqSelectedDb;
if (!isset($_SESSION["user_logged"]) || $_SESSION["user_logged"] != "Y") {
    header("Location: ../login.php");
    exit;
}
header('Content-Type: application/json');

$rawInput = file_get_contents('php://input');
$input = json_decode($rawInput, true) ?? [];
$action = $_GET['action'] ?? ($input['action'] ?? '');

// ===m=== Platform parameter to distinguish Google vs Taboola ===m===
$platform = $_GET['platform'] ?? ($input['platform'] ?? '');
$platform = strtolower(trim($platform));

if ($platform === 'taboola') {
    $sourceCond = "LOWER(TRIM(campaignsource)) = 'taboola'";
} else {
    // Google only (Meta leads have their own list — they used to be counted here too).
    $sourceCond = "(LOWER(TRIM(campaignsource)) IN ('google', 'googledg') AND (leadgen_id IS NULL OR TRIM(leadgen_id) = ''))";
}

// ===m=== master: campaigns + adgroups + ads for dropdowns ===m===
if ($action === 'master') {
    $camps = $ags = $ads = [];

    if ($platform === 'taboola') {
        // Campaign names from existing Taboola leads
        $r = $conn->query("SELECT DISTINCT utm_campaignname AS campaign_name 
                            FROM `lead` 
                            WHERE LOWER(TRIM(campaignsource)) = 'taboola' 
                              AND utm_campaignname IS NOT NULL AND TRIM(utm_campaignname) != '' 
                            ORDER BY utm_campaignname ASC");
        if ($r) {
            while ($row = $r->fetch_assoc()) {
                $camps[] = [
                    'campaign_id'   => $row['campaign_name'],
                    'campaign_name' => $row['campaign_name'],
                    'platform'      => 'taboola'
                ];
            }
        }

        // Adset names from adset column on Taboola leads
        $r = $conn->query("SELECT DISTINCT adset
                            FROM `lead`
                            WHERE LOWER(TRIM(campaignsource)) = 'taboola'
                              AND adset IS NOT NULL AND TRIM(adset) != ''
                            ORDER BY adset ASC");
        if ($r) {
            while ($row = $r->fetch_assoc()) {
                $ags[] = [
                    'adgroup_id'   => $row['adset'],
                    'adgroup_name' => $row['adset'],
                    'campaign_id'  => '' // Taboola adsets are not scoped to one campaign
                ];
            }
        }

        // Distinct adcreative names for the ad-name dropdown
        $r = $conn->query("SELECT DISTINCT adcreative
                            FROM `lead`
                            WHERE LOWER(TRIM(campaignsource)) = 'taboola'
                              AND adcreative IS NOT NULL AND TRIM(adcreative) != ''
                            ORDER BY adcreative ASC");
        if ($r) {
            while ($row = $r->fetch_assoc()) {
                $ads[] = [
                    'ad_id'      => $row['adcreative'],
                    'ad_name'    => $row['adcreative'],
                    'adgroup_id' => ''
                ];
            }
        }
    } else {
        // This project's saved Google campaigns / ad groups / ads only (master tables, saved names).
        $gs = projectStructure('google');
        foreach ($gs['campaigns'] as $cid => $cname) {
            $camps[] = ['campaign_id' => (string) $cid, 'campaign_name' => $cname, 'platform' => 'google'];
        }
        foreach ($gs['adgroups'] as $gid => $g) {
            $ags[] = ['adgroup_id' => (string) $gid, 'campaign_id' => $g['campaign_id'], 'adgroup_name' => $g['name'], 'platform' => 'google'];
        }
        foreach ($gs['ads'] as $aid => $a) {
            $ads[] = ['ad_id' => (string) $aid, 'adgroup_id' => $a['adgroup_id'], 'ad_name' => $a['name'] !== '' ? $a['name'] : 'Unnamed Ad', 'platform' => 'google'];
        }
        usort($camps, fn($x, $y) => strcasecmp($x['campaign_name'], $y['campaign_name']));
        usort($ags, fn($x, $y) => strcasecmp($x['adgroup_name'], $y['adgroup_name']));
        usort($ads, fn($x, $y) => strcasecmp($x['ad_name'], $y['ad_name']));
    }

    $cs_res = $conn->query("SELECT DISTINCT campaignsource FROM `lead` WHERE campaignsource IS NOT NULL AND TRIM(campaignsource) != '' ORDER BY campaignsource ASC");

    $sources = [];
    if ($cs_res) {
        while ($row = $cs_res->fetch_assoc())
            $sources[] = $row['campaignsource'];
    }

    $ls_res = $conn->query("SELECT DISTINCT lead_status FROM `lead` WHERE lead_status IS NOT NULL AND TRIM(lead_status) != '' ORDER BY lead_status ASC");
    $statuses = [];
    if ($ls_res) {
        while ($row = $ls_res->fetch_assoc())
            $statuses[] = $row['lead_status'];
    }

    $countQuery = $conn->query("SELECT COUNT(DISTINCT mobile) as total FROM `lead` WHERE (utm_campaignname IS NULL OR TRIM(utm_campaignname) = '') AND (lead_status IS NULL OR TRIM(lead_status) = '' OR UPPER(TRIM(lead_status)) NOT IN ('TEST', 'JUNK')) AND $sourceCond");
    $totalUnmapped = 0;
    if ($countQuery && $cRow = $countQuery->fetch_assoc()) {
        $totalUnmapped = (int)$cRow['total'];
    }

    echo json_encode([
        'campaigns' => $camps,
        'adgroups' => $ags,
        'ads' => $ads,
        'sources' => $sources,
        'statuses' => $statuses,
        'total_all_time' => $totalUnmapped
    ]);
    exit;
}

// ===m=== unmapped: leads with no utmC, fetch mobile + gclid + createddate ===m===
if ($action === 'unmapped') {
    $leads = [];
    $search = !empty($_GET['search']) ? $conn->real_escape_string($_GET['search']) : '';

    $source_filter = !empty($_GET['source']) ? $conn->real_escape_string($_GET['source']) : '';
    $status_filter = !empty($_GET['status']) ? $conn->real_escape_string($_GET['status']) : '';

    $where = "WHERE (utm_campaignname IS NULL OR TRIM(utm_campaignname) = '') AND (lead_status IS NULL OR TRIM(lead_status) = '' OR UPPER(TRIM(lead_status)) NOT IN ('TEST', 'JUNK')) AND $sourceCond";

    if ($source_filter !== '') {
        $where .= " AND campaignsource = '{$source_filter}' ";
    }

    if ($status_filter !== '') {
        $where .= " AND lead_status = '{$status_filter}' ";
    }

    if ($search !== '') {
        $where .= " AND (mobile LIKE '{$search}%' OR gclid = '{$search}')";
        $start_datetime = '';
        $end_datetime = '';
    } else {
        $start_date = !empty($_GET['start'])
            ? $conn->real_escape_string($_GET['start'])
            : date('Y-m-d', strtotime('-30 days'));

        $end_date = !empty($_GET['end'])
            ? $conn->real_escape_string($_GET['end'])
            : date('Y-m-d');

        $start_datetime = $start_date . " 00:00:00";
        $end_datetime = $end_date . " 23:59:59";

        $where .= "
            AND createddate >= '{$start_datetime}'
            AND createddate <= '{$end_datetime}'
        ";
    }

    // For Taboola leads also fetch adcreative + adset so the UI can display them
    $extraCols = ($platform === 'taboola') ? ', l.adcreative, l.adset' : '';
    $sql = "SELECT l.mobile, l.gclid, l.createddate{$extraCols} FROM `lead` l INNER JOIN (SELECT mobile, campaignsource, MAX(createddate) AS latest_created FROM `lead` $where GROUP BY mobile, campaignsource) x ON l.mobile = x.mobile AND l.campaignsource = x.campaignsource AND l.createddate = x.latest_created ORDER BY l.createddate DESC LIMIT 1000";

    $r = $conn->query($sql);

    if (!$r) {
        echo json_encode([
            'success' => false,
            'error' => 'Could not load the leads.'
        ]);
        error_log('[unmapped_api] ' . $conn->error);
        exit;
    }

    while ($row = $r->fetch_assoc()) {
        $row['is_test'] = stripos((string) ($row['mobile'] ?? ''), 'test') !== false;
        $leads[] = $row;
    }

    echo json_encode([
        'success' => true,
        // mobile masked here by Users & Roles (mobile_export for the Excel); `ref` is the key for Test / Junk / Save
        'leads' => pqLeadRowsForBrowser($leads),
        'count' => count($leads),
        'start' => $start_datetime,
        'end' => $end_datetime
    ]);

    exit;
}

// ===m=== update status: mark as test or junk ===m===
if ($action === 'update_status' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $mobile = $conn->real_escape_string(pqLeadMobile($input['mobile'] ?? ''));
    $status = $conn->real_escape_string($input['status'] ?? '');

    if (!$mobile || !in_array($status, ['TEST', 'JUNK'])) {
        echo json_encode(['error' => 'Invalid input']);
        exit;
    }

    $result = $conn->query("UPDATE `lead` SET lead_status = '$status' WHERE mobile = '$mobile' AND $sourceCond");
    if (!$result) {
        echo json_encode(['error' => $conn->error]);
        exit;
    }

    echo json_encode(['success' => true, 'affected' => $conn->affected_rows]);
    exit;
}
// ===m=== save: update single lead mapping ===m===
if ($action === 'save' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!$input) {
        echo json_encode(['error' => 'Invalid input']);
        exit;
    }

    $unique_id = $conn->real_escape_string(pqLeadMobile($input['unique_id'] ?? $input['mobile'] ?? ''));   // gclid, mobile or lead reference
    $campaign_name = $conn->real_escape_string($input['campaign_name'] ?? '');
    $adgroup_name = $conn->real_escape_string($input['adgroup_name'] ?? '');
    $ad_name = $conn->real_escape_string($input['ad_name'] ?? '');

    // Build SET dynamically based on existing columns
    $existingCols = [];
    $r = $conn->query("SHOW COLUMNS FROM `lead`");
    while ($col = $r->fetch_assoc())
        $existingCols[] = $col['Field'];

    // $setParts = ["utmC = '$campaign_name'"];
    // if (in_array('utm_adgroup', $existingCols))
    //     $setParts[] = "utm_adgroup = '$adgroup_name'";
    // if (in_array('utm_adname', $existingCols))
    //     $setParts[] = "utm_adname = '$ad_name'";

    $campaign_id = $conn->real_escape_string($input['campaign_id'] ?? '');
    $adgroup_id = $conn->real_escape_string($input['adgroup_id'] ?? '');
    $ad_id = $conn->real_escape_string($input['ad_id'] ?? '');

    $setParts = [
        "utm_campaignname = '$campaign_name'",
        "utm_campaignid   = '$campaign_id'",
        "utm_adgroupname  = '$adgroup_name'",
        "utm_adgroupid    = '$adgroup_id'",
        "utm_adname       = '$ad_name'",
        "utm_adid         = '$ad_id'"
    ];

    if (in_array('utm_adgroup', $existingCols))
        $setParts[] = "utm_adgroupname  = '$adgroup_name'";
    if (in_array('utm_adname', $existingCols))
        $setParts[] = "utm_adname = '$ad_name'";

    // Taboola leads are unmapped when utm_campaignname is empty (not utmC).
    // Google leads are unmapped when utmC is empty.
    $unmappedCond = ($platform === 'taboola')
        ? "(utm_campaignname IS NULL OR TRIM(utm_campaignname) = '')"
        : "(utmC IS NULL OR utmC = '')";

    $result = $conn->query("UPDATE `lead` SET " . implode(', ', $setParts) . " WHERE (mobile = '$unique_id' OR gclid = '$unique_id') AND $sourceCond AND $unmappedCond");
    if (!$result) {
        echo json_encode(['error' => $conn->error]);
        exit;
    }

    echo json_encode(['success' => true, 'affected' => $conn->affected_rows]);
    exit;
}

// ===m=== import: batch CSV update ===m===
if ($action === 'import' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $rows = $input['rows'] ?? [];

    if (empty($rows)) {
        echo json_encode(['error' => 'No rows provided']);
        exit;
    }

    // Check columns once
    $existingCols = [];
    $r = $conn->query("SHOW COLUMNS FROM `lead`");
    while ($col = $r->fetch_assoc())
        $existingCols[] = $col['Field'];

    $success = $failed = 0;
    foreach ($rows as $row) {
        $gclid = $conn->real_escape_string(trim($row['gclid'] ?? ''));
        $mobile = $conn->real_escape_string(trim($row['mobile'] ?? ''));
        $campaign_name = $conn->real_escape_string(trim($row['campaign_name'] ?? ''));

        if ((!$gclid && !$mobile) || !$campaign_name) {
            $failed++;
            continue;
        }

        $adgroup_name = $conn->real_escape_string(trim($row['adgroup_name'] ?? ''));
        $ad_name = $conn->real_escape_string(trim($row['ad_name'] ?? ''));

        $campaign_id = $conn->real_escape_string(trim($row['campaign_id'] ?? ''));
        $adgroup_id = $conn->real_escape_string(trim($row['adgroup_id'] ?? ''));
        $ad_id = $conn->real_escape_string(trim($row['ad_id'] ?? ''));

        $setParts = [
            "utm_campaignname = '$campaign_name'",
            "utm_campaignid   = '$campaign_id'",
            "utm_adgroupname  = '$adgroup_name'",
            "utm_adgroupid    = '$adgroup_id'",
            "utm_adname       = '$ad_name'",
            "utm_adid         = '$ad_id'"
        ];
        if (in_array('utm_adgroupname', $existingCols))
            $setParts[] = "utm_adgroupname  = '$adgroup_name'";
        if (in_array('utm_adname', $existingCols))
            $setParts[] = "utm_adname = '$ad_name'";

        // Update matching mobile OR gclid since unique_id could be either
        // $result = $conn->query("UPDATE `lead` SET " . implode(', ', $setParts) . " WHERE (mobile = '$unique_id' OR gclid = '$unique_id') AND (utmC IS NULL OR utmC = '')");
        $whereClause = [];
        if ($gclid)
            $whereClause[] = "gclid = '$gclid'";
        if ($mobile)
            $whereClause[] = "mobile = '$mobile'";
        $where = implode(' OR ', $whereClause);

        $result = $conn->query("UPDATE `lead` SET " . implode(', ', $setParts) . " WHERE ($where) AND (utm_campaignname IS NULL OR utm_campaignname = '') AND $sourceCond");
        $result ? $success++ : $failed++;
    }

    echo json_encode(['success' => true, 'updated' => $success, 'failed' => $failed]);
    exit;
}
