<?php
// The Meta dashboard is now a section of the PerformIQ shell — keep old links working.
header('Location: ../dashboard.php#meta', true, 301);
exit;
