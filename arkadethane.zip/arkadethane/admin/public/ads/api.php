<?php
/**
 * api.php — JSON data endpoint for the PerfomIQ dashboard.
 *
 * Called via AJAX from dashboard.php after the UI has already painted.
 * Returns the same data structure as fetchMetaAdsData() as JSON.
 *
 * Accepts the same URL params as the dashboard:
 *   ?preset=last_7d
 *   ?since=2026-05-01&until=2026-05-29
 */

require_once dirname(__DIR__, 2) . '/app/Core/db.php';
require_once dirname(__DIR__, 2) . '/app/Ads/fetch_meta.php';

/*
| CRM DATABASES — every database in LEAD_DATABASES (config/config.php)
*/
function getCrmDatabaseConnections(): array
{
    return leadDbs('all');
}

// Strict JSON-only response
header('Content-Type: application/json');
header('X-Content-Type-Options: nosniff');

// Simple CORS guard — same origin only (adjust if your setup differs)
$origin = $_SERVER['HTTP_ORIGIN'] ?? '';
if ($origin !== '' && parse_url($origin, PHP_URL_HOST) !== $_SERVER['HTTP_HOST']) {
    http_response_code(403);
    echo json_encode(['error' => 'Forbidden']);
    exit;
}

// Read the requested API action.
// update_leads has intentionally been removed; Meta uploads use
// meta_update_leads.php exclusively.
$action = isset($_GET['action']) ? trim((string) $_GET['action']) : '';

// Session check used by dashboard.php before loading/refreshing data.
// Everything except the session check needs a logged-in user (this returns spend and lead data).
if ($action !== 'check_session') {
    if (session_status() !== PHP_SESSION_ACTIVE) {
        session_start();
    }
    if (($_SESSION['user_logged'] ?? '') !== 'Y') {
        http_response_code(401);
        echo json_encode(['valid' => false, 'error' => 'Not logged in']);
        exit;
    }
    session_write_close();
}

if ($action === 'check_session') {
    if (session_status() !== PHP_SESSION_ACTIVE) {
        session_start();
    }

    echo json_encode([
        'valid' => isset($_SESSION['user_logged']) && $_SESSION['user_logged'] === 'Y'
    ]);
    exit;
}

// ── Verify Campaign Name via Database / Meta Graph API ──────────────────
if ($action === 'verify_campaign_name') {
    $campaignName = isset($_GET['campaign_name']) ? trim($_GET['campaign_name']) : '';

    if ($campaignName === '') {
        echo json_encode(['valid' => false, 'error' => 'Campaign name is required.']);
        exit;
    }

    // 1. Check if already exists in lead table
    $alreadyExistsInLeads = false;
    foreach (getCrmDatabaseConnections() as $dbName => $db) {
        $stmt = $db->prepare(
            "SELECT id FROM `lead`
             WHERE LOWER(TRIM(campaign_name)) = LOWER(TRIM(?))
             LIMIT 1"
        );
        if ($stmt) {
            $stmt->bind_param('s', $campaignName);
            $stmt->execute();
            $stmt->store_result();
            if ($stmt->num_rows > 0) {
                $alreadyExistsInLeads = true;
                $stmt->close();
                break;
            }
            $stmt->close();
        }
    }

    if ($alreadyExistsInLeads) {
        echo json_encode([
            'valid' => false,
            'error' => 'Campaign already exists in the lead table. No need to add.'
        ]);
        exit;
    }

    // 2. Check if already exists in campaigns_master
    $alreadyExistsInMaster = false;
    if (isset($conn) && !$conn->connect_error) {
        $stmt = $conn->prepare("SELECT id FROM `campaigns` WHERE LOWER(TRIM(campaign_name)) = LOWER(TRIM(?)) LIMIT 1");
        if ($stmt) {
            $stmt->bind_param('s', $campaignName);
            $stmt->execute();
            $stmt->store_result();
            $alreadyExistsInMaster = $stmt->num_rows > 0;
            $stmt->close();
        }
    }

    if ($alreadyExistsInMaster) {
        echo json_encode([
            'valid' => false,
            'error' => 'Campaign already exists in the master list. No need to add.'
        ]);
        exit;
    }

    // 3. Search via Meta Graph API across all accounts
    $token = META_ACCESS_TOKEN;
    $version = META_API_VERSION;
    $foundCampaign = null;

    // Get all account IDs
    $accountIds = [];
    if (defined('META_AD_ACCOUNT_IDS')) {
        $rawIds = META_AD_ACCOUNT_IDS;
        if (is_array($rawIds)) {
            $accountIds = $rawIds;
        } elseif (is_string($rawIds)) {
            $decoded = json_decode($rawIds, true);
            $accountIds = is_array($decoded) ? $decoded : [$rawIds];
        }
    } elseif (defined('META_AD_ACCOUNT_ID')) {
        $accountIds = [META_AD_ACCOUNT_ID];
    }

    foreach ($accountIds as $accId) {
        if (empty($accId))
            continue;
        $url = "https://graph.facebook.com/{$version}/act_{$accId}/campaigns?fields=name,status,objective&limit=1000&access_token={$token}";
        $result = fetchAllPages($url);

        if (isset($result['data']) && is_array($result['data'])) {
            foreach ($result['data'] as $c) {
                if (isset($c['name']) && strcasecmp(trim($c['name']), $campaignName) === 0) {
                    $foundCampaign = $c;
                    break 2;
                }
            }
        }
    }

    if ($foundCampaign) {
        echo json_encode([
            'valid' => true,
            'campaign_id' => $foundCampaign['id'],
            'campaign_name' => $foundCampaign['name'],
            'status' => $foundCampaign['status'] ?? '',
            'objective' => $foundCampaign['objective'] ?? '',
        ]);
    } else {
        echo json_encode(['valid' => false, 'error' => 'Campaign name not found in any Meta Ad Account.']);
    }
    exit;
}

// ── Save Campaign to campaigns_master ──────────────────────
// ── Save Campaign to the `campaigns` master table ──────────────────────────
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST' && $action === 'save_campaign') {
    header('Content-Type: application/json; charset=utf-8');

    $reply = static function (array $payload, int $status = 200): never {
        http_response_code($status);
        echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        exit;
    };

    $input = json_decode((string) file_get_contents('php://input'), true);
    $input = is_array($input) ? $input : [];

    $campaignId = preg_replace('/\D+/', '', trim((string) ($input['campaign_id'] ?? ''))) ?? '';
    $campaignName = trim(preg_replace('/\s+/u', ' ', (string) ($input['campaign_name'] ?? '')) ?? '');
    $status = strtoupper(trim((string) ($input['status'] ?? '')));
    $platform = 'meta';

    if ($campaignId === '' || strlen($campaignId) > 50) {
        $reply(['success' => false, 'error' => 'A valid Meta campaign ID is required.'], 400);
    }

    // Master tables live in one database: MASTER_TABLES_DB (any LEAD_DATABASES key; default: the first).
    $masterDb = leadDb(masterTablesDbKey());
    if (!$masterDb instanceof mysqli || $masterDb->connect_errno) {
        $reply(['success' => false, 'error' => 'Database connection failed.'], 500);
    }

    // Confirm with Meta and take its official name + live status (falls back to the posted values).
    if (defined('META_ACCESS_TOKEN') && defined('META_API_VERSION') && function_exists('curl_init')) {
        $ver = trim((string) META_API_VERSION);
        $ver = $ver !== '' && $ver[0] !== 'v' ? 'v' . $ver : $ver;
        $ch = curl_init('https://graph.facebook.com/' . rawurlencode($ver) . '/' . rawurlencode($campaignId) . '?'
            . http_build_query(['fields' => 'id,name,effective_status', 'access_token' => (string) META_ACCESS_TOKEN]));
        curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_CONNECTTIMEOUT => 8, CURLOPT_TIMEOUT => 15]);
        $graph = json_decode((string) curl_exec($ch), true);
        unset($ch);

        if (is_array($graph) && !empty($graph['id'])) {
            $campaignName = trim((string) ($graph['name'] ?? $campaignName));
            $status = strtoupper((string) ($graph['effective_status'] ?? $status));
        } elseif (is_array($graph) && isset($graph['error'])) {
            $reply(['success' => false, 'error' => 'Meta could not find this campaign: ' . ($graph['error']['message'] ?? 'unknown error')], 404);
        }
    }

    if ($campaignName === '') {
        $reply(['success' => false, 'error' => 'Campaign name is required.'], 400);
    }
    $campaignName = mb_substr($campaignName, 0, 255);
    $status = $status !== '' ? mb_substr($status, 0, 50) : null;

    try {
        // One row per campaign_id (unique key): insert new, or refresh name/status if it already exists.
        $stmt = $masterDb->prepare(
            'INSERT INTO `campaigns` (campaign_id, campaign_name, status, platform) VALUES (?, ?, ?, ?)
             ON DUPLICATE KEY UPDATE campaign_name = VALUES(campaign_name),
                                     status        = COALESCE(VALUES(status), status),
                                     platform      = VALUES(platform)'
        );
        if (!$stmt) {
            throw new RuntimeException($masterDb->error);
        }
        $stmt->bind_param('ssss', $campaignId, $campaignName, $status, $platform);
        $stmt->execute();
        $affected = $stmt->affected_rows;   // 1 = inserted, 2 = updated, 0 = already identical
        $stmt->close();
    } catch (Throwable $e) {
        error_log('[save_campaign] ' . $e->getMessage());
        $reply(['success' => false, 'error' => 'Could not save the campaign. Check server logs.'], 500);
    }

    // Clear cached dashboard data so the change shows immediately.
    foreach (glob(CACHE_PATH . '/meta_*.json') ?: [] as $file) {
        if (is_file($file)) {
            @unlink($file);
        }
    }

    $reply([
        'success' => true,
        'campaign_id' => $campaignId,
        'campaign_name' => $campaignName,
        'status' => $status,
        'already_exists' => $affected !== 1,
        'message' => $affected === 1
            ? 'Campaign added to the master list.'
            : 'Campaign was already in the master list; its name and status were refreshed.',
    ]);
}

// ── Fetch Individual Lead Details (Qualified Leads / Site Visits popup) ────────────────
if ($action === 'fetch_lead_details') {
    $campaignName = isset($_GET['campaign_name']) ? trim($_GET['campaign_name']) : '';
    $adsetName = isset($_GET['adset_name']) ? trim($_GET['adset_name']) : '';
    $adName = isset($_GET['ad_name']) ? trim($_GET['ad_name']) : '';
    $type = isset($_GET['type']) ? trim($_GET['type']) : '';
    $since = isset($_GET['since']) ? preg_replace('/[^0-9\-]/', '', $_GET['since']) : '';
    $until = isset($_GET['until']) ? preg_replace('/[^0-9\-]/', '', $_GET['until']) : '';
    $preset = isset($_GET['preset']) ? preg_replace('/[^a-zA-Z0-9_]/', '', $_GET['preset']) : '';
    // Google dashboard uses this popup too: its leads carry utm_* columns.
    $lp = (($_GET['platform'] ?? '') === 'google') ? 'google' : 'meta';
    $col = $lp === 'google'
        ? ['campaign' => 'utm_campaignname', 'adset' => 'utm_adgroupname', 'ad' => 'utm_adname', 'ad_id' => 'utm_adid', 'campaign_id' => 'utm_campaignid',
           'source' => "LOWER(TRIM(COALESCE(campaignsource, ''))) IN ('google', 'googledg')"]
        : ['campaign' => 'campaign_name', 'adset' => 'adset_name', 'ad' => 'ad_name', 'ad_id' => 'ad_id', 'campaign_id' => '',
           'source' => PQ_META_LEAD_SQL];

    if ($campaignName === '' || !in_array($type, ['leads', 'qualified', 'sitevisit'], true)) {
        echo json_encode(['success' => false, 'error' => 'Invalid parameters.']);
        exit;
    }

    if ($type === 'sitevisit') {
        echo json_encode([
            'success' => false,
            'error' => 'Site visit status is not available in the lead table schema.'
        ]);
        exit;
    }

    if ($since === '' || $until === '') {
        $p = $preset !== '' ? $preset : (defined('DATE_PRESET') ? DATE_PRESET : 'last_30d');
        [$since, $until] = getDatesFromPreset($p);
    }

    $dbStart = $since . ' 00:00:00';
    $dbEnd = $until . ' 23:59:59';

    $whereType = $type === 'qualified'
        ? "AND TRIM(UPPER(COALESCE(lead_status,''))) IN ('QUALIFIED','LOST POST QUALIFIED')"
        : "";

    $dbConnections = getCrmDatabaseConnections();
    $leads = [];

    foreach ($dbConnections as $dbName => $db) {
        $params = [];
        $types = '';

        $where = "createddate >= ? AND createddate <= ?
                  AND {$col['source']}
                  AND (lead_status IS NULL OR UPPER(TRIM(lead_status)) NOT IN ('TEST', 'JUNK'))
                  AND (name IS NULL OR LOWER(TRIM(name)) NOT LIKE '%test%')
                  AND (email IS NULL OR LOWER(TRIM(email)) NOT LIKE '%test%')
                  AND (mobile IS NULL OR (
                      LOWER(TRIM(mobile)) NOT LIKE '%test%'
                      AND TRIM(mobile) NOT IN ('9999999999', '8888888888', '0000000000', '1234567890', '1111111111')
                  ))";
        $params[] = $dbStart;
        $params[] = $dbEnd;
        $types .= 'ss';

        // Only leads of this project's campaigns (`campaigns` table) — matched by campaign name or by ad ID,
        // so a campaign renamed in the table still finds its leads.
        if (strcasecmp($campaignName, 'ALL') !== 0) {
            $projectCid = projectCampaignId($lp, $_GET['campaign_id'] ?? null, $campaignName);
            $cond = $projectCid === null
                ? '1=0'
                : projectLeadCondition($db, $lp, $projectCid, $col['campaign'], $col['ad_id'], [$campaignName, $_GET['source_name'] ?? ''], $col['campaign_id']);
            $where .= ' AND ' . $cond;
        } else {
            $where .= ' AND ' . projectLeadCondition($db, $lp, null, $col['campaign'], $col['ad_id'], [], $col['campaign_id']);
        }

        if ($adsetName !== '') {
            $where .= " AND LOWER(TRIM(COALESCE({$col['adset']},''))) = LOWER(TRIM(?))";
            $params[] = $adsetName;
            $types .= 's';
        }

        if ($adName !== '') {
            $where .= " AND LOWER(TRIM(COALESCE({$col['ad']},''))) = LOWER(TRIM(?))";
            $params[] = $adName;
            $types .= 's';
        }

        $sql = "SELECT
                    leadgen_id,
                    DATE_FORMAT(createddate, '%d %b %Y, %h:%i %p') AS created_date,
                    {$col['campaign']} AS campaign_name,
                    COALESCE({$col['adset']}, '—') AS adset_name,
                    COALESCE({$col['ad']}, '—') AS ad_name,
                    lead_status,
                    {$col['ad_id']} AS ad_id
                FROM `lead`
                WHERE {$where}
                  {$whereType}
                ORDER BY createddate DESC
                LIMIT 500";

        $stmt = $db->prepare($sql);
        if (!$stmt) {
            continue;
        }

        $stmt->bind_param($types, ...$params);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result) {
            $ps = projectStructure($lp);
            while ($row = $result->fetch_assoc()) {
                $row['database'] = $dbName;
                // show the names saved in the campaigns / adgroups / ads tables
                $ad = $ps['ads'][trim((string) $row['ad_id'])] ?? null;
                $set = $ad ? ($ps['adgroups'][$ad['adgroup_id']] ?? null) : null;
                $cid = null;
                if ($set) {
                    $cid = $set['campaign_id'];
                    $row['campaign_name'] = $ps['campaigns'][$set['campaign_id']] ?? $row['campaign_name'];
                    $row['adset_name'] = $set['name'] !== '' ? $set['name'] : $row['adset_name'];
                    $row['ad_name'] = $ad['name'] !== '' ? $ad['name'] : $row['ad_name'];
                } elseif (($cid = projectCampaignId($lp, null, (string) $row['campaign_name'])) !== null) {
                    $row['campaign_name'] = $ps['campaigns'][$cid];
                }
                unset($row['ad_id']);
                // All / Performance / Awareness tab + Users & Roles → Campaign types
                if (!pqViewShows($cid !== null && isset($ps['awareness'][$cid]) ? 'awareness' : 'performance')) {
                    continue;
                }
                $leads[] = $row;
            }
        }

        $stmt->close();
    }

    /*
     * Both DBs are queried independently, then combined and sorted by created date.
     */
    usort($leads, static function ($a, $b) {
        return strcmp(
            (string) ($b['created_date'] ?? ''),
            (string) ($a['created_date'] ?? '')
        );
    });

    $leads = array_slice($leads, 0, 500);

    echo json_encode([
        'success' => true,
        'leads' => $leads,
        'total' => count($leads),
        'databases' => array_keys($dbConnections)
    ]);
    exit;
}

// Validate / sanitise inputs
$preset = isset($_GET['preset']) ? preg_replace('/[^a-zA-Z0-9_]/', '', $_GET['preset']) : null;
$since = isset($_GET['since']) ? preg_replace('/[^0-9\-]/', '', $_GET['since']) : null;
$until = isset($_GET['until']) ? preg_replace('/[^0-9\-]/', '', $_GET['until']) : null;

if ($action === 'fetch_adsets') {
    $campaignId = isset($_GET['campaign_id']) ? preg_replace('/[^0-9]/', '', $_GET['campaign_id']) : '';
    $campaignName = isset($_GET['campaign_name']) ? trim($_GET['campaign_name']) : '';
    if ($campaignId === '') {
        echo json_encode(['error' => 'Campaign ID is required.']);
        exit;
    }
    try {
        $data = fetchAdsetData($campaignId, $preset, $since, $until, $campaignName);
        echo json_encode($data);
    } catch (Throwable $e) {
        http_response_code(500);
        echo json_encode(['error' => ['message' => $e->getMessage()]]);
    }
    exit;
}

if ($action === 'fetch_ads') {
    $adsetId = isset($_GET['adset_id']) ? preg_replace('/[^0-9]/', '', $_GET['adset_id']) : '';
    $campaignName = isset($_GET['campaign_name']) ? trim($_GET['campaign_name']) : '';
    $adsetName = isset($_GET['adset_name']) ? trim($_GET['adset_name']) : '';
    if ($adsetId === '') {
        echo json_encode(['error' => 'Adset ID is required.']);
        exit;
    }
    try {
        $data = fetchAdData($adsetId, $preset, $since, $until, $campaignName, $adsetName);
        echo json_encode($data);
    } catch (Throwable $e) {
        http_response_code(500);
        echo json_encode(['error' => ['message' => $e->getMessage()]]);
    }
    exit;
}

// ── Pivot report: Campaign > Ad Set > Ad, with lead_status breakdown ────────
// Reuses the same hierarchical fetchers (and their caches) as fetch_adsets/fetch_ads
// so this endpoint doesn't add extra live Meta API load beyond a normal drill-down.
// Whatever date range is selected on the dashboard's calendar (since/until, or a
// preset) is passed straight through — same params as the rest of api.php.
if ($action === 'fetch_pivot_report') {
    set_time_limit(300);

    $resolvedSince = $since;
    $resolvedUntil = $until;
    if (empty($resolvedSince) || empty($resolvedUntil)) {
        $p = !empty($preset) ? $preset : (defined('DATE_PRESET') ? DATE_PRESET : 'last_30d');
        [$resolvedSince, $resolvedUntil] = getDatesFromPreset($p);
    }

    // Same All / Active / Inactive filter as the dashboard's status tabs, so the
    // export always matches whichever tab is selected on screen.
    $statusFilter = isset($_GET['status_filter']) ? strtolower(preg_replace('/[^a-z]/i', '', $_GET['status_filter'])) : 'all';
    if (!in_array($statusFilter, ['all', 'active', 'inactive'], true)) {
        $statusFilter = 'all';
    }

    try {
        // 1. Campaigns active in this date range.
        $accountData = fetchMetaAdsData($preset, $since, $until);
        if (!empty($accountData['api_error'])) {
            echo json_encode(['success' => false, 'error' => $accountData['api_error']]);
            exit;
        }
        $campaigns = $accountData['campaigns'] ?? [];

        // 1b. Apply the same status filter used by the dashboard's All/Active/Inactive tabs.
        if ($statusFilter !== 'all') {
            $campaigns = array_values(array_filter($campaigns, function ($camp) use ($statusFilter) {
                $es = strtoupper($camp['effective_status'] ?? $camp['status'] ?? '');
                if ($statusFilter === 'active') {
                    return $es === 'ACTIVE';
                }
                // inactive: anything that isn't ACTIVE and isn't blank/UNKNOWN
                return $es !== 'ACTIVE' && $es !== '' && $es !== 'UNKNOWN';
            }));
        }

        // 2. Single fast level=ad insights fetch (1-3 Graph API calls total, paginated)
        //    instead of the old per-campaign/per-adset walk (previously 100+ sequential
        //    calls via fetchAdsetData/fetchAdData, which is what made this export slow).
        $allowedCampaignNames = null; // null = no status filter, keep everything
        if ($statusFilter !== 'all') {
            $allowedCampaignNames = [];
            foreach ($campaigns as $camp) {
                if (!empty($camp['name'])) {
                    $allowedCampaignNames[strtolower(trim($camp['name']))] = true;
                }
            }
        }

        $pivotSpend = fetchAdsPivotSpend($preset, $since, $until);
        if (!empty($pivotSpend['api_error'])) {
            echo json_encode(['success' => false, 'error' => $pivotSpend['api_error']]);
            exit;
        }

        // Dedupe by ad_id (unique per ad on Meta) — KEEP the first occurrence rather than
        // summing. A true duplicate (e.g. a repeated page from fetchAllPages) collapses to
        // one correct-spend row. Two genuinely different ads that just share a display name
        // keep different ad_ids, so they still show as separate rows with their own spend
        // instead of being incorrectly merged together.
        $seenAdIds = [];
        $rows = [];
        foreach ($pivotSpend['rows'] as $r) {
            if ($allowedCampaignNames !== null && !isset($allowedCampaignNames[strtolower(trim($r['campaign_name']))])) {
                continue; // filtered out by Active/Inactive tab
            }
            if (!pqViewShows(pqCampaignType('meta', (string) ($r['campaign_id'] ?? ''), (string) $r['campaign_name']))) {
                continue; // All / Performance / Awareness tab, Users & Roles → Campaign types
            }
            $adId = $r['ad_id'] ?? '';
            if ($adId !== '') {
                if (isset($seenAdIds[$adId])) {
                    continue; // duplicate fetch of the same ad — skip, don't double-count
                }
                $seenAdIds[$adId] = true;
            }
            $rows[] = [
                'campaign_name' => $r['campaign_name'] ?: 'Unknown',
                'adset_name' => $r['adset_name'] ?: 'Unknown',
                'ad_name' => $r['ad_name'] ?: 'Unknown',
                'spend' => (float) $r['spend'],
                'impressions' => (int) ($r['impressions'] ?? 0),
                'clicks' => (int) ($r['clicks'] ?? 0),
                'frequency' => (float) ($r['frequency'] ?? 0),
                'reach' => (int) ($r['reach'] ?? 0),
            ];
        }

        // 3. One DB pass for the 4 lead_status buckets, grouped by the same
        //    campaign_name/adset_name/ad_name text columns used everywhere else.
        $statusCounts = [];
        $dbConnections = getCrmDatabaseConnections();

        foreach ($dbConnections as $dbName => $db) {
            $dbStart = $resolvedSince . ' 00:00:00';
            $dbEnd = $resolvedUntil . ' 23:59:59';

            $sqlStatus = "SELECT
                    COALESCE(campaign_name, '') AS campaign_name,
                    COALESCE(adset_name, '') AS adset_name,
                    COALESCE(ad_name, '') AS ad_name,
                    SUM(CASE WHEN TRIM(UPPER(COALESCE(lead_status,''))) = 'QUALIFIED' THEN 1 ELSE 0 END) AS in_qualified,
                    SUM(CASE WHEN TRIM(UPPER(COALESCE(lead_status,''))) = 'LOST POST QUALIFIED' THEN 1 ELSE 0 END) AS lost_post_qualified,
                    SUM(CASE WHEN TRIM(UPPER(COALESCE(lead_status,''))) IN ('QUALIFIED','LOST POST QUALIFIED') THEN 1 ELSE 0 END) AS qualified_total,
                    SUM(CASE WHEN TRIM(UPPER(COALESCE(lead_status,''))) = 'NON-QUALIFIED' THEN 1 ELSE 0 END) AS non_qualified,
                    SUM(CASE WHEN TRIM(UPPER(COALESCE(lead_status,''))) = 'TO BE QUALIFIED' THEN 1 ELSE 0 END) AS to_be_qualified
                FROM `lead`
                WHERE createddate >= ? AND createddate <= ?
                  AND ad_name IS NOT NULL AND ad_name <> ''
                  AND " . PQ_META_LEAD_SQL . "
                  AND (lead_status IS NULL OR UPPER(TRIM(lead_status)) NOT IN ('TEST', 'JUNK'))
                  AND (name IS NULL OR LOWER(TRIM(name)) NOT LIKE '%test%')
                  AND (email IS NULL OR LOWER(TRIM(email)) NOT LIKE '%test%')
                  AND (mobile IS NULL OR (
                      LOWER(TRIM(mobile)) NOT LIKE '%test%'
                      AND TRIM(mobile) NOT IN ('9999999999', '8888888888', '0000000000', '1234567890', '1111111111')
                  ))
                GROUP BY campaign_name, adset_name, ad_name";

            $stmtStatus = $db->prepare($sqlStatus);
            if (!$stmtStatus) {
                continue;
            }

            $stmtStatus->bind_param('ss', $dbStart, $dbEnd);
            $stmtStatus->execute();
            $resStatus = $stmtStatus->get_result();

            while ($rowStatus = $resStatus->fetch_assoc()) {
                $key = strtolower(trim($rowStatus['campaign_name'])) . '|' .
                    strtolower(trim($rowStatus['adset_name'])) . '|' .
                    strtolower(trim($rowStatus['ad_name']));

                if (!isset($statusCounts[$key])) {
                    $statusCounts[$key] = [
                        'campaign_name' => $rowStatus['campaign_name'],
                        'adset_name' => $rowStatus['adset_name'],
                        'ad_name' => $rowStatus['ad_name'],
                        'in_qualified' => 0,
                        'lost_post_qualified' => 0,
                        'non_qualified' => 0,
                        'to_be_qualified' => 0,
                        'qualified_total' => 0
                    ];
                }

                $statusCounts[$key]['in_qualified'] += (int) $rowStatus['in_qualified'];
                $statusCounts[$key]['lost_post_qualified'] += (int) $rowStatus['lost_post_qualified'];
                $statusCounts[$key]['non_qualified'] += (int) $rowStatus['non_qualified'];
                $statusCounts[$key]['to_be_qualified'] += (int) $rowStatus['to_be_qualified'];
                $statusCounts[$key]['qualified_total'] += (int) $rowStatus['qualified_total'];
            }

            $stmtStatus->close();
        }

        // 4. Merge — same "claim a name only once" guard used elsewhere in fetch_meta.php
        //    (e.g. fetchAdData's $usedAdCrmNames) so a reused ad/adset name across
        //    campaigns doesn't get double-counted.
        $usedKeys = [];
        $out = [];
        foreach ($rows as $r) {
            $key = strtolower(trim($r['campaign_name'])) . '|' .
                strtolower(trim($r['adset_name'])) . '|' .
                strtolower(trim($r['ad_name']));
            $counts = ['in_qualified' => 0, 'lost_post_qualified' => 0, 'non_qualified' => 0, 'to_be_qualified' => 0, 'qualified_total' => 0];
            if (!isset($usedKeys[$key])) {
                $counts = $statusCounts[$key] ?? $counts;
                $usedKeys[$key] = true;
            }
            $out[] = array_merge($r, $counts);
        }

        // Include DB-only entries (leads without matching Meta ad) — only for this project's campaigns,
        // with saved names where the campaign / ad set / ad is in the master tables.
        $metaStructure = projectStructure('meta');
        foreach ($statusCounts as $key => $c) {
            $pcid = projectCampaignId('meta', '', (string) $c['campaign_name']);
            if ($pcid === null) {
                continue;
            }
            $c['campaign_name'] = $metaStructure['campaigns'][$pcid];
            $pgid = projectAdgroupId('meta', $pcid, '', (string) $c['adset_name']);
            if ($pgid !== null) {
                $c['adset_name'] = $metaStructure['adgroups'][$pgid]['name'];
                $paid = projectAdId('meta', $pgid, '', (string) $c['ad_name']);
                if ($paid !== null) {
                    $c['ad_name'] = $metaStructure['ads'][$paid]['name'];
                }
            }
            if (!isset($usedKeys[$key])) {
                $out[] = [
                    'campaign_name' => $c['campaign_name'] ?: 'Unknown',
                    'adset_name' => $c['adset_name'] ?: 'Unknown',
                    'ad_name' => $c['ad_name'] ?: 'Unknown',
                    'spend' => 0.0,
                    'impressions' => 0,
                    'clicks' => 0,
                    'frequency' => 0.0,
                    'reach' => 0,
                    'in_qualified' => $c['in_qualified'],
                    'lost_post_qualified' => $c['lost_post_qualified'],
                    'non_qualified' => $c['non_qualified'],
                    'to_be_qualified' => $c['to_be_qualified'],
                    'qualified_total' => $c['qualified_total'],
                ];
                $usedKeys[$key] = true;
            }
        }

        echo json_encode([
            'success' => true,
            'since' => $resolvedSince,
            'until' => $resolvedUntil,
            'status_filter' => $statusFilter,
            'rows' => $out,
        ]);
    } catch (Throwable $e) {
        http_response_code(500);
        echo json_encode(['success' => false, 'error' => ['message' => $e->getMessage()]]);
    }
    exit;
}

/**
 * Build CRM lead metrics from the confirmed `lead` table.
 * This is intentionally independent of Meta Graph API availability.
 */
function normalizeMetaCampaignName($value): string
{
    $value = trim((string) $value);
    if ($value === '') {
        return '';
    }

    // Normalize whitespace and common Unicode dash variants so CRM and Meta
    // campaign names can be joined reliably.
    $value = preg_replace('/[\\x{2010}-\\x{2015}\\x{2212}]/u', '-', $value);
    $value = preg_replace('/\\s+/u', ' ', $value);

    return strtolower(trim($value));
}

function buildCrmMetaLeadData($databases, $resolvedSince, $resolvedUntil)
{
    $result = [
        'campaigns' => [],
        'trend' => [],
        'crm_source' => true,
        'databases' => []
    ];

    if (!is_array($databases)) {
        return $result;
    }

    $campaignMap = [];
    $trendMap = [];

    $start = $resolvedSince . ' 00:00:00';
    $end = $resolvedUntil . ' 23:59:59';

    $testCondition = "
        AND (lead_status IS NULL OR UPPER(TRIM(lead_status)) NOT IN ('TEST', 'JUNK'))
        AND (name IS NULL OR LOWER(TRIM(name)) NOT LIKE '%test%')
        AND (email IS NULL OR LOWER(TRIM(email)) NOT LIKE '%test%')
        AND (mobile IS NULL OR (
            LOWER(TRIM(mobile)) NOT LIKE '%test%'
            AND TRIM(mobile) NOT IN ('9999999999', '8888888888', '0000000000', '1234567890', '1111111111')
        ))";

    $sourceWhere = PQ_META_LEAD_SQL . " {$testCondition}";

    foreach ($databases as $dbName => $db) {
        if (!($db instanceof mysqli) || $db->connect_errno) {
            continue;
        }

        $result['databases'][] = $dbName;

        $sql = "SELECT
                    COALESCE(NULLIF(TRIM(campaign_name), ''), 'Unknown Campaign') AS campaign_name,
                    COUNT(*) AS leads,
                    COUNT(DISTINCT CASE
                            WHEN TRIM(UPPER(COALESCE(lead_status,'')))
                                 IN ('QUALIFIED','LOST POST QUALIFIED','LOST POST QUALIFICATION')
                            THEN " . PQ_PERSON_KEY_SQL . " END
                    ) AS qualified
                FROM `lead`
                WHERE createddate >= ?
                  AND createddate <= ?
                  AND {$sourceWhere}
                GROUP BY campaign_name";

        $stmt = $db->prepare($sql);
        if ($stmt) {
            $stmt->bind_param('ss', $start, $end);
            $stmt->execute();
            $res = $stmt->get_result();

            while ($row = $res->fetch_assoc()) {
                $name = trim((string) $row['campaign_name']);
                $key = normalizeMetaCampaignName($name);

                if ($key === '') {
                    $key = 'unknown campaign';
                }

                if (!isset($campaignMap[$key])) {
                    $campaignMap[$key] = [
                        'name' => $name,
                        'id' => '',
                        'platform' => 'Meta',
                        'spend' => 0.0,
                        'impressions' => 0,
                        'clicks' => 0,
                        'leads' => 0,
                        'qualified' => 0,
                        'walkins' => 0,
                        'bookings' => 0,
                        'cpql' => 0,
                        'cpsv' => 0,
                        'effective_status' => 'UNKNOWN',
                        'status' => 'UNKNOWN'
                    ];
                }

                $campaignMap[$key]['leads'] += (int) $row['leads'];
                $campaignMap[$key]['qualified'] += (int) $row['qualified'];
            }

            $stmt->close();
        }

        $trendSql = "SELECT
                        DATE(createddate) AS lead_date,
                        campaign_name,
                        COUNT(*) AS leads,
                        SUM(
                            CASE
                                WHEN TRIM(UPPER(COALESCE(lead_status,'')))
                                     IN ('QUALIFIED','LOST POST QUALIFIED')
                                THEN 1 ELSE 0
                            END
                        ) AS qualified
                     FROM `lead`
                     WHERE createddate >= ?
                       AND createddate <= ?
                       AND {$sourceWhere}
                     GROUP BY DATE(createddate), campaign_name
                     ORDER BY lead_date ASC";

        $stmt = $db->prepare($trendSql);
        if ($stmt) {
            $stmt->bind_param('ss', $start, $end);
            $stmt->execute();
            $res = $stmt->get_result();

            while ($row = $res->fetch_assoc()) {
                $date = $row['lead_date'];
                $result['trend_rows'][] = $row;

                if (!isset($trendMap[$date])) {
                    $trendMap[$date] = [
                        'date' => $date,
                        'spend' => 0.0,
                        'leads' => 0,
                        'qualified' => 0,
                        'walkins' => 0,
                        'impressions' => 0,
                        'clicks' => 0
                    ];
                }

                $trendMap[$date]['leads'] += (int) $row['leads'];
                $trendMap[$date]['qualified'] += (int) $row['qualified'];
            }

            $stmt->close();
        }
    }

    $result['campaigns'] = array_values($campaignMap);
    $result['trend'] = $trendMap;
    return $result;
}

// Main dashboard endpoint.
try {
    $resolvedSince = $since;
    $resolvedUntil = $until;
    if (empty($resolvedSince) || empty($resolvedUntil)) {
        $p = !empty($preset) ? $preset : (defined('DATE_PRESET') ? DATE_PRESET : 'last_30d');
        [$resolvedSince, $resolvedUntil] = getDatesFromPreset($p);
    }

    // Get Meta performance data first. Meta can legitimately return zero campaigns
    // while CRM still contains leads, so CRM data is merged below rather than discarded.
    $data = fetchMetaAdsData($preset, $since, $until);
    if (!is_array($data)) {
        $data = [];
    }

    $data['campaigns'] = is_array($data['campaigns'] ?? null) ? $data['campaigns'] : [];
    $data['trend'] = is_array($data['trend'] ?? null) ? $data['trend'] : [];

    $crm = buildCrmMetaLeadData(getCrmDatabaseConnections(), $resolvedSince, $resolvedUntil);

    // Merge CRM lead counts into Meta campaigns by campaign name.
    $crmByName = [];
    foreach ($crm['campaigns'] as $crmCamp) {
        $crmKey = normalizeMetaCampaignName($crmCamp['name']);
        if ($crmKey !== '') {
            $crmByName[$crmKey] = $crmCamp;
        }
    }

    $seen = [];
    foreach ($data['campaigns'] as &$camp) {
        $name = trim((string) ($camp['source_name'] ?? $camp['name'] ?? $camp['campaign'] ?? ''));
        $key = normalizeMetaCampaignName($name);
        $camp['platform'] = $camp['platform'] ?? 'Meta';
        if ($key !== '' && isset($crmByName[$key])) {
            $crmCamp = $crmByName[$key];

            // CRM is the authoritative source for lead lifecycle status.
            // Meta is authoritative for delivery metrics (spend, impressions, clicks).
            $camp['leads'] = (int) $crmCamp['leads'];
            $camp['qualified'] = (int) $crmCamp['qualified'];

            // Keep useful CRM fields available to the frontend.
            $camp['crm_leads'] = (int) $crmCamp['leads'];
            $camp['crm_qualified'] = (int) $crmCamp['qualified'];
            $camp['crm_source'] = 'lead';

            $seen[$key] = true;
        }
    }
    unset($camp);

    // If Meta returned no campaign, or a CRM campaign exists only in the DB,
    // append the real CRM campaign so the dashboard does not show an empty state.
    foreach ($crm['campaigns'] as $crmCamp) {
        $key = normalizeMetaCampaignName($crmCamp['name']);
        if ($key !== '' && !isset($seen[$key])) {
            $data['campaigns'][] = $crmCamp;
            $seen[$key] = true;
        }
    }

    // Daily CRM leads → this project's campaigns only (`campaigns` table). Lead campaign names are
    // matched to the Meta campaign ID first, so a campaign renamed in the table still keeps its leads.
    $leadNameToId = [];
    foreach ($data['campaigns'] as $c) {
        $n = normalizeMetaCampaignName((string) ($c['source_name'] ?? $c['name'] ?? $c['campaign'] ?? ''));
        if ($n !== '' && !empty($c['id'])) {
            $leadNameToId[$n] = (string) $c['id'];
        }
    }
    $isProjectLeadName = function (string $name) use ($leadNameToId): bool {
        return metaIsProjectCampaign($leadNameToId[normalizeMetaCampaignName($name)] ?? null, $name);
    };
    $crm['trend'] = [];
    $awLeadTrend = [];   // daily leads of awareness campaigns (for the Performance / Awareness tabs)
    foreach (($crm['trend_rows'] ?? []) as $row) {
        $ln = trim((string) ($row['campaign_name'] ?? ''));
        if (!$isProjectLeadName($ln)) {
            continue;
        }
        $date = $row['lead_date'];
        $crm['trend'][$date] = $crm['trend'][$date] ?? ['leads' => 0, 'qualified' => 0];
        $crm['trend'][$date]['leads'] += (int) $row['leads'];
        $crm['trend'][$date]['qualified'] += (int) $row['qualified'];
        if (pqCampaignType('meta', $leadNameToId[normalizeMetaCampaignName($ln)] ?? null, $ln) === 'awareness') {
            $awLeadTrend[$date] = $awLeadTrend[$date] ?? ['leads' => 0, 'qualified' => 0];
            $awLeadTrend[$date]['leads'] += (int) $row['leads'];
            $awLeadTrend[$date]['qualified'] += (int) $row['qualified'];
        }
    }

    // Merge CRM daily leads/qualified with Meta daily spend metrics.
    $mergedTrend = [];
    foreach ($data['trend'] as $trendRow) {
        $date = $trendRow['date'] ?? '';
        if ($date === '')
            continue;
        $mergedTrend[$date] = $trendRow;
    }

    foreach ($crm['trend'] as $date => $crmTrendRow) {
        if (!isset($mergedTrend[$date])) {
            $mergedTrend[$date] = [
                'date' => $date,
                'spend' => 0.0,
                'impressions' => 0,
                'clicks' => 0,
                'leads' => 0,
                'qualified' => 0,
                'walkins' => 0
            ];
        }

        $mergedTrend[$date]['leads'] = (int) ($crmTrendRow['leads'] ?? 0);
        $mergedTrend[$date]['qualified'] = (int) ($crmTrendRow['qualified'] ?? 0);
    }

    ksort($mergedTrend);
    $data['trend'] = array_values($mergedTrend);

    $crmTotalLeads = 0;
    $crmTotalQualified = 0;
    foreach ($crm['campaigns'] as $crmCamp) {
        if (!$isProjectLeadName((string) ($crmCamp['name'] ?? ''))) {
            continue;
        }
        $crmTotalLeads += (int) ($crmCamp['leads'] ?? 0);
        $crmTotalQualified += (int) ($crmCamp['qualified'] ?? 0);
    }

    // Only this project's campaigns (the `campaigns` table) — also covers the CRM-only rows added above.
    $prevFilter = is_array($data['campaign_filter'] ?? null) ? $data['campaign_filter'] : [];
    // the "Unmapped leads (no campaign)" row (app/Ads/fetch_meta.php, step 5c) is not a project campaign — keep it
    $unmappedRows = array_values(array_filter($data['campaigns'], fn($c) => ($c['data_source'] ?? '') === 'crm_unmapped'));
    [$data['campaigns'], $finalFilter] = metaApplyProjectFilter($data['campaigns']);
    foreach ($unmappedRows as $u) {
        $data['campaigns'][] = $u;
    }
    $finalFilter['hidden_count'] = max((int) $finalFilter['hidden_count'], (int) ($prevFilter['hidden_count'] ?? 0));   // leads-only rows are mostly the same hidden campaigns
    $finalFilter['hidden_spend'] = round($finalFilter['hidden_spend'] + (float) ($prevFilter['hidden_spend'] ?? 0), 2);
    $data['campaign_filter'] = $finalFilter;

    // All / Performance / Awareness tab (and Users & Roles → Campaign types): only the campaigns of the view
    [$data['campaigns'], $aw] = pqApplyView('meta', $data['campaigns'], 'id', ['name', 'campaign', 'campaign_name']);
    if ($aw['view'] !== 'all') {
        // the daily chart: awareness campaigns' own numbers, or everything minus them
        $awT = (array) ($data['awareness_trend'] ?? []);
        foreach ($awLeadTrend as $d => $l) {
            $awT[$d] = ($awT[$d] ?? ['spend' => 0.0, 'impressions' => 0, 'clicks' => 0]) + ['leads' => 0, 'qualified' => 0];
            $awT[$d]['leads'] = $l['leads'];
            $awT[$d]['qualified'] = $l['qualified'];
        }
        foreach ($data['trend'] as &$t) {
            $a = $awT[(string) ($t['date'] ?? '')] ?? [];
            foreach (['spend', 'impressions', 'clicks', 'leads', 'qualified'] as $k) {
                $v = (float) ($a[$k] ?? 0);
                $t[$k] = $aw['view'] === 'awareness' ? $v : max(0, (float) ($t[$k] ?? 0) - $v);
                $t[$k] = $k === 'spend' ? round($t[$k], 2) : (int) round($t[$k]);
            }
            if ($aw['view'] === 'awareness') {
                $t['walkins'] = 0;
            }
        }
        unset($t);
        $data['summary'] = pqSumRows($data['campaigns']);
    }
    unset($data['awareness_trend']);
    $data['awareness'] = $aw;

    $data['crm_lead_source'] = 'lead';
    $data['crm_date_range'] = ['since' => $resolvedSince, 'until' => $resolvedUntil];
    $data['crm_totals'] = [
        'leads' => $crmTotalLeads,
        'qualified' => $crmTotalQualified
    ];

    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode([
        'error' => [
            'message' => $e->getMessage()
        ]
    ]);
}
