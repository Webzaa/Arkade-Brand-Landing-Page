<?php
/**
 * column_prefs_api.php — saved table layouts ("Modify columns") per user, used by js/column_picker.js on the
 * Meta and Google dashboards. Table `pq_user_prefs` (username + pref_key → JSON), created on first use in the
 * master-tables database.
 *
 *   GET  ?keys=meta,google           → {success, prefs: {meta: {...} | null, google: ...}}
 *   POST {key, value}                → saves (value null = back to the default layout)
 */
ob_start();
ini_set('display_errors', '0');
session_start();

function cpJson(array $p, int $code = 200): never
{
    while (ob_get_level()) {
        ob_end_clean();
    }
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    header('X-Content-Type-Options: nosniff');
    echo json_encode($p, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}
if (($_SESSION['user_logged'] ?? '') !== 'Y') {
    cpJson(['success' => false, 'error' => 'Please sign in again.'], 401);
}
$user = mb_substr((string) ($_SESSION['username'] ?? $_SESSION['user'] ?? $_SESSION['uid'] ?? 'user'), 0, 100);
session_write_close();

require_once dirname(__DIR__, 2) . '/app/Ads/master_tables.php';

try {
    $db = masterDb();
    if (!$db) {
        cpJson(['success' => false, 'error' => 'Database not reachable.'], 500);
    }
    $db->query("CREATE TABLE IF NOT EXISTS `pq_user_prefs` (
        `username`   VARCHAR(100) NOT NULL,
        `pref_key`   VARCHAR(100) NOT NULL,
        `value`      MEDIUMTEXT   NULL,
        `updated_at` DATETIME     NULL,
        PRIMARY KEY (`username`, `pref_key`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci");
    $keyOk = fn($k) => is_string($k) && preg_match('/^[a-z0-9_:-]{1,60}$/', $k);

    if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
        $in = json_decode((string) file_get_contents('php://input'), true) ?: [];
        $key = 'columns:' . (string) ($in['key'] ?? '');
        if (!$keyOk((string) ($in['key'] ?? ''))) {
            cpJson(['success' => false, 'error' => 'Bad key.'], 400);
        }
        $value = $in['value'] ?? null;
        if ($value === null) {
            $st = $db->prepare('DELETE FROM `pq_user_prefs` WHERE username = ? AND pref_key = ?');
            $st->bind_param('ss', $user, $key);
        } else {
            $v = json_encode($value, JSON_UNESCAPED_UNICODE);
            if (strlen($v) > 60000) {
                cpJson(['success' => false, 'error' => 'Layout too large.'], 400);
            }
            $now = date('Y-m-d H:i:s');
            $st = $db->prepare('REPLACE INTO `pq_user_prefs` (username, pref_key, value, updated_at) VALUES (?, ?, ?, ?)');
            $st->bind_param('ssss', $user, $key, $v, $now);
        }
        $st->execute();
        cpJson(['success' => true]);
    }

    $out = [];
    foreach (array_slice(explode(',', (string) ($_GET['keys'] ?? '')), 0, 10) as $k) {
        if (!$keyOk($k)) {
            continue;
        }
        $pk = 'columns:' . $k;
        $st = $db->prepare('SELECT value FROM `pq_user_prefs` WHERE username = ? AND pref_key = ?');
        $st->bind_param('ss', $user, $pk);
        $st->execute();
        $r = $st->get_result()->fetch_assoc();
        $out[$k] = $r ? json_decode((string) $r['value'], true) : null;
    }
    cpJson(['success' => true, 'prefs' => $out]);
} catch (Throwable $e) {
    error_log('[column_prefs_api] ' . $e->getMessage());
    cpJson(['success' => false, 'error' => $e->getMessage()], 500);
}
