/**
 * email_report_pdf.js — All Platforms → Reports → Daily / Weekly / Monthly report as a PDF.
 *
 * The PDF is the same combined Meta + Google report the morning email sends:
 *   1. loads meta_performance_report.php and google_performance_report.php (same period as the email)
 *   2. email_report_api.php builds the email HTML with the cron job's own builder
 *   3. the HTML is drawn in a hidden frame and cut into A4 pages between table rows (never through a row)
 *
 *   EmailReportPDF.export({ period: 'daily'|'weekly'|'monthly', base: 'ads/', onStatus: fn[, campaigns] }) → Promise
 *   Asks first "All campaigns or select campaigns?" (js/report_picker.js) unless `campaigns` is given; null when cancelled.
 * Needs html2canvas + jsPDF — loaded from cdnjs when the page doesn't have them yet.
 */
(function () {
    'use strict';
    const WIDTH = 760;                       // px the email is drawn at (its table is 680 wide)
    const TITLE = { daily: 'Daily', weekly: 'Weekly', monthly: 'Monthly' };

    // "All campaigns or select campaigns?" — js/report_picker.js, next to this file
    const HERE = (document.currentScript && document.currentScript.src || '').replace(/[^/]*$/, '');
    async function pickCampaigns(o, campaignsApi, title) {
        if (o.campaigns !== undefined) return o.campaigns;          // the caller chose already (null = all)
        if (!window.PQReportPicker) {
            await new Promise((ok, fail) => {
                const s = document.createElement('script');
                s.src = HERE + 'report_picker.js?v=4'; s.onload = ok; s.onerror = () => fail(new Error('Could not load the campaign picker.'));
                document.head.appendChild(s);
            });
        }
        return window.PQReportPicker.ask({ api: campaignsApi, title });
    }

    function loadScript(src) {
        return new Promise((ok, fail) => {
            const s = document.createElement('script');
            s.src = src; s.onload = ok; s.onerror = () => fail(new Error('Could not load ' + src.split('/').pop()));
            document.head.appendChild(s);
        });
    }
    async function libs() {
        if (typeof window.html2canvas === 'undefined') await loadScript('https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js');
        if (!(window.jspdf && window.jspdf.jsPDF) && !window.jsPDF) await loadScript('https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js');
        return (window.jspdf && window.jspdf.jsPDF) || window.jsPDF;
    }

    async function getJson(url, opts) {
        const res = await fetch(url, Object.assign({ credentials: 'same-origin', cache: 'no-store', headers: { Accept: 'application/json' } }, opts || {}));
        const d = await res.json().catch(() => null);
        if (!res.ok || !d || d.success === false) {
            const detail = d && d.debug && d.debug.message ? ` (${d.debug.message})` : '';
            throw new Error(((d && d.error) || `HTTP ${res.status}`) + detail);
        }
        return d;
    }

    /** Draws the email in a hidden same-origin frame; resolves with { doc, frame }. */
    function drawFrame(html, base) {
        return new Promise((resolve, reject) => {
            const f = document.createElement('iframe');
            f.setAttribute('aria-hidden', 'true');
            f.style.cssText = `position:fixed;left:-${WIDTH + 100}px;top:0;width:${WIDTH}px;height:1200px;border:0;visibility:hidden;`;
            document.body.appendChild(f);
            const doc = f.contentDocument;
            doc.open();
            doc.write(html);
            doc.close();
            const ready = async () => {
                try {
                    // the logo is an https URL on another site (fine in email, blocks the PDF) → use this site's copy
                    doc.querySelectorAll('img').forEach(img => {
                        try {
                            if (new URL(img.src, location.href).origin !== location.origin) img.src = base + 'images/webzaa-logo.png';
                        } catch (e) { /* keep it */ }
                    });
                    await Promise.all([...doc.images].map(img => img.complete ? 0 : new Promise(r => { img.onload = img.onerror = r; })));
                    f.style.height = doc.documentElement.scrollHeight + 'px';
                    resolve({ doc, frame: f });
                } catch (e) { reject(e); }
            };
            if (doc.readyState === 'complete') setTimeout(ready, 50); else f.onload = ready;
        });
    }

    /** y positions (px) where a page may end: the bottom of every table row and block. */
    function breakPoints(doc) {
        const ys = new Set();
        doc.querySelectorAll('tr, div, table').forEach(el => {
            const r = el.getBoundingClientRect();
            if (r.height > 0) ys.add(Math.round(r.bottom));
        });
        return [...ys].sort((a, b) => a - b);
    }

    async function exportPdf(opt) {
        const o = Object.assign({ period: 'daily', base: 'ads/', onStatus: () => {} }, opt || {});
        if (!TITLE[o.period]) throw new Error('Unknown report: ' + o.period);
        const pick = await pickCampaigns(o, o.base + 'report_campaigns_api.php', TITLE[o.period] + ' report');
        if (pick === false) return null;                            // cancelled
        o.onStatus('Loading Meta + Google…');
        const JsPDF = await libs();

        // 1. both platform reports (a platform that fails is left out and named in the report)
        const reports = {};
        const errors = [];
        await Promise.all(['meta', 'google'].map(async p => {
            try {
                reports[p] = await getJson(`${o.base}${p}_performance_report.php?period=${encodeURIComponent(o.period)}`);
            } catch (e) { errors.push(`${p === 'meta' ? 'Meta' : 'Google'}: ${e.message}`); }
        }));
        if (!Object.keys(reports).length) throw new Error('Could not load the reports. ' + errors.join(' · '));

        // 2. the email HTML
        o.onStatus('Building report…');
        const d = await getJson(`${o.base}email_report_api.php`, {
            method: 'POST', headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
            body: JSON.stringify({ period: o.period, reports, campaigns: pick ? { meta: pick.meta, google: pick.google } : null })
        });

        // 3. HTML → A4 pages
        o.onStatus('Building PDF…');
        const { doc, frame } = await drawFrame(d.html, o.base);
        try {
            // stop just under the email card (its outer grey padding would only add an empty last page)
            const card = doc.querySelector('table[width="680"]');
            const totalH = card ? Math.min(doc.documentElement.scrollHeight, Math.ceil(card.getBoundingClientRect().bottom) + 14)
                                : doc.documentElement.scrollHeight;
            const canvas = await window.html2canvas(doc.body, {
                scale: 2, backgroundColor: '#f4f4f5', useCORS: true, logging: false,
                width: WIDTH, height: totalH, windowWidth: WIDTH, windowHeight: totalH
            });
            const scale = canvas.width / WIDTH;
            const pdf = new JsPDF('p', 'mm', 'a4');
            const W = 210, H = 297, M = 8, FOOT = 7, CW = W - 2 * M;
            const mmPerPx = CW / WIDTH;
            const pagePx = Math.floor((H - 2 * M - FOOT) / mmPerPx);
            const cuts = breakPoints(doc);
            let start = 0, first = true;
            while (first || start < totalH - 24) {          // a leftover under 24px is only the card's bottom padding
                let end = start + pagePx;
                if (end >= totalH) {
                    end = totalH;
                } else {
                    const ok = cuts.filter(y => y > start + pagePx * 0.4 && y <= end);
                    if (ok.length) end = ok[ok.length - 1];
                }
                const slice = document.createElement('canvas');
                slice.width = canvas.width;
                slice.height = Math.max(1, Math.round((end - start) * scale));
                const ctx = slice.getContext('2d');
                ctx.fillStyle = '#f4f4f5';
                ctx.fillRect(0, 0, slice.width, slice.height);
                ctx.drawImage(canvas, 0, Math.round(start * scale), canvas.width, slice.height, 0, 0, canvas.width, slice.height);
                if (!first) pdf.addPage();
                pdf.addImage(slice.toDataURL('image/jpeg', 0.92), 'JPEG', M, M, CW, (end - start) * mmPerPx);
                first = false;
                start = end;
            }
            const pages = pdf.getNumberOfPages();
            const footer = d.subject.length > 110 ? d.subject.slice(0, 107) + '…' : d.subject;
            for (let i = 1; i <= pages; i++) {
                pdf.setPage(i);
                pdf.setFontSize(7.5);
                pdf.setTextColor(120);
                pdf.text(footer, M, H - 4);
                pdf.text(`${i} / ${pages}`, W - M, H - 4, { align: 'right' });
            }
            const label = (reports.meta || reports.google).current.label || '';
            const safe = s => String(s).replace(/[^A-Za-z0-9]+/g, '_').replace(/^_|_$/g, '');
            pdf.save(`Meta_Google_${TITLE[o.period]}_Report${pick ? '_' + pick.count + '_campaigns' : ''}_${safe(label) || o.period}.pdf`);
            return { subject: d.subject, missing: d.missing || [], errors };
        } finally {
            frame.remove();
        }
    }

    window.EmailReportPDF = { export: exportPdf };
})();
