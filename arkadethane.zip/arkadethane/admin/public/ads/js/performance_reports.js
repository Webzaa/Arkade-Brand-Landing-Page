/*
 * Ads performance reports for dashboard.php (Meta) and googledashboard.php (Google).
 *
 *   openPerformanceReport('meta' | 'google', 'daily' | 'weekly' | 'monthly' [, asOf])
 *       Opens a report modal (KPIs, comparison, chart, campaign table) with Excel + PDF export.
 *
 *   exportMonthlyDeck('meta' | 'google' [, asOf [, 'YYYY-MM']])
 *       Builds a landscape slide-style PDF deck for the last full month vs the month before.
 *
 * Shortcuts: openMetaPerformanceReport(period), exportMetaMonthlyDeck(),
 *            openGooglePerformanceReport(period), exportGoogleMonthlyDeck().
 *
 * Needs Chart.js 4, html2canvas, jsPDF, html2pdf.js and xlsx-js-style on the page.
 * Data comes from meta_performance_report.php / google_performance_report.php.
 * Optional: set window.REPORT_ACCOUNT_NAMES = ['Account A', …] to show account names on the deck cover.
 */
(function () {
    'use strict';

    // Resolve endpoints relative to this script (ads/js/ → ads/) so it works from
    // /dashboard.php as well as /ads/googledashboard.php.
    const SCRIPT_BASE = (document.currentScript && document.currentScript.src) || window.location.href;
    const ENDPOINTS = {
        meta: new URL('../meta_performance_report.php', SCRIPT_BASE).href,
        google: new URL('../google_performance_report.php', SCRIPT_BASE).href,
    };

    /* ------------------------------------------------------------------
     * Formatting
     * ------------------------------------------------------------------ */
    const isNum = v => v !== null && v !== undefined && v !== '' && !isNaN(Number(v));
    const money = (v, dp = 2) => isNum(v)
        ? '₹' + Number(v).toLocaleString('en-IN', {minimumFractionDigits: dp, maximumFractionDigits: dp})
        : '—';
    const num = v => isNum(v) ? Math.round(Number(v)).toLocaleString('en-IN') : '—';
    const pctVal = v => isNum(v) ? Number(v).toFixed(2) + '%' : '—';
    const esc = v => String(v ?? '').replace(/[&<>"']/g, c => ({'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'}[c]));

    const METRICS = {
        spend:       {label: 'Spend',           short: 'Spend',  fmt: v => money(v, 0), better: 'neutral'},
        impressions: {label: 'Impressions',     short: 'Impr.',  fmt: num,              better: 'up'},
        clicks:      {label: 'Clicks',          short: 'Clicks', fmt: num,              better: 'up'},
        ctr:         {label: 'CTR',             short: 'CTR',    fmt: pctVal,           better: 'up'},
        cpc:         {label: 'CPC',             short: 'CPC',    fmt: v => money(v, 2), better: 'down'},
        leads:       {label: 'Leads',           short: 'Leads',  fmt: num,              better: 'up'},
        cpl:         {label: 'CPL',             short: 'CPL',    fmt: v => money(v, 0), better: 'down'},
        qualified:   {label: 'Qualified Leads', short: 'QL',     fmt: num,              better: 'up'},
        cpql:        {label: 'CPQL',            short: 'CPQL',   fmt: v => money(v, 0), better: 'down'},
        site_visits: {label: 'Site Visits',     short: 'SV',     fmt: num,              better: 'up'},
        cpsv:        {label: 'CPSV',            short: 'CPSV',   fmt: v => money(v, 0), better: 'down'},
    };

    const PERIOD_METRICS = {
        daily:   ['spend', 'leads', 'cpl', 'cpc', 'impressions', 'ctr'],
        weekly:  ['spend', 'leads', 'cpl', 'cpc', 'impressions', 'ctr', 'qualified', 'cpql', 'site_visits', 'cpsv'],
        monthly: ['spend', 'leads', 'cpl', 'cpc', 'impressions', 'ctr', 'qualified', 'cpql', 'site_visits', 'cpsv'],
    };
    // Users & Roles → "Hide numbers": metrics this role may not see are left out of every report / deck / Excel
    const HIDE = window.PQ_HIDE_METRICS || [];
    const hid = k => HIDE.indexOf(k === 'site_visits' ? 'sitevisits' : k) >= 0;
    Object.keys(PERIOD_METRICS).forEach(p => { PERIOD_METRICS[p] = PERIOD_METRICS[p].filter(k => !hid(k)); });
    /** Is a column / row label one of the hidden metrics? (QL, CPQL Δ, SV, Site visits …) */
    const hiddenLabel = label => !!HIDE.length && typeof window.pqMetricHidden === 'function'
        && window.pqMetricHidden(String(label || '').replace(/[ΔΔ%]|\(.*?\)/g, '').trim());

    const PERIOD_TITLE = {daily: 'Daily Report', weekly: 'Weekly Report', monthly: 'Monthly Report'};
    const COMPARE_LABEL = {daily: 'vs previous day', weekly: 'vs previous week', monthly: 'vs previous month'};

    const TONE_DARK = {good: '#34d399', bad: '#f87171', neutral: '#94a3b8'};
    const TONE_LIGHT = {good: '#047857', bad: '#b91c1c', neutral: '#64748b'};

    function tone(pct, better) {
        if (!isNum(pct) || Number(pct) === 0 || better === 'neutral') return 'neutral';
        return (better === 'up' ? pct > 0 : pct < 0) ? 'good' : 'bad';
    }

    function changeText(pct) {
        if (!isNum(pct)) return 'n/a';
        const p = Number(pct);
        return `${p > 0 ? '▲' : p < 0 ? '▼' : '■'} ${Math.abs(p).toFixed(1)}%`;
    }

    /** "Selected campaigns only (3): A · B · C" — when the report covers chosen campaigns (data.selection). */
    function selectionLine(data, style) {
        const s = data.selection;
        if (!s || !s.names) return '';
        const n = s.names.length;
        return `<div style="${style}">Selected campaigns only (${n}): ${s.names.slice(0, 5).map(esc).join(' · ')}${n > 5 ? ' +' + (n - 5) + ' more' : ''}</div>`;
    }

    /* ------------------------------------------------------------------
     * Data
     * ------------------------------------------------------------------ */
    async function fetchReport(platform, period, asOf, month, pick) {
        const endpoint = ENDPOINTS[platform];
        if (!endpoint) throw new Error(`Unknown platform: ${platform}`);
        const params = new URLSearchParams({period});
        if (asOf) params.set('as_of', asOf);
        if (month) params.set('month', month);   // monthly: that month (current month = to date)
        if (pick && (pick[platform] || []).length) params.set('campaigns', pick[platform].join(','));   // "Select campaigns"

        const res = await fetch(`${endpoint}?${params.toString()}`, {
            credentials: 'same-origin',
            cache: 'no-store',
            headers: {Accept: 'application/json'},
        });
        const data = await res.json().catch(() => null);

        if (!res.ok || !data || !data.success) {
            const detail = data && data.debug && data.debug.message ? ` (${data.debug.message})` : '';
            throw new Error(((data && data.error) || `Report request failed (HTTP ${res.status}).`) + detail);
        }
        return data;
    }

    function setBusy(label) {
        const btn = document.getElementById('export-dropdown-btn');
        if (!btn) return () => {};
        const original = btn.innerHTML;
        btn.disabled = true;
        btn.innerHTML = label;
        return () => {
            btn.disabled = false;
            btn.innerHTML = original;
        };
    }

    const nextFrames = () => new Promise(r => requestAnimationFrame(() => requestAnimationFrame(r)));

    /** Factual, rule-based summary lines built from the numbers (no guesses). */
    function buildTakeaways(data, period) {
        const c = data.current.totals;
        const p = data.previous.totals;
        const ch = data.changes;
        const out = [];

        const line = k => {
            const m = METRICS[k];
            if (hid(k) || !isNum(c[k])) return;
            const pct = ch[k];
            if (!isNum(pct)) {
                out.push(`${m.label} was ${m.fmt(c[k])}; there is no comparable figure for ${data.previous.label}.`);
            } else if (Number(pct) === 0) {
                out.push(`${m.label} held steady at ${m.fmt(c[k])}.`);
            } else {
                out.push(`${m.label} ${pct > 0 ? 'rose' : 'fell'} ${Math.abs(pct).toFixed(1)}% to ${m.fmt(c[k])} (from ${m.fmt(p[k])}).`);
            }
        };

        ['spend', 'leads', 'cpl'].forEach(line);
        if (period !== 'daily') ['cpql', 'cpsv'].forEach(line);

        const live = (data.campaigns || []).filter(x => Number(x.current.spend) > 0);
        const useQl = period !== 'daily' && !hid('qualified') && !hid('cpql');
        const efficient = live
            .filter(x => useQl ? x.current.qualified >= 2 && isNum(x.current.cpql) : x.current.leads >= 2 && isNum(x.current.cpl))
            .sort((a, b) => useQl ? a.current.cpql - b.current.cpql : a.current.cpl - b.current.cpl)[0];
        if (efficient) {
            out.push(useQl
                ? `Most efficient campaign on qualified leads: “${efficient.campaign_name}” at ${money(efficient.current.cpql, 0)} CPQL (${num(efficient.current.qualified)} QL).`
                : `Most efficient campaign: “${efficient.campaign_name}” at ${money(efficient.current.cpl, 0)} CPL (${num(efficient.current.leads)} leads).`);
        }

        const noLeads = live.filter(x => Number(x.current.leads) === 0).sort((a, b) => b.current.spend - a.current.spend)[0];
        if (noLeads) {
            out.push(`“${noLeads.campaign_name}” spent ${money(noLeads.current.spend, 0)} with no CRM leads.`);
        }

        const un = data.unattributed && data.unattributed.current ? Number(data.unattributed.current.leads) : 0;
        if (un > 0) {
            out.push(`${num(un)} CRM lead(s) did not match a ${data.platform} campaign. They are counted in totals only.`);
        }
        return out;
    }

    /** Campaigns that need a look: spend with no leads, CPL up >25%, or leads but no qualified. */
    function buildWatchlist(data, period) {
        const items = [];
        (data.campaigns || []).forEach(x => {
            const c = x.current;
            if (!(Number(c.spend) > 0)) return;
            const reasons = [];
            if (Number(c.leads) === 0) reasons.push('Spend with no leads');
            if (isNum(x.changes.cpl) && x.changes.cpl > 25) reasons.push(`CPL up ${x.changes.cpl.toFixed(0)}%`);
            if (period !== 'daily' && !hid('qualified') && Number(c.leads) >= 5 && Number(c.qualified) === 0) reasons.push('No qualified leads');
            if (period !== 'daily' && !hid('cpql') && isNum(x.changes.cpql) && x.changes.cpql > 25) reasons.push(`CPQL up ${x.changes.cpql.toFixed(0)}%`);
            if (reasons.length) items.push({...x, reasons});
        });
        return items.sort((a, b) => b.current.spend - a.current.spend);
    }

    /* ------------------------------------------------------------------
     * Report modal (daily / weekly / monthly)
     * ------------------------------------------------------------------ */
    window.openPerformanceReport = async function (platform, period, asOf, pick) {
        platform = String(platform || 'meta').toLowerCase();
        period = PERIOD_METRICS[period] ? period : 'daily';
        const restore = setBusy('⏳ Building report…');
        let chart = null;

        try {
            const data = await fetchReport(platform, period, asOf, null, pick);
            const P = data.platform || 'Ads';
            const keys = PERIOD_METRICS[period];
            const cur = data.current.totals;
            const prev = data.previous.totals;
            const ch = data.changes;
            const curLabel = data.current.label;
            const prevLabel = data.previous.label;

            const cell = 'border:1px solid #334155;padding:8px 10px;text-align:right;white-space:nowrap;';
            const head = cell + 'background:#18263c;color:#a9bad0;font-size:10.5px;text-transform:uppercase;letter-spacing:.04em;';

            const kpiCards = keys.map(k => {
                const m = METRICS[k];
                const t = tone(ch[k], m.better);
                return `<article style="background:#172033;border:1px solid #334155;border-radius:10px;padding:14px;">
                    <div style="font-size:11px;color:#94a3b8;text-transform:uppercase;letter-spacing:.05em;">${m.label}</div>
                    <strong style="display:block;font-size:21px;margin:7px 0 4px;color:#f1f5f9;">${m.fmt(cur[k])}</strong>
                    <div style="display:flex;justify-content:space-between;gap:8px;font-size:11.5px;">
                        <span style="color:#7c8aa0;">Prev ${m.fmt(prev[k])}</span>
                        <span style="color:${TONE_DARK[t]};font-weight:700;">${changeText(ch[k])}</span>
                    </div>
                </article>`;
            }).join('');

            const takeaways = buildTakeaways(data, period);

            const campaignCell = (row, k) => {
                const m = METRICS[k];
                const t = tone(row.changes[k], m.better);
                return `<td style="${cell}">${m.fmt(row.current[k])}<div style="font-size:10px;color:${TONE_DARK[t]};margin-top:2px;">${changeText(row.changes[k])}</div></td>`;
            };

            const campaignRows = (data.campaigns || []).map(r => `<tr>
                <td style="${cell}text-align:left;white-space:normal;min-width:220px;"><strong>${esc(r.campaign_name)}</strong>
                    <div style="color:#7c8aa0;font-size:10px;margin-top:3px;">ID ${esc(r.campaign_id)}</div></td>
                ${keys.map(k => campaignCell(r, k)).join('')}
            </tr>`).join('');

            const totalRow = `<tr style="background:#202d43;font-weight:700;">
                <td style="${cell}text-align:left;">${data.selection ? 'Selected campaigns' : 'All campaigns (incl. unmatched CRM leads)'}</td>
                ${keys.map(k => campaignCell({current: cur, changes: ch}, k)).join('')}
            </tr>`;

            const warnings = (data.warnings || []).length
                ? `<div style="margin:0 0 14px;padding:10px 12px;border:1px solid #92400e;background:#451a0333;color:#fcd34d;border-radius:8px;font-size:12px;">${data.warnings.map(esc).join('<br>')}</div>`
                : '';

            const chartTitle = period === 'daily'
                ? 'Spend and leads by campaign (top 12 by spend)'
                : `Daily spend and leads · ${esc(curLabel)} (previous period leads dashed)`;

            const modalId = 'meta-performance-modal';
            document.getElementById(modalId)?.remove();
            const modal = document.createElement('div');
            modal.id = modalId;
            modal.style.cssText = 'position:fixed;inset:0;z-index:999999;background:rgba(2,6,23,.86);padding:14px;display:flex;align-items:center;justify-content:center;';
            modal.innerHTML = `
<section id="meta-performance-content" style="width:min(1500px,100%);max-height:95vh;overflow:auto;background:#0f172a;color:#e2e8f0;border:1px solid #334155;border-radius:16px;padding:22px;font:14px 'Sora',Arial,sans-serif;">
  <header style="display:flex;justify-content:space-between;gap:14px;align-items:flex-start;flex-wrap:wrap;margin-bottom:16px;">
    <div>
      <img src="${logoUrl()}" alt="Webzaa" style="width:66px;height:48px;background:#fff;border-radius:8px;padding:5px;margin-bottom:10px;display:block;">
      <div style="color:#E84E24;font-size:11px;font-weight:700;letter-spacing:.1em;text-transform:uppercase;">${esc(P)} Ads · ${PERIOD_TITLE[period]}</div>
      <h2 style="margin:6px 0 4px;font-size:22px;">${esc(curLabel)} <span style="color:#94a3b8;font-weight:400;font-size:15px;">${COMPARE_LABEL[period]} (${esc(prevLabel)})</span></h2>
      <div style="color:#7c8aa0;font-size:11.5px;">Generated ${esc(data.generated_at)} · Asia/Kolkata</div>
      ${selectionLine(data, 'color:#fcd34d;font-size:12px;margin-top:6px;')}
    </div>
    <div class="mpr-actions" style="display:flex;gap:8px;flex-wrap:wrap;">
      <button id="mpr-excel" style="padding:9px 13px;border:1px solid #475569;border-radius:7px;background:#1e293b;color:#e2e8f0;cursor:pointer;font-weight:600;">Export Excel</button>
      <button id="mpr-pdf" style="padding:9px 13px;border:0;border-radius:7px;background:#E84E24;color:#ffffff;font-weight:700;cursor:pointer;">Export PDF</button>
      <button id="mpr-close" style="padding:9px 13px;border:1px solid #475569;border-radius:7px;background:#1e293b;color:#e2e8f0;cursor:pointer;">Close</button>
    </div>
  </header>

  ${warnings}

  <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(165px,1fr));gap:10px;margin-bottom:18px;">${kpiCards}</div>

  ${takeaways.length ? `<div style="margin-bottom:18px;padding:14px 16px;border:1px solid #334155;border-radius:10px;background:#172033;">
    <div style="font-size:12px;font-weight:700;color:#E84E24;text-transform:uppercase;letter-spacing:.06em;margin-bottom:8px;">Summary</div>
    <ul style="margin:0;padding-left:18px;line-height:1.7;font-size:13px;color:#cbd5e1;">${takeaways.map(t => `<li>${esc(t)}</li>`).join('')}</ul>
  </div>` : ''}

  <div style="background:#111c30;border:1px solid #334155;border-radius:12px;padding:14px;margin-bottom:20px;">
    <div style="font-size:13px;font-weight:600;margin-bottom:10px;">${chartTitle}</div>
    <div style="height:320px;"><canvas id="mpr-chart"></canvas></div>
  </div>

  <h3 style="font-size:16px;margin:0 0 6px;">Campaign breakdown · ${esc(curLabel)}</h3>
  <p style="margin:0 0 10px;color:#94a3b8;font-size:12px;">Each cell shows the ${esc(curLabel)} value and its change ${COMPARE_LABEL[period]}. Sorted by spend.</p>
  <div style="overflow-x:auto;">
    <table style="width:100%;border-collapse:collapse;font-size:12px;background:#111c30;">
      <thead><tr><th style="${head}text-align:left;">Campaign</th>${keys.map(k => `<th style="${head}">${METRICS[k].short}</th>`).join('')}</tr></thead>
      <tbody>${campaignRows || `<tr><td colspan="${keys.length + 1}" style="${cell}text-align:center;color:#94a3b8;">No ${esc(P)} campaign delivery in these periods.</td></tr>`}${totalRow}</tbody>
    </table>
  </div>

  <div style="margin-top:14px;color:#7c8aa0;font-size:11px;line-height:1.6;">
    Spend: ${esc(data.definitions?.spend || '')} Leads: ${esc(data.definitions?.leads || '')}
    ${period !== 'daily' && !hid('qualified') ? `Qualified = ${esc(data.definitions?.qualified || '')}.` : ''} ${period !== 'daily' && !hid('site_visits') ? `Site visit = ${esc(data.definitions?.site_visits || '')}.` : ''}
  </div>
</section>`;
            document.body.appendChild(modal);

            const onKey = e => { if (e.key === 'Escape') close(); };
            const close = () => {
                if (chart) chart.destroy();
                chart = null;
                document.removeEventListener('keydown', onKey);
                modal.remove();
            };
            document.addEventListener('keydown', onKey);
            modal.querySelector('#mpr-close').addEventListener('click', close);
            modal.addEventListener('click', e => { if (e.target === modal) close(); });

            if (typeof Chart !== 'undefined') {
                chart = new Chart(modal.querySelector('#mpr-chart'), buildChartConfig(data, period, 'dark'));
            }

            modal.querySelector('#mpr-excel').addEventListener('click', () => exportReportExcel(data, period));

            modal.querySelector('#mpr-pdf').addEventListener('click', async () => {
                if (typeof html2pdf === 'undefined') { alert('html2pdf.js is not loaded.'); return; }
                const btn = modal.querySelector('#mpr-pdf');
                const actions = modal.querySelector('.mpr-actions');
                const label = btn.textContent;
                try {
                    btn.disabled = true;
                    btn.textContent = 'Preparing PDF…';
                    actions.style.visibility = 'hidden';
                    await nextFrames();
                    await html2pdf().set({
                        margin: 8,
                        filename: `${P}_${PERIOD_TITLE[period].replace(' ', '_')}${data.selection ? '_' + data.selection.names.length + '_campaigns' : ''}_${data.current.since}.pdf`,
                        image: {type: 'jpeg', quality: 0.96},
                        html2canvas: {scale: 2, useCORS: true, backgroundColor: '#0f172a'},
                        jsPDF: {unit: 'mm', format: 'a4', orientation: 'landscape'},
                        pagebreak: {mode: ['css', 'legacy'], avoid: ['tr', 'article']},
                    }).from(modal.querySelector('#meta-performance-content')).save();
                } catch (e) {
                    console.error('Report PDF export failed', e);
                    alert('Could not export the PDF.');
                } finally {
                    actions.style.visibility = '';
                    btn.disabled = false;
                    btn.textContent = label;
                }
            });
        } catch (error) {
            console.error('Performance report failed:', error);
            alert(error.message || 'Unable to build the report.');
        } finally {
            restore();
        }
    };

    /* ------------------------------------------------------------------
     * Chart config (shared by modal and deck)
     * ------------------------------------------------------------------ */
    function buildChartConfig(data, period, theme, staticRender) {
        const dark = theme === 'dark';
        const text = dark ? '#cbd5e1' : '#334155';
        const grid = dark ? 'rgba(148,163,184,.12)' : 'rgba(100,116,139,.15)';

        let labels, datasets;

        if (period === 'daily') {
            const top = (data.campaigns || []).slice(0, 12);
            labels = top.map(r => r.campaign_name.length > 28 ? r.campaign_name.slice(0, 27) + '…' : r.campaign_name);
            datasets = [
                {type: 'bar', label: `Spend · ${data.previous.label}`, data: top.map(r => r.previous.spend), yAxisID: 'spend', backgroundColor: 'rgba(100,116,139,.75)', borderRadius: 4},
                {type: 'bar', label: `Spend · ${data.current.label}`, data: top.map(r => r.current.spend), yAxisID: 'spend', backgroundColor: 'rgba(59,130,246,.85)', borderRadius: 4},
                {type: 'line', label: `Leads · ${data.previous.label}`, data: top.map(r => r.previous.leads), yAxisID: 'leads', borderColor: '#f59e0b', backgroundColor: '#f59e0b', borderDash: [6, 4], pointRadius: 3, tension: 0.2},
                {type: 'line', label: `Leads · ${data.current.label}`, data: top.map(r => r.current.leads), yAxisID: 'leads', borderColor: '#10b981', backgroundColor: '#10b981', pointRadius: 4, tension: 0.2},
            ];
        } else {
            const curDays = data.daily_series.filter(d => d.bucket === 'current');
            const prevDays = data.daily_series.filter(d => d.bucket === 'previous');
            labels = curDays.map(d => d.label);
            datasets = [
                {type: 'bar', label: `Spend · ${data.current.label}`, data: curDays.map(d => d.spend), yAxisID: 'spend', backgroundColor: 'rgba(59,130,246,.8)', borderRadius: 3},
                {type: 'line', label: `Leads · ${data.current.label}`, data: curDays.map(d => d.leads), yAxisID: 'leads', borderColor: '#10b981', backgroundColor: '#10b981', pointRadius: 3, tension: 0.25},
                {type: 'line', label: `Leads · ${data.previous.label}`, data: curDays.map((_, i) => prevDays[i] ? prevDays[i].leads : null), yAxisID: 'leads', borderColor: '#f59e0b', backgroundColor: '#f59e0b', borderDash: [6, 4], pointRadius: 2, tension: 0.25},
            ];
        }

        return {
            data: {labels, datasets},
            options: {
                animation: staticRender ? false : undefined,
                responsive: !staticRender,
                maintainAspectRatio: false,
                devicePixelRatio: staticRender ? 2 : undefined,
                interaction: {mode: 'index', intersect: false},
                plugins: {
                    legend: {labels: {color: text, font: {size: staticRender ? 14 : 12}}},
                    tooltip: {callbacks: {label: c => c.dataset.yAxisID === 'spend' ? `${c.dataset.label}: ${money(c.parsed.y, 0)}` : `${c.dataset.label}: ${num(c.parsed.y)}`}},
                },
                scales: {
                    x: {ticks: {color: text, maxRotation: 40, autoSkip: true, font: {size: staticRender ? 12 : 11}}, grid: {color: grid}},
                    spend: {type: 'linear', position: 'left', beginAtZero: true, ticks: {color: '#3b82f6', callback: v => '₹' + num(v)}, title: {display: true, text: 'Spend (₹)', color: '#3b82f6'}, grid: {color: grid}},
                    leads: {type: 'linear', position: 'right', beginAtZero: true, ticks: {color: '#10b981', precision: 0}, title: {display: true, text: 'CRM leads', color: '#10b981'}, grid: {drawOnChartArea: false}},
                },
            },
        };
    }

    /* ------------------------------------------------------------------
     * Excel export
     * ------------------------------------------------------------------ */
    function exportReportExcel(data, period) {
        if (typeof XLSX === 'undefined') { alert('Excel library is not loaded.'); return; }

        const keys = PERIOD_METRICS[period];
        const curL = data.current.label;
        const prevL = data.previous.label;
        const raw = v => isNum(v) ? Number(v) : '';
        const pctRaw = v => isNum(v) ? Number(v) / 100 : '';

        const summary = [
            [`${data.platform} Ads ${PERIOD_TITLE[period]}`],
            [`${curL} ${COMPARE_LABEL[period]} (${prevL})`],
            [`Generated ${data.generated_at}`],
            [],
            ['Metric', curL, prevL, 'Change %'],
            ...keys.map(k => [METRICS[k].label, raw(data.current.totals[k]), raw(data.previous.totals[k]), pctRaw(data.changes[k])]),
        ];
        const wsSummary = XLSX.utils.aoa_to_sheet(summary);
        wsSummary['!cols'] = [{wch: 22}, {wch: 18}, {wch: 18}, {wch: 12}];
        for (let r = 5; r < summary.length; r++) {
            const ref = XLSX.utils.encode_cell({r, c: 3});
            if (wsSummary[ref]) wsSummary[ref].z = '0.0%';
        }
        [0, 1, 2, 3].forEach(c => {
            const ref = XLSX.utils.encode_cell({r: 4, c});
            if (wsSummary[ref]) wsSummary[ref].s = {font: {bold: true}, fill: {patternType: 'solid', fgColor: {rgb: 'ADD8E6'}}};
        });

        const header = ['Campaign', 'Campaign ID'];
        keys.forEach(k => header.push(`${METRICS[k].label} (${curL})`, `${METRICS[k].label} (${prevL})`, `${METRICS[k].label} Δ%`));
        const rows = [header];
        (data.campaigns || []).forEach(r => {
            const row = [r.campaign_name, r.campaign_id];
            keys.forEach(k => row.push(raw(r.current[k]), raw(r.previous[k]), pctRaw(r.changes[k])));
            rows.push(row);
        });
        const totalRow = ['All campaigns (incl. unmatched CRM leads)', ''];
        keys.forEach(k => totalRow.push(raw(data.current.totals[k]), raw(data.previous.totals[k]), pctRaw(data.changes[k])));
        rows.push(totalRow);

        const wsCampaigns = XLSX.utils.aoa_to_sheet(rows);
        wsCampaigns['!cols'] = [{wch: 44}, {wch: 20}, ...keys.flatMap(() => [{wch: 16}, {wch: 16}, {wch: 10}])];
        for (let r = 0; r < rows.length; r++) {
            for (let c = 0; c < header.length; c++) {
                const ref = XLSX.utils.encode_cell({r, c});
                if (!wsCampaigns[ref]) continue;
                if (r === 0 || r === rows.length - 1) {
                    wsCampaigns[ref].s = {font: {bold: true}, fill: {patternType: 'solid', fgColor: {rgb: r === 0 ? 'ADD8E6' : 'D9D9D9'}}};
                }
                if (r > 0 && c >= 2 && (c - 2) % 3 === 2) wsCampaigns[ref].z = '0.0%';
            }
        }

        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, wsSummary, 'Summary');
        XLSX.utils.book_append_sheet(wb, wsCampaigns, 'Campaigns');

        if ((data.unattributed?.campaigns || []).length) {
            const un = [['CRM campaign name (unmatched)', `Leads (${curL})`, `Leads (${prevL})`].concat(hid('qualified') ? [] : [`QL (${curL})`], hid('site_visits') ? [] : [`SV (${curL})`])];
            data.unattributed.campaigns.forEach(u => un.push([u.crm_campaign_name, u.current.leads, u.previous.leads].concat(hid('qualified') ? [] : [u.current.qualified], hid('site_visits') ? [] : [u.current.site_visits])));
            const wsUn = XLSX.utils.aoa_to_sheet(un);
            wsUn['!cols'] = [{wch: 44}, {wch: 16}, {wch: 16}, {wch: 12}, {wch: 12}];
            XLSX.utils.book_append_sheet(wb, wsUn, 'Unmatched CRM');
        }

        XLSX.writeFile(wb, `${data.platform}_${PERIOD_TITLE[period].replace(' ', '_')}${data.selection ? '_' + data.selection.names.length + '_campaigns' : ''}_${data.current.since}.xlsx`);
    }

    /* ------------------------------------------------------------------
     * Monthly deck (landscape PDF slides)
     * ------------------------------------------------------------------ */
    const DECK = {
        brand: '#E84E24',   // Webzaa orange (logo)
        accent: '#6B6B6B',  // Webzaa grey (logo)
        ink: '#2F2F2F',
        muted: '#64748b',
        line: '#e2e8f0',
        soft: '#fafafa',
    };
    const logoUrl = () => window.REPORT_LOGO_URL || 'images/webzaa-logo.png';

    function slideFrame(title, subtitle, body, meta) {
        return `
<div style="position:absolute;inset:0;background:#fff;font-family:'Sora',Arial,sans-serif;color:${DECK.ink};">
  <div style="height:6px;background:linear-gradient(90deg,${DECK.brand},${DECK.accent});"></div>
  <div style="padding:34px 56px 0;display:flex;justify-content:space-between;align-items:flex-end;">
    <div>
      <div style="font-size:12px;font-weight:700;letter-spacing:.14em;color:${DECK.brand};text-transform:uppercase;">${esc(meta.platform)} Ads · Monthly Review · ${esc(meta.month)}</div>
      <div style="font-size:32px;font-weight:700;margin-top:8px;color:${DECK.ink};letter-spacing:-.01em;">${esc(title)}</div>
      ${subtitle ? `<div style="font-size:15px;color:${DECK.muted};margin-top:6px;">${esc(subtitle)}</div>` : ''}
    </div>
    <img src="${logoUrl()}" alt="Webzaa" style="width:77px;height:56px;">
  </div>
  <div style="position:absolute;left:56px;right:56px;top:${subtitle ? 158 : 132}px;bottom:58px;">${body}</div>
  <div style="position:absolute;left:56px;right:56px;bottom:22px;display:flex;justify-content:space-between;font-size:11px;color:#94a3b8;border-top:1px solid ${DECK.line};padding-top:10px;">
    <span>${esc(meta.footer)}</span><span>${meta.page} / ${meta.total}</span>
  </div>
</div>`;
    }

    function deckTable(columns, rows, opts = {}) {
        const fs = opts.fontSize || 13;
        const keep = columns.map((c, i) => i === 0 || !hiddenLabel(c.label));
        if (keep.some(k => !k)) {
            columns = columns.filter((c, i) => keep[i]);
            rows = rows.map(r => Object.assign({}, r, {cells: r.cells.filter((v, i) => keep[i])}));
        }
        return `<table style="width:100%;border-collapse:collapse;font-size:${fs}px;table-layout:fixed;">
  <thead><tr>${columns.map((c, i) => `<th style="background:${DECK.brand};color:#fff;padding:9px 10px;font-weight:600;font-size:${fs - 2}px;text-transform:uppercase;letter-spacing:.04em;text-align:${i === 0 ? 'left' : 'right'};${c.width ? `width:${c.width};` : ''}">${esc(c.label)}</th>`).join('')}</tr></thead>
  <tbody>${rows.map((r, ri) => `<tr style="background:${r.total ? '#fdeee9' : ri % 2 ? '#fff' : DECK.soft};${r.total ? `font-weight:700;border-top:2px solid ${DECK.brand};` : ''}">
    ${r.cells.map((v, i) => `<td style="color:${DECK.ink};background:transparent;padding:8px 10px;border-bottom:1px solid ${DECK.line};text-align:${i === 0 ? 'left' : 'right'};${i === 0 ? 'white-space:nowrap;overflow:hidden;text-overflow:ellipsis;' : 'white-space:nowrap;'}">${v}</td>`).join('')}
  </tr>`).join('')}</tbody>
</table>`;
    }

    const lightChange = (pct, better) => `<span style="color:${TONE_LIGHT[tone(pct, better)]};font-weight:700;">${changeText(pct)}</span>`;

    function buildDeckSlides(data) {
        const keys = PERIOD_METRICS.monthly;
        const cur = data.current.totals;
        const prev = data.previous.totals;
        const ch = data.changes;
        const month = data.current.label;
        const prevMonth = data.previous.label;
        const P = data.platform || 'Ads';
        const accountList = window.REPORT_ACCOUNT_NAMES || (P === 'Meta' ? window.META_ACCOUNT_NAMES : null);
        const accounts = Array.isArray(accountList) ? accountList.filter(Boolean) : [];
        const slides = [];

        // 1. Cover
        slides.push({
            cover: true,
            html: `
<div style="position:absolute;inset:0;background:linear-gradient(135deg,${DECK.brand} 0%,#b8391a 100%);color:#fff;font-family:'Sora',Arial,sans-serif;">
  <div style="position:absolute;left:80px;top:64px;background:#fff;border-radius:12px;padding:12px 16px;"><img src="${logoUrl()}" alt="Webzaa" style="display:block;width:110px;height:80px;"></div>
  <div style="position:absolute;left:80px;top:250px;right:80px;">
    <div style="font-size:15px;letter-spacing:.2em;color:#ffe3d9;font-weight:700;text-transform:uppercase;">${esc(P)} Ads · Monthly Performance Review</div>
    <div style="font-size:64px;font-weight:700;margin-top:18px;letter-spacing:-.02em;">${esc(month)}</div>
    <div style="font-size:22px;color:#ffe3d9;margin-top:10px;">Compared with ${esc(prevMonth)}</div>
    ${accounts.length ? `<div style="margin-top:42px;font-size:15px;color:#fff1ec;">${accounts.map(esc).join(' · ')}</div>` : ''}
    ${selectionLine(data, 'margin-top:22px;font-size:15px;color:#fff;font-weight:600;')}
  </div>
  <div style="position:absolute;left:80px;bottom:56px;font-size:13px;color:#ffe3d9;">Generated ${esc(data.generated_at)} · Spend from ${esc(P)} Ads · Leads from CRM</div>
  <div style="position:absolute;right:80px;bottom:48px;width:120px;height:6px;background:#ffffff;border-radius:3px;"></div>
</div>`,
        });

        // 2. Month at a glance
        slides.push({
            title: 'Month at a glance',
            subtitle: `${month} vs ${prevMonth}`,
            body: `<div style="display:grid;grid-template-columns:repeat(5,1fr);gap:16px;">
${keys.map(k => {
                const m = METRICS[k];
                return `<div style="border:1px solid ${DECK.line};border-radius:12px;padding:18px 18px 16px;background:${DECK.soft};border-top:4px solid ${k === 'spend' ? DECK.accent : DECK.brand};">
    <div style="font-size:12px;color:${DECK.muted};text-transform:uppercase;letter-spacing:.06em;">${m.label}</div>
    <div style="font-size:26px;font-weight:700;margin:10px 0 8px;color:${DECK.ink};">${m.fmt(cur[k])}</div>
    <div style="display:flex;justify-content:space-between;font-size:12.5px;"><span style="color:${DECK.muted};">${m.fmt(prev[k])}</span>${lightChange(ch[k], m.better)}</div>
  </div>`;
            }).join('')}
</div>
<div style="margin-top:22px;font-size:12.5px;color:${DECK.muted};">Small figure: ${esc(prevMonth)}. Green = better, red = worse. Spend change is shown in grey (neutral).</div>
${(data.warnings || []).length ? `<div style="margin-top:16px;padding:12px 14px;border:1px solid #fecaca;background:#fef2f2;border-radius:10px;font-size:13px;line-height:1.6;color:${TONE_LIGHT.bad};">${data.warnings.map(esc).join('<br>')}</div>` : ''}`,
        });

        // 3. MoM comparison + takeaways
        const takeaways = buildTakeaways(data, 'monthly');
        slides.push({
            title: 'Month-over-month comparison',
            subtitle: 'Key movements and what the numbers show',
            body: `<div style="display:grid;grid-template-columns:1.05fr .95fr;gap:34px;height:100%;">
  <div>${deckTable(
                [{label: 'Metric', width: '34%'}, {label: prevMonth}, {label: month}, {label: 'Change'}],
                ['spend', 'impressions', 'clicks', 'ctr', 'cpc', 'leads', 'cpl', 'qualified', 'cpql', 'site_visits', 'cpsv'].filter(k => !hid(k)).map(k => ({
                    cells: [METRICS[k].label, METRICS[k].fmt(prev[k]), `<strong>${METRICS[k].fmt(cur[k])}</strong>`, lightChange(ch[k], METRICS[k].better)],
                })),
                {fontSize: 13}
            )}</div>
  <div style="background:${DECK.soft};border:1px solid ${DECK.line};border-left:4px solid ${DECK.accent};border-radius:10px;padding:20px 24px;">
    <div style="font-size:13px;font-weight:700;color:${DECK.brand};text-transform:uppercase;letter-spacing:.08em;margin-bottom:12px;">Key takeaways</div>
    <ul style="margin:0;padding-left:18px;font-size:14.5px;line-height:1.65;color:#334155;">${takeaways.map(t => `<li style="margin-bottom:6px;">${esc(t)}</li>`).join('')}</ul>
  </div>
</div>`,
        });

        // 4. Daily trend chart
        slides.push({
            title: 'Daily spend and lead trend',
            subtitle: `${month} daily spend (bars) and CRM leads (line); ${prevMonth} leads dashed for comparison`,
            body: `<canvas class="deck-chart" width="1168" height="470" style="width:1168px;height:470px;"></canvas>`,
            chart: true,
        });

        // 5. Funnel
        const stages = [
            {k: 'impressions', label: 'Impressions'},
            {k: 'clicks', label: 'Clicks', rate: (t) => t.impressions > 0 ? t.clicks / t.impressions * 100 : null, rateLabel: 'CTR'},
            {k: 'leads', label: 'Leads', rate: (t) => t.clicks > 0 ? t.leads / t.clicks * 100 : null, rateLabel: 'Click → lead'},
            {k: 'qualified', label: 'Qualified leads', rate: (t) => t.leads > 0 ? t.qualified / t.leads * 100 : null, rateLabel: 'Lead → QL'},
            {k: 'site_visits', label: 'Site visits', rate: hid('qualified') ? null : (t) => t.qualified > 0 ? t.site_visits / t.qualified * 100 : null, rateLabel: 'QL → SV'},
        ].filter(st => !hid(st.k));
        slides.push({
            title: 'Conversion funnel',
            subtitle: hid('site_visits') ? 'From ad impression to lead, with step conversion rates' : 'From ad impression to site visit, with step conversion rates',
            body: `<div style="display:flex;flex-direction:column;gap:14px;">
${stages.map((s, i) => {
                const w = 100 - i * 15;
                const rc = s.rate ? s.rate(cur) : null;
                const rp = s.rate ? s.rate(prev) : null;
                const diff = isNum(rc) && isNum(rp) ? rc - rp : null;
                return `<div style="display:grid;grid-template-columns:1fr 330px;gap:24px;align-items:center;">
    <div style="height:62px;width:${w}%;background:linear-gradient(90deg,${DECK.brand},#f27552);border-radius:8px;display:flex;align-items:center;justify-content:space-between;padding:0 22px;color:#fff;box-sizing:border-box;">
      <span style="font-size:16px;font-weight:600;">${s.label}</span><span style="font-size:22px;font-weight:700;">${num(cur[s.k])}</span>
    </div>
    <div style="font-size:13.5px;color:#334155;">
      ${s.rate ? `<div><strong>${s.rateLabel}:</strong> ${isNum(rc) ? rc.toFixed(2) + '%' : '—'} <span style="color:${DECK.muted};">(prev ${isNum(rp) ? rp.toFixed(2) + '%' : '—'})</span></div>
      <div style="margin-top:3px;color:${diff == null ? DECK.muted : diff >= 0 ? TONE_LIGHT.good : TONE_LIGHT.bad};font-weight:600;">${diff == null ? 'n/a' : `${diff >= 0 ? '+' : ''}${diff.toFixed(2)} pts`}</div>`
                    : `<div style="color:${DECK.muted};">Previous: ${num(prev[s.k])} · ${lightChange(ch[s.k], 'up')}</div>`}
    </div>
  </div>`;
            }).join('')}
</div>`,
        });

        // 6. Top campaigns
        const top = (data.campaigns || []).filter(r => r.current.spend > 0).sort((a, b) => b.current.leads - a.current.leads || b.current.spend - a.current.spend).slice(0, 9);
        slides.push({
            title: 'Top campaigns by leads',
            subtitle: `${month} · change vs ${prevMonth} shown for CPL${hid('cpql') ? '' : ' and CPQL'}`,
            body: top.length ? deckTable(
                [{label: 'Campaign', width: '30%'}, {label: 'Spend'}, {label: 'Leads'}, {label: 'CPL'}, {label: 'CPL Δ'}, {label: 'QL'}, {label: 'CPQL'}, {label: 'CPQL Δ'}, {label: 'SV'}, {label: 'CPSV'}],
                top.map(r => ({
                    cells: [esc(r.campaign_name), money(r.current.spend, 0), num(r.current.leads), money(r.current.cpl, 0), lightChange(r.changes.cpl, 'down'),
                        num(r.current.qualified), money(r.current.cpql, 0), lightChange(r.changes.cpql, 'down'), num(r.current.site_visits), money(r.current.cpsv, 0)],
                })),
                {fontSize: 13}
            ) : `<div style="font-size:16px;color:${DECK.muted};">No campaigns delivered in ${esc(month)}.</div>`,
        });

        // 7. Watchlist
        const watch = buildWatchlist(data, 'monthly').slice(0, 9);
        slides.push({
            title: 'Campaigns to review',
            subtitle: HIDE.length ? 'Spend with no leads, or CPL up more than 25%' : 'Spend with no leads, CPL or CPQL up more than 25%, or leads with no qualified leads',
            body: watch.length ? deckTable(
                [{label: 'Campaign', width: '32%'}, {label: 'Spend'}, {label: 'Leads'}, {label: 'CPL'}, {label: 'QL'}, {label: 'CPQL'}, {label: 'Flag', width: '24%'}],
                watch.map(r => ({
                    cells: [esc(r.campaign_name), money(r.current.spend, 0), num(r.current.leads), money(r.current.cpl, 0), num(r.current.qualified), money(r.current.cpql, 0),
                        `<span style="color:${TONE_LIGHT.bad};font-weight:600;white-space:normal;">${esc(r.reasons.join(' · '))}</span>`],
                })),
                {fontSize: 13}
            ) : `<div style="padding:26px;border:1px dashed ${DECK.line};border-radius:10px;font-size:16px;color:${DECK.muted};">No campaigns triggered the review rules in ${esc(month)}.</div>`,
        });

        // 8+. All campaigns, paginated
        const all = data.campaigns || [];
        const PER_SLIDE = 11;
        const pages = Math.max(1, Math.ceil(all.length / PER_SLIDE));
        for (let p = 0; p < pages; p++) {
            const chunk = all.slice(p * PER_SLIDE, (p + 1) * PER_SLIDE);
            const rows = chunk.map(r => ({
                cells: [esc(r.campaign_name), money(r.current.spend, 0), num(r.current.impressions), pctVal(r.current.ctr), money(r.current.cpc, 2),
                    num(r.current.leads), money(r.current.cpl, 0), num(r.current.qualified), money(r.current.cpql, 0), num(r.current.site_visits), money(r.current.cpsv, 0),
                    lightChange(r.changes.spend, 'neutral')],
            }));
            if (p === pages - 1) {
                rows.push({
                    total: true,
                    cells: ['All campaigns', money(cur.spend, 0), num(cur.impressions), pctVal(cur.ctr), money(cur.cpc, 2), num(cur.leads), money(cur.cpl, 0),
                        num(cur.qualified), money(cur.cpql, 0), num(cur.site_visits), money(cur.cpsv, 0), lightChange(ch.spend, 'neutral')],
                });
            }
            slides.push({
                title: 'All campaigns',
                subtitle: `${month} · sorted by spend${pages > 1 ? ` · part ${p + 1} of ${pages}` : ''}`,
                body: deckTable(
                    [{label: 'Campaign', width: '25%'}, {label: 'Spend'}, {label: 'Impr.'}, {label: 'CTR'}, {label: 'CPC'}, {label: 'Leads'}, {label: 'CPL'}, {label: 'QL'}, {label: 'CPQL'}, {label: 'SV'}, {label: 'CPSV'}, {label: 'Spend Δ'}],
                    rows,
                    {fontSize: 12}
                ),
            });
        }

        // Last: notes
        const un = data.unattributed || {current: {leads: 0}};
        slides.push({
            title: 'Notes and methodology',
            subtitle: '',
            body: `<div style="display:grid;grid-template-columns:1fr 1fr;gap:28px;font-size:14px;line-height:1.7;color:#334155;">
  <div>
    <div style="font-weight:700;color:${DECK.brand};margin-bottom:6px;">Data sources</div>
    <ul style="margin:0;padding-left:18px;">
      <li>Spend, impressions and clicks: ${esc(data.definitions?.spend || '')}</li>
      <li>Leads: ${esc(data.definitions?.leads || '')}</li>
      ${hid('qualified') ? '' : `<li>Qualified: ${esc(data.definitions?.qualified || '')}.</li>`}
      ${hid('site_visits') ? '' : `<li>Site visits: ${esc(data.definitions?.site_visits || '')}.</li>`}
      <li>${HIDE.length ? 'CPL = spend ÷ leads.' : 'CPL / CPQL / CPSV = spend ÷ leads / qualified leads / site visits.'}</li>
    </ul>
  </div>
  <div>
    <div style="font-weight:700;color:${DECK.brand};margin-bottom:6px;">Reading this report</div>
    <ul style="margin:0;padding-left:18px;">
      ${HIDE.length ? '' : '<li>Qualified leads and site visits are counted against the month the lead was created, so recent leads may still progress.</li>'}
      <li>${esc(data.definitions?.matching || `CRM leads are matched to ${P} campaigns by campaign name.`)} ${num(un.current.leads)} lead(s) in ${esc(month)} did not match a campaign name; they are in totals but not in campaign rows.</li>
      ${(data.warnings || []).map(w => `<li style="color:${TONE_LIGHT.bad};">${esc(w)}</li>`).join('')}
    </ul>
  </div>
</div>`,
        });

        return slides;
    }

    window.exportMonthlyDeck = async function (platform, asOf, month, pick) {
        platform = String(platform || 'meta').toLowerCase();
        const restore = setBusy('⏳ Building deck…');
        const holder = document.createElement('div');
        let chart = null;

        try {
            if (typeof html2canvas === 'undefined') throw new Error('html2canvas is not loaded.');
            const JsPDF = (window.jspdf && window.jspdf.jsPDF) || window.jsPDF;
            if (!JsPDF) throw new Error('jsPDF is not loaded.');
            if (typeof Chart === 'undefined') throw new Error('Chart.js is not loaded.');

            const data = await fetchReport(platform, 'monthly', asOf, month, pick);
            const t = data.current.totals || {};
            if (!(Number(t.spend) > 0) && !(Number(t.leads) > 0)) {
                const now = new Date();
                const thisMonth = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
                const offerMtd = !month && data.current.since.slice(0, 7) !== thisMonth;
                const msg = `There is no spend and no leads for this project's ${data.platform} campaigns in ${data.current.label}, so the deck would be all zeros.`
                    + ((data.warnings || []).length ? `\n\n${data.warnings.join('\n')}` : '')
                    + (offerMtd ? `\n\nOK = build this month (to date) instead · Cancel = stop` : `\n\nBuild it anyway?`);
                if (!window.confirm(msg)) return;
                if (offerMtd) {
                    restore();
                    return await window.exportMonthlyDeck(platform, null, thisMonth, pick);
                }
            }
            const slides = buildDeckSlides(data);
            const total = slides.length;
            const footer = `${data.platform} Ads · ${data.current.label} vs ${data.previous.label}`;

            holder.style.cssText = 'position:fixed;left:0;top:0;width:1280px;height:720px;z-index:-9999;opacity:0.01;pointer-events:none;overflow:hidden;';
            document.body.appendChild(holder);

            if (document.fonts && document.fonts.ready) await document.fonts.ready;

            const pdf = new JsPDF({orientation: 'landscape', unit: 'pt', format: [960, 540]});

            for (let i = 0; i < slides.length; i++) {
                const s = slides[i];
                const meta = {platform: data.platform, month: data.current.label, footer, page: i + 1, total};
                holder.innerHTML = `<div class="mdeck-slide" style="position:relative;width:1280px;height:720px;overflow:hidden;background:#fff;">${
                    s.cover ? s.html : slideFrame(s.title, s.subtitle, s.body, meta)
                }</div>`;
                const slideEl = holder.firstElementChild;

                if (s.chart) {
                    const canvas = slideEl.querySelector('.deck-chart');
                    chart = new Chart(canvas, buildChartConfig(data, 'monthly', 'light', true));
                }

                // Wait for the logo (and any other images) so they appear in the capture.
                await Promise.all([...slideEl.querySelectorAll('img')].map(img =>
                    img.complete ? Promise.resolve() : new Promise(r => { img.onload = img.onerror = r; })));
                await nextFrames();

                const shot = await html2canvas(slideEl, {
                    scale: 1.5,
                    useCORS: true,
                    backgroundColor: '#ffffff',
                    logging: false,
                    width: 1280,
                    height: 720,
                    windowWidth: 1280,
                    windowHeight: 720,
                    scrollX: 0,
                    scrollY: 0,
                });

                if (i > 0) pdf.addPage([960, 540], 'landscape');
                pdf.addImage(shot.toDataURL('image/jpeg', 0.92), 'JPEG', 0, 0, 960, 540);

                if (chart) {
                    chart.destroy();
                    chart = null;
                }
            }

            pdf.save(`${data.platform}_Monthly_Deck${data.selection ? '_' + data.selection.names.length + '_campaigns' : ''}_${data.current.since.slice(0, 7)}.pdf`);
            if (typeof window.showCampaignToast === 'function') {
                window.showCampaignToast(`✅ Monthly deck for ${data.current.label} downloaded.`, 'success');
            }
        } catch (error) {
            console.error('Monthly deck failed:', error);
            alert(error.message || 'Unable to build the monthly deck.');
        } finally {
            if (chart) chart.destroy();
            holder.remove();
            restore();
        }
    };

    /* ------------------------------------------------------------------
     * Shortcuts used by the dashboard buttons
     * ------------------------------------------------------------------ */
    // The dashboard buttons ask first "All campaigns or select campaigns?" (js/report_picker.js); false = cancelled.
    // (Signed report links — report_view.php — call openPerformanceReport directly: always all campaigns.)
    const ask = async (pf, title) => typeof window.pqPickCampaigns === 'function' ? window.pqPickCampaigns(pf, title) : null;
    const withPick = (pf, title, run) => async (...a) => { const pick = await ask(pf, title); if (pick !== false) return run(pick, ...a); };
    window.openMetaPerformanceReport = (period, asOf) => withPick('meta', 'Meta ' + (PERIOD_TITLE[period] || 'report'), pick => window.openPerformanceReport('meta', period, asOf, pick))();
    window.exportMetaMonthlyDeck = (asOf, month) => withPick('meta', 'Meta monthly deck', pick => window.exportMonthlyDeck('meta', asOf, month, pick))();
    window.openGooglePerformanceReport = (period, asOf) => withPick('google', 'Google ' + (PERIOD_TITLE[period] || 'report'), pick => window.openPerformanceReport('google', period, asOf, pick))();
    window.exportGoogleMonthlyDeck = (asOf, month) => withPick('google', 'Google monthly deck', pick => window.exportMonthlyDeck('google', asOf, month, pick))();
    /** "This month to date" deck (YYYY-MM of today). */
    const thisMonthKey = () => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`; };
    window.exportMetaMonthToDateDeck = () => window.exportMetaMonthlyDeck(null, thisMonthKey());
    window.exportGoogleMonthToDateDeck = () => window.exportGoogleMonthlyDeck(null, thisMonthKey());
})();
