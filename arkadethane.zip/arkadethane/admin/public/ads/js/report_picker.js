/**
 * report_picker.js — asked before every report download: "All campaigns, or select campaigns?"
 *
 *   const pick = await PQReportPicker.ask({ api: 'ads/report_campaigns_api.php', title: 'Campaign report' });
 *   pick === false → cancelled · pick === null → all campaigns · else { meta: [ids], google: [ids], count, names }
 *   PQReportPicker.param(pick) → "meta:1,meta:2,google:3" (for a GET parameter)
 *   PQReportPicker.has(pick, 'meta', id, name) → is this campaign one of the chosen (by ID, else by saved name)
 *   pqPickCampaigns('meta', 'Daily report') → ask for one platform's campaigns only (Meta / Google dashboards)
 *
 * Used by js/portfolio_pdf.js and js/email_report_pdf.js, so every page that downloads those reports asks.
 * The last choice is remembered on this browser (pre-filled the next time, never applied silently).
 */
(function () {
    'use strict';
    if (window.PQReportPicker) return;
    const KEY = 'pq-report-pick';
    const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
    const store = { get() { try { return JSON.parse(localStorage.getItem(KEY) || 'null'); } catch (e) { return null; } },
                    set(v) { try { localStorage.setItem(KEY, JSON.stringify(v)); } catch (e) {} } };

    const css = `
    .pqrp-ov { position: fixed; inset: 0; z-index: 100000; background: rgba(2, 6, 23, .68); display: grid; place-items: center; padding: 16px; font-family: 'Sora', system-ui, -apple-system, 'Segoe UI', sans-serif; }
    .pqrp { --s: #111827; --s2: #161D2E; --b: #2A3957; --t: #E2E8F0; --d: #94A3B8; --f: #64748B; --a: #E8A820; --as: #E8A8201F; --aw: #A78BFA;
            background: var(--s); color: var(--t); border: 1px solid var(--b); border-radius: 14px; width: 100%; max-width: 620px; max-height: 90vh; display: flex; flex-direction: column;
            box-shadow: 0 24px 70px rgba(0, 0, 0, .5); font-size: 13.5px; line-height: 1.45; }
    html[data-theme="light"] .pqrp { --s: #fff; --s2: #F8FAFC; --b: #CBD5E1; --t: #0F172A; --d: #475569; --f: #94A3B8; --a: #B7791F; --as: #B7791F1A; --aw: #7C3AED; }
    .pqrp .pqrp-hd { padding: 18px 20px 8px; } .pqrp h3 { margin: 0; font-size: 16px; } .pqrp .pqrp-hd p { margin: 4px 0 0; color: var(--d); font-size: 12.5px; }
    .pqrp .pqrp-body { padding: 6px 20px 4px; overflow: auto; flex: 1; min-height: 0; }
    .pqrp .pqrp-opt { display: flex; gap: 10px; align-items: flex-start; padding: 11px 13px; border: 1px solid var(--b); border-radius: 10px; margin-bottom: 8px; cursor: pointer; }
    .pqrp .pqrp-opt.on { border-color: var(--a); background: var(--as); }
    .pqrp .pqrp-opt input { margin-top: 3px; accent-color: var(--a); } .pqrp .pqrp-opt b { display: block; } .pqrp .pqrp-opt span { color: var(--d); font-size: 12px; }
    .pqrp .pqrp-pick { border: 1px solid var(--b); border-radius: 10px; margin: 2px 0 8px; }
    .pqrp .pqrp-tools { display: flex; gap: 8px; padding: 10px; border-bottom: 1px solid var(--b); align-items: center; flex-wrap: wrap; }
    .pqrp input[type=search] { flex: 1 1 180px; min-width: 0; background: var(--s2); color: var(--t); border: 1px solid var(--b); border-radius: 8px; padding: 7px 10px; font: inherit; outline: none; }
    .pqrp input[type=search]:focus { border-color: var(--a); }
    .pqrp .pqrp-list { max-height: 330px; overflow: auto; }
    .pqrp .pqrp-pf { display: flex; justify-content: space-between; align-items: center; gap: 8px; padding: 8px 12px; background: var(--s2); border-bottom: 1px solid var(--b); position: sticky; top: 0; font-weight: 700; font-size: 12px; text-transform: uppercase; letter-spacing: .05em; color: var(--d); }
    .pqrp .pqrp-row { display: flex; gap: 10px; align-items: center; padding: 7px 12px; border-bottom: 1px solid var(--b); cursor: pointer; }
    .pqrp .pqrp-row:last-child { border-bottom: 0; } .pqrp .pqrp-row input { accent-color: var(--a); flex: none; }
    .pqrp .pqrp-row .pqrp-n { flex: 1; min-width: 0; overflow-wrap: anywhere; font-size: 13px; }
    .pqrp .pqrp-tag { font-size: 10.5px; font-weight: 600; color: var(--aw); border: 1px solid currentColor; border-radius: 99px; padding: 0 7px; flex: none; }
    .pqrp .pqrp-lnk { background: none; border: 0; color: var(--a); font: inherit; font-size: 11.5px; font-weight: 600; cursor: pointer; padding: 2px 4px; text-transform: none; letter-spacing: 0; }
    .pqrp .pqrp-empty { padding: 14px; color: var(--d); text-align: center; font-size: 12.5px; }
    .pqrp .pqrp-ft { display: flex; gap: 10px; align-items: center; padding: 12px 20px 16px; border-top: 1px solid var(--b); flex-wrap: wrap; }
    .pqrp .pqrp-ft .pqrp-cnt { flex: 1; color: var(--d); font-size: 12.5px; }
    .pqrp .pqrp-btn { border: 1px solid var(--b); background: var(--s2); color: var(--t); padding: 8px 15px; border-radius: 8px; cursor: pointer; font: inherit; font-weight: 600; font-size: 13px; }
    .pqrp .pqrp-btn.pqrp-primary { background: var(--a); border-color: var(--a); color: #111; } .pqrp .pqrp-btn:disabled { opacity: .5; cursor: not-allowed; }
    .pqrp .pqrp-btn:focus-visible, .pqrp .pqrp-lnk:focus-visible, .pqrp input:focus-visible { outline: 2px solid var(--a); outline-offset: 2px; }
    .pqrp .pqrp-err { color: #EF4444; padding: 10px 0; }
    .pqrp [hidden] { display: none !important; }
    .pqrp, .pqrp * { box-sizing: border-box; letter-spacing: normal; text-align: left; }
    .pqrp label { margin: 0; font-size: inherit; color: inherit; text-transform: none; float: none; width: auto; }
    .pqrp input[type=radio], .pqrp input[type=checkbox] { position: static; opacity: 1; width: 16px; height: 16px; margin: 3px 0 0; padding: 0; flex: none; appearance: auto; -webkit-appearance: auto; display: inline-block; }
    .pqrp b, .pqrp span { display: inline; } .pqrp .pqrp-opt b { display: block; }
    .pqrp .pqrp-opt > div, .pqrp .pqrp-row .pqrp-n { flex: 1; min-width: 0; text-align: left; }
    .pqrp .pqrp-row .pqrp-n { color: var(--t); }`;

    function addCss() {
        if (document.getElementById('pqrp-css')) return;
        const s = document.createElement('style'); s.id = 'pqrp-css'; s.textContent = css; document.head.appendChild(s);
    }

    async function loadCampaigns(api) {
        const res = await fetch(api, { credentials: 'same-origin', cache: 'no-store' });
        const d = await res.json().catch(() => null);
        if (!res.ok || !d || !d.success) throw new Error((d && d.error) || 'Could not load the campaigns (HTTP ' + res.status + ').');
        return d.platforms || [];
    }

    /** The All / Performance / Awareness tab the report follows (campaign_view.js, cookie pq_view). */
    function allText() {
        const v = window.PQView ? PQView.current() : ((document.cookie.match(/(?:^|;\s*)pq_view=([a-z]+)/) || [])[1] || 'all');
        return v === 'performance' ? 'Every performance campaign (the Performance tab).'
            : v === 'awareness' ? 'Every awareness campaign (the Awareness tab).'
            : 'Every campaign saved for this project.';
    }

    function ask(opt) {
        const o = Object.assign({ api: 'report_campaigns_api.php', title: 'Report', platforms: ['meta', 'google'] }, opt || {});
        addCss();
        return new Promise(resolve => {
            const last = store.get() || {};
            const ov = document.createElement('div');
            ov.className = 'pqrp-ov';
            ov.innerHTML = `<div class="pqrp" role="dialog" aria-modal="true" aria-labelledby="pqrp-h">
                <div class="pqrp-hd"><h3 id="pqrp-h">Download · ${esc(o.title)}</h3><p>Which campaigns should the report cover?</p></div>
                <div class="pqrp-body">
                    <label class="pqrp-opt" data-o="all"><input type="radio" name="pqrp-mode" value="all"><div><b>All campaigns</b><span>${esc(allText())}</span></div></label>
                    <label class="pqrp-opt" data-o="some"><input type="radio" name="pqrp-mode" value="some"><div><b>Select campaigns</b><span>Only the campaigns you tick — totals, tables and insights cover just those.</span></div></label>
                    <div class="pqrp-pick" hidden>
                        <div class="pqrp-tools"><input type="search" placeholder="Search campaigns…" aria-label="Search campaigns"></div>
                        <div class="pqrp-list"><div class="pqrp-empty">Loading campaigns…</div></div>
                    </div>
                </div>
                <div class="pqrp-ft"><span class="pqrp-cnt"></span><button class="pqrp-btn" data-x type="button">Cancel</button><button class="pqrp-btn pqrp-primary" data-ok type="button">Download</button></div>
            </div>`;
            document.body.appendChild(ov);
            const $ = s => ov.querySelector(s), $$ = s => [...ov.querySelectorAll(s)];
            const prevFocus = document.activeElement;
            let platforms = null;
            const sel = new Set((last.ids || []).map(String));
            let mode = last.mode === 'some' ? 'some' : 'all';

            const done = v => { ov.remove(); document.removeEventListener('keydown', key, true); try { prevFocus && prevFocus.focus(); } catch (e) {} resolve(v); };
            const key = e => { if (e.key === 'Escape') { e.stopPropagation(); done(false); } };
            document.addEventListener('keydown', key, true);
            ov.addEventListener('click', e => { if (e.target === ov) done(false); });
            $('[data-x]').onclick = () => done(false);

            function count() {
                if (mode === 'all') { $('.pqrp-cnt').textContent = 'All campaigns'; $('[data-ok]').disabled = false; return; }
                const known = platforms ? platforms.filter(p => o.platforms.includes(p.key)).flatMap(p => p.campaigns.map(c => p.key + ':' + c.id)) : [];
                const n = known.filter(k => sel.has(k)).length;
                $('.pqrp-cnt').textContent = n ? n + ' campaign' + (n === 1 ? '' : 's') + ' selected' : 'Tick at least one campaign';
                $('[data-ok]').disabled = !n;
            }
            function drawList() {
                if (!platforms) return;
                const q = $('input[type=search]').value.trim().toLowerCase();
                const html = platforms.filter(p => o.platforms.includes(p.key)).map(p => {
                    const cs = p.campaigns.filter(c => !q || c.name.toLowerCase().includes(q) || String(c.id).includes(q));
                    if (!p.campaigns.length) return `<div class="pqrp-pf"><span>${esc(p.name)}</span></div><div class="pqrp-empty">No ${esc(p.name)} campaigns saved yet (⟳ Sync with ${esc(p.name)}).</div>`;
                    return `<div class="pqrp-pf"><span>${esc(p.name)} · ${p.campaigns.length}</span><span><button class="pqrp-lnk" type="button" data-all="${p.key}">Select all</button><button class="pqrp-lnk" type="button" data-none="${p.key}">None</button></span></div>`
                        + (cs.length ? cs.map(c => {
                            const k = p.key + ':' + c.id;
                            return `<label class="pqrp-row"><input type="checkbox" value="${esc(k)}" ${sel.has(k) ? 'checked' : ''}><span class="pqrp-n">${esc(c.name)}</span>${c.type === 'awareness' ? '<span class="pqrp-tag">Awareness</span>' : ''}</label>`;
                        }).join('') : '<div class="pqrp-empty">No match.</div>');
                }).join('');
                $('.pqrp-list').innerHTML = html || '<div class="pqrp-empty">No campaigns saved for this project yet.</div>';
                $$('.pqrp-list input[type=checkbox]').forEach(cb => cb.onchange = () => { cb.checked ? sel.add(cb.value) : sel.delete(cb.value); count(); });
                const bulk = (pk, on) => {
                    const p = platforms.find(x => x.key === pk);
                    p.campaigns.filter(c => !q || c.name.toLowerCase().includes(q) || String(c.id).includes(q)).forEach(c => on ? sel.add(pk + ':' + c.id) : sel.delete(pk + ':' + c.id));
                    drawList(); count();
                };
                $$('[data-all]').forEach(b => b.onclick = () => bulk(b.dataset.all, true));
                $$('[data-none]').forEach(b => b.onclick = () => bulk(b.dataset.none, false));
            }
            async function setMode(m) {
                mode = m;
                $$('.pqrp-opt').forEach(l => { const on = l.dataset.o === m; l.classList.toggle('on', on); l.querySelector('input').checked = on; });
                $('.pqrp-pick').hidden = m !== 'some';
                count();
                if (m === 'some' && !platforms) {
                    try { platforms = await loadCampaigns(o.api); drawList(); count(); }
                    catch (e) { $('.pqrp-list').innerHTML = '<div class="pqrp-empty pqrp-err">' + esc(e.message) + '</div>'; }
                }
                if (m === 'some') setTimeout(() => $('input[type=search]').focus(), 20);
            }
            $$('input[name=pqrp-mode]').forEach(r => r.onchange = () => setMode(r.value));
            $('input[type=search]').oninput = drawList;
            $('[data-ok]').onclick = () => {
                if (mode === 'all') { store.set({ mode: 'all', ids: [...sel] }); return done(null); }
                const out = { meta: [], google: [], names: [], byName: { meta: [], google: [] }, count: 0 };
                platforms.filter(p => o.platforms.includes(p.key)).forEach(p => p.campaigns.forEach(c => {
                    if (sel.has(p.key + ':' + c.id)) { out[p.key].push(String(c.id)); out.names.push(c.name); out.byName[p.key].push(c.name); }
                }));
                out.count = out.names.length;
                if (!out.count) return;
                store.set({ mode: 'some', ids: [...sel] });
                done(out);
            };
            setMode(mode);
            setTimeout(() => ($(`.pqrp-opt[data-o="${mode}"] input`) || $('[data-ok]')).focus(), 20);
        });
    }

    const param = pick => !pick ? '' : ['meta', 'google'].flatMap(p => (pick[p] || []).map(id => p + ':' + id)).join(',');
    const norm = s => String(s ?? '').toLowerCase().replace(/[\u2010-\u2015\u2212]/g, '-').replace(/\s+/g, ' ').trim();
    function has(pick, pf, id, name) {
        if (!pick) return true;
        const ids = (pick[pf] || []).map(String);
        if (id != null && String(id).trim() !== '' && ids.includes(String(id).trim())) return true;
        const n = norm(name);
        return n !== '' && ((pick.byName && pick.byName[pf]) || []).some(x => norm(x) === n);
    }

    window.PQReportPicker = { ask, param, has };
    // Meta / Google dashboards (public/ads/*): one platform's campaigns
    window.pqPickCampaigns = (pf, title) => ask({ api: 'report_campaigns_api.php', title, platforms: [pf] });
})();
