/*
 * project_sync.js — "⟳ Sync with Meta / Google / Taboola" for every ads dashboard.
 *
 * The dashboards show ONLY campaigns saved for this project (campaigns / adgroups / ads tables).
 * This file draws the banner above the tabs and the Sync window that links / unlinks campaigns.
 *
 *   ProjectSync.init({
 *     platform: 'meta' | 'google',
 *     label:    'Meta',                       // shown in buttons and text
 *     groupWord:'ad sets',                    // 'ad groups' for Google; '' when the platform has none
 *     getRange: () => ({ since, until }),     // optional: period for the spend column
 *     onSaved:  () => reloadDashboard(),      // called after Save / Refresh
 *     suggestFromAds: true                    // Meta: look up the leads' ad_id in Meta for suggestions
 *   });
 *   ProjectSync.renderBanner(data.campaign_filter)   // after every data load
 *   ProjectSync.open()                               // e.g. from a toolbar button
 */
(function () {
    'use strict';

    const API = 'project_sync_api.php';
    let cfg = { platform: 'meta', label: 'Meta', groupWord: 'ad sets', getRange: null, onSaved: null, suggestFromAds: false, bannerId: 'campaign-filter-banner' };
    const S = { list: [], selected: new Set(), original: new Set(), fromAds: {}, filter: 'all', q: '', loading: false, types: {}, origTypes: {} };
    // campaign type (performance | awareness): saved per campaign; the dashboards' All / Performance / Awareness tabs follow it
    const typeOf = c => S.types[c.id] || (c.awareness_hint ? 'awareness' : 'performance');
    function typeChanges() {
        const out = {};
        S.selected.forEach(id => {
            const c = S.list.find(x => x.id === id);
            if (!c) return;
            const t = typeOf(c);
            if (!S.original.has(id) || (S.origTypes[id] || 'performance') !== t) out[id] = t;
        });
        return out;
    }

    const esc = (v) => String(v ?? '').replace(/[&<>"']/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch]));
    const money = (v) => '₹' + Math.round(Number(v || 0)).toLocaleString('en-IN');
    const plural = (n, w) => `${n} ${w}${n === 1 ? '' : 's'}`;
    const url = (action, extra) => `${API}?platform=${encodeURIComponent(cfg.platform)}&action=${action}` + (extra ? '&' + extra : '');

    function toast(msg, type, details) {
        if (!details && typeof window.showCampaignToast === 'function') { window.showCampaignToast(msg, type); return; }
        const colors = { success: '#10B981', error: '#EF4444', warn: '#F59E0B' };
        const t = document.createElement('div');
        t.style.cssText = `position:fixed; bottom:28px; right:28px; z-index:100001; background:var(--pq-card,#161D2E); color:var(--pq-text,#E2E8F0);
            border:1px solid var(--pq-border,#1E2A42); border-left:4px solid ${colors[type] || '#3B82F6'}; padding:14px 20px; border-radius:8px;
            font:500 13px/1.5 Sora,sans-serif; max-width:420px; box-shadow:0 10px 32px rgba(0,0,0,.4);`;
        t.textContent = msg;
        if (details && details.length) {
            // Which campaigns failed and Meta's / Google's reason — stays until closed.
            t.style.maxWidth = '560px';
            const ul = document.createElement('ul');
            ul.style.cssText = 'margin:8px 0 0; padding-left:18px; font-size:12px; line-height:1.55; color:var(--pq-text,#E2E8F0); opacity:.85; max-height:220px; overflow:auto;';
            details.slice(0, 8).forEach(d => { const li = document.createElement('li'); li.textContent = d; ul.appendChild(li); });
            if (details.length > 8) { const li = document.createElement('li'); li.textContent = `…and ${details.length - 8} more`; ul.appendChild(li); }
            const x = document.createElement('button');
            x.textContent = '✕';
            x.style.cssText = 'position:absolute; top:8px; right:10px; background:none; border:0; color:inherit; cursor:pointer; font-size:14px;';
            x.onclick = () => t.remove();
            t.style.paddingRight = '36px';
            t.appendChild(ul); t.appendChild(x);
            document.body.appendChild(t);
            return;
        }
        document.body.appendChild(t);
        setTimeout(() => t.remove(), 5200);
    }

    /* ── Banner above the tabs ─────────────────────────────────────────── */
    function renderBanner(f) {
        const el = document.getElementById(cfg.bannerId);
        if (!el) return;
        if (!f) { el.style.display = 'none'; return; }
        const box = (bg, border, html) => `<div style="display:flex; align-items:center; justify-content:space-between; gap:16px; flex-wrap:wrap;
            background:${bg}; border:1px solid ${border}; border-radius:12px; padding:14px 18px; font-size:13px; color:var(--pq-text);">${html}</div>`;
        const btn = (label, primary) => `<button type="button" onclick="ProjectSync.open()" style="background:${primary ? '#3B82F6' : 'var(--pq-card)'}; color:${primary ? '#fff' : 'var(--pq-text)'};
            border:1px solid ${primary ? '#3B82F6' : 'var(--pq-border)'}; padding:8px 14px; border-radius:8px; cursor:pointer; font-size:12.5px; font-weight:600; white-space:nowrap; font-family:inherit;">${label}</button>`;
        let html = '';
        if (f.error) {
            html = box('#EF444414', '#EF444455', `<span>⚠️ Couldn't read this project's campaign list: ${esc(f.error)}</span>`);
        } else if (!f.configured) {
            html = box('#3B82F614', '#3B82F655', `<span><b>No ${esc(cfg.label)} campaigns linked to this project yet.</b> This dashboard only shows campaigns saved for this project
                ${f.hidden_count ? `— ${plural(f.hidden_count, 'campaign')} in the account (${money(f.hidden_spend)} spend) are hidden` : ''}. Pick the ones that belong here.</span>`
                + btn(`⟳ Sync with ${esc(cfg.label)}`, true));
        } else if (f.hidden_count > 0) {
            html = box('var(--pq-surface)', 'var(--pq-border)', `<span style="color:var(--pq-text-dim);">Showing <b style="color:var(--pq-text)">${plural(f.shown, 'campaign')}</b> linked to this project ·
                ${plural(f.hidden_count, 'other campaign')} in the account hidden (${money(f.hidden_spend)} spend)</span>` + btn('Manage campaigns', false));
        }
        el.innerHTML = html;
        el.style.display = html ? 'block' : 'none';
    }

    /* ── Sync window ───────────────────────────────────────────────────── */
    function close() { const o = document.getElementById('ps-overlay'); if (o) o.remove(); }

    function chips() {
        document.querySelectorAll('#ps-chips button').forEach(b => {
            const on = b.dataset.f === S.filter;
            b.style.background = on ? 'var(--pq-border)' : 'transparent';
            b.style.color = on ? 'var(--pq-text)' : 'var(--pq-text-dim)';
        });
    }

    function leadsOf(c) { return Math.max(c.leads || 0, S.fromAds[c.id] || 0); }

    function render() {
        const body = document.getElementById('ps-body');
        if (!body) return;
        if (S.loading) { body.innerHTML = `<div style="padding:48px; text-align:center; color:var(--pq-text-dim);">Loading campaigns from ${esc(cfg.label)}…</div>`; return; }
        const q = S.q.trim().toLowerCase();
        const rows = S.list.filter(c => {
            if (q && !c.name.toLowerCase().includes(q) && !String(c.id).includes(q)) return false;
            if (S.filter === 'selected') return S.selected.has(c.id);
            if (S.filter === 'leads') return leadsOf(c) > 0;
            if (S.filter === 'active') return /^(ACTIVE|ENABLED|RUNNING)$/i.test(c.status || '');
            if (S.filter === 'awareness') return S.selected.has(c.id) && typeOf(c) === 'awareness';
            return true;
        });
        body.innerHTML = !rows.length
            ? `<div style="padding:40px; text-align:center; color:var(--pq-text-dim);">No campaigns match.</div>`
            : rows.map(c => {
                const on = S.selected.has(c.id);
                const leads = leadsOf(c);
                const st = String(c.status || '—');
                const stColor = /^(ACTIVE|ENABLED|RUNNING)$/i.test(st) ? '#10B981' : 'var(--pq-text-dim)';
                const t = typeOf(c);
                const seg = (v, l) => `<button type="button" onclick="event.preventDefault(); event.stopPropagation(); ProjectSync._type('${esc(c.id)}', '${v}')" aria-pressed="${t === v}"
                    style="border:none; border-radius:6px; padding:3px 9px; font-size:11px; cursor:pointer; font-family:inherit; font-weight:600; background:${t === v ? (v === 'awareness' ? '#8B5CF6' : '#3B82F6') : 'transparent'}; color:${t === v ? '#fff' : 'var(--pq-text-dim)'};">${l}</button>`;
                const typeCtl = on ? `<span title="Awareness campaigns show in the dashboards' Awareness tab (and All); the Performance tab leaves them out" style="display:inline-flex; gap:2px; background:var(--pq-card); border:1px solid var(--pq-border); border-radius:8px; padding:2px;">${seg('performance', 'Performance')}${seg('awareness', 'Awareness')}</span>` : '<span></span>';
                return `<label class="ps-row" style="display:grid; grid-template-columns:22px 1fr auto auto auto; gap:12px; align-items:center; padding:11px 16px; border-bottom:1px solid var(--pq-border); cursor:pointer; ${on ? 'background:#3B82F610;' : ''}">
                    <input type="checkbox" ${on ? 'checked' : ''} onchange="ProjectSync._toggle('${esc(c.id)}', this.checked)" style="width:16px; height:16px; accent-color:#3B82F6;">
                    <span style="min-width:0;">
                        <span style="display:block; font-size:13px; color:var(--pq-text); font-weight:${on ? 600 : 400}; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;">${esc(c.saved_name || c.name)}</span>
                        <span style="display:flex; gap:6px; margin-top:4px; flex-wrap:wrap; font-size:10.5px;">
                            ${c.in_project ? `<span style="color:#3B82F6; border:1px solid #3B82F655; border-radius:99px; padding:1px 7px;">In project</span>` : ''}
                            ${leads ? `<span style="color:#10B981; border:1px solid #10B98155; border-radius:99px; padding:1px 7px;">${plural(leads, 'lead')} in this project</span>` : ''}
                            ${c.saved_name ? `<span style="color:#F59E0B; border:1px solid #F59E0B55; border-radius:99px; padding:1px 7px;" title="Refresh details to use the new name">Renamed in ${esc(cfg.label)}: ${esc(c.name)}</span>` : ''}
                            ${c.awareness_hint ? `<span style="color:#8B5CF6; border:1px solid #8B5CF655; border-radius:99px; padding:1px 7px;" title="From the campaign's ${cfg.platform === 'meta' ? 'objective' : 'bidding strategy'} in ${esc(cfg.label)}">Looks like awareness${c.objective ? ' · ' + esc(String(c.objective).replace(/^OUTCOME_/, '').replace(/_/g, ' ').toLowerCase()) : (c.bidding ? ' · ' + esc(String(c.bidding).replace(/_/g, ' ').toLowerCase()) : '')}</span>` : ''}
                            <span style="color:var(--pq-muted);">ID ${esc(c.id)}</span>
                        </span>
                    </span>
                    <span class="ps-type">${typeCtl}</span>
                    <span class="ps-st" style="font-size:11px; color:${stColor}; white-space:nowrap;">${esc(st.replace(/_/g, ' ').toLowerCase())}</span>
                    <span class="ps-sp" style="font-family:'JetBrains Mono',monospace; font-size:12px; color:var(--pq-text); text-align:right; min-width:90px;">${money(c.spend)}</span>
                </label>`;
            }).join('');
        const add = [...S.selected].filter(id => !S.original.has(id));
        const rem = [...S.original].filter(id => !S.selected.has(id));
        const sum = document.getElementById('ps-summary');
        const tc = Object.keys(typeChanges()).filter(id => S.original.has(id)).length;
        const nAw = [...S.selected].filter(id => { const c = S.list.find(x => x.id === id); return c && typeOf(c) === 'awareness'; }).length;
        if (sum) sum.innerHTML = `<b style="color:var(--pq-text)">${S.selected.size}</b> selected` + (nAw ? ` (<span style="color:#8B5CF6">${nAw} awareness</span>)` : '')
            + (add.length ? ` · <span style="color:#10B981">+${add.length} to add</span>` : '') + (rem.length ? ` · <span style="color:#EF4444">−${rem.length} to remove</span>` : '')
            + (tc ? ` · <span style="color:#8B5CF6">${plural(tc, 'type change')}</span>` : '');
        const save = document.getElementById('ps-save');
        if (save) save.disabled = !(add.length || rem.length || tc);
        chips();
    }

    async function postJson(action, body) {
        const res = await fetch(url(action), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body || {}) });
        const data = await res.json().catch(() => ({ success: false, error: 'Invalid response (HTTP ' + res.status + ')' }));
        if (!data.success) throw new Error(data.error || 'Request failed');
        return data;
    }

    function resultText(d, asked) {
        const parts = [];
        const n = Number(d.campaigns) || 0;
        if (n || asked) parts.push((asked ? `${n} of ${plural(asked, 'campaign')}` : plural(n, 'campaign')) + ' synced'
            + (cfg.groupWord && n ? ` (${d.adgroups} ${cfg.groupWord}, ${plural(d.ads, 'ad')})` : ''));
        if (d.removed) parts.push(`${d.removed} removed`);
        if (d.leads_filled) parts.push(`campaign name filled on ${plural(d.leads_filled, 'lead')}`);
        if (d.types_changed) parts.push(`${plural(d.types_changed, 'campaign type')} saved`);
        const failed = (d.failed || []).length;
        const errs = (d.errors || []).length;
        return (parts.join(' · ') || 'Saved')
            + (failed ? ` · ⚠️ ${plural(failed, 'campaign')} could not be read from ${cfg.label}` : '')
            + (errs > failed ? ` · ⚠️ ${errs - failed} with missing ad sets / ads` : '');
    }
    function showResult(prefix, d, asked) {
        const errs = d.errors || [];
        if (errs.length) console.warn('[ProjectSync] ' + cfg.label + ' sync problems:', errs);
        toast(prefix + resultText(d, asked), errs.length ? 'warn' : 'success', errs.length ? errs : null);
    }

    // phone: each campaign on two lines (name + spend, then Performance / Awareness + status)
    function addCss() {
        if (document.getElementById('ps-css')) return;
        const st = document.createElement('style'); st.id = 'ps-css';
        st.textContent = `@media (max-width: 640px) {
            #ps-overlay { padding: 8px !important; }
            #ps-overlay .ps-row { grid-template-columns: 22px minmax(0, 1fr) auto !important; row-gap: 8px !important; padding: 10px 12px !important; }
            #ps-overlay .ps-row > span:nth-child(2) > span:first-child { white-space: normal !important; }
            #ps-overlay .ps-row .ps-sp { grid-column: 3; grid-row: 1; min-width: 0 !important; }
            #ps-overlay .ps-row .ps-type { grid-column: 2; grid-row: 2; }
            #ps-overlay .ps-row .ps-st { grid-column: 3; grid-row: 2; text-align: right; }
            #ps-summary { flex: 1 1 100% !important; }
            #ps-summary + * , #ps-save { flex: 1 1 auto; }
            #ps-save { order: -1; }
        }`;
        document.head.appendChild(st);
    }

    async function open() {
        close();
        addCss();
        const r = (cfg.getRange && cfg.getRange()) || {};
        const o = document.createElement('div');
        o.id = 'ps-overlay';
        o.style.cssText = 'position:fixed; inset:0; background:rgba(0,0,0,.6); z-index:100000; display:flex; align-items:center; justify-content:center; padding:16px;';
        o.addEventListener('click', e => { if (e.target === o) close(); });
        const word = cfg.groupWord ? `${cfg.groupWord} and ads` : 'details';
        o.innerHTML = `
          <div role="dialog" aria-label="Sync with ${esc(cfg.label)}" style="background:var(--pq-surface); border:1px solid var(--pq-border); border-radius:14px; width:min(860px,100%); max-height:88vh; display:flex; flex-direction:column; box-shadow:0 24px 64px rgba(0,0,0,.5); font-family:'Sora',sans-serif;">
            <div style="padding:18px 20px 14px; border-bottom:1px solid var(--pq-border);">
              <div style="display:flex; justify-content:space-between; align-items:flex-start; gap:12px;">
                <div>
                  <div style="font-size:16px; font-weight:700; color:var(--pq-text);">Project campaigns · Sync with ${esc(cfg.label)}</div>
                  <div style="font-size:12.5px; color:var(--pq-text-dim); margin-top:4px; line-height:1.5;">Tick the campaigns that belong to this project. Only these — with the names saved here — appear on the dashboard, in exports and in reports.
                    Saving also pulls each campaign's ${esc(word)}. Campaigns with <span style="color:#10B981">leads in this project</span> are suggested.
                    <br>Mark each ticked campaign <b style="color:#3B82F6">Performance</b> or <b style="color:#8B5CF6">Awareness</b> — the dashboards' <b>Performance</b> tab leaves awareness campaigns out, the <b>Awareness</b> tab shows only them.</div>
                </div>
                <button type="button" onclick="ProjectSync.close()" aria-label="Close" style="background:none; border:none; color:var(--pq-text-dim); font-size:20px; cursor:pointer; line-height:1;">✕</button>
              </div>
              <div style="display:flex; gap:10px; margin-top:14px; flex-wrap:wrap; align-items:center;">
                <input type="search" placeholder="Search campaign name or ID…" oninput="ProjectSync._search(this.value)"
                  style="flex:1; min-width:200px; background:var(--pq-card); border:1px solid var(--pq-border); color:var(--pq-text); border-radius:8px; padding:8px 12px; font-size:12.5px; font-family:inherit; outline:none;">
                <div id="ps-chips" style="display:flex; gap:2px; background:var(--pq-card); border:1px solid var(--pq-border); border-radius:8px; padding:3px;">
                  ${[['all', 'All'], ['selected', 'Selected'], ['leads', 'Has leads'], ['active', 'Active'], ['awareness', 'Awareness']].map(([f, l]) =>
                    `<button type="button" data-f="${f}" onclick="ProjectSync._filter('${f}')" style="border:none; border-radius:6px; padding:5px 10px; font-size:11.5px; cursor:pointer; font-family:inherit;">${l}</button>`).join('')}
                </div>
                <button type="button" onclick="ProjectSync._tickSuggested()" style="background:none; border:1px solid #10B98166; color:#10B981; border-radius:8px; padding:7px 12px; font-size:12px; cursor:pointer; font-family:inherit;">✓ Tick all with leads</button>
              </div>
              <div id="ps-note" style="font-size:11.5px; color:var(--pq-muted); margin-top:10px;">Spend shown for ${r.since && r.until ? esc(r.since + ' → ' + r.until) : 'the last 30 days'}.${cfg.suggestFromAds ? ' <span id="ps-ads-note">Checking which ads brought leads…</span>' : ''}</div>
            </div>
            <div id="ps-body" style="overflow-y:auto; flex:1; min-height:200px;"></div>
            <div style="padding:14px 20px; border-top:1px solid var(--pq-border); display:flex; align-items:center; gap:10px; flex-wrap:wrap;">
              <span id="ps-summary" style="font-size:12.5px; color:var(--pq-text-dim); flex:1;"></span>
              <button type="button" id="ps-refresh" onclick="ProjectSync._refresh()" title="Re-read names, statuses${cfg.groupWord ? ', ' + esc(cfg.groupWord) + ' and ads' : ''} of the campaigns already in this project"
                style="background:none; border:1px solid var(--pq-border); color:var(--pq-text); border-radius:8px; padding:9px 14px; font-size:12.5px; cursor:pointer; font-family:inherit;">↻ Refresh details</button>
              <button type="button" onclick="ProjectSync.close()" style="background:none; border:1px solid var(--pq-border); color:var(--pq-text-dim); border-radius:8px; padding:9px 14px; font-size:12.5px; cursor:pointer; font-family:inherit;">Cancel</button>
              <button type="button" id="ps-save" onclick="ProjectSync._save()" disabled style="background:#3B82F6; border:none; color:#fff; border-radius:8px; padding:9px 16px; font-size:12.5px; font-weight:600; cursor:pointer; font-family:inherit;">Save & sync</button>
            </div>
          </div>`;
        document.body.appendChild(o);
        S.loading = true; S.filter = 'all'; S.q = ''; S.fromAds = {}; render();

        try {
            const res = await fetch(url('list', r.since && r.until ? `since=${encodeURIComponent(r.since)}&until=${encodeURIComponent(r.until)}` : ''));
            const data = await res.json();
            if (!data.success) throw new Error(data.error || `Could not load campaigns from ${cfg.label}`);
            S.list = (data.campaigns || []).map(c => ({ ...c, id: String(c.id) }));
            S.original = new Set(S.list.filter(c => c.in_project).map(c => c.id));
            S.selected = new Set(S.original);
            S.types = {}; S.origTypes = {};
            S.list.forEach(c => { if (c.in_project) { S.types[c.id] = c.campaign_type || 'performance'; S.origTypes[c.id] = c.campaign_type || 'performance'; } });
            if (!S.original.size) S.list.forEach(c => { if (c.leads > 0) S.selected.add(c.id); });   // first time: pre-tick suggestions
            S.loading = false; render();
            if (data.errors && data.errors.length) document.getElementById('ps-note').innerHTML += `<br><span style="color:#EF4444">${esc(data.errors.join(' · '))}</span>`;
        } catch (err) {
            S.loading = false;
            const b = document.getElementById('ps-body');
            if (b) b.innerHTML = `<div style="padding:40px; text-align:center; color:#EF4444;">${esc(err.message)}</div>`;
            return;
        }

        if (cfg.suggestFromAds) {
            try {
                const data = await postJson('from_leads');
                (data.campaigns || []).forEach(c => { S.fromAds[String(c.id)] = c.leads; });
                if (!S.original.size) Object.keys(S.fromAds).forEach(id => { if (S.list.some(c => c.id === id)) S.selected.add(id); });
                const n = document.getElementById('ps-ads-note');
                if (n) n.textContent = `Checked ${plural(data.ads_checked, 'ad ID')} from your leads.`;
                render();
            } catch (e) {
                const n = document.getElementById('ps-ads-note');
                if (n) n.textContent = 'Could not check lead ad IDs (' + e.message + ').';
            }
        }
    }

    async function save() {
        const add = [...S.selected].filter(id => !S.original.has(id));
        const remove = [...S.original].filter(id => !S.selected.has(id));
        const types = typeChanges();
        if (remove.length && !confirm(`Remove ${plural(remove.length, 'campaign')} from this project? They will no longer appear on the dashboard, in exports or in reports.`)) return;
        const btn = document.getElementById('ps-save');
        btn.disabled = true; btn.textContent = add.length ? `Syncing ${plural(add.length, 'campaign')}…` : 'Saving…';
        if (!add.length && !remove.length && !Object.keys(types).length) { btn.textContent = 'Save & sync'; return; }
        try {
            const d = await postJson('save', { add, remove, types });
            close();
            showResult('✅ ', d, add.length);
            if (cfg.onSaved) cfg.onSaved();
        } catch (err) {
            btn.disabled = false; btn.textContent = 'Save & sync';
            toast('❌ ' + err.message, 'error');
        }
    }

    async function refresh() {
        const btn = document.getElementById('ps-refresh');
        btn.disabled = true; btn.textContent = 'Refreshing…';
        try {
            const d = await postJson('refresh');
            close();
            showResult('✅ Refreshed: ', d, 0);
            if (cfg.onSaved) cfg.onSaved();
        } catch (err) {
            btn.disabled = false; btn.textContent = '↻ Refresh details';
            toast('❌ ' + err.message, 'error');
        }
    }

    document.addEventListener('keydown', e => { if (e.key === 'Escape') close(); });

    window.ProjectSync = {
        init(options) { cfg = Object.assign({}, cfg, options || {}); return this; },
        open, close, renderBanner,
        _toggle(id, on) { on ? S.selected.add(String(id)) : S.selected.delete(String(id)); render(); },
        _type(id, t) { S.types[String(id)] = t === 'awareness' ? 'awareness' : 'performance'; render(); },
        _filter(f) { S.filter = f; render(); },
        _search(v) { S.q = v; render(); },
        _tickSuggested() { S.list.forEach(c => { if (leadsOf(c) > 0) S.selected.add(c.id); }); render(); },
        _save: save, _refresh: refresh,
    };
})();
