/**
 * js/portfolio_pdf.js — the portfolio PDF ("Export PDF (Meta + Google)"), shared by the main dashboard
 * (Overview) and the Meta / Google / Taboola dashboards.
 *
 *   PortfolioPDF.export({ since, until, detail: 'campaign'|'adset'|'ad', api, logo, onStatus[, campaigns] })
 *   Asks first "All campaigns or select campaigns?" (js/report_picker.js) unless `campaigns` is given
 *   (null = all, {meta: [ids], google: [ids]}). Resolves with null when the person cancels.
 *
 * Data: portfolio_report_api.php. Every section is drawn on its own and placed on A4 pages, so no
 * row is cut in half; colours are fixed (light) whatever theme the dashboard is in.
 * Needs html2canvas + jsPDF — loaded from cdnjs when the page doesn't have them yet.
 */
(function () {
    'use strict';
    const C = { brand: '#E84E24', brandDark: '#B8391A', ink: '#1F2937', muted: '#64748B', line: '#E2E8F0', soft: '#F8FAFC', meta: '#1877F2', google: '#EA4335', taboola: '#0E7C66', good: '#047857', warn: '#B45309' };
    const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
    const num = n => Math.round(Number(n) || 0).toLocaleString('en-IN');
    const money = n => (Number(n) > 0 ? '₹' + Math.round(Number(n)).toLocaleString('en-IN') : '—');
    const pct = n => (Number(n) || 0).toFixed(1) + '%';
    const PCOLOR = { Meta: C.meta, Google: C.google, Taboola: C.taboola };

    // "All campaigns or select campaigns?" — js/report_picker.js, next to this file
    const HERE = (document.currentScript && document.currentScript.src || '').replace(/[^/]*$/, '');
    async function pickCampaigns(o, campaignsApi, title) {
        if (o.campaigns !== undefined) return o.campaigns;          // the caller chose already (null = all)
        if (!window.PQReportPicker) {
            await new Promise((ok, fail) => {
                const s = document.createElement('script');
                s.src = HERE + 'report_picker.js?v=4'; s.onload = ok; s.onerror = () => fail(new Error('Could not load the campaign picker.'));
                document.head.appendChild(s);
            });
        }
        return window.PQReportPicker.ask({ api: campaignsApi, title });
    }

    function loadScript(src) {
        return new Promise((ok, fail) => {
            const s = document.createElement('script');
            s.src = src; s.onload = ok; s.onerror = () => fail(new Error('Could not load ' + src.split('/').pop()));
            document.head.appendChild(s);
        });
    }
    async function libs() {
        if (typeof window.html2canvas === 'undefined') await loadScript('https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js');
        if (!(window.jspdf && window.jspdf.jsPDF) && !window.jsPDF) await loadScript('https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js');
        return (window.jspdf && window.jspdf.jsPDF) || window.jsPDF;
    }

    /* ── building blocks (each becomes one image in the PDF) ── */
    const box = inner => `<div style="width:794px;box-sizing:border-box;padding:0 2px;background:#fff;color:${C.ink};font-family:'Sora',Arial,sans-serif;">${inner}</div>`;
    const th = (t, left) => `<th style="background:${C.brand};color:#fff;padding:7px 8px;font-size:9.5px;font-weight:600;text-transform:uppercase;letter-spacing:.03em;text-align:${left ? 'left' : 'right'};white-space:nowrap;">${t}</th>`;
    const td = (v, o = {}) => `<td style="padding:6px 8px;border-bottom:1px solid ${C.line};font-size:10.5px;color:${o.color || C.ink};text-align:${o.left ? 'left' : 'right'};${o.bold ? 'font-weight:700;' : ''}${o.left ? '' : 'font-variant-numeric:tabular-nums;white-space:nowrap;'}${o.pad ? 'padding-left:' + o.pad + 'px;' : ''}">${v}</td>`;
    // Users & Roles → "Hide numbers": columns / cards this role may not see are left out of the PDF
    const HIDE = window.PQ_HIDE_METRICS || [];
    const H = k => HIDE.indexOf(k) >= 0;
    const COLS = [
        ['Spend', r => money(r.spend)], ['Impr.', r => num(r.impressions)], ['Clicks', r => num(r.clicks)], ['CTR', r => pct(r.ctr)],
        ['Leads', r => num(r.leads)], ['CPL', r => money(r.cpl)],
        ['Qualified', r => num(r.ql), 'qualified'], ['CPQL', r => money(r.cpql), 'cpql'],
        ['Site visits', r => num(r.sv_done), 'sitevisits'], ['CPSV', r => money(r.cpsv), 'cpsv'],
    ].filter(c => !c[2] || !H(c[2]));
    const METRIC_HEAD = COLS.map(c => c[0]);
    const metricCells = (r, o = {}) => COLS.map(c => td(c[1](r), o)).join('');

    function headerBlock(d, projName, logo) {
        const s = d.summary;
        const card = (label, value, sub) => `<div style="flex:1;min-width:0;border:1px solid ${C.line};border-radius:10px;padding:12px 12px 10px;background:${C.soft};">
            <div style="font-size:9px;color:${C.muted};text-transform:uppercase;letter-spacing:.05em;">${label}</div>
            <div style="font-size:19px;font-weight:700;margin-top:4px;color:${C.ink};">${value}</div>${sub ? `<div style="font-size:9px;color:${C.muted};margin-top:2px;">${sub}</div>` : ''}</div>`;
        const um = s.unmapped ? (s.unmapped.meta + s.unmapped.google + s.unmapped.unknown) : 0;
        return box(`
            <div style="background:linear-gradient(135deg,${C.brand},${C.brandDark});color:#fff;border-radius:12px;padding:24px 26px;display:flex;justify-content:space-between;align-items:center;">
              <div>
                <div style="font-size:10px;letter-spacing:.18em;font-weight:700;text-transform:uppercase;color:#FFE3D9;">Campaign performance report</div>
                <div style="font-size:24px;font-weight:700;margin-top:6px;">${esc(projName)}</div>
                <div style="font-size:12px;margin-top:4px;color:#FFF1EC;">${esc(d.platforms.join(' + '))} · ${esc(fmtDate(d.since))} – ${esc(fmtDate(d.until))}</div>
                <div style="font-size:10px;margin-top:10px;color:#FFE3D9;">Generated ${esc(d.generated_at)} · spend from the ad platforms · leads from the CRM</div>
                ${d.selection ? `<div style="font-size:10.5px;margin-top:6px;color:#fff;font-weight:600;">Selected campaigns only (${num(d.selection.count)}): ${esc(d.selection.names.slice(0, 6).join(' · '))}${d.selection.names.length > 6 ? ' +' + (d.selection.names.length - 6) + ' more' : ''}</div>` : ''}
              </div>
              ${logo ? `<div style="background:#fff;border-radius:10px;padding:8px 10px;"><img src="${esc(logo)}" style="height:44px;display:block;" crossorigin="anonymous"></div>` : ''}
            </div>
            <div style="display:flex;gap:8px;margin-top:14px;">
              ${card('Spend', money(s.spend))}${card('Leads', num(s.total_leads), 'CPL ' + money(s.avg_cpl))}
              ${!H('qualified') ? card('Qualified', num(s.positive_prospects), H('cpql') ? '' : 'CPQL ' + money(s.cpql)) : (!H('cpql') ? card('CPQL', money(s.cpql)) : '')}
              ${!H('sitevisits') ? card('Site visits', num(s.site_visits_done), H('cpsv') ? '' : 'CPSV ' + money(s.cpsv)) : (!H('cpsv') ? card('CPSV', money(s.cpsv)) : '')}
              ${card('Impressions', num(s.impressions), num(s.clicks) + ' clicks')}
            </div>
            ${um ? `<div style="margin-top:10px;padding:9px 12px;border:1px solid #FCD34D;background:#FFFBEB;border-radius:8px;font-size:10px;color:${C.warn};">
                ${num(um)} lead(s) in this period are not under any of this project's campaigns (Meta ${num(s.unmapped.meta)} · Google ${num(s.unmapped.google)}${s.unmapped.unknown ? ' · no source ' + num(s.unmapped.unknown) : ''}) and are not counted here. Map them in Unmapped Leads.</div>` : ''}
            ${(d.warnings || []).length ? `<div style="margin-top:8px;padding:9px 12px;border:1px solid #FCA5A5;background:#FEF2F2;border-radius:8px;font-size:10px;color:#B91C1C;">${d.warnings.map(esc).join('<br>')}</div>` : ''}`);
    }
    function fmtDate(s) { const d = new Date(s + 'T00:00:00'); return isNaN(d) ? s : d.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }); }

    function monthTitle(m) {
        return box(`<div style="margin-top:18px;display:flex;align-items:baseline;gap:10px;border-bottom:2px solid ${C.brand};padding-bottom:5px;">
            <div style="font-size:15px;font-weight:700;color:${C.brand};">${esc(m.label)}</div><div style="font-size:10px;color:${C.muted};">${esc(fmtDate(m.since))} – ${esc(fmtDate(m.until))}</div></div>`);
    }
    function channelBlock(m) {
        const plats = m.rows.filter(r => r.level === 0);
        return box(`<div style="font-size:11px;font-weight:700;margin:12px 0 6px;color:${C.ink};">Channel summary</div>
            <table style="width:100%;border-collapse:collapse;"><thead><tr>${th('Platform', true)}${METRIC_HEAD.map(h => th(h)).join('')}</tr></thead><tbody>
            ${plats.map(r => `<tr>${td(`<span style="color:${PCOLOR[r.platform] || C.ink};font-weight:700;">${esc(r.platform)}</span>`, { left: true })}${metricCells(r)}</tr>`).join('')}
            <tr style="background:#FDEEE9;">${td('Total', { left: true, bold: true })}${metricCells(m.total, { bold: true })}</tr></tbody></table>`);
    }
    /** One platform's campaign → ad set → ad table, split into chunks so it can run over pages. */
    function platformBlocks(m, platform, detail) {
        const maxLevel = detail === 'ad' ? 3 : detail === 'adset' ? 2 : 1;
        const rows = m.rows.filter(r => r.platform === platform && r.level >= 1 && r.level <= maxLevel);
        if (!rows.length) return [];
        const grp = platform === 'Google' ? 'ad group' : 'ad set';
        const head = `<tr>${th(`Campaign${maxLevel >= 2 ? ' › ' + grp : ''}${maxLevel >= 3 ? ' › ad' : ''}`, true)}${METRIC_HEAD.map(h => th(h)).join('')}</tr>`;
        const line = r => {
            const style = r.level === 1 ? { left: true, bold: true } : { left: true, pad: r.level === 2 ? 22 : 40, color: r.level === 3 ? C.muted : C.ink };
            const o = r.level === 1 ? { bold: true } : (r.level === 3 ? { color: C.muted } : {});
            return `<tr style="${r.level === 1 ? `background:${C.soft};` : ''}">${td(esc(r.name), style)}${metricCells(r, o)}</tr>`;
        };
        const out = [];
        const CH = 26;
        for (let i = 0; i < rows.length; i += CH) {
            const part = rows.slice(i, i + CH);
            out.push(box(`${i === 0 ? `<div style="font-size:11px;font-weight:700;margin:14px 0 6px;color:${PCOLOR[platform] || C.ink};">${esc(platform)} — by campaign${maxLevel >= 2 ? ' and ' + grp : ''}${maxLevel >= 3 ? ' and ad' : ''}</div>` : `<div style="font-size:9px;color:${C.muted};margin:6px 0 4px;">${esc(platform)} (continued)</div>`}
                <table style="width:100%;border-collapse:collapse;table-layout:fixed;"><colgroup><col style="width:30%">${METRIC_HEAD.map(() => '<col>').join('')}</colgroup>
                <thead>${head}</thead><tbody>${part.map(line).join('')}</tbody></table>`));
        }
        return out;
    }
    function dispositionBlock(m) {
        const d = Object.assign({}, m.disposition || {});
        if (H('qualified')) delete d.QUALIFIED;   // hidden for this role
        const total = Object.values(d).reduce((a, b) => a + b, 0);
        if (!total) return null;
        return box(`<div style="font-size:11px;font-weight:700;margin:14px 0 6px;">Lead status (CRM)</div>
            <div style="display:flex;gap:8px;">${Object.entries(d).map(([k, v]) => `<div style="flex:1;border:1px solid ${C.line};border-radius:8px;padding:9px 10px;">
                <div style="font-size:9px;color:${C.muted};text-transform:uppercase;letter-spacing:.04em;">${esc(k)}</div>
                <div style="font-size:16px;font-weight:700;margin-top:2px;color:${k === 'QUALIFIED' ? C.good : C.ink};">${num(v)} <span style="font-size:10px;color:${C.muted};font-weight:400;">${total ? Math.round(v / total * 100) : 0}%</span></div></div>`).join('')}</div>`);
    }
    function insightBlock(text) {
        if (!text) return null;
        const html = esc(text)
            .replace(/What's working:/gi, `<b style="display:block;color:${C.good};margin-top:4px;">✓ What's working</b>`)
            .replace(/Where the value leaks:/gi, `<b style="display:block;color:${C.warn};margin-top:10px;">⚠ Where the value leaks</b>`)
            .replace(/The lever:/gi, `<b style="display:block;color:${C.brand};margin-top:10px;">⚙ The lever</b>`);
        return box(`<div style="margin-top:18px;font-size:13px;font-weight:700;color:${C.brand};">Insights</div>
            <div style="margin-top:6px;background:#FFF7ED;border-left:3px solid ${C.brand};border-radius:6px;padding:12px 16px;font-size:10.5px;line-height:1.65;white-space:pre-line;">${html}</div>`);
    }

    async function render(blocks, JsPDF, footer) {
        const holder = document.createElement('div');
        holder.style.cssText = 'position:fixed;left:0;top:0;width:794px;z-index:-9999;opacity:0.01;pointer-events:none;background:#fff;';
        document.body.appendChild(holder);
        const pdf = new JsPDF('p', 'mm', 'a4');
        const W = 210, H = 297, M = 10, FOOT = 8, CW = W - 2 * M, mmPerPx = CW / 794;
        let y = M, page = 1;
        try {
            if (document.fonts && document.fonts.ready) await document.fonts.ready;
            for (const html of blocks.filter(Boolean)) {
                holder.innerHTML = html;
                const el = holder.firstElementChild;
                await Promise.all([...el.querySelectorAll('img')].map(img => img.complete ? 0 : new Promise(r => { img.onload = img.onerror = r; })));
                const canvas = await window.html2canvas(el, { scale: 2, backgroundColor: '#ffffff', useCORS: true, logging: false, width: 794, windowWidth: 794 });
                const h = canvas.height / 2 * mmPerPx;
                if (y + h > H - M - FOOT && y > M) { pdf.addPage(); page++; y = M; }
                pdf.addImage(canvas.toDataURL('image/jpeg', 0.92), 'JPEG', M, y, CW, h);
                y += h + 2;
            }
            const pages = pdf.getNumberOfPages();
            for (let i = 1; i <= pages; i++) {
                pdf.setPage(i);
                pdf.setFontSize(7.5);
                pdf.setTextColor(120);
                pdf.text(footer, M, H - 5);
                pdf.text(`${i} / ${pages}`, W - M, H - 5, { align: 'right' });
            }
            return pdf;
        } finally {
            holder.remove();
        }
    }

    async function exportPdf(opt) {
        const o = Object.assign({ api: 'portfolio_report_api.php', detail: 'adset', logo: '', onStatus: () => {} }, opt || {});
        if (!o.since || !o.until) throw new Error('Choose a date range first.');
        const pick = await pickCampaigns(o, o.api.replace(/[^/]*$/, 'report_campaigns_api.php'), 'Campaign report');
        if (pick === false) return null;                            // cancelled
        o.onStatus('Loading data…');
        const JsPDF = await libs();
        const qs = new URLSearchParams({ since: o.since, until: o.until });
        if (pick) qs.set('campaigns', window.PQReportPicker.param(pick));
        if (o.force) qs.set('force', '1');
        const res = await fetch(`${o.api}?${qs}`, { credentials: 'same-origin' });
        const d = await res.json().catch(() => ({ success: false, error: `Server error (HTTP ${res.status}).` }));
        if (!d.success) throw new Error(d.error || 'Could not build the report.');
        o.onStatus('Building PDF…');
        const projName = d.project || o.project || 'Project';
        const blocks = [headerBlock(d, projName, o.logo)];
        for (const m of d.months) {
            blocks.push(monthTitle(m), channelBlock(m));
            for (const p of d.platforms) blocks.push(...platformBlocks(m, p, o.detail));
            blocks.push(dispositionBlock(m));
        }
        blocks.push(insightBlock(d.insight_text));
        const pdf = await render(blocks, JsPDF, `${projName} · ${d.platforms.join(' + ')} · ${fmtDate(d.since)} – ${fmtDate(d.until)}`);
        const safe = String(projName).replace(/[^A-Za-z0-9]+/g, '_').replace(/^_|_$/g, '');
        pdf.save(`${safe || 'Portfolio'}_Report${pick ? '_' + pick.count + '_campaigns' : ''}_${d.since}_to_${d.until}.pdf`);
        return d;
    }

    window.PortfolioPDF = { export: exportPdf };
})();
