/**
 * column_picker.js — "Modify columns" for the campaign tables on the Meta and Google dashboards (like Google Ads):
 * tick the columns to show, drag to reorder, remove, add extra metrics and custom formula columns.
 *
 *   PQColumns.apply({ table, key: 'meta'|'google', rows, allRows, lock: 2, host })
 *     table    the rendered <table> (the dashboard draws it as before; this rearranges its cells)
 *     rows     data objects of the rows shown (same order as the table body), allRows = every row (for the totals)
 *     lock     leading columns that always stay first (Status, Campaign)
 *     host     element that gets the "▥ Columns" button
 *   Call it after every render. Layouts are saved per user (column_prefs_api.php) with a copy in this browser.
 */
(function () {
    'use strict';
    const API = 'column_prefs_api.php';
    const ACCENT = '#E8A820';

    /* ── Users & Roles → "Hide numbers": metrics this role may not see (metric_guard.js) ── */
    const mHid = k => typeof window.pqMetricHiddenKey === 'function' && window.pqMetricHiddenKey(k);
    const lHid = l => typeof window.pqMetricHidden === 'function' && window.pqMetricHidden(l);
    /** extra columns built on a metric: hidden with it */
    const EXTRA_USES = { ql_rate: ['qualified'], sv_rate: ['qualified', 'sitevisits'], lead_to_sv: ['sitevisits'], lost_post_qualified: ['qualified'] };
    /** formula names: qualified / site visits are blocked also when their cost is hidden (spend ÷ qualified = CPQL) */
    const VAR_METRIC = { qualified: ['qualified', 'cpql'], sitevisits: ['sitevisits', 'cpsv'] };
    const varHidden = v => (VAR_METRIC[v] || []).some(mHid);
    const extraHidden = id => id.startsWith('x:') && (EXTRA_USES[id.slice(2)] || []).some(mHid);

    /* ── numbers ── */
    const div = (a, b, m) => (Number(b) > 0 ? Number(a) / Number(b) * (m || 1) : null);
    const has = v => v != null && v !== '' && isFinite(Number(v));
    const FMT = {
        int: v => has(v) ? Math.round(v).toLocaleString('en-IN') : '—',
        money: v => has(v) ? '₹' + Number(v).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) : '—',
        pct: v => has(v) ? Number(v).toFixed(2) + '%' : '—',
        dec: v => has(v) ? Number(v).toLocaleString('en-IN', { maximumFractionDigits: 2 }) : '—'
    };
    const FMT_LABEL = { int: 'Number', money: '₹ Money', pct: '%', dec: 'Decimal' };

    /** Metrics fetched from Meta / Google (app/Ads/platform_metrics.php): key => {label, kind: sum|rate} */
    const PM = () => window.PQ_PM_LABELS || {};
    const isRate = k => (PM()[k] && PM()[k].kind === 'rate') || /_rate$/.test(k);

    /** One data row → the fields formulas can use. */
    function norm(r) {
        r = r || {};
        const n = v => (has(v) ? Number(v) : 0);
        const pm = {};
        for (const [k, v] of Object.entries(r.pm || {})) if (has(v)) pm[k] = Number(v);
        return Object.assign(pm, {
            spend: n(r.spend), impressions: n(r.impressions), clicks: n(r.clicks), reach: has(r.reach) ? Number(r.reach) : null,
            leads: n(r.leads), qualified: n(r.qualified), sitevisits: n(r.walkins ?? r.sitevisits),
            non_qualified: has(r.non_qualified) ? Number(r.non_qualified) : null, to_be_qualified: has(r.to_be_qualified) ? Number(r.to_be_qualified) : null,
            lost_post_qualified: has(r.lost_post_qualified) ? Number(r.lost_post_qualified) : null, conversions: has(r.conversions) ? Number(r.conversions) : null
        }, hiddenVals());
    }
    /** hidden metrics never reach a formula or calculated column */
    function hiddenVals() {
        const o = {};
        for (const v of Object.keys(VAR_METRIC)) if (varHidden(v)) o[v] = null;
        if (mHid('qualified')) o.lost_post_qualified = null;
        return o;
    }
    /** Adds the platform metrics of one row into a running total (rates weighted by impressions). */
    function addPm(acc, pm, wAcc, wNew) {
        const out = Object.assign({}, acc || {});
        for (const [k, v] of Object.entries(pm || {})) {
            if (!has(v)) continue;
            if (isRate(k)) {
                const a = Number(wAcc) || 0, b = Number(wNew) || 0;
                out[k] = (a + b) > 0 ? ((Number(out[k]) || 0) * a + Number(v) * b) / (a + b) : Number(v);
            } else out[k] = (Number(out[k]) || 0) + Number(v);
        }
        return out;
    }
    const BASE_VARS = ['spend', 'impressions', 'clicks', 'reach', 'leads', 'qualified', 'sitevisits', 'non_qualified', 'to_be_qualified', 'lost_post_qualified', 'conversions'];
    let VARS = BASE_VARS.slice();
    const varLabel = v => VAR_LABEL[v] || (PM()[v] && PM()[v].label) || v;
    const VAR_LABEL = { spend: 'Spend', impressions: 'Impressions', clicks: 'Clicks', reach: 'Reach', leads: 'Leads', qualified: 'Qualified', sitevisits: 'Site visits',
                        non_qualified: 'Non-qualified', to_be_qualified: 'To be qualified', lost_post_qualified: 'Lost post qualified', conversions: 'Conversions' };

    /** Extra metrics that can be added (computed from the data rows). */
    const EXTRA = {
        cpc:        { label: 'Avg. CPC', group: 'Performance', fmt: 'money', f: r => div(r.spend, r.clicks) },
        reach:      { label: 'Reach', group: 'Performance', fmt: 'int', f: r => r.reach, needs: 'reach' },
        cp1kreach:  { label: 'Cost per 1,000 reached', group: 'Performance', fmt: 'money', f: r => div(r.spend, r.reach, 1000), needs: 'reach' },
        lead_rate:  { label: 'Lead rate (leads ÷ clicks)', group: 'Leads & conversions', fmt: 'pct', f: r => div(r.leads, r.clicks, 100) },
        ql_rate:    { label: 'Qualified rate (qualified ÷ leads)', group: 'Leads & conversions', fmt: 'pct', f: r => div(r.qualified, r.leads, 100) },
        sv_rate:    { label: 'Site-visit rate (site visits ÷ qualified)', group: 'Leads & conversions', fmt: 'pct', f: r => div(r.sitevisits, r.qualified, 100) },
        lead_to_sv: { label: 'Lead → site visit %', group: 'Leads & conversions', fmt: 'pct', f: r => div(r.sitevisits, r.leads, 100) },
        non_qualified:       { label: 'Non-qualified', group: 'Lead status', fmt: 'int', f: r => r.non_qualified, needs: 'non_qualified' },
        to_be_qualified:     { label: 'To be qualified', group: 'Lead status', fmt: 'int', f: r => r.to_be_qualified, needs: 'to_be_qualified' },
        lost_post_qualified: { label: 'Lost post qualified', group: 'Lead status', fmt: 'int', f: r => r.lost_post_qualified, needs: 'lost_post_qualified' },
        conversions:         { label: 'Conversions (ad platform)', group: 'Leads & conversions', fmt: 'dec', f: r => r.conversions, needs: 'conversions' },
        // calculated from the platform metrics
        link_ctr:      { label: 'Link CTR (link clicks ÷ impr.)', group: 'Calculated from platform metrics', fmt: 'pct', f: r => div(r.pm_link_clicks, r.impressions, 100), needs: 'pm_link_clicks' },
        cp_link_click: { label: 'Cost per link click', group: 'Calculated from platform metrics', fmt: 'money', f: r => div(r.spend, r.pm_link_clicks), needs: 'pm_link_clicks' },
        cp_lpv:        { label: 'Cost per landing page view', group: 'Calculated from platform metrics', fmt: 'money', f: r => div(r.spend, r.pm_landing_page_views), needs: 'pm_landing_page_views' },
        hook_rate:     { label: 'Hook rate (3-sec views ÷ impr.)', group: 'Calculated from platform metrics', fmt: 'pct', f: r => div(r.pm_video_views_3s, r.impressions, 100), needs: 'pm_video_views_3s' },
        cp_thruplay:   { label: 'Cost per ThruPlay', group: 'Calculated from platform metrics', fmt: 'money', f: r => div(r.spend, r.pm_thruplays), needs: 'pm_thruplays' },
        thruplay_rate: { label: 'ThruPlay rate (ThruPlays ÷ impr.)', group: 'Calculated from platform metrics', fmt: 'pct', f: r => div(r.pm_thruplays, r.impressions, 100), needs: 'pm_thruplays' },
        g_cp1k_users:  { label: 'Cost per 1,000 unique users', group: 'Calculated from platform metrics', fmt: 'money', f: r => div(r.spend, r.pm_unique_users, 1000), needs: 'pm_unique_users' },
        g_avg_freq:    { label: 'Avg. impr. per user (impr. ÷ unique users)', group: 'Calculated from platform metrics', fmt: 'dec', f: r => div(r.impressions, r.pm_unique_users), needs: 'pm_unique_users' },
        g_avg_cpv:     { label: 'Avg. CPV (cost ÷ views)', group: 'Calculated from platform metrics', fmt: 'money', f: r => div(r.spend, r.pm_video_views), needs: 'pm_video_views' },
        g_view_rate:   { label: 'View rate (views ÷ impr.)', group: 'Calculated from platform metrics', fmt: 'pct', f: r => div(r.pm_video_views, r.impressions, 100), needs: 'pm_video_views' },
        g_int_rate:    { label: 'Interaction rate', group: 'Calculated from platform metrics', fmt: 'pct', f: r => div(r.pm_interactions, r.impressions, 100), needs: 'pm_interactions' },
        g_cost_conv:   { label: 'Cost / conv.', group: 'Calculated from platform metrics', fmt: 'money', f: r => div(r.spend, r.pm_conversions), needs: 'pm_conversions' },
        g_conv_rate:   { label: 'Conv. rate (conv. ÷ interactions)', group: 'Calculated from platform metrics', fmt: 'pct', f: r => div(r.pm_conversions, r.pm_interactions, 100), needs: 'pm_conversions' }
    };

    /* ── formulas: names, numbers, + - * / ( ) — parsed, never eval'd ── */
    function evalFormula(src, row) {
        const toks = String(src).match(/\s*([A-Za-z_][A-Za-z0-9_]*|\d+(?:\.\d+)?|\.\d+|[()+\-*/])\s*/g);
        if (!toks || toks.join('').replace(/\s/g, '') !== String(src).replace(/\s/g, '')) return null;
        const t = toks.map(x => x.trim()); let i = 0;
        const peek = () => t[i], next = () => t[i++];
        function atom() {
            const x = next();
            if (x === '(') { const v = expr(); if (next() !== ')') throw 0; return v; }
            if (x === '-') return -atom();
            if (/^[\d.]/.test(x)) return parseFloat(x);
            if (/^[A-Za-z_]/.test(x)) { if (!VARS.includes(x)) throw 0; const v = row[x]; return v == null ? NaN : Number(v); }
            throw 0;
        }
        function term() { let v = atom(); while (peek() === '*' || peek() === '/') { const op = next(), w = atom(); v = op === '*' ? v * w : (w === 0 ? NaN : v / w); } return v; }
        function expr() { let v = term(); while (peek() === '+' || peek() === '-') { const op = next(), w = term(); v = op === '+' ? v + w : v - w; } return v; }
        try { const v = expr(); return i === t.length && isFinite(v) ? v : null; } catch (e) { return null; }
    }
    const formulaOk = f => evalFormula(f, Object.fromEntries(VARS.map(v => [v, 1]))) !== null;

    /* ── saved layouts ── */
    const S = { prefs: {}, loaded: false, last: {} };
    const lsKey = k => 'pq-columns-' + k;
    function getLayout(key) {
        if (S.prefs[key] !== undefined) return S.prefs[key];
        try { const v = JSON.parse(localStorage.getItem(lsKey(key)) || 'null'); if (v) return v; } catch (e) {}
        return null;
    }
    async function loadPrefs(keys) {
        try {
            const res = await fetch(`${API}?keys=${encodeURIComponent(keys.join(','))}`, { credentials: 'same-origin', cache: 'no-store' });
            const d = await res.json();
            if (d && d.success) {
                for (const k of keys) {
                    S.prefs[k] = d.prefs[k] || null;
                    try { d.prefs[k] ? localStorage.setItem(lsKey(k), JSON.stringify(d.prefs[k])) : localStorage.removeItem(lsKey(k)); } catch (e) {}
                }
            }
        } catch (e) { /* keep the browser copy */ }
        S.loaded = true;
        for (const k of keys) if (S.last[k]) apply(S.last[k]);   // re-draw with the saved layout
    }
    async function saveLayout(key, layout) {
        S.prefs[key] = layout;
        try { layout ? localStorage.setItem(lsKey(key), JSON.stringify(layout)) : localStorage.removeItem(lsKey(key)); } catch (e) {}
        const res = await fetch(API, { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ key, value: layout }) });
        const d = await res.json().catch(() => null);
        if (!d || !d.success) throw new Error((d && d.error) || 'Could not save the columns (they are kept in this browser).');
    }

    /* ── table ── */
    const slug = s => String(s || '').toLowerCase().replace(/[^a-z0-9]+/g, '_').replace(/^_|_$/g, '');
    function baseColumns(table, lock) {
        const head = table.tHead && table.tHead.rows[0];
        if (!head) return [];
        const ths = [...head.cells].filter(c => !c.dataset.pqGen);
        ths.sort((a, b) => (+(a.dataset.pqBase ?? 1e9)) - (+(b.dataset.pqBase ?? 1e9)));
        return ths.map((th, i) => {
            const idx = th.dataset.pqBase != null ? +th.dataset.pqBase : i;
            const label = (th.dataset.pqLabel || th.textContent || '').replace(/\s+/g, ' ').trim();
            const id = idx === 1 ? 'name' : (th.dataset.col && th.dataset.col !== 'campaign' ? th.dataset.col : slug(label));
            return { id, idx, label, locked: idx < lock, hidden: idx >= lock && lHid(label) };
        });
    }
    function availableExtras(rows, key) {
        const n = rows.map(norm);
        const present = new Set(n.flatMap(r => Object.keys(r)).filter(k => k.startsWith('pm_')));
        VARS = BASE_VARS.concat([...present]).filter(v => !varHidden(v));
        const fromPlatform = [...present].filter(k => PM()[k]).map(k => ({
            id: 'p:' + k, label: PM()[k].label, group: key === 'google' ? 'From Google' : 'From Meta',
            fmt: isRate(k) ? 'pct' : ((PM()[k].money || /value/.test(k)) ? 'money' : (/conv/.test(k) ? 'dec' : 'int')), pm: k,
            def: !!PM()[k].default
        }));
        return fromPlatform.filter(e => !lHid(e.label)).concat(Object.entries(EXTRA).filter(([k, m]) => !extraHidden('x:' + k) && (!m.needs || n.some(r => r[m.needs] != null))).map(([k, m]) => Object.assign({ id: 'x:' + k }, m)));
    }
    /** The columns to draw, in order: [{id, kind: base|extra|custom, ...}] */
    function plan(base, extras, layout) {
        const lockedCols = base.filter(c => c.locked);
        const free = base.filter(c => !c.locked);
        // extras marked default (e.g. Daily budget) show until the user removes them in ▥ Columns
        const defaults = extras.filter(c => c.def && !(layout && ((layout.order || []).includes(c.id) || (layout.removed || []).includes(c.id))))
            .map(c => Object.assign({ kind: 'extra' }, c));
        if (!layout) return lockedCols.concat(free.filter(c => !c.hidden)).map(c => Object.assign({ kind: 'base' }, c)).concat(defaults);
        const byId = {};
        free.forEach(c => { if (!c.hidden) byId[c.id] = Object.assign({ kind: 'base' }, c); });
        extras.forEach(c => { byId[c.id] = Object.assign({ kind: 'extra' }, c); });
        (layout.custom || []).filter(c => formulaOk(c.formula)).forEach(c => { byId['c:' + c.key] = { id: 'c:' + c.key, kind: 'custom', label: c.label, fmt: c.fmt, formula: c.formula }; });
        const out = [];
        const seen = new Set();
        for (const id of layout.order || []) { if (byId[id] && !seen.has(id)) { out.push(byId[id]); seen.add(id); } }
        free.forEach(c => { if (!c.hidden && !seen.has(c.id) && !(layout.removed || []).includes(c.id)) out.push(byId[c.id]); });   // a new column on the dashboard shows up
        return lockedCols.map(c => Object.assign({ kind: 'base' }, c)).concat(out, defaults);
    }
    function valueOf(col, r) {
        if (col.kind === 'extra' && col.id.startsWith('p:')) return r[col.id.slice(2)] ?? null;
        if (col.kind === 'extra') return EXTRA[col.id.slice(2)].f(r);
        if (col.kind === 'custom') return evalFormula(col.formula, r);
        return null;
    }
    function totals(allRows) {
        const t = { spend: 0, impressions: 0, clicks: 0, reach: null, leads: 0, qualified: 0, sitevisits: 0, non_qualified: null, to_be_qualified: null, lost_post_qualified: null, conversions: null };
        let pm = {}, w = 0;
        for (const raw of allRows) {
            const r = norm(raw);
            for (const k of Object.keys(t)) {
                if (r[k] == null) continue;
                t[k] = (t[k] || 0) + r[k];
            }
            pm = addPm(pm, raw && raw.pm, w, r.impressions); w += r.impressions;
        }
        return Object.assign(pm, t, hiddenVals());
    }
    function cellLike(sample, tag, html, extraStyle) {
        const c = document.createElement(tag);
        if (sample) { c.className = sample.className.replace(/\bpq-mg-hide\b/g, ''); c.setAttribute('style', (sample.getAttribute('style') || '').replace(/cursor:\s*pointer;?|text-decoration:[^;]*;?|color:[^;]*;?/g, '')); }
        if (extraStyle) c.style.cssText += extraStyle;
        c.innerHTML = html;
        c.dataset.pqGen = '1';
        return c;
    }

    function apply(o) {
        const table = typeof o.table === 'string' ? document.getElementById(o.table) : o.table;
        if (!table || !table.tHead) return;
        S.last[o.key] = o;
        if (!S.loaded && !S.loading) { S.loading = true; loadPrefs(o.keys || [o.key]); }
        const lock = o.lock ?? 2;
        const base = baseColumns(table, lock);
        if (!base.length) return;
        const rows = o.rows || [], allRows = o.allRows || rows;
        const extras = availableExtras(allRows, o.key);
        const layout = getLayout(o.key);
        const cols = plan(base, extras, layout);
        const tot = totals(allRows);

        // rows: header, data rows (one per data object), total rows (anything else with the full cell count)
        const head = table.tHead.rows[0];
        const bodyRows = [...table.tBodies].flatMap(b => [...b.rows]);
        const footRows = table.tFoot ? [...table.tFoot.rows] : [];
        let di = 0;
        const baseThs = [...head.cells].filter(c => !c.dataset.pqGen);
        const sampleTh = baseThs.find(c => c.dataset.pqBase === String(base.length - 1)) || baseThs[baseThs.length - 1];

        const rebuild = (tr, kind, data) => {
            const own = [...tr.cells].filter(c => !c.dataset.pqGen);
            if (own.length !== base.length && !own.some(c => c.dataset.pqBase != null)) return false;   // a "Loading…" / "No data" row
            const byIdx = {};
            own.forEach((c, i) => { const idx = c.dataset.pqBase != null ? +c.dataset.pqBase : i; c.dataset.pqBase = idx; byIdx[idx] = c; });
            if (kind === 'head') own.forEach(c => { if (!c.dataset.pqLabel) c.dataset.pqLabel = (c.textContent || '').replace(/\s+/g, ' ').trim(); });
            [...tr.cells].filter(c => c.dataset.pqGen).forEach(c => c.remove());
            const sample = own.find(c => +c.dataset.pqBase >= lock && /mono/.test(c.className)) || own[own.length - 1];
            const shown = new Set(cols.filter(c => c.kind === 'base').map(c => c.idx));
            own.forEach(c => { c.style.display = shown.has(+c.dataset.pqBase) ? '' : 'none'; });
            const frag = [];
            for (const col of cols) {
                if (col.kind === 'base') { if (byIdx[col.idx]) frag.push(byIdx[col.idx]); continue; }
                if (kind === 'head') { frag.push(cellLike(sampleTh, 'th', col.label + (col.kind === 'custom' ? ' <span style="opacity:.55;font-size:10px;">ƒ</span>' : ''), 'cursor:default;')); continue; }
                const fmt = FMT[col.fmt] || FMT.dec;
                const v = valueOf(col, kind === 'total' ? tot : norm(data));
                frag.push(cellLike(sample, 'td', fmt(v), kind === 'total' ? 'font-weight:700;color:' + ACCENT + ';' : ''));
            }
            own.filter(c => !shown.has(+c.dataset.pqBase)).forEach(c => frag.push(c));   // hidden cells stay (for sorting / exports)
            frag.forEach(c => tr.appendChild(c));
            return true;
        };
        rebuild(head, 'head');
        for (const tr of bodyRows) {
            if (tr.dataset.pqTotal || di >= rows.length) { rebuild(tr, 'total'); continue; }
            if (rebuild(tr, 'data', rows[di])) di++;
        }
        footRows.forEach(tr => rebuild(tr, 'total'));

        // the button
        const host = typeof o.host === 'string' ? document.getElementById(o.host) : o.host;
        if (host && !host.querySelector('[data-pq-cols-btn]')) {
            const b = document.createElement('button');
            b.type = 'button';
            b.dataset.pqColsBtn = '1';
            b.innerHTML = '▥ Columns';
            b.title = 'Add, remove and reorder columns';
            b.style.cssText = 'background:var(--pq-card);color:var(--pq-text);border:1px solid var(--pq-border);padding:6px 12px;border-radius:6px;cursor:pointer;font-size:11.5px;font-weight:600;font-family:Sora,sans-serif;';
            b.onclick = () => openDialog(o.key);
            host.appendChild(b);
        }
    }

    /* ── the "Modify columns" panel ── */
    function esc(s) { return String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }
    function openDialog(key) {
        const o = S.last[key];
        if (!o) return;
        const table = typeof o.table === 'string' ? document.getElementById(o.table) : o.table;
        const lock = o.lock ?? 2;
        const base = baseColumns(table, lock);
        const extras = availableExtras(o.allRows || o.rows || [], key);
        const saved = getLayout(key);
        const start = plan(base, extras, saved);
        const savedCustom = (saved && saved.custom) || [];
        const L = { custom: JSON.parse(JSON.stringify(savedCustom.filter(c => formulaOk(c.formula)))), sel: start.filter(c => !(c.kind === 'base' && c.locked)).map(c => c.id) };
        const label = id => { const b = base.find(c => c.id === id); if (b) return b.label; if (id.startsWith('p:')) return varLabel(id.slice(2)); if (id.startsWith('x:')) return EXTRA[id.slice(2)].label; const c = L.custom.find(c => 'c:' + c.key === id); return c ? c.label : id; };
        const groups = [
            ['On this table', base.filter(c => !c.locked && !c.hidden).map(c => ({ id: c.id, label: c.label }))],
            ...[key === 'google' ? 'From Google' : 'From Meta', 'Performance', 'Calculated from platform metrics', 'Leads & conversions', 'Lead status'].map(g => [g, extras.filter(e => e.group === g).map(e => ({ id: e.id, label: e.label }))])
        ].filter(([, list]) => list.length);

        const ov = document.createElement('div');
        ov.style.cssText = 'position:fixed;inset:0;z-index:100000;background:rgba(2,6,23,.62);display:flex;align-items:center;justify-content:center;padding:16px;font-family:Sora,sans-serif;';
        ov.innerHTML = `
        <div role="dialog" aria-modal="true" style="background:var(--pq-card);color:var(--pq-text);border:1px solid var(--pq-border);border-radius:14px;width:min(1040px,100%);max-height:92vh;display:flex;flex-direction:column;box-shadow:0 24px 70px rgba(0,0,0,.5);overflow:hidden;">
          <div style="display:grid;grid-template-columns:minmax(0,1fr) 300px;min-height:0;flex:1;">
            <div style="display:flex;flex-direction:column;min-height:0;border-right:1px solid var(--pq-border);">
              <div style="display:flex;align-items:center;gap:10px;padding:16px 20px;border-bottom:1px solid var(--pq-border);">
                <b style="font-size:16px;flex:1;">Modify columns · ${key === 'meta' ? 'Meta' : 'Google'}</b>
                <input id="pqc-q" type="search" placeholder="Search columns" style="background:var(--pq-surface,var(--pq-bg));color:var(--pq-text);border:1px solid var(--pq-border);border-radius:8px;padding:7px 10px;font-size:12px;width:190px;outline:none;">
                <button id="pqc-new" type="button" style="background:none;border:0;color:#3B82F6;font-weight:600;font-size:13px;cursor:pointer;">＋ Custom column</button>
              </div>
              <div id="pqc-left" style="overflow:auto;padding:12px 20px 18px;"></div>
            </div>
            <div style="display:flex;flex-direction:column;min-height:0;">
              <div style="padding:16px 18px 10px;border-bottom:1px solid var(--pq-border);"><b style="font-size:14px;">Your columns</b><div style="font-size:11.5px;color:var(--pq-text-dim);margin-top:2px;">Drag and drop to reorder</div></div>
              <div id="pqc-right" style="overflow:auto;padding:8px 10px 14px;"></div>
            </div>
          </div>
          <div style="display:flex;align-items:center;gap:10px;padding:14px 20px;border-top:1px solid var(--pq-border);">
            <button id="pqc-apply" type="button" style="background:#3B82F6;color:#fff;border:0;border-radius:8px;padding:9px 20px;font-weight:600;cursor:pointer;">Apply</button>
            <button id="pqc-cancel" type="button" style="background:none;border:0;color:#3B82F6;font-weight:600;cursor:pointer;">Cancel</button>
            <span style="flex:1"></span>
            <button id="pqc-reset" type="button" style="background:none;border:1px solid var(--pq-border);color:var(--pq-text-dim);border-radius:8px;padding:7px 12px;font-size:12px;cursor:pointer;">Reset to default</button>
          </div>
        </div>`;
        document.body.appendChild(ov);
        const $ = s => ov.querySelector(s);
        const close = () => ov.remove();
        $('#pqc-cancel').onclick = close;
        ov.addEventListener('click', e => { if (e.target === ov) close(); });
        document.addEventListener('keydown', function esc_(e) { if (e.key === 'Escape') { close(); document.removeEventListener('keydown', esc_); } });

        const chk = (id, text) => `<label style="display:flex;gap:9px;align-items:flex-start;padding:7px 4px;font-size:13px;cursor:pointer;" data-q="${esc(text.toLowerCase())}">
            <input type="checkbox" data-id="${esc(id)}" ${L.sel.includes(id) ? 'checked' : ''} style="width:16px;height:16px;accent-color:#3B82F6;margin-top:1px;flex:none;"><span style="flex:1;">${esc(text)}</span>${id.startsWith('c:')
                ? `<button type="button" data-del="${esc(id)}" title="Delete this custom column" style="background:none;border:0;color:#EF4444;cursor:pointer;font-size:12px;padding:0 2px;">Delete</button>` : ''}</label>`;
        function drawLeft() {
            const q = $('#pqc-q').value.trim().toLowerCase();
            const sec = (title, items) => {
                const list = items.filter(x => !q || x.label.toLowerCase().includes(q));
                if (!list.length) return '';
                return `<div style="font-size:11px;text-transform:uppercase;letter-spacing:.06em;color:var(--pq-text-dim);margin:14px 0 4px;">${esc(title)}</div>
                    <div style="display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:0 14px;">${list.map(x => chk(x.id, x.label)).join('')}</div>`;
            };
            const custom = L.custom.map(c => ({ id: 'c:' + c.key, label: c.label }));
            $('#pqc-left').innerHTML = groups.map(([t, l]) => sec(t, l)).join('')
                + (custom.length ? sec('Custom columns', custom) : '')
                + `<div id="pqc-form"></div>`;
            ov.querySelectorAll('#pqc-left [data-del]').forEach(b => b.onclick = e => {
                e.preventDefault();
                const id = b.dataset.del;
                L.custom = L.custom.filter(c => 'c:' + c.key !== id);
                L.sel = L.sel.filter(x => x !== id);
                drawLeft(); drawRight();
            });
            ov.querySelectorAll('#pqc-left input[type=checkbox][data-id]').forEach(cb => cb.onchange = () => {
                const id = cb.dataset.id;
                L.sel = L.sel.filter(x => x !== id);
                if (cb.checked) L.sel.push(id);
                drawRight();
            });
        }
        function drawRight() {
            const locked = base.filter(c => c.locked).map(c => `<div style="display:flex;align-items:center;gap:10px;padding:9px 8px;font-size:13px;color:var(--pq-text-dim);">🔒 ${esc(c.label)}</div>`).join('');
            $('#pqc-right').innerHTML = locked + `<div style="border-top:1px solid var(--pq-border);margin:6px 0;"></div>`
                + L.sel.map((id, i) => `<div draggable="true" data-i="${i}" style="display:flex;align-items:center;gap:10px;padding:8px;border-radius:7px;font-size:13px;cursor:grab;user-select:none;">
                    <span style="color:var(--pq-text-dim);font-size:15px;">☰</span><span style="flex:1;">${esc(label(id))}${id.startsWith('c:') ? ' <span style="opacity:.55;font-size:11px;">ƒ</span>' : ''}</span>
                    <button type="button" data-rm="${esc(id)}" title="Remove" style="background:none;border:1px solid var(--pq-border);border-radius:50%;width:22px;height:22px;line-height:18px;color:var(--pq-text-dim);cursor:pointer;">✕</button></div>`).join('')
                + (L.sel.length ? '' : `<div style="padding:12px 8px;color:var(--pq-text-dim);font-size:12px;">Tick columns on the left.</div>`);
            ov.querySelectorAll('[data-rm]').forEach(b => b.onclick = () => { L.sel = L.sel.filter(x => x !== b.dataset.rm); drawLeft(); drawRight(); });
            let drag = null;
            ov.querySelectorAll('#pqc-right [draggable]').forEach(el => {
                el.addEventListener('dragstart', e => { drag = +el.dataset.i; el.style.opacity = '.4'; e.dataTransfer.effectAllowed = 'move'; try { e.dataTransfer.setData('text/plain', el.dataset.i); } catch (x) {} });
                el.addEventListener('dragend', () => { el.style.opacity = ''; });
                el.addEventListener('dragover', e => { e.preventDefault(); el.style.background = 'var(--pq-border)'; });
                el.addEventListener('dragleave', () => { el.style.background = ''; });
                el.addEventListener('drop', e => {
                    e.preventDefault(); el.style.background = '';
                    const to = +el.dataset.i;
                    if (drag == null || drag === to) return;
                    const [m] = L.sel.splice(drag, 1); L.sel.splice(to, 0, m); drag = null; drawRight();
                });
            });
        }
        function customForm() {
            const box = $('#pqc-form');
            box.innerHTML = `<div style="margin-top:16px;padding:14px;border:1px solid var(--pq-border);border-radius:10px;background:var(--pq-surface,transparent);">
                <b style="font-size:13px;">New custom column</b>
                <div style="display:grid;grid-template-columns:1fr 150px;gap:10px;margin-top:10px;">
                  <label style="font-size:12px;color:var(--pq-text-dim);display:flex;flex-direction:column;gap:4px;">Name<input id="pqc-name" maxlength="40" placeholder="e.g. Cost per 100 clicks" style="background:var(--pq-card);color:var(--pq-text);border:1px solid var(--pq-border);border-radius:7px;padding:7px 9px;"></label>
                  <label style="font-size:12px;color:var(--pq-text-dim);display:flex;flex-direction:column;gap:4px;">Format<select id="pqc-fmt" style="background:var(--pq-card);color:var(--pq-text);border:1px solid var(--pq-border);border-radius:7px;padding:7px 9px;">${Object.entries(FMT_LABEL).map(([k, v]) => `<option value="${k}" ${k === 'money' ? 'selected' : ''}>${v}</option>`).join('')}</select></label>
                  <label style="grid-column:1/-1;font-size:12px;color:var(--pq-text-dim);display:flex;flex-direction:column;gap:4px;">Formula<input id="pqc-formula" placeholder="spend / clicks * 100" style="background:var(--pq-card);color:var(--pq-text);border:1px solid var(--pq-border);border-radius:7px;padding:7px 9px;font-family:'JetBrains Mono',monospace;"></label>
                </div>
                <div style="margin-top:8px;display:flex;flex-wrap:wrap;gap:6px;">${VARS.map(v => `<button type="button" data-ins="${v}" title="${esc(varLabel(v))}" style="background:var(--pq-card);border:1px solid var(--pq-border);color:var(--pq-text-dim);border-radius:99px;padding:3px 10px;font-size:11px;cursor:pointer;font-family:'JetBrains Mono',monospace;">${v}</button>`).join('')}</div>
                <div style="font-size:11.5px;color:var(--pq-text-dim);margin-top:8px;">Use the names above, numbers and + − × ÷ ( ). Totals use the summed numbers (e.g. total spend ÷ total clicks).</div>
                <div style="display:flex;gap:8px;margin-top:12px;"><button type="button" id="pqc-add" style="background:${ACCENT};color:#111;border:0;border-radius:7px;padding:7px 14px;font-weight:600;cursor:pointer;">Add column</button><button type="button" id="pqc-x" style="background:none;border:0;color:var(--pq-text-dim);cursor:pointer;">Cancel</button></div>
                <div id="pqc-err" style="color:#EF4444;font-size:12px;margin-top:8px;"></div></div>`;
            box.querySelectorAll('[data-ins]').forEach(b => b.onclick = () => { const f = $('#pqc-formula'); f.value = (f.value ? f.value.replace(/\s*$/, ' ') : '') + b.dataset.ins; f.focus(); });
            $('#pqc-x').onclick = () => { box.innerHTML = ''; };
            $('#pqc-add').onclick = () => {
                const name = $('#pqc-name').value.trim(), formula = $('#pqc-formula').value.trim();
                if (!name) { $('#pqc-err').textContent = 'Give the column a name.'; return; }
                if (!formulaOk(formula)) { $('#pqc-err').textContent = 'The formula can only use the names above, numbers and + − × ÷ ( ).'; return; }
                let k = slug(name).slice(0, 30) || 'col';
                while (L.custom.some(c => c.key === k)) k += '_2';
                L.custom.push({ key: k, label: name, formula, fmt: $('#pqc-fmt').value });
                L.sel.push('c:' + k);
                drawLeft(); drawRight();
            };
            $('#pqc-name').focus();
        }
        $('#pqc-q').addEventListener('input', drawLeft);
        $('#pqc-new').onclick = () => { if (!$('#pqc-form')) drawLeft(); customForm(); $('#pqc-form').scrollIntoView({ block: 'nearest' }); };
        $('#pqc-reset').onclick = async () => {
            try { await saveLayout(key, null); } catch (e) { /* browser copy cleared */ }
            close(); apply(S.last[key]); if (o.onChange) o.onChange();
        };
        $('#pqc-apply').onclick = async () => {
            // unticked custom columns stay in the list (to tick again); "Delete" removes them for good
            // columns this role can't see keep their saved state (they come back if the role is given them again)
            const hiddenIds = base.filter(c => !c.locked && c.hidden).map(c => c.id);
            const free = base.filter(c => !c.locked && !c.hidden).map(c => c.id);
            const keepCustomIds = savedCustom.filter(c => !formulaOk(c.formula)).map(c => 'c:' + c.key);   // declared first: used just below
            const keepOrder = ((saved && saved.order) || []).filter(id => hiddenIds.includes(id) || extraHidden(id) || keepCustomIds.includes(id));
            const keepRemoved = ((saved && saved.removed) || []).filter(id => hiddenIds.includes(id));
            const keepCustom = savedCustom.filter(c => !formulaOk(c.formula));
            const layout = { order: L.sel.slice().concat(keepOrder), removed: free.filter(id => !L.sel.includes(id)).concat(extras.filter(e => e.def && !L.sel.includes(e.id)).map(e => e.id), keepRemoved), custom: L.custom.concat(keepCustom) };
            const btn = $('#pqc-apply'); btn.disabled = true; btn.textContent = 'Saving…';
            let warn = '';
            try { await saveLayout(key, layout); } catch (e) { warn = e.message; }
            close();
            apply(S.last[key]);
            if (o.onChange) o.onChange();
            if (warn) console.warn('[columns]', warn);
        };
        drawLeft(); drawRight();
    }

    window.PQColumns = { apply, open: openDialog, evalFormula, addPm };
})();
