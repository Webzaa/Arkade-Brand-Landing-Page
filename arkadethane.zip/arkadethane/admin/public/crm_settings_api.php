<?php
/**
 * crm_settings_api.php — backend of crm_settings.php (Admin → CRM Settings). Super Admin only (app/Core/access.php).
 *
 *   GET  ?action=load                 → settings (secrets never returned, only "saved" flags), lead columns, placeholders
 *   POST ?action=save     {settings}  → validate + save (blank secret = keep the saved one)
 *   POST ?action=test     {settings}  → sign in to Salesforce with these settings (nothing is saved, no lead is sent)
 *   POST ?action=preview  {settings, platform, lead_id?}  → the JSON a lead would be sent with
 *   POST ?action=import_config        → copy the CRM_SFDC block of config.php into these settings
 *   GET  ?action=capi_load / POST ?action=capi_save {capi} / POST ?action=capi_check {capi}
 *                                     → Meta Conversions API sent with Upload Lead Status (app/Leads/meta_capi_send.php)
 * Logic: app/Leads/crm_sfdc.php
 */
session_start();
header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');
require_once dirname(__DIR__) . '/app/Leads/crm_send.php';
require_once dirname(__DIR__) . '/app/Leads/meta_capi_send.php';

function csReply(array $p, int $code = 200): never
{
    http_response_code($code);
    echo json_encode($p, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}
if (($_SESSION['user_logged'] ?? '') !== 'Y') {
    csReply(['success' => false, 'error' => 'Please sign in again.'], 401);
}
if (!function_exists('pqIsSuperadmin') || !pqIsSuperadmin()) {
    csReply(['success' => false, 'error' => 'Only a Super Admin can change the CRM settings.'], 403);
}
$user = (string) ($_SESSION['username'] ?? $_SESSION['user'] ?? 'admin');
session_write_close();

$appDb = leadDb(appDbKey());
if (!$appDb) {
    csReply(['success' => false, 'error' => 'The main database is not reachable.'], 500);
}
const CS_SECRETS = [['auth', 'client_secret'], ['auth', 'password'], ['fallback', 'client_secret'], ['fallback', 'password']];

function csLeadColumns(mysqli $db): array
{
    $cols = [];
    $r = @$db->query('SHOW COLUMNS FROM `lead`');
    if ($r) {
        while ($c = $r->fetch_assoc()) {
            $cols[] = (string) ($c['Field'] ?? '');
        }
    }
    if (!$cols) {
        $r = $db->query('SELECT * FROM `lead` LIMIT 1');
        $row = $r ? $r->fetch_assoc() : null;
        $cols = $row ? array_keys($row) : [];
    }
    return array_values(array_filter($cols, fn($c) => $c !== '' && !in_array($c, ['curlresponse', 'meta_curlresponse'], true)));
}

/** Settings for the browser: secrets blanked, with "saved" flags. */
function csMask(?array $s): array
{
    $s ??= crmSfdcNormalize(['enabled' => false, 'auth' => ['mode' => 'client_credentials', 'token_url' => 'https://login.salesforce.com/services/oauth2/token'],
        'platforms' => ['meta' => true, 'google' => true], 'fields' => crmSfdcDefaultFields()]);
    $saved = [];
    foreach (CS_SECRETS as [$b, $k]) {
        $saved["$b.$k"] = (string) $s[$b][$k] !== '';
        $s[$b][$k] = '';
    }
    return ['settings' => $s, 'saved_secrets' => $saved];
}

/** Settings posted by the page + the saved secrets where a secret box was left empty. */
function csIncoming(array $in, ?array $current): array
{
    $s = crmSfdcNormalize((array) ($in['settings'] ?? []));
    $clear = (array) ($in['clear_secrets'] ?? []);
    foreach (CS_SECRETS as [$b, $k]) {
        if (in_array("$b.$k", $clear, true)) {
            $s[$b][$k] = '';
        } elseif ((string) $s[$b][$k] === '' && $current !== null) {
            $s[$b][$k] = (string) ($current[$b][$k] ?? '');
        }
    }
    return $s;
}

/** @return list<string> problems in plain words */
function csValidate(array $s, array $columns): array
{
    $err = [];
    $url = fn($u) => (bool) preg_match('#^https://[^\s/$.?\#].[^\s]*$#i', $u) || (bool) preg_match('#^http://(127\.0\.0\.1|localhost)(:\d+)?/#i', $u);
    foreach (['auth' => 'Sign-in', 'fallback' => 'Backup sign-in'] as $b => $label) {
        $a = $s[$b];
        if ($a['mode'] === '') {
            if ($b === 'auth' && $s['enabled']) {
                $err[] = 'Choose how to sign in to Salesforce.';
            }
            continue;
        }
        if (!in_array($a['mode'], ['client_credentials', 'password'], true)) {
            $err[] = "$label: unknown sign-in method.";
            continue;
        }
        if (!$url($a['token_url'])) {
            $err[] = "$label: the token URL must start with https://";
        }
        if (trim($a['client_id']) === '' || $a['client_secret'] === '') {
            $err[] = "$label: client ID and client secret are needed.";
        }
        if ($a['mode'] === 'password' && (trim($a['username']) === '' || $a['password'] === '')) {
            $err[] = "$label: username and password are needed for the username + password method.";
        }
    }
    if ($s['enabled'] || $s['lead_url'] !== '') {
        if (!$url($s['lead_url']) && !preg_match('#^/[A-Za-z0-9_\-./]+$#', $s['lead_url'])) {
            $err[] = 'Lead endpoint: use the full https:// URL, or a path starting with / (for example /services/apexrest/Marketing/Leads/).';
        }
    }
    if ($s['enabled'] && !in_array(true, $s['platforms'], true)) {
        $err[] = 'Turn on at least one kind of lead (Meta, Google or other sources).';
    }
    if (count($s['fields']) > 80) {
        $err[] = 'At most 80 fields.';
    }
    $seen = [];
    foreach ($s['fields'] as $i => $f) {
        $n = $f['name'];
        if (!preg_match('/^[A-Za-z0-9_.\-]{1,80}$/', $n)) {
            $err[] = "Field “{$n}”: use letters, numbers, _ . - only.";
        }
        if (isset($seen[strtolower($n)])) {
            $err[] = "Field “{$n}” is listed twice.";
        }
        $seen[strtolower($n)] = true;
        foreach (['meta', 'google', 'other'] as $p) {
            if (mb_strlen($f[$p]) > 500) {
                $err[] = "Field “{$n}” ({$p}): value is too long.";
            }
            $bad = crmSfdcUnknownNames($f[$p], $columns);
            if ($bad) {
                $err[] = "Field “{$n}” (" . CRM_SFDC_PLATFORMS[$p] . '): unknown name ' . implode(', ', array_map(fn($x) => '{' . $x . '}', $bad))
                    . ' — use a lead column, a special name, or put fixed text in quotes.';
            }
        }
    }
    if ($s['enabled'] && !$s['fields']) {
        $err[] = 'Add the fields Salesforce expects.';
    }
    return $err;
}

function csEncrypt(array $s): array
{
    foreach (CS_SECRETS as [$b, $k]) {
        $s[$b][$k] = pqEncrypt((string) $s[$b][$k]);
    }
    return $s;
}

try {
    $action = (string) ($_GET['action'] ?? '');
    $loaded = crmSfdcLoad($appDb);
    $current = $loaded['settings'];
    $columns = csLeadColumns($appDb);
    $isPost = ($_SERVER['REQUEST_METHOD'] ?? '') === 'POST';
    $in = $isPost ? (array) json_decode((string) file_get_contents('php://input'), true) : [];

    // ── Meta Conversions API ──
    $capiPublic = function (array $s): array {
        return ['enabled' => $s['enabled'], 'dataset_id' => $s['dataset_id'], 'use_config_token' => $s['use_config_token'],
                'token_saved' => $s['access_token'] !== '', 'token_error' => $s['token_error'],
                'config_token' => defined('META_ACCESS_TOKEN') && (string) META_ACCESS_TOKEN !== '',
                'config_pixel' => defined('META_PIXEL_ID') ? (string) META_PIXEL_ID : '',
                'send' => $s['send'], 'events' => $s['events'], 'lead_event_source' => $s['lead_event_source'],
                'test_event_code' => $s['test_event_code'], 'saved' => $s['saved'], 'updated_at' => $s['updated_at'], 'updated_by' => $s['updated_by'],
                'problem' => capiProblem($s)];
    };
    $capiIncoming = function (array $in, array $cur): array {
        $c = (array) ($in['capi'] ?? []);
        $s = $cur;
        $s['enabled'] = !empty($c['enabled']);
        $s['dataset_id'] = preg_replace('/\D+/', '', (string) ($c['dataset_id'] ?? ''));
        $s['use_config_token'] = !empty($c['use_config_token']);
        if (!empty($c['clear_token'])) {
            $s['access_token'] = '';
        } elseif (trim((string) ($c['access_token'] ?? '')) !== '') {
            $s['access_token'] = trim((string) $c['access_token']);
        }
        $s['send'] = ['qualified' => !empty($c['send']['qualified']), 'sitevisit' => !empty($c['send']['sitevisit'])];
        foreach (['qualified', 'sitevisit'] as $k) {
            $v = trim((string) ($c['events'][$k] ?? ''));
            $s['events'][$k] = $v !== '' ? mb_substr($v, 0, 50) : capiDefaults()['events'][$k];
        }
        $s['lead_event_source'] = mb_substr(trim((string) ($c['lead_event_source'] ?? '')) ?: 'PerformIQ', 0, 60);
        $s['test_event_code'] = mb_substr(preg_replace('/[^A-Za-z0-9_]/', '', (string) ($c['test_event_code'] ?? '')), 0, 40);
        return $s;
    };
    if ($action === 'capi_load') {
        csReply(['success' => true, 'capi' => $capiPublic(capiSettings($appDb))]);
    }
    if ($action === 'capi_save' || $action === 'capi_check') {
        if (!$isPost) {
            csReply(['success' => false, 'error' => 'Use POST.'], 405);
        }
        $s = $capiIncoming($in, capiSettings($appDb));
        if ($action === 'capi_check') {
            csReply(['success' => true, 'check' => capiCheck($s)]);
        }
        if ($s['enabled'] && capiProblem($s) !== '') {
            csReply(['success' => false, 'error' => 'Not saved — ' . capiProblem($s) . '.'], 422);
        }
        $store = array_intersect_key($s, capiDefaults());
        $store['access_token'] = pqEncrypt((string) $s['access_token']);
        pqSettingPut($appDb, 'meta_capi', $store, $user);
        csReply(['success' => true, 'capi' => $capiPublic(capiSettings($appDb))]);
    }

    if ($action === 'load') {
        csReply(['success' => true, 'source' => $loaded['source'], 'updated_at' => $loaded['updated_at'] ?? '', 'updated_by' => $loaded['updated_by'] ?? '',
                 'secret_errors' => $loaded['secret_errors'], 'config_available' => crmSfdcFromConfig() !== null,
                 'columns' => $columns, 'specials' => CRM_SFDC_SPECIALS, 'platform_labels' => CRM_SFDC_PLATFORMS,
                 'standard_fields' => crmSfdcDefaultFields(), 'max_batch' => CRM_SEND_MAX_BATCH] + csMask($current));
    }
    if (!$isPost) {
        csReply(['success' => false, 'error' => 'Use POST.'], 405);
    }
    if ($action === 'save') {
        $s = csIncoming($in, $current);
        $errs = csValidate($s, $columns);
        if ($errs) {
            csReply(['success' => false, 'error' => 'Not saved — please fix: ' . $errs[0], 'errors' => $errs], 422);
        }
        pqSettingPut($appDb, 'crm_sfdc', csEncrypt($s), $user);
        crmSfdcClearTokenCache();
        $loaded = crmSfdcLoad($appDb);
        csReply(['success' => true, 'source' => 'db', 'updated_at' => $loaded['updated_at'] ?? '', 'updated_by' => $loaded['updated_by'] ?? ''] + csMask($loaded['settings']));
    }
    if ($action === 'import_config') {
        $c = crmSfdcFromConfig();
        if ($c === null) {
            csReply(['success' => false, 'error' => 'There is no CRM_SFDC block in config.php.'], 404);
        }
        pqSettingPut($appDb, 'crm_sfdc', csEncrypt(crmSfdcNormalize($c)), $user);
        crmSfdcClearTokenCache();
        $loaded = crmSfdcLoad($appDb);
        csReply(['success' => true, 'source' => 'db', 'updated_at' => $loaded['updated_at'] ?? '', 'updated_by' => $loaded['updated_by'] ?? ''] + csMask($loaded['settings']));
    }
    if ($action === 'test') {
        $s = csIncoming($in, $current);
        $out = [];
        foreach (['auth' => 'Sign-in', 'fallback' => 'Backup sign-in'] as $b => $label) {
            if ($s[$b]['mode'] === '') {
                continue;
            }
            $t0 = microtime(true);
            $r = crmSfdcAuth($s[$b]);
            $row = ['which' => $label, 'ok' => $r['token'] !== '', 'ms' => (int) round((microtime(true) - $t0) * 1000), 'error' => $r['error'], 'instance_url' => $r['instance_url']];
            if ($r['token'] !== '' && $s['lead_url'] !== '') {
                try {
                    $row['lead_url'] = crmSfdcLeadUrl($s, $r['instance_url']);
                } catch (Throwable $e) {
                    $row['lead_url_error'] = $e->getMessage();
                }
            }
            $out[] = $row;
        }
        if (!$out) {
            csReply(['success' => false, 'error' => 'Fill in the sign-in first.'], 422);
        }
        csReply(['success' => true, 'results' => $out]);
    }
    if ($action === 'preview') {
        $s = csIncoming($in, $current);
        $pk = (string) ($in['platform'] ?? 'meta');
        if (!isset(CRM_SFDC_PLATFORMS[$pk])) {
            csReply(['success' => false, 'error' => 'Unknown platform.'], 400);
        }
        $dbKey = (string) ($in['db'] ?? appDbKey());
        $db = in_array($dbKey, leadDbKeys(), true) ? leadDb($dbKey) : null;
        if (!$db) {
            csReply(['success' => false, 'error' => 'Database not reachable.'], 500);
        }
        $lead = null;
        $id = (int) ($in['lead_id'] ?? 0);
        if ($id > 0) {
            $st = $db->prepare('SELECT * FROM `lead` WHERE id = ?');
            $st->bind_param('i', $id);
            $st->execute();
            $lead = $st->get_result()->fetch_assoc() ?: null;
            if (!$lead) {
                csReply(['success' => false, 'error' => "Lead #{$id} not found."], 404);
            }
        } else {
            $res = $db->query('SELECT * FROM `lead` ORDER BY id DESC LIMIT 400');
            while ($res && ($l = $res->fetch_assoc())) {
                if (!crmIsTestLead($l) && crmSfdcPlatformKey(crmPlatform($l)) === $pk) {
                    $lead = $l;
                    break;
                }
            }
            if (!$lead) {
                csReply(['success' => false, 'error' => 'No recent ' . CRM_SFDC_PLATFORMS[$pk] . ' lead to preview with. Enter a lead ID.'], 404);
            }
        }
        $label = crmPlatform($lead);
        $payload = crmSfdcPayloadFor($s, $lead, $label);
        $empty = array_keys(array_filter($payload, fn($v) => $v === ''));
        csReply(['success' => true, 'lead' => ['id' => (int) $lead['id'], 'name' => (string) $lead['name'], 'platform' => $label, 'date' => (string) $lead['createddate']],
                 'platform_used' => crmSfdcPlatformKey($label), 'payload' => $payload, 'empty_fields' => $empty,
                 'json' => json_encode($payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)]);
    }
    csReply(['success' => false, 'error' => 'Unknown action.'], 400);
} catch (Throwable $e) {
    error_log('[crm_settings_api] ' . $e->getMessage());
    csReply(['success' => false, 'error' => $e->getMessage()], 500);
}
