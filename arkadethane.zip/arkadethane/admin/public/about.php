<?php
/**
 * about.php — About PerformIQ by Webzaa, written for the execution / DM team:
 *   version + last update · what's new · FAQs · all updates · what PerformIQ includes (and what you can open).
 * One search box looks through the updates and the FAQs.
 * Opened inside dashboard.php (#about) or on its own. Every signed-in user can open it; the system summary and the
 * technical notes (docs/CHANGES_vNN.md) are for Super Admin only, folded away at the bottom.
 * Content: app/Core/version.php (PQ_RELEASES, PQ_FAQS).
 */
session_start();
if (($_SESSION['user_logged'] ?? '') !== 'Y') {
    header('Location: login.php');
    exit;
}
require_once dirname(__DIR__) . '/app/Core/db.php';
require_once dirname(__DIR__) . '/app/Core/version.php';

$h = fn($v) => htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');
$isSuper = ($_SESSION['role'] ?? '') === 'superadmin';

// Super Admin: technical notes of a release (plain text from docs/)
if (isset($_GET['doc'])) {
    $doc = (string) $_GET['doc'];
    $path = dirname(__DIR__) . '/docs/' . $doc;
    header('Content-Type: text/plain; charset=utf-8');
    header('X-Content-Type-Options: nosniff');
    if (!$isSuper || !preg_match('/^CHANGES_v\d+\.md$/', $doc) || !is_file($path)) {
        http_response_code(404);
        echo 'Not available.';
        exit;
    }
    readfile($path);
    exit;
}

$project = defined('PROJECT_NAME') ? (string) PROJECT_NAME : '';
$latest = PQ_RELEASES[0];
$showFirst = 5;                       // updates shown before "Show all updates"

$faqTopics = [];
foreach (PQ_FAQS as $f) {
    $faqTopics[$f['topic']][] = $f;
}

// What PerformIQ includes — in the team's words, grouped like the menu, with "you can open it" per person
$friendly = [
    'overview'  => 'Meta, Google and other platforms together: spend, leads, qualified leads, site visits, CPL / CPQL / CPSV.',
    'reports'   => 'Download the campaign report and daily / weekly / monthly PDFs for the client.',
    'targets'   => 'Monthly plan vs achieved, shown on every dashboard.',
    'meta'      => 'Meta campaigns, ad sets and ads with their leads, and AI suggestions.',
    'google'    => 'Google campaigns, ad groups and ads with their leads, and AI suggestions.',
    'taboola'   => 'Taboola native ads.',
    'manual'    => 'OTT, Display, MyGate and other platforms whose numbers you add or paste.',
    'creatives' => 'Every ad with its image or video and results — what to scale, fix or pause.',
    'keywords'  => 'Google keywords and search terms that bring real leads.',
    'leads'     => 'All leads from every source, with follow-ups and status.',
    'unmapped'  => 'Leads that are not under one of this project\'s campaigns — map them so they count.',
    'crm'       => 'Which leads reached the CRM, which failed and why.',
    'status'    => 'Upload the CRM feedback file: qualified leads and site visits for CPQL / CPSV.',
    'lphygiene' => 'Landing page speed, tracking and form checks, test leads, PDF report.',
    'analytics' => 'Website visitors, sessions and behaviour.',
    'capi'      => 'Send qualified leads and site visits back to Meta to improve targeting.',
    'import'    => 'Add leads from a Meta / Google download — only the missing ones.',
];
$groups = [];
foreach (PQ_MODULES as $key => $m) {
    if ($key === 'taboola' && !(defined('SHOW_TABOOLA') && SHOW_TABOOLA)) {
        continue;
    }
    $groups[$m['group']][] = ['label' => $m['label'], 'desc' => $friendly[$key] ?? $m['desc'], 'can' => function_exists('pqCan') ? pqCan($key) : true];
}
$groups['Admin'] = [
    ['label' => 'Users & Roles', 'desc' => 'Who can sign in and what each person can see and do.', 'can' => $isSuper],
    ['label' => 'CRM Settings', 'desc' => 'Connection to Salesforce and to Meta Conversions API.', 'can' => $isSuper],
];
$canCount = 0;
$allCount = 0;
foreach ($groups as $g) {
    foreach ($g as $m) {
        $allCount++;
        $canCount += $m['can'] ? 1 : 0;
    }
}

// System summary (Super Admin)
$sys = [];
if ($isSuper) {
    $dbs = function_exists('leadDbKeys') ? leadDbKeys() : [];
    $sys = [
        'Project' => $project !== '' ? $project : '—',
        'Lead databases' => $dbs ? implode(', ', array_map(fn($k) => function_exists('leadDbLabel') ? leadDbLabel($k) : $k, $dbs)) : '—',
        'Meta API version' => defined('META_API_VERSION') ? (string) META_API_VERSION : '—',
        'Taboola' => defined('SHOW_TABOOLA') && SHOW_TABOOLA ? 'On' : 'Off',
        'Manual platforms (OTT…)' => !defined('SHOW_OTT') || SHOW_OTT ? 'On' : 'Off',
        'PageSpeed key' => defined('PAGESPEED_API_KEY') && PAGESPEED_API_KEY !== '' ? 'Set' : 'Not set',
        'PHP' => PHP_VERSION,
        'Server time' => date('j M Y, H:i') . ' (' . date_default_timezone_get() . ')',
    ];
}
$roleName = $isSuper ? 'Super Admin' : (function_exists('pqRoles') ? (pqRoles($conn ?? null)[$_SESSION['role'] ?? '']['name'] ?? ($_SESSION['role'] ?? '')) : ($_SESSION['role'] ?? ''));
?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Sora:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
<script>
(function () {
    var root = document.documentElement, t = null;
    try { t = localStorage.getItem('performiq-theme'); } catch (e) {}
    root.setAttribute('data-theme', t === 'light' ? 'light' : 'dark');
    if (/[?&]embed=1(&|$)/.test(location.search)) root.classList.add('pq-embed');
    window.addEventListener('storage', function (e) {
        if (e.key === 'performiq-theme') root.setAttribute('data-theme', e.newValue === 'light' ? 'light' : 'dark');
    });
    window.setTheme = function (t) { root.setAttribute('data-theme', t === 'light' ? 'light' : 'dark'); };
})();
</script>
<title>About PerformIQ</title>
<style>
    :root, html[data-theme="dark"] {
        --bg: #0B0F1A; --surface: #111827; --surface-2: #161D2E; --border: #1E2A42; --border-strong: #2A3957;
        --text: #E2E8F0; --text-dim: #94A3B8; --text-faint: #64748B; --accent: #E8A820; --accent-soft: #E8A8201F;
        --hover: #1A2337; --good: #10B981; --good-soft: #10B9811F; --info: #60A5FA; --info-soft: #60A5FA1A; color-scheme: dark;
    }
    html[data-theme="light"] {
        --bg: #F4F6FA; --surface: #FFFFFF; --surface-2: #F8FAFC; --border: #E2E8F0; --border-strong: #CBD5E1;
        --text: #0F172A; --text-dim: #475569; --text-faint: #94A3B8; --accent: #B7791F; --accent-soft: #B7791F1A;
        --hover: #F1F5F9; --good: #059669; --good-soft: #0596691A; --info: #2563EB; --info-soft: #2563EB14; color-scheme: light;
    }
    * { box-sizing: border-box; }
    [hidden] { display: none !important; }
    body { margin: 0; background: var(--bg); color: var(--text); font: 14px/1.6 'Sora', system-ui, -apple-system, 'Segoe UI', sans-serif; }
    button, input { font: inherit; color: inherit; }
    .wrap { max-width: 1040px; margin: 0 auto; padding: 28px 24px 60px; }
    .pq-embed .wrap { padding-top: 18px; }
    .card { background: var(--surface); border: 1px solid var(--border); border-radius: 14px; padding: 20px 22px; margin-bottom: 18px; min-width: 0; }
    h2 { font-size: 16px; margin: 0 0 4px; }
    .lead { margin: 0 0 16px; color: var(--text-dim); font-size: 13px; }
    .faint { color: var(--text-faint); }

    /* hero */
    .hero { display: flex; gap: 18px; align-items: center; flex-wrap: wrap; }
    .logo { width: 52px; height: 52px; border-radius: 14px; background: var(--accent); color: #111; display: grid; place-items: center; font-weight: 700; font-size: 24px; flex: none; }
    .hero-txt { flex: 1 1 320px; min-width: 0; }
    .hero h1 { margin: 0; font-size: 21px; }
    .hero h1 small { font-size: 12px; font-weight: 600; letter-spacing: .12em; text-transform: uppercase; color: var(--text-faint); margin-left: 6px; }
    .hero p { margin: 4px 0 0; color: var(--text-dim); font-size: 13px; }
    .badges { display: flex; gap: 8px; flex-wrap: wrap; margin-top: 14px; }
    .badge { display: inline-flex; gap: 6px; align-items: center; padding: 6px 12px; border-radius: 10px; background: var(--surface-2); border: 1px solid var(--border); font-size: 12.5px; }
    .badge b { font-weight: 600; }
    .badge.ver b { color: var(--accent); }
    .chan { font-size: 10.5px; font-weight: 700; letter-spacing: .08em; text-transform: uppercase; padding: 1px 7px; border-radius: 99px; border: 1px solid var(--accent); color: var(--accent); }

    /* search */
    .search { position: relative; margin-bottom: 18px; }
    .search input { width: 100%; background: var(--surface); border: 1px solid var(--border-strong); border-radius: 12px; padding: 12px 14px 12px 40px; outline: none; font-size: 14px; }
    .search input:focus { border-color: var(--accent); }
    .search svg { position: absolute; left: 14px; top: 50%; transform: translateY(-50%); width: 16px; height: 16px; color: var(--text-faint); }
    .search-note { font-size: 12px; color: var(--text-faint); margin: -10px 0 16px 4px; }

    /* what's new */
    .new { border-color: var(--accent); background: linear-gradient(0deg, var(--accent-soft), var(--accent-soft)), var(--surface); }
    .eyebrow { font-size: 11px; font-weight: 700; letter-spacing: .1em; text-transform: uppercase; color: var(--accent); }
    .new h2 { font-size: 18px; margin: 4px 0 6px; }
    .why { margin: 0 0 10px; font-size: 13.5px; }
    ul.items { margin: 0; padding-left: 18px; }
    ul.items li { margin: 5px 0; }
    .where { display: inline-flex; gap: 8px; align-items: flex-start; margin-top: 12px; padding: 8px 12px; border-radius: 10px; background: var(--surface-2); border: 1px solid var(--border); font-size: 12.5px; }
    .where b { color: var(--text-dim); font-weight: 600; white-space: nowrap; }

    /* FAQ */
    .topics { display: flex; gap: 8px; flex-wrap: wrap; margin-bottom: 14px; }
    .chip { cursor: pointer; border: 1px solid var(--border-strong); background: var(--surface-2); border-radius: 99px; padding: 5px 12px; font-size: 12.5px; font-weight: 600; color: var(--text-dim); }
    .chip[aria-pressed="true"] { border-color: var(--accent); color: var(--accent); background: var(--accent-soft); }
    .chip:focus-visible, summary:focus-visible, .more:focus-visible, .linkbtn:focus-visible { outline: 2px solid var(--accent); outline-offset: 2px; }
    .faq-topic { margin-top: 6px; }
    .faq-topic h3 { font-size: 11.5px; text-transform: uppercase; letter-spacing: .08em; color: var(--text-faint); margin: 14px 0 6px; font-weight: 600; }
    details.faq { border: 1px solid var(--border); border-radius: 10px; margin-bottom: 8px; background: var(--surface-2); }
    details.faq summary { cursor: pointer; list-style: none; padding: 11px 40px 11px 14px; font-weight: 600; font-size: 13.5px; position: relative; }
    details.faq summary::-webkit-details-marker { display: none; }
    details.faq summary::after { content: '+'; position: absolute; right: 14px; top: 50%; transform: translateY(-50%); font-size: 18px; color: var(--text-faint); font-weight: 400; }
    details.faq[open] summary::after { content: '–'; }
    details.faq .a { padding: 0 14px 12px; color: var(--text-dim); font-size: 13px; }
    details.faq .a b { color: var(--text); }

    /* updates */
    .upd { display: grid; grid-template-columns: 120px 1fr; gap: 6px 18px; padding: 14px 0; border-top: 1px solid var(--border); }
    .upd:first-of-type { border-top: 0; }
    .upd-when { font-size: 12.5px; color: var(--text-dim); }
    .upd-when b { display: block; color: var(--text); font-weight: 600; }
    .upd-when span { font-size: 11.5px; color: var(--text-faint); }
    .upd h4 { margin: 0; font-size: 14.5px; display: flex; gap: 8px; align-items: center; flex-wrap: wrap; }
    .upd .why { margin: 2px 0 6px; font-size: 13px; color: var(--text-dim); }
    .upd .where { margin-top: 8px; }
    .tag { font-size: 11px; font-weight: 600; padding: 1px 8px; border-radius: 99px; border: 1px solid var(--border-strong); color: var(--text-dim); }
    .tag.now { border-color: var(--accent); color: var(--accent); }
    .more { all: unset; box-sizing: border-box; width: 100%; cursor: pointer; display: block; text-align: center; padding: 10px; margin-top: 6px; border: 1px dashed var(--border-strong); border-radius: 10px; color: var(--text-dim); font-weight: 600; font-size: 13px; }
    .more:hover { color: var(--accent); border-color: var(--accent); }
    .linkbtn { all: unset; cursor: pointer; font-size: 11.5px; color: var(--text-faint); }
    .linkbtn:hover { color: var(--info); text-decoration: underline; }
    .empty { color: var(--text-faint); padding: 6px 0; }

    /* included */
    .mods { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 14px; }
    .mod-group h3 { font-size: 11.5px; text-transform: uppercase; letter-spacing: .08em; color: var(--text-faint); margin: 0 0 8px; font-weight: 600; }
    .mod { padding: 10px 12px; border: 1px solid var(--border); border-radius: 10px; margin-bottom: 8px; background: var(--surface-2); }
    .mod.off { opacity: .6; }
    .mod b { font-size: 13px; display: flex; gap: 8px; align-items: center; justify-content: space-between; }
    .mod p { margin: 3px 0 0; font-size: 12px; color: var(--text-dim); line-height: 1.5; }
    .ok { font-size: 10.5px; font-weight: 600; color: var(--good); white-space: nowrap; }
    .no { font-size: 10.5px; font-weight: 600; color: var(--text-faint); white-space: nowrap; }

    /* admin */
    details.admin summary { cursor: pointer; font-weight: 600; font-size: 13px; color: var(--text-dim); }
    .sys { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 0 24px; margin: 12px 0 0; }
    .sys div { display: flex; justify-content: space-between; gap: 12px; padding: 8px 0; border-bottom: 1px solid var(--border); font-size: 13px; }
    .sys dt { color: var(--text-dim); }
    .sys dd { margin: 0; text-align: right; font-weight: 600; overflow-wrap: anywhere; }

    .modal { position: fixed; inset: 0; background: rgba(0,0,0,.55); display: grid; place-items: center; padding: 16px; z-index: 50; }
    .modal-box { background: var(--surface); border: 1px solid var(--border-strong); border-radius: 14px; width: min(860px, 100%); max-height: 86vh; display: flex; flex-direction: column; }
    .modal-head { display: flex; justify-content: space-between; align-items: center; padding: 12px 16px; border-bottom: 1px solid var(--border); }
    .modal-head button { all: unset; cursor: pointer; font-size: 20px; line-height: 1; padding: 2px 8px; color: var(--text-dim); }
    .modal pre { margin: 0; padding: 16px; overflow: auto; white-space: pre-wrap; font: 12.5px/1.6 'JetBrains Mono', ui-monospace, monospace; }

    footer { text-align: center; color: var(--text-faint); font-size: 12px; margin-top: 8px; }
    mark { background: var(--accent-soft); color: inherit; border-radius: 3px; }

    @media (max-width: 860px) { .mods { grid-template-columns: 1fr 1fr; } }
    @media (max-width: 640px) {
        .wrap { padding: 16px 16px 40px; }
        .card { padding: 16px; }
        .mods, .sys { grid-template-columns: 1fr; }
        .upd { grid-template-columns: 1fr; }
        .upd-when b, .upd-when span { display: inline; margin-right: 6px; }
    }
</style>
</head>
<body>
<div class="wrap">

    <section class="card">
        <div class="hero">
            <div class="logo" aria-hidden="true">P</div>
            <div class="hero-txt">
                <h1><?= $h(PQ_PRODUCT) ?><small>by <?= $h(PQ_VENDOR) ?></small></h1>
                <p>Your campaign dashboard: Meta, Google and other platforms in one place, matched with CRM leads, qualified leads and site visits — so you can see what every rupee of spend brought in.</p>
            </div>
        </div>
        <div class="badges">
            <span class="badge ver">Version <b><?= $h(PQ_VERSION) ?></b><?php if (PQ_CHANNEL !== '') { ?> <span class="chan"><?= $h(PQ_CHANNEL) ?></span><?php } ?></span>
            <span class="badge">Last updated <b><?= $h(pqReleaseDate(PQ_RELEASED)) ?></b></span>
            <?php if ($project !== '') { ?><span class="badge">Project <b><?= $h($project) ?></b></span><?php } ?>
            <span class="badge">You can open <b><?= (int) $canCount ?> of <?= (int) $allCount ?></b> features</span>
        </div>
    </section>

    <div class="search">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>
        <input type="search" id="q" placeholder="Search help and updates — e.g. site visit, +91, All time, import" aria-label="Search help and updates">
    </div>
    <p class="search-note" id="q-note" hidden></p>

    <section class="card new" id="new" aria-labelledby="new-h">
        <div class="eyebrow">New in <?= $h(pqVersionLabel($latest['v'])) ?> · <?= $h(pqReleaseDate($latest['date'])) ?></div>
        <h2 id="new-h"><?= $h($latest['title']) ?></h2>
        <p class="why"><?= $h($latest['why'] ?? '') ?></p>
        <ul class="items"><?php foreach ($latest['items'] as $it) { ?><li><?= $h($it) ?></li><?php } ?></ul>
        <?php if (!empty($latest['where'])) { ?><div class="where"><b>Where:</b> <span><?= $h($latest['where']) ?></span></div><?php } ?>
    </section>

    <section class="card" id="faqs" aria-labelledby="faq-h">
        <h2 id="faq-h">FAQs</h2>
        <p class="lead">Quick answers to what the team asks most.</p>
        <div class="topics" role="group" aria-label="FAQ topics">
            <button class="chip" data-topic="" aria-pressed="true">All</button>
            <?php foreach ($faqTopics as $t => $list) { ?>
                <button class="chip" data-topic="<?= $h($t) ?>" aria-pressed="false"><?= $h($t) ?></button>
            <?php } ?>
        </div>
        <?php foreach ($faqTopics as $t => $list) { ?>
            <div class="faq-topic" data-topic="<?= $h($t) ?>">
                <h3><?= $h($t) ?></h3>
                <?php foreach ($list as $f) { ?>
                    <details class="faq">
                        <summary><?= $h($f['q']) ?></summary>
                        <div class="a"><?= pqHelpHtml($f['a']) ?></div>
                    </details>
                <?php } ?>
            </div>
        <?php } ?>
        <p class="empty" id="faq-none" hidden>No FAQ matches your search.</p>
    </section>

    <section class="card" id="updates" aria-labelledby="upd-h">
        <h2 id="upd-h">All updates</h2>
        <p class="lead">What changed, why it helps and where to find it — newest first.</p>
        <div id="upd-list">
            <?php foreach (PQ_RELEASES as $i => $r) { ?>
                <article class="upd" data-i="<?= (int) $i ?>"<?= $i >= $showFirst ? ' data-extra="1" hidden' : '' ?>>
                    <div class="upd-when"><b><?= $h(pqReleaseDate($r['date'])) ?></b><span>Version <?= $h($r['v']) ?></span></div>
                    <div>
                        <h4><?= $h($r['title']) ?>
                            <?php if ($i === 0) { ?><span class="tag now">Latest</span><?php } ?>
                            <?php foreach ($r['areas'] as $a) { ?><span class="tag"><?= $h($a) ?></span><?php } ?>
                        </h4>
                        <?php if (!empty($r['why'])) { ?><p class="why"><?= $h($r['why']) ?></p><?php } ?>
                        <ul class="items"><?php foreach ($r['items'] as $it) { ?><li><?= $h($it) ?></li><?php } ?></ul>
                        <?php if (!empty($r['where'])) { ?><div class="where"><b>Where:</b> <span><?= $h($r['where']) ?></span></div><?php } ?>
                        <?php if ($isSuper && !empty($r['doc'])) { ?><div style="margin-top:6px"><button class="linkbtn" data-doc="<?= $h($r['doc']) ?>">Technical notes (admin)</button></div><?php } ?>
                    </div>
                </article>
            <?php } ?>
        </div>
        <?php if (count(PQ_RELEASES) > $showFirst) { ?>
            <button class="more" id="more" aria-expanded="false">Show all <?= count(PQ_RELEASES) ?> updates</button>
        <?php } ?>
        <p class="empty" id="upd-none" hidden>No update matches your search.</p>
    </section>

    <section class="card" id="included" aria-labelledby="inc-h">
        <h2 id="inc-h">What PerformIQ includes</h2>
        <p class="lead">Everything in the menu, in one line each. <span class="ok">● You have access</span> shows what you can open<?= $roleName !== '' ? ' as ' . $h($roleName) : '' ?>.</p>
        <div class="mods">
            <?php foreach ($groups as $g => $mods) { ?>
                <div class="mod-group">
                    <h3><?= $h($g) ?></h3>
                    <?php foreach ($mods as $m) { ?>
                        <div class="mod<?= $m['can'] ? '' : ' off' ?>">
                            <b><?= $h($m['label']) ?> <?= $m['can'] ? '<span class="ok">● You have access</span>' : '<span class="no">Ask your admin</span>' ?></b>
                            <p><?= $h($m['desc']) ?></p>
                        </div>
                    <?php } ?>
                </div>
            <?php } ?>
        </div>
    </section>

    <?php if ($isSuper) { ?>
    <section class="card">
        <details class="admin">
            <summary>For Super Admin — system details</summary>
            <dl class="sys">
                <?php foreach ($sys as $k => $v) { ?><div><dt><?= $h($k) ?></dt><dd><?= $h($v) ?></dd></div><?php } ?>
            </dl>
            <p class="faint" style="font-size:12px;margin:12px 0 0">Updates and FAQs are edited in app/Core/version.php; technical notes are in docs/. When deploying, keep the live config/config.php.</p>
        </details>
    </section>
    <?php } ?>

    <footer><?= $h(PQ_PRODUCT) ?> by <?= $h(PQ_VENDOR) ?> · Version <?= $h(pqVersionLabel()) ?> · Updated <?= $h(pqReleaseDate(PQ_RELEASED)) ?></footer>
</div>

<div class="modal" id="modal" hidden role="dialog" aria-modal="true" aria-labelledby="modal-t">
    <div class="modal-box">
        <div class="modal-head"><b id="modal-t">Technical notes</b><button id="modal-x" aria-label="Close">×</button></div>
        <pre id="modal-body"></pre>
    </div>
</div>

<script>
(function () {
    'use strict';
    const $ = (s, el = document) => el.querySelector(s);
    const $$ = (s, el = document) => [...el.querySelectorAll(s)];
    let topic = '', showAll = false;

    function apply() {
        const q = $('#q').value.trim().toLowerCase();
        // FAQs
        let faqHits = 0;
        $$('.faq-topic').forEach(t => {
            let shown = 0;
            const okTopic = !topic || t.dataset.topic === topic;
            $$('details.faq', t).forEach(d => {
                const ok = okTopic && (!q || d.textContent.toLowerCase().includes(q));
                d.hidden = !ok;
                if (ok) { shown++; if (q) d.open = true; }
            });
            t.hidden = shown === 0;
            faqHits += shown;
        });
        $('#faq-none').hidden = faqHits > 0;
        // updates
        let updHits = 0;
        $$('.upd').forEach(u => {
            const okText = !q || u.textContent.toLowerCase().includes(q);
            const ok = okText && (q || showAll || !u.dataset.extra);
            u.hidden = !ok;
            if (ok) updHits++;
        });
        $('#upd-none').hidden = updHits > 0;
        const more = $('#more');
        if (more) more.hidden = !!q || showAll;
        $('#new').hidden = !!q;
        $('#included').hidden = !!q;
        const note = $('#q-note');
        note.hidden = !q;
        if (q) note.textContent = `${faqHits} FAQ${faqHits === 1 ? '' : 's'} and ${updHits} update${updHits === 1 ? '' : 's'} match "${$('#q').value.trim()}".`;
    }
    $('#q').addEventListener('input', apply);
    $$('.chip').forEach(c => c.addEventListener('click', () => {
        topic = c.dataset.topic;
        $$('.chip').forEach(x => x.setAttribute('aria-pressed', x === c ? 'true' : 'false'));
        apply();
    }));
    const more = $('#more');
    if (more) more.addEventListener('click', () => { showAll = true; more.setAttribute('aria-expanded', 'true'); apply(); });

    // Super Admin: technical notes
    const modal = $('#modal');
    const close = () => { modal.hidden = true; };
    $('#modal-x').addEventListener('click', close);
    modal.addEventListener('click', e => { if (e.target === modal) close(); });
    document.addEventListener('keydown', e => { if (e.key === 'Escape' && !modal.hidden) close(); });
    $$('[data-doc]').forEach(b => b.addEventListener('click', async () => {
        $('#modal-t').textContent = 'Technical notes — ' + b.dataset.doc;
        $('#modal-body').textContent = 'Loading…';
        modal.hidden = false;
        try {
            const r = await fetch('about.php?doc=' + encodeURIComponent(b.dataset.doc), { credentials: 'same-origin' });
            $('#modal-body').textContent = r.ok ? await r.text() : 'Not available.';
        } catch (e) { $('#modal-body').textContent = 'Could not load the notes.'; }
        $('#modal-x').focus();
    }));
})();
</script>
</body>
</html>
