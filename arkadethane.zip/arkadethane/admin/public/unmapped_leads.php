<?php
/**
 * unmapped_leads.php — Meta + Google leads that no dashboard can put under one of this project's
 * campaigns, in one place (tabs: All / Meta / Google / No source). Map them to a saved campaign →
 * ad set / ad group → ad, or mark them Test / Junk. Backend: unmapped_leads_api.php,
 * logic: app/Leads/unmapped.php.
 */
session_start();
if (($_SESSION['user_logged'] ?? '') !== 'Y') {
    header('Location: login.php');
    exit;
}
require_once dirname(__DIR__) . '/app/Core/db.php';
$h = fn($v) => htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');
$dbs = [];
foreach (leadDbKeys() as $k) {
    $dbs[$k] = leadDbLabel($k);
}
$defaultDb = appDbKey();
?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Unmapped Leads</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Sora:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
<script>
(function () {
    var root = document.documentElement, t = null;
    try { t = localStorage.getItem('performiq-theme'); } catch (e) {}
    root.setAttribute('data-theme', t === 'light' ? 'light' : 'dark');
    if (/[?&]embed=1(&|$)/.test(location.search)) root.classList.add('pq-embed');
    window.addEventListener('storage', function (e) {
        if (e.key === 'performiq-theme') root.setAttribute('data-theme', e.newValue === 'light' ? 'light' : 'dark');
    });
    window.setTheme = function (t) { root.setAttribute('data-theme', t === 'light' ? 'light' : 'dark'); };
})();
</script>
<style>
    :root, html[data-theme="dark"] {
        --bg: #0B0F1A; --surface: #111827; --surface-2: #161D2E; --border: #1E2A42; --border-strong: #2A3957;
        --text: #E2E8F0; --text-dim: #94A3B8; --text-faint: #64748B; --accent: #E8A820; --accent-soft: #E8A8201F;
        --hover: #1A2337; --good: #10B981; --good-soft: #10B9811F; --bad: #EF4444; --bad-soft: #EF44441A;
        --warn: #F59E0B; --warn-soft: #F59E0B1A; --meta: #3987E5; --meta-soft: #3987E51F; --google: #D95926; --google-soft: #D959261F; color-scheme: dark;
    }
    html[data-theme="light"] {
        --bg: #F4F6FA; --surface: #FFFFFF; --surface-2: #F8FAFC; --border: #E2E8F0; --border-strong: #CBD5E1;
        --text: #0F172A; --text-dim: #475569; --text-faint: #94A3B8; --accent: #B7791F; --accent-soft: #B7791F1A;
        --hover: #F1F5F9; --good: #059669; --good-soft: #0596691A; --bad: #DC2626; --bad-soft: #DC26261A;
        --warn: #B45309; --warn-soft: #B453091A; --meta: #2A78D6; --meta-soft: #2A78D61A; --google: #C2410C; --google-soft: #C2410C1A; color-scheme: light;
    }
    * { box-sizing: border-box; }
    body { margin: 0; background: var(--bg); color: var(--text); font: 14px/1.5 'Sora', system-ui, -apple-system, 'Segoe UI', sans-serif; }
    button, input, select { font: inherit; color: inherit; }
    .mono { font-family: 'JetBrains Mono', ui-monospace, monospace; font-variant-numeric: tabular-nums; }
    .wrap { max-width: 1400px; margin: 0 auto; padding: 28px 24px 60px; }
    .pq-embed .wrap { padding-top: 20px; }
    .pq-embed .page-head { display: none; }
    h1 { font-size: 22px; margin: 0 0 4px; }
    .sub { color: var(--text-dim); margin: 0 0 20px; font-size: 13px; }
    .card { background: var(--surface); border: 1px solid var(--border); border-radius: 12px; padding: 18px 20px; margin-bottom: 16px; }
    .bar { display: flex; gap: 10px; align-items: center; flex-wrap: wrap; }
    .bar .grow { flex: 1 1 220px; }
    select, input[type=text], input[type=date], input[type=search] { background: var(--surface-2); border: 1px solid var(--border-strong); border-radius: 8px; padding: 8px 10px; outline: none; min-width: 0; }
    select:focus, input:focus { border-color: var(--accent); }
    .btn { border: 1px solid var(--border-strong); background: var(--surface-2); padding: 8px 14px; border-radius: 8px; cursor: pointer; font-weight: 600; font-size: 13px; white-space: nowrap; }
    .btn:hover { background: var(--hover); }
    .btn.primary { background: var(--accent); border-color: var(--accent); color: #111; }
    .btn.sm { padding: 5px 10px; font-size: 12px; }
    .btn.ghost-bad { color: var(--bad); }
    .btn.danger { background: var(--bad); border-color: var(--bad); color: #fff; }
    .btn:disabled { opacity: .5; cursor: not-allowed; }
    .tabs { display: flex; gap: 6px; flex-wrap: wrap; }
    .tab { border: 1px solid var(--border); background: var(--surface-2); border-radius: 99px; padding: 6px 14px; font-size: 12.5px; cursor: pointer; color: var(--text-dim); font-weight: 600; }
    .tab.on { border-color: var(--accent); color: var(--text); background: var(--accent-soft); }
    .tab b { margin-left: 4px; font-family: 'JetBrains Mono', monospace; }
    .tbl-wrap { overflow: auto; border: 1px solid var(--border); border-radius: 10px; }
    table { width: 100%; border-collapse: collapse; font-size: 12.5px; }
    th { position: sticky; top: 0; z-index: 1; background: var(--surface-2); color: var(--text-dim); font-weight: 600; text-align: left; padding: 9px 10px;
         border-bottom: 1px solid var(--border); white-space: nowrap; font-size: 11px; text-transform: uppercase; letter-spacing: .04em; }
    td { padding: 9px 10px; border-bottom: 1px solid var(--border); vertical-align: top; }
    tr:last-child td { border-bottom: 0; }
    tr.sel td { background: var(--accent-soft); }
    td.chk, th.chk { width: 34px; text-align: center; }
    input[type=checkbox] { accent-color: var(--accent); width: 15px; height: 15px; }
    .pill { display: inline-block; padding: 1px 8px; border-radius: 99px; font-size: 11px; font-weight: 600; white-space: nowrap; }
    .pill.meta { color: var(--meta); background: var(--meta-soft); }
    .pill.google { color: var(--google); background: var(--google-soft); }
    .pill.unknown { color: var(--text-dim); background: var(--surface-2); border: 1px solid var(--border); }
    .pill.warn { color: var(--warn); background: var(--warn-soft); }
    .pill.bad { color: var(--bad); background: var(--bad-soft); }
    .muted { color: var(--text-dim); }
    .faint { color: var(--text-faint); font-size: 11.5px; }
    .map { display: grid; grid-template-columns: repeat(3, minmax(130px, 1fr)) auto; gap: 6px; align-items: center; min-width: 500px; }
    .map select { width: 100%; padding: 6px 8px; font-size: 12px; }
    .map .plat { grid-column: 1 / -1; display: flex; gap: 6px; align-items: center; }
    .note { padding: 11px 14px; border-radius: 10px; font-size: 12.5px; margin-bottom: 14px; border: 1px solid; }
    .note.warn { background: var(--warn-soft); border-color: var(--warn); }
    .note.bad { background: var(--bad-soft); border-color: var(--bad); }
    .note.good { background: var(--good-soft); border-color: var(--good); }
    .bulk { position: sticky; bottom: 12px; z-index: 5; display: flex; gap: 10px; align-items: center; flex-wrap: wrap; background: var(--surface);
            border: 1px solid var(--accent); border-radius: 12px; padding: 10px 14px; box-shadow: 0 10px 30px rgba(0, 0, 0, .35); margin-top: 12px; }
    .pager { display: flex; justify-content: space-between; align-items: center; gap: 10px; flex-wrap: wrap; margin-top: 12px; font-size: 12px; color: var(--text-dim); }
    .pager button { border: 1px solid var(--border); background: var(--surface-2); border-radius: 6px; padding: 4px 10px; cursor: pointer; font-size: 11px; color: var(--text-dim); }
    .pager button.on { background: var(--accent); border-color: var(--accent); color: #111; font-weight: 700; }
    .hidden { display: none !important; }
    .overlay { position: fixed; inset: 0; background: rgba(2, 6, 23, .6); display: grid; place-items: center; z-index: 50; padding: 16px; }
    .dialog { background: var(--surface); border: 1px solid var(--border-strong); border-radius: 14px; padding: 22px; max-width: 620px; width: 100%; max-height: 90vh; overflow: auto; box-shadow: 0 20px 60px rgba(0, 0, 0, .45); }
    .dialog h3 { margin: 0 0 8px; font-size: 17px; }
    .actions { display: flex; justify-content: flex-end; gap: 10px; margin-top: 18px; flex-wrap: wrap; }
    .spinner { width: 15px; height: 15px; border: 2px solid var(--border-strong); border-top-color: var(--accent); border-radius: 50%; display: inline-block; animation: spin .8s linear infinite; vertical-align: -3px; margin-right: 8px; }
    @keyframes spin { to { transform: rotate(360deg); } }
    .toast { position: fixed; right: 24px; bottom: 24px; z-index: 60; background: var(--surface); border: 1px solid var(--border-strong); border-left: 4px solid var(--good);
             padding: 12px 16px; border-radius: 8px; font-size: 13px; box-shadow: 0 10px 30px rgba(0, 0, 0, .35); max-width: 440px; }
    .toast.bad { border-left-color: var(--bad); }
    @media (max-width: 760px) { .wrap { padding: 16px; } }
</style>
</head>
<body>
<div class="wrap">
    <div class="page-head">
        <h1>Unmapped Leads</h1>
        <p class="sub">Meta and Google leads the dashboards can't put under one of this project's campaigns.</p>
    </div>

    <div class="card">
        <div class="bar" style="justify-content:space-between;">
            <div class="tabs" id="tabs"></div>
            <div class="bar">
                <button class="btn" id="b-export">↓ Export CSV</button>
                <button class="btn" id="b-template">Import format</button>
                <label class="btn" style="margin:0;">↑ Import CSV<input type="file" id="f-import" accept=".csv,.txt" hidden></label>
            </div>
        </div>
        <div class="bar" style="margin-top:14px;">
            <?php if (count($dbs) > 1) { ?>
            <select id="db" title="Lead database"><?php foreach ($dbs as $k => $l) { ?><option value="<?= $h($k) ?>" <?= $k === $defaultDb ? 'selected' : '' ?>><?= $h($l) ?></option><?php } ?></select>
            <?php } else { ?><input type="hidden" id="db" value="<?= $h($defaultDb) ?>"><?php } ?>
            <select id="range">
                <option value="today">Today</option>
                <option value="yesterday">Yesterday</option>
                <option value="7">Last 7 days</option>
                <option value="30" selected>Last 30 days</option>
                <option value="90">Last 90 days</option>
                <option value="month">This month</option>
                <option value="lastmonth">Last month</option>
                <option value="last_1y">Last 1 year</option>
                <option value="all">All time</option>
                <option value="custom">Custom…</option>
            </select>
            <span id="custom" class="bar hidden"><input type="date" id="d-from"> <span class="muted">to</span> <input type="date" id="d-to"></span>
            <select id="st" title="Lead status"><option value="">All lead statuses</option></select>
            <input type="search" id="q" class="grow" placeholder="Search name, mobile, email, leadgen ID or gclid…">
            <button class="btn" id="b-refresh">↻ Refresh</button>
        </div>
    </div>

    <div id="msg"></div>
    <div id="unlinked"></div>

    <div class="card" style="padding:0;">
        <div class="tbl-wrap" style="border:0;border-radius:12px;max-height:calc(100vh - 260px);">
            <table>
                <thead><tr>
                    <th class="chk"><input type="checkbox" id="all" title="Select all on this page"></th>
                    <th>Lead date</th><th>Lead</th><th>Platform</th><th>Why it's unmapped</th>
                    <th>Map to a saved campaign → ad set / group → ad</th><th></th>
                </tr></thead>
                <tbody id="rows"><tr><td colspan="7" class="muted" style="padding:24px;"><span class="spinner"></span>Loading…</td></tr></tbody>
            </table>
        </div>
    </div>
    <div class="pager" id="pager"></div>
    <div class="bulk hidden" id="bulk"></div>
</div>

<script>
(function () {
    'use strict';
    const API = 'unmapped_leads_api.php';
    const $ = s => document.querySelector(s);
    const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
    const fmt = n => Number(n || 0).toLocaleString('en-IN');
    const LABEL = { all: 'All', meta: 'Meta', google: 'Google', unknown: 'No source' };
    const S = { rows: [], counts: {}, unlinked: [], linked: {}, tab: 'all', status: '', page: 1, size: 50, sel: new Set(), struct: {}, pick: {} };
    try { S.status = localStorage.getItem('pq-unmapped-status') || ''; } catch (e) {}
    try { const t = localStorage.getItem('pq-unmapped-tab'); if (LABEL[t]) S.tab = t; } catch (e) {}

    const db = () => $('#db').value;
    async function api(action, params, body) {
        const qs = new URLSearchParams(Object.assign({ action, db: db() }, params || {}));
        const opt = body ? { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(Object.assign({ db: db() }, body)) } : {};
        const res = await fetch(`${API}?${qs}`, Object.assign({ credentials: 'same-origin' }, opt));
        const d = await res.json().catch(() => ({ success: false, error: `Server error (HTTP ${res.status}).` }));
        if (!d.success) throw new Error(d.error || 'Request failed');
        return d;
    }
    function toast(text, bad) {
        const t = document.createElement('div');
        t.className = 'toast' + (bad ? ' bad' : '');
        t.textContent = text;
        document.body.appendChild(t);
        setTimeout(() => t.remove(), 4500);
    }
    function dialog(html, okText, okClass) {
        return new Promise(resolve => {
            const o = document.createElement('div');
            o.className = 'overlay';
            o.innerHTML = `<div class="dialog" role="dialog" aria-modal="true">${html}<div class="actions"><button class="btn" data-x>Cancel</button>${okText ? `<button class="btn ${okClass || 'primary'}" data-ok>${okText}</button>` : ''}</div></div>`;
            document.body.appendChild(o);
            const end = v => { o.remove(); resolve(v); };
            o.querySelector('[data-x]').onclick = () => end(null);
            if (okText) o.querySelector('[data-ok]').onclick = () => end(o);
            o.addEventListener('click', e => { if (e.target === o) end(null); });
        });
    }

    /* ── dates ── */
    const ymd = d => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
    function range() {
        const v = $('#range').value, now = new Date(), t = ymd(now);
        if (v === 'all') return { since: '', until: '' };
        if (v === 'today') return { since: t, until: t };
        if (v === 'yesterday') { const y = new Date(now); y.setDate(y.getDate() - 1); return { since: ymd(y), until: ymd(y) }; }
        if (v === 'last_1y') { const y = new Date(now); y.setFullYear(y.getFullYear() - 1); y.setDate(y.getDate() + 1); return { since: ymd(y), until: t }; }
        if (v === 'custom') return { since: $('#d-from').value, until: $('#d-to').value };
        if (v === 'month') return { since: ymd(new Date(now.getFullYear(), now.getMonth(), 1)), until: t };
        if (v === 'lastmonth') return { since: ymd(new Date(now.getFullYear(), now.getMonth() - 1, 1)), until: ymd(new Date(now.getFullYear(), now.getMonth(), 0)) };
        const d = new Date(now); d.setDate(d.getDate() - (+v - 1));
        return { since: ymd(d), until: t };
    }
    $('#range').addEventListener('change', () => { $('#custom').classList.toggle('hidden', $('#range').value !== 'custom'); if ($('#range').value !== 'custom') load(); });
    ['#d-from', '#d-to'].forEach(id => $(id).addEventListener('change', () => { if ($('#d-from').value && $('#d-to').value) load(); }));
    let qTimer = null;
    $('#q').addEventListener('input', () => { clearTimeout(qTimer); qTimer = setTimeout(load, 400); });
    $('#b-refresh').addEventListener('click', load);
    $('#db').addEventListener('change', () => { S.struct = {}; load(); });

    /* ── data ── */
    async function structure(p) {
        if (!S.struct[p]) S.struct[p] = api('structure', { platform: p }).then(d => d.campaigns);
        return S.struct[p];
    }
    async function load() {
        $('#rows').innerHTML = `<tr><td colspan="7" class="muted" style="padding:24px;"><span class="spinner"></span>Loading…</td></tr>`;
        $('#msg').innerHTML = '';
        try {
            const r = range();
            const d = await api('list', { since: r.since, until: r.until, search: $('#q').value.trim() });
            Object.assign(S, { rows: d.rows, counts: d.counts, unlinked: d.unlinked, linked: d.linked, page: 1 });
            S.sel.clear();
            await Promise.all(['meta', 'google'].map(structure));
            buildStatusFilter();
            render();
        } catch (e) {
            $('#rows').innerHTML = `<tr><td colspan="7" style="padding:24px;color:var(--bad);">${esc(e.message)}</td></tr>`;
        }
    }

    /* ── render ── */
    const stKey = r => (r.status || '').trim().toUpperCase() || '__none';
    const ST_ORDER = ['__none', 'QUALIFIED', 'TO BE QUALIFIED', 'NON-QUALIFIED'];
    const stLabel = k => k === '__none' ? 'No status yet' : k;
    function byStatus() { return S.rows.filter(r => !S.status || stKey(r) === S.status); }
    function visible() { return byStatus().filter(r => S.tab === 'all' || r.platform === S.tab); }
    function buildStatusFilter() {
        const n = {};
        S.rows.forEach(r => { const k = stKey(r); n[k] = (n[k] || 0) + 1; });
        const keys = Object.keys(n).sort((a, b) => ((ST_ORDER.indexOf(a) + 1) || 99) - ((ST_ORDER.indexOf(b) + 1) || 99) || a.localeCompare(b));
        if (S.status && !n[S.status]) S.status = '';
        $('#st').innerHTML = `<option value="">All lead statuses (${fmt(S.rows.length)})</option>`
            + keys.map(k => `<option value="${esc(k)}" ${S.status === k ? 'selected' : ''}>${esc(stLabel(k))} (${fmt(n[k])})</option>`).join('');
    }
    $('#st').addEventListener('change', () => { S.status = $('#st').value; S.page = 1; S.sel.clear(); try { localStorage.setItem('pq-unmapped-status', S.status); } catch (e) {} render(); });
    function campaignOptions(list, sel) {
        return '<option value="">— campaign —</option>' + list.map(c => `<option value="${esc(c.id)}" ${c.id === sel ? 'selected' : ''}>${esc(c.name)}</option>`).join('');
    }
    async function mapCell(r) {
        const pick = S.pick[r.key] || (S.pick[r.key] = { platform: r.platform === 'unknown' ? '' : r.platform, c: '', g: '', a: '' });
        const p = pick.platform;
        let html = '';
        if (r.platform === 'unknown') {
            html += `<div class="plat"><span class="faint">Platform:</span>
                <select data-k="${esc(r.key)}" data-f="platform" style="width:auto;"><option value="">— choose —</option>
                <option value="meta" ${p === 'meta' ? 'selected' : ''}>Meta</option><option value="google" ${p === 'google' ? 'selected' : ''}>Google</option></select></div>`;
        }
        if (!p) return `<div class="map">${html}</div>`;
        const camps = await structure(p);
        if (!camps.length) return `<div class="map">${html}<span class="faint" style="grid-column:1/-1;">No ${p === 'meta' ? 'Meta' : 'Google'} campaigns are linked yet — use ⟳ Sync with ${p === 'meta' ? 'Meta' : 'Google'} on the ${p === 'meta' ? 'Meta' : 'Google'} dashboard.</span></div>`;
        const c = camps.find(x => x.id === pick.c);
        const g = c && c.groups.find(x => x.id === pick.g);
        const gw = p === 'meta' ? 'ad set' : 'ad group';
        html += `<select data-k="${esc(r.key)}" data-f="c">${campaignOptions(camps, pick.c)}</select>
            <select data-k="${esc(r.key)}" data-f="g" ${c ? '' : 'disabled'}><option value="">— ${gw} (optional) —</option>${c ? c.groups.map(x => `<option value="${esc(x.id)}" ${x.id === pick.g ? 'selected' : ''}>${esc(x.name)}</option>`).join('') : ''}</select>
            <select data-k="${esc(r.key)}" data-f="a" ${g ? '' : 'disabled'}><option value="">— ad (optional) —</option>${g ? g.ads.map(x => `<option value="${esc(x.id)}" ${x.id === pick.a ? 'selected' : ''}>${esc(x.name)}</option>`).join('') : ''}</select>
            <button class="btn sm primary" data-save="${esc(r.key)}" ${pick.c ? '' : 'disabled'}>Save</button>`;
        return `<div class="map">${html}</div>`;
    }
    async function render() {
        const tabs = ['all', 'meta', 'google', 'unknown'].filter(k => k !== 'unknown' || S.counts.unknown);
        const base = byStatus(), cnt = { all: base.length };
        base.forEach(r => { cnt[r.platform] = (cnt[r.platform] || 0) + 1; });
        $('#tabs').innerHTML = tabs.map(k => `<button class="tab ${S.tab === k ? 'on' : ''}" data-tab="${k}">${LABEL[k]}<b>${fmt(cnt[k] || 0)}</b></button>`).join('');
        $('#tabs').querySelectorAll('[data-tab]').forEach(b => b.onclick = () => { S.tab = b.dataset.tab; S.page = 1; try { localStorage.setItem('pq-unmapped-tab', S.tab); } catch (e) {} render(); });

        // campaigns found on leads that aren't linked → usually a Sync away
        const ul = S.unlinked.filter(u => S.tab === 'all' || u.platform === S.tab).slice(0, 8);
        $('#unlinked').innerHTML = ul.length ? `<div class="note warn"><b>Campaigns on these leads aren't linked to this project.</b>
            If they belong here, link them with ⟳ Sync with Meta / Google on that dashboard and the leads map themselves; otherwise map the leads below.
            <div style="margin-top:6px;">${ul.map(u => `<span class="pill ${u.platform}" style="margin:2px 4px 2px 0;white-space:normal;overflow-wrap:anywhere;max-width:100%;">${esc(u.campaign)} · ${fmt(u.leads)}</span>`).join('')}</div></div>` : '';

        const list = visible();
        const pages = Math.max(1, Math.ceil(list.length / S.size));
        S.page = Math.min(S.page, pages);
        const shown = list.slice((S.page - 1) * S.size, S.page * S.size);
        if (!shown.length) {
            const linkedNote = (S.tab === 'meta' || S.tab === 'google') && !S.linked[S.tab] ? ` No ${LABEL[S.tab]} campaigns are linked yet, so nothing can be mapped — use ⟳ Sync with ${LABEL[S.tab]} first.` : '';
            $('#rows').innerHTML = `<tr><td colspan="7" style="padding:28px;" class="muted">🎉 No unmapped ${S.tab === 'all' ? '' : LABEL[S.tab] + ' '}leads${S.status ? ' with status “' + esc(stLabel(S.status)) + '”' : ''} in this period.${linkedNote}</td></tr>`;
        } else {
            const cells = await Promise.all(shown.map(mapCell));
            $('#rows').innerHTML = shown.map((r, i) => `<tr class="${S.sel.has(r.key) ? 'sel' : ''}">
                <td class="chk"><input type="checkbox" data-sel="${esc(r.key)}" ${S.sel.has(r.key) ? 'checked' : ''}></td>
                <td class="mono" style="white-space:nowrap;">${esc(r.date.slice(0, 16))}${r.leads > 1 ? `<div class="faint">${r.leads} leads since ${esc(r.first_date.slice(0, 10))}</div>` : ''}</td>
                <td><div><b>${esc(r.name) || '<span class="faint">(no name)</span>'}</b></div><div class="mono faint">${esc(r.mobile)}</div>${r.email ? `<div class="faint">${esc(r.email)}</div>` : ''}
                    ${r.status ? `<div class="faint">Status: ${esc(r.status)}</div>` : ''}</td>
                <td><span class="pill ${r.platform}">${LABEL[r.platform]}</span><div class="faint" style="margin-top:3px;">${esc(r.source || '(no source)')}</div>
                    ${r.leadgen_id ? `<div class="faint mono" title="leadgen_id">LG ${esc(r.leadgen_id)}</div>` : ''}${r.gclid ? `<div class="faint mono" title="gclid">gclid ${esc(r.gclid.slice(0, 14))}…</div>` : ''}
                    ${r.crm && (r.crm.state === 'failed' || r.crm.state === 'not_sent') ? `<div class="pill bad" style="margin-top:3px;" title="${esc(r.crm.reason)}">CRM ${r.crm.state === 'failed' ? 'failed' : 'not sent'}</div>` : ''}</td>
                <td>${esc(r.reason.text)}${r.reason.campaign ? `<div class="faint">“${esc(r.reason.campaign)}”</div>` : ''}
                    ${(r.current.group || r.current.ad) ? `<div class="faint">${esc([r.current.group, r.current.ad].filter(Boolean).join(' › '))}</div>` : ''}</td>
                <td>${cells[i]}</td>
                <td style="white-space:nowrap;"><button class="btn sm" data-st="TEST" data-k="${esc(r.key)}">Test</button> <button class="btn sm ghost-bad" data-st="JUNK" data-k="${esc(r.key)}">Junk</button></td>
            </tr>`).join('');
        }
        // pager
        const btn = (p, l) => `<button class="${p === S.page ? 'on' : ''}" data-page="${p}" ${p < 1 || p > pages ? 'disabled' : ''}>${l || p}</button>`;
        let pb = '';
        if (pages > 1) {
            pb += btn(S.page - 1, '‹ Prev');
            for (let p = Math.max(1, S.page - 2); p <= Math.min(pages, S.page + 2); p++) pb += btn(p);
            pb += btn(S.page + 1, 'Next ›');
        }
        $('#pager').innerHTML = `<span>${list.length ? `Showing ${fmt((S.page - 1) * S.size + 1)}–${fmt(Math.min(S.page * S.size, list.length))} of ${fmt(list.length)}` : ''} · one row per person and platform</span>
            <span style="display:flex;gap:4px;align-items:center;flex-wrap:wrap;"><select id="psize" style="padding:4px 6px;font-size:11px;">${[25, 50, 100, 250].map(n => `<option ${n === S.size ? 'selected' : ''}>${n}</option>`).join('')}</select> per page ${pb}</span>`;
        $('#pager').querySelectorAll('[data-page]').forEach(b => b.onclick = () => { S.page = +b.dataset.page; render(); });
        $('#psize').onchange = e => { S.size = +e.target.value; S.page = 1; render(); };
        $('#all').checked = shown.length > 0 && shown.every(r => S.sel.has(r.key));
        renderBulk();
    }

    /* ── row events ── */
    const byKey = k => S.rows.find(r => r.key === k);
    $('#rows').addEventListener('change', async e => {
        const t = e.target;
        if (t.dataset.sel) { t.checked ? S.sel.add(t.dataset.sel) : S.sel.delete(t.dataset.sel); t.closest('tr').classList.toggle('sel', t.checked); renderBulk(); return; }
        if (!t.dataset.f) return;
        const p = S.pick[t.dataset.k];
        if (t.dataset.f === 'platform') Object.assign(p, { platform: t.value, c: '', g: '', a: '' });
        if (t.dataset.f === 'c') Object.assign(p, { c: t.value, g: '', a: '' });
        if (t.dataset.f === 'g') Object.assign(p, { g: t.value, a: '' });
        if (t.dataset.f === 'a') p.a = t.value;
        const td = t.closest('td');
        td.innerHTML = await mapCell(byKey(t.dataset.k));
    });
    $('#rows').addEventListener('click', async e => {
        const b = e.target.closest('button');
        if (!b) return;
        if (b.dataset.save) return saveMap([byKey(b.dataset.save)], S.pick[b.dataset.save], b);
        if (b.dataset.st) return markStatus([byKey(b.dataset.k)], b.dataset.st);
    });
    $('#all').addEventListener('change', e => {
        const list = visible().slice((S.page - 1) * S.size, S.page * S.size);
        list.forEach(r => e.target.checked ? S.sel.add(r.key) : S.sel.delete(r.key));
        render();
    });

    async function saveMap(rows, pick, btn) {
        const ids = rows.flatMap(r => r.lead_ids);
        if (btn) { btn.disabled = true; btn.innerHTML = '<span class="spinner"></span>'; }
        try {
            const d = await api('map', {}, { platform: pick.platform, lead_ids: ids, campaign_id: pick.c, group_id: pick.g, ad_id: pick.a });
            toast(`✅ ${fmt(d.updated)} lead${d.updated === 1 ? '' : 's'} mapped to “${d.choice.campaign}”${d.choice.group ? ' › ' + d.choice.group : ''}${d.choice.ad ? ' › ' + d.choice.ad : ''}.`);
            removeRows(rows);
        } catch (err) { toast('❌ ' + err.message, true); if (btn) { btn.disabled = false; btn.textContent = 'Save'; } }
    }
    async function markStatus(rows, st) {
        const n = rows.reduce((a, r) => a + r.lead_ids.length, 0);
        if (!await dialog(`<h3>Mark ${fmt(n)} lead${n === 1 ? '' : 's'} as ${st}?</h3><div class="muted" style="font-size:13px;">${rows.length === 1 ? esc(rows[0].name || rows[0].mobile) + ' — ' : ''}they'll be left out of every dashboard and report.</div>`, `Mark as ${st}`, st === 'JUNK' ? 'danger' : 'primary')) return;
        try {
            const d = await api('status', {}, { lead_ids: rows.flatMap(r => r.lead_ids), status: st });
            toast(`✅ ${fmt(d.updated)} lead(s) marked ${st}.`);
            removeRows(rows);
        } catch (err) { toast('❌ ' + err.message, true); }
    }
    function removeRows(rows) {
        const keys = new Set(rows.map(r => r.key));
        S.rows = S.rows.filter(r => !keys.has(r.key));
        rows.forEach(r => { S.counts.all--; S.counts[r.platform]--; S.sel.delete(r.key); });
        render();
        try { window.parent && window.parent !== window && window.parent.postMessage({ type: 'pq-unmapped-changed' }, '*'); } catch (e) {}
    }

    /* ── bulk ── */
    function renderBulk() {
        const rows = S.rows.filter(r => S.sel.has(r.key));
        const box = $('#bulk');
        if (!rows.length) { box.classList.add('hidden'); return; }
        const plats = [...new Set(rows.map(r => r.platform))];
        box.classList.remove('hidden');
        box.innerHTML = `<b>${fmt(rows.length)} selected</b> <span class="faint">(${fmt(rows.reduce((a, r) => a + r.lead_ids.length, 0))} leads)</span>
            <button class="btn sm primary" id="bk-map" ${plats.filter(p => p !== 'unknown').length > 1 ? 'disabled title="Select Meta or Google leads, not both"' : ''}>Map to…</button>
            <button class="btn sm" id="bk-test">Mark Test</button><button class="btn sm ghost-bad" id="bk-junk">Mark Junk</button>
            <button class="btn sm" id="bk-clear">Clear</button>
            ${plats.filter(p => p !== 'unknown').length > 1 ? '<span class="faint">Meta and Google leads are mapped separately.</span>' : ''}`;
        $('#bk-clear').onclick = () => { S.sel.clear(); render(); };
        $('#bk-test').onclick = () => markStatus(rows, 'TEST');
        $('#bk-junk').onclick = () => markStatus(rows, 'JUNK');
        $('#bk-map').onclick = () => bulkMap(rows, plats.find(p => p !== 'unknown') || '');
    }
    async function bulkMap(rows, platform) {
        const pick = { platform, c: '', g: '', a: '' };
        const body = async () => {
            if (!pick.platform) return `<label class="muted">Platform <select id="bm-p"><option value="">— choose —</option><option value="meta">Meta</option><option value="google">Google</option></select></label>`;
            const camps = await structure(pick.platform);
            const c = camps.find(x => x.id === pick.c), g = c && c.groups.find(x => x.id === pick.g);
            return `<div style="display:grid;gap:8px;">
                ${platform ? '' : `<label class="muted">Platform <select id="bm-p"><option value="meta" ${pick.platform === 'meta' ? 'selected' : ''}>Meta</option><option value="google" ${pick.platform === 'google' ? 'selected' : ''}>Google</option></select></label>`}
                <select id="bm-c">${campaignOptions(camps, pick.c)}</select>
                <select id="bm-g" ${c ? '' : 'disabled'}><option value="">— ${pick.platform === 'meta' ? 'ad set' : 'ad group'} (optional) —</option>${c ? c.groups.map(x => `<option value="${esc(x.id)}" ${x.id === pick.g ? 'selected' : ''}>${esc(x.name)}</option>`).join('') : ''}</select>
                <select id="bm-a" ${g ? '' : 'disabled'}><option value="">— ad (optional) —</option>${g ? g.ads.map(x => `<option value="${esc(x.id)}" ${x.id === pick.a ? 'selected' : ''}>${esc(x.name)}</option>`).join('') : ''}</select></div>`;
        };
        const n = rows.reduce((a, r) => a + r.lead_ids.length, 0);
        const o = document.createElement('div');
        o.className = 'overlay';
        const paint = async () => {
            o.innerHTML = `<div class="dialog"><h3>Map ${fmt(n)} lead${n === 1 ? '' : 's'}${pick.platform ? ' (' + LABEL[pick.platform] + ')' : ''}</h3>
                <p class="muted" style="font-size:13px;margin-top:0;">Only campaigns saved for this project are listed.</p><div id="bm-body">${await body()}</div>
                <div class="actions"><button class="btn" data-x>Cancel</button><button class="btn primary" data-ok ${pick.c ? '' : 'disabled'}>Map ${fmt(n)} lead${n === 1 ? '' : 's'}</button></div></div>`;
            const on = (id, fn) => { const el = o.querySelector(id); if (el) el.onchange = e => { fn(e.target.value); paint(); }; };
            on('#bm-p', v => Object.assign(pick, { platform: v, c: '', g: '', a: '' }));
            on('#bm-c', v => Object.assign(pick, { c: v, g: '', a: '' }));
            on('#bm-g', v => Object.assign(pick, { g: v, a: '' }));
            on('#bm-a', v => { pick.a = v; });
            o.querySelector('[data-x]').onclick = () => o.remove();
            o.querySelector('[data-ok]').onclick = async () => { o.remove(); await saveMap(rows, pick); };
        };
        document.body.appendChild(o);
        paint();
    }

    /* ── export / import ── */
    const csvQ = v => `"${String(v ?? '').replace(/"/g, '""')}"`;
    function download(name, text) {
        const a = document.createElement('a');
        a.href = URL.createObjectURL(new Blob(['﻿' + text], { type: 'text/csv' }));
        a.download = name;
        a.click();
    }
    $('#b-export').addEventListener('click', () => {
        const rows = visible();
        const head = ['Lead date', 'Name', 'Mobile', 'Email', 'Platform', 'Source', 'leadgen_id', 'gclid', 'Why unmapped', 'Campaign on lead', 'Lead status', 'CRM', 'Leads', 'Lead IDs'];
        download(`unmapped_${S.tab}_${ymd(new Date())}.csv`, [head.map(csvQ).join(',')].concat(rows.map(r => [r.date, r.name, r.mobile_export ?? r.mobile, r.email_export ?? r.email, LABEL[r.platform], r.source, r.leadgen_id, r.gclid, r.reason.text, r.reason.campaign, r.status, r.crm ? (r.crm.state + (r.crm.reason ? ': ' + r.crm.reason : '')) : '', r.leads, r.lead_ids.join(' ')].map(csvQ).join(','))).join('\r\n'));
    });
    $('#b-template').addEventListener('click', () => {
        const rows = visible().slice(0, 3);
        download('unmapped_import_format.csv', ['mobile,leadgen_id,gclid,platform,campaign,adset_or_adgroup,ad']
            .concat(rows.length ? rows.map(r => [r.mobile_export ?? r.mobile, r.leadgen_id, r.gclid, r.platform === 'unknown' ? '' : LABEL[r.platform], '', '', ''].map(csvQ).join(',')) : ['9876543210,,,Meta,Campaign name as saved,Ad set name,Ad name']).join('\r\n'));
    });
    function parseCsv(text) {
        text = text.replace(/^﻿/, '');
        const delim = [',', ';', '\t'].map(d => [d, (text.split('\n')[0].match(new RegExp(d === '\t' ? '\t' : '\\' + d, 'g')) || []).length]).sort((a, b) => b[1] - a[1])[0][0];
        const rows = []; let row = [], cur = '', q = false;
        for (let i = 0; i < text.length; i++) {
            const ch = text[i];
            if (q) { if (ch === '"') { if (text[i + 1] === '"') { cur += '"'; i++; } else q = false; } else cur += ch; }
            else if (ch === '"') q = true;
            else if (ch === delim) { row.push(cur); cur = ''; }
            else if (ch === '\n') { row.push(cur.replace(/\r$/, '')); rows.push(row); row = []; cur = ''; }
            else cur += ch;
        }
        if (cur !== '' || row.length) { row.push(cur.replace(/\r$/, '')); rows.push(row); }
        return rows.filter(r => r.some(c => c.trim() !== ''));
    }
    $('#f-import').addEventListener('change', async e => {
        const f = e.target.files[0];
        e.target.value = '';
        if (!f) return;
        const raw = parseCsv(await f.text());
        if (raw.length < 2) return toast('❌ The file has no data rows.', true);
        const norm = h => h.toLowerCase().replace(/[^a-z]/g, '');
        const head = raw[0].map(norm);
        const col = names => head.findIndex(h => names.includes(h));
        const ix = { mobile: col(['mobile', 'phone', 'mobilenumber']), leadgen_id: col(['leadgenid', 'leadgen']), gclid: col(['gclid']), platform: col(['platform', 'source']),
                     campaign: col(['campaign', 'campaignname']), adgroup: col(['adsetoradgroup', 'adset', 'adgroup', 'adsetname', 'adgroupname']), ad: col(['ad', 'adname']) };
        if (ix.campaign < 0 || (ix.mobile < 0 && ix.leadgen_id < 0 && ix.gclid < 0)) return toast('❌ Needs a “campaign” column and a “mobile”, “leadgen_id” or “gclid” column (see Import format).', true);
        const rows = raw.slice(1).map(r => { const o = {}; Object.entries(ix).forEach(([k, i]) => { if (i >= 0) o[k] = (r[i] || '').trim(); }); return o; });
        try {
            const d = await api('import', {}, { rows, write: false });
            const bad = d.rows.filter(r => !r.ok);
            const o = await dialog(`<h3>Import ${esc(f.name)}</h3>
                <p class="muted" style="font-size:13px;">${fmt(d.ok)} row(s) will map <b>${fmt(d.leads)}</b> lead(s). ${bad.length ? `${fmt(bad.length)} row(s) can't be used:` : 'Every row matched.'}</p>
                ${bad.length ? `<div class="tbl-wrap" style="max-height:260px;"><table><thead><tr><th>Row</th><th>ID</th><th>Problem</th></tr></thead><tbody>${bad.slice(0, 200).map(r => `<tr><td class="mono">${r.row}</td><td class="mono">${esc(r.id)}</td><td>${esc(r.message)}</td></tr>`).join('')}</tbody></table></div>` : ''}`,
                d.ok ? `Map ${fmt(d.leads)} lead${d.leads === 1 ? '' : 's'}` : null);
            if (!o) return;
            const w = await api('import', {}, { rows, write: true });
            toast(`✅ ${fmt(w.written)} lead(s) mapped from ${f.name}.`);
            load();
        } catch (err) { toast('❌ ' + err.message, true); }
    });

    window.addEventListener('storage', e => { if (e.key === 'pq-unmapped-tab' && LABEL[e.newValue]) { S.tab = e.newValue; render(); } });
    load();
})();
</script>
</body>
</html>
