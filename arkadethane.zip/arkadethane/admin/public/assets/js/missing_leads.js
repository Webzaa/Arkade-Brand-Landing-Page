/**
 * missing_leads.js — "Add missing leads" editor for Upload Lead Status (status_upload.php).
 *
 * Rows of the CRM feedback file that are not in the lead table: shown in an editable table before anything is saved.
 *   - edit any field, untick rows to leave them out, set one campaign source for all rows
 *   - Check rows: the server says, row by row, what would be added / skipped (already in the database, repeated) / wrong
 *   - Several lead databases: every row has its own Database (guessed from its campaign; change it per row, or set one
 *     for all rows at the top); Check / Add run database by database
 *   - Add: inserted as new leads into each row's database (logged; Undo deletes them again)
 *   - Download CSV: the same table as a file, to add later with "Import a saved missing-leads file" (same columns)
 *
 *   PQMissing.open(data, { api, onDone })
 *     data = {rows, file_name, databases, default_db, sources, status_values, sitevisit_values, can_insert}  (status_upload_api.php)
 *     api  = (action, body) => Promise  — the page's api() (JSON POST)
 */
(function () {
    'use strict';
    const F = [
        ['name', 'Name', 'text', 140], ['mobile', 'Mobile', 'tel', 115], ['email', 'Email', 'email', 170],
        ['campaignsource', 'Campaign source', 'source', 140], ['campaign', 'Campaign', 'text', 170],
        ['lead_status', 'Lead status', 'status', 150], ['sitevisit_status', 'Site visit', 'sitevisit', 110],
        ['createddate', 'Created date', 'text', 150], ['uniqueid', 'Unique ID', 'text', 130],
    ];
    const PAGE = 100;
    const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
    const fmt = n => Number(n || 0).toLocaleString('en-IN');
    const css = `
    .ml-ov { position: fixed; inset: 0; background: rgba(2, 6, 23, .62); z-index: 60; display: flex; align-items: stretch; justify-content: center; padding: 18px; }
    .ml { background: var(--surface); border: 1px solid var(--border-strong); border-radius: 14px; width: 100%; max-width: 1500px; display: flex; flex-direction: column; min-height: 0; box-shadow: 0 20px 60px rgba(0,0,0,.45); }
    .ml-hd { padding: 16px 20px 10px; border-bottom: 1px solid var(--border); }
    .ml-hd h3 { margin: 0; font-size: 17px; display: flex; gap: 10px; align-items: center; }
    .ml-hd p { margin: 4px 0 0; color: var(--text-dim); font-size: 12.5px; }
    .ml-x { margin-left: auto; border: 0; background: none; color: var(--text-dim); font-size: 22px; cursor: pointer; line-height: 1; padding: 2px 6px; }
    .ml-ctl { display: flex; gap: 10px 14px; flex-wrap: wrap; align-items: flex-end; padding: 12px 20px; border-bottom: 1px solid var(--border); background: var(--surface-2); }
    .ml-ctl label { display: flex; flex-direction: column; gap: 4px; font-size: 11.5px; color: var(--text-dim); font-weight: 600; }
    .ml-ctl select, .ml-ctl input { background: var(--surface); border: 1px solid var(--border-strong); border-radius: 8px; padding: 7px 10px; color: var(--text); font: inherit; font-size: 13px; min-width: 0; }
    .ml-ctl .grow { flex: 1 1 auto; }
    .ml-body { flex: 1 1 auto; overflow: auto; min-height: 120px; }
    .ml table { width: 100%; border-collapse: collapse; font-size: 12.5px; }
    .ml th { position: sticky; top: 0; z-index: 1; background: var(--surface-2); color: var(--text-dim); font-size: 11px; text-transform: uppercase; letter-spacing: .04em; text-align: left; padding: 8px 6px; border-bottom: 1px solid var(--border); white-space: nowrap; }
    .ml td { padding: 4px 6px; border-bottom: 1px solid var(--border); vertical-align: top; }
    .ml td input[type=text], .ml td select { width: 100%; background: transparent; border: 1px solid transparent; border-radius: 6px; padding: 5px 6px; color: var(--text); font: inherit; font-size: 12.5px; min-width: 0; }
    .ml td input[type=text]:hover, .ml td select:hover { border-color: var(--border-strong); }
    .ml td input[type=text]:focus, .ml td select:focus { border-color: var(--accent); background: var(--surface-2); outline: none; }
    .ml td input.bad { border-color: var(--bad); background: var(--bad-soft); }
    .ml tr.off td { opacity: .45; }
    .ml .rn { color: var(--text-faint); font-family: 'JetBrains Mono', monospace; font-size: 11.5px; padding-top: 10px; text-align: right; }
    .ml .res { min-width: 130px; max-width: 220px; font-size: 11.5px; padding-top: 8px; }
    .ml .del { border: 0; background: none; color: var(--text-faint); cursor: pointer; font-size: 15px; padding: 6px; }
    .ml .del:hover { color: var(--bad); }
    .ml-ft { display: flex; gap: 10px; align-items: center; flex-wrap: wrap; padding: 12px 20px; border-top: 1px solid var(--border); }
    .ml-ft .sum { flex: 1 1 auto; font-size: 12.5px; color: var(--text-dim); }
    .ml-pg { display: flex; gap: 6px; align-items: center; justify-content: center; padding: 10px; font-size: 12px; color: var(--text-dim); }
    .ml .chkc { width: 30px; text-align: center; padding-top: 9px; }
    .ml .chkc input { accent-color: var(--accent); width: 15px; height: 15px; }
    @media (max-width: 700px) { .ml-ov { padding: 0; } .ml { border-radius: 0; } .ml-ctl, .ml-hd, .ml-ft { padding-left: 14px; padding-right: 14px; } }`;

    function addCss() {
        if (document.getElementById('ml-css')) return;
        const s = document.createElement('style'); s.id = 'ml-css'; s.textContent = css; document.head.appendChild(s);
    }

    /** CSV of the rows (the format "Import a saved missing-leads file" reads back). */
    function toCsv(rows, dbLabels) {
        const extraKeys = [...new Set(rows.flatMap(r => Object.keys(r.extra || {})))];
        const q = v => `"${String(v ?? '').replace(/"/g, '""')}"`;
        const withDb = dbLabels && Object.keys(dbLabels).length > 1;
        const head = ['Row'].concat(withDb ? ['Database'] : [], F.map(f => f[1]), extraKeys.map(k => k.replace(/_/g, ' ')));
        return '﻿' + [head.map(q).join(',')].concat(rows.map(r => [r.row].concat(withDb ? [dbLabels[r.db] || r.db || ''] : [], F.map(f => r[f[0]]), extraKeys.map(k => (r.extra || {})[k])).map(q).join(','))).join('\r\n');
    }
    function download(name, text) {
        const a = document.createElement('a');
        a.href = URL.createObjectURL(new Blob([text], { type: 'text/csv;charset=utf-8' }));
        a.download = name; document.body.appendChild(a); a.click();
        setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 500);
    }

    function open(data, opt) {
        addCss();
        opt = opt || {};
        const api = opt.api;
        const st = { page: 0, q: '', dirty: false, done: null, db: data.default_db || (data.databases && data.databases[0] && data.databases[0].key) || '' };
        const DBS = data.databases || [];
        const multi = DBS.length > 1;
        const dbLabel = Object.fromEntries(DBS.map(d => [d.key, d.label]));
        const rows = (data.rows || []).map(r => Object.assign({ _sel: true, _res: null }, r, { db: dbLabel[r.db] ? r.db : st.db }));
        const sources = data.sources || [];
        const canInsert = data.can_insert !== false;
        const fileBase = String(data.file_name || 'feedback').replace(/\.\w+$/, '');

        const ov = document.createElement('div');
        ov.className = 'ml-ov';
        ov.innerHTML = `<div class="ml" role="dialog" aria-modal="true" aria-labelledby="ml-h">
            <div class="ml-hd"><h3 id="ml-h">Add missing leads <span class="pill info" id="ml-cnt"></span><button class="ml-x" type="button" title="Close" aria-label="Close">×</button></h3>
                <p>${esc(data.file_name || '')} — these rows are <b>not in the lead table</b>. Check and edit them, then add them as new leads.
                Not now? <b>Download CSV</b> and add them any time from Upload Lead Status → “Import a saved missing-leads file”.</p></div>
            <div class="ml-ctl">
                ${multi ? `<label>Database for the rows
                    <span style="display:flex;gap:6px;"><select id="ml-db">${DBS.map(d => `<option value="${esc(d.key)}" ${d.key === st.db ? 'selected' : ''}>${esc(d.label)}</option>`).join('')}</select>
                    <button class="btn" type="button" id="ml-db-all" title="Every ticked row goes to this database">Set for all rows</button></span></label>` : ''}
                <label>Campaign source for the rows
                    <span style="display:flex;gap:6px;"><select id="ml-src"><option value="">— choose —</option>${sources.map(s => `<option>${esc(s)}</option>`).join('')}<option value="__other">Other…</option></select>
                    <input id="ml-src-other" type="text" placeholder="Type a source" maxlength="45" hidden style="width:150px;"></span></label>
                <label>&nbsp;<span style="display:flex;gap:6px;"><button class="btn" type="button" id="ml-src-all">Set for all rows</button><button class="btn" type="button" id="ml-src-empty">Only where empty</button></span></label>
                <span class="grow"></span>
                <label>Search<input id="ml-q" type="text" placeholder="Name, mobile, email…" style="width:200px;"></label>
            </div>
            <div class="ml-body"><table><thead><tr><th class="chkc"><input type="checkbox" id="ml-all" checked aria-label="Select all rows"></th><th>Row</th><th>Check</th>${multi ? '<th style="min-width:175px">Database</th>' : ''}${F.map(f => `<th style="min-width:${f[3]}px">${f[1]}</th>`).join('')}<th></th></tr></thead><tbody id="ml-rows"></tbody></table>
                <div class="ml-pg" id="ml-pg"></div></div>
            <div class="ml-ft"><span class="sum" id="ml-sum"></span>
                <button class="btn" type="button" id="ml-dl">⤓ Download CSV</button>
                ${canInsert ? `<button class="btn" type="button" id="ml-check">Check rows</button><button class="btn primary" type="button" id="ml-add">Add leads</button>` : `<span class="faint">Your role can download them; adding needs “Add missing leads” (Users &amp; Roles → Upload Lead Status).</span>`}</div>
        </div>`;
        document.body.appendChild(ov);
        const $ = s => ov.querySelector(s);
        const prevFocus = document.activeElement;

        const visible = () => {
            const q = st.q.toLowerCase();
            return rows.map((r, i) => [r, i]).filter(([r]) => !q || F.some(f => String(r[f[0]] || '').toLowerCase().includes(q)) || String(r.row).includes(q));
        };
        const selected = () => rows.filter(r => r._sel);
        function cell(r, i, f) {
            const [k, , type] = f, v = r[k] ?? '';
            const attrs = `data-i="${i}" data-k="${k}" aria-label="${esc(f[1])} row ${esc(r.row)}"`;
            if (type === 'status' || type === 'sitevisit') {
                const vals = [''].concat(type === 'status' ? (data.status_values || []) : (data.sitevisit_values || []));
                if (v && !vals.includes(v)) vals.push(v);
                return `<select ${attrs}>${vals.map(x => `<option value="${esc(x)}" ${x === v ? 'selected' : ''}>${x === '' ? '—' : esc(x)}</option>`).join('')}</select>`;
            }
            if (type === 'source') return `<input type="text" ${attrs} value="${esc(v)}" list="ml-src-list" maxlength="45" class="${v ? '' : 'bad'}">`;
            const bad = (k === 'mobile' || k === 'email') && !r.mobile && !r.email;
            return `<input type="text" ${attrs} value="${esc(v)}" class="${bad ? 'bad' : ''}" ${k === 'createddate' ? 'placeholder="today"' : ''}>`;
        }
        function resCell(r) {
            const x = r._res;
            if (!x) return '';
            const cls = { add: 'good', added: 'good', skip: 'warn', error: 'bad' }[x.state] || 'dim';
            const lbl = { add: 'Will be added', added: 'Added', skip: 'Skipped', error: 'Fix' }[x.state] || x.state;
            return `<span class="pill ${cls}">${lbl}</span>${x.reason ? `<div class="faint" style="margin-top:3px;">${esc(x.reason)}</div>` : ''}`;
        }
        function render() {
            const list = visible();
            const pages = Math.max(1, Math.ceil(list.length / PAGE));
            st.page = Math.min(st.page, pages - 1);
            const shown = list.slice(st.page * PAGE, st.page * PAGE + PAGE);
            $('#ml-rows').innerHTML = shown.map(([r, i]) => `<tr class="${r._sel ? '' : 'off'}">
                <td class="chkc"><input type="checkbox" data-sel="${i}" ${r._sel ? 'checked' : ''} ${st.done ? 'disabled' : ''} aria-label="Add row ${esc(r.row)}"></td>
                <td class="rn">${esc(r.row)}</td><td class="res">${resCell(r) || '<span class="faint">—</span>'}</td>${multi ? `<td><select data-i="${i}" data-k="db" aria-label="Database row ${esc(r.row)}">${DBS.map(d => `<option value="${esc(d.key)}" ${d.key === r.db ? 'selected' : ''}>${esc(d.label)}</option>`).join('')}</select></td>` : ''}${F.map(f => `<td>${cell(r, i, f)}</td>`).join('')}
                <td><button class="del" type="button" data-del="${i}" title="Remove this row from the list" ${st.done ? 'disabled' : ''}>🗑</button></td></tr>`).join('')
                || `<tr><td colspan="${F.length + 4 + (multi ? 1 : 0)}" class="muted" style="padding:20px;">${rows.length ? 'No row matches the search.' : 'No rows left.'}</td></tr>`;
            $('#ml-pg').innerHTML = pages > 1 ? `<button class="btn" type="button" data-pg="-1" ${st.page ? '' : 'disabled'}>‹</button> Page ${st.page + 1} of ${pages} · ${fmt(list.length)} rows <button class="btn" type="button" data-pg="1" ${st.page < pages - 1 ? '' : 'disabled'}>›</button>` : '';
            if (st.done) ov.querySelectorAll('#ml-rows input[type=text], #ml-rows select').forEach(x => { x.disabled = true; });
            sum();
        }
        function sum() {
            const n = selected().length;
            $('#ml-cnt').textContent = fmt(rows.length) + ' row' + (rows.length === 1 ? '' : 's');
            const noContact = selected().filter(r => !r.mobile && !r.email).length, noSrc = selected().filter(r => !String(r.campaignsource || '').trim()).length;
            $('#ml-sum').innerHTML = st.done ? st.done
                : `<b>${fmt(n)}</b> of ${fmt(rows.length)} selected${multi ? ' (' + DBS.map(d => [d, selected().filter(r => r.db === d.key).length]).filter(x => x[1]).map(([d, c]) => `${esc(d.label)}: ${fmt(c)}`).join(', ') + ')' : ''}${noSrc ? ` · <span style="color:var(--bad)">${fmt(noSrc)} without a campaign source</span>` : ''}${noContact ? ` · <span style="color:var(--bad)">${fmt(noContact)} without mobile / email</span>` : ''}`;
            if ($('#ml-add')) { $('#ml-add').disabled = !n || !!st.done; $('#ml-add').textContent = st.done ? 'Added' : `Add ${fmt(n)} lead${n === 1 ? '' : 's'}`; }
            if ($('#ml-check')) $('#ml-check').disabled = !n || !!st.done;
            $('#ml-all').checked = rows.length > 0 && rows.every(r => r._sel);
        }
        // datalist for the campaign source cells
        const dl = document.createElement('datalist'); dl.id = 'ml-src-list';
        dl.innerHTML = sources.map(s => `<option value="${esc(s)}">`).join(''); ov.appendChild(dl);

        // edits
        ov.addEventListener('input', e => {
            const t = e.target;
            if (t.dataset && t.dataset.k != null && t.dataset.i != null) {
                const r = rows[+t.dataset.i]; r[t.dataset.k] = t.value; r._res = null; st.dirty = true;
                if (t.dataset.k === 'campaignsource') t.classList.toggle('bad', !t.value.trim());
                if (t.dataset.k === 'mobile' || t.dataset.k === 'email') {
                    t.closest('tr').querySelectorAll('[data-k=mobile],[data-k=email]').forEach(x => x.classList.toggle('bad', !r.mobile && !r.email));
                }
                sum();
            }
            if (t.id === 'ml-q') { st.q = t.value.trim(); st.page = 0; render(); }
            if (t.id === 'ml-src-other') st.dirty = true;
        });
        ov.addEventListener('change', e => {
            const t = e.target;
            if (t.dataset && t.dataset.k && t.tagName === 'SELECT') { rows[+t.dataset.i][t.dataset.k] = t.value; rows[+t.dataset.i]._res = null; st.dirty = true; }
            if (t.dataset && t.dataset.sel != null) { rows[+t.dataset.sel]._sel = t.checked; t.closest('tr').classList.toggle('off', !t.checked); sum(); }
            if (t.id === 'ml-all') { visible().forEach(([r]) => { r._sel = t.checked; }); render(); }
            if (t.id === 'ml-src') { $('#ml-src-other').hidden = t.value !== '__other'; if (t.value === '__other') $('#ml-src-other').focus(); }
            if (t.id === 'ml-db') st.db = t.value;
            if (t.dataset && t.dataset.k === 'db') sum();
        });
        ov.addEventListener('click', e => {
            const t = e.target.closest('button'); if (!t) return;
            if (t.dataset.del != null) { rows.splice(+t.dataset.del, 1); st.dirty = true; render(); return; }
            if (t.dataset.pg) { st.page += +t.dataset.pg; render(); $('.ml-body').scrollTop = 0; return; }
        });
        const srcValue = () => $('#ml-src').value === '__other' ? $('#ml-src-other').value.trim() : $('#ml-src').value;
        const applySrc = onlyEmpty => {
            const v = srcValue();
            if (!v) { $('#ml-src').focus(); return; }
            let n = 0;
            rows.forEach(r => { if (r._sel && (!onlyEmpty || !String(r.campaignsource || '').trim())) { r.campaignsource = v; r._res = null; n++; } });
            st.dirty = true; render();
            $('#ml-sum').insertAdjacentHTML('beforeend', ` · campaign source “${esc(v)}” set on ${fmt(n)} row${n === 1 ? '' : 's'}`);
        };
        $('#ml-src-all').onclick = () => applySrc(false);
        if ($('#ml-db-all')) $('#ml-db-all').onclick = () => {
            let n = 0;
            rows.forEach(r => { if (r._sel) { r.db = st.db; r._res = null; n++; } });
            st.dirty = true; render();
            $('#ml-sum').insertAdjacentHTML('beforeend', ` · database “${esc(dbLabel[st.db])}” set on ${fmt(n)} row${n === 1 ? '' : 's'}`);
        };
        $('#ml-src-empty').onclick = () => applySrc(true);
        $('#ml-dl').onclick = () => {
            const list = selected();
            download(`missing_leads_${fileBase}_${new Date().toISOString().slice(0, 10)}.csv`, toCsv(list.length ? list : rows, dbLabel));
            st.dirty = false;
        };
        const payload = list => list.map(r => {
            const o = { row: r.row, extra: r.extra || {} };
            F.forEach(f => { o[f[0]] = String(r[f[0]] ?? '').trim(); });
            return o;
        });
        /** selected rows by database: [[key, rows], …] */
        const groups = () => {
            const g = {};
            selected().forEach(r => { (g[r.db || st.db] = g[r.db || st.db] || []).push(r); });
            return Object.entries(g);
        };
        /** check / add every database; results per database → rows */
        async function run(adding) {
            const out = { to_add: 0, added: 0, skipped: 0, errors: 0, per: [], imports: [] };
            for (const [db, list] of groups()) {
                const r = await api('missing_insert', { target_db: db, rows: payload(list), file_name: data.file_name || '', check: !adding });
                const byRow = {};
                (r.errors || []).forEach(x => { byRow[x.row] = { state: 'error', reason: x.reason }; });
                (r.skipped || []).forEach(x => { byRow[x.row] = { state: 'skip', reason: x.reason }; });
                list.forEach(x => { x._res = byRow[x.row] || { state: adding ? 'added' : 'add' }; });
                out.to_add += r.to_add; out.added += r.added || 0; out.skipped += r.skipped.length; out.errors += r.errors.length;
                out.per.push({ db, label: r.db_label, to_add: r.to_add, added: r.added || 0, skipped: r.skipped.length, errors: r.errors.length });
                if (r.import_id) out.imports.push({ db, import_id: r.import_id, added: r.added });
            }
            const firstBad = rows.findIndex(x => x._sel && x._res && x._res.state === 'error');
            if (firstBad >= 0 && !adding) st.page = Math.floor(visible().findIndex(([, i]) => i === firstBad) / PAGE) || 0;
            render();
            return out;
        }
        const perText = (o, k) => {
            const has = o.per.filter(p => p[k]);
            if (!has.length) return '';
            return o.per.length > 1 ? ' (' + has.map(p => `${esc(p.label)}: ${fmt(p[k])}`).join(', ') + ')' : ` to ${esc(has[0].label)}`;
        };
        async function check() {
            const b = $('#ml-check'), old = b.innerHTML;
            b.disabled = true; b.innerHTML = '<span class="spinner"></span>Checking…';
            try {
                const o = await run(false);
                $('#ml-sum').innerHTML = `Check: <b style="color:var(--good)">${fmt(o.to_add)} will be added</b>${perText(o, 'to_add')}${o.skipped ? ` · <b style="color:var(--warn)">${fmt(o.skipped)} skipped</b> (already in that database or repeated)` : ''}${o.errors ? ` · <b style="color:var(--bad)">${fmt(o.errors)} to fix</b>` : ''}`;
                return o;
            } catch (e) { $('#ml-sum').innerHTML = `<span style="color:var(--bad)">${esc(e.message)}</span>`; return null; }
            finally { b.innerHTML = old; b.disabled = false; }
        }
        if ($('#ml-check')) $('#ml-check').onclick = check;
        if ($('#ml-add')) $('#ml-add').onclick = async () => {
            const c = await check();
            if (!c) return;
            if (!c.to_add) { $('#ml-sum').insertAdjacentHTML('beforeend', ' — nothing to add.'); return; }
            const where = c.per.filter(p => p.to_add).map(p => `${fmt(p.to_add)} to ${p.label}`).join('\n');
            if (!window.confirm(`Add ${c.to_add} new lead${c.to_add === 1 ? '' : 's'}?\n\n${where}` + (c.skipped || c.errors ? `\n\n${c.skipped + c.errors} row(s) are left out (see “Check”).` : '') + '\n\nThey are saved as already in the CRM, so CRM Push does not send them again. You can undo this.')) return;
            const b = $('#ml-add'), old = b.innerHTML;
            b.disabled = true; b.innerHTML = '<span class="spinner"></span>Adding…';
            try {
                const o = await run(true);
                st.done = `✅ <b>${fmt(o.added)} lead${o.added === 1 ? '' : 's'} added</b>${perText(o, 'added')}${o.skipped ? ` · ${fmt(o.skipped)} skipped` : ''}${o.errors ? ` · ${fmt(o.errors)} not added (fix and add them again)` : ''}. `
                    + (o.imports.length ? `<button class="btn" type="button" id="ml-undo" style="padding:4px 10px;font-size:12px;">Undo</button>` : '');
                st.dirty = false;
                render();
                const u = $('#ml-undo');
                if (u) u.onclick = async () => {
                    if (!window.confirm(`Delete the ${o.added} lead(s) just added?`)) return;
                    try {
                        let n = 0;
                        for (const im of o.imports) n += (await api('missing_undo', { target_db: im.db, import_id: im.import_id })).deleted;
                        st.done = `Undone — ${fmt(n)} lead(s) deleted.`;
                        rows.forEach(z => { if (z._res && z._res.state === 'added') z._res = { state: 'skip', reason: 'undone' }; });
                        render();
                        if (opt.onDone) opt.onDone(o);
                    } catch (e) { $('#ml-sum').insertAdjacentHTML('beforeend', ` <span style="color:var(--bad)">${esc(e.message)}</span>`); }
                };
                b.textContent = 'Added'; b.disabled = true;
                if (opt.onDone) opt.onDone(o);
            } catch (e) {
                // a database that failed is rolled back on its own; others may have been added — show what happened
                $('#ml-sum').innerHTML = `<span style="color:var(--bad)">${esc(e.message)}</span> — rows marked “Added” were saved; check “Missing leads added”.`;
                b.innerHTML = old; b.disabled = false;
                if (opt.onDone) opt.onDone(null);
            }
        };
        function close() {
            if (st.dirty && !st.done && !window.confirm('Close without adding? Your edits are lost (use “Download CSV” to keep them).')) return;
            ov.remove(); document.removeEventListener('keydown', key, true);
            try { prevFocus && prevFocus.focus(); } catch (e) {}
            if (opt.onClose) opt.onClose();
        }
        const key = e => { if (e.key === 'Escape' && !e.target.closest('input,select')) { e.stopPropagation(); close(); } };
        document.addEventListener('keydown', key, true);
        $('.ml-x').onclick = close;
        render();
        setTimeout(() => { const s = $('#ml-src'); if (s) s.focus(); }, 30);
    }
    window.PQMissing = { open, toCsv };
})();
