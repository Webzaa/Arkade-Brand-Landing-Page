/**
 * date_presets.js — "Last 1 year" and "All time" for every date filter.
 *
 *   PQDates.range('last_1y')   → {since, until}  the last 12 months, till today
 *   PQDates.range('all_time')  → {since, until}  from the project's first lead (window.PQ_ALL_SINCE) till today
 *   PQDates.range(other)       → null            (the page's own presets handle the rest)
 *
 * window.PQ_ALL_SINCE comes from pqDatesTag() (app/Core/access.php): the oldest lead's date, at most 37 months less
 * two days back (Meta keeps ad results that long), or PROJECT_START_DATE from config.php.
 * Dates are local (YYYY-MM-DD), so the pages send them as since / until — never as a Meta / Google preset name.
 */
(function () {
    'use strict';
    const ymd = d => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
    const today = () => { const n = new Date(); return new Date(n.getFullYear(), n.getMonth(), n.getDate()); };
    function range(p) {
        const t = today();
        if (p === 'last_1y') {
            const s = new Date(t); s.setFullYear(s.getFullYear() - 1); s.setDate(s.getDate() + 1);
            return { since: ymd(s), until: ymd(t) };
        }
        if (p === 'all_time') {
            const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(window.PQ_ALL_SINCE || '');
            let s = m ? new Date(+m[1], +m[2] - 1, +m[3]) : (() => { const x = new Date(t); x.setFullYear(x.getFullYear() - 1); return x; })();
            if (s > t) s = t;
            return { since: ymd(s), until: ymd(t) };
        }
        return null;
    }
    const LABELS = { last_1y: 'Last 1 Year', all_time: 'All Time' };
    window.PQDates = { range, ymd, LABELS, ids: Object.keys(LABELS) };
})();
