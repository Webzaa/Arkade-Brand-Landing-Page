/**
 * metric_guard.js — hides metrics a role may not see (Users & Roles → Roles → "Hide numbers").
 *
 *   window.PQ_HIDE_METRICS = ['qualified', 'cpql', 'sitevisits', 'cpsv']   (set by pqMetricGuardTag() in PHP)
 *
 * - pqMetricHidden(label) → true when a card / funnel stage / column with that label must not be shown
 *   (the dashboards call it when they build KPI cards and funnels).
 * - Table columns whose header matches are hidden automatically, also after the table is re-drawn.
 * - Any element with data-pq-metric="qualified|cpql|sitevisits|cpsv" is hidden.
 * - KPI tiles (.kpi / .tile / .stat) whose label matches are hidden.
 */
(function () {
    'use strict';
    var hide = (window.PQ_HIDE_METRICS || []).filter(function (k) { return ['qualified', 'cpql', 'sitevisits', 'cpsv'].indexOf(k) >= 0; });
    var PATTERNS = {
        qualified: /^(qualified( leads?)?|ql|qualified rate|in[- ]?qualified|quality leads?|mql)$/,
        cpql: /^(cpql|cost per qualified lead|cost per ql|cpql \(₹\)|cpql \(rs\.?\))$/,
        sitevisits: /^(site ?visits?|site visit leads|sv|walk-?ins?|walk-?ins? \/ site visits|sv done|site visits done)$/,
        cpsv: /^(cpsv|cost per site visit|cost per sv|cpsv \(₹\)|cpsv \(rs\.?\)|cpw|cost per walk-?in)$/
    };
    function norm(s) {
        return String(s || '').replace(/\s+/g, ' ').replace(/[▲▼↑↓⇅↕*]/g, '').trim().toLowerCase();
    }
    function metricOf(label) {
        var n = norm(label);
        for (var k in PATTERNS) { if (PATTERNS[k].test(n)) return k; }
        return null;
    }
    window.pqMetricHidden = function (label) {
        if (!hide.length) return false;
        var m = metricOf(label);
        return m !== null && hide.indexOf(m) >= 0;
    };
    window.pqMetricHiddenKey = function (key) { return hide.indexOf(key) >= 0; };
    if (!hide.length) return;

    var css = hide.map(function (k) { return '[data-pq-metric~="' + k + '"]'; }).join(',') + '{display:none!important}' +
        '.pq-mg-hide{display:none!important}';
    var st = document.createElement('style');
    st.textContent = css;
    (document.head || document.documentElement).appendChild(st);

    function headerCells(table) {
        var head = table.tHead && table.tHead.rows.length ? table.tHead.rows[table.tHead.rows.length - 1] : null;
        if (!head) {
            var first = table.rows[0];
            if (first && first.querySelector('th')) head = first;
        }
        return head;
    }
    function scanTable(table) {
        var head = headerCells(table);
        if (!head) return;
        var cols = [], idx = 0;
        for (var i = 0; i < head.cells.length; i++) {
            var c = head.cells[i], span = c.colSpan || 1;
            if (span === 1 && window.pqMetricHidden(c.getAttribute('data-label') || c.textContent)) cols.push(idx);
            idx += span;
        }
        if (!cols.length) return;
        for (var r = 0; r < table.rows.length; r++) {
            var row = table.rows[r], pos = 0;
            for (var j = 0; j < row.cells.length; j++) {
                var cell = row.cells[j], sp = cell.colSpan || 1;
                if (sp === 1 && cols.indexOf(pos) >= 0) cell.classList.add('pq-mg-hide');
                pos += sp;
            }
        }
    }
    function scanTiles(root) {
        var tiles = root.querySelectorAll('.kpi, .tile, .stat, .kpi-card');
        for (var i = 0; i < tiles.length; i++) {
            var t = tiles[i];
            var lbl = t.querySelector('.kpi-label, small, .label, .lbl, div');
            if (lbl && window.pqMetricHidden(lbl.textContent)) t.classList.add('pq-mg-hide');
        }
    }
    var queued = false;
    function scan() {
        queued = false;
        var tables = document.querySelectorAll('table');
        for (var i = 0; i < tables.length; i++) scanTable(tables[i]);
        scanTiles(document);
    }
    function queue() {
        if (queued) return;
        queued = true;
        (window.requestAnimationFrame || setTimeout)(scan, 16);
    }
    /* Excel exports (SheetJS): drop hidden columns right before a sheet is built. Patched on the first click,
       because the Excel library is loaded after this script. */
    function hiddenCols(row) {
        var out = [];
        for (var i = 0; i < row.length; i++) {
            var v = row[i];
            if (typeof v === 'string' && window.pqMetricHidden(v.replace(/\(.*?\)|Δ|%|₹/g, '').trim())) out.push(i);
        }
        return out;
    }
    function filterAoa(aoa) {
        if (!Array.isArray(aoa)) return aoa;
        for (var r = 0; r < Math.min(aoa.length, 12); r++) {
            var row = aoa[r];
            if (!Array.isArray(row) || row.length < 3) continue;
            var cols = hiddenCols(row);
            if (!cols.length) continue;
            var width = row.length;
            for (var k = r; k < aoa.length; k++) {            // header row and everything below it
                var x = aoa[k];
                if (!Array.isArray(x) || x.length < Math.min(width, 3)) continue;
                for (var c = cols.length - 1; c >= 0; c--) if (cols[c] < x.length) x.splice(cols[c], 1);
            }
            return aoa;
        }
        return aoa;
    }
    function filterJson(list) {
        if (!Array.isArray(list)) return list;
        list.forEach(function (o) {
            if (o && typeof o === 'object') Object.keys(o).forEach(function (k) {
                if (window.pqMetricHidden(k.replace(/\(.*?\)|Δ|%|₹/g, '').trim())) delete o[k];
            });
        });
        return list;
    }
    function patchXlsx() {
        var X = window.XLSX;
        if (!X || !X.utils || X.utils.__pqPatched) return;
        var aoa = X.utils.aoa_to_sheet, json = X.utils.json_to_sheet;
        if (aoa) X.utils.aoa_to_sheet = function (data) { return aoa.apply(this, [filterAoa(data)].concat([].slice.call(arguments, 1))); };
        if (json) X.utils.json_to_sheet = function (data) { return json.apply(this, [filterJson(data)].concat([].slice.call(arguments, 1))); };
        X.utils.__pqPatched = true;
    }
    window.pqFilterAoa = filterAoa;
    document.addEventListener('click', patchXlsx, true);
    window.addEventListener('load', patchXlsx);

    function start() {
        scan();
        new MutationObserver(queue).observe(document.body, { childList: true, subtree: true });
    }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start);
    else start();
})();
