/**
 * target_report.js — "Target vs Achieved" card, the same on every dashboard (All Platforms, Meta, Google, Taboola,
 * manual platforms). Data: targets_api.php?action=report (app/Ads/targets.php). Rows the role may not see
 * (Users & Roles → Hide numbers) are left out by the server. Hidden when the role has no Targets permission.
 *
 *   const r = PQTargets.mount(el, { api: '../targets_api.php', platform: 'meta' })     // fixed platform
 *   const r = PQTargets.mount(el, { api: 'targets_api.php', platform: 'overall', pick: true })  // with a platform picker
 *   r.update({ since: '2026-10-01', until: '2026-10-18' })                              // call when the dates change
 */
(function () {
    'use strict';
    const LS = 'pq-targets-view';
    const css = `
    .pqt { background: var(--pq-surface, var(--surface, #fff)); border: 1px solid var(--pq-border, var(--border, #e2e8f0)); border-radius: 14px;
           padding: 16px 18px; margin: 0 0 20px; color: var(--pq-text, var(--text, #0f172a)); font-family: inherit; }
    .pqt-head { display: flex; flex-wrap: wrap; gap: 10px; align-items: center; justify-content: space-between; margin-bottom: 10px; }
    .pqt-title { font-size: 15px; font-weight: 700; }
    .pqt-sub { font-size: 12px; color: var(--pq-text-dim, var(--text-faint, #64748b)); margin-top: 2px; }
    .pqt-ctl { display: flex; gap: 8px; align-items: center; flex-wrap: wrap; }
    .pqt-ctl select, .pqt-seg button { font: inherit; font-size: 12px; color: inherit; background: var(--pq-card, var(--surface-2, #f8fafc));
           border: 1px solid var(--pq-border, var(--border, #e2e8f0)); border-radius: 8px; padding: 5px 9px; cursor: pointer; }
    .pqt-seg { display: inline-flex; gap: 0; }
    .pqt-seg button { border-radius: 0; } .pqt-seg button:first-child { border-radius: 8px 0 0 8px; } .pqt-seg button:last-child { border-radius: 0 8px 8px 0; border-left: 0; }
    .pqt-seg button.on { background: var(--accent, #E8A820); color: #111; border-color: var(--accent, #E8A820); font-weight: 700; }
    .pqt-link { font-size: 12px; color: var(--accent, #B7791F); text-decoration: none; font-weight: 600; cursor: pointer; background: none; border: 0; }
    .pqt-wrap { overflow-x: auto; }
    .pqt table { width: 100%; border-collapse: collapse; font-size: 13px; min-width: 520px; }
    .pqt th { text-align: right; font-size: 11px; text-transform: uppercase; letter-spacing: .04em; color: var(--pq-text-dim, var(--text-dim, #475569));
              padding: 8px 10px; border-bottom: 1px solid var(--pq-border, var(--border, #e2e8f0)); font-weight: 600; white-space: nowrap; }
    .pqt th:first-child, .pqt td:first-child { text-align: left; }
    .pqt td { padding: 7px 10px; border-bottom: 1px solid var(--pq-line, var(--border, #eef2f7)); text-align: right; font-variant-numeric: tabular-nums; white-space: nowrap; }
    .pqt tr:last-child td { border-bottom: 0; }
    .pqt td:first-child { font-weight: 600; }
    .pqt tr.rate td:first-child { font-weight: 500; color: var(--pq-text-dim, var(--text-dim, #475569)); padding-left: 22px; }
    .pqt .ok { color: #10B981; } .pqt .near { color: #F59E0B; } .pqt .bad { color: #EF4444; }
    .pqt .dim { color: var(--pq-text-dim, var(--text-faint, #94a3b8)); }
    .pqt .tag { font-size: 10px; font-weight: 600; padding: 0 5px; border-radius: 4px; border: 1px solid var(--pq-border, var(--border, #e2e8f0)); color: var(--pq-text-dim, var(--text-faint, #94a3b8)); margin-left: 6px; vertical-align: 1px; }
    .pqt .bar { display: inline-block; width: 70px; height: 6px; border-radius: 99px; background: var(--pq-border, var(--border, #e2e8f0)); vertical-align: middle; margin-left: 8px; overflow: hidden; }
    .pqt .bar i { display: block; height: 100%; border-radius: 99px; }
    .pqt-empty { padding: 14px; font-size: 13px; color: var(--pq-text-dim, var(--text-dim, #475569)); border: 1px dashed var(--pq-border, var(--border, #e2e8f0)); border-radius: 10px; }
    .pqt-foot { font-size: 11.5px; color: var(--pq-text-dim, var(--text-faint, #94a3b8)); margin-top: 8px; }
    .pqt-load { font-size: 12.5px; color: var(--pq-text-dim, var(--text-faint, #94a3b8)); padding: 12px 0; }`;
    function addCss() {
        if (document.getElementById('pqt-css')) return;
        const s = document.createElement('style'); s.id = 'pqt-css'; s.textContent = css; document.head.appendChild(s);
    }
    const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
    const inr = (v, d = 0) => Number(v).toLocaleString('en-IN', { maximumFractionDigits: d, minimumFractionDigits: 0 });
    function fmt(v, f) {
        if (v === null || v === undefined || !isFinite(v)) return '<span class="dim">—</span>';
        if (f === 'money') return '₹' + inr(Math.round(v));
        if (f === 'pct') return inr(v, v < 10 ? 2 : 1) + '%';
        return inr(Math.round(v));
    }
    const nice = d => new Date(d + 'T00:00:00').toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' });
    function getView() { try { return localStorage.getItem(LS) || ''; } catch (e) { return ''; } }
    function setView(v) { try { localStorage.setItem(LS, v); } catch (e) {} }

    function mount(el, opt) {
        addCss();
        const st = { since: '', until: '', platform: opt.platform || 'overall', req: 0, platforms: null };
        el.innerHTML = '';
        el.className = (el.className + ' pqt').trim();
        el.hidden = true;
        async function load() {
            if (!st.since || !st.until) return;
            const id = ++st.req;
            const view = getView();
            const qs = new URLSearchParams({ action: 'report', platform: st.platform, since: st.since, until: st.until });
            if (view) qs.set('prorate', view === 'prorate' ? '1' : '0');
            if (!el.dataset.loaded) { el.hidden = false; el.innerHTML = '<div class="pqt-title">Target vs Achieved</div><div class="pqt-load">Loading…</div>'; }
            let d;
            try {
                const res = await fetch(`${opt.api}?${qs}`, { credentials: 'same-origin' });
                if (res.status === 403 || res.status === 401) { el.hidden = true; return; }    // no Targets permission
                d = await res.json();
            } catch (e) { d = { success: false, error: e.message }; }
            if (id !== st.req) return;
            el.dataset.loaded = '1';
            el.hidden = false;
            if (!d || !d.success) { el.innerHTML = `<div class="pqt-title">Target vs Achieved</div><div class="pqt-empty">${esc((d && d.error) || 'Could not load the targets.')}</div>`; return; }
            render(d);
        }
        function render(d) {
            // "October 2023 – October 2026 (37 months)" instead of every name when the dates cover many periods
            const per = d.periods.length > 3
                ? `${d.periods[0].label} – ${d.periods[d.periods.length - 1].label} (${d.periods.length} ${d.period_type}s)`
                : d.periods.map(p => p.label).join(', ');
            const share = d.periods.length === 1 && d.periods[0].days_in < d.periods[0].days ? ` (${d.periods[0].days_in} of ${d.periods[0].days} days)` : '';
            const editLink = d.can_edit ? `<button class="pqt-link" data-edit>Edit targets →</button>` : '';
            const picker = opt.pick && opt.platforms ? `<select data-pf>${Object.entries(opt.platforms).map(([k, n]) => `<option value="${esc(k)}" ${k === st.platform ? 'selected' : ''}>${esc(n)}</option>`).join('')}</select>` : '';
            const head = `<div class="pqt-head"><div><div class="pqt-title">Target vs Achieved · ${esc(d.platform_name)}</div>
                <div class="pqt-sub">${nice(d.since)} – ${nice(d.until)} · targets: ${esc(per)}${esc(share)}</div></div>
                <div class="pqt-ctl">${picker}<span class="pqt-seg"><button data-v="full" class="${d.prorate ? '' : 'on'}" title="Whole month / quarter target">Full ${d.period_type}</button><button data-v="prorate" class="${d.prorate ? 'on' : ''}" title="Target × share of the days in the selected dates">Pro-rated</button></span>${editLink}</div></div>`;
            let body;
            if (!d.has_targets) {
                body = `<div class="pqt-empty">No targets set for ${esc(per)}${d.platform !== 'overall' ? ' on ' + esc(d.platform_name) : ''}. ${d.can_edit ? 'Add them on the Targets page.' : 'Ask an admin to add them.'}</div>`;
            } else {
                body = `<div class="pqt-wrap"><table><thead><tr><th>Particulars</th><th>Target</th><th>Achieved</th><th>vs target</th></tr></thead><tbody>${d.rows.map(r => {
                    let vs = '<span class="dim">—</span>';
                    const cls = r.status === 'good' ? 'ok' : (r.status === 'near' ? 'near' : (r.status === 'bad' ? 'bad' : ''));
                    if (r.pct !== null && r.pct !== undefined) {
                        const w = Math.max(2, Math.min(100, r.pct));
                        const col = r.better === 'neutral' ? 'var(--accent,#E8A820)' : (cls === 'ok' ? '#10B981' : cls === 'near' ? '#F59E0B' : '#EF4444');
                        vs = `<span class="${r.better === 'neutral' ? '' : cls}">${inr(r.pct, 0)}%</span><span class="bar"><i style="width:${w}%;background:${col}"></i></span>`;
                    } else if (r.target && r.achieved !== null && r.achieved !== undefined && r.better !== 'neutral') {
                        const diff = (r.achieved - r.target) / r.target * 100;
                        vs = `<span class="${cls}">${diff > 0 ? '+' : ''}${inr(diff, 0)}%</span>`;
                    }
                    return `<tr class="${r.kind === 'rate' ? 'rate' : ''}"><td>${esc(r.label)}${r.manual ? '<span class="tag" title="Entered on the Targets page">by hand</span>' : ''}</td>
                        <td>${fmt(r.target, r.format)}${r.fixed ? '' : ''}</td><td class="${cls}">${fmt(r.achieved, r.format)}</td><td>${vs}</td></tr>`;
                }).join('')}</tbody></table></div>`;
            }
            const notes = [];
            if (d.has_targets && !d.manual_entered) notes.push('Bookings, clash bookings and revenue achieved are entered on the Targets page.');
            if (d.warnings && d.warnings.length) notes.push(esc(d.warnings.join(' · ')));
            el.innerHTML = head + body + (notes.length ? `<div class="pqt-foot">${notes.join('<br>')}</div>` : '');
            el.querySelectorAll('[data-v]').forEach(b => b.onclick = () => { setView(b.dataset.v); load(); });
            const pf = el.querySelector('[data-pf]');
            if (pf) pf.onchange = () => { st.platform = pf.value; load(); };
            const ed = el.querySelector('[data-edit]');
            if (ed) ed.onclick = () => {
                if (window.parent && window.parent !== window) window.parent.postMessage({ type: 'pq-open', view: 'targets' }, '*');
                else if (opt.editUrl) location.href = opt.editUrl;
                else location.hash = 'targets';
            };
        }
        return {
            update(r) { if (!r || !r.since || !r.until) return; if (r.since === st.since && r.until === st.until) return; st.since = r.since; st.until = r.until; load(); },
            reload() { load(); },
            setPlatforms(p) { opt.platforms = p; }
        };
    }
    window.PQTargets = { mount };
})();
