/**
 * campaign_view.js — the All / Performance / Awareness tabs on All Platforms, Meta Ads, Google Ads, the manual
 * platforms, Creatives & Insights and Keyword Analysis.
 *
 *   All          every campaign
 *   Performance  only performance campaigns
 *   Awareness    only campaigns tagged Awareness in ⟳ Sync (and the awareness share of manual platforms, ✎ Awareness)
 *
 * The choice is a cookie (pq_view), so every dashboard, report and API call follows it, and switching on one page
 * updates the others that are open (storage event). The tabs a viewer gets come from Users & Roles → Campaign types
 * (window.PQ_VIEW_TABS, printed by pqViewTag() in app/Core/access.php); the server enforces the same.
 *
 *   const v = PQView.mount(el, { onChange: view => reload() });
 *   v.info(data.awareness)    // after each load: {view, tagged, performance:{count, spend}, awareness:{count, spend}}
 *   PQView.current()          // 'all' | 'performance' | 'awareness'
 */
(function () {
    'use strict';
    const KEY = 'pq-view';
    const LABEL = { all: 'All', performance: 'Performance', awareness: 'Awareness' };
    const TIP = {
        all: 'Every campaign — performance and awareness together',
        performance: 'Only performance campaigns',
        awareness: 'Only campaigns tagged Awareness in ⟳ Sync (and the awareness share of manual platforms)',
    };
    const css = `
    .pqv { display: inline-flex; align-items: center; gap: 10px; flex-wrap: wrap; font-family: inherit; font-size: 12.5px; color: var(--pq-text-dim, var(--text-dim, #64748b)); }
    .pqv-tabs { display: inline-flex; gap: 3px; padding: 3px; border-radius: 10px; background: var(--pq-surface-2, var(--surface-2, #f1f5f9)); border: 1px solid var(--pq-border, var(--border, #e2e8f0)); }
    .pqv-tab { all: unset; box-sizing: border-box; cursor: pointer; padding: 5px 13px; border-radius: 7px; font-weight: 600; font-size: 12.5px; line-height: 1.35;
               color: var(--pq-text-dim, var(--text-dim, #64748b)); white-space: nowrap; }
    .pqv-tab:hover { color: var(--pq-text, var(--text, #0f172a)); }
    .pqv-tab[aria-selected="true"] { background: var(--pq-surface, var(--surface, #fff)); color: var(--pq-text, var(--text, #0f172a)); box-shadow: 0 1px 2px rgba(0,0,0,.18); }
    .pqv-tab[data-v="awareness"][aria-selected="true"] { color: var(--accent, #B7791F); }
    .pqv-tab:focus-visible { outline: 2px solid var(--accent, #E8A820); outline-offset: 1px; }
    .pqv-only { display: inline-flex; align-items: center; padding: 4px 11px; border-radius: 99px; font-weight: 600; font-size: 12px;
                background: var(--pq-surface-2, var(--surface-2, #f1f5f9)); border: 1px solid var(--pq-border, var(--border, #e2e8f0)); color: var(--pq-text, var(--text, #0f172a)); }
    .pqv-note { font-size: 11.5px; }
    @media (max-width: 600px) { .pqv { width: 100%; } .pqv-tabs { flex: 1 1 auto; } .pqv-tab { flex: 1 1 0; text-align: center; padding: 6px 6px; } }`;

    function addCss() {
        if (document.getElementById('pqv-css')) return;
        const s = document.createElement('style'); s.id = 'pqv-css'; s.textContent = css; document.head.appendChild(s);
    }
    const tabs = () => {
        const t = Array.isArray(window.PQ_VIEW_TABS) && window.PQ_VIEW_TABS.length ? window.PQ_VIEW_TABS : ['all', 'performance', 'awareness'];
        return t.filter(v => LABEL[v]);
    };
    const cookie = () => { const m = document.cookie.match(/(?:^|;\s*)pq_view=([a-z]+)/); return m ? m[1] : ''; };
    function current() {
        const t = tabs(), v = cookie() || 'all';
        return t.includes(v) ? v : t[0];
    }
    function setView(v) {
        document.cookie = 'pq_view=' + v + '; path=/; max-age=31536000; SameSite=Lax';
        try { localStorage.setItem(KEY, v + ':' + Date.now()); } catch (e) {}
    }
    const money = v => '₹' + Math.round(Number(v || 0)).toLocaleString('en-IN');
    const plural = (n, w) => n + ' ' + w + (n === 1 ? '' : 's');

    // the cookie may hold a tab this role no longer has: store the one in use, so the server agrees
    if (cookie() !== current()) setView(current());

    function mount(el, opt) {
        if (!el) return { info() {}, current };
        addCss();
        opt = opt || {};
        const t = tabs();
        el.classList.add('pqv');
        if (t.length < 2) {
            el.innerHTML = `<span class="pqv-only" title="${TIP[t[0]]}">${LABEL[t[0]]} campaigns only</span><span class="pqv-note"></span>`;
        } else {
            el.innerHTML = `<div class="pqv-tabs" role="tablist" aria-label="Campaign type">${t.map(v =>
                `<button type="button" class="pqv-tab" role="tab" data-v="${v}" title="${TIP[v]}" aria-selected="false">${LABEL[v]}</button>`).join('')}</div><span class="pqv-note"></span>`;
        }
        const note = el.querySelector('.pqv-note');
        const paint = () => el.querySelectorAll('.pqv-tab').forEach(b => {
            const on = b.dataset.v === current();
            b.setAttribute('aria-selected', on ? 'true' : 'false');
            b.tabIndex = on ? 0 : -1;
        });
        paint();
        const pick = v => {
            if (v === current()) return;
            setView(v); paint(); note.textContent = '';
            if (opt.onChange) opt.onChange(v);
        };
        el.addEventListener('click', e => { const b = e.target.closest('.pqv-tab'); if (b) pick(b.dataset.v); });
        el.addEventListener('keydown', e => {
            if (!['ArrowLeft', 'ArrowRight'].includes(e.key) || !e.target.closest('.pqv-tab')) return;
            const i = t.indexOf(current()), n = t[(i + (e.key === 'ArrowRight' ? 1 : t.length - 1)) % t.length];
            pick(n); const b = el.querySelector(`.pqv-tab[data-v="${n}"]`); if (b) b.focus();
            e.preventDefault();
        });
        // another dashboard (another frame / tab) switched
        let last = current();
        window.addEventListener('storage', e => {
            if (e.key !== KEY) return;
            const v = current();
            if (v !== last) { last = v; paint(); note.textContent = ''; if (opt.onChange) opt.onChange(v); }
        });
        return {
            current,
            /** a: {view, tagged, performance:{count, spend}|null, awareness:{count, spend}|null} (or several summed) */
            info(a) {
                last = current();
                if (!a) { note.textContent = ''; return; }
                const v = current(), aw = a.awareness || null;
                if (opt.untagged && !a.tagged && v !== 'performance') { note.textContent = opt.untagged; return; }
                if (v === 'awareness') {
                    note.textContent = !a.tagged ? 'No campaign is tagged as awareness yet (⟳ Sync → Awareness).'
                        : aw && aw.count ? plural(aw.count, 'awareness campaign') + ' · ' + money(aw.spend) + ' spend' : plural(a.tagged, 'awareness campaign') + ' tagged · none ran in these dates';
                } else if (v === 'performance') {
                    note.textContent = aw && aw.count ? money(aw.spend) + ' awareness spend not shown (' + plural(aw.count, 'campaign') + ')' : '';
                } else {
                    note.textContent = aw && aw.count ? 'incl. ' + money(aw.spend) + ' awareness (' + plural(aw.count, 'campaign') + ')' : '';
                }
            }
        };
    }
    /** Sums the info of several platforms (All Platforms). */
    function sum(list) {
        const out = { view: current(), tagged: 0, performance: null, awareness: null };
        for (const a of list || []) {
            if (!a) continue;
            out.tagged += a.tagged || 0;
            for (const k of ['performance', 'awareness']) {
                if (!a[k]) continue;
                out[k] = out[k] || { count: 0, spend: 0 };
                out[k].count += a[k].count || 0;
                out[k].spend += a[k].spend || 0;
            }
        }
        return out;
    }
    window.PQView = { mount, current, tabs, sum, label: v => LABEL[v] || v };
})();
