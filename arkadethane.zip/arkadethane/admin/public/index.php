<?php
/*
=========================================================
* Paper Dashboard 2 - v2.0.1
=========================================================

* Product Page: https://www.creative-tim.com/product/paper-dashboard-2
* Copyright 2020 Creative Tim (https://www.creative-tim.com)

Coded by www.creative-tim.com

 =========================================================

* The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
*/

// The admin's home is dashboard.php: opening /admin/ or index.php on its own goes there.
// dashboard.php shows this page inside its "Leads & CRM" section as index.php?embed=1.
if (!isset($_GET['embed']) || $_GET['embed'] !== '1') {
  header('Location: dashboard.php' . (isset($_GET['leads']) ? '#leads' : ''), true, 302);
  exit;
}

session_start();
include dirname(__DIR__) . '/app/Core/db.php';
require_once dirname(__DIR__) . '/app/Leads/header.php';
require_once dirname(__DIR__) . '/app/bootstrap.php';
require_once dirname(__DIR__) . '/app/Leads/status_filter.php';

if (!isset($_SESSION["user_logged"]) || $_SESSION["user_logged"] != "Y") {
  header("Location: login.php");
  exit;
}

$username = $_SESSION['username'] ?? 'Admin';
$role = $_SESSION['role'] ?? 'admin';

// Embed mode: dashboard.php loads this page inside its "Leads" tab (index.php?embed=1).
// Hides this page's own sidebar / top navbar / footer so only the Leads & CRM content shows.
$isEmbed = isset($_GET['embed']) && $_GET['embed'] === '1';

/**
 * Campaign database selector — options come from LEAD_DATABASES in config/config.php
 * (any number of databases; 'all' = every one of them).
 */
$campaignDatabaseOptions = ['all' => 'ALL'] + leadDbLabels();   // from LEAD_DATABASES in config/config.php
$showDatabaseFilter = count(leadDbKeys()) > 1;                   // one database → no filter

/**
 * Build a unique list of campaign filter values from both databases.
 * This keeps Campaign Source/Subsource usable when ALL is selected.
 */
function getDistinctCampaignValues(array $connections, string $column): array
{
  $allowedColumns = ['campaignsource', 'campaignsubsource'];

  if (!in_array($column, $allowedColumns, true)) {
    return [];
  }

  $values = [];

  foreach ($connections as $db) {
    if (!$db instanceof mysqli) {
      continue;
    }

    $sql = "SELECT DISTINCT `{$column}` FROM `lead`
            WHERE `{$column}` IS NOT NULL
              AND TRIM(`{$column}`) <> ''
            ORDER BY `{$column}` ASC";

    $result = mysqli_query($db, $sql);

    if (!$result) {
      error_log("Campaign filter query failed for {$column}: " . mysqli_error($db));
      continue;
    }

    while ($row = mysqli_fetch_assoc($result)) {
      $value = trim((string) ($row[$column] ?? ''));
      if ($value !== '') {
        $values[$value] = true;
      }
    }

    mysqli_free_result($result);
  }

  $values = array_keys($values);
  natcasesort($values);

  return array_values($values);
}

$campaignSources = getDistinctCampaignValues(array_values(leadDbs('all')), 'campaignsource');
$campaignSubSources = getDistinctCampaignValues(array_values(leadDbs('all')), 'campaignsubsource');

?>

<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <link rel="apple-touch-icon" sizes="76x76" href="./assets/img/apple-icon.png">

  <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css" />
  <link rel="icon" type="image/png" href="./assets/img/favicon.png">

  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <title>
    Webzaa Admin | <?php echo PROJECT_NAME; ?>
  </title>
  <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no'
    name='viewport' />
  <!--     Fonts and icons     -->
  <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
  <link href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
  <!-- CSS Files -->
  <link href="./assets/css/bootstrap.min.css" rel="stylesheet" />
  <link href="./assets/css/paper-dashboard.css?v=2.0.1" rel="stylesheet" />
  <!-- CSS Just for demo purpose, don't include it in your project -->
  <link href="./assets/demo/demo.css" rel="stylesheet" />
  <link href="./assets/css/style.css" rel="stylesheet" />
  <link rel="stylesheet" href="https://cdn.datatables.net/responsive/2.2.9/css/responsive.dataTables.min.css">
  <style>
    :root {
      --app-bg: #f5f7fb;
      --surface: #fff;
      --border: #e7eaf0;
      --text: #171b24;
      --muted: #737b8c;
      --green: #176b3a;
      --green-soft: #eaf6ef;
      --green-border: #cce8d6;
      --shadow: 0 8px 28px rgba(25, 35, 52, .06);
      --radius: 14px
    }

    html,
    body {
      min-height: 100%;
      background: var(--app-bg) !important;
      font-family: "Montserrat", -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
      color: var(--text)
    }

    body {
      overflow-x: hidden
    }

    .wrapper {
      min-height: 100vh;
      background: var(--app-bg)
    }

    .sidebar {
      width: 224px !important;
      background: #fff !important;
      border-right: 1px solid var(--border);
      box-shadow: none !important;
      z-index: 1040
    }

    .sidebar .logo {
      height: 78px !important;
      border-bottom: 1px solid var(--border);
      display: flex;
      align-items: center;
      padding: 0 22px
    }

    .sidebar .logo a {
      width: 100%;
      padding: 0 !important;
      margin: 0 !important
    }

    .sidebar .logo-image-big {
      padding: 0 !important;
      width: 100%;
      text-align: left
    }

    .sidebar .logo-image-big img {
      max-width: 142px;
      max-height: 42px;
      object-fit: contain
    }

    .sidebar .sidebar-wrapper {
      padding: 18px 12px;
      height: calc(100vh - 78px);
      overflow-y: auto
    }

    .sidebar .nav {
      margin: 0;
      padding: 0
    }

    .sidebar .nav li {
      margin: 4px 0
    }

    .sidebar .nav li a {
      display: flex !important;
      align-items: center;
      min-height: 48px;
      border-radius: 10px;
      padding: 10px 14px !important;
      color: #687181 !important;
      font-size: 13px;
      font-weight: 500;
      transition: .18s ease
    }

    .sidebar .nav li a:hover {
      background: #f5f7f8;
      color: var(--green) !important
    }

    .sidebar .nav li.active>a {
      background: var(--green-soft) !important;
      color: var(--green) !important;
      box-shadow: inset 0 0 0 1px var(--green-border)
    }

    .sidebar .nav li a p {
      margin: 0 0 0 10px !important;
      font-size: 13px;
      line-height: 1.2
    }

    .sidebar .nav li a i,
    .sidebar .nav li a .iconify {
      flex: 0 0 24px;
      width: 24px !important;
      margin: 0 !important;
      text-align: center;
      font-size: 19px !important
    }

    .main-panel {
      width: calc(100% - 224px) !important;
      min-height: 100vh;
      height: auto !important;
      margin-left: 224px !important;
      background: var(--app-bg);
      overflow-x: hidden
    }

    .main-panel>.navbar {
      position: sticky !important;
      top: 0;
      left: auto !important;
      width: 100% !important;
      min-height: 78px;
      padding: 0 28px !important;
      background: rgba(255, 255, 255, .96) !important;
      border-bottom: 1px solid var(--border);
      box-shadow: none !important;
      z-index: 1030;
      transform: none !important
    }

    .navbar .container-fluid {
      padding: 0 !important;
      min-height: 78px
    }

    .navbar-wrapper {
      display: flex;
      align-items: center;
      gap: 10px
    }

    .navbar-brand {
      margin: 0 !important;
      padding: 0 !important;
      color: var(--text) !important;
      font-size: 18px !important;
      font-weight: 700 !important
    }

    .navbar-wrapper:after {
      content: "Manage leads, customer relationships and campaign data.";
      display: block;
      color: var(--muted);
      font-size: 11px;
      font-weight: 400;
      margin-left: 8px
    }

    .navbar .navbar-nav {
      align-items: center
    }

    .navbar .dropdown-toggle {
      display: flex;
      align-items: center;
      justify-content: center;
      width: 42px;
      height: 42px;
      border: 1px solid var(--border);
      border-radius: 10px;
      background: #fff
    }

    .navbar .dropdown-toggle:after {
      margin-left: 0
    }

    .navbar .dropdown-menu {
      border: 1px solid var(--border);
      border-radius: 10px;
      box-shadow: var(--shadow)
    }

    .content {
      padding: 26px 28px 38px !important
    }

    .page-heading {
      display: flex;
      justify-content: space-between;
      align-items: flex-end;
      gap: 16px;
      margin-bottom: 20px
    }

    .page-heading h1 {
      margin: 0;
      font-size: 25px;
      line-height: 1.2;
      font-weight: 700;
      color: var(--text)
    }

    .page-heading p {
      margin: 6px 0 0;
      color: var(--muted);
      font-size: 12px
    }

    .dashboard-kpis {
      display: grid;
      grid-template-columns: repeat(4, minmax(0, 1fr));
      gap: 14px;
      margin-bottom: 18px
    }

    .kpi-card {
      background: var(--surface);
      border: 1px solid var(--border);
      border-radius: var(--radius);
      padding: 16px 18px;
      box-shadow: var(--shadow);
      min-height: 96px
    }

    .kpi-label {
      color: var(--muted);
      font-size: 11px;
      font-weight: 600;
      margin-bottom: 8px;
      text-transform: uppercase;
      letter-spacing: .04em
    }

    .kpi-value {
      color: var(--text);
      font-size: 20px;
      font-weight: 700;
      line-height: 1.2
    }

    .kpi-sub {
      margin-top: 7px;
      color: #8a92a0;
      font-size: 10px
    }

    .filter-card {
      background: var(--surface);
      border: 1px solid var(--border);
      border-radius: var(--radius);
      padding: 18px;
      box-shadow: var(--shadow);
      margin-bottom: 18px
    }

    .filter-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 10px;
      margin-bottom: 14px
    }

    .filter-header h4 {
      margin: 0;
      font-size: 14px;
      font-weight: 700
    }

    .filter-header span {
      color: var(--muted);
      font-size: 11px
    }

    .filter-grid {
      display: grid;
      grid-template-columns: 1.15fr 1fr 1fr 1fr 1.25fr auto;
      gap: 12px;
      align-items: end
    }

    .filter-field label {
      display: block;
      margin: 0 0 6px;
      color: #606979;
      font-size: 10px;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: .03em
    }

    .filter-field .form-control,
    .filter-field select {
      height: 42px !important;
      min-height: 42px !important;
      border: 1px solid #dfe3e9 !important;
      border-radius: 9px !important;
      background: #fff !important;
      box-shadow: none !important;
      color: var(--text) !important;
      font-size: 12px !important;
      padding: 0 12px !important
    }

    .filter-field .form-control:focus,
    .filter-field select:focus {
      border-color: #9bcab0 !important;
      box-shadow: 0 0 0 3px rgba(23, 107, 58, .08) !important
    }

    .filter-actions {
      display: flex;
      gap: 8px;
      height: 42px
    }

    .btn-modern {
      height: 42px;
      border-radius: 9px !important;
      border: 1px solid var(--green) !important;
      padding: 0 16px !important;
      font-size: 11px !important;
      font-weight: 600 !important;
      white-space: nowrap;
      transition: .18s ease
    }

    .btn-search {
      background: var(--green) !important;
      color: #fff !important
    }

    .btn-search:hover {
      background: #11552e !important
    }

    .btn-reset {
      background: #fff !important;
      color: #596171 !important;
      border-color: #dfe3e9 !important
    }

    .btn-reset:hover {
      background: #f7f8fa !important
    }

    .till-date-wrap {
      margin-top: 7px;
      display: flex;
      align-items: center;
      gap: 6px
    }

    .till-date-wrap label {
      margin: 0;
      text-transform: none;
      letter-spacing: 0;
      font-size: 10px;
      color: var(--muted);
      font-weight: 500
    }

    .workspace-card {
      background: var(--surface);
      border: 1px solid var(--border);
      border-radius: var(--radius);
      box-shadow: var(--shadow);
      overflow: hidden
    }

    .tab {
      display: flex;
      align-items: center;
      gap: 4px;
      padding: 7px;
      background: #f7f8fa;
      border: 0 !important;
      border-bottom: 1px solid var(--border) !important;
      overflow-x: auto
    }

    .tab button {
      float: none !important;
      border: 0 !important;
      border-radius: 8px !important;
      background: transparent !important;
      color: #727a89;
      padding: 9px 13px !important;
      font-size: 11px !important;
      font-weight: 600;
      white-space: nowrap
    }

    .tab button:hover {
      background: #fff !important;
      color: var(--text)
    }

    .tab button.active {
      background: #fff !important;
      color: var(--green) !important;
      box-shadow: 0 1px 5px rgba(20, 30, 40, .08)
    }

    .tabcontent {
      border: 0 !important;
      padding: 20px !important;
      background: #fff
    }

    .tabcontent>h3 {
      margin: 0 0 16px;
      font-size: 16px;
      font-weight: 700
    }

    .charts-grid {
      display: grid !important;
      grid-template-columns: repeat(2, minmax(0, 1fr));
      gap: 16px;
      width: 100% !important;
      margin: 0 !important
    }

    .chart-card {
      min-height: 350px;
      border: 1px solid var(--border);
      border-radius: 12px;
      padding: 8px;
      background: #fff
    }

    .chart-loading {
      height: 100%;
      display: flex;
      align-items: center;
      justify-content: center;
      color: #89919d;
      font-size: 12px
    }

    .chart-wide {
      grid-column: 1/-1;
      min-height: 300px
    }

    .leads-toolbar {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 12px;
      margin-bottom: 14px
    }

    .leads-toolbar h3 {
      margin: 0 !important;
      font-size: 17px !important
    }

    .toolbar-actions {
      display: flex;
      gap: 8px
    }

    .toolbar-actions .btn-modern,
    .toolbar-actions a {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      text-decoration: none
    }

    .table-wrap {
      width: 100%;
      overflow-x: auto;
      border: 1px solid var(--border);
      border-radius: 11px
    }

    #showRecords,
    #showRecordsFollowup {
      width: 100% !important;
      min-width: 620px;
      margin: 0 !important;
      border: 0 !important;
      background: #fff
    }

    #showRecords thead th,
    #showRecordsFollowup thead th {
      background: #f8f9fb;
      border-bottom: 1px solid var(--border) !important;
      color: #727a89;
      font-size: 10px;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: .03em;
      padding: 12px 11px !important;
      white-space: nowrap
    }

    #showRecords tbody td,
    #showRecordsFollowup tbody td {
      border-top: 1px solid #eef0f3 !important;
      color: #303642;
      font-size: 11px;
      padding: 12px 11px !important;
      vertical-align: middle
    }

    #showRecords tbody tr:hover,
    #showRecordsFollowup tbody tr:hover {
      background: #fbfcfd
    }

    .dataTables_wrapper {
      padding: 14px 12px 4px !important;
      font-size: 11px;
      color: var(--muted)
    }

    .dataTables_wrapper .dataTables_length,
    .dataTables_wrapper .dataTables_filter {
      margin-bottom: 10px
    }

    .dataTables_wrapper .dataTables_length select,
    .dataTables_wrapper .dataTables_filter input {
      height: 34px;
      border: 1px solid #dfe3e9;
      border-radius: 8px;
      background: #fff;
      padding: 0 9px;
      color: var(--text);
      outline: none
    }

    .dataTables_wrapper .dataTables_filter input {
      margin-left: 6px;
      min-width: 190px
    }

    .dataTables_wrapper .dataTables_info {
      padding-top: 12px !important;
      color: #7a8290
    }

    .dataTables_wrapper .dataTables_paginate {
      padding-top: 8px !important
    }

    .dataTables_wrapper .dataTables_paginate .paginate_button {
      border: 1px solid transparent !important;
      border-radius: 7px !important;
      color: #687181 !important;
      padding: 5px 9px !important;
      margin: 0 2px !important;
      background: transparent !important
    }

    .dataTables_wrapper .dataTables_paginate .paginate_button.current,
    .dataTables_wrapper .dataTables_paginate .paginate_button.current:hover {
      background: var(--green) !important;
      border-color: var(--green) !important;
      color: #fff !important
    }

    .dataTables_wrapper .dataTables_paginate .paginate_button:hover {
      background: #eef7f1 !important;
      border-color: #d6eadc !important;
      color: var(--green) !important
    }

    table.dataTable.dtr-inline.collapsed>tbody>tr>td.dtr-control:before,
    table.dataTable.dtr-inline.collapsed>tbody>tr>th.dtr-control:before {
      background: var(--green) !important
    }

    table.dataTable.dtr-inline.collapsed>tbody>tr.parent>td.dtr-control:before,
    table.dataTable.dtr-inline.collapsed>tbody>tr.parent>th.dtr-control:before {
      background: #777 !important
    }

    .lead-detail-grid {
      display: grid;
      grid-template-columns: repeat(4, minmax(0, 1fr));
      gap: 0;
      padding: 6px 14px 14px;
      background: #f8faf9;
      border: 1px solid #e5eee8;
      border-top: 0;
      border-radius: 0 0 10px 10px;
      box-sizing: border-box;
      width: 100%;
      overflow: hidden
    }

    .lead-detail-item {
      min-width: 0;
      padding: 12px 16px 10px 0;
      border-bottom: 1px solid #e7eee9
    }

    .lead-detail-item strong {
      display: block;
      color: #788190;
      font-size: 10px;
      line-height: 1.35;
      text-transform: uppercase;
      letter-spacing: .045em;
      margin-bottom: 6px;
      font-weight: 700
    }

    .lead-detail-item span {
      display: block;
      color: #252b35;
      font-size: 12px;
      line-height: 1.5;
      font-weight: 500;
      word-break: break-word;
      overflow-wrap: anywhere;
      white-space: normal
    }

    .lead-detail-item:last-child {
      border-bottom: 1px solid #e7eee9
    }

    .lead-row {
      cursor: pointer
    }

    .lead-row:hover>td {
      background: #f7faf8 !important
    }

    .lead-row.shown>td {
      background: #f3f8f5 !important
    }

    .lead-actions {
      position: relative;
      display: flex;
      align-items: center;
      justify-content: flex-end;
      gap: 5px;
      min-width: 42px
    }

    .action-btn {
      width: 32px;
      height: 32px;
      padding: 0 !important;
      border: 1px solid transparent !important;
      border-radius: 8px !important;
      display: inline-flex !important;
      align-items: center;
      justify-content: center;
      margin: 0 !important;
      background: #f2f4f6 !important;
      color: #4c5563 !important;
      cursor: pointer
    }

    .action-btn.details-control {
      border-color: #dce2e8 !important;
      background: #fff !important
    }

    .action-btn:hover {
      background: #e8f4ed !important;
      color: var(--green) !important
    }

    .action-menu {
      display: none;
      position: absolute;
      right: 0;
      top: 38px;
      min-width: 165px;
      background: #fff;
      border: 1px solid #dfe4ea;
      border-radius: 10px;
      box-shadow: 0 12px 30px rgba(20, 30, 40, .14);
      padding: 5px;
      z-index: 1200
    }

    .action-menu.open {
      display: block
    }

    .action-menu button {
      display: flex;
      width: 100%;
      align-items: center;
      gap: 9px;
      border: 0;
      background: #fff;
      border-radius: 7px;
      padding: 9px 10px;
      color: #4a5260;
      font-size: 11px;
      text-align: left;
      cursor: pointer
    }

    .action-menu button:hover {
      background: #f4f8f5;
      color: var(--green)
    }

    .action-menu i {
      width: 15px;
      text-align: center
    }

    .dataTables_wrapper {
      overflow: visible !important
    }

    #showRecords tbody td:last-child {
      overflow: visible !important
    }

    #showRecords tbody tr.lead-row.shown {
      background: #fbfdfb
    }

    #showRecords tbody tr.child td {
      padding: 0 !important;
      border-top: 0 !important;
      background: #f8faf9 !important
    }

    #showRecords tbody tr.child .lead-detail-grid {
      margin: 0 !important
    }

    .table-wrap {
      overflow: visible !important
    }

    .lead-name {
      font-weight: 600;
      color: #20252e
    }

    .lead-sub {
      display: block;
      margin-top: 3px;
      color: #89919d;
      font-size: 9px
    }

    .modal-content {
      border: 0;
      border-radius: 14px;
      box-shadow: 0 18px 50px rgba(20, 30, 40, .18)
    }

    .modal-header {
      border-bottom: 1px solid var(--border)
    }

    #footer {
      display: none
    }

    .mobile-menu-btn {
      display: none;
      width: 38px;
      height: 38px;
      border: 1px solid var(--border);
      border-radius: 9px;
      background: #fff;
      color: var(--text);
      align-items: center;
      justify-content: center;
      cursor: pointer
    }

    .description {
      display: none
    }

    .error {
      border-color: #dc3545 !important
    }

    @media(max-width:991px) {
      .lead-detail-grid {
        grid-template-columns: repeat(2, minmax(0, 1fr));
        padding: 4px 12px 12px
      }

      .lead-detail-item {
        padding: 10px 12px 9px 0
      }

      .lead-detail-item span {
        font-size: 11px
      }
    }

    @media(max-width:575px) {
      .lead-detail-grid {
        grid-template-columns: 1fr;
        padding: 2px 10px 10px
      }

      .lead-detail-item {
        padding: 9px 4px;
        border-bottom: 1px solid #e7eee9
      }

      .lead-detail-item strong {
        font-size: 9px;
        margin-bottom: 4px
      }

      .lead-detail-item span {
        font-size: 11px
      }

      .lead-actions {
        min-width: 72px
      }

      .action-btn {
        width: 30px;
        height: 30px
      }
    }

    @media(max-width:1200px) {
      .filter-grid {
        grid-template-columns: repeat(3, minmax(0, 1fr))
      }

      .filter-actions {
        grid-column: span 3;
        justify-content: flex-end
      }

      .dashboard-kpis {
        grid-template-columns: repeat(2, minmax(0, 1fr))
      }
    }

    @media(max-width:991px) {
      .sidebar {
        transform: translate3d(-100%, 0, 0) !important;
        transition: transform .22s ease
      }

      .sidebar.mobile-open {
        transform: translate3d(0, 0, 0) !important
      }

      .main-panel {
        width: 100% !important;
        margin-left: 0 !important
      }

      .main-panel>.navbar {
        padding: 0 18px !important
      }

      .mobile-menu-btn {
        display: inline-flex
      }

      .navbar-wrapper:after {
        display: none
      }

      .content {
        padding: 20px 18px 30px !important
      }

      .charts-grid {
        grid-template-columns: 1fr
      }

      .chart-wide {
        grid-column: auto
      }

      .sidebar-overlay {
        display: none;
        position: fixed;
        inset: 0;
        background: rgba(10, 18, 28, .28);
        z-index: 1035
      }

      .sidebar-overlay.active {
        display: block
      }
    }

    @media(max-width:767px) {
      .content {
        padding: 14px 10px 24px !important
      }

      .main-panel>.navbar,
      .navbar .container-fluid {
        min-height: 62px
      }

      .main-panel>.navbar {
        padding: 0 10px !important
      }

      .navbar-brand {
        font-size: 15px !important
      }

      .page-heading {
        align-items: flex-start;
        margin-bottom: 12px
      }

      .page-heading h1 {
        font-size: 20px
      }

      .dashboard-kpis {
        grid-template-columns: 1fr 1fr;
        gap: 8px
      }

      .kpi-card {
        min-height: 78px;
        padding: 11px
      }

      .kpi-label {
        font-size: 9px
      }

      .kpi-value {
        font-size: 15px
      }

      .kpi-sub {
        font-size: 9px
      }

      .filter-card {
        padding: 12px
      }

      .filter-grid {
        grid-template-columns: 1fr
      }

      .filter-actions {
        grid-column: auto;
        width: 100%;
        justify-content: stretch
      }

      .filter-actions button {
        flex: 1
      }

      .tabcontent {
        padding: 12px !important
      }

      .leads-toolbar {
        align-items: flex-start;
        flex-direction: column
      }

      .toolbar-actions {
        width: 100%
      }

      .toolbar-actions .btn-modern,
      .toolbar-actions a {
        flex: 1
      }

      .chart-card {
        min-height: 260px;
        padding: 4px
      }

      .chart-card>div {
        height: 270px !important
      }

      .navbar .navbar-nav {
        display: none
      }

      .dataTables_wrapper {
        padding: 10px 4px 2px !important
      }

      .dataTables_wrapper .dataTables_length,
      .dataTables_wrapper .dataTables_filter {
        float: none !important;
        text-align: left !important;
        width: 100%;
        margin-bottom: 8px
      }

      .dataTables_wrapper .dataTables_filter input {
        width: calc(100% - 65px);
        min-width: 0;
        margin-left: 5px
      }

      .dataTables_wrapper .dataTables_info {
        float: none !important;
        text-align: center !important;
        margin-bottom: 5px
      }

      .dataTables_wrapper .dataTables_paginate {
        float: none !important;
        text-align: center !important
      }

      .lead-detail-grid {
        grid-template-columns: 1fr 1fr;
        gap: 8px;
        padding: 10px
      }

      .table-wrap {
        border: 0;
        overflow: visible
      }

      .workspace-card {
        border-radius: 11px
      }

      .toolbar-actions {
        gap: 6px
      }

      .btn-modern {
        padding: 0 12px !important
      }
    }

    @media(max-width:420px) {
      .dashboard-kpis {
        grid-template-columns: 1fr
      }

      .kpi-card {
        min-height: 74px
      }

      .page-heading h1 {
        font-size: 19px
      }

      .tab button {
        padding: 8px 10px !important
      }
    }
  </style>
  <?php include dirname(__DIR__) . '/app/Ui/embed_head.php'; ?>
  <script>window.LEAD_DB_LABELS = <?php echo json_encode(leadDbLabels(), JSON_UNESCAPED_UNICODE | JSON_HEX_TAG); ?>;</script>
<?= function_exists('pqDatesTag') ? pqDatesTag('') : '' ?>
</head>


<body class="">
  <form action="./leads/export.php" id="export_form" method="POST">
    <input type="hidden" id="till_date_form" name="till_date">
    <input type="hidden" id="from_date_form" name="from_date">
    <input type="hidden" id="to_date_form" name="to_date">
    <input type="hidden" id="camp_source_form" name="camp_source">
    <input type="hidden" id="Campaign_sub_source_form" name="Campaign_sub_source">
    <input type="hidden" id="keyword_form" name="keyword">
    <input type="hidden" id="lead_status_form" name="lead_status">
    <input type="hidden" id="campaign_database_form" name="database">

  </form>

  <form action="./leads/add-lead.php" id="edit_form" method="POST"<?php echo $isEmbed ? ' target="_blank"' : ''; ?>>
    <input type="hidden" id="mobile_edit" name="mobile">
    <input type="hidden" id="database_edit" name="database">
  </form>

  <div class="wrapper ">
    <!-- ===m=== Sidebar code started ===m=== -->
    <div class="sidebar" data-color="white" data-active-color="danger">
      <div class="logo">
        <a href="index.php" class="simple-text logo-normal">
          <div class="logo-image-big pl-5">
            <img src="./assets/images/webzaa-logo.png">
          </div>
        </a>
      </div>
      <div class="sidebar-wrapper">
        <ul class="nav">
          <li class="active ">
            <a href="index.php">
              <span class="iconify" data-icon="ri:dashboard-fill"
                style="font-size:24px;float:left;margin-right:12px;line-height:30px;width:34px;text-align:center;position:relative;"></span>
              <p>Dashboard</p>
            </a>
          </li>
          <li class="">
            <a href="analytics.php">
              <i class="nc-icon nc-chart-pie-36"></i>
              <p>Analytics</p>
            </a>
          </li>
          <li class="">
            <a href="meta_capi.php">
              <span class="iconify" data-icon="ri:meta-fill"
                style="font-size:24px;float:left;margin-right:12px;line-height:30px;width:34px;text-align:center;position:relative;"></span>
              <p>Meta CAPI</p>
            </a>
          </li>
          <li class="">
            <a href="import.php">
              <i class="nc-icon nc-cloud-upload-94"></i>
              <p>Import</p>
            </a>
          </li>
          <li>
            <a href="dashboard.php">
              <i class="nc-icon nc-diamond"></i>
              <p>Ad Analytics</p>
            </a>
          </li>
          <!--  <li>
            <a href="javascript:;">
              <i class="nc-icon nc-diamond"></i>
              <p>Users</p>
            </a>
          </li> -->
          <!-- <li>
            <a href="javascript:;">
              <i class="nc-icon nc-pin-3"></i>
              <p>Facebook Leads Form</p>
            </a>
          </li> -->
        </ul>
      </div>
    </div>
    <div class="sidebar-overlay" id="sidebarOverlay"></div>
    <div class="main-panel" style="height: 100vh;">
      <!-- ===m=== Sidebar code started ===m=== -->
      <!-- Modern Navbar -->
      <nav class="navbar navbar-expand-lg navbar-transparent">
        <div class="container-fluid">
          <div class="navbar-wrapper">
            <button type="button" class="mobile-menu-btn" id="mobileSidebarToggle" aria-label="Open menu">
              <i class="fa fa-bars"></i>
            </button>
            <a class="navbar-brand" href="javascript:;">Leads &amp; CRM</a>
          </div>
          <div class="ml-auto">
            <ul class="navbar-nav">
              <li class="nav-item btn-rotate dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown"
                  aria-haspopup="true" aria-expanded="false" aria-label="Account menu">
                  <i class="fa fa-user-circle-o" style="font-size:22px;color:#596171;"></i>
                </a>
                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownMenuLink">
                  <div class="dropdown-header">
                    <strong><?php echo htmlspecialchars($username, ENT_QUOTES, 'UTF-8'); ?></strong>
                  </div>
                  <a class="dropdown-item" href="./leads/logout.php">Logout</a>
                  <?php if (isset($_SESSION['role']) && $_SESSION['role'] == 'superadmin') { ?>
                    <a class="dropdown-item" href="./leads/users.php">Add Users</a>
                  <?php } ?>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </nav>
      <!-- End Modern Navbar -->
      <div class="content">

        <div class="page-heading">
          <div>
            <h1>Leads &amp; CRM</h1>
            <p>Manage leads, customer relationships, campaign performance and follow-ups.</p>
          </div>
        </div>

        <div class="dashboard-kpis">
          <div class="kpi-card">
            <div class="kpi-label">Campaign Database</div>
            <div class="kpi-value" id="kpiDatabase">ALL</div>
            <div class="kpi-sub">Current data source</div>
          </div>
          <div class="kpi-card">
            <div class="kpi-label">Date Range</div>
            <div class="kpi-value" id="kpiDateRange">Last 7 Days</div>
            <div class="kpi-sub">Active date filter</div>
          </div>
          <div class="kpi-card">
            <div class="kpi-label">Campaign Source</div>
            <div class="kpi-value" id="kpiSource">All Sources</div>
            <div class="kpi-sub">Current source filter</div>
          </div>
          <div class="kpi-card">
            <div class="kpi-label">Search</div>
            <div class="kpi-value" id="kpiSearch">All Leads</div>
            <div class="kpi-sub">Name, mobile, email or keyword</div>
          </div>
        </div>

        <div class="filter-card">
          <div class="filter-header">
            <div>
              <h4>Lead Filters</h4>
              <span>Refine campaign and lead data</span>
            </div>
          </div>

          <div class="filter-grid">
            <div class="filter-field">
              <label for="from_date">Date</label>
              <input type="text" class="form-control" placeholder="DD/MM/YYYY - DD/MM/YYYY" id="from_date">
              <div class="till-date-wrap">
                <input type="checkbox" id="till_date" value="1">
                <label for="till_date">Till Date</label>
              </div>
            </div>

            <div class="filter-field"<?php echo $showDatabaseFilter ? '' : ' style="display:none"'; ?>>
              <label for="campaign_database">Campaign Database</label>
              <select class="form-control" id="campaign_database">
                <?php foreach ($campaignDatabaseOptions as $value => $label) { ?>
                  <option value="<?php echo htmlspecialchars($value, ENT_QUOTES, 'UTF-8'); ?>" <?php echo $value === 'all' ? 'selected' : ''; ?>>
                    <?php echo htmlspecialchars($label, ENT_QUOTES, 'UTF-8'); ?>
                  </option>
                <?php } ?>
              </select>
            </div>

            <div class="filter-field">
              <label for="camp_source">Campaign Source</label>
              <select class="form-control" id="camp_source">
                <option value="">All Sources</option>
                <?php foreach ($campaignSources as $campaignSource) { ?>
                  <option value="<?php echo htmlspecialchars($campaignSource, ENT_QUOTES, 'UTF-8'); ?>">
                    <?php echo htmlspecialchars($campaignSource, ENT_QUOTES, 'UTF-8'); ?>
                  </option>
                <?php } ?>
              </select>
            </div>

            <div class="filter-field">
              <label for="Campaign_sub_source">Campaign Subsource</label>
              <select class="form-control" id="Campaign_sub_source">
                <option value="">All Subsources</option>
                <?php foreach ($campaignSubSources as $campaignSubSource) { ?>
                  <option value="<?php echo htmlspecialchars($campaignSubSource, ENT_QUOTES, 'UTF-8'); ?>">
                    <?php echo htmlspecialchars($campaignSubSource, ENT_QUOTES, 'UTF-8'); ?>
                  </option>
                <?php } ?>
              </select>
            </div>

            <div class="filter-field">
              <label for="f_lead_status">Lead Status</label>
              <select class="form-control" id="f_lead_status">
                <option value="">All Statuses</option>
                <?php foreach (PQ_LEAD_STATUS_FILTERS as $stKey => $stLabel) { ?>
                  <option value="<?php echo htmlspecialchars($stKey, ENT_QUOTES, 'UTF-8'); ?>"><?php echo htmlspecialchars($stLabel, ENT_QUOTES, 'UTF-8'); ?></option>
                <?php } ?>
              </select>
            </div>

            <div class="filter-field">
              <label for="keyword">Search</label>
              <input type="text" class="form-control" id="keyword" placeholder="Name / Mobile / Email / Keyword">
            </div>

            <div class="filter-actions">
              <button class="btn-modern btn-search" id="search" type="button">
                <i class="fa fa-search"></i>&nbsp; Search
              </button>
              <button class="btn-modern btn-reset" id="reset" type="button">Reset</button>
            </div>
          </div>
        </div>

        <div class="workspace-card">
          <div class="tab">
            <button class="tablinks active" onclick="openCity(event, 'Visualization')">
              <i class="fa fa-bar-chart"></i>&nbsp; Visualization
            </button>
            <button class="tablinks" onclick="openCity(event, 'Leads')">
              <i class="fa fa-users"></i>&nbsp; Leads
            </button>
            <button class="tablinks" id="follow_up" onclick="openCity(event, 'followup')">
              <i class="fa fa-clock-o"></i>&nbsp; Today's Followup
            </button>
          </div>

          <div id="Visualization" class="tabcontent" style="display: block;">
            <div class="leads-toolbar">
              <div>
                <h3>Execution Dashboard</h3>
                <span style="display:block;margin-top:4px;color:#89919d;font-size:11px;">
                  Lead flow, execution status, daily volume and campaign drilldown
                </span>
              </div>
            </div>

            <div class="charts-grid">
              <div class="chart-card">
                <div id="funnelChart" style="height:360px;width:100%;"></div>
              </div>

              <div class="chart-card">
                <div id="statusChart" style="height:360px;width:100%;"></div>
              </div>

              <div class="chart-card chart-wide">
                <div id="dailyTrendChart" style="height:330px;width:100%;"></div>
              </div>

              <div class="chart-card chart-wide">
                <div id="campaignDrilldownChart" style="height:430px;width:100%;"></div>
              </div>
            </div>
          </div>

          <div id="Leads" class="tabcontent">
            <div class="leads-toolbar">
              <div>
                <h3>Leads</h3>
              </div>
              <div class="toolbar-actions">
                <?php if (pqCan('leads', 'export')) { ?>
                <button class="btn-modern btn-reset" id="export" type="button">
                  <i class="fa fa-download"></i>&nbsp; Export
                </button>
                <?php } if (pqCan('leads', 'edit')) { ?>
                <a class="btn-modern btn-search" href="./leads/add-lead.php"<?php echo $isEmbed ? ' target="_blank"' : ''; ?>>
                  <i class="fa fa-plus"></i>&nbsp; Add Lead
                </a>
                <?php } ?>
              </div>
            </div>

            <div class="table-wrap">
              <table class="display table" id="showRecords">
                <thead>
                  <tr>
                    <th data-priority="1">Sr.No.</th>
                    <th data-priority="2">Date</th>
                    <th data-priority="3">Name</th>
                    <th data-priority="4">Email</th>
                    <th data-priority="6">Mobile</th>
                    <th data-priority="7">Actions</th>
                  </tr>
                </thead>
                <tbody class="body-data"></tbody>
              </table>
            </div>
          </div>

          <div id="followup" class="tabcontent">
            <div class="leads-toolbar">
              <div>
                <h3>Today's Followup</h3>
              </div>
            </div>

            <div class="table-wrap">
              <table class="display table" id="showRecordsFollowup">
                <thead>
                  <tr>
                    <th data-priority="1">Sr.No.</th>
                    <th data-priority="2">Date</th>
                    <th data-priority="3">Name</th>
                    <th data-priority="4">Email</th>
                    <th data-priority="6">Mobile</th>
                    <th data-priority="7">Actions</th>
                  </tr>
                </thead>
                <tbody class="body-data-followup"></tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- The Modal -->
  <div class="modal" id="myModal">
    <div class="modal-dialog">
      <div class="modal-content">

        <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-title">Curd</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>

        <!-- Modal body -->
        <div class="modal-body">
          <div class="col-md-12 row">
            <div class="form-group col-md-12">
              <label for="result">Result:</label>
              <select class="form-control" id="result">
                <option>Select Reason</option>
                <option>Call Back</option>
                <option>Call Not Answer</option>
                <option>Interested</option>
                <option>Wrong Number</option>
                <option>Not Interested</option>
              </select>
            </div>
            <div class="form-group col-md-12">
              <label for="comment">Comments:</label>
              <textarea class="form-control" rows="4" cols="50" placeholder="Add Comments..." id="comment">  </textarea>
            </div>
            <div class="form-group col-md-12">
              <label for="followup_date">Followup Date:</label>
              <input class="form-control" type="datetime-local" id="followup_date" name="followup_date">
              <input type="hidden" id="id" value="0">
            </div>

            <div class="form-group col-md-12">
              <button class="btn btn-primary form-control" id="add_result" style="color: white;background: #424240;">
                ADD</button>
            </div>

          </div>
        </div>

        <!-- Modal footer -->
        <div class="modal-footer">
          <!-- <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button> -->
        </div>

      </div>
    </div>
  </div>



  <!-- The Modal -->
  <div class="modal" id="modal_history">
    <div class="modal-dialog">
      <div class="modal-content">

        <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-title">Curd</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>

        <!-- Modal body -->
        <div class="modal-body">
          <div class="col-md-12 row">
            <table class="">
              <thead>
                <th>Sr No</th>
                <th>Result</th>
                <th>Comments</th>
                <th>Followup date</th>
                <th>Created date</th>
              </thead>
              <tbody class="body-logs">

              </tbody>
            </table>

          </div>
        </div>

        <!-- Modal footer -->
        <div class="modal-footer">
          <!-- <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button> -->
        </div>

      </div>
    </div>
  </div>






  <!--   Core JS Files   -->
  <link rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/css/bootstrap-datepicker.css"
    integrity="sha512-Fppbdpv9QhevzDE+UHmdxL4HoW8HantO+rC8oQB2hCofV+dWV2hePnP5SgiWR1Y1vbJeYONZfzQc5iII6sID2Q=="
    crossorigin="anonymous" referrerpolicy="no-referrer" />

  <script src="./assets/js/core/jquery.min.js"></script>
  <script src="https://code.jquery.com/ui/1.13.2/jquery-ui.min.js"></script>
  <script type="text/javascript" src="https://cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>
  <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js"></script>
  <script src="assets/js/highcharts/highcharts.js"></script>
  <script src="assets/js/highcharts/data.js"></script>
  <script src="assets/js/highcharts/drilldown.js"></script>
  <script src="assets/js/highcharts/exporting.js"></script>
  <script src="assets/js/highcharts/export-data.js"></script>
  <script src="assets/js/highcharts/accessibility.js"></script>
  <script src="https://code.iconify.design/3/3.1.1/iconify.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/js/bootstrap-datepicker.min.js"
    integrity="sha512-T/tUfKSV1bihCnd+MxKD0Hm1uBBroVYBOYSk1knyvQ9VyZJpc/ALb4P0r6ubwVPSGB2GvjeoMAJJImBG12TiaQ=="
    crossorigin="anonymous" referrerpolicy="no-referrer"></script>
  <script src="https://cdn.datatables.net/v/dt/dt-1.10.20/datatables.min.js"></script>
  <script src="https://cdn.datatables.net/buttons/1.6.1/js/dataTables.buttons.min.js"></script>
  <script src="https://cdn.datatables.net/buttons/1.6.1/js/buttons.flash.min.js"></script>
  <script src="https://cdn.datatables.net/buttons/1.6.1/js/buttons.html5.min.js"></script>
  <script src="https://cdn.datatables.net/buttons/1.6.1/js/buttons.print.min.js"></script>
  <script src="https://cdn.datatables.net/fixedcolumns/3.3.0/js/dataTables.fixedColumns.min.js"></script>
  <script src="https://cdn.datatables.net/colreorder/1.5.2/js/dataTables.colReorder.min.js"></script>
  <script src="https://cdn.datatables.net/responsive/2.2.9/js/dataTables.responsive.min.js"></script>
  <script src="./assets/js/core/popper.min.js"></script>
  <script src="./assets/js/core/bootstrap.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.perfect-scrollbar/1.5.5/perfect-scrollbar.min.js"
    integrity="sha512-X41/A5OSxoi5uqtS6Krhqz8QyyD8E/ZbN7B4IaBSgqPLRbWVuXJXr9UwOujstj71SoVxh5vxgy7kmtd17xrJRw=="
    crossorigin="anonymous" referrerpolicy="no-referrer"></script>
  <!--  Google Maps Plugin    -->
  <!-- <script src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script> -->
  <!-- Chart JS -->
  <script src="./assets/js/plugins/chartjs.min.js"></script>
  <!--  Notifications Plugin    -->
  <script src="./assets/js/plugins/bootstrap-notify.js"></script>
  <!-- Control Center for Now Ui Dashboard: parallax effects, scripts for the example pages etc -->
  <script src="./assets/js/paper-dashboard.min.js?v=2.0.1" type="text/javascript"></script>
  <script type="text/javascript">
    //   $('#from_date').datepicker({
    //     changeMonth: true,
    //     changeYear: true,
    //     showButtonPanel: true,
    //     autoclose:true,
    //     format: 'dd-mm-yyyy'
    // });
    //    $('#to_date').datepicker({
    //     changeMonth: true,
    //     changeYear: true,
    //     showButtonPanel: true,
    //     autoclose:true,
    //     format: 'dd-mm-yyyy'
    // });
    // $('#followup_date').datetimepicker();

    var start = moment().subtract(6, 'days');
    var end = moment();

    function cb(start, end) {
      $('#from_date span').html(start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'));
    }

    $('#from_date').daterangepicker({
      startDate: start,
      endDate: end,

      locale: {
        format: 'DD/MM/YYYY'
      },
      ranges: {
        'Today': [moment(), moment()],
        'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
        'Last 7 Days': [moment().subtract(6, 'days'), moment()],
        'Last 30 Days': [moment().subtract(29, 'days'), moment()],
        'This Month': [moment().startOf('month'), moment().endOf('month')],
        'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')],
        'Last 1 Year': [moment().subtract(1, 'year').add(1, 'day'), moment()],
        'All Time': [moment(window.PQ_ALL_SINCE || moment().subtract(1, 'year').format('YYYY-MM-DD'), 'YYYY-MM-DD'), moment()]   // from the project's first lead (app/Core/access.php pqAllTimeSince)
      }
    }, cb);

    cb(start, end);


    $(document).on('click', '#reset', function () {
      // Reset all filters to their default state.
      $('#from_date').val('');
      $('#till_date').prop('checked', false).trigger('change');
      $('#campaign_database').val('all');
      $('#camp_source').val('');
      $('#Campaign_sub_source').val('');
      $('#f_lead_status').val('');
      $('#keyword').val('');

      var database = getSelectedDatabase();
      get_data('', '', '', '', '1', '', database);
      get_records('1', database);
      updateDashboardKpis();
    })

    $(document).on('click', '#follow_up', function () {

      get_todays_followup();

    })
    function getSelectedDatabase() {
      return $('#campaign_database').val() || 'all';
    }

    function updateDashboardKpis() {
      var dbLabel = $('#campaign_database option:selected').text().trim() || 'ALL';
      var source = $('#camp_source option:selected').text().trim() || 'All Sources';
      var keyword = $('#keyword').val().trim();

      $('#kpiDatabase').text(dbLabel.toUpperCase());
      $('#kpiSource').text(source.length > 20 ? source.substring(0, 20) + '…' : source);
      $('#kpiSearch').text(keyword ? (keyword.length > 20 ? keyword.substring(0, 20) + '…' : keyword) : 'All Leads');

      if ($('#till_date').is(':checked')) {
        $('#kpiDateRange').text('Till Date');
      } else if ($('#from_date').val()) {
        $('#kpiDateRange').text($('#from_date').val());
      } else {
        $('#kpiDateRange').text('Last 7 Days');
      }
    }

    $(document).on('change', '#campaign_database, #camp_source, #Campaign_sub_source, #f_lead_status, #till_date', updateDashboardKpis);
    $(document).on('input', '#keyword', updateDashboardKpis);

    $(document).on('change', '#campaign_database', function () {
      var database = getSelectedDatabase();
      get_data(
        $('#from_date').val(),
        $('#camp_source').val(),
        $('#Campaign_sub_source').val(),
        $('#keyword').val(),
        '1',
        $('#till_date').is(':checked') ? 1 : '',
        database
      );
      get_records('1', database);
    });

    $(document).on('click', '#mobileSidebarToggle', function () {
      $('.sidebar').toggleClass('mobile-open');
      $('#sidebarOverlay').toggleClass('active');
    });

    $(document).on('click', '#sidebarOverlay, .sidebar a', function () {
      if (window.innerWidth <= 991) {
        $('.sidebar').removeClass('mobile-open');
        $('#sidebarOverlay').removeClass('active');
      }
    });

    updateDashboardKpis();

    get_data('', '', '', '', '1', '', getSelectedDatabase());
    get_records('1', getSelectedDatabase());

    $(document).on('click', '#search', function () {

      var from_date = $("#from_date").val();
      var camp_source = $("#camp_source").val();
      var Campaign_sub_source = $("#Campaign_sub_source").val();
      var keyword = $("#keyword").val();
      var database = getSelectedDatabase();
      var id = '1';
      var till_date = '';
      if ($('#till_date').is(':checked')) {
        till_date = 1;
      }
      get_data(from_date, camp_source, Campaign_sub_source, keyword, id, till_date, database);
      get_records(id, database);
      updateDashboardKpis();

    })

    // $( ".body-data" ).accordion({
    //   collapsible: true
    // });


    function get_data(from_date, camp_source, Campaign_sub_source, keyword, page, till_date, database) {

      $.ajax({
        url: 'leads/get_data.php',
        type: 'POST',
        dataType: 'json',
        data: {
          from_date: from_date,
          camp_source: camp_source,
          Campaign_sub_source: Campaign_sub_source,
          lead_status: $('#f_lead_status').val() || '',
          keyword: keyword,
          page: page,
          till_date: till_date,
          database: database
        },
        cache: false,
        beforeSend: function () {
          $("#funnelChart").html('<div class="chart-loading">Loading execution data...</div>');
          $("#statusChart").html('<div class="chart-loading">Loading execution data...</div>');
          $("#dailyTrendChart").html('<div class="chart-loading">Loading daily trend...</div>');
          $("#campaignDrilldownChart").html('<div class="chart-loading">Loading campaign data...</div>');
        },
        success: function (returnhtml) {
          if (!returnhtml || typeof returnhtml !== 'object') {
            showChartEmpty('funnelChart', 'Unable to read analytics response.');
            showChartEmpty('statusChart', 'Unable to read analytics response.');
            showChartEmpty('dailyTrendChart', 'Unable to read analytics response.');
            showChartEmpty('campaignDrilldownChart', 'Unable to read analytics response.');
            return;
          }

          renderLeadFunnel(returnhtml.leadFunnel || []);
          renderLeadStatusDistribution(returnhtml.leadStatusDistribution || []);
          renderDailyLeadTrend(returnhtml.dailyLeadTrend || []);
          renderCampaignDrilldown(
            returnhtml.campaignHierarchy || [],
            returnhtml.campaignDrilldown || []
          );
        },
        error: function (xhr) {
          console.error('get_data.php failed:', xhr.responseText);

          var message = 'Unable to load analytics.';
          try {
            var response = JSON.parse(xhr.responseText || '{}');
            if (response.message) {
              message = response.message;
            }
          } catch (e) { }

          showChartEmpty('funnelChart', message);
          showChartEmpty('statusChart', message);
          showChartEmpty('dailyTrendChart', message);
          showChartEmpty('campaignDrilldownChart', message);
        }
      });
    }

    function escapeHtml(value) {
      return $('<div>').text(value == null ? '' : String(value)).html();
    }

    function maskEmail(email) {
      email = email || '';
      var at = email.lastIndexOf('@');
      if (at <= 0) return email;
      var prefix = email.substring(0, at);
      var postfix = email.substring(at);
      if (prefix.length <= 2) return prefix.charAt(0) + '*' + postfix;
      return prefix.charAt(0) + '*'.repeat(Math.max(1, prefix.length - 2)) + prefix.charAt(prefix.length - 1) + postfix;
    }

    function maskMobile(mobile) {
      // stars + the last 5 digits (same rule as pqMaskMobile in app/Core/db.php)
      var d = String(mobile || '').replace(/\D+/g, '');
      if (!String(mobile || '').trim() || String(mobile).indexOf('*') >= 0) return String(mobile || '');   // empty / masked already
      if (d.length <= 5) return '*'.repeat(Math.max(5, d.length));
      return '*'.repeat(d.length - 5) + d.slice(-5);
    }

    function leadDetailHtml(i) {
      /*
       * Fields are based strictly on the supplied `lead` table schema.
       * Empty / NULL fields are not rendered.
       */
      var fields = [
        ['Lead ID', i.id],
        ['Country Code', i.countrycode],
        ['Campaign Source', i.campaignsource],
        ['Campaign Sub Source', i.campaignsubsource],
        ['Placement', i.placement],
        ['Device', i.device],
        ['Ad Creative', i.adcreative],
        ['Ad Set', i.adset],
        ['IP Address', i.ip_address],
        ['MF Medium', i.mf_medium],
        ['MF Campaign ID', i.mf_campaignid],

        ['BHK Type', i.bhktype],
        ['Purpose', i.purpose],
        ['Visit Possible On', i.visitpossibleon],
        ['Favourite Destination', i.favdestination],
        ['Villa Type', i.villatype],
        ['Project Interest', i.projinterest],

        ['Form ID', i.form_id],
        ['Ad ID', i.ad_id],
        ['Leadgen ID', i.leadgen_id],
        ['Page ID', i.page_id],
        ['Keyword', i.keyword],
        ['Capture From', i.capturefromname],
        ['Website', i.websitename],

        ['UTM Medium', i.utmM],
        ['UTM Campaign', i.utmC],
        ['Ad Name', i.ad_name],
        ['Ad Set Name', i.adset_name],
        ['Campaign Name', i.campaign_name],

        ['Duplicate', i.duplicate],
        ['Lead Status', i.lead_status],
        ['Last Reason', i.reason || i.last_reson],
        ['GCLID', i.gclid],

        ['UTM Campaign ID', i.utm_campaignid],
        ['UTM Campaign Name', i.utm_campaignname],
        ['UTM Ad Group ID', i.utm_adgroupid],
        ['UTM Ad Group Name', i.utm_adgroupname],
        ['UTM Ad ID', i.utm_adid],
        ['UTM Ad Name', i.utm_adname],

        ['Database', i.database_label || LEAD_DB_LABELS[i._database] || '']
      ];

      var visibleFields = fields.filter(function (field) {
        if (field[1] === null || field[1] === undefined) return false;
        return String(field[1]).trim() !== '';
      });

      if (!visibleFields.length) {
        return '<div class="lead-detail-grid">' +
          '<div class="lead-detail-item">' +
          '<span>No additional lead information available.</span>' +
          '</div>' +
          '</div>';
      }

      var html = '<div class="lead-detail-grid">';

      visibleFields.forEach(function (field) {
        html += '<div class="lead-detail-item">' +
          '<strong>' + escapeHtml(field[0]) + '</strong>' +
          '<span>' + escapeHtml(field[1]) + '</span>' +
          '</div>';
      });

      html += '</div>';

      return html;
    }


    function initLeadsDataTable() {
      if ($.fn.DataTable.isDataTable('#showRecords')) {
        $('#showRecords').DataTable().clear().destroy();
      }

      // Remove any DataTables-generated child rows left by a previous instance.
      $('#showRecords tbody tr.child').remove();

      $('#showRecords').DataTable({
        responsive: true,
        autoWidth: false,
        pageLength: 25,
        lengthMenu: [[10, 25, 50, 100], [10, 25, 50, 100]],
        order: [[1, 'desc']],
        columnDefs: [
          {targets: 0, responsivePriority: 5, width: '50px'},
          {targets: 1, responsivePriority: 4, width: '130px'},
          {targets: 2, responsivePriority: 1},
          {targets: 3, responsivePriority: 6},
          {targets: 4, responsivePriority: 5},
          {targets: 5, responsivePriority: 1, orderable: false, searchable: false, width: '82px'}
        ],
        language: {search: '', searchPlaceholder: 'Search loaded leads...', lengthMenu: 'Show _MENU_', info: 'Showing _START_ to _END_ of _TOTAL_ leads', infoEmpty: 'No leads found', zeroRecords: 'No matching leads found', paginate: {previous: '‹', next: '›'}}
      });
    }

    function initFollowupDataTable() {
      if ($.fn.DataTable.isDataTable('#showRecordsFollowup')) $('#showRecordsFollowup').DataTable().destroy();
      $('#showRecordsFollowup').DataTable({
        responsive: true,
        autoWidth: false,
        pageLength: 10,
        lengthMenu: [[10, 25, 50], [10, 25, 50]],
        order: [[1, 'desc']],
        columnDefs: [
          {targets: 0, responsivePriority: 5}, {targets: 1, responsivePriority: 4},
          {targets: 2, responsivePriority: 1}, {targets: 3, responsivePriority: 6},
          {targets: 4, responsivePriority: 5}, {targets: 5, responsivePriority: 1, orderable: false, searchable: false}
        ],
        language: {search: '', searchPlaceholder: 'Search followups...', lengthMenu: 'Show _MENU_', info: 'Showing _START_ to _END_ of _TOTAL_ followups', infoEmpty: 'No followups found', zeroRecords: 'No matching followups found', paginate: {previous: '‹', next: '›'}}
      });
    }

    function get_records(id, database) {
      var from_date = $('#from_date').val();
      var camp_source = $('#camp_source').val();
      var Campaign_sub_source = $('#Campaign_sub_source').val();
      var keyword = $('#keyword').val();
      var till_date = $('#till_date').is(':checked') ? 1 : '';

      $.ajax({
        url: 'leads/get_records.php',
        type: 'POST',
        dataType: 'json',
        cache: false,
        data: {
          from_date: from_date,
          camp_source: camp_source,
          Campaign_sub_source: Campaign_sub_source,
          lead_status: $('#f_lead_status').val() || '',
          keyword: keyword,
          till_date: till_date,
          database: database
        },
        beforeSend: function () {
          if ($.fn.DataTable.isDataTable('#showRecords')) {
            $('#showRecords').DataTable().clear().destroy();
          }

          // DataTables does not support colspan cells inside tbody rows.
          // Always render exactly 6 cells while loading.
          $('.body-data').html(
            '<tr class="dt-message-row">' +
            '<td></td>' +
            '<td></td>' +
            '<td class="text-center" style="padding:30px!important;color:#7a8290;">Loading leads...</td>' +
            '<td></td>' +
            '<td></td>' +
            '<td></td>' +
            '</tr>'
          );
        },
        success: function (returnhtml) {
          var html = '';
          var cnt = 1;

          if (!Array.isArray(returnhtml) || returnhtml.length === 0) {
            var emptyMessage = 'No leads found for the selected filters.';

            // If PHP returned an error object, keep the actual error visible in DevTools.
            if (returnhtml && !Array.isArray(returnhtml) && returnhtml.error) {
              emptyMessage = 'Unable to load leads.';
              console.error('get_records.php returned an error:', returnhtml);
            }

            // DataTables requires every tbody row to contain exactly 6 cells.
            $('.body-data').html(
              '<tr class="dt-message-row">' +
              '<td></td>' +
              '<td></td>' +
              '<td class="text-center" style="padding:35px!important;color:#7a8290;">' +
              escapeHtml(emptyMessage) +
              '</td>' +
              '<td></td>' +
              '<td></td>' +
              '<td></td>' +
              '</tr>'
            );

            initLeadsDataTable();
            return;
          }

          $.each(returnhtml, function (arr, i) {
            // masked on the server when this user may not see them (leads/get_records.php)
            var finalEmail = i.email || '';
            var finalMobile = i.mobile || '';

            // row key for Edit / Add Response / History: an encrypted reference, not the mobile number
            var mobile = escapeHtml(i.ref || i.mobile || '');

            var databaseLabel =
              i.database_label ||
              LEAD_DB_LABELS[i._database] ||
              '';

            html += '<tr class="lead-row" data-database="' +
              escapeHtml(i._database || '') +
              '">';

            html += '<td>' + cnt + '</td>';

            html += '<td>' +
              escapeHtml(i.createddate || '') +
              '</td>';

            html += '<td>' +
              '<span class="lead-name">' +
              escapeHtml(i.name || '') +
              '</span>' +
              '<span class="lead-sub">' +
              escapeHtml(databaseLabel) +
              '</span>' +
              '</td>';

            html += '<td>' +
              escapeHtml(finalEmail) +
              '</td>';

            html += '<td>' +
              escapeHtml(finalMobile) +
              '</td>';

            html += '<td>';

            html += '<div class="lead-actions">';

            html += '<button type="button" ' +
              'class="action-btn more-actions" ' +
              'title="More actions" ' +
              'aria-label="More actions">' +
              '<i class="fa fa-ellipsis-v"></i>' +
              '</button>';

            html += '<div class="action-menu">';

            html += '<button type="button" ' +
              'data-id="' + mobile + '" ' +
              'data-database="' + escapeHtml(i._database || '') + '" ' +
              'id="edit_lead">' +
              '<i class="fa fa-edit"></i>' +
              '<span>Edit Lead</span>' +
              '</button>';

            html += '<button type="button" ' +
              'data-id="' + mobile + '" ' +
              'data-database="' + escapeHtml(i._database || '') + '" ' +
              'data-toggle="modal" ' +
              'data-target="#myModal" ' +
              'id="add">' +
              '<i class="fa fa-plus"></i>' +
              '<span>Add Response</span>' +
              '</button>';

            html += '<button type="button" ' +
              'data-id="' + mobile + '" ' +
              'data-database="' + escapeHtml(i._database || '') + '" ' +
              'data-toggle="modal" ' +
              'data-target="#modal_history" ' +
              'id="history">' +
              '<i class="fa fa-history"></i>' +
              '<span>View History</span>' +
              '</button>';

            html += '</div>';
            html += '</div>';

            /*
             * DataTables child row displays this HTML when the main
             * lead row is clicked.
             */
            html += '<div class="lead-details-template" style="display:none;">' +
              leadDetailHtml(i) +
              '</div>';

            html += '</td>';
            html += '</tr>';

            cnt++;
          });

          $('.body-data').html(html);

          initLeadsDataTable();
        },
        error: function (xhr) {
          $('.body-data').html(
            '<tr class="dt-message-row">' +
            '<td></td>' +
            '<td></td>' +
            '<td class="text-center" style="padding:35px!important;color:#dc3545;">' +
            'Unable to load leads. Please try again.' +
            '</td>' +
            '<td></td>' +
            '<td></td>' +
            '<td></td>' +
            '</tr>'
          );

          initLeadsDataTable();

          console.error(
            'get_records.php failed:',
            xhr.status,
            xhr.responseText
          );
        }
      });
    }


    get_todays_followup();

    function get_todays_followup() {

      $.ajax({
        url: 'leads/get_followups.php',
        type: 'POST',
        dataType: "json",
        cache: false,
        success: function (returnhtml) {
          //console.log(returnhtml) ;   
          var html = '';
          var cnt = 0;
          $.each(returnhtml, function (arr, i) {
            cnt++;
            html += ' <tr data-toggle="collapse" data-target="#followup' + escapeHtml(i.id_map || i.id || '') + '" class="accordion-toggle">';
            html += ' <td>' + cnt + '</td>';
            html += ' <td>' + escapeHtml(i.createddate || '') + '</td>';
            html += ' <td>' + escapeHtml(i.name || '') + '</td>';
            html += ' <td>' + escapeHtml(i.email || '') + '</td>';
            html += ' <td>' + escapeHtml(i.mobile || '') + '</td>';
            html += ' <td><button data-id="' + escapeHtml(i.ref || '') + '" class="btn btn-primary btn-sm" style="color: white;background: #424240;margin-right: 5px;"  data-toggle="modal" data-target="#myModal" id="add" data-toggle="tooltip" data-html="true" title="Add Response"><i class="fa fa-plus"> </i></button><button  data-id="' + i.mobile + '" data-toggle="modal" data-target="#modal_history" style="color: white;background: #424240;" class="btn btn-primary btn-sm" id="history" data-toggle="tooltip" data-html="true" title="View History"><i class="fa fa-history"></i></button></td> ';
            html += '</tr>';
            html += '<tr class="p">'
            html += '  <td colspan="6" class="hiddenRow" style="text-align: left;">'
            html += '     <div class="accordian-body collapse" id="followup' + escapeHtml(i.id_map || i.id || '') + '">'

            html += '      <p class="col-lg-4" style="float: left;"><strong>Reason : </strong><span>' + escapeHtml(i.reason || '') + '</span></p>'
            html += '      <p class="col-lg-4" style="float: left;"><strong>comment : </strong><span>' + escapeHtml(i.comment || '') + '</span></p>'
            html += '     </div>'
            html += '  </td>'
            html += '</tr>';
            // html+= ' <tr>';
            // html+= ' <td>'+cnt+'</td>';
            // html+= ' <td>'+i.createddate+'</td>';
            // html+= ' <td>'+i.name+'</td>';
            // html+= ' <td>'+i.email+'</td>';
            // html+= ' <td>'+i.countrycode+'</td>';
            // html+= ' <td>'+i.mobile+'</td>';
            // html+= ' <td>'+i.campaignsource+'</td>';
            // html+= ' <td>'+i.campaignsubsource+'</td>';
            // html+= ' <td>'+i.keyword+'</td>';
            // html+= ' <td>'+i.capturefromname+'</td>';
            // html+= ' <td>'+i.websitename+'</td>';
            // html+= ' <td>'+i.createddate+'</td>';
            // html+= ' <td>'+i.utmM+'</td>';
            // html+= ' <td>'+i.utmC+'</td>';
            // html+= ' <td>'+i.duplicate+'</td>'; 
            // html+= ' <td>'+i.reason+'</td>';
            // html+= ' <td><button data-id="'+i.mobile+'" class="btn btn-primary btn-sm" style="color: white;background: #424240;margin-right: 5px;"  data-toggle="modal" data-target="#myModal" id="add"><i class="fa fa-plus"> </i></button><button  data-id="'+i.mobile+'" data-toggle="modal" data-target="#modal_history" style="color: white;background: #424240;" class="btn btn-primary btn-sm" id="history"><i class="fa fa-history"></i></button></td> ';
            // html+= '</tr>';
          })

          html += '</tr>';
          $(".body-data-followup").html(html);


        }
      });
    }

    function showChartEmpty(containerId, message) {
      $('#' + containerId).html(
        '<div style="height:100%;display:flex;align-items:center;justify-content:center;' +
        'text-align:center;color:#89919d;font-size:12px;">' +
        escapeHtml(message || 'No data available.') +
        '</div>'
      );
    }

    function renderLeadFunnel(data) {
      if (!Array.isArray(data) || !data.length) {
        showChartEmpty('funnelChart', 'No execution funnel data available.');
        return;
      }

      Highcharts.chart('funnelChart', {
        chart: {
          type: 'bar',
          backgroundColor: 'transparent'
        },
        title: {
          text: 'Lead Funnel',
          align: 'left',
          style: {
            fontSize: '16px',
            fontWeight: '700'
          }
        },
        subtitle: {
          text: 'Lead progression based on available execution data',
          align: 'left',
          style: {
            fontSize: '11px'
          }
        },
        xAxis: {
          type: 'category',
          lineWidth: 0,
          tickWidth: 0
        },
        yAxis: {
          min: 0,
          title: {
            text: 'Leads'
          },
          allowDecimals: false
        },
        legend: {
          enabled: false
        },
        tooltip: {
          pointFormat: '<b>{point.y}</b> leads'
        },
        plotOptions: {
          series: {
            borderWidth: 0,
            pointPadding: 0.08,
            dataLabels: {
              enabled: true,
              format: '{point.y}'
            }
          }
        },
        series: [{
          name: 'Leads',
          data: data.map(function (item) {
            return {
              name: item.name,
              y: Number(item.y || 0)
            };
          })
        }],
        credits: {
          enabled: false
        }
      });
    }

    function renderLeadStatusDistribution(data) {
      if (!Array.isArray(data) || !data.length) {
        showChartEmpty('statusChart', 'No lead status data available.');
        return;
      }

      Highcharts.chart('statusChart', {
        chart: {
          type: 'pie',
          backgroundColor: 'transparent'
        },
        title: {
          text: 'Lead Status Distribution',
          align: 'left',
          style: {
            fontSize: '16px',
            fontWeight: '700'
          }
        },
        subtitle: {
          text: 'Based on the lead_status field',
          align: 'left',
          style: {
            fontSize: '11px'
          }
        },
        tooltip: {
          pointFormat: '<b>{point.y}</b> leads ({point.percentage:.1f}%)'
        },
        plotOptions: {
          pie: {
            innerSize: '58%',
            allowPointSelect: true,
            cursor: 'pointer',
            showInLegend: true,
            dataLabels: {
              enabled: false
            }
          }
        },
        legend: {
          layout: 'vertical',
          align: 'right',
          verticalAlign: 'middle',
          itemStyle: {
            fontSize: '10px',
            fontWeight: '500'
          }
        },
        series: [{
          name: 'Leads',
          data: data.map(function (item) {
            return {
              name: item.name,
              y: Number(item.y || 0)
            };
          })
        }],
        credits: {
          enabled: false
        }
      });
    }

    function renderDailyLeadTrend(data) {
      if (!Array.isArray(data) || !data.length) {
        showChartEmpty('dailyTrendChart', 'No daily lead data available.');
        return;
      }

      Highcharts.chart('dailyTrendChart', {
        chart: {
          type: 'line',
          backgroundColor: 'transparent'
        },
        title: {
          text: 'Daily Lead Trend',
          align: 'left',
          style: {
            fontSize: '16px',
            fontWeight: '700'
          }
        },
        subtitle: {
          text: 'Lead volume across the selected date range',
          align: 'left',
          style: {
            fontSize: '11px'
          }
        },
        xAxis: {
          type: 'category',
          categories: data.map(function (item) {
            var date = new Date(item.date + 'T00:00:00');
            if (isNaN(date.getTime())) return item.date;

            return date.toLocaleDateString('en-IN', {
              day: '2-digit',
              month: 'short'
            });
          })
        },
        yAxis: {
          min: 0,
          allowDecimals: false,
          title: {
            text: 'Leads'
          }
        },
        tooltip: {
          valueSuffix: ' leads'
        },
        legend: {
          enabled: false
        },
        plotOptions: {
          line: {
            lineWidth: 3,
            marker: {
              enabled: true,
              radius: 4
            }
          }
        },
        series: [{
          name: 'Leads',
          data: data.map(function (item) {
            return Number(item.y || 0);
          })
        }],
        credits: {
          enabled: false
        }
      });
    }

    function renderCampaignDrilldown(topLevel, drilldownSeries) {
      if (!Array.isArray(topLevel) || !topLevel.length) {
        showChartEmpty('campaignDrilldownChart', 'No UTM campaign data available.');
        return;
      }

      Highcharts.chart('campaignDrilldownChart', {
        chart: {
          type: 'column',
          backgroundColor: 'transparent'
        },
        title: {
          text: 'Campaign → Ad Group → Ad',
          align: 'left',
          style: {
            fontSize: '16px',
            fontWeight: '700'
          }
        },
        subtitle: {
          text: 'Click a campaign, then an ad group to drill into individual ads',
          align: 'left',
          style: {
            fontSize: '11px'
          }
        },
        xAxis: {
          type: 'category'
        },
        yAxis: {
          min: 0,
          allowDecimals: false,
          title: {
            text: 'Leads'
          }
        },
        legend: {
          enabled: false
        },
        tooltip: {
          pointFormat: '<b>{point.y}</b> leads'
        },
        plotOptions: {
          series: {
            borderWidth: 0,
            dataLabels: {
              enabled: true,
              format: '{point.y}'
            }
          }
        },
        series: [{
          name: 'Campaigns',
          data: topLevel.map(function (item) {
            return {
              name: item.name,
              y: Number(item.y || 0),
              drilldown: item.drilldown
            };
          })
        }],
        drilldown: {
          breadcrumbs: {
            position: {
              align: 'right'
            }
          },
          series: (drilldownSeries || []).map(function (series) {
            return {
              id: series.id,
              name: series.name,
              data: (series.data || []).map(function (item) {
                if (Array.isArray(item)) {
                  return {
                    name: item[0],
                    y: Number(item[1] || 0)
                  };
                }

                return {
                  name: item.name,
                  y: Number(item.y || 0),
                  drilldown: item.drilldown
                };
              })
            };
          })
        },
        credits: {
          enabled: false
        }
      });
    }

    function openCity(evt, cityName) {
      var i, tabcontent, tablinks;
      tabcontent = document.getElementsByClassName("tabcontent");
      for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
      }
      tablinks = document.getElementsByClassName("tablinks");
      for (i = 0; i < tablinks.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(" active", "");
      }
      document.getElementById(cityName).style.display = "block";
      evt.currentTarget.className += " active";
    }

    $(document).on('click', "#add", function () {
      $('.modal input').val('');
      $("#id").val($(this).data('id'));

      var database = $(this).data('database') || getSelectedDatabase();
      $("#id").attr('data-database', database);
    })

    $(document).on('change', "#result", function () {
      if ($(this).val() != 'Select Reason') {
        $("#result").removeClass('error');
      } else {
        $("#result").addClass('error');
      }
    })

    $(document).on('click', "#till_date", function () {
      if ($('#till_date').is(':checked')) {
        $("#from_date").attr('disabled', true);
      } else {
        $("#from_date").attr('disabled', false);
      }
    })


    $(document).on('click', "#add_result", function () {
      var database = getSelectedDatabase();
      var result = $("#result").val();

      if (result.trim() == 'Select Reason') {
        $("#result").addClass('error');
        return false;
      }
      var comment = $("#comment").val();
      var followup_date = $("#followup_date").val();
      var id = $("#id").val();

      $.ajax({
        url: 'leads/insert_curd.php',
        type: 'POST',
        dataType: "json",
        beforeSend: function () {
          $("#add_result").attr('disabled', true);
        },
        cache: false,
        data: {
          result: result,
          comment: comment,
          followup_date: followup_date,
          id: id,
          database: $("#id").attr('data-database') || database

        },
        success: function (returnhtml) {
          $("#add_result").attr('disabled', false);
          if (returnhtml.message == 'success') {
            alert('Record Added successfully');
            $('#myModal').modal('toggle');
          } else {
            alert('Record not added');
          }
          get_records('1', database);



        }
      })
    })

    $(document).on('click', "#history", function () {
      var id = $(this).data('id');
      $.ajax({
        url: 'leads/get_logs.php',
        type: 'POST',
        dataType: "json",
        cache: false,
        data: {
          mobile: id

        },
        success: function (data) {
          var html = '';
          let cnt = 0;
          if (data.length > 0) {
            $.each(data, function (arr, i) {
              cnt++;
              html += '<tr>';
              html += '<td>' + cnt + '</td>';
              html += '<td>' + escapeHtml(i.reason || '') + '</td>';
              html += '<td>' + escapeHtml(i.comment || '') + '</td>';
              html += '<td>' + escapeHtml(i.followup_date || '') + '</td>';
              html += '<td>' + escapeHtml(i.createddt || '') + '</td>';
              html += '</tr>';

            })
          }

          $(".body-logs").html(html);



        }
      })
    })
    // Create the chart

    $(document).on('click', "#export", function () {
      var from_date = $("#from_date").val();
      var camp_source = $("#camp_source").val();
      var Campaign_sub_source = $("#Campaign_sub_source").val();
      var keyword = $("#keyword").val();
      var database = getSelectedDatabase();

      var till_date = '';
      if ($('#till_date').is(':checked')) {
        till_date = 1;
      }
      $("#from_date_form").val(from_date);
      $("#camp_source_form").val(camp_source);
      $("#Campaign_sub_source_form").val(Campaign_sub_source);
      $("#keyword_form").val(keyword);
      $("#lead_status_form").val($('#f_lead_status').val() || '');
      $("#till_date_form").val(till_date);
      $("#campaign_database_form").val(database);

      $("#export_form").submit();
    });


    $(document).on('click', "#edit_lead", function (e) {
      e.preventDefault();
      e.stopPropagation();

      var mobile = $(this).data('id') || '';
      var database = $(this).data('database') || getSelectedDatabase();

      $("#mobile_edit").val(mobile);
      $("#database_edit").val(database);

      $("#edit_form").submit();
    });


    $(document).on('click', '#showRecords tbody tr.lead-row', function (e) {
      // Actions / buttons should not toggle the row details.
      if ($(e.target).closest('.lead-actions, button, a, input, select, textarea, label').length) {
        return;
      }

      $('.action-menu').removeClass('open');

      var table = $('#showRecords').DataTable();
      var tr = $(this);
      var row = table.row(tr);

      if (row.child.isShown()) {
        row.child.hide();
        tr.removeClass('shown');
      } else {
        row.child(
          tr.find('.lead-details-template').html() ||
          '<div class="lead-detail-grid">No additional details available.</div>'
        ).show();
        tr.addClass('shown');
      }
    });

    $(document).on('click', '#showRecords tbody .more-actions', function (e) {
      e.preventDefault();
      e.stopPropagation();
      var menu = $(this).siblings('.action-menu');
      $('.action-menu').not(menu).removeClass('open');
      menu.toggleClass('open');
    });

    $(document).on('click', function (e) {
      if (!$(e.target).closest('.lead-actions').length) {
        $('.action-menu').removeClass('open');
      }
    });
  </script>

  <!-- ===m=== Analytics Script Code ===m=== -->
  <script>
    $(document).ready(function () {
      function sendLog(actionType, dataPayload) {
        dataPayload.action_type = actionType;
        // ===m=== Capture the exact page they are on ===m===
        dataPayload.current_url = window.location.pathname + window.location.search;
        $.ajax({
          url: 'leads/ajax_log_activity.php',
          type: 'POST',
          data: dataPayload,
          error: function () {
            console.log("Background log failed");
          }
        });
      }
      // ===m=== Track logout specifically ===m===
      $(document).on('click', 'a[href*="logout.php"]', function (e) {
        e.preventDefault(); // stop immediate redirect
        e.stopImmediatePropagation();
        let logoutUrl = $(this).attr('href');
        sendLog('logout', {
          clicked_element: 'Logout'

        });
        setTimeout(function () {
          // In embed mode, log out the whole dashboard window, not just the iframe
          (window.top || window).location.href = new URL(logoutUrl, window.location.href).href;
        }, 400);
        return;
      });
      // ===m=== Track clicks ===m===
      $(document).on('click', 'a, button, input[type="button"], input[type="submit"], [role="button"], .nav-link, .dropdown-item,[data-bs-toggle], [data-toggle]', function (e) {
        let $el = $(this);
        // ===m=== Extract element text/label ===m===
        let text = $el.text().trim() || $el.val() || $el.attr('title') || $el.attr('aria-label') || 'Icon/Element';
        let href = $el.attr('href') || '';
        let id = $el.attr('id') || '';
        let textLower = text.toLowerCase();
        // ===m=== Limit text length ===m===
        if (text.length > 50) text = text.substring(0, 50) + '...';
        // ===m=== Ignore useless javascript-only icon clicks ===m===
        if (href.toLowerCase().includes('javascript:') && text === 'Icon/Element') return;
        // ===m=== Detect report export/download actions ===m===
        if (textLower.includes('export') || textLower.includes('download') || href.toLowerCase().includes('export.php')) {
          sendLog('report_download', {
            report_name: text || 'Export Data'
          });
          return;
        }
        if (textLower.includes('search') || $el.attr('id') === 'search-btn' || $el.hasClass('search')) {
          let searchTerm = $el.closest('form, div, .row').find('input[type="text"], input[type="search"]').val();
          if (searchTerm && searchTerm.trim() !== '') {
            sendLog('search', {
              search_term: searchTerm.trim()
            });
            return;
          }
        }
        // ===m=== Prepare element details for logging ===m===
        let elementDetails = text;
        if (href && href !== '#' && !href.toLowerCase().includes('javascript:')) {
          elementDetails += ' (' + href + ')';
        } else if (id) {
          elementDetails += ' (#' + id + ')';
        }
        sendLog('click', {
          clicked_element: elementDetails
        });
      });
      // ===m=== Track search via Enter key in input fields ===m===
      $(document).on('keypress', 'input', function (e) {
        if (e.which == 13) {
          let inputAttributes = ($(this).attr('id') || '') + ($(this).attr('name') || '') + ($(this).attr('placeholder') || '');
          if (inputAttributes.toLowerCase().includes('search')) {
            let searchTerm = $(this).val().trim();
            if (searchTerm !== '') {
              sendLog('search', {
                search_term: searchTerm
              });
            }
          }
        }
      });
      // ===m=== Track dropdown/select value changes ===m===
      $(document).on('change', 'select', function () {
        let selectIdentifier = $(this).attr('name') || $(this).attr('id') || 'Dropdown';
        let selectedText = $(this).find('option:selected').text().trim();
        sendLog('change', {
          changed_element: selectIdentifier,
          new_value: selectedText
        });
      });

    });

    // ===m=== Time Spent Tracking Started ===m===
    const _sessionStart = Date.now();

    function _sendTimeSpent() {
      const seconds = Math.round((Date.now() - _sessionStart) / 1000);
      if (seconds < 2) return; // ignore accidental closes
      navigator.sendBeacon("datalog.php", JSON.stringify({
        event: "time_spent",
        label: "session_duration",
        tag: "",
        id: "",
        class: "",
        href: "",
        page: location.pathname,
        session_id: localStorage.session_id,
        campaignsource: campaignsource,
        campaignsubsource: campaignsubsource,
        client_os: accurateOS,
        client_model: accurateModel,
        time_spent: seconds
      }));
    }

    // Covers tab close, browser close, navigation away
    window.addEventListener("beforeunload", _sendTimeSpent);

    // Covers tab switch, phone lock screen, swipe away on mobile
    document.addEventListener("visibilitychange", function () {
      if (document.visibilityState === "hidden") _sendTimeSpent();
    });

    // Covers iOS Safari which doesn't fire beforeunload reliably
    window.addEventListener("pagehide", _sendTimeSpent);
    // ===m=== Time Spent Tracking Ended ===m===
  </script>
  <!-- ===m=== Analytics Script Code ===m=== -->

  <section id="footer">
    <footer class="footer" style="position: absolute; bottom: 0; width: -webkit-fill-available;">
      <div class="container-fluid">
        <div class="row">
          <nav class="footer-nav">
            <ul>
              <!-- <li><a href="https://www.creative-tim.com" target="_blank">Creative Tim</a></li>
                <li><a href="https://www.creative-tim.com/blog" target="_blank">Blog</a></li>
                <li><a href="https://www.creative-tim.com/license" target="_blank">Licenses</a></li> -->
            </ul>
          </nav>
          <div class="credits ml-auto">
            <span class="copyright">
              © Copyrights @ all rights reserved under SSV Technologies.
            </span>
          </div>
        </div>
      </div>
    </footer>
  </section>
</body>

</html>