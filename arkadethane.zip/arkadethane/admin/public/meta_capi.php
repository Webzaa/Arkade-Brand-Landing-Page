<?php
// ini_set('display_errors', 1);
// ini_set('display_startup_errors', 1);
// error_reporting(E_ALL);

session_start();

// $active_pixel      = $_SESSION['active_pixel_id']   ?? '';
// $active_pixel_name = $_SESSION['active_pixel_name'] ?? '';
// $pixel_history     = $_SESSION['pixel_history']     ?? [];
// unset($_SESSION['active_pixel_id']);
// $active_pixel = '';
// $pixel_history     = $_SESSION['pixel_history']     ?? [];



include dirname(__DIR__) . '/app/Core/db.php';
require_once dirname(__DIR__) . '/app/Leads/header.php';

// ===m=== Load pixel history from DB ===m===
$pixel_history = [];
$ph_res = $conn->query("SELECT id, name FROM `meta_pixel_history` ORDER BY created_at DESC");
while ($ph_row = $ph_res->fetch_assoc()) {
    $pixel_history[] = ['id' => $ph_row['id'], 'name' => $ph_row['name']];
}
$_SESSION['pixel_history'] = $pixel_history; // keep session in sync
unset($_SESSION['active_pixel_id'], $_SESSION['active_pixel_name']);
$active_pixel      = '';
$active_pixel_name = '';

if (!isset($_SESSION["user_logged"])) {
    header("Location: login.php");
    exit;
}
?>
<!DOCTYPE html>
<html>

<head>
    <link rel="icon" type="image/png" href="./assets/img/favicon.png">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- ===m===  ===m=== Fonts and icons Started ===m===  ===m=== -->
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <!-- ===m===  ===m=== Fonts and icons Ended ===m===  ===m=== -->
    <!-- ===m=== ===m=== CSS Started ===m=== ===m=== -->
    <link href="./assets/css/bootstrap.min.css" rel="stylesheet" />
    <link href="./assets/css/paper-dashboard.css?v=2.0.1" rel="stylesheet" />
    <link href="./assets/demo/demo.css" rel="stylesheet" />
    <link href="./assets/css/style.css" rel="stylesheet" />
    <!-- ===m=== DataTables CSS ===m=== -->
    <link href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap4.min.css" rel="stylesheet" />
    <!-- ===m=== ===m=== CSS Ended ===m=== ===m=== -->
    <title> Webzaa Meta CAPI | <?php echo PROJECT_NAME; ?></title>

    <style>
        body {
            background: #f4f6f9;
        }
    </style>
  <?php include dirname(__DIR__) . '/app/Ui/embed_head.php'; ?>
  <style>
    /* phone: pixel ID box and button stacked, full width */
    @media (max-width: 600px) {
      .capi-pixel-row { flex-direction: column; align-items: stretch !important; }
      .capi-pixel-row input { max-width: none !important; width: 100% !important; }
      .capi-pixel-row button { width: 100%; }
    }
  </style>
</head>

<body>

    <div class="wrapper">
        <!-- ===m=== ===m=== Sidebar Code Started ===m=== ===m=== -->
        <div class="sidebar" data-color="white" data-active-color="danger">
            <div class="logo">
                <a href="index.php" class="simple-text logo-normal">
                    <div class="logo-image-big pl-5">
                        <img src="./assets/images/webzaa-logo.png">
                    </div>
                </a>
            </div>
            <div class="sidebar-wrapper">
                <ul class="nav">
                    <li class="">
                        <a href="index.php">
                            <span class="iconify" data-icon="ri:dashboard-fill" style="font-size:24px;float:left;margin-right:12px;line-height:30px;width:34px;text-align:center;position:relative;"></span>
                            <p>Dashboard</p>
                        </a>
                    </li>
                    <li class="">
                        <a href="analytics.php">
                            <i class="nc-icon nc-chart-pie-36"></i>
                            <p>Analytics</p>
                        </a>
                    </li>
                    <li class="active">
                        <a href="meta_capi.php">
                            <span class="iconify" data-icon="ri:meta-fill" style="font-size:24px;float:left;margin-right:12px;line-height:30px;width:34px;text-align:center;position:relative;"></span>
                            <p>Meta CAPI</p>
                        </a>
                    </li>
                    <li class="">
                        <a href="import.php">
                            <i class="nc-icon nc-cloud-upload-94"></i>
                            <p>Import</p>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
        <!-- ===m=== ===m=== Sidebar Code Ended ===m=== ===m=== -->

        <div class="main-panel">
            <!-- ===m=== ===m=== Navbar Code Started ===m=== ===m=== -->
            <nav class="navbar navbar-expand-lg navbar-absolute fixed-top navbar-transparent">
                <div class="container-fluid">
                    <div class="navbar-wrapper analytics-offset">
                        <div class="navbar-toggle">
                            <button type="button" class="navbar-toggler">
                                <span class="navbar-toggler-bar bar1"></span>
                                <span class="navbar-toggler-bar bar2"></span>
                                <span class="navbar-toggler-bar bar3"></span>
                            </button>
                        </div>
                        <a class="analytics_greeting navbar-brand" href="javascript:;"><?php echo $greeting . ', ' . htmlspecialchars($username); ?></a>
                    </div>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navigation"
                        aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-bar navbar-kebab"></span>
                        <span class="navbar-toggler-bar navbar-kebab"></span>
                        <span class="navbar-toggler-bar navbar-kebab"></span>
                    </button>
                    <div class="collapse navbar-collapse justify-content-end" id="navigation">
                        <form>
                            <div class="input-group no-border"></div>
                        </form>
                        <ul class="navbar-nav">
                            <li class="nav-item btn-rotate dropdown">
                                <a class="nav-link dropdown-toggle" href="" id="navbarDropdownMenuLink"
                                    data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <p><span class="d-lg-none d-md-block">Actions</span></p>
                                </a>
                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownMenuLink">
                                    <a class="dropdown-item" href="./leads/logout.php">Logout</a>
                                    <?php if (isset($_SESSION['role']) && $_SESSION['role'] == 'superadmin') { ?>
                                        <a class="dropdown-item" href="./leads/users.php">Add Users</a>
                                    <?php } ?>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>
            <!-- ===m=== ===m=== Navbar Code Ended ===m=== ===m=== -->
            <div class="content">
                <div class="container-fluid">
                    <div class="row justify-content-center">
                        <div class="col-md-10">
                            <div class="capi-card">

                                <!-- ===m=== Top Bar ===m=== -->
                                <div class="capi-topbar">
                                    <div class="capi-topbar-left">
                                        <div class="capi-icon-box">
                                            <svg viewBox="0 0 24 24">
                                                <polyline points="16 16 12 12 8 16" />
                                                <line x1="12" y1="12" x2="12" y2="21" />
                                                <path d="M20.39 18.39A5 5 0 0 0 18 9h-1.26A8 8 0 1 0 3 16.3" />
                                            </svg>
                                        </div>
                                        <div>
                                            <h2>Meta CAPI — CSV Upload</h2>
                                            <!-- <p>Upload a CSV to send conversion events to Meta</p> -->
                                        </div>
                                    </div>
                                    <div style="display:flex;align-items:center;gap:10px;">
                                        <a href="index.php" class="capi-back-btn">
                                            <svg viewBox="0 0 24 24">
                                                <polyline points="15 18 9 12 15 6" />
                                            </svg>
                                            Back
                                        </a>
                                        <span class="capi-badge idle" id="capiBadge">Idle</span>
                                    </div>
                                </div>

                                <!-- ===m=== META PIXEL ID INPUT SECTION ===m=== -->
                                <!-- ===m=== META PIXEL ID INPUT SECTION ===m=== -->
                                <div class="capi-card" id="pixelInputSection" style="margin-bottom: 20px; padding: 20px; border: 1px dashed #ccc; width: 100%; box-sizing: border-box; border-radius: 8px; <?php echo $active_pixel ? 'display:none;' : ''; ?>">
                                    <h5 style="margin-top: 0; font-size: 1rem !important; font-weight: 600; color: #000000" id="pixelInputHeading">Enter Meta Pixel ID</h5>
                                    <!-- <p style="color: #666; font-size: 14px;">Please enter the Meta Pixel ID.</p> -->

                                    <div class="capi-pixel-row" style="display: flex; gap: 10px; align-items: center; flex-wrap: wrap;">
                                        <input type="text" id="pixelIdInput" class="form-control" placeholder="Enter Pixel ID [e.g., 269565121287482]" style="max-width: 300px; height: 42px; border: 1px dashed;">
                                        <button class="capi-btn-primary" id="verifyPixelBtn" onclick="verifyPixel()" style="margin: 0; padding: 10px 20px;">Verify & Add</button>
                                    </div>
                                    <div id="pixelStatusMsg" style="margin-top: 10px; font-weight: bold; font-size: 13px; display: none;"></div>

                                    <!-- ===m=== Saved Pixel History ===m=== -->
                                    <?php if (!empty($pixel_history)): ?>
                                        <div style="margin-top: 18px;" id="pixelHistorySection">
                                            <p style="font-size: 1rem; color: #000000; font-weight: 600; margin-bottom: 8px;">Previously used pixels:</p>
                                            <table id="pixelHistoryTable" class="table table-bordered table-hover" style="width:100%; font-size: 13px;">
                                                <thead style="background: #fce6e0;">
                                                    <tr>
                                                        <th>Pixel Name</th>
                                                        <th>Pixel ID</th>
                                                        <th style="width: 100px; text-align:center;">Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php foreach ($pixel_history as $p): ?>
                                                        <tr>
                                                            <td style="font-size:14px; color:#000; letter-spacing: 1px;"><?php echo htmlspecialchars($p['name']); ?></td>
                                                            <td style="font-size:14px; color:#000; letter-spacing: 1px;"><?php echo htmlspecialchars($p['id']); ?></td>
                                                            <td style="text-align:center;">
                                                                <button onclick="activateSavedPixel('<?php echo htmlspecialchars($p['id']); ?>', '<?php echo htmlspecialchars($p['name']); ?>', event)"
                                                                    style="background:#e9532a; color:#fff; border:none; padding:4px 14px; border-radius:5px; font-size:12px; cursor:pointer; font-weight:600;">
                                                                    Use
                                                                </button>
                                                            </td>
                                                        </tr>
                                                    <?php endforeach; ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    <?php endif; ?>
                                </div>

                                <!-- ===m=== ACTIVE PIXEL DISPLAY SECTION ===m=== -->
                                <div class="verify-pixel" id="verifiedPixelSection" style="margin-bottom: 20px; padding: 0.6rem 0.8rem; display: <?php echo $active_pixel ? 'flex' : 'none'; ?>; justify-content: space-between; align-items: center; margin: 1rem;">
                                    <div>
                                        <h5 style="margin: 0; color: #6a6968; font-size: 1rem; display: flex; align-items: center; gap: 20px;">

                                            <span>
                                                <strong>Pixel Name:</strong>
                                                <span id="displayPixelName" style="font-weight: 400; color:#000000;">
                                                    <?php echo htmlspecialchars($active_pixel_name); ?>
                                                </span>
                                            </span>

                                            <span>
                                                <strong>Pixel ID:</strong>
                                                <span id="displayPixelId" style="font-weight: 400; color:#000000;">
                                                    <?php echo htmlspecialchars($active_pixel); ?>
                                                </span>
                                            </span>

                                        </h5>
                                    </div>

                                    <div style="position: relative; display: inline-block;">
                                        <button onclick="togglePixelDropdown()" style="background:#e9532a; color:#fff; border:none; padding:6px 14px; border-radius:6px; font-size:0.85rem; font-weight:600; cursor:pointer;">
                                            <svg width="18" height="18" viewBox="0 0 20 20" fill="currentColor">
                                                <path d="M5 7l5 5 5-5H5z"></path>
                                            </svg> Switch Pixel
                                        </button>
                                        <div id="pixelDropdown" style="display:none; position:absolute; right:0; top:110%; background:#fff; border:1px solid #ddd; border-radius:8px; box-shadow:0 4px 12px rgba(0,0,0,0.1); min-width:325px; z-index:999; overflow:hidden;">
                                            <?php if (!empty($pixel_history)): ?>
                                                <?php foreach ($pixel_history as $p): ?>
                                                    <div onclick="activateSavedPixel('<?php echo htmlspecialchars($p['id']); ?>', '<?php echo htmlspecialchars($p['name']); ?>', event)"
                                                        style="padding:10px 14px; cursor:pointer; border-bottom:1px solid #f0f0f0; transition:background 0.15s;"
                                                        onmouseover="this.style.background='#fff5f2'"
                                                        onmouseout="this.style.background='#fff'">
                                                        <div style="font-weight:600; font-size:13px; color:#333;"><?php echo htmlspecialchars($p['name']); ?></div>
                                                        <div style="font-size:12px; color:#000000; letter-spacing: 1px;"><?php echo htmlspecialchars($p['id']); ?></div>
                                                    </div>
                                                <?php endforeach; ?>
                                                <div onclick="showPixelInput('add')" style="padding:10px 14px; cursor:pointer; text-align:center; font-size:13px; font-weight:600; color:#e9532a; background:#fff8f6;"
                                                    onmouseover="this.style.background='#ffe9e2'"
                                                    onmouseout="this.style.background='#fff8f6'">
                                                    ＋ Add New Pixel ID
                                                </div>
                                            <?php else: ?>
                                                <div onclick="showPixelInput('add')" style="padding:10px 14px; cursor:pointer; text-align:center; font-size:13px; font-weight:600; color:#e9532a;">
                                                    ＋ Add New Pixel ID
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>

                                <!-- ===m=== CSV UPLOAD WRAPPER ===m=== -->
                                <div id="csvUploadWrapper" style="display: <?php echo $active_pixel ? 'block' : 'none'; ?>;">

                                    <!-- ===m=== Drop Zone ===m=== -->
                                    <div class="capi-drop-zone" id="capiDropZone" onclick="document.getElementById('capiCsvInput').click()">
                                        <div class="capi-drop-icon">
                                            <svg viewBox="0 0 24 24">
                                                <polyline points="16 16 12 12 8 16" />
                                                <line x1="12" y1="12" x2="12" y2="21" />
                                                <path d="M20.39 18.39A5 5 0 0 0 18 9h-1.26A8 8 0 1 0 3 16.3" />
                                            </svg>
                                        </div>
                                        <div class="capi-drop-title">Drop your CSV file here</div>
                                        <div class="capi-drop-sub">Supports .csv files up to 50MB</div>
                                        <span class="capi-browse-btn">Browse files</span>
                                    </div>
                                    <input type="file" id="capiCsvInput" accept=".csv" style="display:none;">

                                    <!-- ===m=== File Chosen Row ===m=== -->
                                    <div class="capi-file-row" id="capiFileRow">
                                        <div class="capi-file-icon">
                                            <svg viewBox="0 0 24 24">
                                                <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
                                                <polyline points="14 2 14 8 20 8" />
                                                <line x1="16" y1="13" x2="8" y2="13" />
                                                <line x1="16" y1="17" x2="8" y2="17" />
                                            </svg>
                                        </div>
                                        <div class="capi-file-info">
                                            <div class="capi-file-name" id="capiFileName">—</div>
                                            <div class="capi-file-size" id="capiFileSize">—</div>
                                        </div>
                                        <button class="capi-remove-btn" onclick="capiClear()" title="Remove">✕</button>
                                    </div>

                                    <!-- ===m=== Actions ===m=== -->
                                    <div class="capi-actions">
                                        <button class="capi-btn-primary" id="capiUploadBtn" onclick="uploadCSV()" disabled>
                                            <svg viewBox="0 0 24 24">
                                                <polyline points="16 16 12 12 8 16" />
                                                <line x1="12" y1="12" x2="12" y2="21" />
                                                <path d="M20.39 18.39A5 5 0 0 0 18 9h-1.26A8 8 0 1 0 3 16.3" />
                                            </svg>
                                            Upload &amp; Preview
                                        </button>
                                        <button class="capi-btn-secondary" id="capiSendBtn" onclick="startProcessing()">
                                            <svg viewBox="0 0 24 24">
                                                <line x1="22" y1="2" x2="11" y2="13" />
                                                <polygon points="22 2 15 22 11 13 2 9 22 2" />
                                            </svg>
                                            Send to CAPI
                                        </button>
                                        <a class="capi-sample-link" onclick="downloadSampleCSV()">
                                            <svg viewBox="0 0 24 24">
                                                <polyline points="8 17 12 21 16 17" />
                                                <line x1="12" y1="21" x2="12" y2="3" />
                                            </svg>
                                            Click here to download the sample format
                                        </a>
                                    </div>

                                    <!-- ===m=== Progress ===m=== -->
                                    <div class="capi-progress-wrap" id="capiProgressWrap">
                                        <div class="capi-progress-meta">
                                            <span id="capiProgressLabel">Sending events…</span>
                                            <span id="capiProgressPct">0%</span>
                                        </div>
                                        <div class="capi-progress-track">
                                            <div class="capi-progress-fill" id="capiProgressFill"></div>
                                        </div>
                                    </div>

                                    <!-- ===m=== Summary ===m=== -->
                                    <div class="capi-summary-wrap" id="capiSummaryWrap">
                                        <h5 style="margin-top:0; font-weight:700;">Import Summary</h5>
                                        <p style="margin:0; font-weight:bold; color:#333;">Total Processed: <span id="sumTotal">0</span></p>

                                        <p style="margin:4px 0 0 0; color:green;">
                                            <b>Successfully Imported to CAPI:</b> <span id="sumSuccess">0</span>
                                            <a href="javascript:void(0)" id="dlSuccess" onclick="downloadReport('success')" style="display:none; margin-left:10px; color:#0056b3; text-decoration:underline; font-size:13px; font-weight:bold;">Export Data</a>
                                        </p>

                                        <p style="margin:4px 0 0 0; color:#6f42c1;">
                                            <b>CSV Duplicate [Repeated in file]:</b> <span id="sumCsvDuplicate">0</span>
                                            <a href="javascript:void(0)" id="dlCsvDuplicate" onclick="downloadReport('csv_duplicate')" style="display:none; margin-left:10px; color:#0056b3; text-decoration:underline; font-size:13px; font-weight:bold;">Export Data</a>
                                        </p>

                                        <p style="margin:4px 0 0 0; color:#d88600;">
                                            <b>Skipped [Not present in DB]:</b> <span id="sumSkipped">0</span>
                                            <a href="javascript:void(0)" id="dlSkipped" onclick="downloadReport('skipped')" style="display:none; margin-left:10px; color:#0056b3; text-decoration:underline; font-size:13px; font-weight:bold;">Export Data</a>
                                        </p>

                                        <p style="margin:4px 0 0 0; color:red;">
                                            <b>Failed[Meta Error]:</b> <span id="sumFailed">0</span>
                                            <a href="javascript:void(0)" id="dlFailed" onclick="downloadReport('failed')" style="display:none; margin-left:10px; color:#0056b3; text-decoration:underline; font-size:13px; font-weight:bold;">Export Data</a>
                                        </p>
                                    </div>

                                    <!-- ===m=== Preview Table ===m=== -->
                                    <div class="capi-preview-wrap" id="capiPreviewWrap">
                                        <div class="capi-preview-header">
                                            <span class="capi-preview-label">Preview</span>
                                            <div id="capiHeaderRight" style="display: flex; align-items: center; gap: 12px;">
                                                <span class="capi-row-badge" id="capiRowCount">0 rows</span>
                                            </div>
                                        </div>
                                        <div class="capi-table-wrap">
                                            <table class="capi-table" id="capiPreviewTable"></table>
                                        </div>
                                    </div>

                                    <div class="capi-divider"></div>

                                </div> <!-- End of csvUploadWrapper -->

                            </div> <!-- End of capi-card -->
                        </div>
                    </div>
                </div>
            </div>

        </div>
        <!-- ===m=== ===m=== Scripts Started ===m=== ===m=== -->
        <script src="./assets/js/core/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.perfect-scrollbar/1.5.5/perfect-scrollbar.min.js"></script>
        <script src="./assets/js/core/popper.min.js"></script>
        <script src="./assets/js/core/bootstrap.min.js"></script>
        <script src="./assets/js/plugins/bootstrap-notify.js"></script>
        <script src="./assets/js/paper-dashboard.min.js?v=2.0.1" type="text/javascript"></script>
        <script src="https://code.iconify.design/3/3.1.1/iconify.min.js"></script>
        <!-- ===m=== ===m=== DataTables JS ===m=== ===m=== -->
        <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
        <script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap4.min.js"></script>
        <!-- ===m=== ===m=== Scripts Ended ===m=== ===m=== -->

        <script>
            let totalRows = 0;
            let dataTableInstance = null;
            let importStats = {
                success: 0,
                // duplicate: 0,
                csv_duplicate: 0,
                skipped: 0,
                failed: 0
            };
            let reportData = {
                success: [],
                // duplicate: [],
                csv_duplicate: [],
                skipped: [],
                failed: []
            };

            function downloadSampleCSV() {
                window.location.href = './samples/capi_sample.csv';
            }

            const capiDropZone = document.getElementById('capiDropZone');
            const capiCsvInput = document.getElementById('capiCsvInput');

            capiDropZone.addEventListener('dragover', e => {
                e.preventDefault();
                capiDropZone.classList.add('drag-over');
            });
            capiDropZone.addEventListener('dragleave', () => capiDropZone.classList.remove('drag-over'));
            capiDropZone.addEventListener('drop', e => {
                e.preventDefault();
                capiDropZone.classList.remove('drag-over');
                const f = e.dataTransfer.files[0];

                if (f && (f.name.endsWith('.csv') || f.type === 'text/csv')) {
                    document.getElementById('capiCsvInput').files = e.dataTransfer.files;
                    capiSetFile(f);
                } else {
                    alert("Please drop a valid .csv file only.");
                }
            });
            capiCsvInput.addEventListener('change', e => {
                if (e.target.files[0]) capiSetFile(e.target.files[0]);
            });

            function capiSetFile(file) {
                if (!file.name.endsWith('.csv')) {
                    alert("Only CSV files are permitted.");
                    capiClear();
                    return;
                }
                document.getElementById('capiFileName').textContent = file.name;
                document.getElementById('capiFileSize').textContent = file.size > 1048576 ? (file.size / 1048576).toFixed(1) + ' MB' : Math.round(file.size / 1024) + ' KB';
                document.getElementById('capiFileRow').classList.add('visible');
                document.getElementById('capiUploadBtn').disabled = false;
                capiSetBadge('ready', 'File selected');
            }

            function capiClear() {
                capiCsvInput.value = '';
                document.getElementById('capiFileRow').classList.remove('visible');
                document.getElementById('capiUploadBtn').disabled = true;
                document.getElementById('capiSendBtn').classList.remove('visible');
                document.getElementById('capiPreviewWrap').classList.remove('visible');
                document.getElementById('capiProgressWrap').classList.remove('visible');
                document.getElementById('capiSummaryWrap').style.display = 'none';
                capiSetBadge('idle', 'Idle');
                if (dataTableInstance !== null) {
                    dataTableInstance.clear().draw();
                }
            }

            function capiSetBadge(type, label) {
                const b = document.getElementById('capiBadge');
                b.className = 'capi-badge ' + type;
                b.textContent = label;
            }

            function capiShowPreview(data) {
                totalRows = data.total;

                document.getElementById('capiSummaryWrap').style.display = 'none';
                $('.dataTables_filter').remove();

                if (dataTableInstance !== null) {
                    dataTableInstance.destroy();
                    $('#capiPreviewTable').empty();
                }

                let dtData = [];
                if (data.data) {
                    dtData = data.data.map((row) => {
                        let leadgenId = row[0] || '-';
                        let status = row[1] || 'Pending';

                        let dbExistsIcon = '';

                        // let csvDupText = (row.csv_count > 1) ? ` <small style="color:#6c757d;">[Appears ${row.csv_count}x]</small>` : '';

                        // if (row.is_csv_duplicate) {
                        //     dbExistsIcon = `<span style="color:#6f42c1; font-weight:bold;">CSV Duplicate</span>${csvDupText}`;
                        // } 
                        if (!row.db_exists) {
                            dbExistsIcon = `<span style="color:#dc3545; font-weight:bold;">Not Found</span>`;
                        }
                        // else if (row.is_duplicate) {
                        //     dbExistsIcon = `<span style="color:#17a2b8; font-weight:bold;">DB Duplicate</span>${csvDupText}`;
                        // } 
                        else {
                            dbExistsIcon = `<span style="color:#28a745; font-weight:bold;">Present</span>`;
                            // dbExistsIcon = `<span style="color:#28a745; font-weight:bold;">Present</span>${csvDupText}`;
                        }

                        let importStatusIcon = '<span style="color:#6a6968;">Waiting...</span>';

                        return [leadgenId, status, dbExistsIcon, importStatusIcon];
                    });
                }

                dataTableInstance = $('#capiPreviewTable').DataTable({
                    data: dtData,
                    columns: [{
                            title: "Leadgen ID"
                        },
                        {
                            title: "Event Status"
                        },
                        {
                            title: "In Database?"
                        },
                        {
                            title: "Import Status"
                        }
                    ],
                    pageLength: 10,
                    lengthChange: false,
                    searching: true,
                    ordering: false,
                    info: true,
                    autoWidth: false,
                    language: {
                        search: "",
                        searchPlaceholder: "Search records..."
                    }
                });

                document.getElementById('capiRowCount').textContent = totalRows + ' rows';
                document.getElementById('capiPreviewWrap').classList.add('visible');
                document.getElementById('capiSendBtn').classList.add('visible');

                $('.dataTables_filter').detach().appendTo('#capiHeaderRight');
                capiSetBadge('ready', 'Ready to send');
            }

            function uploadCSV() {
                let file = document.getElementById('capiCsvInput').files[0];
                if (!file) {
                    alert("Please select a file");
                    return;
                }

                let formData = new FormData();
                formData.append("file", file);

                let uploadBtn = document.getElementById('capiUploadBtn');
                let originalText = uploadBtn.innerHTML;
                uploadBtn.innerHTML = "Processing...";
                uploadBtn.disabled = true;

                fetch("meta_capi/upload_csv.php", {
                        method: "POST",
                        body: formData
                    })
                    .then(async res => {
                        const text = await res.text();
                        try {
                            return JSON.parse(text);
                        } catch (e) {
                            throw new Error(text);
                        }
                    })
                    .then(data => {
                        uploadBtn.innerHTML = originalText;
                        uploadBtn.disabled = false;

                        if (data.error) {
                            alert("Error: " + data.error);
                            return;
                        }

                        capiShowPreview(data);
                    })
                    .catch(err => {
                        console.error("Upload error:", err);
                        uploadBtn.innerHTML = originalText;
                        uploadBtn.disabled = false;
                        alert("An error occurred reading the CSV file.");
                    });
            }

            function startProcessing() {
                document.getElementById('capiProgressWrap').classList.add('visible');
                document.getElementById('capiSendBtn').disabled = true;
                document.getElementById('capiUploadBtn').disabled = true;
                document.getElementById('capiSummaryWrap').style.display = 'none';

                document.getElementById('dlSuccess').style.display = 'none';
                // document.getElementById('dlDuplicate').style.display = 'none';
                document.getElementById('dlCsvDuplicate').style.display = 'none';
                document.getElementById('dlSkipped').style.display = 'none';
                document.getElementById('dlFailed').style.display = 'none';

                importStats = {
                    success: 0,
                    // duplicate: 0,
                    csv_duplicate: 0,
                    skipped: 0,
                    failed: 0
                };

                let headers = ['Leadgen ID', 'Event Status', 'Import Details'];
                reportData = {
                    success: [headers],
                    // duplicate: [headers],
                    csv_duplicate: [headers],
                    skipped: [headers],
                    failed: [headers]
                };

                capiSetBadge('sending', 'Sending…');
                processRow(0);
            }

            function processRow(index) {
                if (index >= totalRows) {
                    document.getElementById('sumTotal').textContent = totalRows;
                    document.getElementById('sumSuccess').textContent = importStats.success;
                    // document.getElementById('sumDuplicate').textContent = importStats.duplicate;
                    document.getElementById('sumCsvDuplicate').textContent = importStats.csv_duplicate;
                    document.getElementById('sumSkipped').textContent = importStats.skipped;
                    document.getElementById('sumFailed').textContent = importStats.failed;
                    document.getElementById('capiSummaryWrap').style.display = 'block';

                    if (reportData.success.length > 1) document.getElementById('dlSuccess').style.display = 'inline-block';
                    // if (reportData.duplicate.length > 1) document.getElementById('dlDuplicate').style.display = 'inline-block';
                    if (reportData.csv_duplicate.length > 1) document.getElementById('dlCsvDuplicate').style.display = 'inline-block';
                    if (reportData.skipped.length > 1) document.getElementById('dlSkipped').style.display = 'inline-block';
                    if (reportData.failed.length > 1) document.getElementById('dlFailed').style.display = 'inline-block';

                    capiSetBadge('done', '✔ Import Completed!');
                    document.getElementById('capiProgressLabel').innerHTML = '<span style="color: #28a745; font-weight: bold;">All records have been successfully processed!</span>';

                    if (typeof $.notify === 'function') {
                        $.notify({
                            icon: "nc-icon nc-check-2",
                            message: "<b>Success!</b> The CSV data has been successfully processed and sent to CAPI."
                        }, {
                            type: 'success',
                            timer: 4000,
                            placement: {
                                from: 'top',
                                align: 'right'
                            }
                        });
                    }

                    document.getElementById('capiSendBtn').disabled = false;
                    document.getElementById('capiUploadBtn').disabled = false;
                    return;
                }

                fetch(`meta_capi/process_capi_lead.php?index=${index}`)
                    .then(res => res.json())
                    .then(data => {
                        let statusHtml = '';
                        let rowData = dataTableInstance.row(index).data();

                        if (data.status === 'success') {
                            importStats.success++;
                            statusHtml = '<span style="color:#28a745; font-weight:bold;">Imported</span>';
                            reportData.success.push([rowData[0], rowData[1], 'Successfully Imported']);
                        }
                        // else if (data.status === 'duplicate') {
                        //     importStats.duplicate++;
                        //     statusHtml = '<span style="color:#17a2b8; font-weight:bold;">🔁 DB Duplicate</span>';
                        //     reportData.duplicate.push([rowData[0], rowData[1], 'Duplicate (Already Sent to CAPI)']);
                        // } 
                        else if (data.status === 'csv_duplicate') {
                            importStats.csv_duplicate++;
                            statusHtml = '<span style="color:#d88600; font-weight:bold;">Skipped</span>';
                            reportData.csv_duplicate.push([rowData[0], rowData[1], 'Repeated in uploaded CSV file']);
                        } else if (data.status === 'skipped') {
                            importStats.skipped++;
                            statusHtml = '<span style="color:#d88600; font-weight:bold;">Skipped</span>';
                            reportData.skipped.push([rowData[0], rowData[1], 'Skipped [Not present in DB]']);
                        } else {
                            importStats.failed++;
                            statusHtml = '<span style="color:#dc3545; font-weight:bold;">Failed</span>';
                            reportData.failed.push([rowData[0], rowData[1], 'Failed [Meta Error]']);
                        }

                        dataTableInstance.cell(index, 3).data(statusHtml).draw(false);

                        let percent = Math.round(((index + 1) / totalRows) * 100);
                        document.getElementById('capiProgressFill').style.width = percent + '%';
                        document.getElementById('capiProgressPct').textContent = percent + '%';
                        document.getElementById('capiProgressLabel').textContent = `Processing event ${index + 1} of ${totalRows}…`;

                        setTimeout(() => processRow(index + 1), 50);
                    })
                    .catch(err => {
                        console.error("Error at row:", index, err);
                        importStats.failed++;
                        let rowData = dataTableInstance.row(index).data();
                        reportData.failed.push([rowData[0], rowData[1], 'Failed (Network/Server Error)']);

                        dataTableInstance.cell(index, 3).data('<span style="color:#dc3545; font-weight:bold;">✖ Error</span>').draw(false);
                        processRow(index + 1);
                    });
            }

            // ===m=== Triggers the CSV Download automatically ===m===
            function downloadReport(type) {
                let dataArray = reportData[type];
                if (!dataArray || dataArray.length <= 1) return; // Failsafe

                let csvContent = "";
                dataArray.forEach(function(rowArray) {
                    // Escape quotes inside fields to prevent Excel breakage
                    let row = rowArray.map(item => `"${String(item).replace(/"/g, '""')}"`).join(",");
                    csvContent += row + "\r\n";
                });

                let blob = new Blob([csvContent], {
                    type: 'text/csv;charset=utf-8;'
                });
                let link = document.createElement("a");
                if (link.download !== undefined) {
                    let url = URL.createObjectURL(blob);
                    link.setAttribute("href", url);

                    // Format filename dynamically (e.g., CAPI_Success_Report.csv)
                    let fileName = type.charAt(0).toUpperCase() + type.slice(1);
                    link.setAttribute("download", `CAPI_${fileName}_Report.csv`);

                    link.style.visibility = 'hidden';
                    document.body.appendChild(link);
                    link.click();
                    document.body.removeChild(link);
                }
            }

            function activateSavedPixel(pixelId, pixelName, event) {

                console.log('pixelId:', pixelId);
                const formData = new URLSearchParams();
                formData.append('pixel_id', pixelId);
                formData.append('reactivate', '1');

                const btn = event ? event.target : null;
                if (btn) {
                    btn.innerHTML = '...';
                    btn.disabled = true;
                }

                fetch('meta_capi/verify_pixel.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded'
                        },
                        body: formData.toString()
                    })
                    .then(res => res.json())
                    .then(data => {
                        if (data.status === 'success') {
                            document.getElementById('displayPixelId').textContent = data.pixel_id;
                            document.getElementById('displayPixelName').textContent = data.name;

                            document.getElementById('pixelInputSection').style.display = 'none';
                            document.getElementById('verifiedPixelSection').style.display = 'flex';
                            document.getElementById('csvUploadWrapper').style.display = 'block';
                            document.getElementById('pixelDropdown').style.display = 'none';
                            btn.innerHTML = 'Use';
                            btn.disabled = false;

                            $.notify({
                                icon: "nc-icon nc-check-2",
                                message: "Pixel <b>" + data.name + "</b> activated!"
                            }, {
                                type: 'success',
                                timer: 2000
                            });
                        }
                    });
            }

            function addPixelChip(pixelId, pixelName) {
                const tableEl = document.getElementById('pixelHistoryTable');
                if (!tableEl) return;

                // Show history section if hidden
                const section = document.getElementById('pixelHistorySection');
                if (section) section.style.display = 'block';

                if ($.fn.DataTable.isDataTable('#pixelHistoryTable')) {
                    const table = $('#pixelHistoryTable').DataTable();
                    let exists = false;
                    table.rows().every(function() {
                        if (this.data()[1] === pixelId) exists = true;
                    });
                    if (exists) return;
                    table.row.add([
                        pixelName,
                        pixelId,
                        `<button onclick="activateSavedPixel('${pixelId}', '${pixelName}', event)" style="background:#e9532a;color:#fff;border:none;padding:4px 14px;border-radius:5px;font-size:12px;cursor:pointer;font-weight:600;">Use</button>`
                    ]).draw();
                } else {
                    // Init fresh DataTable
                    const tbody = tableEl.querySelector('tbody');
                    const tr = document.createElement('tr');
                    tr.innerHTML = `<td>${pixelName}</td><td>${pixelId}</td>
            <td style="text-align:center;">
                <button onclick="activateSavedPixel('${pixelId}', '${pixelName}', event)" style="background:#e9532a;color:#fff;border:none;padding:4px 14px;border-radius:5px;font-size:12px;cursor:pointer;font-weight:600;">Use</button>
            </td>`;
                    tbody.appendChild(tr);
                    $('#pixelHistoryTable').DataTable({
                        pageLength: 5,
                        lengthChange: false,
                        searching: false,
                        ordering: false,
                        info: false
                    });
                }
            }

            // ===m=== Meta Pixel Verification Logic ===m===
            function verifyPixel() {
                const pixelId = document.getElementById('pixelIdInput').value.trim();
                const btn = document.getElementById('verifyPixelBtn');
                const statusMsg = document.getElementById('pixelStatusMsg');

                if (!pixelId) {
                    statusMsg.style.display = 'block';
                    statusMsg.innerHTML = '<span style="color: #dc3545;">Please enter a Pixel ID</span>';
                    return;
                }

                // UI Loading State
                btn.disabled = true;
                btn.innerHTML = 'Verifying...';
                statusMsg.style.display = 'none';

                // AJAX Call
                const formData = new URLSearchParams();
                formData.append('pixel_id', pixelId);

                fetch('meta_capi/verify_pixel.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded'
                        },
                        body: formData.toString()
                    })
                    .then(res => res.json())
                    .then(data => {
                        btn.disabled = false;
                        btn.innerHTML = 'Verify & Add';
                        statusMsg.style.display = 'block';

                        if (data.status === 'success') {
                            // Valid Pixel
                            statusMsg.style.display = 'none'; // Hide error msg
                            document.getElementById('pixelInputSection').style.display = 'none';
                            document.getElementById('verifiedPixelSection').style.display = 'flex';
                            document.getElementById('displayPixelId').textContent = data.pixel_id;
                            document.getElementById('displayPixelName').textContent = data.name;
                            document.getElementById('csvUploadWrapper').style.display = 'block';
                            addPixelChip(data.pixel_id, data.name);

                            // Notification via paper-dashboard
                            $.notify({
                                icon: "nc-icon nc-check-2",
                                message: "Pixel Verified Successfully!"
                            }, {
                                type: 'success',
                                timer: 2000
                            });
                        } else {
                            // Invalid Pixel
                            statusMsg.innerHTML = `<span style="color: #dc3545;">Invalid: ${data.message}</span>`;
                        }
                    })
                    .catch(err => {
                        btn.disabled = false;
                        btn.innerHTML = 'Verify & Add';
                        statusMsg.style.display = 'block';
                        statusMsg.innerHTML = '<span style="color: #dc3545;">Network Error!</span>';
                    });
            }

            function showPixelInput(mode) {
                if (mode === 'change') {
                    // Inline edit: just prefill the input and show it ABOVE the verified section
                    const currentId = document.getElementById('displayPixelId').textContent.trim();
                    document.getElementById('pixelIdInput').value = currentId;
                    document.getElementById('pixelStatusMsg').style.display = 'none';
                    document.getElementById('pixelInputSection').style.display = 'block';
                    // Keep csvUploadWrapper and verifiedPixelSection visible
                    // Just scroll to the input
                    document.getElementById('pixelInputSection').scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                } else {
                    // Fresh add: clear everything
                    fetch('meta_capi/verify_pixel.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded'
                        },
                        body: 'pixel_id=reset'
                    });
                    document.getElementById('verifiedPixelSection').style.display = 'none';
                    document.getElementById('csvUploadWrapper').style.display = 'none';
                    document.getElementById('pixelInputSection').style.display = 'block';
                    document.getElementById('pixelIdInput').value = '';
                    document.getElementById('pixelStatusMsg').style.display = 'none';
                    capiClear();
                }

                const heading = document.querySelector('#pixelInputSection h5');
                if (heading) {
                    heading.textContent = mode === 'change' ? 'Change Meta Pixel' : 'Connect Meta Pixel';
                }
            }

            function resetPixel() {
                showPixelInput(); // Now just an alias
            }

            function togglePixelDropdown() {
                const dd = document.getElementById('pixelDropdown');
                dd.style.display = dd.style.display === 'none' ? 'block' : 'none';
            }

            // Close dropdown when clicking outside
            document.addEventListener('click', function(e) {
                const dd = document.getElementById('pixelDropdown');
                if (dd && !dd.contains(e.target) && !e.target.closest('[onclick="togglePixelDropdown()"]')) {
                    dd.style.display = 'none';
                }
            });
        </script>
</body>

</html>