<?php
/**
 * lp_hygiene.php — LP Hygiene: is each landing page fast, tracked and delivering leads?
 *   PageSpeed (mobile + desktop) · page checks (HTTPS, tags, form, UTM capture…) · Meta and landing-page test leads
 *   (name and email always contain "test") · did the lead reach the lead table and the CRM · PDF report.
 * Opened inside dashboard.php, or on its own. Backend: lp_hygiene_api.php · logic: app/Tools/lp_hygiene.php.
 * Access: Users & Roles → LP Hygiene (View · Run PageSpeed & checks · Edit pages · Meta test leads · Landing page test leads · PDF).
 */
session_start();
if (($_SESSION['user_logged'] ?? '') !== 'Y') {
    header('Location: login.php');
    exit;
}
require_once dirname(__DIR__) . '/app/Core/db.php';
$canView = pqCan('lphygiene');
?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Sora:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
<script>
(function () {
    var root = document.documentElement, t = null;
    try { t = localStorage.getItem('performiq-theme'); } catch (e) {}
    root.setAttribute('data-theme', t === 'light' ? 'light' : 'dark');
    if (/[?&]embed=1(&|$)/.test(location.search)) root.classList.add('pq-embed');
    window.addEventListener('storage', function (e) {
        if (e.key === 'performiq-theme') root.setAttribute('data-theme', e.newValue === 'light' ? 'light' : 'dark');
    });
    window.setTheme = function (t) { root.setAttribute('data-theme', t === 'light' ? 'light' : 'dark'); };
})();
</script>
<title>LP Hygiene</title>
<style>
    :root, html[data-theme="dark"] {
        --bg: #0B0F1A; --surface: #111827; --surface-2: #161D2E; --border: #1E2A42; --border-strong: #2A3957;
        --text: #E2E8F0; --text-dim: #94A3B8; --text-faint: #64748B; --accent: #E8A820; --accent-soft: #E8A8201F;
        --hover: #1A2337; --good: #10B981; --good-soft: #10B9811F; --bad: #EF4444; --bad-soft: #EF44441A;
        --warn: #F59E0B; --warn-soft: #F59E0B1A; --info: #60A5FA; --info-soft: #60A5FA1A; --meta: #4F7DF3; --google: #D95926; color-scheme: dark;
    }
    html[data-theme="light"] {
        --bg: #F4F6FA; --surface: #FFFFFF; --surface-2: #F8FAFC; --border: #E2E8F0; --border-strong: #CBD5E1;
        --text: #0F172A; --text-dim: #475569; --text-faint: #94A3B8; --accent: #B7791F; --accent-soft: #B7791F1A;
        --hover: #F1F5F9; --good: #059669; --good-soft: #0596691A; --bad: #DC2626; --bad-soft: #DC26261A;
        --warn: #B45309; --warn-soft: #B453091A; --info: #2563EB; --info-soft: #2563EB14; --meta: #1D4ED8; --google: #C2410C; color-scheme: light;
    }
    * { box-sizing: border-box; }
    [hidden] { display: none !important; }
    body { margin: 0; background: var(--bg); color: var(--text); font: 14px/1.5 'Sora', system-ui, -apple-system, 'Segoe UI', sans-serif; }
    button, input, select, textarea { font: inherit; color: inherit; }
    .wrap { max-width: 1320px; margin: 0 auto; padding: 28px 24px 60px; }
    .pq-embed .wrap { padding-top: 18px; }
    .pq-embed .page-head { display: none !important; }
    h1 { font-size: 22px; margin: 0 0 4px; }
    h2 { font-size: 15px; margin: 0; display: flex; gap: 8px; align-items: center; }
    h3 { font-size: 13px; margin: 0 0 8px; color: var(--text-dim); text-transform: uppercase; letter-spacing: .05em; font-weight: 600; }
    .sub { color: var(--text-dim); margin: 0 0 18px; font-size: 13px; }
    .card { background: var(--surface); border: 1px solid var(--border); border-radius: 12px; padding: 16px 18px; margin-bottom: 16px; min-width: 0; }
    .card-head { display: flex; gap: 10px; align-items: center; flex-wrap: wrap; margin-bottom: 14px; }
    .row { display: flex; gap: 10px; align-items: center; flex-wrap: wrap; }
    .grow { flex: 1 1 auto; }
    select, input[type=text], input[type=url], input[type=email], input[type=tel], input:not([type]), textarea {
        background: var(--surface-2); border: 1px solid var(--border-strong); border-radius: 8px; padding: 7px 10px; outline: none; min-width: 0; }
    select:focus, input:focus, textarea:focus { border-color: var(--accent); }
    label.f { display: flex; flex-direction: column; gap: 4px; font-size: 12px; color: var(--text-dim); font-weight: 600; min-width: 0; }
    label.f input, label.f select { font-weight: 400; color: var(--text); width: 100%; }
    .btn { border: 1px solid var(--border-strong); background: var(--surface-2); padding: 7px 13px; border-radius: 8px; cursor: pointer; font-weight: 600; font-size: 12.5px; white-space: nowrap; display: inline-flex; gap: 6px; align-items: center; }
    .btn:hover { background: var(--hover); }
    .btn.primary { background: var(--accent); border-color: var(--accent); color: #111; }
    .btn.primary:hover { filter: brightness(1.07); }
    .btn.meta { border-color: var(--meta); color: var(--meta); } .btn.google { border-color: var(--google); color: var(--google); }
    .btn.sm { padding: 4px 9px; font-size: 11.5px; }
    .btn.danger { color: var(--bad); }
    .btn[disabled] { opacity: .55; cursor: not-allowed; }
    .btn:focus-visible, .tab:focus-visible, summary:focus-visible { outline: 2px solid var(--accent); outline-offset: 2px; }
    .tabs { display: inline-flex; gap: 4px; background: var(--surface-2); border: 1px solid var(--border); border-radius: 10px; padding: 3px; }
    .tab { border: 0; background: none; border-radius: 7px; padding: 6px 14px; font-size: 13px; cursor: pointer; color: var(--text-dim); font-weight: 600; }
    .tab.on { background: var(--surface); color: var(--text); box-shadow: 0 1px 0 var(--border-strong); }
    .pill { display: inline-flex; align-items: center; padding: 1px 8px; border-radius: 99px; font-size: 11px; font-weight: 600; white-space: nowrap; }
    .pill.pass, .pill.good { color: var(--good); background: var(--good-soft); } .pill.fail, .pill.bad { color: var(--bad); background: var(--bad-soft); }
    .pill.warn { color: var(--warn); background: var(--warn-soft); } .pill.info { color: var(--info); background: var(--info-soft); }
    .pill.dim { color: var(--text-dim); background: var(--surface-2); border: 1px solid var(--border); }
    .note { padding: 10px 14px; border-radius: 10px; font-size: 12.5px; margin-bottom: 14px; border: 1px solid; }
    .note.warn { background: var(--warn-soft); border-color: var(--warn); } .note.info { background: var(--info-soft); border-color: var(--info); }
    .note.bad { background: var(--bad-soft); border-color: var(--bad); }
    .muted { color: var(--text-dim); } .faint { color: var(--text-faint); font-size: 11.5px; }
    .mono { font-family: 'JetBrains Mono', monospace; font-size: 12px; }
    .spinner { width: 15px; height: 15px; border: 2px solid var(--border-strong); border-top-color: var(--accent); border-radius: 50%; display: inline-block; animation: spin .8s linear infinite; vertical-align: -3px; }
    @keyframes spin { to { transform: rotate(360deg); } }
    .empty { padding: 26px; text-align: center; color: var(--text-dim); border: 1px dashed var(--border-strong); border-radius: 10px; }

    /* page picker */
    .pagebar { display: flex; gap: 10px; align-items: center; flex-wrap: wrap; margin-bottom: 16px; }
    .pagebar select { min-width: 260px; max-width: 100%; }
    .pagebar .url { font-size: 12.5px; color: var(--text-dim); overflow-wrap: anywhere; }
    .pagebar .url a { color: var(--info); }

    /* PageSpeed */
    .gauges { display: grid; grid-template-columns: repeat(auto-fit, minmax(130px, 1fr)); gap: 12px; margin-bottom: 16px; }
    .gauge { text-align: center; padding: 6px 4px; }
    .gauge svg { width: 96px; height: 96px; display: block; margin: 0 auto 6px; }
    .gauge circle { fill: none !important; } .gauge .ring-bg { stroke: var(--border); } .gauge text { stroke: none !important; } .gauge text { font-family: 'JetBrains Mono', monospace; font-size: 26px; font-weight: 500; }
    .gauge .lbl { font-size: 12.5px; font-weight: 600; }
    .c-good { color: var(--good); stroke: var(--good); fill: var(--good); } .c-avg { color: var(--warn); stroke: var(--warn); fill: var(--warn); }
    .c-bad { color: var(--bad); stroke: var(--bad); fill: var(--bad); } .c-na { color: var(--text-faint); stroke: var(--text-faint); fill: var(--text-faint); }
    .legend { display: flex; gap: 16px; justify-content: center; font-size: 11.5px; color: var(--text-dim); margin: -4px 0 16px; flex-wrap: wrap; }
    .legend i { display: inline-block; width: 10px; height: 10px; margin-right: 5px; vertical-align: -1px; }
    .legend .tri { width: 0; height: 0; border-left: 6px solid transparent; border-right: 6px solid transparent; border-bottom: 10px solid var(--bad); }
    .legend .sq { background: var(--warn); } .legend .ci { background: var(--good); border-radius: 50%; }
    .psi-body { display: grid; grid-template-columns: minmax(0, 1fr) 220px; gap: 18px; align-items: start; }
    .metrics { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); border-top: 1px solid var(--border); }
    .metric { padding: 12px 6px; border-bottom: 1px solid var(--border); display: flex; gap: 10px; align-items: flex-start; }
    .metric .mk { width: 10px; height: 10px; flex: none; margin-top: 5px; }
    .metric .mk.c-good { background: var(--good); border-radius: 50%; } .metric .mk.c-avg { background: var(--warn); }
    .metric .mk.c-bad { width: 0; height: 0; border-left: 6px solid transparent; border-right: 6px solid transparent; border-bottom: 10px solid var(--bad); background: none; }
    .metric .mk.c-na { background: var(--text-faint); border-radius: 50%; }
    .metric .ml { font-size: 12.5px; color: var(--text-dim); }
    .metric .mv { font-size: 24px; font-family: 'JetBrains Mono', monospace; line-height: 1.25; }
    .shot { border: 1px solid var(--border); border-radius: 10px; overflow: hidden; background: var(--surface-2); }
    .shot img { display: block; width: 100%; height: auto; }
    .opps { margin-top: 16px; }
    .opp { display: flex; gap: 10px; padding: 8px 0; border-bottom: 1px solid var(--border); font-size: 13px; align-items: baseline; }
    .opp:last-child { border-bottom: 0; }
    .opp .t { flex: 1 1 auto; min-width: 0; } .opp .s { font-family: 'JetBrains Mono', monospace; font-size: 12px; color: var(--warn); white-space: nowrap; }
    .psi-meta { font-size: 11.5px; color: var(--text-faint); margin-top: 10px; }

    /* checks */
    .checks { display: grid; grid-template-columns: repeat(auto-fill, minmax(340px, 1fr)); gap: 8px; }
    .chk { border: 1px solid var(--border); border-radius: 10px; padding: 9px 12px; background: var(--surface-2); display: flex; gap: 10px; align-items: flex-start; min-width: 0; }
    .chk .ct { font-weight: 600; font-size: 13px; } .chk .cd { font-size: 12.5px; color: var(--text-dim); overflow-wrap: anywhere; }
    .counts { display: flex; gap: 6px; flex-wrap: wrap; }

    /* test leads */
    .tl-grid { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 16px; }
    .tl-box { border: 1px solid var(--border); border-radius: 12px; padding: 14px; background: var(--surface-2); min-width: 0; }
    .tl-box h2 .dot { width: 9px; height: 9px; border-radius: 50%; display: inline-block; }
    .vals { display: grid; grid-template-columns: 1.2fr 1.4fr 1fr; gap: 10px; margin-bottom: 8px; }
    .fields { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 8px; margin-top: 8px; }
    .kv { display: grid; grid-template-columns: 110px minmax(0, 1fr); gap: 4px 10px; font-size: 12.5px; margin: 10px 0; }
    .kv dt { color: var(--text-dim); } .kv dd { margin: 0; overflow-wrap: anywhere; font-family: 'JetBrains Mono', monospace; font-size: 12px; }
    .steps { margin-top: 10px; display: flex; flex-direction: column; gap: 6px; }
    details.step { border: 1px solid var(--border); border-radius: 8px; background: var(--surface); }
    details.step > summary { cursor: pointer; padding: 7px 10px; display: flex; gap: 8px; align-items: center; font-size: 12.5px; list-style: none; }
    details.step > summary::-webkit-details-marker { display: none; }
    details.step > summary .grow { min-width: 0; overflow-wrap: anywhere; }
    details.step pre { margin: 0; padding: 8px 10px; border-top: 1px solid var(--border); font-size: 11.5px; overflow: auto; max-height: 300px; white-space: pre-wrap; word-break: break-all; }
    .arrive { margin-top: 10px; border-top: 1px dashed var(--border-strong); padding-top: 10px; font-size: 12.5px; }
    .hist { width: 100%; border-collapse: collapse; font-size: 12.5px; }
    .hist td, .hist th { padding: 7px 8px; border-bottom: 1px solid var(--border); text-align: left; vertical-align: top; }
    .hist th { color: var(--text-dim); font-size: 11px; text-transform: uppercase; letter-spacing: .04em; }
    .hist td:last-child { overflow-wrap: anywhere; }

    /* dialog */
    dialog { border: 1px solid var(--border-strong); background: var(--surface); color: var(--text); border-radius: 14px; padding: 0; width: min(640px, calc(100vw - 32px)); }
    dialog::backdrop { background: rgba(0,0,0,.55); }
    .dlg-head { padding: 14px 18px; border-bottom: 1px solid var(--border); display: flex; align-items: center; gap: 10px; }
    .dlg-body { padding: 16px 18px; display: flex; flex-direction: column; gap: 12px; max-height: 70vh; overflow: auto; }
    .dlg-foot { padding: 12px 18px; border-top: 1px solid var(--border); display: flex; gap: 8px; justify-content: flex-end; flex-wrap: wrap; }
    .toast { position: fixed; bottom: 20px; left: 50%; transform: translateX(-50%); background: var(--surface); border: 1px solid var(--border-strong); padding: 10px 16px; border-radius: 10px; z-index: 50; font-size: 13px; box-shadow: 0 8px 30px rgba(0,0,0,.3); max-width: calc(100vw - 32px); }

    @media (prefers-reduced-motion: reduce) { .spinner { animation: none; } }
    @media (max-width: 980px) { .psi-body { grid-template-columns: 1fr; } .shot { max-width: 240px; } .tl-grid { grid-template-columns: 1fr; } }
    @media (max-width: 640px) {
        .wrap { padding: 16px 16px 40px; }
        .metrics { grid-template-columns: 1fr; } .checks { grid-template-columns: 1fr; }
        .vals, .fields { grid-template-columns: 1fr; }
        .pagebar select { min-width: 0; flex: 1 1 100%; }
        .gauges { grid-template-columns: repeat(2, 1fr); }
        .kv { grid-template-columns: 90px minmax(0, 1fr); }
        .hist th:nth-child(4), .hist td:nth-child(4) { display: none; }
    }

    /* PDF report (built off-screen, light) */
    #pdf { position: fixed; left: -10000px; top: 0; width: 780px; background: #fff; color: #0F172A; font: 12px/1.45 'Sora', system-ui, sans-serif; padding: 28px; }
    #pdf h1 { font-size: 20px; margin: 0; } #pdf h2 { font-size: 14px; margin: 18px 0 8px; border-bottom: 1px solid #E2E8F0; padding-bottom: 4px; display: block; }
    #pdf table { width: 100%; border-collapse: collapse; } #pdf td, #pdf th { border: 1px solid #E2E8F0; padding: 5px 7px; text-align: left; vertical-align: top; font-size: 11px; }
    #pdf th { background: #F1F5F9; } #pdf .g { color: #059669; font-weight: 700; } #pdf .a { color: #B45309; font-weight: 700; } #pdf .b { color: #DC2626; font-weight: 700; }
    #pdf .sm { color: #475569; font-size: 10.5px; } #pdf .brk { page-break-inside: avoid; } #pdf pre { white-space: pre-wrap; word-break: break-all; font-size: 9.5px; margin: 0; }
    @media print {
        body > *:not(#pdf) { display: none !important; }
        #pdf { position: static; width: auto; padding: 0; }
    }
</style>
</head>
<body>
<div class="wrap">
    <div class="page-head">
        <h1>LP Hygiene</h1>
        <p class="sub">Landing page speed, tracking and lead form — and a test lead through Meta and the page, followed to the CRM.</p>
    </div>

<?php if (!$canView) { ?>
    <div class="empty">Your role doesn't include LP Hygiene. Ask a Super Admin for access.</div>
<?php } else { ?>
    <div class="pagebar">
        <select id="page" aria-label="Landing page"></select>
        <span class="url grow" id="page-url"></span>
        <button class="btn" id="edit-page" type="button" data-need="edit">Edit</button>
        <button class="btn" id="add-page" type="button" data-need="edit">+ Add page</button>
        <button class="btn primary" id="run-all" type="button" data-need="run">Run all checks</button>
        <button class="btn" id="pdf-btn" type="button" data-need="pdf">Download PDF</button>
    </div>
    <div id="notes"></div>

    <div id="main">
        <!-- PageSpeed -->
        <section class="card" id="psi-card">
            <div class="card-head">
                <h2>PageSpeed Insights</h2>
                <div class="tabs" role="tablist" id="psi-tabs">
                    <button class="tab on" type="button" data-s="mobile" role="tab" aria-selected="true">📱 Mobile</button>
                    <button class="tab" type="button" data-s="desktop" role="tab" aria-selected="false">🖥 Desktop</button>
                </div>
                <span class="grow"></span>
                <span class="faint" id="psi-when"></span>
                <button class="btn" id="psi-run" type="button" data-need="run">Run PageSpeed</button>
            </div>
            <div id="psi"></div>
        </section>

        <!-- Page checks -->
        <section class="card" id="scan-card">
            <div class="card-head">
                <h2>Page checks</h2>
                <span class="counts" id="scan-counts"></span>
                <span class="grow"></span>
                <span class="faint" id="scan-when"></span>
                <button class="btn" id="scan-run" type="button" data-need="run">Check page</button>
            </div>
            <div id="scan"></div>
        </section>

        <!-- Test leads -->
        <section class="card" id="tl-card">
            <div class="card-head">
                <h2>Test leads</h2>
                <span class="faint">Name and email must contain “test” — the dashboards and reports leave such leads out.</span>
            </div>
            <div class="vals">
                <label class="f">Name <input id="tv-name" type="text" maxlength="80" autocomplete="off"></label>
                <label class="f">Email <input id="tv-email" type="email" maxlength="120" autocomplete="off"></label>
                <label class="f">Mobile (10 digits) <input id="tv-mobile" type="tel" maxlength="14" inputmode="numeric" placeholder="98XXXXXXXX" autocomplete="off"></label>
            </div>
            <p class="faint" style="margin:0 0 14px">Use a team member's number — the CRM may call or SMS it. <button class="btn sm" id="tv-new" type="button">New name &amp; email</button></p>

            <div class="tl-grid">
                <div class="tl-box">
                    <div class="card-head" style="margin-bottom:8px">
                        <h2><span class="dot" style="background:var(--meta)"></span>Meta lead form</h2>
                        <span class="grow"></span>
                        <span class="faint" id="mt-when"></span>
                    </div>
                    <label class="f">Lead form <select id="mt-form"><option value="">Loading forms…</option></select></label>
                    <p class="faint" style="margin:6px 0 10px">Through the Graph API: the form's old test lead is deleted first (Meta keeps one per form), then a new one is created and read back.</p>
                    <button class="btn meta" id="mt-send" type="button" data-need="meta_test">Delete old &amp; send Meta test lead</button>
                    <div id="mt-out"></div>
                </div>
                <div class="tl-box">
                    <div class="card-head" style="margin-bottom:8px">
                        <h2><span class="dot" style="background:var(--google)"></span>Landing page form (Google)</h2>
                        <span class="grow"></span>
                        <span class="faint" id="lt-when"></span>
                    </div>
                    <label class="f">Form posts to <input id="lt-endpoint" type="url" placeholder="Run “Check page” to detect, or paste the form's action URL"></label>
                    <div class="fields">
                        <label class="f">Name field <input id="lt-f-name" type="text" placeholder="name"></label>
                        <label class="f">Email field <input id="lt-f-email" type="text" placeholder="email"></label>
                        <label class="f">Phone field <input id="lt-f-mobile" type="text" placeholder="mobile"></label>
                    </div>
                    <p class="faint" style="margin:6px 0 10px">Posted the way a visitor from a Google ad would: utm_source=google, utm_medium=cpc, a test gclid and keyword go into the form's hidden fields.</p>
                    <div class="row">
                        <button class="btn google" id="lt-send" type="button" data-need="lp_test">Send landing page test lead</button>
                        <button class="btn sm" id="lt-save" type="button" data-need="edit">Save form settings</button>
                    </div>
                    <div id="lt-out"></div>
                </div>
            </div>
        </section>

        <section class="card">
            <div class="card-head"><h2>History</h2></div>
            <div id="hist"></div>
        </section>
    </div>

    <dialog id="dlg">
        <form method="dialog" id="dlg-form">
            <div class="dlg-head"><h2 id="dlg-title" class="grow">Landing page</h2></div>
            <div class="dlg-body">
                <label class="f">Name <input id="pg-name" type="text" maxlength="120" placeholder="e.g. Embassy North Yelahanka — main LP"></label>
                <label class="f">Page address <input id="pg-url" type="url" required placeholder="https://…"></label>
                <p class="faint" style="margin:0">Add every landing page the ads send people to (each Google / Meta variant). The lead form is detected when you run “Check page”.</p>
            </div>
            <div class="dlg-foot">
                <button class="btn danger" id="pg-del" type="button">Delete page</button>
                <span class="grow"></span>
                <button class="btn" value="cancel" formnovalidate>Cancel</button>
                <button class="btn primary" id="pg-save" value="save">Save</button>
            </div>
        </form>
    </dialog>
<?php } ?>
</div>
<div id="pdf" aria-hidden="true"></div>

<?php if ($canView) { ?>
<script>
(function () {
    'use strict';
    var API = 'lp_hygiene_api.php';
    var S = { pages: [], page: null, runs: { latest: {}, history: [] }, can: {}, strat: 'mobile', forms: [], meta: null, lp: null, busy: {} };
    var $ = function (id) { return document.getElementById(id); };
    var esc = function (s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); };
    var fmtAt = function (s) { if (!s) return ''; var d = new Date(String(s).replace(' ', 'T')); return isNaN(d) ? s : d.toLocaleString('en-IN', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' }); };
    var cls = function (score) { return score == null ? 'c-na' : score >= 90 ? 'c-good' : score >= 50 ? 'c-avg' : 'c-bad'; };
    var mcls = function (s) { return s == null ? 'c-na' : s >= 0.9 ? 'c-good' : s >= 0.5 ? 'c-avg' : 'c-bad'; };

    function toast(msg, ms) {
        var t = document.createElement('div'); t.className = 'toast'; t.textContent = msg; document.body.appendChild(t);
        setTimeout(function () { t.remove(); }, ms || 3500);
    }
    function api(action, body, q) {
        var url = API + '?action=' + action + (q ? '&' + q : '');
        var opt = body ? { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body), credentials: 'same-origin' } : { credentials: 'same-origin' };
        return fetch(url, opt).then(function (r) {
            return r.json().catch(function () { throw new Error('The server answered HTTP ' + r.status + ' (not JSON).'); });
        }).then(function (j) { if (!j.success) throw new Error(j.error || 'Failed'); return j; });
    }
    function busy(btn, on, label) {
        if (!btn) return;
        if (on) { btn.dataset.lbl = btn.innerHTML; btn.disabled = true; btn.innerHTML = '<span class="spinner"></span> ' + esc(label || 'Working…'); }
        else { btn.disabled = false; if (btn.dataset.lbl) btn.innerHTML = btn.dataset.lbl; }
    }
    function applyCan() {
        document.querySelectorAll('[data-need]').forEach(function (b) { if (!S.can[b.dataset.need]) b.hidden = true; });
    }

    /* ---------------- pages ---------------- */
    function loadPages(keepId) {
        return api('pages').then(function (j) {
            S.pages = j.pages; S.can = j.can; S.info = j;
            applyCan();
            if (!$('tv-name').value) { $('tv-name').value = j.defaults.name; $('tv-email').value = j.defaults.email; $('tv-mobile').value = j.defaults.mobile; }
            var notes = '';
            if (!j.psi_key) notes += '<div class="note info">PageSpeed runs without an API key — Google allows only a few runs. For regular use add <span class="mono">define(\'PAGESPEED_API_KEY\', \'…\');</span> to config.php (free: Google Cloud → APIs &amp; Services → PageSpeed Insights API → Credentials).</div>';
            if (!j.meta_ready) notes += '<div class="note warn">META_ACCESS_TOKEN is not set in config.php, so Meta test leads can\'t be sent.</div>';
            $('notes').innerHTML = notes;
            var sel = $('page');
            if (!S.pages.length) {
                sel.innerHTML = '<option value="">No landing pages yet</option>';
                $('main').hidden = true;
                $('page-url').innerHTML = S.can.edit ? 'Add the landing page your ads send people to.' : 'No landing pages have been added yet.';
                $('edit-page').hidden = true; $('run-all').hidden = true; $('pdf-btn').hidden = true;
                return;
            }
            $('main').hidden = false; $('pdf-btn').hidden = !S.can.pdf;
            $('edit-page').hidden = !S.can.edit; $('run-all').hidden = !S.can.run;
            sel.innerHTML = S.pages.map(function (p) {
                var m = p.last.mobile && p.last.mobile.scores.performance ? ' · mobile ' + p.last.mobile.scores.performance.score : '';
                return '<option value="' + p.id + '">' + esc(p.name) + m + '</option>';
            }).join('');
            var want = keepId || (function () { try { return +localStorage.getItem('pq-lph-page'); } catch (e) { return 0; } })();
            if (want && S.pages.some(function (p) { return p.id === want; })) sel.value = String(want);
            return openPage(+sel.value);
        });
    }
    function openPage(id) {
        try { localStorage.setItem('pq-lph-page', String(id)); } catch (e) {}
        S.page = S.pages.filter(function (p) { return p.id === id; })[0];
        S.meta = null; S.lp = null;
        $('page-url').innerHTML = '<a href="' + esc(S.page.url) + '" target="_blank" rel="noopener">' + esc(S.page.url) + '</a>';
        fillForm(S.page.form);
        return api('page', null, 'id=' + id).then(function (j) {
            S.page = j.page; S.runs = { latest: j.latest || {}, history: j.history || [] };
            var l = S.runs.latest;
            S.meta = l.meta_test ? l.meta_test.result : null; S.lp = l.lp_test ? l.lp_test.result : null;
            renderPsi(); renderScan(); renderTest('meta'); renderTest('lp'); renderHist();
        });
    }
    function fillForm(f) {
        f = f || {}; var fl = f.fields || {};
        $('lt-endpoint').value = f.endpoint || ''; $('lt-f-name').value = fl.name || ''; $('lt-f-email').value = fl.email || ''; $('lt-f-mobile').value = fl.mobile || '';
    }

    /* ---------------- PageSpeed ---------------- */
    var CAT = [['performance', 'Performance'], ['accessibility', 'Accessibility'], ['best-practices', 'Best Practices'], ['seo', 'SEO']];
    function gauge(score, label) {
        var c = cls(score), r = 42, L = 2 * Math.PI * r, f = score == null ? 0 : score / 100;
        return '<div class="gauge"><svg viewBox="0 0 100 100" role="img" aria-label="' + esc(label + ' ' + (score == null ? 'not measured' : score)) + '">' +
            '<circle cx="50" cy="50" r="' + r + '" fill="none" stroke-width="8" class="ring-bg"/>' +
            '<circle cx="50" cy="50" r="' + r + '" fill="none" stroke-width="8" class="' + c + '" stroke-linecap="round" stroke-dasharray="' + (L * f) + ' ' + L + '" transform="rotate(-90 50 50)"/>' +
            '<text x="50" y="59" text-anchor="middle" class="' + c + '" style="stroke:none">' + (score == null ? '–' : score) + '</text></svg>' +
            '<div class="lbl">' + esc(label) + '</div></div>';
    }
    function renderPsi() {
        var run = S.runs.latest['psi_' + S.strat];
        $('psi-when').textContent = run ? 'Run ' + fmtAt(run.at) : '';
        if (!run || !run.result) {
            $('psi').innerHTML = '<div class="empty">No ' + S.strat + ' PageSpeed run yet.' + (S.can.run ? ' Click <b>Run PageSpeed</b> (takes up to a minute per device).' : '') + '</div>';
            return;
        }
        var r = run.result, sc = r.scores || {}, h = '<div class="gauges">';
        CAT.forEach(function (c) { if (sc[c[0]]) h += gauge(sc[c[0]].score, sc[c[0]].title || c[1]); });
        Object.keys(sc).forEach(function (k) { if (!CAT.some(function (c) { return c[0] === k; })) h += gauge(sc[k].score, sc[k].title || k); });
        h += '</div><div class="legend"><span><i class="tri"></i>0–49</span><span><i class="sq"></i>50–89</span><span><i class="ci"></i>90–100</span></div>';
        h += '<div class="psi-body"><div><h3>Metrics</h3><div class="metrics">';
        ['fcp', 'lcp', 'tbt', 'cls', 'si'].forEach(function (k) {
            var m = (r.metrics || {})[k] || {};
            h += '<div class="metric"><span class="mk ' + mcls(m.score) + '"></span><div><div class="ml">' + esc(m.label || k) + '</div><div class="mv ' + mcls(m.score) + '" style="stroke:none">' + esc(m.value || '–') + '</div></div></div>';
        });
        h += '</div>';
        if (r.field) h += '<p class="faint" style="margin:8px 0 0">Real-user data (Chrome users, last 28 days): <b>' + esc(String(r.field).replace(/_/g, ' ').toLowerCase()) + '</b></p>';
        if ((r.opportunities || []).length) {
            h += '<div class="opps"><h3>Biggest fixes</h3>' + r.opportunities.map(function (o) {
                return '<div class="opp"><span class="t">' + esc(o.title) + (o.value ? ' <span class="faint">' + esc(o.value) + '</span>' : '') + '</span>' +
                    (o.savings_ms ? '<span class="s">save ~' + (o.savings_ms >= 1000 ? (o.savings_ms / 1000).toFixed(1) + ' s' : o.savings_ms + ' ms') + '</span>' : '') + '</div>';
            }).join('') + '</div>';
        }
        h += '</div><div>' + (r.screenshot ? '<div class="shot"><img alt="How the page looked when loaded" src="' + esc(r.screenshot) + '"></div>' : '') + '</div></div>';
        h += '<div class="psi-meta">Tested ' + esc(r.url) + ' · Lighthouse ' + esc(r.lighthouse) + ' · values are estimated and may vary between runs.</div>';
        $('psi').innerHTML = h;
    }
    function runPsi(strat) {
        var btn = $('psi-run');
        busy(btn, true, 'PageSpeed ' + strat + '…');
        return api('pagespeed', { id: S.page.id, strategy: strat }).then(function (j) {
            S.runs.latest['psi_' + strat] = { at: j.result.at, result: j.result };
            S.strat = strat; setTab(); renderPsi();
        }).catch(function (e) { toast(e.message, 7000); $('psi').insertAdjacentHTML('afterbegin', '<div class="note bad">' + esc(e.message) + '</div>'); })
          .finally(function () { busy(btn, false); });
    }
    function setTab() {
        document.querySelectorAll('#psi-tabs .tab').forEach(function (t) { var on = t.dataset.s === S.strat; t.classList.toggle('on', on); t.setAttribute('aria-selected', on); });
    }

    /* ---------------- checks ---------------- */
    var ST = { pass: 'Pass', warn: 'Check', fail: 'Fix', info: 'Info' };
    function renderScan() {
        var run = S.runs.latest.scan;
        $('scan-when').textContent = run ? 'Checked ' + fmtAt(run.at) : '';
        if (!run || !run.result) { $('scan-counts').innerHTML = ''; $('scan').innerHTML = '<div class="empty">Not checked yet.</div>'; return; }
        var ch = run.result.checks || [], n = { pass: 0, warn: 0, fail: 0 };
        ch.forEach(function (c) { if (n[c.status] != null) n[c.status]++; });
        $('scan-counts').innerHTML = '<span class="pill pass">' + n.pass + ' pass</span><span class="pill warn">' + n.warn + ' to check</span><span class="pill fail">' + n.fail + ' to fix</span>';
        var order = { fail: 0, warn: 1, pass: 2, info: 3 };
        $('scan').innerHTML = '<div class="checks">' + ch.slice().sort(function (a, b) { return order[a.status] - order[b.status]; }).map(function (c) {
            return '<div class="chk"><span class="pill ' + c.status + '">' + ST[c.status] + '</span><div style="min-width:0"><div class="ct">' + esc(c.label) + '</div><div class="cd">' + esc(c.detail) + '</div></div></div>';
        }).join('') + '</div>' + ((run.result.endpoints || []).length ? '<p class="faint" style="margin:10px 0 0">Form handlers named in the page scripts: ' + run.result.endpoints.map(esc).join(' · ') + '</p>' : '');
    }
    function runScan() {
        var btn = $('scan-run'); busy(btn, true, 'Checking…');
        return api('scan', { id: S.page.id }).then(function (j) {
            S.runs.latest.scan = { at: j.result.at, result: j.result };
            if (j.result.page) { S.page = j.result.page; fillForm(S.page.form); }
            renderScan();
            if (j.result.form_saved) toast('Lead form detected and saved for test leads.');
        }).catch(function (e) { toast(e.message, 7000); }).finally(function () { busy(btn, false); });
    }

    /* ---------------- test leads ---------------- */
    function vals() { return { name: $('tv-name').value.trim(), email: $('tv-email').value.trim(), mobile: $('tv-mobile').value.trim() }; }
    function checkVals() {
        var v = vals();
        if (!/test/i.test(v.name)) return 'The name must contain “test”.';
        if (!/test/i.test(v.email) || !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(v.email)) return 'The email must be valid and contain “test”.';
        var m = v.mobile.replace(/\D/g, '').slice(-10);
        if (!/^[6-9]\d{9}$/.test(m)) return 'Enter a 10-digit mobile number.';
        return '';
    }
    function loadForms() {
        return api('meta_forms').then(function (j) {
            S.forms = j.forms;
            var sel = $('mt-form');
            if (!j.forms.length) { sel.innerHTML = '<option value="">No Meta lead forms in the leads yet</option>'; return; }
            sel.innerHTML = j.forms.map(function (f) {
                return '<option value="' + esc(f.id) + '" data-page="' + esc(f.page_id) + '">' + esc((f.name || 'Form ' + f.id) + (f.status && f.status !== 'ACTIVE' ? ' (' + f.status.toLowerCase() + ')' : '') + ' · ' + f.leads + ' leads, last ' + String(f.last).slice(0, 10)) + '</option>';
            }).join('');
        }).catch(function (e) { $('mt-form').innerHTML = '<option value="">' + esc(e.message) + '</option>'; });
    }
    function valsHtml(v, extra) {
        return '<dl class="kv"><dt>Name</dt><dd>' + esc(v.name) + '</dd><dt>Email</dt><dd>' + esc(v.email) + '</dd><dt>Mobile</dt><dd>' + esc(v.mobile) + '</dd>' + (extra || '') + '</dl>';
    }
    function pre(o) { return '<pre>' + esc(typeof o === 'string' ? o : JSON.stringify(o, null, 2)) + '</pre>'; }
    function renderTest(kind) {
        var r = kind === 'meta' ? S.meta : S.lp, out = $(kind === 'meta' ? 'mt-out' : 'lt-out');
        $(kind === 'meta' ? 'mt-when' : 'lt-when').textContent = r ? 'Sent ' + fmtAt(r.sent_at) : '';
        if (!r) { out.innerHTML = ''; return; }
        var h = '<div style="margin-top:12px"><span class="pill ' + (r.ok ? 'pass' : 'fail') + '">' + (r.ok ? 'Sent' : 'Failed') + '</span> ';
        if (kind === 'meta') {
            h += r.ok ? 'Lead ID <span class="mono">' + esc(r.lead_id) + '</span>' + (r.deleted ? ' · ' + r.deleted + ' old test lead deleted' : '') : esc(r.error);
            h += '</div>' + valsHtml(r.values, '<dt>Form</dt><dd>' + esc((r.form.name || '') + ' ' + r.form.id) + '</dd>');
            h += '<div class="steps">' + (r.steps || []).map(function (s) {
                var c = s.call || {};
                return '<details class="step"><summary><span class="pill ' + (c.ok ? 'pass' : 'fail') + '">' + (c.http || '—') + '</span><span class="grow"><b>' + esc(s.step) + '</b> <span class="faint mono">' + esc(c.method + ' ' + c.path) + '</span></span></summary>' +
                    pre({ request: { method: c.method, path: c.path, params: c.params }, http: c.http, response: c.response, note: c.note }) + '</details>';
            }).join('') + '</div>';
        } else {
            h += 'HTTP <span class="mono">' + esc(r.http) + '</span> in ' + esc(r.time_ms) + ' ms' + (r.error ? ' · ' + esc(r.error) : '') + '</div>';
            h += valsHtml(r.values, '<dt>Posted to</dt><dd>' + esc(r.method + ' ' + r.endpoint) + '</dd>' + (r.response_text ? '<dt>Page said</dt><dd>' + esc(r.response_text) + '</dd>' : ''));
            h += '<div class="steps"><details class="step"><summary><span class="pill dim">sent</span><span class="grow"><b>Form data sent</b></span></summary>' + pre(r.sent) + '</details>' +
                 '<details class="step"><summary><span class="pill ' + (r.ok ? 'pass' : 'fail') + '">' + esc(r.http) + '</span><span class="grow"><b>Response</b> <span class="faint mono">' + esc(r.final_url) + '</span></span></summary>' + pre(r.response || '(empty)') + '</details></div>';
        }
        h += '<div class="arrive" id="' + kind + '-arrive"></div>';
        out.innerHTML = h;
        if (r.arrive) renderArrive(kind, r.arrive); else $(kind + '-arrive').innerHTML = '<button class="btn sm" type="button" data-arrive="' + kind + '">Did it reach the lead table &amp; CRM?</button>';
    }
    function renderArrive(kind, a) {
        var el = $(kind + '-arrive'); if (!el) return;
        if (a.waiting) { el.innerHTML = '<span class="spinner"></span> Waiting for the lead in the lead table… (' + a.tries + ')'; return; }
        if (!a.leads || !a.leads.length) {
            el.innerHTML = '<span class="pill warn">Not in the lead table</span> <span class="muted">Checked ' + esc(fmtAt(a.checked_at)) + '. ' +
                (kind === 'meta' ? 'Meta delivers through the webhook — it can take a minute. If it never comes, check the page is subscribed to the app (leadgen webhook).' : 'The form answered, but no lead with this email / mobile was saved — check the form handler.') +
                '</span> <button class="btn sm" type="button" data-arrive="' + kind + '">Check again</button>';
            return;
        }
        el.innerHTML = a.leads.map(function (l) {
            var crm = l.crm || {}, st = crm.state || 'not_sent', pc = st === 'sent' || st === 'existing' ? 'pass' : st === 'failed' ? 'fail' : 'warn';
            return '<div><span class="pill pass">In lead table</span> <span class="pill ' + pc + '">CRM: ' + esc(crm.label || st.replace('_', ' ')) + '</span>' +
                '<dl class="kv"><dt>Lead #</dt><dd>' + esc(l.id) + (l.db ? ' (' + esc(l.db) + ')' : '') + '</dd><dt>Created</dt><dd>' + esc(l.created) + '</dd><dt>Source</dt><dd>' + esc(l.source || '—') + (l.campaign ? ' · ' + esc(l.campaign) : '') + '</dd>' +
                (l.keyword || l.gclid ? '<dt>Keyword / gclid</dt><dd>' + esc((l.keyword || '—') + ' / ' + (l.gclid || '—')) + '</dd>' : '') +
                (crm.message || crm.reason ? '<dt>CRM said</dt><dd>' + esc(crm.message || crm.reason) + '</dd>' : '') + '</dl>' +
                (l.crm_raw ? '<details class="step"><summary><span class="pill dim">CRM</span><span class="grow"><b>CRM response</b></span></summary>' + pre(l.crm_raw) + '</details>' : '') + '</div>';
        }).join('');
    }
    function watch(kind, tries) {
        var r = kind === 'meta' ? S.meta : S.lp; if (!r) return;
        tries = tries || 0;
        var q = 'since=' + encodeURIComponent(r.sent_at) + '&email=' + encodeURIComponent(r.values.email) + '&mobile=' + encodeURIComponent(String(r.values.mobile).indexOf('*') < 0 ? r.values.mobile : $('tv-mobile').value) + (r.lead_id ? '&leadgen_id=' + encodeURIComponent(r.lead_id) : '');
        r.arrive = { waiting: true, tries: tries + 1 }; renderArrive(kind, r.arrive);
        api('find_lead', null, q).then(function (j) {
            var found = j.leads.length && j.leads.every(function (l) { return l.crm && l.crm.state !== 'not_sent'; });
            if ((!j.leads.length || !found) && tries < 5) { setTimeout(function () { watch(kind, tries + 1); }, 6000); if (!j.leads.length) return; }
            r.arrive = { leads: j.leads, checked_at: j.checked_at }; renderArrive(kind, r.arrive);
        }).catch(function (e) { r.arrive = { leads: [], checked_at: '' }; renderArrive(kind, r.arrive); toast(e.message); });
    }
    function sendMeta() {
        var err = checkVals(); if (err) return toast(err, 5000);
        var sel = $('mt-form'), fid = sel.value; if (!fid) return toast('Choose a lead form.');
        var v = vals();
        if (!confirmSend('Meta lead form', v)) return;
        var btn = $('mt-send'); busy(btn, true, 'Sending through Meta…');
        api('meta_test', { id: S.page.id, form_id: fid, page_id: sel.selectedOptions[0].dataset.page || '', name: v.name, email: v.email, mobile: v.mobile }).then(function (j) {
            S.meta = j.result; renderTest('meta'); refreshHist();
            if (j.result.ok) watch('meta'); else toast(j.result.error, 7000);
        }).catch(function (e) { toast(e.message, 7000); }).finally(function () { busy(btn, false); });
    }
    function formIn() {
        return { endpoint: $('lt-endpoint').value.trim(), method: (S.page.form && S.page.form.method) || 'POST',
                 fields: { name: $('lt-f-name').value.trim(), email: $('lt-f-email').value.trim(), mobile: $('lt-f-mobile').value.trim() },
                 extra: (S.page.form && S.page.form.extra) || {} };
    }
    function sendLp() {
        var err = checkVals(); if (err) return toast(err, 5000);
        var f = formIn(); if (!f.endpoint || !f.fields.mobile) return toast('Run “Check page” to detect the form, or fill the form address and the phone field.', 6000);
        var v = vals();
        if (!confirmSend('landing page form', v)) return;
        var btn = $('lt-send'); busy(btn, true, 'Posting the form…');
        api('lp_test', { id: S.page.id, name: v.name, email: v.email, mobile: v.mobile, form: f }).then(function (j) {
            S.lp = j.result; renderTest('lp'); refreshHist();
            if (j.result.ok) watch('lp'); else toast('The form answered HTTP ' + j.result.http, 7000);
        }).catch(function (e) { toast(e.message, 7000); }).finally(function () { busy(btn, false); });
    }
    function confirmSend(where, v) {
        return window.confirm('Send a test lead through the ' + where + '?\n\n' + v.name + '\n' + v.email + '\n' + v.mobile + '\n\nIt goes to the CRM like a real lead (the dashboards leave it out because of “test”).');
    }
    function saveForm() {
        api('save_page', { id: S.page.id, name: S.page.name, url: S.page.url, form: formIn() }).then(function () { S.page.form = formIn(); toast('Form settings saved.'); }).catch(function (e) { toast(e.message, 6000); });
    }

    /* ---------------- history ---------------- */
    var KIND = { psi_mobile: 'PageSpeed · mobile', psi_desktop: 'PageSpeed · desktop', scan: 'Page checks', meta_test: 'Meta test lead', lp_test: 'LP test lead' };
    function renderHist() {
        var h = S.runs.history || [];
        $('hist').innerHTML = !h.length ? '<div class="empty">Nothing run yet.</div>' : '<div style="overflow:auto"><table class="hist"><thead><tr><th>When</th><th>Check</th><th>Result</th><th>By</th><th>Summary</th></tr></thead><tbody>' +
            h.map(function (r) { return '<tr><td style="white-space:nowrap">' + esc(fmtAt(r.at)) + '</td><td>' + esc(KIND[r.kind] || r.kind) + '</td><td><span class="pill ' + (r.ok ? 'pass' : 'fail') + '">' + (r.ok ? 'OK' : 'Issue') + '</span></td><td>' + esc(r.by) + '</td><td>' + esc(r.summary) + '</td></tr>'; }).join('') + '</tbody></table></div>';
    }
    function refreshHist() { api('page', null, 'id=' + S.page.id).then(function (j) { S.runs.history = j.history || []; renderHist(); }).catch(function () {}); }

    /* ---------------- PDF ---------------- */
    function loadScript(src) {
        return new Promise(function (res, rej) { var s = document.createElement('script'); s.src = src; s.onload = res; s.onerror = function () { rej(new Error('load')); }; document.head.appendChild(s); });
    }
    function pc(score) { return score == null ? '' : score >= 90 ? 'g' : score >= 50 ? 'a' : 'b'; }
    function mc(s) { return s == null ? '' : s >= 0.9 ? 'g' : s >= 0.5 ? 'a' : 'b'; }
    function buildPdf() {
        var p = S.page, l = S.runs.latest, h = '<div class="brk"><h1>LP Hygiene report</h1><div class="sm">' + esc(p.name) + ' · ' + esc(p.url) + '<br>Generated ' + esc(new Date().toLocaleString('en-IN')) + (S.info.project ? ' · ' + esc(S.info.project) : '') + '</div></div>';
        ['mobile', 'desktop'].forEach(function (s) {
            var run = l['psi_' + s]; if (!run || !run.result) return;
            var r = run.result, sc = r.scores || {};
            h += '<div class="brk"><h2>PageSpeed — ' + (s === 'mobile' ? 'Mobile' : 'Desktop') + ' <span class="sm">(' + esc(fmtAt(run.at)) + ')</span></h2><table><tr>' +
                Object.keys(sc).map(function (k) { return '<th>' + esc(sc[k].title) + '</th>'; }).join('') + '</tr><tr>' +
                Object.keys(sc).map(function (k) { return '<td class="' + pc(sc[k].score) + '" style="font-size:16px">' + (sc[k].score == null ? '–' : sc[k].score) + '</td>'; }).join('') + '</tr></table>' +
                '<table style="margin-top:6px"><tr>' + ['fcp', 'lcp', 'tbt', 'cls', 'si'].map(function (k) { return '<th>' + esc(((r.metrics || {})[k] || {}).label || k) + '</th>'; }).join('') + '</tr><tr>' +
                ['fcp', 'lcp', 'tbt', 'cls', 'si'].map(function (k) { var m = (r.metrics || {})[k] || {}; return '<td class="' + mc(m.score) + '">' + esc(m.value || '–') + '</td>'; }).join('') + '</tr></table>';
            if ((r.opportunities || []).length) h += '<div class="sm" style="margin-top:6px"><b>Biggest fixes:</b> ' + r.opportunities.slice(0, 6).map(function (o) { return esc(o.title) + (o.savings_ms ? ' (~' + (o.savings_ms / 1000).toFixed(1) + ' s)' : ''); }).join(' · ') + '</div>';
            h += '</div>';
        });
        if (l.scan && l.scan.result) {
            h += '<div><h2>Page checks <span class="sm">(' + esc(fmtAt(l.scan.at)) + ')</span></h2><table><tr><th style="width:150px">Check</th><th style="width:60px">Result</th><th>Detail</th></tr>' +
                l.scan.result.checks.map(function (c) { return '<tr class="brk"><td>' + esc(c.label) + '</td><td class="' + ({ pass: 'g', warn: 'a', fail: 'b' }[c.status] || '') + '">' + ST[c.status] + '</td><td>' + esc(c.detail) + '</td></tr>'; }).join('') + '</table></div>';
        }
        [['meta', S.meta, 'Meta test lead (Graph API)'], ['lp', S.lp, 'Landing page test lead (Google)']].forEach(function (t) {
            var r = t[1]; if (!r) return;
            h += '<div class="brk"><h2>' + t[2] + ' <span class="sm">(' + esc(fmtAt(r.sent_at)) + ')</span></h2><table>' +
                '<tr><th style="width:150px">Result</th><td class="' + (r.ok ? 'g' : 'b') + '">' + (r.ok ? 'Sent' : 'Failed') + (r.error ? ' — ' + esc(r.error) : '') + '</td></tr>' +
                '<tr><th>Name</th><td>' + esc(r.values.name) + '</td></tr><tr><th>Email</th><td>' + esc(r.values.email) + '</td></tr><tr><th>Mobile</th><td>' + esc(r.values.mobile) + '</td></tr>' +
                (t[0] === 'meta' ? '<tr><th>Form</th><td>' + esc((r.form.name || '') + ' ' + r.form.id) + '</td></tr><tr><th>Lead ID</th><td>' + esc(r.lead_id || '—') + '</td></tr><tr><th>Old test leads deleted</th><td>' + esc(r.deleted) + '</td></tr>'
                    : '<tr><th>Posted to</th><td>' + esc(r.method + ' ' + r.endpoint) + '</td></tr><tr><th>HTTP</th><td>' + esc(r.http) + ' (' + esc(r.time_ms) + ' ms)</td></tr>');
            var a = r.arrive && r.arrive.leads;
            if (a) h += '<tr><th>Lead table</th><td>' + (a.length ? a.map(function (x) { return 'Lead #' + esc(x.id) + ' at ' + esc(x.created) + ' · CRM: ' + esc((x.crm && (x.crm.label || x.crm.state)) || '—'); }).join('<br>') : '<span class="a">Not found when checked</span>') + '</td></tr>';
            h += '</table>';
            if (t[0] === 'meta') h += '<table style="margin-top:6px"><tr><th>Step</th><th style="width:44px">HTTP</th><th>Response</th></tr>' + (r.steps || []).map(function (s) {
                return '<tr class="brk"><td>' + esc(s.step) + '<div class="sm">' + esc(s.call.method + ' ' + s.call.path) + '</div></td><td class="' + (s.call.ok ? 'g' : 'b') + '">' + esc(s.call.http) + '</td><td><pre>' + esc(JSON.stringify(s.call.response).slice(0, 700)) + '</pre></td></tr>';
            }).join('') + '</table>';
            else h += '<div class="sm" style="margin-top:6px"><b>Response:</b></div><pre>' + esc(String(r.response || '').slice(0, 1200)) + '</pre>';
            h += '</div>';
        });
        $('pdf').innerHTML = h;
    }
    function downloadPdf() {
        var btn = $('pdf-btn'); busy(btn, true, 'Building PDF…');
        buildPdf();
        var name = 'LP_Hygiene_' + S.page.name.replace(/[^A-Za-z0-9]+/g, '_').replace(/^_|_$/g, '') + '_' + new Date().toISOString().slice(0, 10) + '.pdf';
        (window.html2pdf ? Promise.resolve() : loadScript('https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js')).then(function () {
            var el = $('pdf'); el.style.left = '0'; el.style.zIndex = '-1';
            return window.html2pdf().set({ margin: [10, 8, 10, 8], filename: name, image: { type: 'jpeg', quality: 0.95 }, html2canvas: { scale: 2, backgroundColor: '#ffffff', useCORS: true },
                jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' }, pagebreak: { mode: ['css', 'legacy'], avoid: '.brk' } }).from(el).save().finally(function () { el.style.left = '-10000px'; });
        }).catch(function () {
            toast('PDF library could not load — opening print; choose “Save as PDF”.', 6000);
            setTimeout(function () { window.print(); }, 300);
        }).finally(function () { busy(btn, false); });
    }

    /* ---------------- dialog ---------------- */
    function pageDialog(edit) {
        var d = $('dlg');
        $('dlg-title').textContent = edit ? 'Edit landing page' : 'Add landing page';
        $('pg-name').value = edit ? S.page.name : ''; $('pg-url').value = edit ? S.page.url : 'https://';
        $('pg-del').hidden = !edit; d.dataset.edit = edit ? '1' : '';
        d.showModal();
    }
    $('dlg').addEventListener('close', function () {
        var d = $('dlg'); if (d.returnValue !== 'save') return;
        var body = { name: $('pg-name').value, url: $('pg-url').value.trim() }; if (d.dataset.edit) body.id = S.page.id;
        api('save_page', body).then(function (j) { toast('Saved.'); return loadPages(j.id); }).catch(function (e) { toast(e.message, 6000); });
    });
    $('pg-del').addEventListener('click', function () {
        if (!window.confirm('Delete “' + S.page.name + '” and its check history?')) return;
        $('dlg').close('cancel');
        api('delete_page', { id: S.page.id }).then(function () { try { localStorage.removeItem('pq-lph-page'); } catch (e) {} return loadPages(); }).catch(function (e) { toast(e.message); });
    });

    /* ---------------- wiring ---------------- */
    $('page').addEventListener('change', function () { if (this.value) openPage(+this.value); });
    $('add-page').addEventListener('click', function () { pageDialog(false); });
    $('edit-page').addEventListener('click', function () { pageDialog(true); });
    $('psi-tabs').addEventListener('click', function (e) { var t = e.target.closest('.tab'); if (!t) return; S.strat = t.dataset.s; setTab(); renderPsi(); });
    $('psi-run').addEventListener('click', function () { runPsi(S.strat); });
    $('scan-run').addEventListener('click', runScan);
    $('run-all').addEventListener('click', function () {
        var b = $('run-all'); busy(b, true, 'Running…');
        runScan().then(function () { return runPsi('mobile'); }).then(function () { return runPsi('desktop'); }).then(function () { S.strat = 'mobile'; setTab(); renderPsi(); refreshHist(); })
            .finally(function () { busy(b, false); });
    });
    $('mt-send').addEventListener('click', sendMeta);
    $('lt-send').addEventListener('click', sendLp);
    $('lt-save').addEventListener('click', saveForm);
    $('pdf-btn').addEventListener('click', downloadPdf);
    $('tv-new').addEventListener('click', function () {
        var d = new Date(), p = function (n) { return String(n).padStart(2, '0'); };
        $('tv-name').value = 'Test PerformIQ ' + p(d.getDate()) + p(d.getHours()) + p(d.getMinutes());
        $('tv-email').value = 'test.performiq.' + d.getFullYear() + p(d.getMonth() + 1) + p(d.getDate()) + p(d.getHours()) + p(d.getMinutes()) + p(d.getSeconds()) + '@webzaa.in';
    });
    document.addEventListener('click', function (e) { var b = e.target.closest('[data-arrive]'); if (b) watch(b.dataset.arrive); });

    loadPages().then(loadForms).catch(function (e) { $('notes').innerHTML = '<div class="note bad">' + esc(e.message) + '</div>'; });
})();
</script>
<?php } ?>
</body>
</html>
