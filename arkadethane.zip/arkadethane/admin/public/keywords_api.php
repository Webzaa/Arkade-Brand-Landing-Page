<?php
/**
 * keywords_api.php — backend of Keyword Analysis (keywords.php). Logic: app/Ads/keywords.php.
 *
 *   GET ?since=Y-m-d&until=Y-m-d[&force=1]   keywords, search terms, totals, insights
 *
 * Access: Users & Roles → Keyword Analysis → View (app/Core/access.php). Numbers a role may not see
 * (Users & Roles → Hide numbers) are removed here. 'can_export' tells the page whether to show Export CSV.
 */
require_once dirname(__DIR__) . '/app/Core/db.php';      // sign-in + roles & permissions
require_once dirname(__DIR__) . '/app/Ads/keywords.php';

function kwJson(array $out, int $code = 200): never
{
    while (ob_get_level() > 0) {
        @ob_end_clean();
    }
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    echo json_encode($out, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PARTIAL_OUTPUT_ON_ERROR);
    exit;
}

/** Removes the numbers this viewer's role hides. */
function kwStrip(array $r, array $hidden): array
{
    $drop = [];
    if (in_array('qualified', $hidden, true)) {
        array_push($drop, 'ql', 'ql_pct', 'cpql');
    }
    if (in_array('cpql', $hidden, true)) {
        $drop[] = 'cpql';
    }
    if (in_array('sitevisits', $hidden, true)) {
        array_push($drop, 'sv', 'cpsv');
    }
    if (in_array('cpsv', $hidden, true)) {
        $drop[] = 'cpsv';
    }
    foreach ($drop as $k) {
        unset($r[$k]);
    }
    return $r;
}

$today = date('Y-m-d');
$s = (string) ($_GET['since'] ?? '');
$u = (string) ($_GET['until'] ?? '');
$ok = fn($d) => preg_match('/^\d{4}-\d{2}-\d{2}$/', $d) && DateTime::createFromFormat('!Y-m-d', $d) && DateTime::createFromFormat('!Y-m-d', $d)->format('Y-m-d') === $d;
if (!$ok($s) || !$ok($u)) {
    $u = date('Y-m-d', strtotime('-1 day'));
    $s = date('Y-m-d', strtotime('-7 days'));
}
if ($u > $today) {
    $u = $today;
}
if ($s > $u) {
    kwJson(['success' => false, 'error' => 'The start date is after the end date.'], 400);
}
if ((new DateTime($s))->diff(new DateTime($u))->days > 1130) {
    kwJson(['success' => false, 'error' => 'Choose at most 37 months (the most Meta keeps).'], 400);
}

try {
    @set_time_limit(180);
    $hidden = function_exists('pqHiddenMetrics') ? pqHiddenMetrics() : [];
    $d = kwData($s, $u, !empty($_GET['force']));
    $ins = kwInsights($d, $hidden);
    $f = fn($d0) => date(substr($s, 0, 4) === substr($u, 0, 4) && $d0 === $s ? 'j M' : 'j M Y', strtotime($d0));
    kwJson(['success' => true, 'since' => $s, 'until' => $u, 'label' => $s === $u ? date('j M Y', strtotime($s)) : $f($s) . ' – ' . date('j M Y', strtotime($u)),
            'hidden' => $hidden, 'can_export' => pqCan('keywords', 'export'), 'configured' => $d['configured'],
            'total' => kwStrip($d['total'], $hidden),
            'keywords' => array_map(fn($r) => kwStrip($r, $hidden), $d['keywords']),
            'search_terms' => $d['search_terms'],
            'no_keyword' => kwStrip($d['no_keyword'], $hidden),
            'insights' => $ins, 'warnings' => $d['warnings']]);
} catch (Throwable $e) {
    error_log('[keywords_api] ' . $e->getMessage() . ' @ ' . $e->getFile() . ':' . $e->getLine());
    kwJson(['success' => false, 'error' => $e->getMessage()], 500);
}
