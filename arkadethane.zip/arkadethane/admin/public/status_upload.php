<?php
/**
 * status_upload.php — "Upload Lead Status": update lead status and site visits (the data behind
 * CPQL and CPSV) from a CRM export, separately from the platform dashboards.
 *
 * 1 Upload file (CSV / XLSX / XLS) → 2 Unique ID (mobile, email, uniqueid or any other lead column) → 3 Map columns + values
 * → 4 Preview → confirm → written to the lead table (logged, can be undone).
 * Rows not in the lead table: "Add missing leads" (edit, add as new leads, or download and import later) —
 * assets/js/missing_leads.js + app/Leads/missing_leads.php.
 * Backend: status_upload_api.php · logic: app/Leads/status_upload.php
 */
session_start();
if (($_SESSION['user_logged'] ?? '') !== 'Y') {
    header('Location: login.php');
    exit;
}
require_once dirname(__DIR__) . '/app/Core/db.php';
$h = fn($v) => htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');
$dbs = [];
foreach (leadDbKeys() as $k) {
    $dbs[$k] = leadDbLabel($k);
}
$defaultDb = appDbKey();
$showMql = defined('STATUS_UPLOAD_MQL') && STATUS_UPLOAD_MQL;   // MQL column: off unless config.php turns it on
$canAddMissing = !function_exists('pqCan') || pqCan('status', 'insert');   // Users & Roles → Upload Lead Status → Add missing leads
?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Upload Lead Status</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Sora:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
<script>
(function () {
    var root = document.documentElement, t = null;
    try { t = localStorage.getItem('performiq-theme'); } catch (e) {}
    root.setAttribute('data-theme', t === 'light' ? 'light' : 'dark');
    if (/[?&]embed=1(&|$)/.test(location.search)) root.classList.add('pq-embed');
    window.addEventListener('storage', function (e) {
        if (e.key === 'performiq-theme') root.setAttribute('data-theme', e.newValue === 'light' ? 'light' : 'dark');
    });
    window.setTheme = function (t) { root.setAttribute('data-theme', t === 'light' ? 'light' : 'dark'); };
})();
</script>
<style>
    :root, html[data-theme="dark"] {
        --bg: #0B0F1A; --surface: #111827; --surface-2: #161D2E; --border: #1E2A42; --border-strong: #2A3957;
        --text: #E2E8F0; --text-dim: #94A3B8; --text-faint: #64748B; --accent: #E8A820; --accent-soft: #E8A8201F;
        --hover: #1A2337; --good: #10B981; --good-soft: #10B9811F; --bad: #EF4444; --bad-soft: #EF44441A;
        --warn: #F59E0B; --warn-soft: #F59E0B1A; --info: #3B82F6; --info-soft: #3B82F61A; color-scheme: dark;
    }
    html[data-theme="light"] {
        --bg: #F4F6FA; --surface: #FFFFFF; --surface-2: #F8FAFC; --border: #E2E8F0; --border-strong: #CBD5E1;
        --text: #0F172A; --text-dim: #475569; --text-faint: #94A3B8; --accent: #B7791F; --accent-soft: #B7791F1A;
        --hover: #F1F5F9; --good: #059669; --good-soft: #0596691A; --bad: #DC2626; --bad-soft: #DC26261A;
        --warn: #B45309; --warn-soft: #B453091A; --info: #2563EB; --info-soft: #2563EB1A; color-scheme: light;
    }
    * { box-sizing: border-box; }
    body { margin: 0; background: var(--bg); color: var(--text); font: 14px/1.5 'Sora', system-ui, -apple-system, 'Segoe UI', sans-serif; }
    button, input, select { font: inherit; color: inherit; }
    .mono { font-family: 'JetBrains Mono', ui-monospace, monospace; font-variant-numeric: tabular-nums; }
    .wrap { max-width: 1180px; margin: 0 auto; padding: 28px 24px 60px; }
    .pq-embed .wrap { padding-top: 20px; }
    h1 { font-size: 22px; margin: 0 0 4px; letter-spacing: -.01em; }
    .sub { color: var(--text-dim); margin: 0 0 22px; font-size: 13px; }
    .pq-embed .page-head { display: none; }

    .steps { display: flex; gap: 8px; margin-bottom: 18px; flex-wrap: wrap; }
    .step { display: flex; align-items: center; gap: 10px; padding: 10px 14px; border: 1px solid var(--border); border-radius: 10px;
            background: var(--surface); color: var(--text-dim); font-size: 13px; flex: 1 1 200px; }
    .step b { width: 24px; height: 24px; border-radius: 50%; display: grid; place-items: center; font-size: 12px;
              background: var(--surface-2); border: 1px solid var(--border-strong); color: var(--text-dim); flex: none; }
    .step.on { border-color: var(--accent); color: var(--text); }
    .step.on b { background: var(--accent); border-color: var(--accent); color: #111; }
    .step.done b { background: var(--good); border-color: var(--good); color: #fff; }

    .card { background: var(--surface); border: 1px solid var(--border); border-radius: 12px; padding: 22px; margin-bottom: 18px; }
    .card h2 { font-size: 16px; margin: 0 0 4px; }
    .card .hint { color: var(--text-dim); font-size: 12.5px; margin: 0 0 16px; }
    .row { display: flex; gap: 14px; flex-wrap: wrap; align-items: flex-end; }
    label.f { display: flex; flex-direction: column; gap: 6px; font-size: 12px; color: var(--text-dim); min-width: 220px; flex: 1 1 220px; }
    select, input[type=text] { background: var(--surface-2); border: 1px solid var(--border-strong); border-radius: 8px; padding: 9px 11px; outline: none; min-width: 0; }
    select:focus, input[type=text]:focus { border-color: var(--accent); }

    .drop { display: block; border: 2px dashed var(--border-strong); border-radius: 12px; padding: 34px 20px; text-align: center; cursor: pointer;
            background: var(--surface-2); transition: border-color .15s, background .15s; }
    .drop:hover, .drop.over { border-color: var(--accent); background: var(--accent-soft); }
    .drop strong { display: block; font-size: 15px; margin-bottom: 6px; }
    .drop span { color: var(--text-dim); font-size: 12.5px; }

    .btn { border: 1px solid var(--border-strong); background: var(--surface-2); padding: 9px 16px; border-radius: 8px; cursor: pointer; font-weight: 600; font-size: 13px; }
    .btn:hover { background: var(--hover); }
    .btn.primary { background: var(--accent); border-color: var(--accent); color: #111; }
    .btn.primary:hover { filter: brightness(1.06); }
    .btn.danger { background: var(--bad); border-color: var(--bad); color: #fff; }
    .btn:disabled { opacity: .5; cursor: not-allowed; }
    .actions { display: flex; justify-content: space-between; gap: 10px; margin-top: 20px; flex-wrap: wrap; }

    .choice { display: grid; grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); gap: 12px; }
    .opt { border: 1px solid var(--border-strong); border-radius: 10px; padding: 16px; cursor: pointer; display: flex; gap: 12px; background: var(--surface-2); }
    .opt:hover { border-color: var(--text-faint); }
    .opt.sel { border-color: var(--accent); background: var(--accent-soft); }
    .opt input { margin-top: 3px; accent-color: var(--accent); }
    .opt strong { display: block; }
    .opt span { color: var(--text-dim); font-size: 12.5px; }
    .opt.off { opacity: .55; }
    .opt select { margin-top: 8px; width: 100%; }
    .idtest { margin: 10px 0 0; font-size: 12.5px; color: var(--text-dim); }
    .idtest b.good { color: var(--good); } .idtest b.bad { color: var(--bad); }

    .tbl-wrap { overflow: auto; border: 1px solid var(--border); border-radius: 10px; max-height: 460px; }
    table { width: 100%; border-collapse: collapse; font-size: 12.5px; }
    th { position: sticky; top: 0; background: var(--surface-2); color: var(--text-dim); font-weight: 600; text-align: left;
         padding: 9px 11px; border-bottom: 1px solid var(--border); white-space: nowrap; font-size: 11px; text-transform: uppercase; letter-spacing: .04em; }
    td { padding: 8px 11px; border-bottom: 1px solid var(--border); vertical-align: top; }
    tr:last-child td { border-bottom: 0; }
    td.n, th.n { text-align: right; }
    .pill { display: inline-block; padding: 1px 8px; border-radius: 99px; font-size: 11px; font-weight: 600; white-space: nowrap; }
    .pill.good { color: var(--good); background: var(--good-soft); }
    .pill.bad { color: var(--bad); background: var(--bad-soft); }
    .pill.warn { color: var(--warn); background: var(--warn-soft); }
    .pill.info { color: var(--info); background: var(--info-soft); }
    .pill.dim { color: var(--text-dim); background: var(--surface-2); border: 1px solid var(--border); }
    .old { color: var(--text-faint); text-decoration: line-through; }
    .arrow { color: var(--text-faint); padding: 0 4px; }
    .new { font-weight: 600; }
    .muted { color: var(--text-dim); }
    .faint { color: var(--text-faint); font-size: 11.5px; }

    .grid3 { display: grid; grid-template-columns: repeat(auto-fit, minmax(230px, 1fr)); gap: 14px; }
    .vals select { width: 100%; min-width: 170px; padding: 6px 9px; }
    .vals .badge-cell { min-width: 150px; }
    .warnrow td { background: var(--warn-soft); }
    .map-box { border: 1px solid var(--border); border-radius: 10px; padding: 14px; background: var(--surface-2); }
    .map-box h3 { margin: 0 0 2px; font-size: 13.5px; }
    .map-box p { margin: 0 0 10px; color: var(--text-dim); font-size: 12px; }
    .map-box select { width: 100%; }
    .db-col { font-family: 'JetBrains Mono', monospace; font-size: 11.5px; color: var(--accent); }
    .vals { margin-top: 18px; display: grid; grid-template-columns: repeat(auto-fit, minmax(480px, 1fr)); gap: 16px; }
    .vals input[type=text] { width: 100%; padding: 6px 9px; }

    .tiles { display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 10px; margin-bottom: 16px; }
    .tile { border: 1px solid var(--border); border-radius: 10px; padding: 12px 14px; background: var(--surface-2); }
    .tile div { font-size: 11px; color: var(--text-dim); text-transform: uppercase; letter-spacing: .05em; }
    .tile strong { display: block; font-size: 22px; margin-top: 4px; }
    .tile.good strong { color: var(--good); } .tile.bad strong { color: var(--bad); } .tile.accent strong { color: var(--accent); }
    .tabs { display: flex; gap: 6px; margin-bottom: 10px; flex-wrap: wrap; }
    .tab { border: 1px solid var(--border); background: var(--surface-2); border-radius: 99px; padding: 5px 12px; font-size: 12px; cursor: pointer; color: var(--text-dim); }
    .tab.on { border-color: var(--accent); color: var(--text); background: var(--accent-soft); }
    .note { padding: 11px 14px; border-radius: 10px; font-size: 12.5px; margin-bottom: 14px; border: 1px solid; }
    .note.warn { background: var(--warn-soft); border-color: var(--warn); color: var(--text); }
    .note.bad { background: var(--bad-soft); border-color: var(--bad); color: var(--text); }
    .note.good { background: var(--good-soft); border-color: var(--good); color: var(--text); }
    .hidden { display: none !important; }
    .chk { display: grid; grid-template-columns: 26px 1fr; gap: 4px 10px; padding: 10px 0; border-top: 1px solid var(--border); font-size: 13px; }
    .chk:first-child { border-top: 0; }
    .chk i { font-style: normal; width: 22px; height: 22px; border-radius: 50%; display: grid; place-items: center; font-size: 12px; font-weight: 700; }
    .chk i.ok { background: var(--good-soft); color: var(--good); }
    .chk i.no { background: var(--bad-soft); color: var(--bad); }
    .chk i.wa { background: var(--warn-soft); color: var(--warn); }
    .chk .d { color: var(--text-dim); font-size: 12px; grid-column: 2; }
    .chk .fx { grid-column: 2; font-size: 12px; padding: 8px 10px; border-radius: 8px; background: var(--surface-2); border: 1px solid var(--border); margin-top: 4px; }
    .drop.locked { opacity: .45; pointer-events: none; }
    #checks.collapsed #checks-list { display: none; }

    .overlay { position: fixed; inset: 0; background: rgba(2, 6, 23, .6); display: grid; place-items: center; z-index: 50; padding: 16px; }
    .dialog { background: var(--surface); border: 1px solid var(--border-strong); border-radius: 14px; padding: 22px; max-width: 520px; width: 100%; box-shadow: 0 20px 60px rgba(0, 0, 0, .45); }
    .dialog h3 { margin: 0 0 8px; font-size: 17px; }
    .dialog ul { margin: 10px 0 0; padding-left: 18px; color: var(--text-dim); font-size: 13px; }
    .spinner { width: 16px; height: 16px; border: 2px solid var(--border-strong); border-top-color: var(--accent); border-radius: 50%; display: inline-block; animation: spin .8s linear infinite; vertical-align: -3px; margin-right: 8px; }
    @keyframes spin { to { transform: rotate(360deg); } }
    @media (max-width: 640px) { .wrap { padding: 16px; } .vals { grid-template-columns: 1fr; } }
</style>
</head>
<body>
<div class="wrap">
    <div class="page-head">
        <h1>Upload Lead Status</h1>
        <p class="sub">Update lead status, site visits and platform — the numbers behind CPQL and CPSV — from a CRM export.</p>
    </div>

    <div class="steps" id="steps">
        <div class="step on" data-s="1"><b>1</b> Upload file</div>
        <div class="step" data-s="2"><b>2</b> Unique ID</div>
        <div class="step" data-s="3"><b>3</b> Map columns</div>
        <div class="step" data-s="4"><b>4</b> Review &amp; confirm</div>
    </div>

    <div id="msg"></div>

    <!-- CHECKS -->
    <section class="card" id="checks">
        <div style="display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap;">
            <div><h2>Before you upload</h2><p class="hint" style="margin:0;" id="checks-sub">Checking the server…</p></div>
            <button class="btn" id="recheck">↻ Check again</button>
        </div>
        <div id="checks-list" style="margin-top:14px;"></div>
    </section>

    <!-- STEP 1 -->
    <section class="card" id="s1">
        <h2>Upload the CRM export</h2>
        <p class="hint">CSV, XLSX or XLS. The first row must be the column headers. Leads that already exist are updated; rows that are not in the database can be added as new leads after the review (“Add missing leads”).</p>
        <?php if (count($dbs) > 1) { ?>
        <div class="row" style="margin-bottom:14px;">
            <label class="f" style="max-width:420px;">Lead database to update
                <select id="db">
                    <option value="all" selected>All databases — find each lead automatically</option>
                    <?php foreach ($dbs as $k => $l) { ?><option value="<?= $h($k) ?>"><?= $h($l) ?> only</option><?php } ?>
                </select>
            </label>
            <p class="hint" id="db-hint" style="margin:6px 0 0;">Each row is looked up in <?= $h(implode(' and ', $dbs)) ?>. A lead found in more than one is matched to the right one by the file's campaign column (step 3).</p>
        </div>
        <?php } else { ?>
        <input type="hidden" id="db" value="<?= $h($defaultDb) ?>">
        <?php } ?>
        <label class="drop" id="drop">
            <input type="file" id="file" accept=".csv,.xlsx,.xls,.txt" hidden>
            <strong>Drop the file here, or click to choose</strong>
            <span id="drop-sub">.csv · .xlsx · .xls</span>
        </label>
        <p class="hint" style="margin:12px 0 0;">Saved the missing leads of an earlier file? <a href="#" id="ml-import" style="color:var(--accent);font-weight:600;">Import a saved missing-leads file</a> <span class="faint">(the CSV from “Add missing leads” → Download CSV)</span>
            <input type="file" id="ml-file" accept=".csv,.xlsx,.xls,.txt" hidden></p>
    </section>

    <!-- STEP 2 -->
    <section class="card hidden" id="s2">
        <h2>How should leads be matched?</h2>
        <p class="hint" id="s2-file"></p>
        <p class="hint" style="margin-top:-4px;">Pick the field your file and the lead table both have. No mobile in the file? Use <b>Email</b> — or any other lead column under “Another column”.</p>
        <div class="choice" id="id-choices"></div>
        <div class="actions">
            <button class="btn" data-back="1">← Back</button>
            <button class="btn primary" id="to3" disabled>Next: map columns →</button>
        </div>
    </section>

    <!-- STEP 3 -->
    <section class="card hidden" id="s3">
        <h2>Pick the columns to import</h2>
        <p class="hint">Choose which column in your file goes into each database column. Set lead status<?= $showMql ? ', MQL' : '' ?>, site visit or platform to "Don't update" to skip it. Then check how each value in the file is read.</p>
        <div class="grid3">
            <div class="map-box"><h3 id="m-id-title">Mobile</h3><p>→ <span class="db-col" id="m-id-db">lead.mobile</span> (to find the lead)</p><select id="c-id"></select><p class="idtest" id="id-test"></p></div>
            <div class="map-box"><h3>Lead status</h3><p>→ <span class="db-col">lead.lead_status</span> · QUALIFIED / NON-QUALIFIED / TO BE QUALIFIED</p><select id="c-status"></select></div>
            <?php if ($showMql): ?><div class="map-box"><h3>MQL <span class="faint" style="font-weight:400;">(optional)</span></h3><p>MQL = 1 → <span class="db-col">QUALIFIED</span>, even if the lead status column says otherwise. MQL = 0 → the lead status column decides (no status column → NON-QUALIFIED).</p><select id="c-mql"></select></div><?php endif; ?>
            <div class="map-box"><h3>Site visit</h3><p>→ <span class="db-col">lead.sitevisit_status</span> · Yes / No</p><select id="c-sitevisit"></select></div>
            <div class="map-box"><h3>Platform</h3><p>→ <span class="db-col">lead.campaignsource</span> · Google / Meta</p><select id="c-platform"></select></div>
            <div class="map-box" id="m-camp"><h3>Campaign <span class="faint" style="font-weight:400;">(to tell the databases apart)</span></h3><p>When a lead is in more than one database, its campaign in the file is compared with the lead's campaign in each database (and names like “Pseudo” / “Official”).</p><select id="c-campaign"></select>
                <p style="margin-top:8px;">If the campaign doesn't settle it:</p><select id="c-multi"><option value="all">Update the lead in every database it is in</option><option value="skip">Skip it (list it in the review)</option></select></div>
        </div>
        <div class="vals" id="vals"></div>
        <div class="actions">
            <button class="btn" data-back="2">← Back</button>
            <button class="btn primary" id="to4">Next: review →</button>
        </div>
    </section>

    <!-- STEP 4 -->
    <section class="card hidden" id="s4">
        <h2>Review — nothing has been saved yet</h2>
        <p class="hint" id="s4-sub"></p>
        <div id="pv-notes"></div>
        <div id="pv-capi"></div>
        <div class="tiles" id="tiles"></div>
        <div class="tabs" id="tabs"></div>
        <div class="tbl-wrap"><table><thead id="pv-head"></thead><tbody id="pv-body"></tbody></table></div>
        <p class="faint" id="pv-more"></p>
        <div class="actions">
            <div style="display:flex;gap:10px;flex-wrap:wrap;">
                <button class="btn" data-back="3">← Back</button>
                <button class="btn" id="dl-nf">Download rows not found</button>
                <button class="btn" id="add-missing" title="Check, edit and add the rows that are not in the database as new leads — or download them to add later">＋ Add missing leads…</button>
            </div>
            <button class="btn primary" id="go">Update leads</button>
        </div>
    </section>

    <!-- DONE -->
    <section class="card hidden" id="s5">
        <h2 id="done-title">Done</h2>
        <p class="hint" id="done-sub"></p>
        <div id="done-capi"></div>
        <div id="done-missing"></div>
        <div class="actions" style="justify-content:flex-start;">
            <button class="btn primary" id="again">Upload another file</button>
        </div>
    </section>

    <!-- HISTORY -->
    <section class="card" id="hist">
        <h2>Recent uploads</h2>
        <p class="hint">Undo puts back the old status / site visit / platform on leads that still have the uploaded value (anything changed since is kept).</p>
        <div class="tbl-wrap" style="max-height:320px;"><table>
            <thead><tr><th>When</th><th>Database</th><th>By</th><th>File</th><th>Matched by</th><th class="n">Rows</th><th class="n">Leads updated</th><th></th></tr></thead>
            <tbody id="hist-body"><tr><td colspan="8" class="muted">Loading…</td></tr></tbody>
        </table></div>
        <h2 style="margin-top:22px;">Missing leads added</h2>
        <p class="hint">New leads added from feedback files (“Add missing leads”). Undo deletes them again.</p>
        <div class="tbl-wrap" style="max-height:260px;"><table>
            <thead><tr><th>When</th><th>Database</th><th>By</th><th>File</th><th class="n">Leads added</th><th></th></tr></thead>
            <tbody id="ml-hist"><tr><td colspan="6" class="muted">Loading…</td></tr></tbody>
        </table></div>
    </section>
</div>

<script src="assets/js/missing_leads.js?v=<?= (int) @filemtime(__DIR__ . '/assets/js/missing_leads.js') ?>"></script>
<script>
(function () {
    'use strict';
    const API = 'status_upload_api.php';
    const CAN_ML = <?= $canAddMissing ? 'true' : 'false' ?>;
    const $ = s => document.querySelector(s);
    const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
    const fmt = n => Number(n || 0).toLocaleString('en-IN');
    const S = { token: null, file: null, headers: [], sample: [], rows: 0, guess: {}, stats: {}, idType: null, idCols: [],
                values: {}, fieldDefs: {}, preview: null, tab: 'change' };
    const db = () => $('#db').value;

    function msg(text, kind) {
        $('#msg').innerHTML = text ? `<div class="note ${kind || 'bad'}">${text}</div>` : '';
        if (text) $('#msg').scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }
    function step(n) {
        [1, 2, 3, 4, 5].forEach(i => $('#s' + i).classList.toggle('hidden', i !== n));
        document.querySelectorAll('.step').forEach(el => {
            const s = +el.dataset.s;
            el.classList.toggle('on', s === Math.min(n, 4) && n < 5);
            el.classList.toggle('done', s < n);
        });
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }
    async function api(action, body, isForm) {
        const opt = { method: body ? 'POST' : 'GET', credentials: 'same-origin' };
        if (body) {
            if (isForm) opt.body = body;
            else { opt.headers = { 'Content-Type': 'application/json' }; opt.body = JSON.stringify(Object.assign({ db: db() }, body)); }
        }
        const res = await fetch(`${API}?action=${action}${body ? '' : '&db=' + encodeURIComponent(db())}`, opt);
        const data = await res.json().catch(() => ({ success: false, error: `Server error (HTTP ${res.status}).` }));
        if (!data.success) { const e = new Error(data.error || 'Request failed'); e.data = data; throw e; }
        return data;
    }
    function busy(btn, text) {
        const old = btn.innerHTML;
        btn.disabled = true;
        btn.innerHTML = `<span class="spinner"></span>${text}`;
        return () => { btn.disabled = false; btn.innerHTML = old; };
    }

    /* ── step 1: upload ── */
    let sheetJs = null;
    function loadSheetJs() {
        if (window.XLSX) return Promise.resolve(window.XLSX);
        if (sheetJs) return sheetJs;
        sheetJs = new Promise((ok, fail) => {
            const s = document.createElement('script');
            s.src = 'https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js';
            s.onload = () => ok(window.XLSX);
            s.onerror = () => { sheetJs = null; fail(new Error('Could not load the Excel reader. Save the file as .xlsx or .csv and try again.')); };
            document.head.appendChild(s);
        });
        return sheetJs;
    }
    async function toCsvInBrowser(file) {
        const X = await loadSheetJs();
        const wb = X.read(await file.arrayBuffer(), { type: 'array' });
        const ws = wb.Sheets[wb.SheetNames[0]];
        const csv = X.utils.sheet_to_csv(ws, { FS: ',', blankrows: false, rawNumbers: true });
        return new File([csv], file.name.replace(/\.\w+$/, '') + '.csv', { type: 'text/csv' });
    }
    async function upload(file, converted, originalName) {
        msg('');
        const sub = $('#drop-sub');
        sub.innerHTML = `<span class="spinner"></span>Reading ${esc(file.name)}…`;
        try {
            let send = file;
            if (!converted && /\.xls$/i.test(file.name)) send = await toCsvInBrowser(file);
            const fd = new FormData();
            fd.append('file', send);
            fd.append('original_name', originalName || file.name);
            fd.append('db', db());
            const d = await api('parse', fd, true);
            Object.assign(S, { token: d.token, file: d.file_name, headers: d.headers, sample: d.sample, rows: d.rows, guess: d.guess, stats: d.db_stats, idCols: d.id_columns || [] });
            $('#s2-file').innerHTML = `<b>${esc(d.file_name)}</b>${d.sheet ? ` · sheet “${esc(d.sheet)}”` : ''} · ${fmt(d.rows)} data rows · ${d.headers.length} columns · updating <b>${esc(d.db_label)}</b>`;
            buildIdChoices();
            // preselect the likely ID: a uniqueid column in the file, else mobile, else email
            const has = c => d.guess[c] != null && (d.db_stats[c] || 0) > 0;
            setIdType(has('uniqueid') ? 'uniqueid' : has('mobile') ? 'mobile' : has('email') ? 'email' : null);
            step(2);
        } catch (e) {
            if (e.data && e.data.need_client_convert && !converted) {
                try { return await upload(await toCsvInBrowser(file), true, file.name); } catch (e2) { msg(esc(e2.message)); }
            } else msg(esc(e.message));
        } finally {
            sub.textContent = '.csv · .xlsx · .xls';
            $('#file').value = '';
        }
    }
    const drop = $('#drop');
    $('#file').addEventListener('change', e => e.target.files[0] && upload(e.target.files[0]));
    ['dragenter', 'dragover'].forEach(ev => drop.addEventListener(ev, e => { e.preventDefault(); drop.classList.add('over'); }));
    ['dragleave', 'drop'].forEach(ev => drop.addEventListener(ev, e => { e.preventDefault(); drop.classList.remove('over'); }));
    drop.addEventListener('drop', e => e.dataTransfer.files[0] && upload(e.dataTransfer.files[0]));

    /* ── step 2: unique id (any lead column) ── */
    const ID_INFO = {
        mobile: ['Mobile number', "Matched on the last 10 digits, so +91 / 0 / spaces don't matter."],
        email: ['Email', 'Matched exactly, ignoring capitals and spaces.'],
        uniqueid: ['Unique ID', 'Matched exactly (case-insensitive).'],
        leadgen_id: ['Meta lead ID', 'The Meta lead form ID (leadgen_id).'],
        gclid: ['Google click ID', 'The gclid saved with Google leads.'],
        id: ['Lead number', 'The lead\'s own id in this admin (#123).'],
    };
    const KIND_INFO = { mobile: 'Compared on the last 10 digits.', email: 'Compared ignoring capitals and spaces.', text: 'Compared exactly (case-insensitive).' };
    function idLabel(t) { return t ? ((ID_INFO[t] || [])[0] || t) : ''; }
    function buildIdChoices() {
        const cols = S.idCols, main = cols.filter(c => ID_INFO[c.column] && c.column !== 'id' && (c.filled > 0 || ['mobile', 'email', 'uniqueid'].includes(c.column)));
        const others = cols.filter(c => !main.includes(c));
        const inFile = c => S.guess[c] != null ? ` · file column <b>${esc(S.headers[S.guess[c]])}</b>` : '';
        $('#id-choices').innerHTML = main.map(c => `<label class="opt ${c.filled ? '' : 'off'}" data-id="${esc(c.column)}"><input type="radio" name="idtype">
                <div><strong>${esc(ID_INFO[c.column][0])}</strong><span>The lead's <span class="db-col">${esc(c.column)}</span>. ${esc(ID_INFO[c.column][1])}<br><b class="mono">${fmt(c.filled)}</b> leads have one${inFile(c.column)}.</span></div></label>`).join('')
            + (others.length ? `<label class="opt" data-id="__other"><input type="radio" name="idtype">
                <div style="flex:1;min-width:0;"><strong>Another column</strong><span>Any other column of the lead table.</span>
                <select id="id-other"><option value="">— choose a lead column —</option>${others.map(c => `<option value="${esc(c.column)}" ${c.filled ? '' : 'disabled'}>${esc(c.column)} — ${fmt(c.filled)} leads have a value</option>`).join('')}</select>
                <span id="id-other-note"></span></div></label>` : '');
        document.querySelectorAll('#id-choices .opt').forEach(o => o.addEventListener('click', e => {
            if (o.dataset.id === '__other') { if (e.target.tagName !== 'SELECT' && e.target.tagName !== 'OPTION') $('#id-other').focus(); setIdType($('#id-other').value || null, true); }
            else setIdType(o.dataset.id);
        }));
        const oth = $('#id-other');
        if (oth) oth.addEventListener('change', () => setIdType(oth.value || null, true));
    }
    function setIdType(t, other) {
        S.idType = t;
        const isMain = t && document.querySelector(`#id-choices .opt[data-id="${CSS.escape(t)}"]`);
        document.querySelectorAll('#id-choices .opt').forEach(o => {
            const on = o.dataset.id === '__other' ? (other || (!!t && !isMain)) : o.dataset.id === t;
            o.classList.toggle('sel', on); o.querySelector('input').checked = on;
        });
        const n = $('#id-other-note');
        if (n) n.innerHTML = (t && !isMain) ? `<br>${KIND_INFO[kindOf(t)]}` : '';
        $('#to3').disabled = !t;
    }
    function kindOf(t) { const c = S.idCols.find(x => x.column === t); return c ? c.kind : 'text'; }
    $('#to3').addEventListener('click', () => { buildColumnPickers(); step(3); loadValues(); });

    /* ── step 3: columns + values ── */
    const HAS_MQL = <?= $showMql ? 'true' : 'false' ?>;   // MQL column (config STATUS_UPLOAD_MQL)
    const FIELDS = ['status', 'sitevisit', 'platform'];
    const FIELD_LABEL = { status: 'Lead status', sitevisit: 'Site visit', platform: 'Platform' };
    const NONE_LABEL = { status: "— Don't update status —", sitevisit: "— Don't update site visit —", platform: "— Don't update platform —" };
    function options(sel, allowNone, noneLabel) {
        const sample = i => S.sample.map(r => r[i]).filter(v => v !== '' && v != null).slice(0, 2).join(', ');
        return (allowNone ? `<option value="">${noneLabel}</option>` : '<option value="">— choose a column —</option>')
            + S.headers.map((h, i) => `<option value="${i}" ${sel === i ? 'selected' : ''}>${esc(h)}${sample(i) ? ' — e.g. ' + esc(sample(i).slice(0, 40)) : ''}</option>`).join('');
    }
    function buildColumnPickers() {
        $('#m-id-title').textContent = 'Match on: ' + idLabel(S.idType);
        $('#m-id-db').textContent = 'lead.' + S.idType;
        $('#c-id').innerHTML = options(S.guess[S.idType], false);
        idTest();
        FIELDS.forEach(f => { $('#c-' + f).innerHTML = options(S.guess[f], true, NONE_LABEL[f]); });
        if (HAS_MQL) $('#c-mql').innerHTML = options(S.guess.mql, true, '— No MQL column —');
        mqlNote();
        // campaign column (only used with "All databases")
        const hs = S.headers || [];
        const prefer = ['campaign name', 'campaign', 'utm campaign', 'campaign_name', 'sub source', 'source'];
        let gi = null;
        for (const p of prefer) { const i = hs.findIndex(h => String(h).toLowerCase().trim() === p); if (i >= 0) { gi = i; break; } }
        if (gi === null) { const i = hs.findIndex(h => /campaign/i.test(String(h))); gi = i >= 0 ? i : null; }
        $('#c-campaign').innerHTML = options(gi, true, '— No campaign column —');
        $('#m-camp').classList.toggle('hidden', db() !== 'all');
    }
    function mqlNote() {
        const on = HAS_MQL && $('#c-mql').value !== '';
        const box = $('#mql-note');
        if (box) box.innerHTML = on ? `<b>MQL is on:</b> every row with MQL = 1 becomes <b>QUALIFIED</b> (counts for CPQL), whatever its lead status value below.` : '';
    }
    if (HAS_MQL) $('#c-mql').addEventListener('change', () => { mqlNote(); });
    // live check: how many rows of the file find a lead with this ID column
    let idSeq = 0;
    async function idTest() {
        const box = $('#id-test'), col = $('#c-id').value, seq = ++idSeq;
        if (col === '') { box.innerHTML = ''; return; }
        box.innerHTML = '<span class="spinner"></span>Checking the file against the leads…';
        try {
            const r = await api('idtest', { token: S.token, id_type: S.idType, id_col: col });
            if (seq !== idSeq) return;
            const pct = r.rows ? Math.round(r.matched * 100 / r.rows) : 0;
            const bits = [`<b class="${r.matched ? 'good' : 'bad'}">${fmt(r.matched)} of ${fmt(r.rows)} rows (${pct}%)</b> find a lead`];
            if (r.not_found) bits.push(`${fmt(r.not_found)} not found`);
            if (r.blank) bits.push(`${fmt(r.blank)} without a usable ${esc(r.label)}`);
            if (r.multi) bits.push(`${fmt(r.multi)} match more than one lead (all are updated)`);
            if (r.looks_cut) bits.push(`<b>${fmt(r.looks_cut)} email(s) look cut off</b> (e.g. “…@gmail.c”) — fix them in the file to match`);
            if (r.per_db) bits.push(Object.entries(r.per_db).map(([k, n]) => `${esc(r.per_db_labels[k])}: ${fmt(n)}`).join(', ') + (r.in_several_dbs ? ` · <b>${fmt(r.in_several_dbs)} in more than one database</b> (the campaign column decides)` : ''));
            box.innerHTML = bits.join(' · ') + (r.matched === 0 ? '<br><b class="bad">Nothing matches — check the column, or go back and match on a different field.</b>' : '');
        } catch (e) { if (seq === idSeq) box.innerHTML = `<b class="bad">${esc(e.message)}</b>`; }
    }
    $('#c-id').addEventListener('change', idTest);
    FIELDS.forEach(f => $('#c-' + f).addEventListener('change', loadValues));

    // what a choice is written as, and whether it counts for CPQL / CPSV
    const writes = (f, choice) => (S.fieldDefs[f] && S.fieldDefs[f].options[choice]) || '';
    function badge(f, choice) {
        if (!choice) return `<span class="pill dim">not changed</span>`;
        const w = writes(f, choice);
        const counts = S.fieldDefs[f].counts.includes(w);
        const saved = w !== choice ? `<span class="faint">saved as “${esc(w)}”</span> ` : '';
        return saved + (counts ? `<span class="pill good">${f === 'status' ? 'counts for CPQL' : 'counts for CPSV'}</span>` : '');
    }
    async function loadValues() {
        const body = { token: S.token };
        FIELDS.forEach(f => { body[f + '_col'] = $('#c-' + f).value; });
        const any = FIELDS.some(f => body[f + '_col'] !== '');   // MQL needs no value mapping
        $('#vals').innerHTML = any ? '<p class="muted"><span class="spinner"></span>Reading values…</p>' : '';
        if (!any) { S.values = {}; return; }
        try {
            const d = await api('values', body);
            S.fieldDefs = d.fields;
            S.values = d.values;
            renderValues();
        } catch (e) { $('#vals').innerHTML = ''; msg(esc(e.message)); }
    }
    function renderValues() {
        const block = f => {
            const list = S.values[f];
            const opts = Object.keys(S.fieldDefs[f].options);
            const unset = list.filter(v => v.value !== '' && !v.choice).reduce((n, v) => n + v.rows, 0);
            return `<div class="map-box"><h3>${FIELD_LABEL[f]}: how each value is read</h3>
            <p>Pick ${opts.join(' / ')} for each value, or “leave as it is”.${unset ? ` <b style="color:var(--warn)">${fmt(unset)} row(s) still need a choice.</b>` : ''}</p>
            <div class="tbl-wrap" style="max-height:300px;"><table>
              <thead><tr><th>Value in file</th><th class="n">Rows</th><th style="width:42%;">Becomes</th><th></th></tr></thead>
              <tbody>${list.map((v, i) => `<tr class="${v.value !== '' && !v.choice ? 'warnrow' : ''}">
                <td>${v.value === '' ? '<span class="faint">(empty)</span>' : esc(v.value)}</td>
                <td class="n mono">${fmt(v.rows)}</td>
                <td><select data-f="${f}" data-i="${i}">
                    <option value="">(leave as it is)</option>
                    ${opts.map(o => `<option value="${esc(o)}" ${v.choice === o ? 'selected' : ''}>${esc(o)}</option>`).join('')}
                </select></td>
                <td class="badge-cell">${badge(f, v.choice)}</td></tr>`).join('')}</tbody>
            </table></div></div>`;
        };
        $('#vals').innerHTML = (HAS_MQL ? '<p class="hint" id="mql-note" style="grid-column:1/-1;margin:0;"></p>' : '') + FIELDS.filter(f => S.values[f]).map(block).join('');
        mqlNote();
        $('#vals').querySelectorAll('select[data-f]').forEach(sel => sel.addEventListener('change', () => {
            S.values[sel.dataset.f][+sel.dataset.i].choice = sel.value;
            renderValues();
        }));
    }
    function mapping() {
        const m = { token: S.token, id_type: S.idType, id_col: $('#c-id').value, mql_col: HAS_MQL ? $('#c-mql').value : '',
                    campaign_col: db() === 'all' ? $('#c-campaign').value : '', multi_db: $('#c-multi').value };
        FIELDS.forEach(f => {
            m[f + '_col'] = $('#c-' + f).value;
            m[f + '_map'] = {};
            if (m[f + '_col'] !== '' && S.values[f]) S.values[f].forEach(v => { m[f + '_map'][v.value] = v.choice; });
        });
        return m;
    }
    $('#to4').addEventListener('click', async () => {
        msg('');
        const m = mapping();
        if (m.id_col === '') return msg(`Choose the column with the ${esc(idLabel(S.idType).toLowerCase())}.`);
        if (!FIELDS.some(f => m[f + '_col'] !== '') && m.mql_col === '') return msg('Choose at least one column to import: lead status, ' + (HAS_MQL ? 'MQL, ' : '') + 'site visit or platform.');
        if (FIELDS.some(f => m[f + '_col'] === m.id_col) || m.mql_col === m.id_col) return msg('The ID column cannot also be a status / site visit / platform column.');
        const done = busy($('#to4'), 'Checking every row…');
        try { S.preview = await api('preview', m); S.tab = S.preview.summary.leads_to_update ? 'change' : 'all'; renderPreview(); step(4); }
        catch (e) { msg(esc(e.message)); }
        finally { done(); }
    });

    /* ── step 4: review ── */
    const STATE = { change: ['Will update', 'good'], same: ['Already up to date', 'dim'], notfound: ['Not found', 'bad'], blank: ['No ID', 'warn'], dup: ['Repeated in file', 'warn'], skipped: ['Skipped — database unclear', 'warn'] };
    function cellChange(oldV, newV) {
        if (newV == null) return oldV ? esc(oldV) : '<span class="faint">(empty)</span>';
        return `<span class="old">${oldV ? esc(oldV) : '(empty)'}</span><span class="arrow">→</span><span class="new">${esc(newV)}</span>`;
    }
    function fileCell(it, f) {
        const v = it.file[f], c = it.choice[f];
        if (v === '' || v == null) return '<span class="faint">(empty)</span>';
        return `${esc(v)}${c ? (c !== v ? ` <span class="faint">→ ${esc(c)}</span>` : '') : ' <span class="pill warn">no choice</span>'}`;
    }
    function renderPreview() {
        const p = S.preview, s = p.summary, used = p.fields;
        $('#s4-sub').innerHTML = `${esc(S.file)} · matched by <b>${esc(idLabel(S.idType))}</b> · database <b>${esc(p.db_label)}</b> · updating <b>${used.map(f => FIELD_LABEL[f]).join(', ')}</b>`;
        const tile = (label, val, cls) => `<div class="tile ${cls || ''}"><div>${label}</div><strong class="mono">${fmt(val)}</strong></div>`;
        $('#tiles').innerHTML = tile('Rows in file', s.rows) + tile('Rows matched', s.matched_rows) + tile('Leads to update', s.leads_to_update, 'accent')
            + tile('Not found', s.not_found, s.not_found ? 'bad' : '') + tile('Already up to date', s.unchanged)
            + (used.includes('status') ? tile('Status changes', s.status_changes) + tile('Newly Qualified', s.new_qualified, 'good') : '')
            + (s.mql_used ? tile('Rows with MQL = 1', s.mql_rows, 'good') : '')
            + (used.includes('sitevisit') ? tile('Site visit changes', s.sitevisit_changes) + tile('New site visits', s.new_sitevisits, 'good') : '')
            + (used.includes('platform') ? tile('Platform changes', s.platform_changes) : '')
            + (s.all_dbs ? Object.values(s.all_dbs.per_db).map(d => tile(`To update in ${esc(d.label)}`, d.leads_to_update)).join('') + tile('Found in more than one database', s.all_dbs.in_several_dbs, s.all_dbs.in_several_dbs ? 'accent' : '') : '');
        const notes = [];
        if (s.all_dbs && s.all_dbs.in_several_dbs) {
            const a = s.all_dbs;
            notes.push(`<b>${fmt(a.in_several_dbs)} row(s) match a lead in more than one database:</b> ${fmt(a.split_by_campaign)} matched to one database by their campaign${a.updated_in_all ? `, ${fmt(a.updated_in_all)} updated in every database they are in (campaign column missing or not clear)` : ''}${a.skipped_undecided ? `, ${fmt(a.skipped_undecided)} skipped` : ''}. See the “Lead in database” column.`);
        }
        if (s.lost_post_qualified) notes.push(`<b>${fmt(s.lost_post_qualified)} lead(s) are Qualified now and the file says Not qualified — they will be set to “LOST POST QUALIFIED”</b> (they still count as qualified for CPQL).`);
        if (s.lost_qualified) notes.push(`<b>${fmt(s.lost_qualified)} lead(s) are Qualified now and will stop being Qualified.</b>`);
        if (s.lost_sitevisits) notes.push(`<b>${fmt(s.lost_sitevisits)} lead(s) have a site visit now that will be set to “No”.</b>`);
        if (s.unmapped_values) notes.push(`${fmt(s.unmapped_values)} value(s) have no choice in step 3 and are left as they are.`);
        if (s.blank_id) notes.push(`${fmt(s.blank_id)} row(s) have no usable ${esc(idLabel(S.idType).toLowerCase())} and are skipped.`);
        if (s.duplicates_in_file) notes.push(`${fmt(s.duplicates_in_file)} ${esc(idLabel(S.idType).toLowerCase())} value(s) appear more than once in the file — the row with the site visit (else the qualified one, else the lower row) is used.`);
        if (s.sv_qualified_rows) notes.push(`${fmt(s.sv_qualified_rows)} row(s) with a site visit are marked <b>QUALIFIED</b> (a site visit is always a qualified lead).`);
        if (s.looks_cut) notes.push(`${fmt(s.looks_cut)} email(s) in the file look cut off (no full domain, e.g. “…@gmail.c”), so they can't match. Fix them in the file and upload again.`);
        if (s.multi_lead_rows) notes.push(`${fmt(s.multi_lead_rows)} row(s) match more than one lead (duplicate leads in the database) — all of them are updated.`);
        if (used.includes('platform')) notes.push('Platform is only changed when a lead moves between Google and Meta. Meta is saved as “Facebook Lead Form”, the source the Meta dashboard reads.');
        if (s.platform_kept) notes.push(`<b>${fmt(s.platform_kept)} platform change(s) skipped</b>: those leads have their own Meta lead form id or Google click tracking, which is more reliable than the CRM's source column.`);
        if (s.matched_rows === 0) notes.push(`<b>No row matched a lead.</b> Check the database, the field you match on (step 2) and the ID column.`);
        $('#pv-notes').innerHTML = notes.length ? `<div class="note warn">${notes.join('<br>')}</div>` : '';
        renderCapi();

        const counts = { all: p.items_total };
        p.items.forEach(it => { counts[it.state] = (counts[it.state] || 0) + 1; });
        const tabs = [['change', 'Will update'], ['notfound', 'Not found'], ['same', 'Up to date'], ['dup', 'Repeated'], ['blank', 'No ID'], ['all', 'All rows']];
        $('#tabs').innerHTML = tabs.filter(([k]) => k === 'all' || counts[k]).map(([k, l]) => `<button class="tab ${S.tab === k ? 'on' : ''}" data-t="${k}">${l} · ${fmt(counts[k] || 0)}</button>`).join('');
        $('#tabs').querySelectorAll('.tab').forEach(b => b.addEventListener('click', () => { S.tab = b.dataset.t; renderPreview(); }));

        // the four columns to review: unique ID, status, site visit, platform (file value, then database old → new)
        $('#pv-head').innerHTML = `<tr><th class="n">Row</th><th>${esc(idLabel(S.idType))}</th><th>Lead in database</th>`
            + used.map(f => `<th>${FIELD_LABEL[f]}<div class="faint" style="text-transform:none;letter-spacing:0;font-weight:400;">file · database</div></th>`).join('') + '<th>Result</th></tr>';
        const list = p.items.filter(it => S.tab === 'all' || it.state === S.tab);
        const shown = list.slice(0, 500);
        $('#pv-body').innerHTML = shown.map(it => {
            const st = STATE[it.state];
            const leads = it.leads.length ? it.leads : [null];
            return leads.map((l, j) => `<tr>
                ${j === 0 ? `<td class="n mono" rowspan="${leads.length}">${it.row}</td><td class="mono" rowspan="${leads.length}">${esc(it.id) || '<span class="faint">(empty)</span>'}</td>` : ''}
                <td>${l ? `${esc(l.name) || '<span class="faint">(no name)</span>'} <span class="faint">#${l.id}${l.date ? ' · ' + l.date : ''}</span>${l.db ? ` <span class="pill ${l.skipped ? 'dim' : 'good'}" style="margin-left:4px;">${esc(l.db)}</span>` : ''}` : '<span class="faint">—</span>'}</td>
                ${used.map(f => `<td><div>${fileCell(it, f)}</div>${l ? `<div style="margin-top:3px;">${cellChange(l['old_' + f], l['new_' + f])}</div>` : ''}</td>`).join('')}
                ${j === 0 ? `<td rowspan="${leads.length}"><span class="pill ${st[1]}">${st[0]}</span>${it.note ? `<div class="faint" style="margin-top:3px;">${esc(it.note)}</div>` : ''}</td>` : ''}
            </tr>`).join('');
        }).join('') || `<tr><td colspan="${4 + used.length}" class="muted">Nothing in this list.</td></tr>`;
        $('#pv-more').textContent = list.length > shown.length ? `Showing the first ${fmt(shown.length)} of ${fmt(list.length)} rows.` : (p.items_total > p.items.length ? `The review lists the first ${fmt(p.items.length)} rows.` : '');
        $('#go').disabled = !s.leads_to_update;
        $('#go').textContent = s.leads_to_update ? `Update ${fmt(s.leads_to_update)} lead${s.leads_to_update === 1 ? '' : 's'}…` : 'Nothing to update';
        $('#dl-nf').classList.toggle('hidden', !s.not_found);
        $('#add-missing').classList.toggle('hidden', !s.not_found);
        $('#add-missing').textContent = `＋ Add ${fmt(s.not_found)} missing lead${s.not_found === 1 ? '' : 's'}…`;
    }
    /* ── Meta Conversions API: send new Qualified / Site visit of Meta leads with the upload ── */
    function capiLabel(by, names) {
        const n = names || {};
        return [by.qualified ? `${fmt(by.qualified)} “${esc(n.qualified || 'Qualified')}”` : '', by.sitevisit ? `${fmt(by.sitevisit)} “${esc(n.sitevisit || 'Site Visit')}”` : ''].filter(Boolean).join(' and ');
    }
    function renderCapi() {
        const c = S.preview.capi || {};
        const sk = c.skipped || {};
        const skipped = [sk.already_sent ? `${fmt(sk.already_sent)} already sent before` : '', sk.test ? `${fmt(sk.test)} test lead(s)` : ''].filter(Boolean).join(', ');
        if (!c.events) { $('#pv-capi').innerHTML = skipped && c.problem === '' ? `<div class="note" style="border-color:var(--border);">Meta Conversions API: nothing new to send (${skipped}).</div>` : ''; return; }
        if (c.problem) {
            $('#pv-capi').innerHTML = `<div class="note" style="border-color:var(--border);"><b>Meta Conversions API is not set up</b> — ${capiLabel(c.by_stage, c.names)} event(s) from Meta leads could go to Meta with this upload. ${esc(c.problem)}.</div>`;
            return;
        }
        $('#pv-capi').innerHTML = `<label class="note good" style="display:flex;gap:10px;align-items:flex-start;cursor:pointer;">
            <input type="checkbox" id="capi-send" ${S.capiOff ? '' : 'checked'} style="margin-top:2px;">
            <span><b>Also send to Meta (Conversions API): ${capiLabel(c.by_stage, c.names)}</b>${c.test_mode ? ' <span class="pill warn">test mode</span>' : ''}
            <span class="faint" style="display:block;margin-top:2px;">Meta lead-form leads that become Qualified or get a site visit in this upload, so Meta can find more people like them.
            Each lead and event is sent once${skipped ? ` · skipped: ${skipped}` : ''}. Undo does not take events back from Meta.</span></span></label>`;
        $('#capi-send').addEventListener('change', e => { S.capiOff = !e.target.checked; });
    }

    $('#dl-nf').addEventListener('click', () => {
        const used = S.preview.fields;
        const rows = S.preview.items.filter(i => i.state === 'notfound');
        const q = v => `"${String(v ?? '').replace(/"/g, '""')}"`;
        const csv = [['Row', idLabel(S.idType)].concat(used.map(f => FIELD_LABEL[f] + ' in file')).map(q).join(',')]
            .concat(rows.map(r => [r.row, r.id].concat(used.map(f => r.file[f])).map(q).join(','))).join('\r\n');
        const a = document.createElement('a');
        a.href = URL.createObjectURL(new Blob(['﻿' + csv], { type: 'text/csv' }));
        a.download = 'not_found_' + String(S.file || 'upload').replace(/\.\w+$/, '') + '.csv';
        a.click();
    });

    /* ── missing leads: rows of the file that are not in the database (assets/js/missing_leads.js) ── */
    function openMissing(d) {
        if (!window.PQMissing) { msg('The missing-leads editor could not load. Reload the page.'); return; }
        PQMissing.open(Object.assign({ can_insert: CAN_ML }, d, { can_insert: CAN_ML && d.can_insert !== false }), {
            api: (action, body) => api(action, body),
            onDone: () => loadMlHistory(),
        });
    }
    $('#add-missing').addEventListener('click', async () => {
        const done = busy($('#add-missing'), 'Reading the rows…');
        try { openMissing(await api('missing', mapping())); }
        catch (e) { msg(esc(e.message)); }
        finally { done(); }
    });
    $('#ml-import').addEventListener('click', e => { e.preventDefault(); $('#ml-file').click(); });
    $('#ml-file').addEventListener('change', async e => {
        const f = e.target.files[0]; if (!f) return;
        msg('');
        const send = async (file, orig) => {
            const fd = new FormData(); fd.append('file', file); fd.append('original_name', orig || file.name); fd.append('db', db());
            return api('missing_parse', fd, true);
        };
        try {
            let d;
            try { d = await send(/\.xls$/i.test(f.name) ? await toCsvInBrowser(f) : f, f.name); }
            catch (err) { if (err.data && err.data.need_client_convert) d = await send(await toCsvInBrowser(f), f.name); else throw err; }
            openMissing(d);
        } catch (err) { msg(esc(err.message)); }
        finally { e.target.value = ''; }
    });
    async function loadMlHistory() {
        try {
            const d = await api('missing_history');
            $('#ml-hist').innerHTML = d.imports.length ? d.imports.map(u => `<tr>
                <td class="mono">${esc(u.at)}</td><td>${esc(u.db_label)}</td><td>${esc(u.by)}</td><td>${esc(u.file)}</td><td class="n mono">${fmt(u.rows)}</td>
                <td>${u.undone ? `<span class="pill dim">Undone ${esc(u.undone)}</span>` : (CAN_ML ? `<button class="btn" style="padding:4px 10px;font-size:12px;" data-mlundo="${u.id}" data-db="${esc(u.db)}">Undo</button>` : '')}</td></tr>`).join('')
                : '<tr><td colspan="6" class="muted">None yet.</td></tr>';
            $('#ml-hist').querySelectorAll('[data-mlundo]').forEach(b => b.addEventListener('click', async () => {
                if (!await confirmDialog(`<h3>Delete the leads added by import #${b.dataset.mlundo}?</h3><div class="muted" style="font-size:13px;">Only those new leads are deleted. Leads that were edited since are deleted too.</div>`, 'Delete them')) return;
                const done = busy(b, '');
                try { const r = await api('missing_undo', { target_db: b.dataset.db, import_id: +b.dataset.mlundo }); msg(`Undone: ${fmt(r.deleted)} lead(s) deleted.`, 'good'); loadMlHistory(); }
                catch (e) { msg(esc(e.message)); done(); }
            }));
        } catch (e) { $('#ml-hist').innerHTML = `<tr><td colspan="6" class="muted">${esc(e.message)}</td></tr>`; }
    }

    function confirmDialog(html, okText) {
        return new Promise(resolve => {
            const o = document.createElement('div');
            o.className = 'overlay';
            o.innerHTML = `<div class="dialog" role="dialog" aria-modal="true">${html}
                <div class="actions" style="justify-content:flex-end;"><button class="btn" data-x>Cancel</button><button class="btn primary" data-ok>${okText}</button></div></div>`;
            document.body.appendChild(o);
            const end = v => { o.remove(); resolve(v); };
            o.querySelector('[data-x]').onclick = () => end(false);
            o.querySelector('[data-ok]').onclick = () => end(true);
            o.addEventListener('click', e => { if (e.target === o) end(false); });
            o.querySelector('[data-ok]').focus();
        });
    }
    $('#go').addEventListener('click', async () => {
        const s = S.preview.summary, m = mapping();
        const used = S.preview.fields;
        const ok = await confirmDialog(`<h3>Update ${fmt(s.leads_to_update)} lead${s.leads_to_update === 1 ? '' : 's'} in ${esc(S.preview.db_label)}?</h3>
            <div class="muted" style="font-size:13px;">This writes to the lead table now.</div>
            <ul>${used.includes('status') ? `<li>Lead status changes: <b>${fmt(s.status_changes)}</b> (newly Qualified: ${fmt(s.new_qualified)}${s.lost_post_qualified ? `, to Lost post qualified: ${fmt(s.lost_post_qualified)}` : ''}${s.lost_qualified ? `, no longer Qualified: ${fmt(s.lost_qualified)}` : ''})</li>` : ''}
                ${used.includes('sitevisit') ? `<li>Site visit changes: <b>${fmt(s.sitevisit_changes)}</b> (new site visits: ${fmt(s.new_sitevisits)}${s.lost_sitevisits ? `, set back to No: ${fmt(s.lost_sitevisits)}` : ''})</li>` : ''}
                ${used.includes('platform') ? `<li>Platform changes: <b>${fmt(s.platform_changes)}</b></li>` : ''}
                ${capiOn() ? `<li>Send to Meta (Conversions API): <b>${capiLabel(S.preview.capi.by_stage, S.preview.capi.names)}</b></li>` : ''}
                <li>Not found / skipped rows are left alone.</li><li>You can undo this from “Recent uploads”.</li></ul>`, 'Yes, update');
        if (!ok) return;
        const done = busy($('#go'), 'Updating…');
        try {
            const d = await api('commit', Object.assign(m, { hash: S.preview.hash, send_capi: capiOn() }));
            $('#done-title').textContent = `✅ ${fmt(d.updated)} lead${d.updated === 1 ? '' : 's'} updated`;
            $('#done-sub').innerHTML = `${esc(S.file)} → ${esc(S.preview.db_label)}. ${d.summary.not_found ? fmt(d.summary.not_found) + ' row(s) were not found. ' : ''}`
                + `The dashboards pick up the new Qualified and Site Visit counts on their next refresh. Upload #${d.upload_id} can be undone below.`;
            showCapiResult(d.capi, d.upload_id);
            S.missing = d.missing || null;
            $('#done-missing').innerHTML = S.missing ? `<div class="note warn" style="display:flex;gap:12px;align-items:center;flex-wrap:wrap;">
                <span style="flex:1 1 300px;"><b>${fmt(S.missing.rows.length)} row${S.missing.rows.length === 1 ? ' is' : 's are'} not in the database.</b> Add them as new leads (you can check and edit every field first), or download them and add them later.</span>
                <button class="btn primary" id="done-ml">＋ Add missing leads…</button></div>` : '';
            if (S.missing) $('#done-ml').onclick = () => openMissing(S.missing);
            step(5);
            loadHistory();
        } catch (e) {
            if (e.data && e.data.stale) { msg(esc(e.message), 'warn'); $('#to4').click(); }
            else msg(esc(e.message));
        } finally { done(); }
    });
    function showCapiResult(c, uploadId) {
        const names = S.preview && S.preview.capi ? S.preview.capi.names : {};
        $('#done-capi').innerHTML = !c ? '' : c.error
            ? `<div class="note bad"><b>Leads updated, but Meta did not take ${fmt(c.failed)} event(s):</b> ${esc(c.error)}.
                <div style="margin-top:8px;"><button class="btn sm" id="capi-retry">Try sending to Meta again</button> <span class="faint">Fix the cause first if it is a setting (Admin → CRM Settings).</span></div></div>`
            : (c.sent ? `<div class="note good"><b>Sent to Meta:</b> ${capiLabel(c.by_stage, names)} event(s).</div>` : `<div class="note good">Nothing left to send to Meta.</div>`);
        const b = $('#capi-retry');
        if (b) b.onclick = async () => {
            const done = busy(b, 'Sending…');
            try {
                if (c.retry && c.retry.length) {           // "All databases": one upload per database
                    const tot = { sent: 0, failed: 0, error: '', by_stage: { qualified: 0, sitevisit: 0 }, retry: [] };
                    for (const x of c.retry.filter(x => x.failed)) {
                        const r = (await api('capi_retry', { upload_id: x.upload_id, db: x.db })).capi;
                        tot.sent += r.sent; tot.failed += r.failed; tot.error = tot.error || r.error;
                        Object.entries(r.by_stage || {}).forEach(([k, n]) => tot.by_stage[k] = (tot.by_stage[k] || 0) + n);
                        tot.retry.push({ db: x.db, upload_id: x.upload_id, failed: r.failed });
                    }
                    showCapiResult(tot, uploadId);
                } else { const r = await api('capi_retry', { upload_id: uploadId }); showCapiResult(r.capi, uploadId); }
            }
            catch (e) { msg(esc(e.message)); } finally { done(); }
        };
    }
    function capiOn() { const c = S.preview && S.preview.capi; return !!(c && c.problem === '' && c.events && !S.capiOff); }
    $('#again').addEventListener('click', () => { Object.assign(S, { token: null, preview: null, values: {}, capiOff: false, missing: null }); $('#done-capi').innerHTML = ''; $('#done-missing').innerHTML = ''; msg(''); step(1); });
    document.querySelectorAll('[data-back]').forEach(b => b.addEventListener('click', () => { msg(''); step(+b.dataset.back); }));

    /* ── history / undo ── */
    async function loadHistory() {
        try {
            const d = await api('history');
            $('#hist-body').innerHTML = d.uploads.length ? d.uploads.map(u => `<tr>
                <td class="mono">${esc(u.created_at)}</td><td>${esc(u.db_label || '')}</td><td>${esc(u.created_by)}</td><td>${esc(u.file_name)}</td>
                <td>${esc(idLabel(u.id_type))}${(u.fields || []).length ? `<div class="faint">${u.fields.map(f => FIELD_LABEL[f] || f).join(', ')}</div>` : ''}</td><td class="n mono">${fmt(u.rows_in_file)}</td><td class="n mono">${fmt(u.leads_updated)}</td>
                <td>${u.undone_at ? `<span class="pill dim">Undone ${esc(u.undone_at)}</span>` : `<button class="btn" style="padding:4px 10px;font-size:12px;" data-undo="${u.id}" data-db="${esc(u.db || '')}" data-label="${esc(u.db_label || '')}">Undo</button>`}</td>
            </tr>`).join('') : '<tr><td colspan="8" class="muted">No uploads yet.</td></tr>';
            $('#hist-body').querySelectorAll('[data-undo]').forEach(b => b.addEventListener('click', async () => {
                if (!await confirmDialog(`<h3>Undo upload #${b.dataset.undo}${b.dataset.label ? ' in ' + esc(b.dataset.label) : ''}?</h3><div class="muted" style="font-size:13px;">The old lead status / site visit is put back on leads that still have the uploaded value.</div>`, 'Undo upload')) return;
                const done = busy(b, '');
                try { const r = await api('undo', Object.assign({ upload_id: +b.dataset.undo }, b.dataset.db ? { db: b.dataset.db } : {})); msg(`Undone: ${fmt(r.restored)} lead(s) restored${r.kept ? `, ${fmt(r.kept)} value(s) kept because they were changed after the upload` : ''}.`, 'good'); loadHistory(); }
                catch (e) { msg(esc(e.message)); done(); }
            }));
        } catch (e) { $('#hist-body').innerHTML = `<tr><td colspan="8" class="muted">${esc(e.message)}</td></tr>`; }
    }
    /* ── checks before uploading ── */
    async function runChecks() {
        const list = $('#checks-list'), sub = $('#checks-sub'), card = $('#checks');
        sub.innerHTML = '<span class="spinner"></span>Checking the server…';
        card.classList.remove('collapsed');
        try {
            const d = await api('check');
            const bad = d.checks.filter(c => !c.ok && c.blocking), warn = d.checks.filter(c => (!c.ok && !c.blocking) || (c.ok && c.fix));
            list.innerHTML = d.checks.map(c => {
                const cls = c.ok ? (c.fix ? 'wa' : 'ok') : (c.blocking ? 'no' : 'wa');
                return `<div class="chk"><i class="${cls}">${cls === 'ok' ? '✓' : cls === 'no' ? '✕' : '!'}</i><div><b>${esc(c.label)}</b></div>
                    <div class="d">${esc(c.detail)}</div>${(!c.ok || cls === 'wa') && c.fix ? `<div class="fx">${esc(c.fix)}</div>` : ''}</div>`;
            }).join('');
            $('#drop').classList.toggle('locked', !d.ready);
            if (!d.ready) {
                sub.innerHTML = `<b style="color:var(--bad)">${bad.length} problem${bad.length === 1 ? '' : 's'} to fix before uploading.</b> Fix ${bad.length === 1 ? 'it' : 'them'}, then press “Check again”.`;
            } else {
                sub.innerHTML = `<b style="color:var(--good)">Ready to upload.</b>${warn.length ? ` ${warn.length} note${warn.length === 1 ? '' : 's'} below.` : ''} <a href="#" id="checks-toggle" style="color:var(--text-dim)">Show / hide details</a>`;
                if (!warn.length) card.classList.add('collapsed');
                const t = $('#checks-toggle');
                if (t) t.addEventListener('click', e => { e.preventDefault(); card.classList.toggle('collapsed'); });
            }
        } catch (e) {
            sub.innerHTML = `<b style="color:var(--bad)">Could not run the checks:</b> ${esc(e.message)}`;
        }
    }
    $('#recheck').addEventListener('click', runChecks);
    $('#db').addEventListener('change', () => { loadHistory(); runChecks(); if ($('#db-hint')) $('#db-hint').classList.toggle('hidden', db() !== 'all'); if ($('#m-camp')) $('#m-camp').classList.toggle('hidden', db() !== 'all'); });
    runChecks();
    loadHistory();
    loadMlHistory();
})();
</script>
</body>
</html>
