<?php
/**
 * users_api.php — backend of leads/users.php (Users & Roles). Super Admin only (checked in app/Core/access.php).
 *
 *   GET  ?action=load                       → users, roles, modules, me, setup notes
 *   POST ?action=save_user   {uid?, username, email, role, status, unmask_email, unmask_mobile, export_email, export_mobile}
 *   POST ?action=set_flag    {uid, field: status|unmask_email|unmask_mobile|export_email|export_mobile, value: Y|N}
 *   unmask_* = full email / mobile on screen, export_* = full email / mobile in Excel / CSV exports (app/Core/db.php pqContact)
 *   POST ?action=delete_user {uid}
 *   POST ?action=save_role   {key?, name, description, permissions: {module: [actions]}}
 *   POST ?action=delete_role {key, move_to}
 */
ob_start();
ini_set('display_errors', '0');
session_start();
require_once dirname(__DIR__, 2) . '/app/Core/db.php';   // also runs the access check (Super Admin only)

function uaJson(array $p, int $code = 200): never
{
    while (ob_get_level()) {
        ob_end_clean();
    }
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    header('X-Content-Type-Options: nosniff');
    echo json_encode($p, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}
function uaFail(string $msg, int $code = 400): never
{
    uaJson(['success' => false, 'error' => $msg], $code);
}
if (($_SESSION['role'] ?? '') !== 'superadmin') {
    uaFail('Only a Super Admin can manage users.', 403);
}
$me = (int) ($_SESSION['uid'] ?? 0);
session_write_close();

$db = $conn;
$action = (string) ($_GET['action'] ?? 'load');
$isPost = ($_SERVER['REQUEST_METHOD'] ?? '') === 'POST';
$in = $isPost ? (json_decode((string) file_get_contents('php://input'), true) ?: []) : [];

function uaLog(mysqli $db, array $details): void
{
    try {
        $uid = (int) ($_SESSION['uid'] ?? 0);
        $project = defined('PROJECT_NAME') ? (string) PROJECT_NAME : '';
        $d = json_encode($details, JSON_UNESCAPED_UNICODE);
        $st = $db->prepare("INSERT INTO team_activity_logs (uid, project_name, action_type, action_details) VALUES (?, ?, 'click', ?)");
        if ($st) {
            $st->bind_param('iss', $uid, $project, $d);
            $st->execute();
        }
    } catch (Throwable $e) {
    }
}
function uaUser(mysqli $db, int $uid): ?array
{
    $st = $db->prepare('SELECT uid, username, email, role, status FROM users WHERE uid = ?');
    $st->bind_param('i', $uid);
    $st->execute();
    $r = $st->get_result()->fetch_assoc();
    $st->close();
    return $r ?: null;
}
function uaActiveSupers(mysqli $db, int $exceptUid = 0): int
{
    $st = $db->prepare("SELECT COUNT(*) AS n FROM users WHERE role = 'superadmin' AND status = 'Y' AND uid <> ?");
    $st->bind_param('i', $exceptUid);
    $st->execute();
    return (int) $st->get_result()->fetch_assoc()['n'];
}
function uaRoleColumnIsEnum(mysqli $db): bool
{
    $c = $db->query("SHOW COLUMNS FROM `users` LIKE 'role'");
    $col = $c ? $c->fetch_assoc() : null;
    return $col && stripos((string) $col['Type'], 'enum') === 0;
}

try {
    $notes = pqEnsureRoles($db);
    $roles = pqRoles($db, true);
    $validRole = fn(string $r) => $r === 'superadmin' || isset($roles[$r]);

    if ($action === 'load') {
        $users = [];
        $hasLast = (bool) @$db->query('SELECT lastlogin FROM users LIMIT 0');
        $hasExport = pqEnsureContactColumns($db);
        $res = $db->query('SELECT uid, username, email, role, status, createdon, unmask_email, unmask_mobile' . ($hasExport ? ', export_email, export_mobile' : '') . ($hasLast ? ', lastlogin' : '') . ' FROM users ORDER BY uid DESC');
        while ($res && ($r = $res->fetch_assoc())) {
            $r['uid'] = (int) $r['uid'];
            $users[] = $r;
        }
        $counts = [];
        foreach ($users as $u) {
            $counts[$u['role']] = ($counts[$u['role']] ?? 0) + 1;
        }
        $roleList = [['key' => 'superadmin', 'name' => 'Super Admin', 'description' => 'Full access to everything, including Users & Roles', 'permissions' => null, 'is_system' => 1, 'builtin' => true, 'users' => $counts['superadmin'] ?? 0]];
        foreach ($roles as $k => $r) {
            $roleList[] = ['key' => $k, 'name' => $r['name'], 'description' => $r['description'], 'permissions' => (object) $r['permissions'],
                           'is_system' => $r['is_system'], 'builtin' => false, 'users' => $counts[$k] ?? 0];
        }
        $modules = [];
        foreach (PQ_MODULES as $k => $m) {
            $modules[] = ['key' => $k] + $m;
        }
        $metrics = [];
        foreach (PQ_METRICS as $k => $m) {
            $metrics[] = ['key' => $k] + $m;
        }
        $ctypes = [];
        foreach (PQ_CAMPAIGN_TYPES as $k => $m) {
            $ctypes[] = ['key' => $k] + $m;
        }
        uaJson(['success' => true, 'me' => $me, 'users' => $users, 'roles' => $roleList, 'modules' => $modules, 'metrics' => $metrics, 'campaign_types' => $ctypes,
                'notes' => $notes, 'role_column_enum' => uaRoleColumnIsEnum($db)]);
    }

    if (!$isPost) {
        uaFail('Unknown action.');
    }

    if ($action === 'save_user') {
        $uid = (int) ($in['uid'] ?? 0);
        $name = trim((string) ($in['username'] ?? ''));
        $email = strtolower(trim((string) ($in['email'] ?? '')));
        $role = (string) ($in['role'] ?? 'admin');
        $status = ($in['status'] ?? 'Y') === 'N' ? 'N' : 'Y';
        $ue = ($in['unmask_email'] ?? 'N') === 'Y' ? 'Y' : 'N';
        $um = ($in['unmask_mobile'] ?? 'N') === 'Y' ? 'Y' : 'N';
        $xe = ($in['export_email'] ?? 'N') === 'Y' ? 'Y' : 'N';
        $xm = ($in['export_mobile'] ?? 'N') === 'Y' ? 'Y' : 'N';
        $hasExport = pqEnsureContactColumns($db);
        if ($name === '' || mb_strlen($name) > 100) {
            uaFail('Enter the full name (up to 100 characters).');
        }
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            uaFail('Enter a valid email address.');
        }
        if (!$validRole($role)) {
            uaFail('Choose a role.');
        }
        if (!in_array($role, ['superadmin', 'admin'], true) && uaRoleColumnIsEnum($db)) {
            uaFail('The users table still only allows Super Admin / Admin. Run: ALTER TABLE users MODIFY role VARCHAR(50) NOT NULL DEFAULT \'admin\';');
        }
        $st = $db->prepare('SELECT uid FROM users WHERE LOWER(email) = ? AND uid <> ?');
        $st->bind_param('si', $email, $uid);
        $st->execute();
        if ($st->get_result()->fetch_assoc()) {
            uaFail('Another user already has this email.');
        }
        if ($uid) {
            $old = uaUser($db, $uid);
            if (!$old) {
                uaFail('User not found.', 404);
            }
            if ($uid === $me && ($role !== 'superadmin' || $status !== 'Y')) {
                uaFail('You can\'t remove your own Super Admin role or block yourself.');
            }
            if ($old['role'] === 'superadmin' && ($role !== 'superadmin' || $status !== 'Y') && uaActiveSupers($db, $uid) === 0) {
                uaFail('This is the last active Super Admin — make someone else Super Admin first.');
            }
            $st = $db->prepare('UPDATE users SET username = ?, email = ?, role = ?, status = ?, unmask_email = ?, unmask_mobile = ? WHERE uid = ?');
            $st->bind_param('ssssssi', $name, $email, $role, $status, $ue, $um, $uid);
            $st->execute();
            if ($hasExport) {
                $st = $db->prepare('UPDATE users SET export_email = ?, export_mobile = ? WHERE uid = ?');
                $st->bind_param('ssi', $xe, $xm, $uid);
                $st->execute();
            }
            uaLog($db, ['action' => 'edit_user', 'edited_uid' => $uid, 'email' => $email, 'role' => $role, 'status' => $status === 'Y' ? 'Active' : 'Blocked']);
        } else {
            $st = $db->prepare('INSERT INTO users (username, email, role, status, unmask_email, unmask_mobile, createdon) VALUES (?, ?, ?, ?, ?, ?, NOW())');
            $st->bind_param('ssssss', $name, $email, $role, $status, $ue, $um);
            $st->execute();
            $st = $db->prepare('SELECT uid FROM users WHERE LOWER(email) = ?');
            $st->bind_param('s', $email);
            $st->execute();
            $uid = (int) (($st->get_result()->fetch_assoc())['uid'] ?? 0);
            if ($hasExport && $uid) {
                $st = $db->prepare('UPDATE users SET export_email = ?, export_mobile = ? WHERE uid = ?');
                $st->bind_param('ssi', $xe, $xm, $uid);
                $st->execute();
            }
            uaLog($db, ['action' => 'add_user', 'added_email' => $email, 'role' => $role]);
        }
        uaJson(['success' => true, 'uid' => $uid]);
    }

    if ($action === 'set_flag') {
        $uid = (int) ($in['uid'] ?? 0);
        $field = (string) ($in['field'] ?? '');
        $value = ($in['value'] ?? 'N') === 'Y' ? 'Y' : 'N';
        if (in_array($field, ['export_email', 'export_mobile'], true) && !pqEnsureContactColumns($db)) {
            uaFail('Could not add the export switches to the users table (the database user needs ALTER rights). Run docs/08_update_contact_export.sql.');
        }
        if (!in_array($field, ['status', 'unmask_email', 'unmask_mobile', 'export_email', 'export_mobile'], true)) {
            uaFail('Unknown setting.');
        }
        $u = uaUser($db, $uid);
        if (!$u) {
            uaFail('User not found.', 404);
        }
        if ($field === 'status' && $value === 'N') {
            if ($uid === $me) {
                uaFail('You can\'t block yourself.');
            }
            if ($u['role'] === 'superadmin' && uaActiveSupers($db, $uid) === 0) {
                uaFail('This is the last active Super Admin.');
            }
        }
        $st = $db->prepare("UPDATE users SET `{$field}` = ? WHERE uid = ?");
        $st->bind_param('si', $value, $uid);
        $st->execute();
        uaLog($db, ['action' => 'permission_change', 'target_uid' => $uid, 'permission' => $field, 'value' => $value]);
        uaJson(['success' => true]);
    }

    if ($action === 'delete_user') {
        $uid = (int) ($in['uid'] ?? 0);
        $u = uaUser($db, $uid);
        if (!$u) {
            uaFail('User not found.', 404);
        }
        if ($uid === $me) {
            uaFail('You can\'t delete your own account.');
        }
        if ($u['role'] === 'superadmin' && uaActiveSupers($db, $uid) === 0) {
            uaFail('This is the last active Super Admin — it can\'t be deleted.');
        }
        $st = $db->prepare('DELETE FROM users WHERE uid = ?');
        $st->bind_param('i', $uid);
        $st->execute();
        uaLog($db, ['action' => 'delete_user', 'deleted_uid' => $uid, 'email' => $u['email'], 'role' => $u['role']]);
        uaJson(['success' => true]);   // their next request signs them out (access check)
    }

    if ($action === 'save_role') {
        $key = (string) ($in['key'] ?? '');
        $name = trim((string) ($in['name'] ?? ''));
        $desc = mb_substr(trim((string) ($in['description'] ?? '')), 0, 255);
        $perms = pqCleanPermissions((array) ($in['permissions'] ?? []));
        if ($name === '' || mb_strlen($name) > 100) {
            uaFail('Enter a role name (up to 100 characters).');
        }
        if ($key === 'superadmin') {
            uaFail('Super Admin always has full access and can\'t be changed.');
        }
        foreach ($roles as $k => $r) {
            if ($k !== $key && strcasecmp($r['name'], $name) === 0) {
                uaFail('A role with this name already exists.');
            }
        }
        $now = date('Y-m-d H:i:s');
        $p = json_encode($perms ?: new stdClass());
        if ($key !== '') {
            if (!isset($roles[$key])) {
                uaFail('Role not found.', 404);
            }
            $st = $db->prepare('UPDATE `pq_roles` SET name = ?, description = ?, permissions = ?, updated_at = ? WHERE role_key = ?');
            $st->bind_param('sssss', $name, $desc, $p, $now, $key);
            $st->execute();
        } else {
            $base = trim(preg_replace('/[^a-z0-9]+/', '_', strtolower($name)), '_') ?: 'role';
            $base = substr($base, 0, 40);
            $key = $base;
            for ($i = 2; isset($roles[$key]) || $key === 'superadmin'; $i++) {
                $key = $base . '_' . $i;
            }
            $sys = 0;
            $st = $db->prepare('INSERT INTO `pq_roles` (role_key, name, description, permissions, is_system, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)');
            $st->bind_param('ssssiss', $key, $name, $desc, $p, $sys, $now, $now);
            $st->execute();
        }
        uaLog($db, ['action' => 'save_role', 'role' => $key, 'permissions' => $perms]);
        uaJson(['success' => true, 'key' => $key]);
    }

    if ($action === 'delete_role') {
        $key = (string) ($in['key'] ?? '');
        $moveTo = (string) ($in['move_to'] ?? '');
        if (!isset($roles[$key])) {
            uaFail('Role not found.', 404);
        }
        if ($roles[$key]['is_system']) {
            uaFail('The ' . $roles[$key]['name'] . ' role is built in and can\'t be deleted (you can change its permissions).');
        }
        $st = $db->prepare('SELECT COUNT(*) AS n FROM users WHERE role = ?');
        $st->bind_param('s', $key);
        $st->execute();
        $n = (int) $st->get_result()->fetch_assoc()['n'];
        if ($n > 0) {
            if ($moveTo === $key || !$validRole($moveTo)) {
                uaFail('Choose the role to give the ' . $n . ' user(s) who have this role.');
            }
            $st = $db->prepare('UPDATE users SET role = ? WHERE role = ?');
            $st->bind_param('ss', $moveTo, $key);
            $st->execute();
        }
        $st = $db->prepare('DELETE FROM `pq_roles` WHERE role_key = ?');
        $st->bind_param('s', $key);
        $st->execute();
        uaLog($db, ['action' => 'delete_role', 'role' => $key, 'users_moved_to' => $n ? $moveTo : null, 'users' => $n]);
        uaJson(['success' => true, 'moved' => $n]);
    }

    uaFail('Unknown action.');
} catch (Throwable $e) {
    error_log('[users_api] ' . $e->getMessage() . ' @ ' . $e->getFile() . ':' . $e->getLine());
    uaFail('Server error: ' . $e->getMessage(), 500);
}
