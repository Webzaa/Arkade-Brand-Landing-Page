<?php
include dirname(__DIR__, 2) . '/app/Core/db.php';
header('Content-Type: application/json; charset=utf-8');

// Response history of one lead. `mobile` is the lead reference from the Leads list (or a plain mobile).
$mobile = pqLeadMobile($_POST['mobile'] ?? '');
$data_result = [];

if ($mobile !== '') {
  $st = $conn->prepare('SELECT id_map, reason, comment, followup_date, createddt FROM map_lead WHERE mobile = ? ORDER BY createddt ASC');
  if ($st) {
    $st->bind_param('s', $mobile);
    $st->execute();
    $result = $st->get_result();
    while ($result && ($row = $result->fetch_assoc())) {
      $fd = (string) ($row['followup_date'] ?? '');
      $data_result[] = [
        'id_map' => $row['id_map'],
        'reason' => $row['reason'],
        'comment' => $row['comment'],
        'followup_date' => ($fd === '' || str_starts_with($fd, '0000-00-00')) ? '' : date('d-m-Y h:i a', strtotime($fd)),
        'createddt' => date('d-m-Y h:i a', strtotime((string) $row['createddt'])),
      ];
    }
    $st->close();
  }
}

echo json_encode($data_result, JSON_UNESCAPED_UNICODE);
