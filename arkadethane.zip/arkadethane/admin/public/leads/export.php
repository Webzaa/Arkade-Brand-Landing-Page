<?php

declare(strict_types=1);

session_start();

include dirname(__DIR__, 2) . '/app/Core/db.php';
require_once dirname(__DIR__, 2) . '/app/Leads/status_filter.php';
require_once dirname(__DIR__, 2) . '/app/bootstrap.php';


/*
|--------------------------------------------------------------------------
| AUTHENTICATION
|--------------------------------------------------------------------------
*/

if (
  !isset($_SESSION['user_logged']) ||
  $_SESSION['user_logged'] !== 'Y'
) {
  header('Location: login.php');
  exit;
}


/*
|--------------------------------------------------------------------------
| INPUT
|--------------------------------------------------------------------------
*/

$from_date = trim(
  (string) ($_POST['from_date'] ?? '')
);

$to_date = trim(
  (string) ($_POST['to_date'] ?? '')
);

$camp_source = trim(
  (string) ($_POST['camp_source'] ?? '')
);

$Campaign_sub_source = trim(
  (string) ($_POST['Campaign_sub_source'] ?? '')
);

$keyword = trim(
  (string) ($_POST['keyword'] ?? '')
);

$till_date = (string) (
  $_POST['till_date'] ?? ''
);


/*
|--------------------------------------------------------------------------
| DATABASE FILTER
|--------------------------------------------------------------------------
|
| pseudo   = test_beliciacp
| official = test_belicia
| all      = both databases
|
*/

$database = strtolower(
  trim((string) ($_POST['database'] ?? 'all'))
);

if (
  !isLeadDbChoice($database)
) {
  $database = 'all';
}


/*
|--------------------------------------------------------------------------
| DATABASE CONNECTIONS
|--------------------------------------------------------------------------
*/

$connections = leadDbs($database);   // 'all' = every database in LEAD_DATABASES


/*
|--------------------------------------------------------------------------
| BUILD WHERE CLAUSE
|--------------------------------------------------------------------------
*/

function buildExportWhere(
  mysqli $db,
  string $from_date,
  string $camp_source,
  string $campaign_sub_source,
  string $keyword,
  string $till_date
): string {

  $conditions = [];


  /*
  |--------------------------------------------------------------------------
  | DATE FILTER
  |--------------------------------------------------------------------------
  */

  if ($till_date === '1') {

    $conditions[] = '1=1';

  } elseif ($from_date !== '') {

    /*
    |--------------------------------------------------------------------------
    | Expected format:
    |
    | DD/MM/YYYY - DD/MM/YYYY
    |--------------------------------------------------------------------------
    */

    $parts = preg_split(
      '/\s*-\s*/',
      $from_date
    );

    if (
      is_array($parts) &&
      count($parts) >= 2
    ) {

      $start = DateTime::createFromFormat(
        'd/m/Y',
        trim($parts[0])
      );

      $end = DateTime::createFromFormat(
        'd/m/Y',
        trim($parts[1])
      );

      if ($start && $end) {

        $startDate =
          $start->format('Y-m-d');

        $endDate =
          $end->format('Y-m-d');

        $conditions[] = sprintf(
          "DATE(createddate) BETWEEN '%s' AND '%s'",
          $db->real_escape_string($startDate),
          $db->real_escape_string($endDate)
        );
      }

    } else {

      /*
      |--------------------------------------------------------------------------
      | Single date fallback
      |--------------------------------------------------------------------------
      */

      $singleDate =
        DateTime::createFromFormat(
          'd/m/Y',
          trim($from_date)
        );

      if ($singleDate) {

        $date =
          $singleDate->format('Y-m-d');

        $conditions[] = sprintf(
          "DATE(createddate) = '%s'",
          $db->real_escape_string($date)
        );
      }
    }

  } else {

    /*
    |--------------------------------------------------------------------------
    | DEFAULT = LAST 7 DAYS
    |--------------------------------------------------------------------------
    */

    $conditions[] = "
            DATE(createddate) >=
            DATE(NOW() - INTERVAL 6 DAY)
        ";
  }


  /*
  |--------------------------------------------------------------------------
  | CAMPAIGN SOURCE
  |--------------------------------------------------------------------------
  */

  if ($camp_source !== '') {

    $conditions[] = sprintf(
      "campaignsource = '%s'",
      $db->real_escape_string($camp_source)
    );
  }

    if (($pqStatusSql = pqLeadStatusFilterFromRequest()) !== '') {
        $conditions[] = $pqStatusSql;   // Lead status filter (app/Leads/status_filter.php)
    }


  /*
  |--------------------------------------------------------------------------
  | CAMPAIGN SUB SOURCE
  |--------------------------------------------------------------------------
  */

  if ($campaign_sub_source !== '') {

    $conditions[] = sprintf(
      "campaignsubsource = '%s'",
      $db->real_escape_string($campaign_sub_source)
    );
  }


  /*
  |--------------------------------------------------------------------------
  | KEYWORD
  |--------------------------------------------------------------------------
  |
  | Search:
  | keyword
  | name
  | email
  | mobile
  |--------------------------------------------------------------------------
  */

  if ($keyword !== '') {

    $safeKeyword =
      $db->real_escape_string($keyword);

    $conditions[] = "
            (
                keyword LIKE '%{$safeKeyword}%'
                OR name LIKE '%{$safeKeyword}%'
                OR email LIKE '%{$safeKeyword}%'
                OR mobile LIKE '%{$safeKeyword}%'
            )
        ";
  }


  return implode(
    ' AND ',
    $conditions
  );
}


/*
|--------------------------------------------------------------------------
| FETCH RECORDS FROM DATABASE
|--------------------------------------------------------------------------
*/

function fetchExportRecords(
  mysqli $db,
  string $databaseName,
  string $from_date,
  string $camp_source,
  string $campaign_sub_source,
  string $keyword,
  string $till_date
): array {

  $where = buildExportWhere(
    $db,
    $from_date,
    $camp_source,
    $campaign_sub_source,
    $keyword,
    $till_date
  );


  /*
  |--------------------------------------------------------------------------
  | Query
  |--------------------------------------------------------------------------
  */

  $query = "
        SELECT
            l.*,

            IFNULL(
                (
                    SELECT reason
                    FROM map_lead
                    WHERE mobile = l.mobile
                    ORDER BY createddt DESC
                    LIMIT 1
                ),
                ''
            ) AS reason

        FROM `lead` l

        WHERE {$where}

        ORDER BY
            createddate DESC,
            id DESC
    ";


  $result = $db->query($query);


  if ($result === false) {

    error_log(
      "Export query failed [{$databaseName}]: "
      . $db->error
    );

    return [];
  }


  $rows = [];


  while ($row = $result->fetch_assoc()) {

    $row['_database'] =
      leadDbLabel($databaseName);   // readable name from LEAD_DATABASES

    $rows[] = $row;
  }


  return $rows;
}


/*
|--------------------------------------------------------------------------
| FETCH FROM SELECTED DATABASE(S)
|--------------------------------------------------------------------------
*/

$allRows = [];


foreach (
  $connections
  as $databaseName => $databaseConnection
) {

  if (
    !($databaseConnection instanceof mysqli) ||
    $databaseConnection->connect_errno
  ) {

    error_log(
      "Invalid database connection: {$databaseName}"
    );

    continue;
  }


  $rows = fetchExportRecords(
    $databaseConnection,
    $databaseName,
    $from_date,
    $camp_source,
    $Campaign_sub_source,
    $keyword,
    $till_date
  );


  $allRows = array_merge(
    $allRows,
    $rows
  );
}


/*
|--------------------------------------------------------------------------
| GLOBAL SORT
|--------------------------------------------------------------------------
|
| Important for ALL mode.
|--------------------------------------------------------------------------
*/

usort(
  $allRows,
  static function (array $a, array $b): int {

    $dateA = strtotime(
      (string) ($a['createddate'] ?? '')
    );

    $dateB = strtotime(
      (string) ($b['createddate'] ?? '')
    );


    if ($dateA === $dateB) {

      $idA =
        (int) ($a['id'] ?? 0);

      $idB =
        (int) ($b['id'] ?? 0);

      return $idB <=> $idA;
    }


    return $dateB <=> $dateA;
  }
);


/*
|--------------------------------------------------------------------------
| EXCEL FILTER / ESCAPE
|--------------------------------------------------------------------------
*/

function filterData(&$str): void
{
  $str = (string) $str;

  /*
  |--------------------------------------------------------------------------
  | Prevent formula injection
  |--------------------------------------------------------------------------
  |
  | Excel interprets values beginning with:
  | = + - @
  |
  | as formulas.
  |--------------------------------------------------------------------------
  */

  if (
    preg_match(
      '/^[=+\-@]/',
      $str
    )
  ) {
    $str = "'" . $str;
  }


  /*
  |--------------------------------------------------------------------------
  | Escape tabs/newlines
  |--------------------------------------------------------------------------
  */

  $str = str_replace(
    ["\r\n", "\r", "\n"],
    ' ',
    $str
  );

  $str = str_replace(
    "\t",
    ' ',
    $str
  );


  /*
  |--------------------------------------------------------------------------
  | Escape quotes
  |--------------------------------------------------------------------------
  */

  if (
    preg_match(
      '/["]/',
      $str
    )
  ) {
    $str = '"' .
      str_replace(
        '"',
        '""',
        $str
      ) .
      '"';
  }
}


/*
|--------------------------------------------------------------------------
| FILE NAME
|--------------------------------------------------------------------------
*/

$projectName =
  defined('PROJECT_NAME')
  ? PROJECT_NAME
  : 'Project';

$fileName =
  'Leads_'
  . $projectName
  . '_'
  . date('YmdHis')
  . '.xls';


/*
|--------------------------------------------------------------------------
| EXCEL COLUMNS
|--------------------------------------------------------------------------
*/

$fields = [

  'Database',
  'ID',
  'Date',
  'Time',
  'Name',
  'Email',
  'Country code',
  'Mobile',
  'Campaign Source',
  'Campaign Sub Source',
  'Placement',
  'IP Address',
  'Ad Set',
  'Ad Creative',
  'Device',
  'Keyword',
  'BHK Type',
  'Purpose',
  'Visit Possible On',
  'Fav Destination',
  'Villa Type',
  'Project Interested',
  'Ad Name',
  'Adset Name',
  'Campaign Name',
  'Form ID',
  'Ad ID',
  'Unique ID',
  'Page ID',
  'Capture From Name',
  'Website Name',
  'Keyword',
  'UTMM',
  'UTMC',
  'UTM Campaign ID',
  'UTM Campaign Name',
  'UTM AD Group ID',
  'UTM AD Group Name',
  'UTM AD ID',
  'UTM AD Name',
  'Lead Status',
  'Site Visit',
  'Duplicate',
  'Reason',
  'Response',
  'UTM SSC'
];


/*
|--------------------------------------------------------------------------
| EXCEL HEADER
|--------------------------------------------------------------------------
*/

$excelData =
  implode(
    "\t",
    array_values($fields)
  ) . "\n";


/*
|--------------------------------------------------------------------------
| BUILD EXCEL DATA
|--------------------------------------------------------------------------
*/

$cnt = 0;


foreach ($allRows as $row) {

  $cnt++;


  /*
  |--------------------------------------------------------------------------
  | EMAIL
  |--------------------------------------------------------------------------
  */

  // Users & Roles → "Full emails / mobiles in exports" (app/Core/db.php pqContact); masked otherwise
  $email = pqContact($row['email'] ?? '', 'email', 'export');
  $mobile = pqContact($row['mobile'] ?? '', 'mobile', 'export');


  /*
  |--------------------------------------------------------------------------
  | UNIQUE ID
  |--------------------------------------------------------------------------
  */

  if (
    ($row['campaignsubsource'] ?? '')
    === 'Facebook Lead Form'
  ) {

    $unique_id =
      $row['leadgen_id'] ?? '';

  } else {

    $unique_id =
      $row['uniqueid'] ?? '';
  }


  /*
  |--------------------------------------------------------------------------
  | CREATED DATE
  |--------------------------------------------------------------------------
  */

  $createdDate =
    !empty($row['createddate'])
    ? strtotime(
      $row['createddate']
    )
    : false;


  $dateValue =
    $createdDate
    ? date(
      'd-M-Y',
      $createdDate
    )
    : '';


  $timeValue =
    $createdDate
    ? date(
      'H:i:s',
      $createdDate
    )
    : '';


  /*
  |--------------------------------------------------------------------------
  | LINE
  |--------------------------------------------------------------------------
  */

  $lineData = [

    $row['_database'] ?? '',

    $cnt,

    $dateValue,

    $timeValue,

    $row['name'] ?? '',

    $email,

    $row['countrycode'] ?? '',

    $mobile,

    $row['campaignsource'] ?? '',

    $row['campaignsubsource'] ?? '',

    $row['placement'] ?? '',

    $row['ip_address'] ?? '',

    $row['adset'] ?? '',

    $row['adcreative'] ?? '',

    $row['device'] ?? '',

    $row['keyword'] ?? '',

    $row['bhktype'] ?? '',

    $row['purpose'] ?? '',

    $row['visitpossibleon'] ?? '',

    $row['favdestination'] ?? '',

    $row['villatype'] ?? '',

    $row['projinterest'] ?? '',

    $row['ad_name'] ?? '',

    $row['adset_name'] ?? '',

    $row['campaign_name'] ?? '',

    $row['form_id'] ?? '',

    $row['ad_id'] ?? '',

    $unique_id,

    $row['page_id'] ?? '',

    $row['capturefromname'] ?? '',

    $row['websitename'] ?? '',

    $row['keyword'] ?? '',

    $row['utmM'] ?? '',

    $row['utmC'] ?? '',

    $row['utm_campaignid'] ?? '',

    $row['utm_campaignname'] ?? '',

    $row['utm_adgroupid'] ?? '',

    $row['utm_adgroupname'] ?? '',

    $row['utm_adid'] ?? '',

    $row['utm_adname'] ?? '',

    $row['lead_status'] ?? '',

    $row['sitevisit_status'] ?? '',

    $row['duplicate'] ?? '',

    $row['reason'] ?? '',

    $row['curlresponse'] ?? '',

    $row['utm_ssc'] ?? ''
  ];


  /*
  |--------------------------------------------------------------------------
  | Escape Excel Values
  |--------------------------------------------------------------------------
  */

  array_walk(
    $lineData,
    'filterData'
  );


  $excelData .=
    implode(
      "\t",
      array_values($lineData)
    ) . "\n";
}


/*
|--------------------------------------------------------------------------
| NO RECORDS
|--------------------------------------------------------------------------
*/

if ($cnt === 0) {

  $excelData .=
    "No records found...\n";
}


/*
|--------------------------------------------------------------------------
| DOWNLOAD HEADERS
|--------------------------------------------------------------------------
*/

header(
  'Content-Type: application/vnd.ms-excel; charset=UTF-8'
);

header(
  'Content-Disposition: attachment; filename="' .
  $fileName .
  '"'
);

header(
  'Content-Length: ' .
  strlen($excelData)
);

header(
  'Cache-Control: max-age=0'
);


/*
|--------------------------------------------------------------------------
| OUTPUT
|--------------------------------------------------------------------------
*/

echo $excelData;

exit;