<?php
session_start();
include dirname(__DIR__, 2) . '/app/Core/db.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_logged']) || $_SESSION['user_logged'] !== 'Y') {
  http_response_code(401);
  echo json_encode(['message' => 'failure', 'error' => 'Not logged in']);
  exit;
}

// Form fields arrive as jQuery serializeArray(): [{name, value}, …]. Read them by NAME
// (the old code read them by position, which broke whenever a field was disabled or moved).
$fields = [];
foreach ((array) ($_POST['from_data'] ?? []) as $pair) {
  if (is_array($pair) && isset($pair['name']) && !isset($fields[$pair['name']])) {
    $fields[(string) $pair['name']] = trim((string) ($pair['value'] ?? ''));
  }
}
$get = fn(string $k) => $fields[$k] ?? '';

$name              = $get('full_name');
$countrycode       = $get('countrycode');
// editing: the Edit page sends the lead reference (the mobile is masked there for some users)
$mobile            = pqLeadMobile($_POST['mobile'] ?? $get('mobile'));
$email             = $get('email');
$campaignsource    = $get('campaignsource');
$campaignsubsource = $get('campaignsubsource');
$bhktype           = $get('bhktype');
$purpose           = $get('purpose');
$visitpossibleon   = $get('visitpossibleon');
$favdestination    = $get('favdestination');
$villatype         = $get('villatype');
$projinterest      = $get('projinterest');

if (!preg_match('/^\+?[0-9]{6,15}$/', $mobile)) {
  echo json_encode(['message' => 'failure', 'error' => 'Enter a valid mobile number']);
  exit;
}

// Save into the lead's own database (LEAD_DATABASES key); new leads go to APP_DB.
$dbKey = (string) ($_POST['database'] ?? '');
if ($dbKey === '' || $dbKey === 'all' || !isLeadDbChoice($dbKey)) {
  $dbKey = appDbKey();
}
$db = leadDb($dbKey);
if (!$db) {
  echo json_encode(['message' => 'failure', 'error' => leadDbLabel($dbKey) . ' database is not reachable']);
  exit;
}

$exists = false;
$storedEmail = '';
$stmt = $db->prepare('SELECT email FROM lead WHERE mobile = ? LIMIT 1');
if ($stmt) {
  $stmt->bind_param('s', $mobile);
  $stmt->execute();
  $row = $stmt->get_result()->fetch_assoc();
  $exists = (bool) $row;
  $storedEmail = (string) ($row['email'] ?? '');
  $stmt->close();
}
// the Edit page showed this user a masked email: an unchanged masked value keeps the saved email
if ($exists && $storedEmail !== '' && $email === pqContact($storedEmail, 'email') && $email !== $storedEmail) {
  $email = $storedEmail;
}

if (!$exists) {
  $createddate = date('Y-m-d H:i:s');
  $stmt = $db->prepare('INSERT INTO lead (name, email, countrycode, mobile, campaignsource, campaignsubsource, bhktype, purpose, visitpossibleon, favdestination, villatype, projinterest, createddate)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
  $ok = $stmt && $stmt->bind_param('sssssssssssss', $name, $email, $countrycode, $mobile, $campaignsource, $campaignsubsource,
                                    $bhktype, $purpose, $visitpossibleon, $favdestination, $villatype, $projinterest, $createddate)
            && $stmt->execute();
} else {
  $stmt = $db->prepare('UPDATE lead SET name = ?, email = ?, campaignsource = ?, campaignsubsource = ?, bhktype = ?, purpose = ?,
                        visitpossibleon = ?, favdestination = ?, villatype = ?, projinterest = ? WHERE mobile = ?');
  $ok = $stmt && $stmt->bind_param('sssssssssss', $name, $email, $campaignsource, $campaignsubsource, $bhktype, $purpose,
                                    $visitpossibleon, $favdestination, $villatype, $projinterest, $mobile)
            && $stmt->execute();
}

echo json_encode($ok
  ? ['message' => 'success', 'database' => $dbKey]
  : ['message' => 'failure', 'error' => $stmt ? $stmt->error : $db->error]);
