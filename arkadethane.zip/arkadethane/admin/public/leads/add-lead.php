<?php
/*
=========================================================
* Paper Dashboard 2 - v2.0.1
=========================================================

* Product Page: https://www.creative-tim.com/product/paper-dashboard-2
* Copyright 2020 Creative Tim (https://www.creative-tim.com)

Coded by www.creative-tim.com

 =========================================================

* The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
*/
session_start();
//print_r($_SESSION);exit;
if (!isset($_SESSION["user"])) {
  header("Location: ../login.php");
  exit;
}
include dirname(__DIR__, 2) . '/app/Core/db.php';
require_once dirname(__DIR__, 2) . '/app/Leads/header.php';

// Which database the lead lives in (sent by the Leads list's Edit button); new leads go to APP_DB.
$leadDbKey = (string) ($_POST['database'] ?? '');
if ($leadDbKey === '' || $leadDbKey === 'all' || !isLeadDbChoice($leadDbKey)) {
  $leadDbKey = appDbKey();
}
$leadConn = leadDb($leadDbKey) ?? $conn;

$mobile = '';
$data_result = array();
if (isset($_POST['mobile'])) {
  $mobile = pqLeadMobile($_POST['mobile']);   // the Leads list sends an encrypted lead reference

  $stmt = $leadConn->prepare("SELECT * FROM lead l WHERE mobile = ?");
  if ($stmt) {
    $stmt->bind_param('s', $mobile);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($result && ($row = $result->fetch_assoc())) {
      array_push($data_result, $row);
    }
    $stmt->close();
  }
  if (!$data_result) {
    $mobile = '';   // not found in that database → behave like "add new"
  }
}
?>
<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <link rel="apple-touch-icon" sizes="76x76" href="../assets/img/apple-icon.png">

  <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css" />
  <link rel="icon" type="image/png" href="../assets/img/favicon.png">

  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <title>
    Webzaa Admin | <?php echo PROJECT_NAME; ?>
  </title>
  <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
  <!--     Fonts and icons     -->
  <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
  <link href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
  <!-- CSS Files -->
  <link href="../assets/css/bootstrap.min.css" rel="stylesheet" />
  <link href="../assets/css/paper-dashboard.css?v=2.0.1" rel="stylesheet" />
  <!-- CSS Just for demo purpose, don't include it in your project -->
  <link href="../assets/demo/demo.css" rel="stylesheet" />
  <link href="../assets/css/style.css" rel="stylesheet" />
  <style type="text/css">
    /* Style the tab */
    .tab {
      overflow: hidden;
      border: 1px solid #ccc;
      background-color: #f1f1f1;
    }

    /* Style the buttons inside the tab */
    .tab button {
      background-color: inherit;
      float: left;
      border: none;
      outline: none;
      cursor: pointer;
      padding: 14px 16px;
      transition: 0.3s;
      font-size: 17px;
    }

    /* Change background color of buttons on hover */
    .tab button:hover {
      background-color: #ddd;
    }

    /* Create an active/current tablink class */
    .tab button.active {
      background-color: #ccc;
    }

    /* Style the tab content */
    .tabcontent {
      display: none;
      padding: 6px 12px;
      border: 1px solid #ccc;
      border-top: none;
    }
  </style>
  <style>
    .ui-accordion .ui-accordion-header {
      display: block;
      cursor: pointer;
      position: relative;
      margin: 2px 0 0 0;

      min-height: 0;
      /* support: IE7 */
      font-size: 100%;
      border: 1px solid #FDF8E4;
      background: #846733;
      color: #fff;
    }

    .error {
      border-color: red;
    }
  </style>
</head>


<body class="">

  <div class="wrapper ">
    <div class="sidebar" data-color="white" data-active-color="danger">
      <div class="logo">
        <a href="https://www.creative-tim.com" class="simple-text logo-mini">
          <!-- <div class="logo-image-small">
            <img src="../assets/img/logo-small.png">
          </div> -->
          <!-- <p>CT</p> -->
        </a>
        <a href="../dashboard.php#leads" class="simple-text logo-normal">

          <div class="logo-image-big">
            <img src="../assets/images/webzaa-logo.png">
          </div>
        </a>
      </div>
      <div class="sidebar-wrapper">
        <ul class="nav">
          <li class="active ">
            <a href="../dashboard.php#leads">
              <span class="iconify" data-icon="ri:dashboard-fill" style="font-size:24px;float:left;margin-right:12px;line-height:30px;width:34px;text-align:center;position:relative;"></span>
              <p>Dashboard</p>
            </a>
          </li>
          <li class="">
            <a href="../dashboard.php#leads">
              <i class="nc-icon nc-chart-pie-36"></i>
              <p>Analytics</p>
            </a>
          </li>
          <li class="">
            <a href="../meta_capi.php">
              <span class="iconify" data-icon="ri:meta-fill" style="font-size:24px;float:left;margin-right:12px;line-height:30px;width:34px;text-align:center;position:relative;"></span>
              <p>Meta CAPI</p>
            </a>
          </li>
          <li class="">
            <a href="../import.php">
              <i class="nc-icon nc-cloud-upload-94"></i>
              <p>Import</p>
            </a>
          </li>
          <!--  <li>
            <a href="javascript:;">
              <i class="nc-icon nc-diamond"></i>
              <p>Users</p>
            </a>
          </li> -->
          <!-- <li>
            <a href="javascript:;">
              <i class="nc-icon nc-pin-3"></i>
              <p>Facebook Leads Form</p>
            </a>
          </li> -->
        </ul>
      </div>
    </div>
    <div class="main-panel" style="height: 100vh;">
      <!-- Navbar -->
      <nav class="navbar navbar-expand-lg navbar-absolute fixed-top navbar-transparent">
        <div class="container-fluid">
          <div class="navbar-wrapper">
            <div class="navbar-toggle">
              <button type="button" class="navbar-toggler">
                <span class="navbar-toggler-bar bar1"></span>
                <span class="navbar-toggler-bar bar2"></span>
                <span class="navbar-toggler-bar bar3"></span>
              </button>
            </div>
            <a class="analytics_greeting navbar-brand" href="javascript:;"><?php echo $greeting . ', ' . htmlspecialchars($username); ?></a>
          </div>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navigation" aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-bar navbar-kebab"></span>
            <span class="navbar-toggler-bar navbar-kebab"></span>
            <span class="navbar-toggler-bar navbar-kebab"></span>
          </button>
          <div class="collapse navbar-collapse justify-content-end" id="navigation">
            <form>
              <div class="input-group no-border">
                <!--   <input type="text" value="" class="form-control" placeholder="Search...">
                <div class="input-group-append">
                  <div class="input-group-text">
                    <i class="nc-icon nc-zoom-split"></i>
                  </div>
                </div>
              </div> -->
            </form>
            <ul class="navbar-nav">
              <li class="nav-item btn-rotate dropdown">
                <a class="nav-link dropdown-toggle" href="http://example.com" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  <!-- <i class="nc-icon nc-bell-55"></i> -->
                  <p>
                    <span class="d-lg-none d-md-block">Some Actions</span>
                  </p>
                </a>
                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownMenuLink">
                  <!-- <a class="dropdown-item" href="#">Action</a>
                  <a class="dropdown-item" href="#">Another action</a> -->
                  <a class="dropdown-item" href="./export.php">Logout</a>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </nav>
      <!-- End Navbar -->
      <div class="content">
        <div class="row">
          <div class="col-md-12 row">
            <div class="col-md-9">
              <h3 class="description">Add Lead</h3>
            </div>
            <div class="col-md-3">
              <h3 class="description"><a class="btn btn-primary form-control" style="color: white;background: #424240;float:right;" href="../dashboard.php#leads">Back</a>
            </div>

          </div>
          <div class="col-md-12 row" id="msg">
            <!-- <span class="alert alert-success">Record added successfully</span> -->
          </div>
          <form id="add_lead">
            <div class="col-md-12 row">

              <div class="form-group col-md-4">
                <label for="full_name">Name:</label>
                <input type="text" class="form-control" name="full_name" placeholder="Enter Name" id="full_name" value="<?php if ($mobile != '') echo htmlspecialchars((string) ($data_result[0]['name'] ?? ''), ENT_QUOTES); ?>">
              </div>
              <div class="form-group  col-md-4">
                <label for="countrycode">Country Code :</label>
                <select name="countrycode" id="countrycode" class="form-control">
                  <option value="">Enter Country Code</option>
                  <option value="1">USA (+1)</option>
                  <option value="971">UAE (+971)</option>
                  <option value="91" selected>India (+91)</option>
                  <option value="44">UK (+44)</option>
                  <option value="65">Singapore (+65)</option>
                  <option value="966">Saudi Arabia (+966)</option>
                  <option value="965">Kuwait (+965)</option>
                  <option value="973">Bahrain (+973)</option>
                  <option value="968">Oman (+968)</option>
                  <option value="852">Hong Kong (+852)</option>


                  <optgroup label="Other countries">
                    <option value="213">Algeria (+213)</option>
                    <option value="376">Andorra (+376)</option>
                    <option value="244">Angola (+244)</option>
                    <option value="1264">Anguilla (+1264)</option>
                    <option value="1268">Antigua &amp; Barbuda (+1268)</option>
                    <option value="54">Argentina (+54)</option>
                    <option value="374">Armenia (+374)</option>
                    <option value="297">Aruba (+297)</option>
                    <option value="61">Australia (+61)</option>
                    <option value="43">Austria (+43)</option>
                    <option value="994">Azerbaijan (+994)</option>
                    <option value="1242">Bahamas (+1242)</option>
                    <option value="973">Bahrain (+973)</option>
                    <option value="880">Bangladesh (+880)</option>
                    <option value="1246">Barbados (+1246)</option>
                    <option value="375">Belarus (+375)</option>
                    <option value="32">Belgium (+32)</option>
                    <option value="501">Belize (+501)</option>
                    <option value="229">Benin (+229)</option>
                    <option value="1441">Bermuda (+1441)</option>
                    <option value="975">Bhutan (+975)</option>
                    <option value="591">Bolivia (+591)</option>
                    <option value="387">Bosnia Herzegovina (+387)</option>
                    <option value="267">Botswana (+267)</option>
                    <option value="55">Brazil (+55)</option>
                    <option value="673">Brunei (+673)</option>
                    <option value="359">Bulgaria (+359)</option>
                    <option value="226">Burkina Faso (+226)</option>
                    <option value="257">Burundi (+257)</option>
                    <option value="855">Cambodia (+855)</option>
                    <option value="237">Cameroon (+237)</option>
                    <option value="1">Canada (+1)</option>
                    <option value="238">Cape Verde Islands (+238)</option>
                    <option value="1345">Cayman Islands (+1345)</option>
                    <option value="236">Central African Republic (+236)</option>
                    <option value="56">Chile (+56)</option>
                    <option value="86">China (+86)</option>
                    <option value="57">Colombia (+57)</option>
                    <option value="269">Comoros (+269)</option>
                    <option value="242">Congo (+242)</option>
                    <option value="682">Cook Islands (+682)</option>
                    <option value="506">Costa Rica (+506)</option>
                    <option value="385">Croatia (+385)</option>
                    <option value="53">Cuba (+53)</option>
                    <option value="90392">Cyprus North (+90392)</option>
                    <option value="357">Cyprus South (+357)</option>
                    <option value="42">Czech Republic (+42)</option>
                    <option value="45">Denmark (+45)</option>
                    <option value="253">Djibouti (+253)</option>
                    <option value="1809">Dominica (+1809)</option>
                    <option value="1809">Dominican Republic (+1809)</option>
                    <option value="593">Ecuador (+593)</option>
                    <option value="20">Egypt (+20)</option>
                    <option value="503">El Salvador (+503)</option>
                    <option value="240">Equatorial Guinea (+240)</option>
                    <option value="291">Eritrea (+291)</option>
                    <option value="372">Estonia (+372)</option>
                    <option value="251">Ethiopia (+251)</option>
                    <option value="500">Falkland Islands (+500)</option>
                    <option value="298">Faroe Islands (+298)</option>
                    <option value="679">Fiji (+679)</option>
                    <option value="358">Finland (+358)</option>
                    <option value="33">France (+33)</option>
                    <option value="594">French Guiana (+594)</option>
                    <option value="689">French Polynesia (+689)</option>
                    <option value="241">Gabon (+241)</option>
                    <option value="220">Gambia (+220)</option>
                    <option value="7880">Georgia (+7880)</option>
                    <option value="49">Germany (+49)</option>
                    <option value="233">Ghana (+233)</option>
                    <option value="350">Gibraltar (+350)</option>
                    <option value="30">Greece (+30)</option>
                    <option value="299">Greenland (+299)</option>
                    <option value="1473">Grenada (+1473)</option>
                    <option value="590">Guadeloupe (+590)</option>
                    <option value="671">Guam (+671)</option>
                    <option value="502">Guatemala (+502)</option>
                    <option value="224">Guinea (+224)</option>
                    <option value="245">Guinea - Bissau (+245)</option>
                    <option value="592">Guyana (+592)</option>
                    <option value="509">Haiti (+509)</option>
                    <option value="504">Honduras (+504)</option>
                    <option value="36">Hungary (+36)</option>
                    <option value="354">Iceland (+354)</option>
                    <option value="62">Indonesia (+62)</option>
                    <option value="98">Iran (+98)</option>
                    <option value="964">Iraq (+964)</option>
                    <option value="353">Ireland (+353)</option>
                    <option value="972">Israel (+972)</option>
                    <option value="39">Italy (+39)</option>
                    <option value="1876">Jamaica (+1876)</option>
                    <option value="81">Japan (+81)</option>
                    <option value="962">Jordan (+962)</option>
                    <option value="7">Kazakhstan (+7)</option>
                    <option value="254">Kenya (+254)</option>
                    <option value="686">Kiribati (+686)</option>
                    <option value="850">Korea North (+850)</option>
                    <option value="82">Korea South (+82)</option>
                    <option value="965">Kuwait (+965)</option>
                    <option value="996">Kyrgyzstan (+996)</option>
                    <option value="856">Laos (+856)</option>
                    <option value="371">Latvia (+371)</option>
                    <option value="961">Lebanon (+961)</option>
                    <option value="266">Lesotho (+266)</option>
                    <option value="231">Liberia (+231)</option>
                    <option value="218">Libya (+218)</option>
                    <option value="417">Liechtenstein (+417)</option>
                    <option value="370">Lithuania (+370)</option>
                    <option value="352">Luxembourg (+352)</option>
                    <option value="853">Macao (+853)</option>
                    <option value="389">Macedonia (+389)</option>
                    <option value="261">Madagascar (+261)</option>
                    <option value="265">Malawi (+265)</option>
                    <option value="60">Malaysia (+60)</option>
                    <option value="960">Maldives (+960)</option>
                    <option value="223">Mali (+223)</option>
                    <option value="356">Malta (+356)</option>
                    <option value="692">Marshall Islands (+692)</option>
                    <option value="596">Martinique (+596)</option>
                    <option value="222">Mauritania (+222)</option>
                    <option value="269">Mayotte (+269)</option>
                    <option value="52">Mexico (+52)</option>
                    <option value="691">Micronesia (+691)</option>
                    <option value="373">Moldova (+373)</option>
                    <option value="377">Monaco (+377)</option>
                    <option value="976">Mongolia (+976)</option>
                    <option value="1664">Montserrat (+1664)</option>
                    <option value="212">Morocco (+212)</option>
                    <option value="258">Mozambique (+258)</option>
                    <option value="95">Myanmar (+95)</option>
                    <option value="264">Namibia (+264)</option>
                    <option value="674">Nauru (+674)</option>
                    <option value="977">Nepal (+977)</option>
                    <option value="31">Netherlands (+31)</option>
                    <option value="687">New Caledonia (+687)</option>
                    <option value="64">New Zealand (+64)</option>
                    <option value="505">Nicaragua (+505)</option>
                    <option value="227">Niger (+227)</option>
                    <option value="234">Nigeria (+234)</option>
                    <option value="683">Niue (+683)</option>
                    <option value="672">Norfolk Islands (+672)</option>
                    <option value="670">Northern Marianas (+670)</option>
                    <option value="47">Norway (+47)</option>
                    <option value="968">Oman (+968)</option>
                    <option value="680">Palau (+680)</option>
                    <option value="507">Panama (+507)</option>
                    <option value="675">Papua New Guinea (+675)</option>
                    <option value="595">Paraguay (+595)</option>
                    <option value="51">Peru (+51)</option>
                    <option value="63">Philippines (+63)</option>
                    <option value="48">Poland (+48)</option>
                    <option value="351">Portugal (+351)</option>
                    <option value="1787">Puerto Rico (+1787)</option>
                    <option value="974">Qatar (+974)</option>
                    <option value="262">Reunion (+262)</option>
                    <option value="40">Romania (+40)</option>
                    <option value="7">Russia (+7)</option>
                    <option value="250">Rwanda (+250)</option>
                    <option value="378">San Marino (+378)</option>
                    <option value="239">Sao Tome &amp; Principe (+239)</option>
                    <option value="966">Saudi Arabia (+966)</option>
                    <option value="221">Senegal (+221)</option>
                    <option value="381">Serbia (+381)</option>
                    <option value="248">Seychelles (+248)</option>
                    <option value="232">Sierra Leone (+232)</option>
                    <option value="421">Slovak Republic (+421)</option>
                    <option value="386">Slovenia (+386)</option>
                    <option value="677">Solomon Islands (+677)</option>
                    <option value="252">Somalia (+252)</option>
                    <option value="27">South Africa (+27)</option>
                    <option value="34">Spain (+34)</option>
                    <option value="94">Sri Lanka (+94)</option>
                    <option value="290">St. Helena (+290)</option>
                    <option value="1869">St. Kitts (+1869)</option>
                    <option value="1758">St. Lucia (+1758)</option>
                    <option value="249">Sudan (+249)</option>
                    <option value="597">Suriname (+597)</option>
                    <option value="268">Swaziland (+268)</option>
                    <option value="46">Sweden (+46)</option>
                    <option value="41">Switzerland (+41)</option>
                    <option value="963">Syria (+963)</option>
                    <option value="886">Taiwan (+886)</option>
                    <option value="7">Tajikstan (+7)</option>
                    <option value="66">Thailand (+66)</option>
                    <option value="228">Togo (+228)</option>
                    <option value="676">Tonga (+676)</option>
                    <option value="1868">Trinidad &amp; Tobago (+1868)</option>
                    <option value="216">Tunisia (+216)</option>
                    <option value="90">Turkey (+90)</option>
                    <option value="7">Turkmenistan (+7)</option>
                    <option value="993">Turkmenistan (+993)</option>
                    <option value="1649">Turks &amp; Caicos Islands (+1649)</option>
                    <option value="688">Tuvalu (+688)</option>
                    <option value="256">Uganda (+256)</option>
                    <option value="598">Uruguay (+598)</option>
                    <option value="7">Uzbekistan (+7)</option>
                    <option value="678">Vanuatu (+678)</option>
                    <option value="379">Vatican City (+379)</option>
                    <option value="58">Venezuela (+58)</option>
                    <option value="84">Vietnam (+84)</option>
                    <option value="84">Virgin Islands - British (+1284)</option>
                    <option value="84">Virgin Islands - US (+1340)</option>
                    <option value="681">Wallis &amp; Futuna (+681)</option>
                    <option value="969">Yemen (North)(+969)</option>
                    <option value="967">Yemen (South)(+967)</option>
                    <option value="260">Zambia (+260)</option>
                    <option value="263">Zimbabwe (+263)</option>
                  </optgroup>
                </select>
              </div>

              <div class="form-group  col-md-4">
                <label for="mobile">Mobile:</label>
                <input type="hidden" id="lead_ref" value="<?php echo $mobile != '' ? htmlspecialchars(pqLeadRef($mobile), ENT_QUOTES) : ''; ?>">
                <input type="text" inputmode="numeric" name="mobile" class="form-control" placeholder="Enter Mobile" id="mobile" <?php if ($mobile != '') echo 'disabled'; ?> value="<?php if ($mobile != '') echo htmlspecialchars(pqContact($data_result[0]['mobile'] ?? '', 'mobile'), ENT_QUOTES); ?>">
              </div>

              <div class="form-group  col-md-4">
                <label for="email">Email Id:</label>
                <input type="email" class="form-control" name="email" placeholder="Enter Email" id="email" data-initial="<?php if ($mobile != '') echo htmlspecialchars(pqContact($data_result[0]['email'] ?? '', 'email'), ENT_QUOTES); ?>" value="<?php if ($mobile != '') echo htmlspecialchars(pqContact($data_result[0]['email'] ?? '', 'email'), ENT_QUOTES); ?>">
              </div>

              <div class="form-group  col-md-4">
                <label for="campaignsource">Campaign Source:</label>
                <input type="text" class="form-control" name="campaignsource" placeholder="Enter Campaign Source" id="campaignsource" value="<?php if ($mobile != '') echo htmlspecialchars((string) ($data_result[0]['campaignsource'] ?? ''), ENT_QUOTES); ?>">
              </div>

              <div class="form-group  col-md-4">
                <label for="campaignsubsource">Campaign Sub Source:</label>
                <input type="text" class="form-control" name="campaignsubsource" placeholder="Enter Campaign Sub Source" id="campaignsubsource" value="<?php if ($mobile != '') echo htmlspecialchars((string) ($data_result[0]['campaignsubsource'] ?? ''), ENT_QUOTES); ?>">
              </div>

              <div class="form-group  col-md-4">
                <label for="bhktype">BHK Type:</label>
                <input type="text" name="bhktype" class="form-control" placeholder="Enter bhk Type" id="bhktype" value="<?php if ($mobile != '') echo htmlspecialchars((string) ($data_result[0]['bhktype'] ?? ''), ENT_QUOTES); ?>">
              </div>

              <div class="form-group  col-md-4">
                <label for="purpose">Purpose:</label>
                <input type="text" name="purpose" class="form-control" placeholder="Enter Purpose" id="purpose" value="<?php if ($mobile != '') echo htmlspecialchars((string) ($data_result[0]['purpose'] ?? ''), ENT_QUOTES); ?>">
              </div>

              <div class="form-group  col-md-4">
                <label for="visitpossibleon">Visit Possible On:</label>
                <input type="text" name="visitpossibleon" class="form-control" placeholder="Enter Visit Possible On" id="visitpossibleon" value="<?php if ($mobile != '') echo htmlspecialchars((string) ($data_result[0]['visitpossibleon'] ?? ''), ENT_QUOTES); ?>">
              </div>

              <div class="form-group  col-md-4">
                <label for="favdestination">Fav Destination:</label>
                <input type="text" name="favdestination" class="form-control" placeholder="Enter Fav Destination" id="favdestination" value="<?php if ($mobile != '') echo htmlspecialchars((string) ($data_result[0]['favdestination'] ?? ''), ENT_QUOTES); ?>">
              </div>

              <div class="form-group  col-md-4">
                <label for="villatype">Villa Type:</label>
                <input type="text" name="villatype" class="form-control" placeholder="Enter Villa Type" id="villatype" value="<?php if ($mobile != '') echo htmlspecialchars((string) ($data_result[0]['villatype'] ?? ''), ENT_QUOTES); ?>">
              </div>


              <div class="form-group  col-md-4">
                <label for="projinterest">Project Interest:</label>
                <input type="text" name="projinterest" class="form-control" placeholder="Enter Project Interest" id="projinterest" value="<?php if ($mobile != '') echo htmlspecialchars((string) ($data_result[0]['projinterest'] ?? ''), ENT_QUOTES); ?>">
              </div>
              <!-- 

            <div class="form-group  col-md-4">
              <label for="pwd">Mobile:</label>
              <input type="text" name="campaignsource" class="form-control" placeholder="Enter text" id="pwd">
            </div> -->

            </div>
          </form>
          <div class="col-md-12 row">
            <div class="form-group col-md-3">
              <button class="btn btn-primary form-control" id="add" style="color: white;background: #424240;float:right;">Add</button>
            </div>
            <div class="form-group col-md-3">
              <button class="btn btn-primary form-control" id="reset" style="color: white;background: #424240;float:right;">Reset</button>
            </div>
          </div>
        </div>
        <footer class="footer" style="position: absolute; bottom: 0; width: -webkit-fill-available;">
          <div class="container-fluid">
            <div class="row">
              <nav class="footer-nav">
                <ul>
                  <!-- <li><a href="https://www.creative-tim.com" target="_blank">Creative Tim</a></li>
                <li><a href="https://www.creative-tim.com/blog" target="_blank">Blog</a></li>
                <li><a href="https://www.creative-tim.com/license" target="_blank">Licenses</a></li> -->
                </ul>
              </nav>
              <div class="credits ml-auto">
                <!-- <span class="copyright">
                © 2017, made with <i class="fa fa-heart heart"></i> by Webzaa
              </span> -->
              </div>
            </div>
          </div>
        </footer>
      </div>
    </div>

    <!--   Core JS Files   -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/css/bootstrap-datepicker.css" integrity="sha512-Fppbdpv9QhevzDE+UHmdxL4HoW8HantO+rC8oQB2hCofV+dWV2hePnP5SgiWR1Y1vbJeYONZfzQc5iII6sID2Q==" crossorigin="anonymous" referrerpolicy="no-referrer" />

    <script src="../assets/js/core/jquery.min.js"></script>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://code.jquery.com/ui/1.13.2/jquery-ui.min.js"></script>
    <script type="text/javascript" src="https://cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>
    <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js"></script>
    <script src="../assets/js/highcharts/highcharts.js"></script>
    <script src="../assets/js/highcharts/data.js"></script>
    <script src="../assets/js/highcharts/drilldown.js"></script>
    <script src="../assets/js/highcharts/exporting.js"></script>
    <script src="../assets/js/highcharts/export-data.js"></script>
    <script src="../assets/js/highcharts/accessibility.js"></script>
    <script src="https://code.iconify.design/3/3.1.1/iconify.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/js/bootstrap-datepicker.min.js" integrity="sha512-T/tUfKSV1bihCnd+MxKD0Hm1uBBroVYBOYSk1knyvQ9VyZJpc/ALb4P0r6ubwVPSGB2GvjeoMAJJImBG12TiaQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="https://cdn.datatables.net/v/dt/dt-1.10.20/datatables.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.6.1/js/dataTables.buttons.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.6.1/js/buttons.flash.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.6.1/js/buttons.html5.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.6.1/js/buttons.print.min.js"></script>
    <script src="https://cdn.datatables.net/fixedcolumns/3.3.0/js/dataTables.fixedColumns.min.js"></script>
    <script src="https://cdn.datatables.net/colreorder/1.5.2/js/dataTables.colReorder.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/paginationjs/2.1.5/pagination.min.js" integrity="sha512-1zzZ0ynR2KXnFskJ1C2s+7TIEewmkB2y+5o/+ahF7mwNj9n3PnzARpqalvtjSbUETwx6yuxP5AJXZCpnjEJkQw==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="../assets/js/core/popper.min.js"></script>
    <script src="../assets/js/core/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.perfect-scrollbar/1.5.5/perfect-scrollbar.min.js" integrity="sha512-X41/A5OSxoi5uqtS6Krhqz8QyyD8E/ZbN7B4IaBSgqPLRbWVuXJXr9UwOujstj71SoVxh5vxgy7kmtd17xrJRw==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <!--  Google Maps Plugin    -->
    <!-- <script src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script> -->
    <!-- Chart JS -->
    <script src="../assets/js/plugins/chartjs.min.js"></script>
    <!--  Notifications Plugin    -->
    <script src="../assets/js/plugins/bootstrap-notify.js"></script>
    <!-- Control Center for Now Ui Dashboard: parallax effects, scripts for the example pages etc -->
    <script src="../assets/js/paper-dashboard.min.js?v=2.0.1" type="text/javascript"></script>
    <script type="text/javascript">
      $(document).on('click', "#add", function() {

        var validation = true;

        if ($("#full_name").val().trim() == '') {
          $("#full_name").addClass('error');
          validation = false;
        }

        if ($("#countrycode").val() == '') {
          $("#countrycode").addClass('error');
          validation = false;
        }

        if ($("#mobile").val().trim() == '') {
          $("#mobile").addClass('error');
          validation = false;
        }

        if ($("#campaignsource").val().trim() == '') {
          $("#campaignsource").addClass('error');
          validation = false;
        }
        var testEmail = /^[A-Z0-9._%+-]+@([A-Z0-9-]+\.)+[A-Z]{2,4}$/i;
        //console.log();
        var emailVal = $("#email").val().trim();
        var emailMasked = emailVal !== '' && emailVal === ($("#email").attr('data-initial') || '') && emailVal.indexOf('*') !== -1;   // unchanged masked email: kept as saved
        if (!emailMasked && !testEmail.test(emailVal) && emailVal != '') {
          validation = false;
          $("#email").addClass('error');
        }




        if (!validation) {
          return false;
        }
        var other_data = $('form').serializeArray();
        $.ajax({
          url: 'insert_lead.php',
          type: 'POST',
          dataType: "json",
          cache: false,
          beforeSend: function() {
            $(this).attr('disabled', true)
          },
          data: {
            from_data: other_data,
            mobile: $('#lead_ref').val() || $('#mobile').val(),   // editing: the lead reference (the field may show a masked number)
            database: <?php echo json_encode($leadDbKey); ?>

          },
          success: function(returnhtml) {
            if (returnhtml.message == 'success') {
              $("#msg").html('<span class="alert alert-success" style="width: 100%;text-align: center;">Record added successfully</span> ');

              setTimeout(function() {
                window.location.href = "../dashboard.php#leads"
              }, 3000);
            } else {
              $("#msg").html('<span class="alert alert-danger" style="width: 100%;text-align: center;">Record not added</span> ');
            }




          }
        })
      })

      $(document).on('click', '#reset', function() {

        $('input').val('');

      })
    </script>
</body>

</html>