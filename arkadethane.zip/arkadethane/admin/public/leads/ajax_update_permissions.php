<?php
session_start();
include dirname(__DIR__, 2) . '/app/Core/db.php';

// Security check
if (!isset($_SESSION["user_logged"]) || $_SESSION["role"] != "superadmin") {
    exit("Unauthorized");
}

$uid = isset($_POST['uid']) ? intval($_POST['uid']) : 0;
$column = isset($_POST['column']) ? $_POST['column'] : '';
$value = isset($_POST['value']) ? $_POST['value'] : 'N';

// Strict validation
$allowed_columns = ['unmask_email', 'unmask_mobile'];

if ($uid > 0 && in_array($column, $allowed_columns) && in_array($value, ['Y', 'N'])) {
    // Prepared statement for security
    $stmt = $conn->prepare("UPDATE users SET $column = ? WHERE uid = ?");
    $stmt->bind_param("si", $value, $uid);

    if ($stmt->execute()) {
        /* ===m=== Activity Log Start ===m=== */
        $admin_uid = $_SESSION['uid'] ?? 0;
        $project   = $_SESSION['project_name'] ?? '';

        $details = json_encode([
            "action" => "permission_change",
            "target_uid" => $uid,
            "permission" => $column,
            "value" => $value
        ]);

        $log = $conn->prepare("INSERT INTO team_activity_logs (uid, project_name, action_type, action_details) VALUES (?, ?, 'click', ?)");
        $log->bind_param("iss", $admin_uid, $project, $details);
        $log->execute();
        /* ===m=== Activity Log End ===m=== */
        echo "success";
    } else {
        echo "error";
    }
    $stmt->close();
} else {
    echo "invalid";
}
