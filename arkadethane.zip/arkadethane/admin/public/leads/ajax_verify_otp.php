<?php
// ini_set('display_errors', 1);
// ini_set('display_startup_errors', 1);
// error_reporting(E_ALL);
session_start();
include dirname(__DIR__, 2) . '/app/Core/db.php';
require_once dirname(__DIR__, 2) . '/app/bootstrap.php';

// ----------------------
// Get inputs safely
// ----------------------

$email = trim($_POST['email'] ?? '');
$otp   = trim($_POST['otp'] ?? '');

// ----------------------
// Validate inputs
// ----------------------

if ($email === '' || $otp === '') {
    echo "Missing fields";
    exit;
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo "Invalid email";
    exit;
}

if (!preg_match('/^[0-9]{6}$/', $otp)) {
    echo "Invalid OTP";
    exit;
}

// ----------------------
// Verify OTP
// ----------------------

$stmt = $conn->prepare("
    SELECT uid, username, role, status, unmask_email, unmask_mobile
    FROM users
    WHERE email = ?
      AND otp = ?
      AND otp_expiry > NOW()
");

$stmt->bind_param("ss", $email, $otp);
$stmt->execute();

$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo "OTP expired or incorrect";
    exit;
}

$user = $result->fetch_assoc();

// ----------------------
// Check user status
// ----------------------

if ($user['status'] !== 'Y') {
    echo "Account blocked";
    exit;
}

// ----------------------
// Set session
// ----------------------

$_SESSION['user']        = $email;
$_SESSION['uid']         = $user['uid'];
$_SESSION['username']   = $user['username'];
$_SESSION['role']       = $user['role'];
$_SESSION['user_logged'] = "Y";
$_SESSION["unmask_email"] = $user['unmask_email'];
$_SESSION["unmask_mobile"] = $user['unmask_mobile'];

// ----------------------
// Clear OTP after login
// ----------------------

$clear = $conn->prepare("
    UPDATE users 
    SET otp = NULL, otp_expiry = NULL, lastlogin = NOW()
    WHERE email = ?
");

$clear->bind_param("s", $email);
$clear->execute();

// ----------------------
// Done
// ----------------------

echo "success";
