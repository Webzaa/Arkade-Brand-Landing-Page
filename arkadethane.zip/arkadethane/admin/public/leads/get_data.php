<?php

declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');

require_once dirname(__DIR__, 2) . '/app/Core/db.php';
require_once dirname(__DIR__, 2) . '/app/Leads/status_filter.php';

/*
|--------------------------------------------------------------------------
| LEAD EXECUTION ANALYTICS
|--------------------------------------------------------------------------
|
| Database mapping:
|   pseudo   -> test_beliciacp -> $conn
|   … one entry per database in LEAD_DATABASES (config/config.php)
|   all      -> every available requested database
|
| Charts:
|   1. Lead Funnel
|   2. Lead Status Distribution
|   3. Daily Lead Trend
|   4. Campaign -> Ad Group -> Ad drilldown
|
| IMPORTANT:
|   - Uses only the supplied `lead` table schema.
|   - Uses lead_status for status.
|   - Uses visitpossibleon for follow-up / visit-date metrics.
|   - Does NOT require map_lead.
|   - Does NOT reference site/site_id/site_domain/cpc.
|
*/

/*
|--------------------------------------------------------------------------
| JSON ERROR
|--------------------------------------------------------------------------
*/

function jsonError(string $message, int $statusCode = 500, array $extra = []): never
{
  http_response_code($statusCode);

  echo json_encode(
    array_merge(
      [
        'success' => false,
        'error' => $message,
      ],
      $extra
    ),
    JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
  );

  exit;
}

/*
|--------------------------------------------------------------------------
| INPUT
|--------------------------------------------------------------------------
*/

$fromDate = trim((string) ($_POST['from_date'] ?? ''));
$campaignSource = trim((string) ($_POST['camp_source'] ?? ''));
$campaignSubsource = trim((string) ($_POST['Campaign_sub_source'] ?? ''));
$keyword = trim((string) ($_POST['keyword'] ?? ''));
$tillDate = (string) ($_POST['till_date'] ?? '');

$database = strtolower(
  trim((string) ($_POST['database'] ?? 'all'))
);

if (!isLeadDbChoice($database)) {
  $database = 'all';
}

/*
|--------------------------------------------------------------------------
| DATABASE CONNECTIONS
|--------------------------------------------------------------------------
|
| For "all", an unavailable database is reported as a warning instead of
| making the entire request fail. This is important because one database
| can be temporarily unavailable while the other remains usable.
|
| For an explicitly selected database, failure is fatal.
|--------------------------------------------------------------------------
*/

$connections = [];
$warnings = [];

$expectedDatabases = leadDbNames();   // key => MySQL database name, from LEAD_DATABASES

$requestedDatabases = $database === 'all' ? leadDbKeys() : [$database];

foreach ($requestedDatabases as $databaseName) {

  $db = leadDb($databaseName);   // null when that database is unreachable

  /*
  |--------------------------------------------------------------------------
  | Connection existence
  |--------------------------------------------------------------------------
  */

  if (!($db instanceof mysqli)) {

    $message =
      leadDbLabel($databaseName) .
      ' database connection is not available.';

    if ($database !== 'all') {
      jsonError(
        $message,
        500,
        ['database' => $databaseName]
      );
    }

    $warnings[] = $message;
    continue;
  }

  /*
  |--------------------------------------------------------------------------
  | Connection status
  |--------------------------------------------------------------------------
  */

  if ($db->connect_errno) {

    $message =
      leadDbLabel($databaseName) .
      ' database connection failed.';

    if ($database !== 'all') {
      jsonError(
        $message,
        500,
        [
          'database' => $databaseName,
          'mysql_error' => $db->connect_error,
        ]
      );
    }

    $warnings[] =
      $message . ' ' . $db->connect_error;

    continue;
  }

  /*
  |--------------------------------------------------------------------------
  | Verify actual database name
  |--------------------------------------------------------------------------
  */

  $verify = $db->query(
    'SELECT DATABASE() AS current_database'
  );

  if ($verify === false) {

    $message =
      'Unable to verify ' .
      $databaseName .
      ' database connection.';

    if ($database !== 'all') {
      jsonError(
        $message,
        500,
        [
          'database' => $databaseName,
          'mysql_error' => $db->error,
        ]
      );
    }

    $warnings[] =
      $message . ' ' . $db->error;

    continue;
  }

  $verifyRow = $verify->fetch_assoc();
  $verify->free();

  $actualDatabase = trim(
    (string) ($verifyRow['current_database'] ?? '')
  );

  $expectedDatabase =
    $expectedDatabases[$databaseName];

  if ($actualDatabase !== $expectedDatabase) {

    $message =
      leadDbLabel($databaseName) .
      ' database mapping is incorrect.';

    if ($database !== 'all') {
      jsonError(
        $message,
        500,
        [
          'database' => $databaseName,
          'expected_database' => $expectedDatabase,
          'actual_database' => $actualDatabase,
        ]
      );
    }

    $warnings[] =
      $message .
      ' Expected: ' .
      $expectedDatabase .
      ', Actual: ' .
      ($actualDatabase !== ''
        ? $actualDatabase
        : 'NULL');

    continue;
  }

  $connections[$databaseName] = $db;
}

/*
|--------------------------------------------------------------------------
| No usable connection
|--------------------------------------------------------------------------
*/

if (empty($connections)) {

  jsonError(
    'No usable campaign database connection is available.',
    500,
    [
      'requested_database' => $database,
      'warnings' => $warnings,
    ]
  );
}

/*
|--------------------------------------------------------------------------
| DATE FILTER
|--------------------------------------------------------------------------
*/

function getDateCondition(
  string $fromDate,
  string $tillDate,
  mysqli $db
): string {

  if ($tillDate === '1') {
    return '1=1';
  }

  /*
  |--------------------------------------------------------------------------
  | Default: last 7 calendar days including today
  |--------------------------------------------------------------------------
  */

  if ($fromDate === '') {
    return "
            createddate >= DATE(NOW() - INTERVAL 6 DAY)
            AND createddate < DATE(NOW() + INTERVAL 1 DAY)
        ";
  }

  /*
  |--------------------------------------------------------------------------
  | Date range: DD/MM/YYYY - DD/MM/YYYY
  |--------------------------------------------------------------------------
  */

  $parts = preg_split(
    '/\s*-\s*/',
    $fromDate
  );

  if (is_array($parts) && count($parts) >= 2) {

    $start = DateTime::createFromFormat(
      '!d/m/Y',
      trim($parts[0])
    );

    $end = DateTime::createFromFormat(
      '!d/m/Y',
      trim($parts[1])
    );

    $startErrors = DateTime::getLastErrors();
    $endErrors = DateTime::getLastErrors();

    $startValid =
      $start instanceof DateTime &&
      (
        $startErrors === false ||
        (
          $startErrors['warning_count'] === 0 &&
          $startErrors['error_count'] === 0
        )
      );

    $endValid =
      $end instanceof DateTime &&
      (
        $endErrors === false ||
        (
          $endErrors['warning_count'] === 0 &&
          $endErrors['error_count'] === 0
        )
      );

    if ($startValid && $endValid) {

      $startDate =
        $start->format('Y-m-d') .
        ' 00:00:00';

      /*
      | Exclusive upper boundary includes the complete end date.
      */

      $end->modify('+1 day');

      $endDate =
        $end->format('Y-m-d') .
        ' 00:00:00';

      return sprintf(
        "createddate >= '%s'
                 AND createddate < '%s'",
        $db->real_escape_string($startDate),
        $db->real_escape_string($endDate)
      );
    }
  }

  /*
  |--------------------------------------------------------------------------
  | Single date
  |--------------------------------------------------------------------------
  */

  $singleDate = DateTime::createFromFormat(
    '!d/m/Y',
    trim($fromDate)
  );

  $singleErrors = DateTime::getLastErrors();

  $singleValid =
    $singleDate instanceof DateTime &&
    (
      $singleErrors === false ||
      (
        $singleErrors['warning_count'] === 0 &&
        $singleErrors['error_count'] === 0
      )
    );

  if ($singleValid) {

    $startDate =
      $singleDate->format('Y-m-d') .
      ' 00:00:00';

    $singleDate->modify('+1 day');

    $endDate =
      $singleDate->format('Y-m-d') .
      ' 00:00:00';

    return sprintf(
      "createddate >= '%s'
             AND createddate < '%s'",
      $db->real_escape_string($startDate),
      $db->real_escape_string($endDate)
    );
  }

  /*
  |--------------------------------------------------------------------------
  | Invalid date input -> last 7 days
  |--------------------------------------------------------------------------
  */

  return "
        createddate >= DATE(NOW() - INTERVAL 6 DAY)
        AND createddate < DATE(NOW() + INTERVAL 1 DAY)
    ";
}

/*
|--------------------------------------------------------------------------
| COMMON WHERE
|--------------------------------------------------------------------------
*/

function buildLeadWhere(
  mysqli $db,
  string $fromDate,
  string $campaignSource,
  string $campaignSubsource,
  string $keyword,
  string $tillDate
): string {

  $conditions = [];

  $conditions[] = getDateCondition(
    $fromDate,
    $tillDate,
    $db
  );

  if ($campaignSource !== '') {

    $safeSource =
      $db->real_escape_string(
        $campaignSource
      );

    $conditions[] =
      "campaignsource = '{$safeSource}'";
  }

    if (($pqStatusSql = pqLeadStatusFilterFromRequest()) !== '') {
        $conditions[] = $pqStatusSql;   // Lead status filter (app/Leads/status_filter.php)
    }

  if ($campaignSubsource !== '') {

    $safeSubsource =
      $db->real_escape_string(
        $campaignSubsource
      );

    $conditions[] =
      "campaignsubsource = '{$safeSubsource}'";
  }

  if ($keyword !== '') {

    $safeKeyword =
      $db->real_escape_string(
        $keyword
      );

    $conditions[] = "
            (
                name LIKE '%{$safeKeyword}%'
                OR email LIKE '%{$safeKeyword}%'
                OR mobile LIKE '%{$safeKeyword}%'
                OR countrycode LIKE '%{$safeKeyword}%'

                OR campaignsource LIKE '%{$safeKeyword}%'
                OR campaignsubsource LIKE '%{$safeKeyword}%'
                OR placement LIKE '%{$safeKeyword}%'
                OR device LIKE '%{$safeKeyword}%'
                OR adcreative LIKE '%{$safeKeyword}%'
                OR adset LIKE '%{$safeKeyword}%'

                OR ip_address LIKE '%{$safeKeyword}%'
                OR mf_medium LIKE '%{$safeKeyword}%'
                OR mf_campaignid LIKE '%{$safeKeyword}%'

                OR bhktype LIKE '%{$safeKeyword}%'
                OR purpose LIKE '%{$safeKeyword}%'
                OR visitpossibleon LIKE '%{$safeKeyword}%'
                OR favdestination LIKE '%{$safeKeyword}%'
                OR villatype LIKE '%{$safeKeyword}%'
                OR projinterest LIKE '%{$safeKeyword}%'

                OR form_id LIKE '%{$safeKeyword}%'
                OR ad_id LIKE '%{$safeKeyword}%'
                OR leadgen_id LIKE '%{$safeKeyword}%'
                OR page_id LIKE '%{$safeKeyword}%'

                OR keyword LIKE '%{$safeKeyword}%'
                OR capturefromname LIKE '%{$safeKeyword}%'
                OR websitename LIKE '%{$safeKeyword}%'

                OR utmM LIKE '%{$safeKeyword}%'
                OR utmC LIKE '%{$safeKeyword}%'

                OR utm_campaignid LIKE '%{$safeKeyword}%'
                OR utm_campaignname LIKE '%{$safeKeyword}%'
                OR utm_adgroupid LIKE '%{$safeKeyword}%'
                OR utm_adgroupname LIKE '%{$safeKeyword}%'
                OR utm_adid LIKE '%{$safeKeyword}%'
                OR utm_adname LIKE '%{$safeKeyword}%'

                OR ad_name LIKE '%{$safeKeyword}%'
                OR adset_name LIKE '%{$safeKeyword}%'
                OR campaign_name LIKE '%{$safeKeyword}%'

                OR whatsapp_number LIKE '%{$safeKeyword}%'
                OR uniqueid LIKE '%{$safeKeyword}%'
                OR gclid LIKE '%{$safeKeyword}%'
                OR lead_status LIKE '%{$safeKeyword}%'
            )
        ";
  }

  return implode(
    ' AND ',
    $conditions
  );
}

/*
|--------------------------------------------------------------------------
| EMPTY ANALYTICS
|--------------------------------------------------------------------------
*/

function emptyAnalytics(): array
{
  return [
    'funnel' => [
      'total' => 0,
      'actioned' => 0,
      'followup' => 0,
      'visit_date' => 0,
    ],

    'statuses' => [],

    'dates' => [],

    'hierarchy' => [],
  ];
}

/*
|--------------------------------------------------------------------------
| ANALYTICS FOR ONE DATABASE
|--------------------------------------------------------------------------
*/

function getLeadAnalytics(
  mysqli $db,
  string $databaseName,
  string $fromDate,
  string $campaignSource,
  string $campaignSubsource,
  string $keyword,
  string $tillDate
): array {

  $data = emptyAnalytics();

  $where = buildLeadWhere(
    $db,
    $fromDate,
    $campaignSource,
    $campaignSubsource,
    $keyword,
    $tillDate
  );

  /*
  |--------------------------------------------------------------------------
  | 1. LEAD FUNNEL
  |--------------------------------------------------------------------------
  |
  | Total Leads:
  |   all matching rows.
  |
  | Actioned:
  |   lead_status is populated.
  |
  | Follow-up Set:
  |   visitpossibleon is populated.
  |
  | Visit Date Captured:
  |   visitpossibleon is populated with a non-zero date value.
  |
  */

  $sql = "
        SELECT
            COUNT(*) AS total,

            SUM(
                CASE
                    WHEN lead_status IS NOT NULL
                     AND TRIM(lead_status) <> ''
                    THEN 1
                    ELSE 0
                END
            ) AS actioned,

            SUM(
                CASE
                    WHEN visitpossibleon IS NOT NULL
                     AND TRIM(visitpossibleon) <> ''
                    THEN 1
                    ELSE 0
                END
            ) AS followup_set,

            SUM(
                CASE
                    WHEN visitpossibleon IS NOT NULL
                     AND TRIM(visitpossibleon) <> ''
                     AND TRIM(visitpossibleon) <> '0000-00-00'
                     AND TRIM(visitpossibleon) <> '0000-00-00 00:00:00'
                    THEN 1
                    ELSE 0
                END
            ) AS visit_date_captured

        FROM `lead`

        WHERE {$where}
    ";

  $result = $db->query($sql);

  if ($result === false) {

    jsonError(
      'Lead funnel query failed.',
      500,
      [
        'database' => $databaseName,
        'mysql_error' => $db->error,
      ]
    );
  }

  $row = $result->fetch_assoc();

  $data['funnel'] = [
    'total' => (int) ($row['total'] ?? 0),
    'actioned' => (int) ($row['actioned'] ?? 0),
    'followup' => (int) ($row['followup_set'] ?? 0),
    'visit_date' => (int) ($row['visit_date_captured'] ?? 0),
  ];

  $result->free();

  /*
  |--------------------------------------------------------------------------
  | 2. LEAD STATUS DISTRIBUTION
  |--------------------------------------------------------------------------
  */

  $sql = "
        SELECT
            CASE
                WHEN lead_status IS NULL
                  OR TRIM(lead_status) = ''
                THEN 'New / Not Actioned'
                ELSE TRIM(lead_status)
            END AS status,

            COUNT(*) AS total

        FROM `lead`

        WHERE {$where}

        GROUP BY status

        ORDER BY total DESC, status ASC
    ";

  $result = $db->query($sql);

  if ($result === false) {

    jsonError(
      'Lead status distribution query failed.',
      500,
      [
        'database' => $databaseName,
        'mysql_error' => $db->error,
      ]
    );
  }

  while ($row = $result->fetch_assoc()) {

    $status = trim(
      (string) ($row['status'] ?? '')
    );

    if ($status === '') {
      $status = 'New / Not Actioned';
    }

    $data['statuses'][$status] =
      ($data['statuses'][$status] ?? 0) +
      (int) ($row['total'] ?? 0);
  }

  $result->free();

  /*
  |--------------------------------------------------------------------------
  | 3. DAILY LEAD TREND
  |--------------------------------------------------------------------------
  */

  $sql = "
        SELECT
            DATE(createddate) AS lead_date,
            COUNT(*) AS total

        FROM `lead`

        WHERE {$where}
          AND createddate IS NOT NULL

        GROUP BY DATE(createddate)

        ORDER BY lead_date ASC
    ";

  $result = $db->query($sql);

  if ($result === false) {

    jsonError(
      'Daily lead trend query failed.',
      500,
      [
        'database' => $databaseName,
        'mysql_error' => $db->error,
      ]
    );
  }

  while ($row = $result->fetch_assoc()) {

    $date = trim(
      (string) ($row['lead_date'] ?? '')
    );

    if ($date === '') {
      continue;
    }

    $data['dates'][$date] =
      ($data['dates'][$date] ?? 0) +
      (int) ($row['total'] ?? 0);
  }

  $result->free();

  /*
  |--------------------------------------------------------------------------
  | 4. CAMPAIGN -> AD GROUP -> AD
  |--------------------------------------------------------------------------
  */

  /*
  |--------------------------------------------------------------------------
  | Use a derived table for the three calculated hierarchy fields.
  |
  | This is intentionally done instead of GROUP BY aliases/CASE expressions
  | directly in the same SELECT. It is compatible with MySQL
  | ONLY_FULL_GROUP_BY.
  |--------------------------------------------------------------------------
  */

  $sql = "
        SELECT
            hierarchy.campaign_name,
            hierarchy.adgroup_name,
            hierarchy.ad_name,
            COUNT(*) AS total

        FROM (
            SELECT

                CASE
                    WHEN utm_campaignname IS NOT NULL
                     AND TRIM(utm_campaignname) <> ''
                    THEN TRIM(utm_campaignname)

                    WHEN campaign_name IS NOT NULL
                     AND TRIM(campaign_name) <> ''
                    THEN TRIM(campaign_name)

                    ELSE 'Unattributed Campaign'
                END AS campaign_name,

                CASE
                    WHEN utm_adgroupname IS NOT NULL
                     AND TRIM(utm_adgroupname) <> ''
                    THEN TRIM(utm_adgroupname)

                    WHEN adset_name IS NOT NULL
                     AND TRIM(adset_name) <> ''
                    THEN TRIM(adset_name)

                    ELSE 'Unattributed Ad Group'
                END AS adgroup_name,

                CASE
                    WHEN utm_adname IS NOT NULL
                     AND TRIM(utm_adname) <> ''
                    THEN TRIM(utm_adname)

                    WHEN ad_name IS NOT NULL
                     AND TRIM(ad_name) <> ''
                    THEN TRIM(ad_name)

                    ELSE 'Unattributed Ad'
                END AS ad_name

            FROM `lead`

            WHERE {$where}
        ) AS hierarchy

        GROUP BY
            hierarchy.campaign_name,
            hierarchy.adgroup_name,
            hierarchy.ad_name

        ORDER BY
            hierarchy.campaign_name ASC,
            hierarchy.adgroup_name ASC,
            total DESC
    ";

  $result = $db->query($sql);

  if ($result === false) {

    jsonError(
      'Campaign drilldown query failed.',
      500,
      [
        'database' => $databaseName,
        'mysql_error' => $db->error,
      ]
    );
  }

  while ($row = $result->fetch_assoc()) {

    $campaign = trim(
      (string) ($row['campaign_name'] ?? '')
    );

    $adgroup = trim(
      (string) ($row['adgroup_name'] ?? '')
    );

    $ad = trim(
      (string) ($row['ad_name'] ?? '')
    );

    $count = (int) (
      $row['total'] ?? 0
    );

    if ($campaign === '') {
      $campaign = 'Unattributed Campaign';
    }

    if ($adgroup === '') {
      $adgroup = 'Unattributed Ad Group';
    }

    if ($ad === '') {
      $ad = 'Unattributed Ad';
    }

    if (!isset($data['hierarchy'][$campaign])) {
      $data['hierarchy'][$campaign] = [];
    }

    if (!isset($data['hierarchy'][$campaign][$adgroup])) {
      $data['hierarchy'][$campaign][$adgroup] = [];
    }

    $data['hierarchy'][$campaign][$adgroup][$ad] =
      ($data['hierarchy'][$campaign][$adgroup][$ad] ?? 0) +
      $count;
  }

  $result->free();

  return $data;
}

/*
|--------------------------------------------------------------------------
| COMBINE AVAILABLE DATABASES
|--------------------------------------------------------------------------
*/

$combined = emptyAnalytics();

$databaseCounts = [];

foreach ($connections as $databaseName => $db) {

  $result = getLeadAnalytics(
    $db,
    $databaseName,
    $fromDate,
    $campaignSource,
    $campaignSubsource,
    $keyword,
    $tillDate
  );

  $databaseCounts[$databaseName] =
    (int) $result['funnel']['total'];

  /*
  |--------------------------------------------------------------------------
  | Funnel
  |--------------------------------------------------------------------------
  */

  foreach ($result['funnel'] as $key => $count) {

    $combined['funnel'][$key] +=
      (int) $count;
  }

  /*
  |--------------------------------------------------------------------------
  | Statuses
  |--------------------------------------------------------------------------
  */

  foreach ($result['statuses'] as $status => $count) {

    $combined['statuses'][$status] =
      ($combined['statuses'][$status] ?? 0) +
      (int) $count;
  }

  /*
  |--------------------------------------------------------------------------
  | Daily trend
  |--------------------------------------------------------------------------
  */

  foreach ($result['dates'] as $date => $count) {

    $combined['dates'][$date] =
      ($combined['dates'][$date] ?? 0) +
      (int) $count;
  }

  /*
  |--------------------------------------------------------------------------
  | Campaign hierarchy
  |--------------------------------------------------------------------------
  */

  foreach ($result['hierarchy'] as $campaign => $adgroups) {

    if (!isset($combined['hierarchy'][$campaign])) {
      $combined['hierarchy'][$campaign] = [];
    }

    foreach ($adgroups as $adgroup => $ads) {

      if (
        !isset(
        $combined['hierarchy'][$campaign][$adgroup]
      )
      ) {
        $combined['hierarchy'][$campaign][$adgroup] = [];
      }

      foreach ($ads as $ad => $count) {

        $combined['hierarchy']
        [$campaign]
        [$adgroup]
        [$ad] =
          (
            $combined['hierarchy']
            [$campaign]
            [$adgroup]
            [$ad] ?? 0
          ) + (int) $count;
      }
    }
  }
}

/*
|--------------------------------------------------------------------------
| SORT
|--------------------------------------------------------------------------
*/

arsort($combined['statuses']);
ksort($combined['dates']);

/*
|--------------------------------------------------------------------------
| LEAD FUNNEL
|--------------------------------------------------------------------------
*/

$leadFunnel = [
  [
    'name' => 'Total Leads',
    'y' => (int) $combined['funnel']['total'],
  ],
  [
    'name' => 'Actioned',
    'y' => (int) $combined['funnel']['actioned'],
  ],
  [
    'name' => 'Follow-up Set',
    'y' => (int) $combined['funnel']['followup'],
  ],
  [
    'name' => 'Visit Date Captured',
    'y' => (int) $combined['funnel']['visit_date'],
  ],
];

/*
|--------------------------------------------------------------------------
| LEAD STATUS DISTRIBUTION
|--------------------------------------------------------------------------
*/

$leadStatusDistribution = [];

foreach ($combined['statuses'] as $status => $count) {

  $leadStatusDistribution[] = [
    'name' => $status,
    'y' => (int) $count,
  ];
}

/*
|--------------------------------------------------------------------------
| DAILY LEAD TREND
|--------------------------------------------------------------------------
*/

$dailyLeadTrend = [];

foreach ($combined['dates'] as $date => $count) {

  $dailyLeadTrend[] = [
    'date' => $date,
    'y' => (int) $count,
  ];
}

/*
|--------------------------------------------------------------------------
| CAMPAIGN -> AD GROUP -> AD DRILLDOWN
|--------------------------------------------------------------------------
*/

$campaignHierarchy = [];
$campaignDrilldown = [];

$campaignIndex = 0;

foreach ($combined['hierarchy'] as $campaign => $adgroups) {

  $campaignId =
    'campaign_' .
    $campaignIndex;

  $campaignTotal = 0;
  $adgroupSeries = [];
  $adgroupIndex = 0;

  foreach ($adgroups as $adgroup => $ads) {

    $adgroupId =
      $campaignId .
      '_adgroup_' .
      $adgroupIndex;

    $adTotal = 0;
    $adData = [];

    foreach ($ads as $ad => $count) {

      $count = (int) $count;

      $adTotal += $count;

      $adData[] = [
        'name' => $ad,
        'y' => $count,
      ];
    }

    $adgroupSeries[] = [
      'name' => $adgroup,
      'y' => $adTotal,
      'drilldown' => $adgroupId,
    ];

    /*
    | Level 3: Ads
    */

    $campaignDrilldown[] = [
      'id' => $adgroupId,
      'name' => $adgroup,
      'data' => $adData,
    ];

    $campaignTotal += $adTotal;
    $adgroupIndex++;
  }

  /*
  | Level 2: Ad Groups
  */

  $campaignDrilldown[] = [
    'id' => $campaignId,
    'name' => $campaign,
    'data' => $adgroupSeries,
  ];

  /*
  | Level 1: Campaign
  */

  $campaignHierarchy[] = [
    'name' => $campaign,
    'y' => $campaignTotal,
    'drilldown' => $campaignId,
  ];

  $campaignIndex++;
}

/*
|--------------------------------------------------------------------------
| RESPONSE
|--------------------------------------------------------------------------
*/

$response = [
  'success' => true,

  'database' => $database,

  'filters' => [
    'from_date' => $fromDate,
    'campaign_source' => $campaignSource,
    'campaign_subsource' => $campaignSubsource,
    'keyword' => $keyword,
    'till_date' => $tillDate,
  ],

  /*
  | Tells the frontend exactly which databases were used.
  */

  'available_databases' => array_keys($connections),

  'database_counts' => $databaseCounts,

  /*
  | If ALL was selected and one DB was unavailable, the other DB still
  | returns data and this array explains what was skipped.
  */

  'warnings' => $warnings,

  'leadFunnel' => $leadFunnel,

  'leadStatusDistribution' =>
    $leadStatusDistribution,

  'dailyLeadTrend' =>
    $dailyLeadTrend,

  'campaignHierarchy' =>
    $campaignHierarchy,

  'campaignDrilldown' =>
    $campaignDrilldown,

  /*
  |--------------------------------------------------------------------------
  | Compatibility keys
  |--------------------------------------------------------------------------
  */

  'rowsChart6' => [],
  'rowsChartDrilldown6' => [],
  'rowsChart13' => [],
  'rowschart5' => [],
];

echo json_encode(
  $response,
  JSON_UNESCAPED_UNICODE |
  JSON_UNESCAPED_SLASHES
);

exit;
?>