<?php

// ini_set('display_errors', 1);
// ini_set('display_startup_errors', 1);
// error_reporting(E_ALL);
// file_put_contents(__DIR__ . '/debug_log.txt', date('Y-m-d H:i:s') . "\nPOST: " . print_r($_POST, true) . "\nRAW: " . file_get_contents('php://input') . "\n\n", FILE_APPEND);


include dirname(__DIR__, 2) . '/app/Core/db.php';
// require dirname(__DIR__, 2) . '/app/Core/mailer.php';
require_once dirname(__DIR__, 2) . '/app/bootstrap.php';

$email = trim($_POST['email'] ?? '');

// --------------------
// Basic validation
// --------------------
if ($email == '') {
    echo "Email is required";
    exit;
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo "Invalid email format";
    exit;
}

// --------------------
// Check user exists
// --------------------
$stmt = $conn->prepare("SELECT uid,status FROM users WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    echo "Email not registered";
    exit;
}

$user = $result->fetch_assoc();

// Optional: block inactive users
if ($user['status'] == 'N') {
    echo "Account blocked";
    exit;
}

// --------------------
// Generate OTP
// --------------------
$otp = random_int(100000, 999999);
$expiry = date("Y-m-d H:i:s", strtotime("+5 minutes"));

// --------------------
// Save OTP
// --------------------
$update = $conn->prepare(
    "UPDATE users SET otp=?, otp_expiry=? WHERE email=?"
);
$update->bind_param("sss", $otp, $expiry, $email);
$update->execute();

// --------------------
// Send the code: this admin's SMTP with the new template (app/Core/otp_mail.php),
// the old external mailer API as a fallback
// --------------------
require_once dirname(__DIR__, 2) . '/app/Core/otp_mail.php';
echo sendLoginOtpMail($email, (string) $otp) ? "sent" : "Failed to send OTP";
