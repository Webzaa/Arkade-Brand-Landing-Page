<?php

declare(strict_types=1);

include dirname(__DIR__, 2) . '/app/Core/db.php';

header('Content-Type: text/html; charset=UTF-8');

$limit = 50;

/*
|--------------------------------------------------------------------------
| POST Parameters
|--------------------------------------------------------------------------
*/

$from_date              = trim($_POST['from_date'] ?? '');
$camp_source            = trim($_POST['camp_source'] ?? '');
$Campaign_sub_source    = trim($_POST['Campaign_sub_source'] ?? '');
$keyword                = trim($_POST['keyword'] ?? '');
$till_date              = trim($_POST['till_date'] ?? '');
$database               = strtolower(trim($_POST['database'] ?? 'all'));

/*
|--------------------------------------------------------------------------
| Validate Database Selection
|--------------------------------------------------------------------------
*/

if (!isLeadDbChoice($database)) {
    $database = 'all';
}

/*
|--------------------------------------------------------------------------
| Build WHERE Conditions
|--------------------------------------------------------------------------
*/

$dateCondition = 'DATE_FORMAT(createddate, "%Y-%m-%d") >= DATE(NOW() - INTERVAL 6 DAY)';

$sourceCondition = '1';
$subSourceCondition = '1';
$keywordCondition = '1';

/*
|--------------------------------------------------------------------------
| Date Filter
|--------------------------------------------------------------------------
*/

if ($till_date === '1') {

    $dateCondition = '1';

} elseif ($from_date !== '') {

    $dateParts = explode('-', $from_date);

    if (count($dateParts) >= 2) {

        $FromDate = str_replace('/', '-', trim($dateParts[0]));
        $ToDate   = str_replace('/', '-', trim($dateParts[1]));

        $fromTimestamp = strtotime($FromDate);
        $toTimestamp   = strtotime($ToDate);

        if ($fromTimestamp !== false && $toTimestamp !== false) {

            $fromDateFormatted = date('Y-m-d', $fromTimestamp);
            $toDateFormatted   = date('Y-m-d', $toTimestamp);

            $dateCondition =
                'DATE_FORMAT(createddate, "%Y-%m-%d") >= "' .
                $fromDateFormatted .
                '" AND DATE_FORMAT(createddate, "%Y-%m-%d") <= "' .
                $toDateFormatted .
                '"';
        }
    }
}

/*
|--------------------------------------------------------------------------
| Campaign Source
|--------------------------------------------------------------------------
*/

if ($camp_source !== '') {

    $escapedSource = mysqli_real_escape_string($conn, $camp_source);

    $sourceCondition = 'campaignsource = "' . $escapedSource . '"';
}

/*
|--------------------------------------------------------------------------
| Campaign Sub Source
|--------------------------------------------------------------------------
*/

if ($Campaign_sub_source !== '') {

    $escapedSubSource = mysqli_real_escape_string(
        $conn,
        $Campaign_sub_source
    );

    $subSourceCondition =
        'campaignsubsource = "' . $escapedSubSource . '"';
}

/*
|--------------------------------------------------------------------------
| Keyword Search
|--------------------------------------------------------------------------
*/

if ($keyword !== '') {

    $escapedKeyword = mysqli_real_escape_string($conn, $keyword);

    $keywordCondition =
        '(keyword LIKE "%' . $escapedKeyword . '%"
        OR name LIKE "%' . $escapedKeyword . '%"
        OR email LIKE "%' . $escapedKeyword . '%"
        OR mobile LIKE "%' . $escapedKeyword . '%")';
}

/*
|--------------------------------------------------------------------------
| Final WHERE
|--------------------------------------------------------------------------
*/

$whereCondition =
    $dateCondition .
    ' AND ' .
    $sourceCondition .
    ' AND ' .
    $subSourceCondition .
    ' AND ' .
    $keywordCondition;


/*
|--------------------------------------------------------------------------
| Count Records
|--------------------------------------------------------------------------
*/

$total_records = 0;


/*
| Count in every selected database (LEAD_DATABASES)
*/
foreach (leadDbs($database) as $countDb) {

    $countSql = "
        SELECT COUNT(id) AS total
        FROM `lead`
        WHERE $whereCondition
    ";

    $countResult = mysqli_query($countDb, $countSql);

    if ($countResult) {

        $countRow = mysqli_fetch_assoc($countResult);

        $total_records += (int) ($countRow['total'] ?? 0);
    }
}


/*
|--------------------------------------------------------------------------
| Calculate Pages
|--------------------------------------------------------------------------
*/

$total_pages = $total_records > 0
    ? (int) ceil($total_records / $limit)
    : 0;


/*
|--------------------------------------------------------------------------
| Pagination HTML
|--------------------------------------------------------------------------
*/

?>

<ul class="pagination">

<?php if ($total_pages > 0): ?>

    <?php for ($i = 1; $i <= $total_pages; $i++): ?>

        <li
            class="pageitem <?php echo ($i === 1) ? 'active' : ''; ?>"
            id="<?php echo $i; ?>"
        >

            <a
                href="javascript:void(0);"
                data-id="<?php echo $i; ?>"
                class="page-link"
            >
                <?php echo $i; ?>
            </a>

        </li>

    <?php endfor; ?>

<?php endif; ?>

</ul>