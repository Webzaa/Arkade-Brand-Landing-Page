<?php

declare(strict_types=1);

session_start();

header('Content-Type: application/json; charset=utf-8');

require_once dirname(__DIR__, 2) . '/app/Core/db.php';
require_once dirname(__DIR__, 2) . '/app/Leads/status_filter.php';

/*
|--------------------------------------------------------------------------
| LEADS DATA ENDPOINT
|--------------------------------------------------------------------------
|
| Database mapping:
|   pseudo   -> test_beliciacp -> $conn
|   … one entry per database in LEAD_DATABASES (config/config.php)
|   all      -> every available requested database
|
| The endpoint uses only the confirmed `lead` table schema.
|
*/

/*
|--------------------------------------------------------------------------
| JSON ERROR
|--------------------------------------------------------------------------
*/

function jsonError(
    string $message,
    int $statusCode = 500,
    array $extra = []
): never {
    http_response_code($statusCode);

    echo json_encode(
        array_merge(
            [
                'success' => false,
                'error' => $message,
            ],
            $extra
        ),
        JSON_UNESCAPED_UNICODE |
        JSON_UNESCAPED_SLASHES
    );

    exit;
}

/*
|--------------------------------------------------------------------------
| INPUT
|--------------------------------------------------------------------------
*/

$fromDate = trim(
    (string) ($_POST['from_date'] ?? '')
);

$campaignSource = trim(
    (string) ($_POST['camp_source'] ?? '')
);

$campaignSubsource = trim(
    (string) ($_POST['Campaign_sub_source'] ?? '')
);

$keyword = trim(
    (string) ($_POST['keyword'] ?? '')
);

$tillDate = (string) (
    $_POST['till_date'] ?? ''
);

$database = strtolower(
    trim((string) ($_POST['database'] ?? 'all'))
);

if (
    !isLeadDbChoice($database)
) {
    $database = 'all';
}

/*
|--------------------------------------------------------------------------
| DATABASE CONNECTIONS
|--------------------------------------------------------------------------
|
| Important:
| When `all` is selected, one unavailable database must NOT prevent the
| other available database from returning leads.
|
| When a specific database is selected, that database is required.
|
*/

$connections = [];
$warnings = [];

$expectedDatabases = leadDbNames();   // key => MySQL database name, from LEAD_DATABASES

$requestedDatabases = $database === 'all' ? leadDbKeys() : [$database];

foreach ($requestedDatabases as $databaseName) {

    $db = leadDb($databaseName);   // null when that database is unreachable

    /*
    |--------------------------------------------------------------------------
    | Missing connection
    |--------------------------------------------------------------------------
    */

    if (!($db instanceof mysqli)) {

        $message =
            leadDbLabel($databaseName) .
            ' database connection is not available.';

        if ($database !== 'all') {
            jsonError(
                $message,
                500,
                [
                    'database' => $databaseName,
                ]
            );
        }

        $warnings[] = $message;

        continue;
    }

    /*
    |--------------------------------------------------------------------------
    | Connection error
    |--------------------------------------------------------------------------
    */

    if ($db->connect_errno) {

        $message =
            leadDbLabel($databaseName) .
            ' database connection failed.';

        if ($database !== 'all') {
            jsonError(
                $message,
                500,
                [
                    'database' => $databaseName,
                    'mysql_error' => $db->connect_error,
                ]
            );
        }

        $warnings[] =
            $message . ' ' .
            $db->connect_error;

        continue;
    }

    /*
    |--------------------------------------------------------------------------
    | Verify actual database
    |--------------------------------------------------------------------------
    */

    $verify = $db->query(
        'SELECT DATABASE() AS current_database'
    );

    if ($verify === false) {

        $message =
            'Unable to verify ' .
            $databaseName .
            ' database connection.';

        if ($database !== 'all') {
            jsonError(
                $message,
                500,
                [
                    'database' => $databaseName,
                    'mysql_error' => $db->error,
                ]
            );
        }

        $warnings[] =
            $message . ' ' .
            $db->error;

        continue;
    }

    $verifyRow = $verify->fetch_assoc();
    $verify->free();

    $actualDatabase = trim(
        (string) (
            $verifyRow['current_database'] ?? ''
        )
    );

    $expectedDatabase =
        $expectedDatabases[$databaseName];

    if ($actualDatabase !== $expectedDatabase) {

        $message =
            leadDbLabel($databaseName) .
            ' database mapping is incorrect.';

        if ($database !== 'all') {
            jsonError(
                $message,
                500,
                [
                    'database' => $databaseName,
                    'expected_database' =>
                        $expectedDatabase,
                    'actual_database' =>
                        $actualDatabase,
                ]
            );
        }

        $warnings[] =
            $message .
            ' Expected: ' .
            $expectedDatabase .
            ', Actual: ' .
            (
                $actualDatabase !== ''
                ? $actualDatabase
                : 'NULL'
            );

        continue;
    }

    $connections[$databaseName] = $db;
}

/*
|--------------------------------------------------------------------------
| NO USABLE DATABASE
|--------------------------------------------------------------------------
*/

if (empty($connections)) {

    jsonError(
        'No usable campaign database connection is available.',
        500,
        [
            'requested_database' => $database,
            'warnings' => $warnings,
        ]
    );
}

/*
|--------------------------------------------------------------------------
| PERMISSIONS
|--------------------------------------------------------------------------
*/

$allowEmail = (
    isset($_SESSION['unmask_email']) &&
    $_SESSION['unmask_email'] === 'Y'
) ? 'Y' : 'N';

$allowMobile = (
    isset($_SESSION['unmask_mobile']) &&
    $_SESSION['unmask_mobile'] === 'Y'
) ? 'Y' : 'N';

/*
|--------------------------------------------------------------------------
| DATE CONDITION
|--------------------------------------------------------------------------
*/

function buildLeadDateCondition(
    mysqli $db,
    string $fromDate,
    string $tillDate
): string {

    /*
    |--------------------------------------------------------------------------
    | ALL DATES
    |--------------------------------------------------------------------------
    */

    if ($tillDate === '1') {
        return '1=1';
    }

    /*
    |--------------------------------------------------------------------------
    | DATE RANGE
    |--------------------------------------------------------------------------
    */

    if ($fromDate !== '') {

        $parts = preg_split(
            '/\s*-\s*/',
            $fromDate
        );

        if (
            is_array($parts) &&
            count($parts) >= 2
        ) {

            $start = DateTime::createFromFormat(
                '!d/m/Y',
                trim($parts[0])
            );

            $end = DateTime::createFromFormat(
                '!d/m/Y',
                trim($parts[1])
            );

            $startErrors =
                DateTime::getLastErrors();

            $endErrors =
                DateTime::getLastErrors();

            $startValid =
                $start instanceof DateTime &&
                (
                    $startErrors === false ||
                    (
                        $startErrors['warning_count'] === 0 &&
                        $startErrors['error_count'] === 0
                    )
                );

            $endValid =
                $end instanceof DateTime &&
                (
                    $endErrors === false ||
                    (
                        $endErrors['warning_count'] === 0 &&
                        $endErrors['error_count'] === 0
                    )
                );

            if ($startValid && $endValid) {

                $startDate =
                    $start->format('Y-m-d') .
                    ' 00:00:00';

                /*
                | End date is exclusive so the complete selected
                | end date is included.
                */

                $end->modify('+1 day');

                $endDate =
                    $end->format('Y-m-d') .
                    ' 00:00:00';

                return sprintf(
                    "createddate >= '%s'
                     AND createddate < '%s'",
                    $db->real_escape_string(
                        $startDate
                    ),
                    $db->real_escape_string(
                        $endDate
                    )
                );
            }
        }

        /*
        |--------------------------------------------------------------------------
        | SINGLE DATE
        |--------------------------------------------------------------------------
        */

        $singleDate =
            DateTime::createFromFormat(
                '!d/m/Y',
                trim($fromDate)
            );

        $singleErrors =
            DateTime::getLastErrors();

        $singleValid =
            $singleDate instanceof DateTime &&
            (
                $singleErrors === false ||
                (
                    $singleErrors['warning_count'] === 0 &&
                    $singleErrors['error_count'] === 0
                )
            );

        if ($singleValid) {

            $startDate =
                $singleDate->format('Y-m-d') .
                ' 00:00:00';

            $singleDate->modify('+1 day');

            $endDate =
                $singleDate->format('Y-m-d') .
                ' 00:00:00';

            return sprintf(
                "createddate >= '%s'
                 AND createddate < '%s'",
                $db->real_escape_string(
                    $startDate
                ),
                $db->real_escape_string(
                    $endDate
                )
            );
        }
    }

    /*
    |--------------------------------------------------------------------------
    | DEFAULT: LAST 7 CALENDAR DAYS
    |--------------------------------------------------------------------------
    */

    return "
        createddate >= DATE(NOW() - INTERVAL 6 DAY)
        AND createddate < DATE(NOW() + INTERVAL 1 DAY)
    ";
}

/*
|--------------------------------------------------------------------------
| WHERE CLAUSE
|--------------------------------------------------------------------------
*/

function buildLeadWhere(
    mysqli $db,
    string $fromDate,
    string $campaignSource,
    string $campaignSubsource,
    string $keyword,
    string $tillDate
): string {

    $conditions = [];

    /*
    |--------------------------------------------------------------------------
    | DATE
    |--------------------------------------------------------------------------
    */

    $conditions[] =
        buildLeadDateCondition(
            $db,
            $fromDate,
            $tillDate
        );

    /*
    |--------------------------------------------------------------------------
    | CAMPAIGN SOURCE
    |--------------------------------------------------------------------------
    */

    if ($campaignSource !== '') {

        $safeSource =
            $db->real_escape_string(
                $campaignSource
            );

        $conditions[] =
            "campaignsource = '{$safeSource}'";
    }

    if (($pqStatusSql = pqLeadStatusFilterFromRequest()) !== '') {
        $conditions[] = $pqStatusSql;   // Lead status filter (app/Leads/status_filter.php)
    }

    /*
    |--------------------------------------------------------------------------
    | CAMPAIGN SUBSOURCE
    |--------------------------------------------------------------------------
    */

    if ($campaignSubsource !== '') {

        $safeSubsource =
            $db->real_escape_string(
                $campaignSubsource
            );

        $conditions[] =
            "campaignsubsource = '{$safeSubsource}'";
    }

    /*
    |--------------------------------------------------------------------------
    | KEYWORD
    |--------------------------------------------------------------------------
    |
    | Only columns confirmed in the supplied schema.
    |
    */

    if ($keyword !== '') {

        $safeKeyword =
            $db->real_escape_string(
                $keyword
            );

        $conditions[] = "
            (
                name LIKE '%{$safeKeyword}%'
                OR email LIKE '%{$safeKeyword}%'
                OR mobile LIKE '%{$safeKeyword}%'
                OR countrycode LIKE '%{$safeKeyword}%'

                OR campaignsource LIKE '%{$safeKeyword}%'
                OR campaignsubsource LIKE '%{$safeKeyword}%'
                OR placement LIKE '%{$safeKeyword}%'
                OR device LIKE '%{$safeKeyword}%'
                OR adcreative LIKE '%{$safeKeyword}%'
                OR adset LIKE '%{$safeKeyword}%'

                OR ip_address LIKE '%{$safeKeyword}%'
                OR mf_medium LIKE '%{$safeKeyword}%'
                OR mf_campaignid LIKE '%{$safeKeyword}%'

                OR bhktype LIKE '%{$safeKeyword}%'
                OR purpose LIKE '%{$safeKeyword}%'
                OR visitpossibleon LIKE '%{$safeKeyword}%'
                OR favdestination LIKE '%{$safeKeyword}%'
                OR villatype LIKE '%{$safeKeyword}%'
                OR projinterest LIKE '%{$safeKeyword}%'

                OR form_id LIKE '%{$safeKeyword}%'
                OR ad_id LIKE '%{$safeKeyword}%'
                OR leadgen_id LIKE '%{$safeKeyword}%'
                OR page_id LIKE '%{$safeKeyword}%'

                OR keyword LIKE '%{$safeKeyword}%'
                OR capturefromname LIKE '%{$safeKeyword}%'
                OR websitename LIKE '%{$safeKeyword}%'

                OR utmM LIKE '%{$safeKeyword}%'
                OR utmC LIKE '%{$safeKeyword}%'

                OR utm_campaignid LIKE '%{$safeKeyword}%'
                OR utm_campaignname LIKE '%{$safeKeyword}%'
                OR utm_adgroupid LIKE '%{$safeKeyword}%'
                OR utm_adgroupname LIKE '%{$safeKeyword}%'
                OR utm_adid LIKE '%{$safeKeyword}%'
                OR utm_adname LIKE '%{$safeKeyword}%'

                OR ad_name LIKE '%{$safeKeyword}%'
                OR adset_name LIKE '%{$safeKeyword}%'
                OR campaign_name LIKE '%{$safeKeyword}%'

                
                
                OR gclid LIKE '%{$safeKeyword}%'
                OR lead_status LIKE '%{$safeKeyword}%'
            )
        ";
    }

    return implode(
        ' AND ',
        $conditions
    );
}

/*
|--------------------------------------------------------------------------
| SELECT COLUMNS
|--------------------------------------------------------------------------
|
| These columns exist in the confirmed lead schema.
| Large payload/meta response fields are excluded from this listing endpoint.
|
*/

$selectColumns = "
    id,
    name,
    email,
    countrycode,
    mobile,

    campaignsource,
    campaignsubsource,
    placement,
    device,
    adcreative,
    adset,

    ip_address,
    mf_medium,
    mf_campaignid,

    bhktype,
    purpose,
    visitpossibleon,
    favdestination,
    villatype,
    projinterest,

    form_id,
    ad_id,
    leadgen_id,
    page_id,

    keyword,
    capturefromname,
    websitename,
    createddate,

    utmM,
    utmC,

    duplicate,
    last_reson,

    ad_name,
    adset_name,
    campaign_name,

   
   
    gclid,

    
    lead_status,

    utm_campaignid,
    utm_campaignname,
    utm_adgroupid,
    utm_adgroupname,
    utm_adid,
    utm_adname,

    curlresponse
";

/*
|--------------------------------------------------------------------------
| FETCH ONE DATABASE
|--------------------------------------------------------------------------
*/

function fetchLeads(
    mysqli $db,
    string $databaseName,
    string $fromDate,
    string $campaignSource,
    string $campaignSubsource,
    string $keyword,
    string $tillDate,
    string $selectColumns,
    string $allowEmail,
    string $allowMobile
): array {

    $where =
        buildLeadWhere(
            $db,
            $fromDate,
            $campaignSource,
            $campaignSubsource,
            $keyword,
            $tillDate
        );

    $sql = "
        SELECT
            {$selectColumns}
        FROM `lead`
        WHERE {$where}
        ORDER BY
            createddate DESC,
            id DESC
    ";

    $result = $db->query($sql);

    if ($result === false) {

        jsonError(
            'Lead query failed.',
            500,
            [
                'database' => $databaseName,
                'mysql_error' => $db->error,
            ]
        );
    }

    $rows = [];

    while ($row = $result->fetch_assoc()) {

        /*
        |--------------------------------------------------------------------------
        | DATABASE SOURCE
        |--------------------------------------------------------------------------
        */

        $row['_database'] =
            $databaseName;

        $row['database_label'] =
            leadDbLabel($databaseName);

        /*
        |--------------------------------------------------------------------------
        | FRONTEND PERMISSIONS
        |--------------------------------------------------------------------------
        */

        $row['allow_email'] =
            $allowEmail;

        $row['allow_mobile'] =
            $allowMobile;

        /*
        |--------------------------------------------------------------------------
        | Existing frontend compatibility
        |--------------------------------------------------------------------------
        */

        $row['reason'] =
            trim(
                (string) (
                    $row['last_reson'] ?? ''
                )
            );

        $rows[] = $row;
    }

    $result->free();

    return $rows;
}

/*
|--------------------------------------------------------------------------
| FETCH SELECTED DATABASES
|--------------------------------------------------------------------------
*/

$allRows = [];

$databaseCounts = [];

foreach ($connections as $databaseName => $db) {

    $rows =
        fetchLeads(
            $db,
            $databaseName,
            $fromDate,
            $campaignSource,
            $campaignSubsource,
            $keyword,
            $tillDate,
            $selectColumns,
            $allowEmail,
            $allowMobile
        );

    $databaseCounts[$databaseName] =
        count($rows);

    $allRows = array_merge(
        $allRows,
        $rows
    );
}

/*
|--------------------------------------------------------------------------
| GLOBAL SORT
|--------------------------------------------------------------------------
*/

usort(
    $allRows,
    static function (array $a, array $b): int {

        $dateA =
            strtotime(
                (string) (
                    $a['createddate'] ?? ''
                )
            );

        $dateB =
            strtotime(
                (string) (
                    $b['createddate'] ?? ''
                )
            );

        if ($dateA === $dateB) {

            return
                (
                    (int) (
                        $b['id'] ?? 0
                    )
                )
                <=>
                (
                    (int) (
                        $a['id'] ?? 0
                    )
                );
        }

        return $dateB <=> $dateA;
    }
);

/*
|--------------------------------------------------------------------------
| RESPONSE
|--------------------------------------------------------------------------
|
| Existing frontend expects an array, so successful responses remain a
| plain JSON array. Diagnostics are available through PHP error logs only
| for compatibility with the existing DataTables implementation.
|
*/

// full / masked email + mobile decided here (Users & Roles), never in the browser; `ref` is the row key
$allRows = pqLeadRowsForBrowser($allRows);

echo json_encode(
    $allRows,
    JSON_UNESCAPED_UNICODE |
    JSON_UNESCAPED_SLASHES
);

exit;
?>