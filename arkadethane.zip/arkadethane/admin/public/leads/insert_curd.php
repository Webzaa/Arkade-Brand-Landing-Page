<?php
include dirname(__DIR__, 2) . '/app/Core/db.php';
header('Content-Type: application/json; charset=utf-8');

// Add Response on the Leads list. `id` is the lead reference (or a plain mobile); `database` the lead's database.
$mobile = pqLeadMobile($_POST['id'] ?? '');
$result = trim((string) ($_POST['result'] ?? ''));
$comment = (string) ($_POST['comment'] ?? '');
$fd = trim((string) ($_POST['followup_date'] ?? ''));
$followup_date = ($fd !== '' && strtotime($fd)) ? date('Y-m-d H:i:s', strtotime($fd)) : '';

if ($mobile === '' || $result === '') {
  echo json_encode(['message' => 'failure', 'error' => 'Lead or reason missing.']);
  exit;
}

$dbKey = (string) ($_POST['database'] ?? '');
$leadConn = ($dbKey !== '' && $dbKey !== 'all' && isLeadDbChoice($dbKey)) ? (leadDb($dbKey) ?? $conn) : $conn;

$data_result = ['message' => 'failure', 'error' => 'Could not save the response.'];
try {
  $st = $conn->prepare('INSERT INTO map_lead (mobile, reason, comment, followup_date) VALUES (?, ?, ?, ?)');
  if ($st && $st->bind_param('ssss', $mobile, $result, $comment, $followup_date) && $st->execute()) {
    $st->close();
    $up = $leadConn->prepare('UPDATE `lead` SET last_reson = ? WHERE mobile = ?');
    if ($up && $up->bind_param('ss', $result, $mobile) && $up->execute()) {
      $data_result = ['message' => 'success'];
    } else {
      $data_result = ['message' => 'failure', 'error' => $leadConn->error];
    }
  } else {
    $data_result = ['message' => 'failure', 'error' => $conn->error];
  }
} catch (Throwable $e) {
  error_log('[insert_curd] ' . $e->getMessage());
}

echo json_encode($data_result);
