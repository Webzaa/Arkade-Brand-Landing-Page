<?php
include dirname(__DIR__, 2) . '/app/Core/db.php';
header('Content-Type: application/json; charset=utf-8');

// Today's follow-ups. Email / mobile are masked here by the user's on-screen switches; `ref` is the row key.
$data_result = [];
$result = $conn->query("SELECT ml.*, l.* FROM map_lead ml LEFT JOIN `lead` l ON ml.mobile = l.mobile WHERE DATE(followup_date) = CURDATE() ORDER BY createddt ASC");
if ($result) {
  while ($row = $result->fetch_assoc()) {
    if (($row['mobile'] ?? null) === null) {
      $row['mobile'] = '';   // map_lead row whose lead is not in this database
    }
    $data_result[] = $row;
  }
}

echo json_encode(pqLeadRowsForBrowser($data_result), JSON_UNESCAPED_UNICODE);
