<?php
/**
 * users.php — Users & Roles (Super Admin only; checked in app/Core/access.php).
 *   Users tab: add / edit / block / delete users, email & mobile unmasking, role per user.
 *   Roles tab: create roles and choose what each one may open and do (permissions per module).
 * Backend: users_api.php · permission engine: app/Core/access.php
 */
session_start();
require_once dirname(__DIR__, 2) . '/app/Core/db.php';
if (($_SESSION['role'] ?? '') !== 'superadmin') {
    header('Location: ../dashboard.php');
    exit;
}
$project = defined('PROJECT_NAME') ? (string) PROJECT_NAME : '';
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Users &amp; Roles</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Sora:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
<script>
(function () {
    var root = document.documentElement, t = null;
    try { t = localStorage.getItem('performiq-theme'); } catch (e) {}
    root.setAttribute('data-theme', t === 'light' ? 'light' : 'dark');
    if (/[?&]embed=1(&|$)/.test(location.search)) root.classList.add('pq-embed');
    window.addEventListener('storage', function (e) { if (e.key === 'performiq-theme') root.setAttribute('data-theme', e.newValue === 'light' ? 'light' : 'dark'); });
    window.setTheme = function (t) { root.setAttribute('data-theme', t === 'light' ? 'light' : 'dark'); };
})();
</script>
<style>
    :root, html[data-theme="dark"] {
        --bg: #0B0F1A; --surface: #111827; --surface-2: #161D2E; --border: #1E2A42; --border-strong: #2A3957;
        --text: #E2E8F0; --text-dim: #94A3B8; --text-faint: #64748B; --accent: #E8A820; --accent-soft: #E8A8201F; --on-accent: #111;
        --hover: #1A2337; --good: #10B981; --good-soft: #10B9811F; --bad: #EF4444; --bad-soft: #EF44441A;
        --warn: #F59E0B; --warn-soft: #F59E0B1A; --info: #3B82F6; --info-soft: #3B82F61A; --shadow: 0 24px 60px rgba(0,0,0,.45); color-scheme: dark;
    }
    html[data-theme="light"] {
        --bg: #F4F6FA; --surface: #FFFFFF; --surface-2: #F8FAFC; --border: #E2E8F0; --border-strong: #CBD5E1;
        --text: #0F172A; --text-dim: #475569; --text-faint: #94A3B8; --accent: #B7791F; --accent-soft: #B7791F1A; --on-accent: #fff;
        --hover: #F1F5F9; --good: #059669; --good-soft: #0596691A; --bad: #DC2626; --bad-soft: #DC26261A;
        --warn: #B45309; --warn-soft: #B453091A; --info: #2563EB; --info-soft: #2563EB1A; --shadow: 0 24px 60px rgba(15,23,42,.18); color-scheme: light;
    }
    * { box-sizing: border-box; }
    body { margin: 0; background: var(--bg); color: var(--text); font: 14px/1.5 'Sora', system-ui, -apple-system, 'Segoe UI', sans-serif; }
    button, input, select, textarea { font: inherit; color: inherit; }
    .mono { font-family: 'JetBrains Mono', ui-monospace, monospace; font-variant-numeric: tabular-nums; }
    .wrap { max-width: 1240px; margin: 0 auto; padding: 26px 24px 70px; }
    .page-head h1 { font-size: 22px; margin: 0 0 4px; } .page-head p { color: var(--text-dim); margin: 0 0 20px; font-size: 13px; }
    .pq-embed .page-head { display: none; }
    .muted { color: var(--text-dim); } .faint { color: var(--text-faint); }
    .hidden { display: none !important; }

    /* tabs + toolbar */
    .topline { display: flex; justify-content: space-between; align-items: center; gap: 12px; flex-wrap: wrap; margin-bottom: 16px; }
    .tabs { display: inline-flex; background: var(--surface); border: 1px solid var(--border); border-radius: 11px; padding: 4px; gap: 4px; }
    .tab { border: 0; background: transparent; padding: 8px 14px; border-radius: 8px; cursor: pointer; color: var(--text-dim); font-weight: 600; font-size: 13px; display: inline-flex; gap: 8px; align-items: center; }
    .tab:hover { color: var(--text); }
    .tab.on { background: var(--accent-soft); color: var(--text); }
    .tab .n { font-size: 11px; padding: 1px 7px; border-radius: 999px; background: var(--surface-2); border: 1px solid var(--border); color: var(--text-dim); }
    .btn { border: 1px solid var(--border-strong); background: var(--surface-2); padding: 9px 15px; border-radius: 9px; cursor: pointer; font-weight: 600; font-size: 13px; display: inline-flex; align-items: center; gap: 7px; white-space: nowrap; }
    .btn:hover { background: var(--hover); }
    .btn.primary { background: var(--accent); border-color: var(--accent); color: var(--on-accent); }
    .btn.primary:hover { filter: brightness(1.07); }
    .btn.danger { background: var(--bad); border-color: var(--bad); color: #fff; }
    .btn.ghost-danger { color: var(--bad); }
    .btn.ghost-danger:hover { background: var(--bad-soft); }
    .btn:disabled { opacity: .5; cursor: not-allowed; }
    .btn.sm { padding: 6px 10px; font-size: 12px; border-radius: 8px; }
    .icon-btn { width: 32px; height: 32px; border-radius: 8px; border: 1px solid transparent; background: transparent; cursor: pointer; display: inline-grid; place-items: center; color: var(--text-dim); }
    .icon-btn:hover { background: var(--hover); color: var(--text); border-color: var(--border); }
    .icon-btn.del:hover { color: var(--bad); background: var(--bad-soft); border-color: transparent; }
    .icon-btn:disabled { opacity: .35; cursor: not-allowed; }
    svg.i { width: 16px; height: 16px; stroke: currentColor; fill: none; stroke-width: 1.8; stroke-linecap: round; stroke-linejoin: round; }

    .note { padding: 11px 14px; border-radius: 10px; font-size: 12.5px; margin-bottom: 14px; border: 1px solid; }
    .note.warn { background: var(--warn-soft); border-color: var(--warn); } .note.bad { background: var(--bad-soft); border-color: var(--bad); }
    .note.good { background: var(--good-soft); border-color: var(--good); }
    .note code { font-family: 'JetBrains Mono', monospace; font-size: 11.5px; background: var(--surface-2); padding: 2px 6px; border-radius: 5px; }

    .stats { display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); gap: 12px; margin-bottom: 16px; }
    .stat { background: var(--surface); border: 1px solid var(--border); border-radius: 12px; padding: 14px 16px; }
    .stat small { color: var(--text-dim); font-size: 12px; display: block; } .stat b { font-size: 22px; font-weight: 700; }
    .card { background: var(--surface); border: 1px solid var(--border); border-radius: 14px; }
    .filters { display: flex; gap: 10px; align-items: center; flex-wrap: wrap; padding: 14px 16px; border-bottom: 1px solid var(--border); }
    .search { position: relative; flex: 1 1 260px; max-width: 360px; }
    .search svg { position: absolute; left: 11px; top: 50%; transform: translateY(-50%); color: var(--text-faint); }
    input[type=text], input[type=email], select, textarea { background: var(--surface-2); border: 1px solid var(--border-strong); border-radius: 9px; padding: 9px 11px; outline: none; width: 100%; }
    input:focus, select:focus, textarea:focus { border-color: var(--accent); box-shadow: 0 0 0 3px var(--accent-soft); }
    .search input { padding-left: 34px; }
    .filters select { width: auto; min-width: 150px; }

    table { width: 100%; border-collapse: collapse; }
    th { text-align: left; font-size: 11px; text-transform: uppercase; letter-spacing: .06em; color: var(--text-faint); font-weight: 600; padding: 11px 14px; border-bottom: 1px solid var(--border); white-space: nowrap; }
    td { padding: 11px 14px; border-bottom: 1px solid var(--border); vertical-align: middle; }
    tr:last-child td { border-bottom: 0; }
    tbody tr:hover td { background: var(--hover); }
    th.c, td.c { text-align: center; }
    .tbl-wrap { overflow-x: auto; }
    .who { display: flex; align-items: center; gap: 11px; min-width: 230px; }
    .av { width: 36px; height: 36px; border-radius: 10px; display: grid; place-items: center; font-weight: 700; font-size: 13px; flex: none; color: #fff; }
    .who b { display: block; font-weight: 600; } .who span { color: var(--text-dim); font-size: 12.5px; }
    .you { font-size: 10.5px; font-weight: 700; padding: 1px 7px; border-radius: 999px; background: var(--info-soft); color: var(--info); margin-left: 6px; vertical-align: 1px; }
    .pill { display: inline-flex; align-items: center; gap: 6px; padding: 3px 10px; border-radius: 999px; font-size: 12px; font-weight: 600; background: var(--surface-2); border: 1px solid var(--border); white-space: nowrap; }
    .pill i { width: 7px; height: 7px; border-radius: 50%; }
    .pill.super { background: var(--accent-soft); border-color: transparent; color: var(--accent); }

    /* switch */
    .sw { position: relative; display: inline-block; width: 38px; height: 22px; flex: none; }
    .sw input { opacity: 0; width: 0; height: 0; position: absolute; }
    .sw span { position: absolute; inset: 0; border-radius: 999px; background: var(--border-strong); transition: background .15s; cursor: pointer; }
    .sw span::after { content: ''; position: absolute; width: 16px; height: 16px; left: 3px; top: 3px; border-radius: 50%; background: #fff; transition: transform .15s; box-shadow: 0 1px 3px rgba(0,0,0,.3); }
    .sw input:checked + span { background: var(--good); }
    .sw input:checked + span::after { transform: translateX(16px); }
    .sw input:disabled + span { opacity: .45; cursor: not-allowed; }
    .sw.accent input:checked + span { background: var(--accent); }
    .stxt { font-size: 12px; color: var(--text-dim); margin-left: 8px; }
    .empty { padding: 40px 16px; text-align: center; color: var(--text-dim); }

    /* roles */
    .roles { display: grid; grid-template-columns: 300px minmax(0, 1fr); gap: 16px; align-items: start; }
    .role-list { display: flex; flex-direction: column; gap: 8px; }
    .role-item { text-align: left; border: 1px solid var(--border); background: var(--surface); border-radius: 12px; padding: 13px 14px; cursor: pointer; width: 100%; }
    .role-item:hover { border-color: var(--border-strong); }
    .role-item.on { border-color: var(--accent); background: linear-gradient(0deg, var(--accent-soft), var(--accent-soft)), var(--surface); }
    .role-item .t { display: flex; justify-content: space-between; align-items: center; gap: 8px; font-weight: 600; }
    .role-item p { margin: 3px 0 0; color: var(--text-dim); font-size: 12px; line-height: 1.45; }
    .tag { font-size: 10.5px; font-weight: 600; color: var(--text-faint); border: 1px solid var(--border); border-radius: 999px; padding: 1px 7px; white-space: nowrap; }
    .role-ed { padding: 20px; }
    .role-ed h2 { margin: 0 0 2px; font-size: 17px; }
    .grid2 { display: grid; grid-template-columns: 1fr 1.6fr; gap: 12px; margin: 16px 0 18px; }
    label.f { display: flex; flex-direction: column; gap: 6px; font-size: 12px; color: var(--text-dim); font-weight: 500; }
    .presets { display: flex; gap: 6px; flex-wrap: wrap; align-items: center; margin-bottom: 10px; }
    .presets .faint { font-size: 12px; margin-right: 4px; }
    .perm-group { border: 1px solid var(--border); border-radius: 12px; margin-bottom: 12px; overflow: hidden; }
    .perm-group h3 { margin: 0; padding: 9px 14px; font-size: 11px; text-transform: uppercase; letter-spacing: .07em; color: var(--text-faint); background: var(--surface-2); border-bottom: 1px solid var(--border); }
    .perm { display: grid; grid-template-columns: minmax(200px, 1fr) fit-content(64%); gap: 14px; padding: 12px 14px; border-bottom: 1px solid var(--border); align-items: center; }
    .perm:last-child { border-bottom: 0; }
    .perm .m b { font-weight: 600; display: block; } .perm .m span { color: var(--text-dim); font-size: 12px; }
    .acts { display: flex; gap: 8px; flex-wrap: wrap; justify-content: flex-end; align-items: center; }
    .chk { display: inline-flex; align-items: center; gap: 7px; padding: 5px 10px; border: 1px solid var(--border); border-radius: 8px; font-size: 12.5px; cursor: pointer; user-select: none; background: var(--surface-2); }
    .chk input { accent-color: var(--accent); margin: 0; }
    .chk.on { border-color: var(--accent); background: var(--accent-soft); }
    .chk.dis { opacity: .4; pointer-events: none; }
    .ed-foot { display: flex; justify-content: space-between; gap: 10px; align-items: center; margin-top: 16px; flex-wrap: wrap; }
    .summary { display: flex; gap: 5px; flex-wrap: wrap; margin-top: 8px; }
    .summary span { font-size: 11px; padding: 2px 8px; border-radius: 999px; background: var(--surface-2); border: 1px solid var(--border); color: var(--text-dim); }

    /* modal */
    .ov { position: fixed; inset: 0; background: rgba(2, 6, 15, .62); display: flex; align-items: flex-start; justify-content: center; padding: 6vh 16px 16px; z-index: 50; overflow-y: auto; animation: fade .15s ease; }
    .modal { width: 100%; max-width: 520px; background: var(--surface); border: 1px solid var(--border); border-radius: 16px; box-shadow: var(--shadow); animation: pop .18s ease; }
    .modal header { padding: 18px 20px 0; } .modal header h3 { margin: 0; font-size: 17px; } .modal header p { margin: 3px 0 0; color: var(--text-dim); font-size: 12.5px; }
    .modal .body { padding: 18px 20px; display: grid; gap: 14px; }
    .modal footer { padding: 14px 20px; border-top: 1px solid var(--border); display: flex; justify-content: flex-end; gap: 8px; }
    .row2 { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
    .toggles { display: grid; gap: 10px; border: 1px solid var(--border); border-radius: 11px; padding: 12px 14px; background: var(--surface-2); }
    .toggle-row { display: flex; justify-content: space-between; align-items: center; gap: 12px; }
    .toggle-row b { font-weight: 600; font-size: 13px; display: block; } .toggle-row span { font-size: 12px; color: var(--text-dim); }
    .err { color: var(--bad); font-size: 12.5px; min-height: 0; }
    @keyframes fade { from { opacity: 0; } } @keyframes pop { from { opacity: 0; transform: translateY(8px) scale(.98); } }
    .toast { position: fixed; bottom: 20px; left: 50%; transform: translateX(-50%); background: var(--text); color: var(--bg); padding: 10px 16px; border-radius: 10px; font-size: 13px; font-weight: 600; z-index: 60; box-shadow: var(--shadow); animation: pop .2s; }
    .toast.bad { background: var(--bad); color: #fff; }

    @media (max-width: 900px) { .roles { grid-template-columns: 1fr; } .stats { grid-template-columns: repeat(2, minmax(0, 1fr)); } .grid2 { grid-template-columns: 1fr; } }
    @media (max-width: 560px) { .wrap { padding: 18px 16px 60px; } .row2 { grid-template-columns: 1fr; } .perm { grid-template-columns: 1fr; } .acts { justify-content: flex-start; } .filters select { flex: 1 1 140px; } }
    .sw-pair { display: inline-flex; gap: 10px; align-items: center; }
    th .th-sub { font-size: 10px; font-weight: 500; text-transform: none; letter-spacing: 0; opacity: .7; margin-top: 2px; }
</style>
</head>
<body>
<svg width="0" height="0" style="position:absolute">
    <symbol id="i-search" viewBox="0 0 24 24"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></symbol>
    <symbol id="i-plus" viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></symbol>
    <symbol id="i-edit" viewBox="0 0 24 24"><path d="M4 20h4L18.5 9.5a2.1 2.1 0 0 0-3-3L5 17v3z"/><path d="m14 7 3 3"/></symbol>
    <symbol id="i-trash" viewBox="0 0 24 24"><path d="M4 7h16M10 11v6M14 11v6M6 7l1 12a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2l1-12M9 7V4h6v3"/></symbol>
    <symbol id="i-shield" viewBox="0 0 24 24"><path d="M12 3 5 6v6c0 4.5 3 7.5 7 9 4-1.5 7-4.5 7-9V6l-7-3z"/></symbol>
    <symbol id="i-users" viewBox="0 0 24 24"><circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c.8-3.5 3.4-5.5 6.5-5.5s5.7 2 6.5 5.5"/><path d="M16 4.5a3.5 3.5 0 0 1 0 7M18.5 14.8c1.6.8 2.6 2.6 3 5.2"/></symbol>
</svg>
<div class="wrap">
    <div class="page-head"><h1>Users &amp; Roles</h1><p>Add users, choose their role, and decide what each role can open and do<?= $project !== '' ? ' in ' . htmlspecialchars($project, ENT_QUOTES, 'UTF-8') : '' ?>.</p></div>
    <div id="notes"></div>

    <div class="topline">
        <div class="tabs" role="tablist">
            <button class="tab on" data-tab="users" role="tab"><svg class="i"><use href="#i-users"/></svg>Users <span class="n" id="n-users">–</span></button>
            <button class="tab" data-tab="roles" role="tab"><svg class="i"><use href="#i-shield"/></svg>Roles &amp; permissions <span class="n" id="n-roles">–</span></button>
        </div>
        <div>
            <button class="btn primary" id="add-user"><svg class="i"><use href="#i-plus"/></svg>Add user</button>
            <button class="btn primary hidden" id="add-role"><svg class="i"><use href="#i-plus"/></svg>New role</button>
        </div>
    </div>

    <!-- USERS -->
    <section id="tab-users">
        <div class="stats" id="stats"></div>
        <div class="card">
            <div class="filters">
                <div class="search"><svg class="i"><use href="#i-search"/></svg><input type="text" id="q" placeholder="Search name or email"></div>
                <select id="f-role"><option value="">All roles</option></select>
                <select id="f-status"><option value="">Active &amp; blocked</option><option value="Y">Active only</option><option value="N">Blocked only</option></select>
            </div>
            <div class="tbl-wrap"><table>
                <thead><tr><th>User</th><th>Role</th><th>Active</th><th class="c">Full emails<div class="th-sub">screen · export</div></th><th class="c">Full mobiles<div class="th-sub">screen · export</div></th><th>Added</th><th>Last login</th><th></th></tr></thead>
                <tbody id="u-body"><tr><td colspan="8" class="empty">Loading…</td></tr></tbody>
            </table></div>
        </div>
    </section>

    <!-- ROLES -->
    <section id="tab-roles" class="hidden">
        <div class="roles">
            <div class="role-list" id="role-list"></div>
            <div class="card role-ed" id="role-ed"></div>
        </div>
    </section>
</div>

<script>
(function () {
    'use strict';
    const API = 'users_api.php';
    const $ = s => document.querySelector(s);
    const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
    const S = { users: [], roles: [], modules: [], metrics: [], ctypes: [], me: 0, tab: 'users', roleSel: null, draft: null, enumCol: false };
    const COLORS = ['#E8A820', '#3B82F6', '#10B981', '#A855F7', '#EF4444', '#06B6D4', '#F97316', '#EC4899', '#84CC16'];
    const roleColor = key => key === 'superadmin' ? 'var(--accent)' : COLORS[(S.roles.findIndex(r => r.key === key) + 1) % COLORS.length] || '#64748B';
    const roleName = key => (S.roles.find(r => r.key === key) || {}).name || key || '—';
    const initials = n => String(n || '?').trim().split(/\s+/).slice(0, 2).map(p => p[0] || '').join('').toUpperCase() || '?';
    const avColor = s => COLORS[[...String(s)].reduce((a, c) => (a * 31 + c.charCodeAt(0)) >>> 0, 7) % COLORS.length];
    const fmtDate = v => { if (!v) return '<span class="faint">—</span>'; const d = new Date(String(v).replace(' ', 'T')); return isNaN(d) ? esc(v) : d.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' }) + `<div class="faint" style="font-size:11.5px">${d.toLocaleTimeString('en-IN', { hour: 'numeric', minute: '2-digit' })}</div>`; };

    async function api(action, body) {
        const opt = { credentials: 'same-origin', method: body ? 'POST' : 'GET' };
        if (body) { opt.headers = { 'Content-Type': 'application/json' }; opt.body = JSON.stringify(body); }
        const res = await fetch(`${API}?action=${action}`, opt);
        const d = await res.json().catch(() => ({ success: false, error: `Server error (HTTP ${res.status}).` }));
        if (!d.success) throw new Error(d.error || 'Request failed');
        return d;
    }
    function toast(text, bad) {
        document.querySelectorAll('.toast').forEach(t => t.remove());
        const t = document.createElement('div'); t.className = 'toast' + (bad ? ' bad' : ''); t.textContent = text;
        document.body.appendChild(t); setTimeout(() => t.remove(), 3200);
    }
    async function load() {
        const d = await api('load');
        Object.assign(S, { users: d.users, roles: d.roles, modules: d.modules, metrics: d.metrics || [], ctypes: d.campaign_types || [], me: d.me, enumCol: d.role_column_enum });
        const notes = (d.notes || []).map(n => `<div class="note warn">${esc(n)}</div>`);
        if (d.role_column_enum) notes.push(`<div class="note warn"><b>One database change needed for custom roles.</b> Users can only be Super Admin or Admin until <code>users.role</code> allows other values. Run once in MySQL: <code>ALTER TABLE users MODIFY role VARCHAR(50) NOT NULL DEFAULT 'admin';</code></div>`);
        $('#notes').innerHTML = notes.join('');
        $('#n-users').textContent = S.users.length;
        $('#n-roles').textContent = S.roles.length;
        $('#f-role').innerHTML = '<option value="">All roles</option>' + S.roles.map(r => `<option value="${esc(r.key)}">${esc(r.name)}</option>`).join('');
        renderUsers();
        if (!S.roleSel || !S.roles.find(r => r.key === S.roleSel)) S.roleSel = (S.roles[1] || S.roles[0]).key;
        if (!S.draft) renderRoles();
    }

    /* ── tabs ── */
    function setTab(t) {
        S.tab = t;
        document.querySelectorAll('.tab').forEach(b => b.classList.toggle('on', b.dataset.tab === t));
        $('#tab-users').classList.toggle('hidden', t !== 'users');
        $('#tab-roles').classList.toggle('hidden', t !== 'roles');
        $('#add-user').classList.toggle('hidden', t !== 'users');
        $('#add-role').classList.toggle('hidden', t !== 'roles');
        try { localStorage.setItem('pq-users-tab', t); } catch (e) {}
    }
    document.querySelectorAll('.tab').forEach(b => b.addEventListener('click', () => setTab(b.dataset.tab)));
    try { if (localStorage.getItem('pq-users-tab') === 'roles') setTab('roles'); } catch (e) {}

    /* ── users ── */
    function renderUsers() {
        const q = $('#q').value.trim().toLowerCase(), fr = $('#f-role').value, fs = $('#f-status').value;
        const act = S.users.filter(u => u.status === 'Y').length;
        $('#stats').innerHTML = [['Users', S.users.length], ['Active', act], ['Blocked', S.users.length - act], ['Super Admins', S.users.filter(u => u.role === 'superadmin').length]]
            .map(([l, v]) => `<div class="stat"><small>${l}</small><b class="mono">${v}</b></div>`).join('');
        const list = S.users.filter(u => (!q || (u.username + ' ' + u.email).toLowerCase().includes(q)) && (!fr || u.role === fr) && (!fs || u.status === fs));
        $('#u-body').innerHTML = list.map(u => {
            const me = u.uid === S.me, sup = u.role === 'superadmin';
            return `<tr data-uid="${u.uid}">
                <td><div class="who"><div class="av" style="background:${avColor(u.email)}">${esc(initials(u.username))}</div><div><b>${esc(u.username)}${me ? '<span class="you">You</span>' : ''}</b><span>${esc(u.email)}</span></div></div></td>
                <td><span class="pill ${sup ? 'super' : ''}"><i style="background:${roleColor(u.role)}"></i>${esc(roleName(u.role))}</span></td>
                <td><label class="sw" title="${me ? 'You can\'t block yourself' : 'Active users can sign in'}"><input type="checkbox" data-flag="status" ${u.status === 'Y' ? 'checked' : ''} ${me ? 'disabled' : ''}><span></span></label><span class="stxt">${u.status === 'Y' ? 'Active' : 'Blocked'}</span></td>
                <td class="c"><span class="sw-pair"><label class="sw accent" title="Full email addresses on screen (Leads, Unmapped, CRM Push…)"><input type="checkbox" data-flag="unmask_email" ${u.unmask_email === 'Y' ? 'checked' : ''}><span></span></label><label class="sw accent" title="Full email addresses in Excel / CSV exports"><input type="checkbox" data-flag="export_email" ${u.export_email === 'Y' ? 'checked' : ''}><span></span></label></span></td>
                <td class="c"><span class="sw-pair"><label class="sw accent" title="Full mobile numbers on screen (Leads, Unmapped, CRM Push…)"><input type="checkbox" data-flag="unmask_mobile" ${u.unmask_mobile === 'Y' ? 'checked' : ''}><span></span></label><label class="sw accent" title="Full mobile numbers in Excel / CSV exports"><input type="checkbox" data-flag="export_mobile" ${u.export_mobile === 'Y' ? 'checked' : ''}><span></span></label></span></td>
                <td class="mono" style="font-size:12.5px">${fmtDate(u.createdon)}</td>
                <td class="mono" style="font-size:12.5px">${fmtDate(u.lastlogin)}</td>
                <td style="white-space:nowrap;text-align:right"><button class="icon-btn" data-act="edit" title="Edit"><svg class="i"><use href="#i-edit"/></svg></button><button class="icon-btn del" data-act="delete" title="${me ? 'You can\'t delete yourself' : 'Delete user'}" ${me ? 'disabled' : ''}><svg class="i"><use href="#i-trash"/></svg></button></td>
            </tr>`;
        }).join('') || `<tr><td colspan="8" class="empty">${S.users.length ? 'No users match the filters.' : 'No users yet.'}</td></tr>`;
    }
    ['#q', '#f-role', '#f-status'].forEach(s => $(s).addEventListener('input', renderUsers));
    $('#u-body').addEventListener('change', async e => {
        const cb = e.target.closest('input[data-flag]'); if (!cb) return;
        const uid = +cb.closest('tr').dataset.uid, field = cb.dataset.flag, value = cb.checked ? 'Y' : 'N';
        cb.disabled = true;
        try {
            await api('set_flag', { uid, field, value });
            const u = S.users.find(x => x.uid === uid); u[field] = value;
            toast(field === 'status' ? (value === 'Y' ? 'User can sign in again' : 'User blocked — signed out on their next click') : 'Saved');
            renderUsers();
        } catch (err) { cb.checked = !cb.checked; cb.disabled = false; toast(err.message, true); }
    });
    $('#u-body').addEventListener('click', e => {
        const b = e.target.closest('[data-act]'); if (!b || b.disabled) return;
        const u = S.users.find(x => x.uid === +b.closest('tr').dataset.uid);
        if (b.dataset.act === 'edit') userModal(u); else deleteUser(u);
    });
    $('#add-user').addEventListener('click', () => userModal(null));

    function modal(html) {
        const ov = document.createElement('div'); ov.className = 'ov';
        ov.innerHTML = `<div class="modal" role="dialog" aria-modal="true">${html}</div>`;
        document.body.appendChild(ov);
        const close = () => ov.remove();
        ov.addEventListener('mousedown', e => { if (e.target === ov) close(); });
        ov.querySelectorAll('[data-close]').forEach(b => b.addEventListener('click', close));
        const onKey = e => { if (e.key === 'Escape') { close(); document.removeEventListener('keydown', onKey); } };
        document.addEventListener('keydown', onKey);
        return { el: ov, close };
    }
    function roleSummary(key) {
        const r = S.roles.find(x => x.key === key);
        if (!r) return '';
        if (r.builtin) return '<div class="summary"><span>Everything</span><span>Users &amp; Roles</span></div>';
        const p = r.permissions || {}, on = S.modules.filter(m => (p[m.key] || []).length);
        return `<div class="summary">${on.length ? on.map(m => `<span>${esc(m.label)}${(p[m.key] || []).length > 1 ? ' +' : ''}</span>`).join('') : '<span>No access to anything yet</span>'}</div>`;
    }
    function userModal(u) {
        const me = u && u.uid === S.me;
        const roleOpts = S.roles.map(r => `<option value="${esc(r.key)}" ${(u ? u.role : (S.roles.find(x => x.key === 'admin') ? 'admin' : S.roles[1]?.key)) === r.key ? 'selected' : ''} ${S.enumCol && !['superadmin', 'admin'].includes(r.key) ? 'disabled' : ''}>${esc(r.name)}${S.enumCol && !['superadmin', 'admin'].includes(r.key) ? ' (needs the database change)' : ''}</option>`).join('');
        const m = modal(`
            <header><h3>${u ? 'Edit user' : 'Add a user'}</h3><p>${u ? esc(u.email) : 'They sign in with this email — a login code is sent to it, or Google login.'}</p></header>
            <div class="body">
                <div class="row2">
                    <label class="f">Full name<input type="text" id="m-name" value="${esc(u?.username || '')}" placeholder="e.g. Priya Sharma" maxlength="100"></label>
                    <label class="f">Email<input type="email" id="m-email" value="${esc(u?.email || '')}" placeholder="name@company.com"></label>
                </div>
                <label class="f">Role<select id="m-role" ${me ? 'disabled' : ''}>${roleOpts}</select><div id="m-sum"></div>${me ? '<span class="faint">You can\'t change your own role.</span>' : ''}</label>
                <div class="toggles">
                    <div class="toggle-row"><div><b>Active</b><span>Blocked users can't sign in</span></div><label class="sw"><input type="checkbox" id="m-status" ${!u || u.status === 'Y' ? 'checked' : ''} ${me ? 'disabled' : ''}><span></span></label></div>
                    <div class="toggle-row"><div><b>Full emails on screen</b><span>Otherwise lead emails are masked on screen (ab••••••@gmail.com)</span></div><label class="sw accent"><input type="checkbox" id="m-ue" ${u?.unmask_email === 'Y' ? 'checked' : ''}><span></span></label></div>
                    <div class="toggle-row"><div><b>Full emails in exports</b><span>Excel / CSV downloads (Leads, Unmapped, CRM Push, Taboola)</span></div><label class="sw accent"><input type="checkbox" id="m-xe" ${u?.export_email === 'Y' ? 'checked' : ''}><span></span></label></div>
                    <div class="toggle-row"><div><b>Full mobile numbers on screen</b><span>Otherwise mobiles are masked on screen — only the last 5 digits (*****43210)</span></div><label class="sw accent"><input type="checkbox" id="m-um" ${u?.unmask_mobile === 'Y' ? 'checked' : ''}><span></span></label></div>
                    <div class="toggle-row"><div><b>Full mobile numbers in exports</b><span>Excel / CSV downloads (Leads, Unmapped, CRM Push, Taboola)</span></div><label class="sw accent"><input type="checkbox" id="m-xm" ${u?.export_mobile === 'Y' ? 'checked' : ''}><span></span></label></div>
                </div>
                <div class="err" id="m-err"></div>
            </div>
            <footer><button class="btn" data-close>Cancel</button><button class="btn primary" id="m-save">${u ? 'Save changes' : 'Add user'}</button></footer>`);
        const sum = () => { $('#m-sum').innerHTML = roleSummary($('#m-role').value); };
        $('#m-role').addEventListener('change', sum); sum();
        setTimeout(() => $('#m-name').focus(), 30);
        $('#m-save').addEventListener('click', async () => {
            const body = { uid: u?.uid || 0, username: $('#m-name').value.trim(), email: $('#m-email').value.trim(), role: $('#m-role').value,
                           status: $('#m-status').checked ? 'Y' : 'N', unmask_email: $('#m-ue').checked ? 'Y' : 'N', unmask_mobile: $('#m-um').checked ? 'Y' : 'N',
                           export_email: $('#m-xe').checked ? 'Y' : 'N', export_mobile: $('#m-xm').checked ? 'Y' : 'N' };
            const btn = $('#m-save'); btn.disabled = true;
            try { await api('save_user', body); m.close(); toast(u ? 'User updated' : 'User added — they can sign in now'); await load(); }
            catch (e) { $('#m-err').textContent = e.message; btn.disabled = false; }
        });
    }
    function deleteUser(u) {
        const m = modal(`
            <header><h3>Delete ${esc(u.username)}?</h3><p>${esc(u.email)} · ${esc(roleName(u.role))}</p></header>
            <div class="body"><div class="note bad" style="margin:0">They lose access straight away (signed out on their next click) and can't sign in again. Their past activity log stays. To keep the account but stop access, <b>block</b> them instead.</div>
            <label class="f">Type <b style="color:var(--text)">DELETE</b> to confirm<input type="text" id="d-confirm" autocomplete="off"></label><div class="err" id="d-err"></div></div>
            <footer><button class="btn" data-close>Cancel</button><button class="btn danger" id="d-go" disabled>Delete user</button></footer>`);
        const inp = $('#d-confirm'); setTimeout(() => inp.focus(), 30);
        inp.addEventListener('input', () => { $('#d-go').disabled = inp.value.trim().toUpperCase() !== 'DELETE'; });
        $('#d-go').addEventListener('click', async () => {
            $('#d-go').disabled = true;
            try { await api('delete_user', { uid: u.uid }); m.close(); toast('User deleted'); await load(); }
            catch (e) { $('#d-err').textContent = e.message; }
        });
    }

    /* ── roles ── */
    function renderRoleList() {
        $('#role-list').innerHTML = S.roles.map(r => `<button class="role-item ${r.key === S.roleSel ? 'on' : ''}" data-key="${esc(r.key)}">
            <div class="t"><span style="display:flex;align-items:center;gap:8px"><span class="pill ${r.builtin ? 'super' : ''}" style="padding:0;width:9px;height:9px;border:0;background:${roleColor(r.key)}"></span>${esc(r.name)}</span>
            <span class="tag">${r.users} user${r.users === 1 ? '' : 's'}</span></div>
            <p>${esc(r.description || (r.builtin ? '' : 'No description'))}</p>
            ${r.builtin ? '<div class="summary"><span>Full access · fixed</span></div>' : r.is_system ? '<div class="summary"><span>Built in · can edit</span></div>' : ''}
        </button>`).join('') + (S.draft && !S.draft.key ? `<button class="role-item on"><div class="t">${esc(S.draft.name || 'New role')}</div><p>Not saved yet</p></button>` : '');
        document.querySelectorAll('.role-item[data-key]').forEach(b => b.addEventListener('click', () => {
            if (S.draft && S.draft.dirty && !confirm('Discard the changes to this role?')) return;
            S.roleSel = b.dataset.key; S.draft = null; renderRoles();
        }));
    }
    function renderRoles() {
        const r = S.draft || S.roles.find(x => x.key === S.roleSel);
        if (!S.draft && r && !r.builtin) S.draft = { key: r.key, name: r.name, description: r.description, permissions: JSON.parse(JSON.stringify(r.permissions || {})), is_system: r.is_system, users: r.users, dirty: false };
        renderRoleList();
        const ed = $('#role-ed');
        if (!r) { ed.innerHTML = '<div class="empty">Choose a role.</div>'; return; }
        if (r.builtin) {
            ed.innerHTML = `<h2>Super Admin</h2><p class="muted" style="margin:0 0 14px;font-size:13px">Always has full access — every page and action, plus Users &amp; Roles and the activity logs. This role can't be changed or deleted, and there must always be at least one active Super Admin.</p>` + matrix({}, true);
            return;
        }
        const d = S.draft;
        ed.innerHTML = `
            <h2>${d.key ? esc(d.name) : 'New role'}</h2>
            <p class="muted" style="margin:0;font-size:13px">${d.key ? `${d.users} user${d.users === 1 ? '' : 's'} with this role · changes apply on their next click` : 'Choose what people with this role can open and do.'}</p>
            <div class="grid2">
                <label class="f">Role name<input type="text" id="r-name" value="${esc(d.name)}" maxlength="100" placeholder="e.g. Sales manager"></label>
                <label class="f">Description<input type="text" id="r-desc" value="${esc(d.description)}" maxlength="255" placeholder="Who is this role for?"></label>
            </div>
            <div class="presets"><span class="faint">Quick set:</span><button class="btn sm" data-preset="all">Everything</button><button class="btn sm" data-preset="view">View only</button><button class="btn sm" data-preset="none">Nothing</button></div>
            ${matrix(d.permissions, false)}
            <div class="err" id="r-err"></div>
            <div class="ed-foot">
                <div>${d.key && !d.is_system ? '<button class="btn ghost-danger" id="r-del"><svg class="i"><use href="#i-trash"/></svg>Delete role</button>' : d.is_system ? '<span class="faint" style="font-size:12px">Built-in role: you can change its permissions, not delete it.</span>' : ''}</div>
                <div style="display:flex;gap:8px">${!d.key ? '<button class="btn" id="r-cancel">Cancel</button>' : ''}<button class="btn primary" id="r-save">${d.key ? 'Save role' : 'Create role'}</button></div>
            </div>`;
        $('#r-name').addEventListener('input', e => { d.name = e.target.value; d.dirty = true; });
        $('#r-desc').addEventListener('input', e => { d.description = e.target.value; d.dirty = true; });
        ed.querySelectorAll('input[data-m]').forEach(cb => cb.addEventListener('change', () => {
            const m = cb.dataset.m, a = cb.dataset.a; let acts = new Set(d.permissions[m] || []);
            if (cb.checked) { acts.add(a); acts.add('view'); } else if (a === 'view') acts = new Set(); else acts.delete(a);
            if (acts.size) d.permissions[m] = [...acts]; else delete d.permissions[m];
            d.dirty = true; refreshMatrix();
        }));
        ed.querySelectorAll('input[data-metric]').forEach(cb => cb.addEventListener('change', () => {
            const set = new Set(d.permissions.hide_metrics || []);
            if (cb.checked) set.delete(cb.dataset.metric); else set.add(cb.dataset.metric);
            if (set.size) d.permissions.hide_metrics = [...set]; else delete d.permissions.hide_metrics;
            d.dirty = true;
            const t = cb.closest('.acts').querySelector('.stxt'); if (t) t.textContent = cb.checked ? 'Shown' : 'Hidden';
        }));
        // Roles → "Campaign types": Show performance / Show awareness (at least one stays on)
        ed.querySelectorAll('input[data-ctype]').forEach(cb => cb.addEventListener('change', () => {
            const set = new Set(d.permissions.hide_types || []);
            if (cb.checked) set.delete(cb.dataset.ctype); else set.add(cb.dataset.ctype);
            if (set.size >= S.ctypes.length) {
                cb.checked = true;
                const e = $('#r-err'); if (e) { e.textContent = 'A role needs at least one campaign type — turn the other one on first.'; setTimeout(() => { if (e.textContent.startsWith('A role needs')) e.textContent = ''; }, 4000); }
                return;
            }
            if (set.size) d.permissions.hide_types = [...set]; else delete d.permissions.hide_types;
            d.dirty = true;
            const t = cb.closest('.acts').querySelector('.stxt'); if (t) t.textContent = cb.checked ? 'Shown' : 'Hidden';
        }));
        ed.querySelectorAll('[data-preset]').forEach(b => b.addEventListener('click', () => {
            const p = b.dataset.preset; const keepHide = d.permissions.hide_metrics, keepTypes = d.permissions.hide_types; d.permissions = {};
            if (keepHide) d.permissions.hide_metrics = keepHide;
            if (keepTypes) d.permissions.hide_types = keepTypes;
            if (p !== 'none') S.modules.forEach(m => { d.permissions[m.key] = p === 'all' ? Object.keys(m.actions) : ['view']; });
            if (p === 'view') ['status', 'import', 'capi'].forEach(k => delete d.permissions[k]);   // these "views" change data
            d.dirty = true; refreshMatrix();
        }));
        $('#r-save').addEventListener('click', saveRole);
        if ($('#r-del')) $('#r-del').addEventListener('click', () => deleteRole(d));
        if ($('#r-cancel')) $('#r-cancel').addEventListener('click', () => { S.draft = null; S.roleSel = (S.roles[1] || S.roles[0]).key; renderRoles(); });
        setTimeout(() => { if (!d.key) $('#r-name').focus(); }, 30);
    }
    function matrix(perms, locked) {
        const groups = [...new Set(S.modules.map(m => m.group))];
        return groups.map(g => `<div class="perm-group"><h3>${esc(g)}</h3>${S.modules.filter(m => m.group === g).map(m => {
            const acts = locked ? Object.keys(m.actions) : (perms[m.key] || []), has = acts.includes('view');
            return `<div class="perm"><div class="m"><b>${esc(m.label)}</b><span>${esc(m.desc)}</span></div><div class="acts">${Object.entries(m.actions).map(([a, label]) => {
                const on = acts.includes(a), dis = locked || (a !== 'view' && !has);
                return `<label class="chk ${on ? 'on' : ''} ${dis && !locked ? 'dis' : ''}" ${locked ? 'style="pointer-events:none"' : ''}><input type="checkbox" data-m="${m.key}" data-a="${a}" ${on ? 'checked' : ''} ${locked ? 'disabled' : ''}>${esc(label)}</label>`;
            }).join('')}</div></div>`;
        }).join('')}</div>`).join('') + typesBlock(perms, locked) + metricsBlock(perms, locked) + (locked ? '<div class="perm-group"><h3>Admin</h3><div class="perm"><div class="m"><b>Users &amp; Roles, activity logs</b><span>Only Super Admins</span></div><div class="acts"><label class="chk on" style="pointer-events:none"><input type="checkbox" checked disabled>Manage</label></div></div></div>' : '');
    }
    // Roles → "Campaign types": Show performance / Show awareness — the All / Performance / Awareness tabs, menu items,
    // spend and results everywhere (app/Core/access.php PQ_CAMPAIGN_TYPES; stored as permissions.hide_types)
    function typesBlock(perms, locked) {
        if (!S.ctypes.length) return '';
        const hidden = locked ? [] : (perms.hide_types || []);
        return `<div class="perm-group"><h3>Campaign types</h3>${S.ctypes.map(m => {
            const on = !hidden.includes(m.key);
            return `<div class="perm"><div class="m"><b>${esc(m.label)}</b><span>${esc(m.desc)}</span></div><div class="acts">
                <span class="stxt" style="margin:0 6px 0 0">${on ? 'Shown' : 'Hidden'}</span>
                <label class="sw accent" ${locked ? 'style="pointer-events:none"' : ''}><input type="checkbox" data-ctype="${m.key}" ${on ? 'checked' : ''} ${locked ? 'disabled' : ''} aria-label="${esc(m.label)}"><span></span></label></div></div>`;
        }).join('')}<div class="perm" style="display:block"><span class="faint" style="font-size:12px">With one of them off, the dashboards show only the other tab, and that type's campaigns are left out everywhere — dashboards, reports and PDFs, Creatives &amp; Insights, Keyword Analysis and Targets. Manual platforms that are all awareness (✎ Awareness → All of it) or all performance disappear from the menu. Leads in Leads &amp; CRM are not affected.</span></div></div>`;
    }
    // Roles → "Hide numbers": Qualified leads / CPQL / Site visits / CPSV on All Platforms and the platform dashboards
    function metricsBlock(perms, locked) {
        if (!S.metrics.length) return '';
        const hidden = locked ? [] : (perms.hide_metrics || []);
        return `<div class="perm-group"><h3>Numbers on the dashboards</h3>${S.metrics.map(m => {
            const on = !hidden.includes(m.key);
            return `<div class="perm"><div class="m"><b>${esc(m.label)}</b><span>${esc(m.desc)}</span></div><div class="acts">
                <span class="stxt" style="margin:0 6px 0 0">${on ? 'Shown' : 'Hidden'}</span>
                <label class="sw accent" ${locked ? 'style="pointer-events:none"' : ''}><input type="checkbox" data-metric="${m.key}" ${on ? 'checked' : ''} ${locked ? 'disabled' : ''}><span></span></label></div></div>`;
        }).join('')}<div class="perm" style="display:block"><span class="faint" style="font-size:12px">Hidden numbers disappear from cards, funnels, tables and charts on All Platforms, Meta, Google and the manual platforms. The PDF / email reports still include them — turn off <b>Reports</b> above for this role if needed.</span></div></div>`;
    }
    function refreshMatrix() {
        const d = S.draft;
        document.querySelectorAll('#role-ed input[data-m]').forEach(cb => {
            const acts = d.permissions[cb.dataset.m] || [], on = acts.includes(cb.dataset.a), has = acts.includes('view');
            cb.checked = on; const l = cb.closest('.chk'); l.classList.toggle('on', on); l.classList.toggle('dis', cb.dataset.a !== 'view' && !has);
        });
    }
    $('#add-role').addEventListener('click', () => {
        if (S.draft && S.draft.dirty && !confirm('Discard the changes to this role?')) return;
        S.draft = { key: '', name: '', description: '', permissions: { overview: ['view'], meta: ['view'], google: ['view'], leads: ['view'] }, is_system: 0, users: 0, dirty: false };
        renderRoles();
    });
    async function saveRole() {
        const d = S.draft, btn = $('#r-save'); btn.disabled = true; $('#r-err').textContent = '';
        try {
            const r = await api('save_role', { key: d.key, name: d.name.trim(), description: d.description.trim(), permissions: d.permissions });
            toast(d.key ? 'Role saved — applies on the next click of its users' : 'Role created');
            S.roleSel = r.key; S.draft = null; await load(); renderRoles();
        } catch (e) { $('#r-err').textContent = e.message; btn.disabled = false; }
    }
    function deleteRole(d) {
        const others = S.roles.filter(r => r.key !== d.key);
        const m = modal(`
            <header><h3>Delete the ${esc(d.name)} role?</h3><p>${d.users ? `${d.users} user${d.users === 1 ? ' has' : 's have'} this role.` : 'Nobody has this role.'}</p></header>
            <div class="body">${d.users ? `<label class="f">Give ${d.users === 1 ? 'that user' : 'those users'} this role instead<select id="dr-to">${others.map(r => `<option value="${esc(r.key)}" ${r.key === 'viewer' ? 'selected' : ''}>${esc(r.name)}</option>`).join('')}</select></label>` : ''}<div class="err" id="dr-err"></div></div>
            <footer><button class="btn" data-close>Cancel</button><button class="btn danger" id="dr-go">Delete role</button></footer>`);
        $('#dr-go').addEventListener('click', async () => {
            $('#dr-go').disabled = true;
            try { const r = await api('delete_role', { key: d.key, move_to: $('#dr-to') ? $('#dr-to').value : '' }); m.close(); toast(r.moved ? `Role deleted · ${r.moved} user(s) moved` : 'Role deleted'); S.draft = null; S.roleSel = null; await load(); renderRoles(); }
            catch (e) { $('#dr-err').textContent = e.message; $('#dr-go').disabled = false; }
        });
    }

    load().catch(e => { $('#u-body').innerHTML = `<tr><td colspan="8" class="empty">${esc(e.message)}</td></tr>`; });
})();
</script>
</body>
</html>
