<?php
/**
 * crm_settings.php — Admin → CRM Settings: the built-in Salesforce (SFDC) integration, set up with no code.
 * Sign-in (client credentials or username + password, with an optional backup), the lead endpoint, which
 * leads may be sent (Meta / Google / other sources) and the field list with placeholders.
 * Test sign-in and Preview never create anything in Salesforce. Super Admin only.
 * Backend: crm_settings_api.php, logic: app/Leads/crm_sfdc.php. Used by "Send to CRM" on the CRM Push page.
 */
session_start();
if (($_SESSION['user_logged'] ?? '') !== 'Y') {
    header('Location: login.php');
    exit;
}
require_once dirname(__DIR__) . '/app/Core/db.php';
$h = fn($v) => htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');
$dbs = [];
foreach (leadDbKeys() as $k) {
    $dbs[$k] = leadDbLabel($k);
}
?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Sora:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
<script>
(function () {
    var root = document.documentElement, t = null;
    try { t = localStorage.getItem('performiq-theme'); } catch (e) {}
    root.setAttribute('data-theme', t === 'light' ? 'light' : 'dark');
    if (/[?&]embed=1(&|$)/.test(location.search)) root.classList.add('pq-embed');
    window.addEventListener('storage', function (e) {
        if (e.key === 'performiq-theme') root.setAttribute('data-theme', e.newValue === 'light' ? 'light' : 'dark');
    });
    window.setTheme = function (t) { root.setAttribute('data-theme', t === 'light' ? 'light' : 'dark'); };
})();
</script>
<title>CRM Settings</title>
<style>
    :root, html[data-theme="dark"] {
        --bg: #0B0F1A; --surface: #111827; --surface-2: #161D2E; --border: #1E2A42; --border-strong: #2A3957;
        --text: #E2E8F0; --text-dim: #94A3B8; --text-faint: #64748B; --accent: #E8A820; --accent-soft: #E8A8201F;
        --hover: #1A2337; --good: #10B981; --good-soft: #10B9811F; --bad: #EF4444; --bad-soft: #EF44441A;
        --warn: #F59E0B; --warn-soft: #F59E0B1A; --meta: #3987E5; --meta-soft: #3987E51F; --google: #D95926; --google-soft: #D959261F; color-scheme: dark;
    }
    html[data-theme="light"] {
        --bg: #F4F6FA; --surface: #FFFFFF; --surface-2: #F8FAFC; --border: #E2E8F0; --border-strong: #CBD5E1;
        --text: #0F172A; --text-dim: #475569; --text-faint: #94A3B8; --accent: #B7791F; --accent-soft: #B7791F1A;
        --hover: #F1F5F9; --good: #059669; --good-soft: #0596691A; --bad: #DC2626; --bad-soft: #DC26261A;
        --warn: #B45309; --warn-soft: #B453091A; --meta: #2A78D6; --meta-soft: #2A78D61A; --google: #C2410C; --google-soft: #C2410C1A; color-scheme: light;
    }
    * { box-sizing: border-box; }
    body { margin: 0; background: var(--bg); color: var(--text); font: 14px/1.5 'Sora', system-ui, -apple-system, 'Segoe UI', sans-serif; }
    button, input, select { font: inherit; color: inherit; }
    .mono { font-family: 'JetBrains Mono', ui-monospace, monospace; font-variant-numeric: tabular-nums; }
    .wrap { max-width: 1400px; margin: 0 auto; padding: 28px 24px 60px; }
    .pq-embed .wrap { padding-top: 20px; }
    .pq-embed .page-head { display: none; }
    h1 { font-size: 22px; margin: 0 0 4px; }
    .sub { color: var(--text-dim); margin: 0 0 20px; font-size: 13px; }
    .card { background: var(--surface); border: 1px solid var(--border); border-radius: 12px; padding: 18px 20px; margin-bottom: 16px; }
    .bar { display: flex; gap: 10px; align-items: center; flex-wrap: wrap; }
    .bar .grow { flex: 1 1 220px; }
    select, input:not([type]), input[type=text], input[type=password], input[type=number], input[type=url], input[type=email], input[type=tel], input[type=date], input[type=search], textarea { background: var(--surface-2); border: 1px solid var(--border-strong); border-radius: 8px; padding: 8px 10px; outline: none; min-width: 0; }
    select:focus, input:focus, textarea:focus { border-color: var(--accent); }
    .btn { border: 1px solid var(--border-strong); background: var(--surface-2); padding: 8px 14px; border-radius: 8px; cursor: pointer; font-weight: 600; font-size: 13px; white-space: nowrap; }
    .btn:hover { background: var(--hover); }
    .btn.primary { background: var(--accent); border-color: var(--accent); color: #111; }
    .btn.sm { padding: 5px 10px; font-size: 12px; }
    .btn.ghost-bad { color: var(--bad); }
    .btn.danger { background: var(--bad); border-color: var(--bad); color: #fff; }
    .btn:disabled { opacity: .5; cursor: not-allowed; }
    .tabs { display: flex; gap: 6px; flex-wrap: wrap; }
    .tab { border: 1px solid var(--border); background: var(--surface-2); border-radius: 99px; padding: 6px 14px; font-size: 12.5px; cursor: pointer; color: var(--text-dim); font-weight: 600; }
    .tab.on { border-color: var(--accent); color: var(--text); background: var(--accent-soft); }
    .tab b { margin-left: 4px; font-family: 'JetBrains Mono', monospace; }
    .tbl-wrap { overflow: auto; border: 1px solid var(--border); border-radius: 10px; }
    table { width: 100%; border-collapse: collapse; font-size: 12.5px; }
    th { position: sticky; top: 0; z-index: 1; background: var(--surface-2); color: var(--text-dim); font-weight: 600; text-align: left; padding: 9px 10px;
         border-bottom: 1px solid var(--border); white-space: nowrap; font-size: 11px; text-transform: uppercase; letter-spacing: .04em; }
    td { padding: 9px 10px; border-bottom: 1px solid var(--border); vertical-align: top; }
    tr:last-child td { border-bottom: 0; }
    tr.sel td { background: var(--accent-soft); }
    td.chk, th.chk { width: 34px; text-align: center; }
    input[type=checkbox] { accent-color: var(--accent); width: 15px; height: 15px; }
    .pill { display: inline-block; padding: 1px 8px; border-radius: 99px; font-size: 11px; font-weight: 600; white-space: nowrap; }
    .pill.meta { color: var(--meta); background: var(--meta-soft); }
    .pill.google { color: var(--google); background: var(--google-soft); }
    .pill.unknown { color: var(--text-dim); background: var(--surface-2); border: 1px solid var(--border); }
    .pill.warn { color: var(--warn); background: var(--warn-soft); }
    .pill.bad { color: var(--bad); background: var(--bad-soft); }
    .muted { color: var(--text-dim); }
    .faint { color: var(--text-faint); font-size: 11.5px; }
    .map { display: grid; grid-template-columns: repeat(3, minmax(130px, 1fr)) auto; gap: 6px; align-items: center; min-width: 500px; }
    .map select { width: 100%; padding: 6px 8px; font-size: 12px; }
    .map .plat { grid-column: 1 / -1; display: flex; gap: 6px; align-items: center; }
    .note { padding: 11px 14px; border-radius: 10px; font-size: 12.5px; margin-bottom: 14px; border: 1px solid; }
    .note.warn { background: var(--warn-soft); border-color: var(--warn); }
    .note.bad { background: var(--bad-soft); border-color: var(--bad); }
    .note.good { background: var(--good-soft); border-color: var(--good); }
    .bulk { position: sticky; bottom: 12px; z-index: 5; display: flex; gap: 10px; align-items: center; flex-wrap: wrap; background: var(--surface);
            border: 1px solid var(--accent); border-radius: 12px; padding: 10px 14px; box-shadow: 0 10px 30px rgba(0, 0, 0, .35); margin-top: 12px; }
    .pager { display: flex; justify-content: space-between; align-items: center; gap: 10px; flex-wrap: wrap; margin-top: 12px; font-size: 12px; color: var(--text-dim); }
    .pager button { border: 1px solid var(--border); background: var(--surface-2); border-radius: 6px; padding: 4px 10px; cursor: pointer; font-size: 11px; color: var(--text-dim); }
    .pager button.on { background: var(--accent); border-color: var(--accent); color: #111; font-weight: 700; }
    .hidden { display: none !important; }
    .overlay { position: fixed; inset: 0; background: rgba(2, 6, 23, .6); display: grid; place-items: center; z-index: 50; padding: 16px; }
    .dialog { background: var(--surface); border: 1px solid var(--border-strong); border-radius: 14px; padding: 22px; max-width: 620px; width: 100%; max-height: 90vh; overflow: auto; box-shadow: 0 20px 60px rgba(0, 0, 0, .45); }
    .dialog h3 { margin: 0 0 8px; font-size: 17px; }
    .actions { display: flex; justify-content: flex-end; gap: 10px; margin-top: 18px; flex-wrap: wrap; }
    .spinner { width: 15px; height: 15px; border: 2px solid var(--border-strong); border-top-color: var(--accent); border-radius: 50%; display: inline-block; animation: spin .8s linear infinite; vertical-align: -3px; margin-right: 8px; }
    @keyframes spin { to { transform: rotate(360deg); } }
    .toast { position: fixed; right: 24px; bottom: 24px; z-index: 60; background: var(--surface); border: 1px solid var(--border-strong); border-left: 4px solid var(--good);
             padding: 12px 16px; border-radius: 8px; font-size: 13px; box-shadow: 0 10px 30px rgba(0, 0, 0, .35); max-width: 440px; }
    .toast.bad { border-left-color: var(--bad); }
    @media (max-width: 760px) { .wrap { padding: 16px; } }
    .pill.bad { color: var(--bad); background: var(--bad-soft); }
    .pill.good { color: var(--good); background: var(--good-soft); }
    .tiles { display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 10px; margin-bottom: 16px; }
    .tile { background: var(--surface); border: 1px solid var(--border); border-radius: 12px; padding: 14px 16px; cursor: pointer; text-align: left; }
    .tile:hover { background: var(--hover); }
    .tile.on { border-color: var(--accent); box-shadow: 0 0 0 1px var(--accent) inset; }
    .tile div { color: var(--text-dim); font-size: 12px; }
    .tile strong { display: block; font-size: 24px; margin-top: 2px; }
    .tile small { color: var(--text-faint); font-size: 11px; }
    .tile.bad strong { color: var(--bad); } .tile.good strong { color: var(--good); } .tile.warn strong { color: var(--warn); }
    .reasons td.n, .reasons th.n { text-align: right; }
    .reasons tr { cursor: pointer; } .reasons tr:hover td { background: var(--hover); } .reasons tr.on td { background: var(--accent-soft); }
    .bar-fill { height: 6px; border-radius: 99px; background: var(--bad); opacity: .75; }
    .send-ok { color: var(--good); } .send-bad { color: var(--bad); } .send-skip { color: var(--text-dim); }
    .res-list { max-height: 260px; overflow: auto; border: 1px solid var(--border); border-radius: 8px; margin-top: 10px; }
    .res-list div { padding: 6px 10px; border-bottom: 1px solid var(--border); font-size: 12.5px; }
    .res-list div:last-child { border-bottom: 0; }
    .progress { height: 8px; background: var(--surface-2); border-radius: 99px; overflow: hidden; margin-top: 12px; }
    .progress i { display: block; height: 100%; background: var(--accent); width: 0; transition: width .3s; }
    pre.raw { white-space: pre-wrap; word-break: break-all; font: 11px/1.45 'JetBrains Mono', monospace; background: var(--surface-2); border: 1px solid var(--border); border-radius: 8px; padding: 10px; margin: 6px 0 0; max-height: 220px; overflow: auto; }
</style>
<style>
    .grid2 { display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 12px 16px; }
    .fld { display: flex; flex-direction: column; gap: 5px; font-size: 12.5px; color: var(--text-dim); }
    .fld input, .fld select { width: 100%; color: var(--text); }
    .fld small { color: var(--text-faint); font-size: 11.5px; }
    h3.sec { margin: 0 0 4px; font-size: 15px; display: flex; align-items: center; gap: 10px; }
    p.sec { margin: 0 0 14px; color: var(--text-faint); font-size: 12px; }
    .switch { display: inline-flex; align-items: center; gap: 10px; cursor: pointer; font-weight: 600; }
    .switch input { display: none; }
    .switch i { width: 38px; height: 22px; border-radius: 99px; background: var(--border-strong); position: relative; transition: background .2s; flex: none; }
    .switch i::after { content: ''; position: absolute; top: 3px; left: 3px; width: 16px; height: 16px; border-radius: 50%; background: #fff; transition: left .2s; }
    .switch input:checked + i { background: var(--good); }
    .switch input:checked + i::after { left: 19px; }
    .plats { display: flex; flex-direction: column; gap: 8px; }
    .plats label { display: flex; gap: 8px; align-items: center; font-size: 13px; cursor: pointer; color: var(--text); white-space: nowrap; }
    .plats label input { width: 15px; flex: none; }
    table.fields td { padding: 5px 6px; vertical-align: middle; }
    table.fields input { width: 100%; padding: 6px 8px; font-size: 12.5px; font-family: 'JetBrains Mono', monospace; }
    table.fields td.nm input { font-weight: 600; }
    table.fields td.x { width: 34px; text-align: center; }
    table.fields th { position: static; }
    .chips { display: flex; flex-wrap: wrap; gap: 6px; }
    .chip { border: 1px solid var(--border); background: var(--surface-2); border-radius: 99px; padding: 3px 9px; font: 11px 'JetBrains Mono', monospace; color: var(--text-dim); cursor: pointer; }
    .chip:hover { border-color: var(--accent); color: var(--text); }
    .chip.sp { border-style: dashed; }
    .savebar { position: sticky; bottom: 12px; z-index: 5; display: flex; gap: 10px; align-items: center; flex-wrap: wrap; background: var(--surface);
               border: 1px solid var(--accent); border-radius: 12px; padding: 10px 14px; box-shadow: 0 10px 30px rgba(0, 0, 0, .35); }
    .badge { font-size: 11px; padding: 2px 9px; border-radius: 99px; font-weight: 700; }
    .badge.on { color: var(--good); background: var(--good-soft); } .badge.off { color: var(--text-dim); background: var(--surface-2); border: 1px solid var(--border); }
    pre.json { white-space: pre-wrap; word-break: break-all; font: 12px/1.5 'JetBrains Mono', monospace; background: var(--surface-2); border: 1px solid var(--border); border-radius: 8px; padding: 12px; margin: 10px 0 0; max-height: 420px; overflow: auto; }
    .test-row { padding: 8px 12px; border-radius: 8px; border: 1px solid var(--border); margin-top: 8px; font-size: 12.5px; }
    .test-row.ok { border-color: var(--good); background: var(--good-soft); } .test-row.bad { border-color: var(--bad); background: var(--bad-soft); }
    .help { font-size: 12px; color: var(--text-dim); line-height: 1.6; }
    .help code { font-family: 'JetBrains Mono', monospace; font-size: 11.5px; background: var(--surface-2); border: 1px solid var(--border); border-radius: 4px; padding: 0 4px; }
</style>
</head>
<body>
<div class="wrap">
    <div class="page-head">
        <h1>CRM Settings</h1>
        <p class="sub">Meta Conversions API (sent with Upload Lead Status) and Salesforce (“Send to CRM” on the CRM Push page).</p>
    </div>
    <div id="msg"></div>

    <div class="card" id="capi-card">
        <div class="bar" style="justify-content:space-between;align-items:flex-start;">
            <div>
                <h3 class="sec">Meta Conversions API <span class="badge off" id="capi-badge">Off</span></h3>
                <p class="sec" style="margin:0;max-width:760px;">When a feedback file in <b>Upload Lead Status</b> makes a Meta lead Qualified or gives it a site visit, send that to Meta.
                    Meta then optimises the lead-form campaigns for leads that qualify and visit, not just form fills. Each lead and event is sent once.</p>
            </div>
            <label class="switch"><input type="checkbox" id="capi-on"><i></i><span>Send with uploads</span></label>
        </div>
        <div class="grid2" style="margin-top:16px;">
            <label class="fld">Dataset / pixel ID<input id="capi-ds" inputmode="numeric" placeholder="e.g. 1234567890123456"><small>Events Manager → your dataset (pixel) → Settings. Use the dataset connected to the lead forms' page.</small></label>
            <label class="fld">Access token<input type="password" id="capi-tok" autocomplete="new-password"><small id="capi-tok-help">Events Manager → Settings → Conversions API → Generate access token.</small></label>
            <label class="fld">Qualified event name<input id="capi-ev-q" placeholder="Qualified"><small><label style="display:inline-flex;gap:6px;align-items:center;"><input type="checkbox" id="capi-s-q" style="width:14px;"> send it</label> · use the stage name set up in Meta's CRM integration</small></label>
            <label class="fld">Site visit event name<input id="capi-ev-s" placeholder="Site Visit"><small><label style="display:inline-flex;gap:6px;align-items:center;"><input type="checkbox" id="capi-s-s" style="width:14px;"> send it</label></small></label>
            <label class="fld">CRM name sent to Meta<input id="capi-src" placeholder="PerformIQ"><small>custom_data.lead_event_source, e.g. Salesforce</small></label>
            <label class="fld">Test event code (optional)<input id="capi-test" placeholder="TEST12345"><small>While set, events show only under Events Manager → Test events. Clear it to go live.</small></label>
        </div>
        <div class="bar" style="margin-top:14px;">
            <button class="btn primary" id="capi-save">Save Meta settings</button>
            <button class="btn" id="capi-check">Check dataset + token</button>
            <span class="faint" id="capi-note"></span>
        </div>
        <div id="capi-out"></div>
    </div>

    <div class="card">
        <div class="bar" style="justify-content:space-between;">
            <div>
                <h3 class="sec">Salesforce <span class="badge off" id="st-badge">Off</span></h3>
                <p class="sec" id="st-src" style="margin:0;"></p>
            </div>
            <div class="bar">
                <button class="btn hidden" id="b-import">Copy from config.php</button>
                <label class="switch"><input type="checkbox" id="enabled"><i></i><span id="enabled-lbl">Send to CRM is off</span></label>
            </div>
        </div>
    </div>

    <div class="card">
        <h3 class="sec">1 · Sign-in</h3>
        <p class="sec">From the Salesforce admin: a Connected App's client ID and secret. “Username + password” also needs the integration user (password followed by its security token, if the org uses one).</p>
        <div id="auth-primary"></div>
        <div style="margin-top:16px;">
            <label class="switch" style="font-weight:500;font-size:13px;"><input type="checkbox" id="fb-on"><i></i>Backup sign-in (used only if the one above fails)</label>
        </div>
        <div id="auth-fallback" class="hidden" style="margin-top:12px;"></div>
        <div class="bar" style="margin-top:16px;"><button class="btn" id="b-test">Test sign-in</button><span class="faint">Signs in only — nothing is created in Salesforce.</span></div>
        <div id="test-out"></div>
    </div>

    <div class="card">
        <h3 class="sec">2 · Where leads go</h3>
        <p class="sec">The Salesforce endpoint that creates a lead. A path (starting with /) is added to the instance URL Salesforce returns at sign-in.</p>
        <div class="grid2">
            <label class="fld">Lead endpoint<input id="lead_url" placeholder="https://yourorg.my.salesforce.com/services/apexrest/Marketing/Leads/"><small>Usually an Apex REST URL from the Salesforce team. Sent as POST with a JSON body.</small></label>
            <div class="fld">Leads that may be sent
                <div class="plats" style="margin-top:4px;">
                    <label><input type="checkbox" id="p-meta"> Meta</label>
                    <label><input type="checkbox" id="p-google"> Google</label>
                    <label><input type="checkbox" id="p-other"> Other sources <span class="faint">(Native, Website …)</span></label>
                </div>
                <small>Test leads are never sent. Only failed / not-sent leads can be sent.</small>
            </div>
        </div>
    </div>

    <div class="card">
        <h3 class="sec">3 · Fields</h3>
        <p class="sec">What Salesforce receives for each kind of lead. Leave a box empty to not send that field for that kind of lead.</p>
        <div class="tbl-wrap">
            <table class="fields">
                <thead><tr><th style="width:18%;">Salesforce field</th><th>Meta leads</th><th>Google leads</th><th>Other sources</th><th class="x"></th></tr></thead>
                <tbody id="fields"></tbody>
            </table>
        </div>
        <div class="bar" style="margin-top:10px;">
            <button class="btn sm" id="b-add">＋ Add field</button>
            <button class="btn sm" id="b-std">Reset to the standard fields</button>
        </div>
        <div style="margin-top:16px;" class="help">
            <b>How values work</b> — plain text is sent as it is (<code>Digital Marketing</code>). Names in braces take the value from the lead:
            <code>{name}</code>, <code>{campaign_name}</code>. <code>{a|b}</code> uses the first one that has a value. Fixed fallback text goes in quotes:
            <code>{campaignsubsource|'Google'}</code> (or <code>{countrycode|+91}</code>). Click a name below to put it in the box you are editing.
        </div>
        <div style="margin-top:10px;"><div class="faint" style="margin-bottom:6px;">Special values</div><div class="chips" id="chips-sp"></div></div>
        <div style="margin-top:10px;"><div class="faint" style="margin-bottom:6px;">Lead columns</div><div class="chips" id="chips-col"></div></div>
    </div>

    <div class="card">
        <h3 class="sec">4 · Preview</h3>
        <p class="sec">See exactly what a lead would be sent with (from the settings on this page, saved or not). Nothing is sent.</p>
        <div class="bar">
            <?php if (count($dbs) > 1) { ?>
            <select id="pv-db"><?php foreach ($dbs as $k => $l) { ?><option value="<?= $h($k) ?>"><?= $h($l) ?></option><?php } ?></select>
            <?php } else { ?><input type="hidden" id="pv-db" value="<?= $h(appDbKey()) ?>"><?php } ?>
            <select id="pv-plat"><option value="meta">Latest Meta lead</option><option value="google">Latest Google lead</option><option value="other">Latest other-source lead</option></select>
            <input type="text" id="pv-id" placeholder="…or lead ID" style="width:140px;">
            <button class="btn" id="b-preview">Preview</button>
        </div>
        <div id="pv-out"></div>
    </div>

    <div class="savebar">
        <button class="btn primary" id="b-save">Save Salesforce settings</button>
        <span class="faint" id="save-note">Changes are not saved yet.</span>
    </div>
</div>

<script>
(function () {
    'use strict';
    const API = 'crm_settings_api.php';
    const $ = s => document.querySelector(s);
    const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
    const D = { settings: null, saved: {}, clear: new Set(), std: [], dirty: false, lastFocus: null };

    async function call(action, body) {
        const opt = body === undefined ? { credentials: 'same-origin' } : { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) };
        const res = await fetch(`${API}?action=${action}`, opt);
        const d = await res.json().catch(() => ({ success: false, error: `Server error (HTTP ${res.status}).` }));
        if (!d.success) { const e = new Error(d.error || 'Request failed'); e.errors = d.errors; throw e; }
        return d;
    }
    function note(html, cls) { $('#msg').innerHTML = html ? `<div class="note ${cls || 'warn'}">${html}</div>` : ''; }
    function dirty(v = true) { D.dirty = v; $('#save-note').textContent = v ? 'Changes are not saved yet.' : 'All changes saved.'; }

    /* ── sign-in blocks ── */
    function authHtml(prefix, a, isFb) {
        const sec = k => D.saved[`${isFb ? 'fallback' : 'auth'}.${k}`];
        const ph = k => sec(k) && !D.clear.has(`${isFb ? 'fallback' : 'auth'}.${k}`) ? '•••••••• saved — leave empty to keep' : '';
        return `<div class="grid2">
            <label class="fld">Method<select data-a="${prefix}.mode">
                <option value="client_credentials" ${a.mode === 'client_credentials' ? 'selected' : ''}>Client credentials (client ID + secret)</option>
                <option value="password" ${a.mode === 'password' ? 'selected' : ''}>Username + password</option></select></label>
            <label class="fld">Token URL<input data-a="${prefix}.token_url" value="${esc(a.token_url)}" placeholder="https://login.salesforce.com/services/oauth2/token">
                <small>Your org: https://&lt;org&gt;.my.salesforce.com/services/oauth2/token · sandbox: https://test.salesforce.com/…</small></label>
            <label class="fld">Client ID<input data-a="${prefix}.client_id" value="${esc(a.client_id)}" autocomplete="off"></label>
            <label class="fld">Client secret<input type="password" data-a="${prefix}.client_secret" placeholder="${ph('client_secret')}" autocomplete="new-password"></label>
            <label class="fld ${a.mode === 'password' ? '' : 'hidden'}" data-pw="${prefix}">Username<input data-a="${prefix}.username" value="${esc(a.username)}" autocomplete="off"></label>
            <label class="fld ${a.mode === 'password' ? '' : 'hidden'}" data-pw="${prefix}">Password (+ security token)<input type="password" data-a="${prefix}.password" placeholder="${ph('password')}" autocomplete="new-password"></label>
        </div>`;
    }
    function drawAuth() {
        const s = D.settings;
        $('#auth-primary').innerHTML = authHtml('auth', s.auth, false);
        $('#fb-on').checked = !!s.fallback.mode;
        $('#auth-fallback').classList.toggle('hidden', !s.fallback.mode);
        $('#auth-fallback').innerHTML = authHtml('fallback', s.fallback.mode ? s.fallback : Object.assign({}, s.fallback, { mode: 'password', token_url: 'https://login.salesforce.com/services/oauth2/token' }), true);
        document.querySelectorAll('[data-a]').forEach(el => {
            const [blk, key] = el.dataset.a.split('.');
            el.addEventListener('input', () => {
                if (key === 'client_secret' || key === 'password') { /* typed secrets are read on save */ }
                else D.settings[blk][key] = el.value.trim();
                if (key === 'mode') document.querySelectorAll(`[data-pw="${blk}"]`).forEach(x => x.classList.toggle('hidden', el.value !== 'password'));
                dirty();
            });
        });
    }
    $('#fb-on').addEventListener('change', e => {
        D.settings.fallback.mode = e.target.checked ? ($(`[data-a="fallback.mode"]`).value || 'password') : '';
        if (e.target.checked && !D.settings.fallback.token_url) D.settings.fallback.token_url = $(`[data-a="fallback.token_url"]`).value;
        $('#auth-fallback').classList.toggle('hidden', !e.target.checked);
        dirty();
    });

    /* ── fields ── */
    function drawFields() {
        $('#fields').innerHTML = D.settings.fields.map((f, i) => `<tr>
            <td class="nm"><input data-f="${i}.name" value="${esc(f.name)}" placeholder="FieldName"></td>
            ${['meta', 'google', 'other'].map(p => `<td><input data-f="${i}.${p}" value="${esc(f[p])}" placeholder="(not sent)"></td>`).join('')}
            <td class="x"><button class="btn sm ghost-bad" data-del="${i}" title="Remove this field">✕</button></td></tr>`).join('')
            || `<tr><td colspan="5" class="muted" style="padding:16px;">No fields yet — click “Add field” or “Reset to the standard fields”.</td></tr>`;
        document.querySelectorAll('[data-f]').forEach(el => {
            el.addEventListener('input', () => { const [i, k] = el.dataset.f.split('.'); D.settings.fields[+i][k] = el.value; dirty(); });
            el.addEventListener('focus', () => { D.lastFocus = el; });
        });
        document.querySelectorAll('[data-del]').forEach(b => b.onclick = () => { D.settings.fields.splice(+b.dataset.del, 1); drawFields(); dirty(); });
    }
    $('#b-add').onclick = () => { D.settings.fields.push({ name: '', meta: '', google: '', other: '' }); drawFields(); dirty(); const ins = document.querySelectorAll('td.nm input'); ins[ins.length - 1].focus(); };
    $('#b-std').onclick = () => { if (!window.confirm('Replace the field list with the standard fields? Your campaign IDs and changes in the list will be lost.')) return; D.settings.fields = JSON.parse(JSON.stringify(D.std)); drawFields(); dirty(); };
    function chips(specials, columns) {
        $('#chips-sp').innerHTML = Object.entries(specials).map(([k, t]) => `<button class="chip sp" data-ins="${esc(k)}" title="${esc(t)}">{${esc(k)}}</button>`).join('');
        $('#chips-col').innerHTML = columns.map(c => `<button class="chip" data-ins="${esc(c)}">{${esc(c)}}</button>`).join('');
        document.querySelectorAll('[data-ins]').forEach(b => b.onmousedown = e => {
            e.preventDefault();
            const el = D.lastFocus;
            if (!el || !document.body.contains(el) || !el.dataset.f || el.dataset.f.endsWith('.name')) { note('Click into a Meta / Google / Other box first, then on a name.', 'warn'); return; }
            const pos = el.selectionStart ?? el.value.length;
            const ins = `{${b.dataset.ins}}`;
            el.value = el.value.slice(0, pos) + ins + el.value.slice(el.selectionEnd ?? pos);
            el.dispatchEvent(new Event('input'));
            el.focus(); el.setSelectionRange(pos + ins.length, pos + ins.length);
        });
    }

    /* ── whole page ── */
    function collect() {
        const s = JSON.parse(JSON.stringify(D.settings));
        s.enabled = $('#enabled').checked;
        s.lead_url = $('#lead_url').value.trim();
        s.platforms = { meta: $('#p-meta').checked, google: $('#p-google').checked, other: $('#p-other').checked };
        ['auth', 'fallback'].forEach(b => ['client_secret', 'password'].forEach(k => {
            const el = $(`[data-a="${b}.${k}"]`);
            s[b][k] = el ? el.value : '';
        }));
        if (!$('#fb-on').checked) s.fallback.mode = '';
        else s.fallback.mode = $(`[data-a="fallback.mode"]`).value;
        s.auth.mode = $(`[data-a="auth.mode"]`).value;
        s.fields = s.fields.filter(f => f.name.trim() !== '' || f.meta || f.google || f.other);
        return { settings: s, clear_secrets: [...D.clear] };
    }
    function status(d) {
        const on = !!D.settings.enabled;
        $('#st-badge').className = 'badge ' + (on ? 'on' : 'off');
        $('#st-badge').textContent = on ? 'On' : 'Off';
        $('#st-src').textContent = d.source === 'db' ? `Saved on this page${d.updated_at ? ' · ' + d.updated_at.slice(0, 16) : ''}${d.updated_by ? ' by ' + d.updated_by : ''}`
            : d.source === 'config' ? 'Using the CRM_SFDC block in config.php. Save here (or “Copy from config.php”) to manage it on this page.'
            : 'Not set up yet.';
        $('#b-import').classList.toggle('hidden', !(d.config_available && d.source !== 'db'));
    }
    function fill(d) {
        D.settings = d.settings; D.saved = d.saved_secrets || {}; D.clear = new Set();
        $('#enabled').checked = !!d.settings.enabled;
        $('#enabled-lbl').textContent = d.settings.enabled ? 'Send to CRM is on' : 'Send to CRM is off';
        $('#lead_url').value = d.settings.lead_url || '';
        ['meta', 'google', 'other'].forEach(p => $('#p-' + p).checked = !!d.settings.platforms[p]);
        drawAuth(); drawFields(); status(d); dirty(false);
        if (d.secret_errors && d.secret_errors.length) note('A saved secret could not be read (the encryption key in config.php changed). Enter the client secret / password again and save.', 'bad');
    }
    $('#enabled').addEventListener('change', e => { D.settings.enabled = e.target.checked; $('#enabled-lbl').textContent = e.target.checked ? 'Send to CRM is on (save to apply)' : 'Send to CRM is off (save to apply)'; dirty(); });
    ['#lead_url', '#p-meta', '#p-google', '#p-other'].forEach(id => $(id).addEventListener('input', () => dirty()));
    ['#p-meta', '#p-google', '#p-other'].forEach(id => $(id).addEventListener('change', () => dirty()));

    $('#b-save').onclick = async () => {
        const btn = $('#b-save'); btn.disabled = true; btn.textContent = 'Saving…'; note('');
        try {
            const d = await call('save', collect());
            fill(Object.assign({ config_available: false }, d));
            note('<b>Saved.</b> “Send to CRM” on the CRM Push page now uses these settings.', 'good');
        } catch (e) {
            note(`<b>${esc(e.message)}</b>${e.errors && e.errors.length > 1 ? '<ul style="margin:6px 0 0;padding-left:18px;">' + e.errors.slice(1).map(x => `<li>${esc(x)}</li>`).join('') + '</ul>' : ''}`, 'bad');
        }
        btn.disabled = false; btn.textContent = 'Save Salesforce settings';
        window.scrollTo({ top: 0, behavior: 'smooth' });
    };
    $('#b-import').onclick = async () => {
        try { const d = await call('import_config', {}); fill(d); note('<b>Copied from config.php and saved.</b> You can manage it here from now on (the config.php block is no longer used).', 'good'); }
        catch (e) { note(esc(e.message), 'bad'); }
    };
    $('#b-test').onclick = async () => {
        const b = $('#b-test'); b.disabled = true; $('#test-out').innerHTML = '<div class="test-row"><span class="spinner"></span>Signing in…</div>';
        try {
            const d = await call('test', collect());
            $('#test-out').innerHTML = d.results.map(r => `<div class="test-row ${r.ok ? 'ok' : 'bad'}"><b>${esc(r.which)}:</b> ${r.ok
                ? `signed in (${r.ms} ms)${r.instance_url ? ' · instance ' + esc(r.instance_url) : ''}${r.lead_url ? `<div class="faint">Leads go to ${esc(r.lead_url)}</div>` : ''}${r.lead_url_error ? `<div style="color:var(--bad);">${esc(r.lead_url_error)}</div>` : ''}`
                : esc(r.error)}</div>`).join('');
        } catch (e) { $('#test-out').innerHTML = `<div class="test-row bad">${esc(e.message)}</div>`; }
        b.disabled = false;
    };
    $('#b-preview').onclick = async () => {
        $('#pv-out').innerHTML = '<div class="test-row"><span class="spinner"></span>Building…</div>';
        try {
            const body = Object.assign(collect(), { platform: $('#pv-plat').value, lead_id: +$('#pv-id').value || 0, db: $('#pv-db').value });
            const d = await call('preview', body);
            const L = d.lead;
            $('#pv-out').innerHTML = `<div class="faint" style="margin-top:10px;">Lead #${L.id} · ${esc(L.name)} · ${esc(L.platform)} · ${esc(L.date)} → uses the <b>${esc({ meta: 'Meta', google: 'Google', other: 'Other sources' }[d.platform_used])}</b> column${D.settings && collect().settings.platforms[d.platform_used] ? '' : ' <span style="color:var(--warn);">(sending is turned off for this kind of lead)</span>'}</div>
                ${d.empty_fields.length ? `<div class="note warn" style="margin:8px 0 0;">Empty for this lead: ${d.empty_fields.map(esc).join(', ')}</div>` : ''}
                <pre class="json">${esc(d.json)}</pre>`;
        } catch (e) { $('#pv-out').innerHTML = `<div class="test-row bad">${esc(e.message)}</div>`; }
    };
    /* ── Meta Conversions API card ── */
    const C = { d: null, clearTok: false };
    function capiFill(c) {
        C.d = c; C.clearTok = false;
        $('#capi-on').checked = c.enabled;
        $('#capi-badge').className = 'badge ' + (c.enabled && !c.problem ? 'on' : 'off');
        $('#capi-badge').textContent = c.enabled && !c.problem ? 'On' : 'Off';
        $('#capi-ds').value = c.dataset_id || c.config_pixel || '';
        $('#capi-tok').value = '';
        $('#capi-tok').placeholder = c.token_saved ? '•••••••• saved — leave empty to keep' : (c.config_token ? 'empty = use META_ACCESS_TOKEN from config.php' : 'paste the token');
        $('#capi-ev-q').value = c.events.qualified; $('#capi-ev-s').value = c.events.sitevisit;
        $('#capi-s-q').checked = c.send.qualified; $('#capi-s-s').checked = c.send.sitevisit;
        $('#capi-src').value = c.lead_event_source; $('#capi-test').value = c.test_event_code || '';
        $('#capi-note').textContent = c.saved ? `Saved${c.updated_at ? ' ' + c.updated_at.slice(0, 16) : ''}${c.updated_by ? ' by ' + c.updated_by : ''}` : 'Not saved yet.';
        if (c.token_error) $('#capi-out').innerHTML = '<div class="test-row bad">The saved token could not be read (the encryption key changed). Paste it again and save.</div>';
    }
    function capiCollect() {
        return { capi: { enabled: $('#capi-on').checked, dataset_id: $('#capi-ds').value, access_token: $('#capi-tok').value, use_config_token: true,
            clear_token: C.clearTok, send: { qualified: $('#capi-s-q').checked, sitevisit: $('#capi-s-s').checked },
            events: { qualified: $('#capi-ev-q').value, sitevisit: $('#capi-ev-s').value }, lead_event_source: $('#capi-src').value, test_event_code: $('#capi-test').value } };
    }
    $('#capi-save').onclick = async () => {
        const b = $('#capi-save'); b.disabled = true; $('#capi-out').innerHTML = '';
        try { const d = await call('capi_save', capiCollect()); capiFill(d.capi); $('#capi-out').innerHTML = `<div class="test-row ok"><b>Saved.</b> ${d.capi.enabled ? 'The next feedback upload will offer to send Meta events.' : 'Sending is off.'}</div>`; }
        catch (e) { $('#capi-out').innerHTML = `<div class="test-row bad">${esc(e.message)}</div>`; }
        b.disabled = false;
    };
    $('#capi-check').onclick = async () => {
        const b = $('#capi-check'); b.disabled = true; $('#capi-out').innerHTML = '<div class="test-row"><span class="spinner"></span>Checking with Meta…</div>';
        try {
            const d = await call('capi_check', capiCollect());
            $('#capi-out').innerHTML = d.check.ok ? `<div class="test-row ok"><b>OK:</b> dataset ${esc(d.check.id)}${d.check.name ? ' · ' + esc(d.check.name) : ''}. Nothing was sent.</div>`
                : `<div class="test-row bad"><b>Meta says:</b> ${esc(d.check.error)}</div>`;
        } catch (e) { $('#capi-out').innerHTML = `<div class="test-row bad">${esc(e.message)}</div>`; }
        b.disabled = false;
    };

    window.addEventListener('beforeunload', e => { if (D.dirty) { e.preventDefault(); e.returnValue = ''; } });

    (async () => {
        try {
            call('capi_load').then(d => capiFill(d.capi)).catch(e => { $('#capi-out').innerHTML = `<div class="test-row bad">${esc(e.message)}</div>`; });
            const d = await call('load');
            D.std = d.standard_fields;
            chips(d.specials, d.columns);
            fill(d);
        } catch (e) { note(esc(e.message), 'bad'); }
    })();
})();
</script>
</body>
</html>
