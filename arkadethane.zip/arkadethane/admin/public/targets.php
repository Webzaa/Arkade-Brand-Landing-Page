<?php
/**
 * targets.php — Targets: enter the plan per month or per quarter (Overall and per platform), plus the bookings,
 * clash bookings and revenue achieved (the admin has no booking data). The "Target vs Achieved" card on every
 * dashboard reads these. Permission: Targets → View (read only) / Edit targets.
 * Backend: targets_api.php, logic: app/Ads/targets.php.
 */
session_start();
if (($_SESSION['user_logged'] ?? '') !== 'Y') {
    header('Location: login.php');
    exit;
}
require_once dirname(__DIR__) . '/app/Core/db.php';
?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Sora:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
<script>
(function () {
    var root = document.documentElement, t = null;
    try { t = localStorage.getItem('performiq-theme'); } catch (e) {}
    root.setAttribute('data-theme', t === 'light' ? 'light' : 'dark');
    if (/[?&]embed=1(&|$)/.test(location.search)) root.classList.add('pq-embed');
    window.addEventListener('storage', function (e) {
        if (e.key === 'performiq-theme') root.setAttribute('data-theme', e.newValue === 'light' ? 'light' : 'dark');
    });
    window.setTheme = function (t) { root.setAttribute('data-theme', t === 'light' ? 'light' : 'dark'); };
})();
</script>
<title>Targets</title>
<?= function_exists('pqMetricGuardTag') ? pqMetricGuardTag('') : '' ?>
<style>
    :root, html[data-theme="dark"] {
        --bg: #0B0F1A; --surface: #111827; --surface-2: #161D2E; --border: #1E2A42; --border-strong: #2A3957;
        --text: #E2E8F0; --text-dim: #94A3B8; --text-faint: #64748B; --accent: #E8A820; --accent-soft: #E8A8201F;
        --hover: #1A2337; --good: #10B981; --good-soft: #10B9811F; --bad: #EF4444; --bad-soft: #EF44441A;
        --warn: #F59E0B; --warn-soft: #F59E0B1A; --meta: #3987E5; --meta-soft: #3987E51F; --google: #D95926; --google-soft: #D959261F; color-scheme: dark;
    }
    html[data-theme="light"] {
        --bg: #F4F6FA; --surface: #FFFFFF; --surface-2: #F8FAFC; --border: #E2E8F0; --border-strong: #CBD5E1;
        --text: #0F172A; --text-dim: #475569; --text-faint: #94A3B8; --accent: #B7791F; --accent-soft: #B7791F1A;
        --hover: #F1F5F9; --good: #059669; --good-soft: #0596691A; --bad: #DC2626; --bad-soft: #DC26261A;
        --warn: #B45309; --warn-soft: #B453091A; --meta: #2A78D6; --meta-soft: #2A78D61A; --google: #C2410C; --google-soft: #C2410C1A; color-scheme: light;
    }
    * { box-sizing: border-box; }
    body { margin: 0; background: var(--bg); color: var(--text); font: 14px/1.5 'Sora', system-ui, -apple-system, 'Segoe UI', sans-serif; }
    button, input, select { font: inherit; color: inherit; }
    .mono { font-family: 'JetBrains Mono', ui-monospace, monospace; font-variant-numeric: tabular-nums; }
    .wrap { max-width: 1400px; margin: 0 auto; padding: 28px 24px 60px; }
    .pq-embed .wrap { padding-top: 20px; }
    .pq-embed .page-head { display: none; }
    h1 { font-size: 22px; margin: 0 0 4px; }
    .sub { color: var(--text-dim); margin: 0 0 20px; font-size: 13px; }
    .card { background: var(--surface); border: 1px solid var(--border); border-radius: 12px; padding: 18px 20px; margin-bottom: 16px; }
    .bar { display: flex; gap: 10px; align-items: center; flex-wrap: wrap; }
    .bar .grow { flex: 1 1 220px; }
    select, input:not([type]), input[type=text], input[type=password], input[type=number], input[type=url], input[type=email], input[type=tel], input[type=date], input[type=search], textarea { background: var(--surface-2); border: 1px solid var(--border-strong); border-radius: 8px; padding: 8px 10px; outline: none; min-width: 0; }
    select:focus, input:focus, textarea:focus { border-color: var(--accent); }
    .btn { border: 1px solid var(--border-strong); background: var(--surface-2); padding: 8px 14px; border-radius: 8px; cursor: pointer; font-weight: 600; font-size: 13px; white-space: nowrap; }
    .btn:hover { background: var(--hover); }
    .btn.primary { background: var(--accent); border-color: var(--accent); color: #111; }
    .btn.sm { padding: 5px 10px; font-size: 12px; }
    .btn.ghost-bad { color: var(--bad); }
    .btn.danger { background: var(--bad); border-color: var(--bad); color: #fff; }
    .btn:disabled { opacity: .5; cursor: not-allowed; }
    .tabs { display: flex; gap: 6px; flex-wrap: wrap; }
    .tab { border: 1px solid var(--border); background: var(--surface-2); border-radius: 99px; padding: 6px 14px; font-size: 12.5px; cursor: pointer; color: var(--text-dim); font-weight: 600; }
    .tab.on { border-color: var(--accent); color: var(--text); background: var(--accent-soft); }
    .tab b { margin-left: 4px; font-family: 'JetBrains Mono', monospace; }
    .tbl-wrap { overflow: auto; border: 1px solid var(--border); border-radius: 10px; }
    table { width: 100%; border-collapse: collapse; font-size: 12.5px; }
    th { position: sticky; top: 0; z-index: 1; background: var(--surface-2); color: var(--text-dim); font-weight: 600; text-align: left; padding: 9px 10px;
         border-bottom: 1px solid var(--border); white-space: nowrap; font-size: 11px; text-transform: uppercase; letter-spacing: .04em; }
    td { padding: 9px 10px; border-bottom: 1px solid var(--border); vertical-align: top; }
    tr:last-child td { border-bottom: 0; }
    tr.sel td { background: var(--accent-soft); }
    td.chk, th.chk { width: 34px; text-align: center; }
    input[type=checkbox] { accent-color: var(--accent); width: 15px; height: 15px; }
    .pill { display: inline-block; padding: 1px 8px; border-radius: 99px; font-size: 11px; font-weight: 600; white-space: nowrap; }
    .pill.meta { color: var(--meta); background: var(--meta-soft); }
    .pill.google { color: var(--google); background: var(--google-soft); }
    .pill.unknown { color: var(--text-dim); background: var(--surface-2); border: 1px solid var(--border); }
    .pill.warn { color: var(--warn); background: var(--warn-soft); }
    .pill.bad { color: var(--bad); background: var(--bad-soft); }
    .muted { color: var(--text-dim); }
    .faint { color: var(--text-faint); font-size: 11.5px; }
    .map { display: grid; grid-template-columns: repeat(3, minmax(130px, 1fr)) auto; gap: 6px; align-items: center; min-width: 500px; }
    .map select { width: 100%; padding: 6px 8px; font-size: 12px; }
    .map .plat { grid-column: 1 / -1; display: flex; gap: 6px; align-items: center; }
    .note { padding: 11px 14px; border-radius: 10px; font-size: 12.5px; margin-bottom: 14px; border: 1px solid; }
    .note.warn { background: var(--warn-soft); border-color: var(--warn); }
    .note.bad { background: var(--bad-soft); border-color: var(--bad); }
    .note.good { background: var(--good-soft); border-color: var(--good); }
    .bulk { position: sticky; bottom: 12px; z-index: 5; display: flex; gap: 10px; align-items: center; flex-wrap: wrap; background: var(--surface);
            border: 1px solid var(--accent); border-radius: 12px; padding: 10px 14px; box-shadow: 0 10px 30px rgba(0, 0, 0, .35); margin-top: 12px; }
    .pager { display: flex; justify-content: space-between; align-items: center; gap: 10px; flex-wrap: wrap; margin-top: 12px; font-size: 12px; color: var(--text-dim); }
    .pager button { border: 1px solid var(--border); background: var(--surface-2); border-radius: 6px; padding: 4px 10px; cursor: pointer; font-size: 11px; color: var(--text-dim); }
    .pager button.on { background: var(--accent); border-color: var(--accent); color: #111; font-weight: 700; }
    .hidden { display: none !important; }
    .overlay { position: fixed; inset: 0; background: rgba(2, 6, 23, .6); display: grid; place-items: center; z-index: 50; padding: 16px; }
    .dialog { background: var(--surface); border: 1px solid var(--border-strong); border-radius: 14px; padding: 22px; max-width: 620px; width: 100%; max-height: 90vh; overflow: auto; box-shadow: 0 20px 60px rgba(0, 0, 0, .45); }
    .dialog h3 { margin: 0 0 8px; font-size: 17px; }
    .actions { display: flex; justify-content: flex-end; gap: 10px; margin-top: 18px; flex-wrap: wrap; }
    .spinner { width: 15px; height: 15px; border: 2px solid var(--border-strong); border-top-color: var(--accent); border-radius: 50%; display: inline-block; animation: spin .8s linear infinite; vertical-align: -3px; margin-right: 8px; }
    @keyframes spin { to { transform: rotate(360deg); } }
    .toast { position: fixed; right: 24px; bottom: 24px; z-index: 60; background: var(--surface); border: 1px solid var(--border-strong); border-left: 4px solid var(--good);
             padding: 12px 16px; border-radius: 8px; font-size: 13px; box-shadow: 0 10px 30px rgba(0, 0, 0, .35); max-width: 440px; }
    .toast.bad { border-left-color: var(--bad); }
    @media (max-width: 760px) { .wrap { padding: 16px; } }
    .pill.bad { color: var(--bad); background: var(--bad-soft); }
    .pill.good { color: var(--good); background: var(--good-soft); }
    .tiles { display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 10px; margin-bottom: 16px; }
    .tile { background: var(--surface); border: 1px solid var(--border); border-radius: 12px; padding: 14px 16px; cursor: pointer; text-align: left; }
    .tile:hover { background: var(--hover); }
    .tile.on { border-color: var(--accent); box-shadow: 0 0 0 1px var(--accent) inset; }
    .tile div { color: var(--text-dim); font-size: 12px; }
    .tile strong { display: block; font-size: 24px; margin-top: 2px; }
    .tile small { color: var(--text-faint); font-size: 11px; }
    .tile.bad strong { color: var(--bad); } .tile.good strong { color: var(--good); } .tile.warn strong { color: var(--warn); }
    .reasons td.n, .reasons th.n { text-align: right; }
    .reasons tr { cursor: pointer; } .reasons tr:hover td { background: var(--hover); } .reasons tr.on td { background: var(--accent-soft); }
    .bar-fill { height: 6px; border-radius: 99px; background: var(--bad); opacity: .75; }
    .send-ok { color: var(--good); } .send-bad { color: var(--bad); } .send-skip { color: var(--text-dim); }
    .res-list { max-height: 260px; overflow: auto; border: 1px solid var(--border); border-radius: 8px; margin-top: 10px; }
    .res-list div { padding: 6px 10px; border-bottom: 1px solid var(--border); font-size: 12.5px; }
    .res-list div:last-child { border-bottom: 0; }
    .progress { height: 8px; background: var(--surface-2); border-radius: 99px; overflow: hidden; margin-top: 12px; }
    .progress i { display: block; height: 100%; background: var(--accent); width: 0; transition: width .3s; }
    pre.raw { white-space: pre-wrap; word-break: break-all; font: 11px/1.45 'JetBrains Mono', monospace; background: var(--surface-2); border: 1px solid var(--border); border-radius: 8px; padding: 10px; margin: 6px 0 0; max-height: 220px; overflow: auto; }
</style>
<style>
    .grid-wrap { overflow: auto; border: 1px solid var(--border); border-radius: 10px; }
    table.tg { width: 100%; border-collapse: collapse; font-size: 12.5px; }
    table.tg th { position: sticky; top: 0; background: var(--surface-2); z-index: 1; text-align: center; padding: 9px 8px; font-size: 11px; text-transform: uppercase; letter-spacing: .04em; color: var(--text-dim); border-bottom: 1px solid var(--border); white-space: nowrap; }
    table.tg th:first-child, table.tg td:first-child { text-align: left; position: sticky; left: 0; background: var(--surface); z-index: 2; min-width: 190px; }
    table.tg th:first-child { background: var(--surface-2); z-index: 3; }
    table.tg td { padding: 4px 6px; border-bottom: 1px solid var(--border); }
    table.tg td:first-child { font-weight: 600; padding-left: 12px; }
    table.tg tr.rate td:first-child { font-weight: 500; color: var(--text-dim); padding-left: 26px; }
    table.tg tr.sec td { background: var(--surface-2); font-size: 11px; text-transform: uppercase; letter-spacing: .05em; color: var(--text-dim); font-weight: 700; padding: 8px 12px; }
    table.tg input { width: 100%; min-width: 110px; text-align: right; padding: 6px 8px; font-family: 'JetBrains Mono', monospace; font-size: 12px; }
    table.tg input::placeholder { color: var(--text-faint); opacity: .9; }
    table.tg input.ov { border-color: var(--accent); }
    table.tg input:disabled { opacity: .7; }
    .unit { font-size: 10.5px; color: var(--text-faint); font-weight: 400; margin-left: 4px; }
    .per { display: flex; align-items: center; gap: 8px; flex-wrap: wrap; }
    .per b { min-width: 170px; text-align: center; font-size: 15px; }
    @media (max-width: 600px) {
        .per { width: 100%; } .per b { min-width: 0; flex: 1; } #per-jump { flex: 1 1 100%; }
        #settings-bar label { width: 100%; display: flex; flex-direction: column; gap: 4px; }
        .bulk .btn { flex: 1 1 45%; }
    }
    .legend2 { font-size: 11.5px; color: var(--text-faint); }
    .legend2 i { display: inline-block; width: 10px; height: 10px; border: 1px solid var(--accent); border-radius: 3px; vertical-align: -1px; margin: 0 4px 0 10px; }
</style>
</head>
<body>
<div class="wrap">
    <div class="page-head">
        <h1>Targets</h1>
        <p class="sub">The plan per month or quarter — shown against the real numbers on every dashboard (“Target vs Achieved”).</p>
    </div>
    <div id="msg"></div>

    <div class="card">
        <div class="bar" style="justify-content:space-between;">
            <div class="per">
                <button class="btn" id="prev" title="Previous">‹</button>
                <b id="per-label">…</b>
                <button class="btn" id="next" title="Next">›</button>
                <select id="per-jump" title="Periods with targets"></select>
            </div>
            <div class="bar" id="settings-bar">
                <label class="muted" style="font-size:12.5px;">Targets are set per
                    <select id="set-period"><option value="month">Month</option><option value="quarter">Quarter</option></select></label>
                <label class="muted" style="font-size:12.5px;">Dashboards show
                    <select id="set-prorate"><option value="0">the full period target</option><option value="1">the target pro-rated to the dates</option></select></label>
            </div>
        </div>
    </div>

    <div class="card" style="padding:0;">
        <div class="grid-wrap" style="border:0;border-radius:12px;">
            <table class="tg"><thead id="tg-head"></thead><tbody id="tg-body"><tr><td class="muted" style="padding:20px;"><span class="spinner"></span>Loading…</td></tr></tbody></table>
        </div>
    </div>
    <div class="bar" style="margin:-4px 0 16px;">
        <span class="legend2">Grey numbers are worked out for you (rates from the numbers, Overall = sum of the platforms). Type a value to set it yourself<i></i>.
            Copy a block of cells in Excel and paste it into any box — it fills from that box to the right and down.</span>
    </div>

    <div class="bulk" id="savebar">
        <button class="btn primary" id="save">Save targets</button>
        <button class="btn" id="copy-prev" title="Fill the empty boxes with the previous period's targets">Copy previous period</button>
        <button class="btn" id="imp-file" title="Fill the boxes from a .csv / .xlsx / .xls file laid out like this table">⤓ Import file</button>
        <button class="btn" id="imp-paste" title="Paste cells copied from Excel or Google Sheets">⧉ Paste from Excel</button>
        <button class="btn" id="tpl" title="The import format: this table as a .csv file (with the values already saved)">↓ Download template</button>
        <input type="file" id="imp-input" accept=".csv,.tsv,.txt,.xlsx,.xls" hidden>
        <span class="faint" id="save-note"></span>
    </div>

    <div style="margin-top:22px;" id="preview"></div>
</div>

<script src="assets/js/target_report.js?v=1"></script>
<script>
(function () {
    'use strict';
    const API = 'targets_api.php';
    const $ = s => document.querySelector(s);
    const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
    const T = { d: null, key: '', dirty: false };
    const UNIT = { money: '₹', pct: '%', int: '' };
    const num = v => { const x = String(v ?? '').replace(/[,₹%\s]/g, ''); return x === '' ? null : (isFinite(+x) ? +x : NaN); };
    const show = (v, f) => v === null || !isFinite(v) ? '' : (f === 'pct' ? (+v).toFixed(v < 10 ? 2 : 1) : Math.round(v).toLocaleString('en-IN'));
    const report = PQTargets.mount($('#preview'), { api: API, platform: 'overall', pick: true });

    async function call(action, body, qs) {
        const opt = body === undefined ? { credentials: 'same-origin' } : { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) };
        const res = await fetch(`${API}?action=${action}${qs ? '&' + qs : ''}`, opt);
        const d = await res.json().catch(() => ({ success: false, error: `Server error (HTTP ${res.status}).` }));
        if (!d.success) throw new Error(d.error || 'Request failed');
        return d;
    }
    const note = (h, c) => { $('#msg').innerHTML = h ? `<div class="note ${c || 'warn'}">${h}</div>` : ''; };
    function dirty(v = true) { T.dirty = v; $('#save-note').textContent = v ? 'Not saved yet.' : ''; }

    function shiftKey(key, n) {
        if (/Q/.test(key)) { let [y, q] = [+key.slice(0, 4), +key.slice(6)]; q += n; while (q > 4) { q -= 4; y++; } while (q < 1) { q += 4; y--; } return `${y}-Q${q}`; }
        let [y, m] = key.split('-').map(Number); m += n; while (m > 12) { m -= 12; y++; } while (m < 1) { m += 12; y--; } return `${y}-${String(m).padStart(2, '0')}`;
    }

    async function load(key) {
        if (T.dirty && !confirm('Leave without saving these targets?')) return;
        try {
            const d = await call('load', undefined, key ? 'period_key=' + encodeURIComponent(key) : '');
            T.d = d; T.key = d.period_key;
            $('#per-label').textContent = d.period_label;
            $('#set-period').value = d.settings.period;
            $('#set-prorate').value = d.settings.prorate ? '1' : '0';
            const keys = [...new Set([d.period_key, ...d.periods_with_data])].sort().reverse();
            $('#per-jump').innerHTML = keys.map(k => `<option value="${k}" ${k === d.period_key ? 'selected' : ''}>${k}${d.periods_with_data.includes(k) ? ' ✓' : ''}</option>`).join('');
            ['#set-period', '#set-prorate', '#save', '#copy-prev', '#imp-file', '#imp-paste'].forEach(s => $(s).disabled = !d.can_edit);
            $('#savebar').classList.toggle('hidden', !d.can_edit);
            if (!d.can_edit) note('You can see the targets. Your role can\'t change them.', 'warn');
            draw(); dirty(false);
            report.setPlatforms(d.platforms);
            report.update({ since: d.start, until: d.end });
            report.reload();
        } catch (e) { note(esc(e.message), 'bad'); }
    }

    function val(pf, kind, m) { const v = (T.d.values[pf] || {})[kind]; return v && v[m] !== undefined ? v[m] : null; }
    function draw() {
        const d = T.d, pfs = Object.entries(d.platforms);
        $('#tg-head').innerHTML = `<tr><th>Particulars</th>${pfs.map(([k, n]) => `<th>${esc(n)}</th>`).join('')}</tr>`;
        const row = (r, kind) => `<tr class="${r.kind === 'rate' ? 'rate' : ''}"><td>${esc(r.label)}<span class="unit">${UNIT[r.format]}</span></td>${pfs.map(([k]) => {
            const v = val(k, kind, r.key);
            return `<td><input data-pf="${esc(k)}" data-kind="${kind}" data-m="${r.key}" data-f="${r.format}" value="${v === null ? '' : show(v, r.format)}" inputmode="decimal" ${d.can_edit ? '' : 'disabled'}></td>`;
        }).join('')}</tr>`;
        $('#tg-body').innerHTML = `<tr class="sec"><td colspan="${pfs.length + 1}">Targets</td></tr>`
            + d.rows.map(r => row(r, 'target')).join('')
            + `<tr class="sec"><td colspan="${pfs.length + 1}">Achieved — entered by hand (the rest comes from the dashboards)</td></tr>`
            + d.rows.filter(r => r.manual_actual).map(r => row(r, 'actual')).join('');
        document.querySelectorAll('table.tg input').forEach(i => i.addEventListener('input', () => { dirty(); hints(); }));
        hints();
    }
    // grey placeholders: rates from the numbers, Overall = sum of the platforms
    function hints() {
        const d = T.d, pfs = Object.keys(d.platforms);
        const get = (pf, kind, m) => { const el = document.querySelector(`input[data-pf="${pf}"][data-kind="${kind}"][data-m="${m}"]`); const v = el ? num(el.value) : null; return v === null || isNaN(v) ? null : v; };
        const base = ['spend', 'leads', 'ql', 'sv', 'bookings', 'clash', 'revenue'];
        const eff = {};
        pfs.forEach(pf => {
            eff[pf] = {};
            base.forEach(m => {
                let v = get(pf, 'target', m);
                if (v === null && pf === 'overall') { const parts = pfs.filter(x => x !== 'overall').map(x => get(x, 'target', m)).filter(x => x !== null); v = parts.length ? parts.reduce((a, b) => a + b, 0) : null; }
                eff[pf][m] = v;
            });
        });
        const div = (a, b, k = 1) => a !== null && b ? a / b * k : null;
        pfs.forEach(pf => {
            const e = eff[pf];
            const calc = { cpl: div(e.spend, e.leads), ql_rate: div(e.ql, e.leads, 100), cpql: div(e.spend, e.ql), sv_rate: div(e.sv, e.ql, 100), cpsv: div(e.spend, e.sv), bk_rate: div(e.bookings, e.sv, 100), cts: div(e.spend, e.revenue, 100) };
            document.querySelectorAll(`input[data-pf="${pf}"][data-kind="target"]`).forEach(i => {
                const m = i.dataset.m;
                const ph = m in calc ? calc[m] : (pf === 'overall' ? e[m] : null);
                i.placeholder = ph === null || ph === undefined ? '' : show(ph, i.dataset.f);
                i.classList.toggle('ov', i.value.trim() !== '' && (m in calc || pf === 'overall'));
            });
            if (pf === 'overall') document.querySelectorAll(`input[data-pf="overall"][data-kind="actual"]`).forEach(i => {
                const parts = pfs.filter(x => x !== 'overall').map(x => get(x, 'actual', i.dataset.m)).filter(x => x !== null);
                i.placeholder = parts.length ? show(parts.reduce((a, b) => a + b, 0), i.dataset.f) : '';
            });
        });
    }

    $('#prev').onclick = () => { note(''); load(shiftKey(T.key, -1)); };
    $('#next').onclick = () => { note(''); load(shiftKey(T.key, 1)); };
    $('#per-jump').onchange = () => { note(''); load($('#per-jump').value); };
    $('#save').onclick = async () => {
        const values = {};
        let bad = '';
        document.querySelectorAll('table.tg input').forEach(i => {
            const v = num(i.value);
            if (Number.isNaN(v) || (v !== null && v < 0)) bad = bad || `${i.closest('tr').firstElementChild.textContent.replace(/[₹%]$/, '')} (${T.d.platforms[i.dataset.pf]})`;
            ((values[i.dataset.pf] ??= {})[i.dataset.kind] ??= {})[i.dataset.m] = v === null ? '' : v;
        });
        if (bad) { note(`<b>Not saved:</b> ${esc(bad)} is not a number.`, 'bad'); return; }
        const b = $('#save'); b.disabled = true; b.textContent = 'Saving…';
        try {
            const d = await call('save', { period_key: T.key, values });
            dirty(false); note(`<b>Saved</b> ${esc(T.d.period_label)} (${d.saved} value${d.saved === 1 ? '' : 's'}). The dashboards show it on their next refresh.`, 'good');
            const k = T.key; T.dirty = false; await load(k);
        } catch (e) { note(esc(e.message), 'bad'); }
        b.disabled = false; b.textContent = 'Save targets';
    };
    $('#copy-prev').onclick = async () => {
        try {
            const d = await call('load', undefined, 'period_key=' + encodeURIComponent(shiftKey(T.key, -1)));
            let n = 0;
            Object.entries(d.values).forEach(([pf, kinds]) => Object.entries(kinds.target || {}).forEach(([m, v]) => {
                const el = document.querySelector(`input[data-pf="${pf}"][data-kind="target"][data-m="${m}"]`);
                if (el && el.value.trim() === '') { el.value = show(v, el.dataset.f); n++; }
            }));
            hints(); if (n) dirty();
            note(n ? `Copied ${n} target(s) from ${esc(d.period_label)} into the empty boxes. Check them and save.` : `${esc(d.period_label)} has no targets to copy.`, n ? 'good' : 'warn');
        } catch (e) { note(esc(e.message), 'bad'); }
    };
    async function saveSettings() {
        try {
            const d = await call('settings', { period: $('#set-period').value, prorate: $('#set-prorate').value === '1' });
            note(`Saved: targets per <b>${d.settings.period}</b>; dashboards show the ${d.settings.prorate ? 'pro-rated' : 'full period'} target by default.`, 'good');
            T.dirty = false; load('');
        } catch (e) { note(esc(e.message), 'bad'); }
    }
    $('#set-period').onchange = () => {
        if (!confirm(`Set targets per ${$('#set-period').value}? Targets entered per ${$('#set-period').value === 'month' ? 'quarter' : 'month'} are kept but not used until you switch back.`)) { $('#set-period').value = T.d.settings.period; return; }
        saveSettings();
    };
    $('#set-prorate').onchange = saveSettings;

    /* ── Import / paste / template ─────────────────────────────────────────────
     * The format is this table: first column = Particulars (row names as on screen), first row = the platforms
     * (Overall, Meta, Google, OTT Video …). The other way round (platforms down, particulars across) works too.
     * Rows under an "Achieved" heading (or named "Achieved Bookings") fill the Achieved boxes.
     * Nothing is saved until Save targets — the boxes are filled for the person to check. Empty cells change nothing. */
    const norm = s => String(s ?? '').toLowerCase().replace(/\(.*?\)/g, ' ').replace(/[^a-z0-9%]+/g, ' ').replace(/\s*%/g, '%').trim();
    const ALIAS = { spend: ['spend', 'spends', 'budget', 'media spend'], leads: ['leads', 'lead', 'workable leads', 'leads workable'], cpl: ['cpl', 'cost per lead'],
        ql: ['ql', 'qualified', 'qualified leads', 'qls'], ql_rate: ['lead to ql %', 'lead to ql', 'ql %', 'ql rate', 'lead to qualified %'], cpql: ['cpql', 'cost per qualified lead'],
        sv_rate: ['ql to sv %', 'ql to sv', 'sv %', 'qualified to site visit %'], sv: ['sv', 'svs', 'site visits', 'site visit', 'walkins', 'walk ins'], cpsv: ['cpsv', 'cost per site visit'],
        bk_rate: ['sv to booking %', 'sv to booking', 'booking %'], bookings: ['bookings', 'booking'], clash: ['clash booking', 'clash bookings', 'clash'],
        revenue: ['revenue', 'sales value'], cts: ['cost to sales %', 'cost to sales', 'cts', 'cost to sales% digital', 'cost to sales %'] };
    function metricOf(label) {
        let t = norm(label), kind = 'target';
        if (/^(achieved|actual|actuals)\b/.test(t)) { kind = 'actual'; t = t.replace(/^(achieved|actual|actuals)\s*/, ''); }
        else if (/^target\s/.test(t)) t = t.replace(/^target\s*/, '');
        const rows = T.d.rows;
        for (const r of rows) {
            const names = [r.key, norm(r.label)].concat(ALIAS[r.key] || []).map(norm);
            if (names.includes(t)) return { m: r.key, kind };
        }
        return null;
    }
    function platformOf(label) {
        const t = norm(label);
        if (!t) return null;
        for (const [k, n] of Object.entries(T.d.platforms)) if (norm(k) === t || norm(n) === t || norm(k.replace(/^m-/, '')) === t) return k;
        if (['total', 'all', 'all platforms'].includes(t)) return 'overall';
        if (['facebook', 'fb', 'meta ads'].includes(t)) return 'meta';
        if (['google ads', 'adwords'].includes(t)) return 'google';
        return null;
    }
    const isSection = t => /achieved|actual/.test(norm(t)) && !metricOf(t);
    /** Fills the boxes from a table of cells. Returns {filled, skipped: [labels]} */
    function applyMatrix(rowsIn) {
        const rows = rowsIn.map(r => r.map(c => String(c ?? '').trim())).filter(r => r.some(c => c !== ''));
        if (!rows.length) throw new Error('The sheet is empty.');
        // the header row: the first row where some cell is a platform
        let h = rows.findIndex(r => r.slice(1).filter(platformOf).length > 0);
        let trans = false;
        if (h < 0) {   // platforms down the first column, particulars across?
            h = rows.findIndex(r => r.slice(1).filter(c => metricOf(c)).length > 0);
            if (h < 0) throw new Error('No platform names (Overall, Meta, Google …) or particulars (Spends, Leads …) found in the first row. Download the template to see the format.');
            trans = true;
        }
        const head = rows[h], skipped = new Set();
        let filled = 0, section = 'target';
        const put = (pf, mk, raw) => {
            if (!pf || !mk || raw === '') return;
            const el = document.querySelector(`input[data-pf="${pf}"][data-kind="${mk.kind}"][data-m="${mk.m}"]`);
            if (!el) { skipped.add(`${T.d.platforms[pf]} · ${mk.kind === 'actual' ? 'Achieved ' : ''}${mk.m}`); return; }
            const v = num(raw);
            if (v === null) return;
            if (Number.isNaN(v) || v < 0) { skipped.add(`"${raw}" (not a number)`); return; }
            el.value = show(v, el.dataset.f) || String(v); filled++;
        };
        for (const r of rows.slice(h + 1)) {
            const label = r[0];
            if (!trans) {
                if (isSection(label)) { section = 'actual'; continue; }
                if (/^targets?$/.test(norm(label))) { section = 'target'; continue; }
                let mk = metricOf(label);
                if (!mk) { if (label && r.slice(1).some(c => c !== '')) skipped.add(label); continue; }
                if (section === 'actual' && mk.kind === 'target') mk = { m: mk.m, kind: 'actual' };
                head.forEach((c, j) => { if (j === 0) return; const pf = platformOf(c); if (pf) put(pf, mk, r[j] || ''); else if (c && r[j]) skipped.add(c); });
            } else {
                const pf = platformOf(label);
                if (!pf) { if (label && r.slice(1).some(c => c !== '')) skipped.add(label); continue; }
                head.forEach((c, j) => { if (j === 0) return; const mk = metricOf(c); if (mk) put(pf, mk, r[j] || ''); else if (c && r[j]) skipped.add(c); });
            }
        }
        hints(); if (filled) dirty();
        return { filled, skipped: [...skipped] };
    }
    function report2(res, what) {
        const sk = res.skipped.length ? ` Skipped (not on this page): ${res.skipped.slice(0, 8).map(esc).join(', ')}${res.skipped.length > 8 ? ' …' : ''}.` : '';
        note(res.filled ? `<b>${res.filled} value${res.filled === 1 ? '' : 's'}</b> filled from ${esc(what)} for ${esc(T.d.period_label)}. Check them and click <b>Save targets</b>.${sk}`
            : `Nothing was filled from ${esc(what)}.${sk || ' Download the template to see the format.'}`, res.filled ? 'good' : 'warn');
    }
    // CSV / TSV text → rows (quotes handled; Excel copies are tab separated)
    function parseText(text) {
        text = String(text).replace(/^﻿/, '').replace(/\r\n?/g, '\n');
        const first = text.split('\n')[0];
        const sep = first.includes('\t') ? '\t' : (first.split(';').length > first.split(',').length ? ';' : ',');
        const out = []; let row = [], cell = '', q = false;
        for (let i = 0; i < text.length; i++) {
            const ch = text[i];
            if (q) { if (ch === '"' && text[i + 1] === '"') { cell += '"'; i++; } else if (ch === '"') q = false; else cell += ch; continue; }
            if (ch === '"' && cell === '') q = true;
            else if (ch === sep) { row.push(cell); cell = ''; }
            else if (ch === '\n') { row.push(cell); out.push(row); row = []; cell = ''; }
            else cell += ch;
        }
        if (cell !== '' || row.length) { row.push(cell); out.push(row); }
        return out;
    }
    let sheetJs = null;
    function loadSheetJs() {   // only for old .xls files
        if (window.XLSX) return Promise.resolve(window.XLSX);
        return sheetJs ||= new Promise((ok, fail) => {
            const sc = document.createElement('script');
            sc.src = 'https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js';
            sc.onload = () => ok(window.XLSX);
            sc.onerror = () => { sheetJs = null; fail(new Error('Could not load the .xls reader. Save the file as .xlsx or .csv and try again.')); };
            document.head.appendChild(sc);
        });
    }
    $('#imp-file').onclick = () => $('#imp-input').click();
    $('#imp-input').onchange = async () => {
        const f = $('#imp-input').files[0]; $('#imp-input').value = '';
        if (!f) return;
        const b = $('#imp-file'), old = b.textContent; b.disabled = true; b.textContent = 'Reading…';
        try {
            let rows;
            const ext = (f.name.split('.').pop() || '').toLowerCase();
            if (['csv', 'tsv', 'txt'].includes(ext)) rows = parseText(await f.text());
            else if (ext === 'xls') { const X = await loadSheetJs(); const wb = X.read(await f.arrayBuffer(), { type: 'array' }); rows = X.utils.sheet_to_json(wb.Sheets[wb.SheetNames[0]], { header: 1, raw: false, defval: '' }); }
            else if (ext === 'xlsx') {
                const fd = new FormData(); fd.append('file', f);
                const res = await fetch(`${API}?action=parse`, { method: 'POST', credentials: 'same-origin', body: fd });
                const d = await res.json().catch(() => ({ success: false, error: `Server error (HTTP ${res.status}).` }));
                if (!d.success && d.convert) { const X = await loadSheetJs(); const wb = X.read(await f.arrayBuffer(), { type: 'array' }); rows = X.utils.sheet_to_json(wb.Sheets[wb.SheetNames[0]], { header: 1, raw: false, defval: '' }); }
                else if (!d.success) throw new Error(d.error || 'Could not read the file.');
                else rows = d.rows;
            } else throw new Error('Choose a .csv, .xlsx or .xls file.');
            report2(applyMatrix(rows), f.name);
        } catch (e) { note(esc(e.message), 'bad'); }
        b.disabled = false; b.textContent = old;
    };
    $('#imp-paste').onclick = () => {
        const o = document.createElement('div');
        o.className = 'overlay';
        o.innerHTML = `<div class="dialog" role="dialog" aria-modal="true" aria-labelledby="pp-h" style="max-width:760px;">
            <h3 id="pp-h">Paste targets · ${esc(T.d.period_label)}</h3>
            <p class="muted" style="margin:0 0 10px;font-size:13px;">In Excel or Google Sheets select the table <b>with its headings</b> — Particulars down the first column,
            platforms (${esc(Object.values(T.d.platforms).join(', '))}) across the first row — copy it and paste below. The boxes are filled for you to check before saving.</p>
            <textarea id="pp-text" rows="12" style="width:100%;background:var(--surface-2);border:1px solid var(--border-strong);border-radius:8px;padding:10px;font:12px/1.5 'JetBrains Mono',monospace;color:inherit;resize:vertical;" placeholder="Particulars\tOverall\tMeta\tGoogle\nSpends\t1500000\t900000\t600000\nLeads (Workable)\t\t400\t250"></textarea>
            <div class="actions"><button class="btn" data-x>Cancel</button><button class="btn primary" data-ok>Fill the boxes</button></div></div>`;
        document.body.appendChild(o);
        const close = () => o.remove();
        o.querySelector('[data-x]').onclick = close;
        o.addEventListener('click', e => { if (e.target === o) close(); });
        o.addEventListener('keydown', e => { if (e.key === 'Escape') close(); });
        o.querySelector('[data-ok]').onclick = () => {
            const t = o.querySelector('#pp-text').value;
            if (!t.trim()) { o.querySelector('#pp-text').focus(); return; }
            try { report2(applyMatrix(parseText(t)), 'the pasted cells'); close(); }
            catch (e) { note(esc(e.message), 'bad'); close(); }
        };
        setTimeout(() => o.querySelector('#pp-text').focus(), 30);
    };
    // paste a block of cells into any box: fills from that box to the right and down (like Excel)
    document.addEventListener('paste', e => {
        const el = e.target;
        if (!(el instanceof HTMLInputElement) || !el.closest('table.tg') || el.disabled) return;
        const text = (e.clipboardData || window.clipboardData).getData('text');
        if (!/[\t\n]/.test(text.trim())) return;   // one value: normal paste
        e.preventDefault();
        const grid = parseText(text.replace(/\n$/, ''));
        const trs = [...document.querySelectorAll('table.tg tbody tr')].filter(tr => tr.querySelector('input'));
        const r0 = trs.indexOf(el.closest('tr')), c0 = [...el.closest('tr').querySelectorAll('input')].indexOf(el);
        let n = 0, bad = 0;
        grid.forEach((row, i) => {
            const tr = trs[r0 + i]; if (!tr) return;
            const ins = tr.querySelectorAll('input');
            row.forEach((raw, j) => {
                const inp = ins[c0 + j]; if (!inp || raw.trim() === '') return;
                const v = num(raw);
                if (v === null || Number.isNaN(v) || v < 0) { bad++; return; }
                inp.value = show(v, inp.dataset.f) || String(v); n++;
            });
        });
        hints(); if (n) dirty();
        note(`<b>${n} value${n === 1 ? '' : 's'}</b> pasted${bad ? ` · ${bad} cell${bad === 1 ? '' : 's'} skipped (not a number)` : ''}. Check them and click <b>Save targets</b>.`, n ? 'good' : 'warn');
    });
    // template = this table as CSV (current values filled in), the format Import reads back
    $('#tpl').onclick = () => {
        const d = T.d, pfs = Object.entries(d.platforms);
        const q = v => /[",\n]/.test(String(v)) ? `"${String(v).replace(/"/g, '""')}"` : String(v);
        const cell = (pf, kind, m) => { const el = document.querySelector(`input[data-pf="${pf}"][data-kind="${kind}"][data-m="${m}"]`); const v = el ? num(el.value) : null; return v === null || Number.isNaN(v) ? '' : v; };
        const lines = [['Particulars'].concat(pfs.map(([, n]) => n))];
        d.rows.forEach(r => lines.push([r.label].concat(pfs.map(([k]) => cell(k, 'target', r.key)))));
        lines.push(['Achieved (entered by hand)'].concat(pfs.map(() => '')));
        d.rows.filter(r => r.manual_actual).forEach(r => lines.push([r.label].concat(pfs.map(([k]) => cell(k, 'actual', r.key)))));
        const a = document.createElement('a');
        a.href = URL.createObjectURL(new Blob(['﻿' + lines.map(l => l.map(q).join(',')).join('\r\n')], { type: 'text/csv' }));
        a.download = `Targets_${T.key}.csv`;
        document.body.appendChild(a); a.click(); a.remove();
        setTimeout(() => URL.revokeObjectURL(a.href), 2000);
    };
    window.addEventListener('beforeunload', e => { if (T.dirty) { e.preventDefault(); e.returnValue = ''; } });
    load(new URLSearchParams(location.search).get('period') || '');
})();
</script>
</body>
</html>
