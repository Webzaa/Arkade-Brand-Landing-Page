<?php
/**
 * crm_push_api.php — backend of crm_push.php (leads that did not reach the CRM).
 *
 *   GET ?action=list&since=&until=&search=&tests=0|1  → counts by result, failure reasons, failed / not-sent leads
 *   GET ?action=counts                                 → all-time failed + not sent (sidebar badge)
 *   POST ?action=send  {"ids":[…]}                     → send failed / not-sent leads to Salesforce (max 25; needs CRM Push → Send)
 * Logic: app/Leads/crm_push.php
 */
session_start();
header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');
require_once dirname(__DIR__) . '/app/Leads/crm_send.php';

function crmReply(array $p, int $code = 200): never
{
    http_response_code($code);
    echo json_encode($p, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}
if (($_SESSION['user_logged'] ?? '') !== 'Y') {
    crmReply(['success' => false, 'error' => 'Please sign in again.'], 401);
}
$sendUser = (string) ($_SESSION['username'] ?? $_SESSION['user'] ?? 'admin');
session_write_close();
@set_time_limit(300);

$dbKey = (string) ($_GET['db'] ?? appDbKey());
if (!in_array($dbKey, leadDbKeys(), true)) {
    crmReply(['success' => false, 'error' => 'Unknown database.'], 400);
}
$db = leadDb($dbKey);
if (!$db) {
    crmReply(['success' => false, 'error' => leadDbLabel($dbKey) . ' database is not reachable.'], 500);
}
$date = fn($v) => (is_string($v) && preg_match('/^\d{4}-\d{2}-\d{2}$/', $v)) ? $v : '';

try {
    $action = (string) ($_GET['action'] ?? '');
    if ($action === 'list') {
        $r = crmList($db, ['since' => $date($_GET['since'] ?? ''), 'until' => $date($_GET['until'] ?? ''),
                           'search' => (string) ($_GET['search'] ?? ''), 'tests' => ($_GET['tests'] ?? '') === '1']);
        $send = crmSendStatus() + ['allowed' => !function_exists('pqCan') || pqCan('crm', 'send'),
                 'super' => function_exists('pqIsSuperadmin') && pqIsSuperadmin(), 'max' => CRM_SEND_MAX_BATCH];
        $r['rows'] = pqContactRows($r['rows']);      // Users & Roles: full mobile / email on screen and in the CSV, separately
        crmReply(['success' => true, 'db_label' => leadDbLabel($dbKey), 'states' => CRM_STATES, 'send' => $send] + $r);
    }
    if ($action === 'counts') {
        $r = crmList($db, []);
        crmReply(['success' => true, 'counts' => $r['counts'], 'problem' => $r['counts']['failed'] + $r['counts']['not_sent']]);
    }
    if ($action === 'send') {
        if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
            crmReply(['success' => false, 'error' => 'Use POST.'], 405);
        }
        if (function_exists('pqCan') && !pqCan('crm', 'send')) {
            crmReply(['success' => false, 'error' => "Your role can't send leads to the CRM."], 403);
        }
        $in = json_decode((string) file_get_contents('php://input'), true);
        $r = crmSendLeads($db, (array) ($in['ids'] ?? []), $sendUser);
        crmReply(['success' => true] + $r);
    }
    crmReply(['success' => false, 'error' => 'Unknown action.'], 400);
} catch (Throwable $e) {
    error_log('[crm_push_api] ' . $e->getMessage());
    crmReply(['success' => false, 'error' => $e->getMessage()], 500);
}
