<?php
/**
 * keywords.php — Keyword Analysis (Google): every keyword and search term of this project's Google campaigns with
 * Google's numbers (impressions, clicks, cost, conversions, quality score) next to the CRM's (leads, qualified,
 * site visits), and "Insights & Actions" for the execution team (what to push, cut, add as keyword or negative).
 * Opened inside dashboard.php (dates from the dashboard's date bar), or on its own.
 * Backend: keywords_api.php · logic: app/Ads/keywords.php. Access: Users & Roles → Keyword Analysis.
 */
session_start();
if (($_SESSION['user_logged'] ?? '') !== 'Y') {
    header('Location: login.php');
    exit;
}
require_once dirname(__DIR__) . '/app/Core/db.php';
$canView = pqCan('keywords');
?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Sora:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
<script>
(function () {
    var root = document.documentElement, t = null;
    try { t = localStorage.getItem('performiq-theme'); } catch (e) {}
    root.setAttribute('data-theme', t === 'light' ? 'light' : 'dark');
    if (/[?&]embed=1(&|$)/.test(location.search)) root.classList.add('pq-embed');
    window.addEventListener('storage', function (e) {
        if (e.key === 'performiq-theme') root.setAttribute('data-theme', e.newValue === 'light' ? 'light' : 'dark');
    });
    window.setTheme = function (t) { root.setAttribute('data-theme', t === 'light' ? 'light' : 'dark'); };
})();
</script>
<title>Keyword Analysis</title>
<?= function_exists('pqMetricGuardTag') ? pqMetricGuardTag('') : '' ?>
<?= function_exists('pqViewTag') ? pqViewTag('') : '' ?>
<?= function_exists('pqDatesTag') ? pqDatesTag('') : '' ?>
<style>
    :root, html[data-theme="dark"] {
        --bg: #0B0F1A; --surface: #111827; --surface-2: #161D2E; --border: #1E2A42; --border-strong: #2A3957;
        --text: #E2E8F0; --text-dim: #94A3B8; --text-faint: #64748B; --accent: #E8A820; --accent-soft: #E8A8201F;
        --hover: #1A2337; --good: #10B981; --good-soft: #10B9811F; --bad: #EF4444; --bad-soft: #EF44441A;
        --warn: #F59E0B; --warn-soft: #F59E0B1A; --info: #60A5FA; --info-soft: #60A5FA1A; --google: #D95926; color-scheme: dark;
    }
    html[data-theme="light"] {
        --bg: #F4F6FA; --surface: #FFFFFF; --surface-2: #F8FAFC; --border: #E2E8F0; --border-strong: #CBD5E1;
        --text: #0F172A; --text-dim: #475569; --text-faint: #94A3B8; --accent: #B7791F; --accent-soft: #B7791F1A;
        --hover: #F1F5F9; --good: #059669; --good-soft: #0596691A; --bad: #DC2626; --bad-soft: #DC26261A;
        --warn: #B45309; --warn-soft: #B453091A; --info: #2563EB; --info-soft: #2563EB14; --google: #C2410C; color-scheme: light;
    }
    * { box-sizing: border-box; }
    [hidden] { display: none !important; }
    body { margin: 0; background: var(--bg); color: var(--text); font: 14px/1.5 'Sora', system-ui, -apple-system, 'Segoe UI', sans-serif; }
    button, input, select { font: inherit; color: inherit; }
    .wrap { max-width: 1480px; margin: 0 auto; padding: 28px 24px 60px; }
    .pq-embed .wrap { padding-top: 18px; }
    .pq-embed .page-head, .pq-embed .own-dates { display: none !important; }
    h1 { font-size: 22px; margin: 0 0 4px; }
    h2 { font-size: 15px; margin: 0; }
    .sub { color: var(--text-dim); margin: 0 0 18px; font-size: 13px; }
    .card { background: var(--surface); border: 1px solid var(--border); border-radius: 12px; padding: 16px 18px; margin-bottom: 16px; min-width: 0; }
    .row { display: flex; gap: 10px; align-items: center; flex-wrap: wrap; }
    .grow { flex: 1 1 auto; }
    select, input[type=date], input[type=search] { background: var(--surface-2); border: 1px solid var(--border-strong); border-radius: 8px; padding: 7px 10px; outline: none; min-width: 0; }
    select:focus, input:focus { border-color: var(--accent); }
    .btn { border: 1px solid var(--border-strong); background: var(--surface-2); padding: 7px 13px; border-radius: 8px; cursor: pointer; font-weight: 600; font-size: 12.5px; white-space: nowrap; display: inline-flex; gap: 6px; align-items: center; }
    .btn:hover { background: var(--hover); }
    .btn.sm { padding: 4px 9px; font-size: 11.5px; }
    .btn:focus-visible, .tab:focus-visible, .chip:focus-visible, .ins-item:focus-visible, th button:focus-visible { outline: 2px solid var(--accent); outline-offset: 2px; }
    .tabs { display: inline-flex; gap: 4px; background: var(--surface-2); border: 1px solid var(--border); border-radius: 10px; padding: 3px; }
    .tab { border: 0; background: none; border-radius: 7px; padding: 6px 14px; font-size: 13px; cursor: pointer; color: var(--text-dim); font-weight: 600; }
    .tab.on { background: var(--surface); color: var(--text); box-shadow: 0 1px 0 var(--border-strong); }
    .tab .dot { display: inline-block; width: 8px; height: 8px; border-radius: 50%; margin-right: 6px; vertical-align: 1px; }
    .tab b { font-family: 'JetBrains Mono', monospace; font-weight: 500; margin-left: 4px; color: var(--text-faint); }
    .range { font-size: 12.5px; color: var(--text-dim); } .range b { color: var(--text); font-weight: 600; }
    .chip { border: 1px solid var(--border); background: var(--surface-2); border-radius: 99px; padding: 4px 11px; font-size: 12px; cursor: pointer; color: var(--text-dim); font-weight: 600; }
    .chip.on { border-color: var(--accent); color: var(--text); background: var(--accent-soft); }
    .chip b { margin-left: 4px; font-family: 'JetBrains Mono', monospace; font-weight: 500; }
    .pill { display: inline-flex; align-items: center; padding: 1px 7px; border-radius: 99px; font-size: 10.5px; font-weight: 600; white-space: nowrap; }
    .pill.good { color: var(--good); background: var(--good-soft); } .pill.bad { color: var(--bad); background: var(--bad-soft); }
    .pill.warn { color: var(--warn); background: var(--warn-soft); } .pill.info { color: var(--info); background: var(--info-soft); }
    .pill.dim { color: var(--text-dim); background: var(--surface-2); border: 1px solid var(--border); }
    .note { padding: 10px 14px; border-radius: 10px; font-size: 12.5px; margin-bottom: 14px; border: 1px solid; }
    .note.warn { background: var(--warn-soft); border-color: var(--warn); }
    .muted { color: var(--text-dim); } .faint { color: var(--text-faint); font-size: 11.5px; }
    .spinner { width: 15px; height: 15px; border: 2px solid var(--border-strong); border-top-color: var(--accent); border-radius: 50%; display: inline-block; animation: spin .8s linear infinite; vertical-align: -3px; margin-right: 8px; }
    @keyframes spin { to { transform: rotate(360deg); } }

    .totals { display: grid; grid-template-columns: repeat(auto-fit, minmax(118px, 1fr)); gap: 10px; margin: 0 0 16px; }
    .tot { background: var(--surface); border: 1px solid var(--border); border-radius: 10px; padding: 10px 12px; }
    .tot div { color: var(--text-dim); font-size: 11px; text-transform: uppercase; letter-spacing: .05em; }
    .tot strong { display: block; font-size: 19px; margin-top: 2px; font-family: 'JetBrains Mono', monospace; font-weight: 500; }
    .tot small { color: var(--text-faint); font-size: 11px; }

    .ins-head { display: flex; gap: 10px; align-items: center; flex-wrap: wrap; margin-bottom: 10px; }
    .ins-list { display: grid; grid-template-columns: repeat(auto-fill, minmax(330px, 1fr)); gap: 10px; }
    .ins-item { border: 1px solid var(--border); background: var(--surface-2); border-radius: 10px; padding: 11px 12px; text-align: left; }
    .ins-item[data-ref] { cursor: pointer; } .ins-item[data-ref]:hover { border-color: var(--border-strong); }
    .ins-title { font-weight: 600; font-size: 13px; display: flex; gap: 7px; align-items: baseline; }
    .ins-title > span:last-child { min-width: 0; overflow-wrap: anywhere; }
    .ins-text { font-size: 12.5px; color: var(--text-dim); margin-top: 3px; }
    .ins-act { font-size: 12.5px; margin-top: 5px; } .ins-act b { color: var(--accent); font-weight: 600; }
    .sev { width: 9px; height: 9px; border-radius: 50%; flex: none; display: inline-block; }
    .sev.good { background: var(--good); } .sev.bad { background: var(--bad); } .sev.warn { background: var(--warn); } .sev.info { background: var(--info); }
    .ins-empty { padding: 12px; border: 1px dashed var(--border-strong); border-radius: 10px; color: var(--text-dim); font-size: 13px; }

    .tbl-head { display: flex; gap: 10px; align-items: center; flex-wrap: wrap; margin-bottom: 12px; }
    .tbl-wrap { overflow: auto; border: 1px solid var(--border); border-radius: 10px; max-height: 70vh; }
    table { width: 100%; border-collapse: collapse; font-size: 12.5px; }
    th { position: sticky; top: 0; z-index: 1; background: var(--surface-2); color: var(--text-dim); font-weight: 600; text-align: right; padding: 0;
         border-bottom: 1px solid var(--border); white-space: nowrap; font-size: 11px; text-transform: uppercase; letter-spacing: .04em; }
    th button { all: unset; display: block; padding: 8px 10px; cursor: pointer; width: 100%; box-sizing: border-box; text-align: inherit; }
    th button:hover { color: var(--text); } th .ar { color: var(--accent); margin-left: 3px; }
    td { padding: 8px 10px; border-bottom: 1px solid var(--border); text-align: right; white-space: nowrap; font-family: 'JetBrains Mono', monospace; font-size: 12px; }
    th:first-child, td:first-child { text-align: left; font-family: inherit; white-space: normal; min-width: 260px; }
    tr:last-child td { border-bottom: 0; }
    tr.flash td { animation: flash 1.8s ease-out; }
    @keyframes flash { 0% { background: var(--accent-soft); } 100% { background: transparent; } }
    .kw { font-weight: 600; font-size: 13px; overflow-wrap: anywhere; }
    .where { font-size: 11px; color: var(--text-faint); margin-top: 2px; }
    .tags { display: inline-flex; gap: 4px; margin-left: 6px; vertical-align: 1px; flex-wrap: wrap; }
    .qs { display: inline-block; min-width: 26px; text-align: center; border-radius: 6px; padding: 0 4px; font-weight: 600; }
    .qs.lo { color: var(--bad); background: var(--bad-soft); } .qs.mid { color: var(--warn); background: var(--warn-soft); } .qs.hi { color: var(--good); background: var(--good-soft); }
    .zero { color: var(--bad); }
    .more { display: flex; gap: 12px; align-items: center; justify-content: center; padding: 14px 0 2px; }
    .empty { padding: 30px; text-align: center; color: var(--text-dim); }
    @media (prefers-reduced-motion: reduce) { .spinner { animation: none; } tr.flash td { animation: none; } }
    @media (max-width: 640px) { .wrap { padding: 16px 16px 40px; } .ins-list { grid-template-columns: 1fr; } }
</style>
</head>
<body>
<div class="wrap">
    <div class="page-head">
        <h1>Keyword Analysis</h1>
        <p class="sub">Google keywords and search terms with the CRM's leads, qualified leads and site visits — and what to do next.</p>
    </div>

    <?php if (!$canView) { ?>
        <div class="empty">Your role doesn't include Keyword Analysis. Ask a Super Admin for access.</div>
    <?php } else { ?>
    <div class="row" style="margin-bottom:14px">
        <div class="tabs" role="group" id="state-tabs" aria-label="Show running or paused keywords">
            <button class="tab" data-st="all" title="Every keyword with impressions or leads">All</button>
            <button class="tab" data-st="running" title="Keyword, ad group and campaign are all on"><span class="dot" style="background:var(--good)"></span>Running</button>
            <button class="tab" data-st="paused" title="Keyword, its ad group or its campaign is paused"><span class="dot" style="background:var(--text-faint)"></span>Paused</button>
        </div>
        <div id="cv-host" title="All / Performance / Awareness — the same tabs as the dashboards"></div>
        <span class="range" id="range-label"></span>
        <span class="own-dates row">
            <button class="btn sm" type="button" data-qd="0">Today</button><button class="btn sm" type="button" data-qd="1">Yesterday</button><button class="btn sm" type="button" data-qr="last_1y" title="The last 12 months, till today">1 year</button><button class="btn sm" type="button" data-qr="all_time" title="From the first lead of this project till today">All time</button>
            <input type="date" id="d-since" aria-label="From"> <span class="faint">to</span> <input type="date" id="d-until" aria-label="To">
            <button class="btn sm" id="d-apply">Show</button>
        </span>
        <span class="grow"></span>
        <button class="btn sm" id="export-btn" hidden>↓ Export CSV</button>
        <button class="btn sm" id="reload-btn" title="Read Google and the CRM again">Refresh</button>
    </div>

    <div id="notes"></div>
    <div class="totals" id="totals"></div>

    <section class="card" aria-labelledby="ins-h">
        <div class="ins-head">
            <h2 id="ins-h">Insights &amp; Actions</h2>
            <span class="pill dim">Rules · numbers from Google + CRM</span>
            <span class="faint" id="ins-bench"></span>
        </div>
        <div class="ins-list" id="ins-list"><div class="ins-empty"><span class="spinner"></span>Reading the numbers…</div></div>
    </section>

    <section class="card" aria-label="Keywords and search terms">
        <div class="tbl-head">
            <div class="tabs" role="tablist" id="view-tabs">
                <button class="tab" role="tab" data-v="keywords">Keywords <b id="n-keywords"></b></button>
                <button class="tab" role="tab" data-v="terms">Search terms <b id="n-terms"></b></button>
            </div>
            <div class="row" id="chips"></div>
            <span class="grow"></span>
            <input type="search" id="q" placeholder="Search keyword, campaign…" aria-label="Search" style="width:220px">
        </div>
        <p class="faint" id="tbl-note" style="margin:-4px 0 10px"></p>
        <div class="tbl-wrap"><table id="tbl"><thead></thead><tbody><tr><td class="muted"><span class="spinner"></span>Loading…</td></tr></tbody></table></div>
        <div class="more" id="more" hidden><button class="btn" id="more-btn" type="button">Show more</button><span class="faint" id="more-note"></span></div>
    </section>
    <?php } ?>
</div>

<?php if ($canView) { ?>
<script>
(function () {
    'use strict';
    const API = 'keywords_api.php';
    const PAGE = 50;
    const $ = s => document.querySelector(s), $$ = s => [...document.querySelectorAll(s)];
    const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
    const has = v => v !== null && v !== undefined && v !== '' && isFinite(v);
    const money = v => has(v) ? '₹' + Math.round(v).toLocaleString('en-IN') : '—';
    const money2 = v => has(v) ? '₹' + Number(v).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) : '—';
    const int = v => has(v) ? Math.round(v).toLocaleString('en-IN') : '—';
    const pct = v => has(v) ? Number(v).toFixed(2) + '%' : '—';
    const dec = v => has(v) ? (Math.round(v * 10) / 10).toLocaleString('en-IN') : '—';
    const ymd = d => d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
    const store = { get(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }, set(k, v) { try { localStorage.setItem(k, v); } catch (e) {} } };

    const S = { since: '', until: '', data: null, req: 0, view: store.get('pq-kw-view') === 'terms' ? 'terms' : 'keywords',
                state: ['all', 'running', 'paused'].includes(store.get('pq-kw-state')) ? store.get('pq-kw-state') : 'all',
                chip: 'all', sort: { keywords: ['spend', -1], terms: ['spend', -1] }, shown: PAGE, flash: null };

    // dates: from the dashboard (?since&until, then pq-range messages), else the last 7 days
    (function () {
        const p = new URLSearchParams(location.search);
        let s = p.get('since'), u = p.get('until');
        if (!/^\d{4}-\d{2}-\d{2}$/.test(s || '') || !/^\d{4}-\d{2}-\d{2}$/.test(u || '')) {
            const y = new Date(); y.setDate(y.getDate() - 1);
            const a = new Date(y); a.setDate(a.getDate() - 6);
            s = ymd(a); u = ymd(y);
        }
        S.since = s; S.until = u; $('#d-since').value = s; $('#d-until').value = u;
    })();
    window.addEventListener('message', e => {
        const d = e.data || {};
        if (d.type === 'pq-range' && d.since && d.until && (d.since !== S.since || d.until !== S.until)) { S.since = d.since; S.until = d.until; load(); }
    });
    // Today / Yesterday (on its own; inside the dashboard the date bar at the top does this)
    // Last 1 year / All time (assets/js/date_presets.js)
    document.querySelectorAll('[data-qr]').forEach(btn => btn.onclick = () => {
        const x = window.PQDates && PQDates.range(btn.dataset.qr); if (!x) return;
        S.since = x.since; S.until = x.until; $('#d-since').value = S.since; $('#d-until').value = S.until; load();
    });
    document.querySelectorAll('[data-qd]').forEach(btn => btn.onclick = () => {
        const d = new Date(); d.setDate(d.getDate() - +btn.dataset.qd);
        S.since = S.until = ymd(d); $('#d-since').value = $('#d-until').value = S.since; load();
    });
    $('#d-apply').onclick = () => {
        const s = $('#d-since').value, u = $('#d-until').value;
        if (!s || !u || s > u) { $('#d-since').focus(); return; }
        S.since = s; S.until = u; load();
    };
    $('#reload-btn').onclick = () => load(true);
    $('#q').oninput = () => { S.shown = PAGE; renderTable(); };
    $('#more-btn').onclick = () => { S.shown += PAGE; renderTable(); };
    if ('IntersectionObserver' in window) {
        new IntersectionObserver(es => { if (es.some(x => x.isIntersecting) && !$('#more').hidden) { S.shown += PAGE; renderTable(); } }, { rootMargin: '300px' }).observe($('#more'));
    }
    function setState(v) {
        S.state = v; store.set('pq-kw-state', v);
        $$('#state-tabs .tab').forEach(b => { const on = b.dataset.st === v; b.classList.toggle('on', on); b.setAttribute('aria-pressed', on ? 'true' : 'false'); });
    }
    function setView(v) {
        S.view = v; store.set('pq-kw-view', v); S.chip = 'all'; S.shown = PAGE;
        $$('#view-tabs .tab').forEach(b => { const on = b.dataset.v === v; b.classList.toggle('on', on); b.setAttribute('aria-selected', on ? 'true' : 'false'); });
    }
    setState(S.state); setView(S.view);
    $$('#state-tabs .tab').forEach(b => b.onclick = () => { setState(b.dataset.st); S.shown = PAGE; if (S.data) { renderInsights(); renderChips(); renderTable(); } });
    $$('#view-tabs .tab').forEach(b => b.onclick = () => { setView(b.dataset.v); if (S.data) { renderChips(); renderTable(); } });

    async function load(force) {
        const id = ++S.req;
        $('#range-label').innerHTML = 'Loading <b>' + esc(S.since) + ' – ' + esc(S.until) + '</b>…';
        $('#ins-list').innerHTML = '<div class="ins-empty"><span class="spinner"></span>Reading Google and the CRM…</div>';
        $('#tbl tbody').innerHTML = '<tr><td class="muted"><span class="spinner"></span>Loading…</td></tr>';
        $('#notes').innerHTML = ''; $('#totals').innerHTML = '';
        try {
            const res = await fetch(API + '?' + new URLSearchParams(Object.assign({ since: S.since, until: S.until }, force ? { force: 1 } : {})), { credentials: 'same-origin' });
            let d = null;
            try { d = await res.json(); } catch (e) { throw new Error('The server did not answer (HTTP ' + res.status + ').'); }
            if (!res.ok || !d.success) throw new Error(d && d.error ? d.error : 'Could not load (HTTP ' + res.status + ').');
            if (id !== S.req) return;
            S.data = d; S.shown = PAGE;
            $('#export-btn').hidden = !d.can_export;
            $('#range-label').innerHTML = '<b>' + esc(d.label) + '</b> · Google Ads + CRM leads';
            $('#notes').innerHTML = (d.warnings || []).map(w => '<div class="note warn">' + esc(w) + '</div>').join('');
            renderTotals(); renderInsights(); renderChips(); renderTable();
        } catch (e) {
            if (id !== S.req) return;
            $('#range-label').textContent = '';
            $('#ins-list').innerHTML = '<div class="ins-empty">—</div>';
            $('#tbl tbody').innerHTML = '<tr><td class="empty">' + esc(e.message) + '</td></tr>';
        }
    }

    const showQl = () => S.data && 'ql' in S.data.total;
    const showSv = () => S.data && 'sv' in S.data.total;
    const showCpql = () => S.data && 'cpql' in S.data.total;
    const showCpsv = () => S.data && 'cpsv' in S.data.total;

    function renderTotals() {
        const t = S.data.total, nk = S.data.no_keyword || {};
        const tile = (l, v, s) => '<div class="tot"><div>' + l + '</div><strong>' + v + '</strong>' + (s ? '<small>' + s + '</small>' : '') + '</div>';
        let h = tile('Spend', money(t.spend), int(t.keywords) + ' keywords')
            + tile('Clicks', int(t.clicks), 'CTR ' + pct(t.ctr))
            + tile('Avg CPC', money2(t.cpc))
            + tile('Google conv.', dec(t.conversions))
            + tile('Leads (CRM)', int(t.leads), nk.leads ? int(nk.leads) + ' without a keyword' : 'all with a keyword')
            + tile('CPL', money(t.cpl));
        if (showQl()) h += tile('Qualified', int(t.ql), has(t.ql_pct) ? pct(t.ql_pct) + ' of leads' : '');
        if (showCpql()) h += tile('CPQL', money(t.cpql));
        if (showSv()) h += tile('Site visits', int(t.sv));
        if (showCpsv()) h += tile('CPSV', money(t.cpsv));
        $('#totals').innerHTML = h;
        $('#ins-bench').textContent = 'Benchmark: CPL ' + money(t.cpl) + (showCpql() && has(t.cpql) ? ' · CPQL ' + money(t.cpql) : '');
    }

    const stateOk = r => S.state === 'all' || r.state === S.state;   // CRM-only keywords (status unknown) show under All
    const kwById = id => (S.data.keywords || []).find(k => k.id === id);

    function renderInsights() {
        const list = (S.data.insights || []).filter(f => {
            if (S.state === 'all' || f.tab !== 'keywords' || !f.ref) return true;
            const k = kwById(f.ref); return !k || stateOk(k);
        });
        if (!list.length) {
            $('#ins-list').innerHTML = '<div class="ins-empty">' + ((S.data.insights || []).length ? 'No finding for ' + S.state + ' keywords. Choose All to see every finding.'
                : 'Nothing stands out for these dates — not enough spend or leads yet. Try a longer date range.') + '</div>';
            return;
        }
        $('#ins-list').innerHTML = list.map(f => '<div class="ins-item"' + (f.ref ? ' data-ref="' + esc(f.ref) + '" data-tab="' + esc(f.tab) + '" role="button" tabindex="0"' : '') + '>'
            + '<div class="ins-title"><span class="sev ' + esc(f.severity) + '" aria-hidden="true"></span><span>' + esc(f.title) + '</span></div>'
            + '<div class="ins-text">' + esc(f.text) + '</div><div class="ins-act"><b>Next step:</b> ' + esc(f.action) + '</div></div>').join('');
        $$('#ins-list [data-ref]').forEach(el => {
            const go = () => {
                setView(el.dataset.tab === 'terms' ? 'terms' : 'keywords');
                $('#q').value = '';
                if (S.view === 'keywords') { const k = kwById(el.dataset.ref); if (k && !stateOk(k)) setState('all'); }
                const rows = filtered(), i = rows.findIndex(r => r.id === el.dataset.ref);
                S.shown = Math.max(PAGE, Math.ceil((i + 1) / PAGE) * PAGE);
                S.flash = el.dataset.ref;
                renderChips(); renderTable();
                const tr = $$('#tbl tbody tr').find(t => t.dataset.id === el.dataset.ref);
                if (tr) tr.scrollIntoView({ behavior: 'smooth', block: 'center' });
            };
            el.onclick = go;
            el.onkeydown = e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); go(); } };
        });
    }

    /* filter chips */
    const KW_CHIPS = {
        all: ['All', () => true],
        leads: ['With leads', r => r.leads > 0],
        noleads: ['Spend, no leads', r => r.spend > 0 && !r.leads],
        lowqs: ['Quality score ≤ 4', r => r.qs !== null && r.qs <= 4],
        crm: ['Only in the CRM', r => !!r.crm_only],
    };
    const TERM_CHIPS = {
        all: ['All', () => true],
        conv: ['Converting', r => r.conversions > 0],
        newkw: ['Converting, not a keyword', r => r.conversions > 0 && !r.is_keyword],
        waste: ['Spend, no conversion', r => r.spend > 0 && r.conversions <= 0 && !r.excluded],
        excluded: ['Excluded', r => r.excluded],
    };
    const chipsFor = () => S.view === 'keywords' ? KW_CHIPS : TERM_CHIPS;
    function base() {
        return S.view === 'keywords' ? (S.data.keywords || []).filter(stateOk) : (S.data.search_terms || []);
    }
    function renderChips() {
        const C = chipsFor(), rows = base();
        if (!C[S.chip]) S.chip = 'all';
        $('#n-keywords').textContent = (S.data.keywords || []).filter(stateOk).length;
        $('#n-terms').textContent = (S.data.search_terms || []).length;
        $('#chips').innerHTML = Object.entries(C).map(([k, [l, fn]]) => {
            const n = rows.filter(fn).length;
            return (k === 'all' || n) ? '<button class="chip' + (S.chip === k ? ' on' : '') + '" data-c="' + k + '">' + l + ' <b>' + n + '</b></button>' : '';
        }).join('');
        $$('#chips .chip').forEach(b => b.onclick = () => { S.chip = b.dataset.c; S.shown = PAGE; renderChips(); renderTable(); });
        $('#tbl-note').textContent = S.view === 'keywords'
            ? 'Leads come from the CRM (the keyword saved on each Google lead), one per person. "Only in the CRM" = a keyword on leads that had no impressions in these dates.'
            : 'What people actually typed. "Keyword" = already a keyword; "Excluded" = already a negative. Google conversions, not CRM leads (a lead does not carry its search term).';
    }

    function columns() {
        if (S.view === 'keywords') {
            const c = [['text', 'Keyword'], ['state', 'Status'], ['qs', 'QS'], ['impressions', 'Impr.'], ['clicks', 'Clicks'], ['ctr', 'CTR'], ['cpc', 'CPC'],
                       ['spend', 'Spend'], ['conversions', 'Conv.'], ['leads', 'Leads'], ['cpl', 'CPL']];
            if (showQl()) c.push(['ql', 'QL']);
            if (showCpql()) c.push(['cpql', 'CPQL']);
            if (showSv()) c.push(['sv', 'Visits']);
            if (showCpsv()) c.push(['cpsv', 'CPSV']);
            return c;
        }
        return [['term', 'Search term'], ['impressions', 'Impr.'], ['clicks', 'Clicks'], ['ctr', 'CTR'], ['cpc', 'CPC'], ['spend', 'Spend'], ['conversions', 'Conv.']];
    }
    function filtered() {
        const q = $('#q').value.trim().toLowerCase();
        const fn = chipsFor()[S.chip] ? chipsFor()[S.chip][1] : () => true;
        const [k, dir] = S.sort[S.view];
        const rows = base().filter(r => fn(r) && (!q || [r.text, r.term, r.keyword, r.campaign, r.adgroup].filter(Boolean).join(' ').toLowerCase().includes(q)));
        return rows.sort((a, b) => {
            const x = a[k], y = b[k];
            if (typeof x === 'string' || typeof y === 'string') return dir * String(x || '').localeCompare(String(y || ''));
            if (!has(x) && !has(y)) return b.spend - a.spend;
            if (!has(x)) return 1;
            if (!has(y)) return -1;
            return dir * (x - y);
        });
    }
    const MATCH = { EXACT: 'Exact', PHRASE: 'Phrase', BROAD: 'Broad' };
    function cell(r, k) {
        switch (k) {
            case 'text': return '<div class="kw">' + esc(r.text) + '<span class="tags">' + (r.match ? '<span class="pill dim">' + esc(MATCH[r.match] || r.match.toLowerCase()) + '</span>' : '')
                + (r.crm_only ? '<span class="pill info" title="On CRM leads, but no impressions in these dates">CRM only</span>' : '') + '</span></div>'
                + '<div class="where">' + esc(r.campaign) + (r.adgroup ? ' › ' + esc(r.adgroup) : '') + '</div>';
            case 'term': return '<div class="kw">' + esc(r.term) + '<span class="tags">' + (r.excluded ? '<span class="pill bad">Excluded</span>' : (r.is_keyword ? '<span class="pill good">Keyword</span>' : '<span class="pill warn">New</span>')) + '</span></div>'
                + '<div class="where">' + (r.keyword ? 'via "' + esc(r.keyword) + '" · ' : '') + esc(r.campaign) + (r.adgroup ? ' › ' + esc(r.adgroup) : '') + '</div>';
            case 'state': return r.state === 'running' ? '<span class="pill good">Running</span>' : (r.state === 'paused' ? '<span class="pill dim">Paused</span>' : '<span class="faint">—</span>');
            case 'qs': return has(r.qs) ? '<span class="qs ' + (r.qs <= 4 ? 'lo' : r.qs <= 6 ? 'mid' : 'hi') + '">' + r.qs + '</span>' : '<span class="faint">—</span>';
            case 'spend': case 'cpl': case 'cpql': case 'cpsv': return money(r[k]);
            case 'cpc': return money2(r[k]);
            case 'ctr': return pct(r[k]);
            case 'conversions': return dec(r[k]);
            case 'leads': return r.spend > 0 && !r.leads ? '<span class="zero">0</span>' : int(r[k]);
            default: return int(r[k]);
        }
    }
    function renderTable() {
        const cols = columns(), [sk, sd] = S.sort[S.view];
        $('#tbl thead').innerHTML = '<tr>' + cols.map(([k, l]) => '<th aria-sort="' + (k === sk ? (sd > 0 ? 'ascending' : 'descending') : 'none') + '"><button type="button" data-k="' + k + '">' + l
            + (k === sk ? '<span class="ar">' + (sd > 0 ? '↑' : '↓') + '</span>' : '') + '</button></th>').join('') + '</tr>';
        $$('#tbl thead button').forEach(b => b.onclick = () => {
            const k = b.dataset.k, cur = S.sort[S.view];
            S.sort[S.view] = [k, cur[0] === k ? -cur[1] : (['text', 'term', 'cpl', 'cpql', 'cpsv', 'cpc'].includes(k) ? 1 : -1)];
            S.shown = PAGE; renderTable();
        });
        const rows = filtered(), show = rows.slice(0, S.shown);
        if (!rows.length) {
            const none = S.view === 'keywords'
                ? (S.data.configured ? 'No keyword matches.' : 'Google Ads is not connected, and no lead in these dates carries a keyword.')
                : 'No search term matches.';
            $('#tbl tbody').innerHTML = '<tr><td colspan="' + cols.length + '" class="empty">' + none + '</td></tr>';
        } else {
            $('#tbl tbody').innerHTML = show.map(r => '<tr data-id="' + esc(r.id) + '"' + (r.id === S.flash ? ' class="flash"' : '') + '>' + cols.map(([k]) => '<td>' + cell(r, k) + '</td>').join('') + '</tr>').join('');
        }
        S.flash = null;
        $('#more').hidden = show.length >= rows.length;
        $('#more-note').textContent = show.length < rows.length ? 'Showing ' + show.length + ' of ' + rows.length : '';
    }

    // Export CSV (Users & Roles → Keyword Analysis → Export CSV): the table as filtered and sorted now
    $('#export-btn').onclick = () => {
        if (!S.data) return;
        const cols = columns().map(([k, l]) => [k, l]);
        if (S.view === 'keywords') cols.splice(1, 0, ['match', 'Match'], ['campaign', 'Campaign'], ['adgroup', 'Ad group']);
        else cols.splice(1, 0, ['tag', 'Type'], ['keyword', 'Matched keyword'], ['campaign', 'Campaign'], ['adgroup', 'Ad group']);
        const q = v => '"' + String(v ?? '').replace(/"/g, '""') + '"';
        const val = (r, k) => k === 'tag' ? (r.excluded ? 'Excluded' : (r.is_keyword ? 'Keyword' : 'New')) : (r[k] ?? '');
        const lines = [cols.map(c => q(c[1])).join(',')].concat(filtered().map(r => cols.map(([k]) => q(val(r, k))).join(',')));
        const a = document.createElement('a');
        a.href = URL.createObjectURL(new Blob(['﻿' + lines.join('\r\n')], { type: 'text/csv' }));
        a.download = (S.view === 'keywords' ? 'Keywords_' : 'Search_terms_') + S.since + '_to_' + S.until + '.csv';
        document.body.appendChild(a); a.click(); a.remove();
        setTimeout(() => URL.revokeObjectURL(a.href), 2000);
    };

    // All / Performance / Awareness (same tabs and cookie as the dashboards; the server filters the campaigns)
    if (window.PQView) PQView.mount(document.getElementById('cv-host'), { onChange: () => load() });
    load();
})();
</script>
<?php } ?>
</body>
</html>
