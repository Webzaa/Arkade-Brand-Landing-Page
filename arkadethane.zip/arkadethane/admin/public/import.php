<?php
session_start();
// ini_set('display_errors', '1');
// ini_set('display_startup_errors', '1');
// error_reporting(E_ALL);

// ===== Auth check BEFORE any import work (previously anyone could POST a file) =====
if (!isset($_SESSION["user_logged"]) || $_SESSION["user_logged"] != "Y") {
  header("Location: login.php");
  exit;
}

include dirname(__DIR__) . '/app/Core/db.php';
date_default_timezone_set('Asia/Kolkata');

/* =====================================================================
 * SETTINGS — change these to match the values your dashboards filter on
 * ===================================================================== */
const IMPORT_SOURCE_META   = 'Facebook';   // saved in lead.campaignsource for Meta leads
const IMPORT_SOURCE_GOOGLE = 'Google';     // saved in lead.campaignsource for Google leads
const IMPORT_DEFAULT_CC    = '+91';        // country code used when the phone has none
const IMPORT_MAX_BYTES     = 10 * 1024 * 1024;

/* =====================================================================
 * FILE READERS  →  each returns an array of rows (row = array of strings)
 * Supports: Meta "Download leads" .xls (SpreadsheetML XML), .xlsx,
 *           .csv / .tsv (UTF-8 or UTF-16, comma / tab / semicolon)
 * ===================================================================== */
function imp_read_file(string $path, string $origName, ?string &$err): array
{
  $head = (string) file_get_contents($path, false, null, 0, 2048);

  // Old binary Excel 97-2003 (.xls BIFF)
  if (strncmp($head, "\xD0\xCF\x11\xE0", 4) === 0) {
    $autoload = dirname(__DIR__) . '/vendor/autoload.php';
    if (is_file($autoload)) {
      require_once $autoload;
      if (class_exists('\PhpOffice\PhpSpreadsheet\IOFactory')) {
        $sheet = \PhpOffice\PhpSpreadsheet\IOFactory::load($path)->getActiveSheet();
        return array_map(fn($r) => array_map('strval', $r), $sheet->toArray(null, false, false, false));
      }
    }
    $err = "This is an old binary .xls file. Open it in Excel and Save As .xlsx or .csv, then import again.";
    return [];
  }
  // .xlsx (zip)
  if (strncmp($head, "PK", 2) === 0) {
    return imp_read_xlsx($path, $err);
  }
  // SpreadsheetML 2003 XML — this is what Meta Ads Manager's "Download leads (.xls)" gives you
  $trim = ltrim(preg_replace('/^\xEF\xBB\xBF/', '', $head));
  if (strpos($trim, '<?xml') === 0 || stripos($head, '<Workbook') !== false) {
    return imp_read_spreadsheetml($path, $err);
  }
  return imp_read_csv($path, $err);
}

function imp_read_spreadsheetml(string $path, ?string &$err): array
{
  libxml_use_internal_errors(true);
  $xml = simplexml_load_file($path, 'SimpleXMLElement', LIBXML_NONET | LIBXML_COMPACT);
  if ($xml === false) {
    $err = "Could not read the Excel XML file.";
    return [];
  }
  $ns = 'urn:schemas-microsoft-com:office:spreadsheet';
  $rows = [];
  $ws = $xml->children($ns)->Worksheet[0] ?? null;
  if (!$ws) {
    $err = "No worksheet found in the file.";
    return [];
  }
  foreach ($ws->children($ns)->Table->children($ns)->Row as $r) {
    $row = [];
    $col = 0;
    foreach ($r->children($ns)->Cell as $c) {
      $idx = (int) ($c->attributes($ns)['Index'] ?? 0);
      if ($idx > 0) $col = $idx - 1;         // ss:Index skips empty cells
      $data = $c->children($ns)->Data;
      $row[$col] = $data !== null ? trim((string) $data) : '';
      $col++;
    }
    if ($row) {
      $max = max(array_keys($row));
      $row = array_replace(array_fill(0, $max + 1, ''), $row);
    }
    $rows[] = $row;
  }
  return $rows;
}

function imp_read_xlsx(string $path, ?string &$err): array
{
  if (!class_exists('ZipArchive')) {
    $err = "PHP zip extension is missing on the server — save the file as .csv and import again.";
    return [];
  }
  $zip = new ZipArchive();
  if ($zip->open($path) !== true) {
    $err = "Could not open the .xlsx file.";
    return [];
  }
  $shared = [];
  if (($s = $zip->getFromName('xl/sharedStrings.xml')) !== false) {
    $sx = simplexml_load_string($s, 'SimpleXMLElement', LIBXML_NONET);
    foreach ($sx->si as $si) {
      if (isset($si->t)) {
        $shared[] = (string) $si->t;
      } else {
        $t = '';
        foreach ($si->r as $run) $t .= (string) $run->t;
        $shared[] = $t;
      }
    }
  }
  $sheetXml = $zip->getFromName('xl/worksheets/sheet1.xml');
  if ($sheetXml === false) {
    for ($i = 0; $i < $zip->numFiles; $i++) {
      $n = $zip->getNameIndex($i);
      if (preg_match('#^xl/worksheets/[^/]+\.xml$#', $n)) {
        $sheetXml = $zip->getFromName($n);
        break;
      }
    }
  }
  $zip->close();
  if ($sheetXml === false) {
    $err = "No worksheet found in the .xlsx file.";
    return [];
  }
  $sx = simplexml_load_string($sheetXml, 'SimpleXMLElement', LIBXML_NONET);
  $rows = [];
  foreach ($sx->sheetData->row as $r) {
    $row = [];
    foreach ($r->c as $c) {
      $ref = preg_replace('/\d+/', '', (string) $c['r']);
      $ci = 0;
      foreach (str_split($ref) as $ch) $ci = $ci * 26 + (ord($ch) - 64);
      $type = (string) $c['t'];
      if ($type === 's')            $v = $shared[(int) $c->v] ?? '';
      elseif ($type === 'inlineStr') $v = (string) $c->is->t;
      else                          $v = (string) $c->v;
      $row[$ci - 1] = trim($v);
    }
    if ($row) {
      $max = max(array_keys($row));
      $row = array_replace(array_fill(0, $max + 1, ''), $row);
    }
    $rows[] = $row;
  }
  return $rows;
}

function imp_read_csv(string $path, ?string &$err): array
{
  $raw = (string) file_get_contents($path);
  // Meta's CSV export is UTF-16 LE, tab separated
  if (strncmp($raw, "\xFF\xFE", 2) === 0)      $raw = mb_convert_encoding(substr($raw, 2), 'UTF-8', 'UTF-16LE');
  elseif (strncmp($raw, "\xFE\xFF", 2) === 0)  $raw = mb_convert_encoding(substr($raw, 2), 'UTF-8', 'UTF-16BE');
  $raw = preg_replace('/^\xEF\xBB\xBF/', '', $raw);

  $firstLine = strtok($raw, "\n");
  $delims = [",", "\t", ";"];
  $best = ",";
  $bestCount = 0;
  foreach ($delims as $d) {
    $n = substr_count((string) $firstLine, $d);
    if ($n > $bestCount) {
      $best = $d;
      $bestCount = $n;
    }
  }
  $fh = fopen('php://temp', 'r+');
  fwrite($fh, $raw);
  rewind($fh);
  $rows = [];
  while (($data = fgetcsv($fh, 0, $best, '"', '\\')) !== false) {
    if ($data === [null]) continue;
    $rows[] = array_map(fn($v) => trim((string) $v), $data);
  }
  fclose($fh);
  if (!$rows) $err = "The file is empty.";
  return $rows;
}

/* =====================================================================
 * HEADER MAPPING
 * ===================================================================== */
function imp_norm_header(string $h): string
{
  $h = strtolower(trim(preg_replace('/^\xEF\xBB\xBF/', '', $h)));
  $h = preg_replace('/[^a-z0-9]+/', '_', $h);
  return trim($h, '_');
}

// field => list of accepted (normalised) header names, first match wins
function imp_aliases(): array
{
  return [
    'lead_id'       => ['id', 'lead_id', 'leadgen_id', 'leadid'],
    'created'       => ['created_time', 'createddate', 'created_date', 'submission_time', 'submitted_at', 'submit_time', 'lead_submit_time', 'submission_date', 'date', 'timestamp', 'time'],
    'full_name'     => ['full_name', 'name', 'user_name', 'fullname', 'customer_name'],
    'first_name'    => ['first_name', 'firstname'],
    'last_name'     => ['last_name', 'lastname', 'surname'],
    'email'         => ['email', 'email_address', 'user_email', 'work_email'],
    'phone'         => ['phone', 'phone_number', 'mobile', 'mobile_number', 'user_phone', 'contact_number', 'work_phone_number'],
    'countrycode'   => ['countrycode', 'country_code'],
    'ad_id'         => ['ad_id', 'adid', 'creative_id', 'asset_id'],
    'ad_name'       => ['ad_name', 'ad', 'asset', 'asset_name', 'creative'],
    'adset_id'      => ['adset_id', 'ad_set_id', 'ad_group_id', 'adgroup_id'],
    'adset_name'    => ['adset_name', 'ad_set_name', 'ad_group', 'ad_group_name', 'adgroup', 'adgroup_name'],
    'campaign_id'   => ['campaign_id'],
    'campaign_name' => ['campaign_name', 'campaign'],
    'form_id'       => ['form_id', 'lead_form_id'],
    'form_name'     => ['form_name', 'lead_form_name', 'capturefromname', 'form'],
    'page_id'       => ['page_id'],
    'platform'      => ['platform', 'publisher_platform'],
    'is_organic'    => ['is_organic'],
    'gclid'         => ['gclid', 'gcl_id', 'google_click_id'],
    'keyword'       => ['keyword', 'search_keyword', 'search_term'],
    'network'       => ['network', 'ad_network_type'],
    'source'        => ['campaignsource', 'source', 'utm_source', 'lead_source'],
    'subsource'     => ['campaignsubsource', 'sub_source', 'utm_medium'],
    'utmM'          => ['utmm'],
    'utmC'          => ['utmc'],
    'websitename'   => ['websitename', 'website', 'website_name'],
    'city'          => ['city'],
  ];
}

function imp_map_headers(array $header): array
{
  $norm = array_map('imp_norm_header', $header);
  $map = [];
  foreach (imp_aliases() as $field => $aliases) {
    foreach ($aliases as $a) {
      $i = array_search($a, $norm, true);
      if ($i !== false) {
        $map[$field] = $i;
        break;
      }
    }
  }
  // Lead-form questions (custom column names) → match by keyword
  $used = array_flip(array_values($map));
  foreach ($norm as $i => $h) {
    if (isset($used[$i]) || $h === '') continue;
    if (!isset($map['bhktype']) && preg_match('/bhk|configuration|unit_type|apartment_type/', $h)) $map['bhktype'] = $i;
    elseif (!isset($map['visit']) && preg_match('/visit/', $h)) $map['visit'] = $i;
    elseif (!isset($map['purpose']) && preg_match('/interest|purpose|investment|self_use|buying_for/', $h)) $map['purpose'] = $i;
    elseif (!isset($map['budget']) && preg_match('/budget|price_range/', $h)) $map['budget'] = $i;
  }
  return $map;
}

/* =====================================================================
 * VALUE HELPERS
 * ===================================================================== */
function imp_split_phone(string $phone, string $cc = ''): array
{
  $phone = preg_replace('/^p:/i', '', trim($phone));          // Meta CSV prefixes "p:"
  $plus = strpos(ltrim($phone), '+') === 0 || strpos($phone, '00') === 0;
  $digits = preg_replace('/\D/', '', $phone);
  if ($digits === '') return ['', ''];
  if (strpos($phone, '00') === 0) $digits = substr($digits, 2);

  $ccDigits = preg_replace('/\D/', '', $cc);
  if ($ccDigits !== '') {
    if (strpos($digits, $ccDigits) === 0 && strlen($digits) > 10) $digits = substr($digits, strlen($ccDigits));
    return ['+' . $ccDigits, $digits];
  }
  if (!$plus && strlen($digits) === 10) return [IMPORT_DEFAULT_CC, $digits];
  if (!$plus && strlen($digits) === 11 && $digits[0] === '0') return [IMPORT_DEFAULT_CC, substr($digits, 1)];
  if (!$plus && strlen($digits) === 12 && strpos($digits, '91') === 0) return ['+91', substr($digits, 2)];

  // International: longest matching known country code
  $codes = ['971', '966', '974', '968', '973', '965', '977', '880', '852', '91', '44', '61', '65', '64', '60', '49', '33', '81', '86', '27', '94', '1', '7'];
  foreach ($codes as $code) {
    if (strpos($digits, $code) === 0 && strlen($digits) - strlen($code) >= 6) {
      return ['+' . $code, substr($digits, strlen($code))];
    }
  }
  return ['', $digits];
}

function imp_parse_date(string $v): string
{
  $v = trim($v);
  if ($v === '') return '';                       // no time in the file: the row is skipped, never saved as "now"
  // Meta "Download leads": 2026-10-28T22:14:50.000 (already IST, no offset) → kept exactly
  if (preg_match('/^(\d{4}-\d{2}-\d{2})[T ](\d{2}:\d{2}:\d{2})(\.\d+)?$/', $v, $m)) return $m[1] . ' ' . $m[2];
  // Excel serial date (from .xlsx)
  if (is_numeric($v) && (float) $v > 20000 && (float) $v < 80000) {
    return gmdate('Y-m-d H:i:s', (int) round(((float) $v - 25569) * 86400));
  }
  // dd/mm/yyyy style → dd-mm-yyyy so strtotime reads it day-first
  if (preg_match('#^\d{1,2}/\d{1,2}/\d{4}#', $v)) $v = str_replace('/', '-', $v);
  try {
    $dt = new DateTime($v);   // ISO with offset (e.g. +05:30 / Z) is converted to IST below
    $dt->setTimezone(new DateTimeZone('Asia/Kolkata'));
    return $dt->format('Y-m-d H:i:s');
  } catch (Exception $e) {
    $ts = strtotime($v);
    return $ts ? date('Y-m-d H:i:s', $ts) : '';
  }
}

function imp_clean_answer(string $v): string
{
  // Meta answers come as "both_self_use_&_investment" → "both self use & investment"
  return trim(str_replace('_', ' ', $v));
}

function imp_platform_label(string $p): string
{
  $p = strtolower(trim($p));
  $map = ['ig' => 'Instagram', 'instagram' => 'Instagram', 'fb' => 'Facebook', 'facebook' => 'Facebook', 'msg' => 'Messenger', 'messenger' => 'Messenger', 'an' => 'Audience Network', 'wa' => 'WhatsApp'];
  return $map[$p] ?? ($p !== '' ? ucfirst($p) : '');
}

// For "Both" mode: work out if a row is Meta or Google
function imp_detect_source(array $f): string
{
  $src = strtolower($f['source'] ?? '');
  if (preg_match('/google|adwords|gads|youtube|pmax|search|display/', $src)) return 'google';
  if (preg_match('/facebook|meta|instagram|\bfb\b|\big\b/', $src)) return 'meta';
  if (($f['gclid'] ?? '') !== '' || ($f['keyword'] ?? '') !== '' || ($f['network'] ?? '') !== '') return 'google';
  if (($f['platform'] ?? '') !== '' || ($f['page_id'] ?? '') !== '' || ($f['is_organic'] ?? '') !== '') return 'meta';
  if (preg_match('/^\d{15,}$/', $f['lead_id'] ?? '') && ($f['adset_id'] ?? '') !== '') return 'meta';
  return '';
}

// Old sample-CSV format (positional) — kept so the existing samples/import.csv still works
function imp_legacy_row(array $d): array
{
  return [
    'full_name' => $d[0] ?? '', 'email' => $d[1] ?? '', 'countrycode' => $d[2] ?? '', 'phone' => $d[3] ?? '',
    'form_id' => $d[4] ?? '', 'page_id' => $d[5] ?? '', 'created' => $d[6] ?? '',
    'source' => $d[7] ?? '', 'subsource' => $d[8] ?? '', 'utmM' => $d[9] ?? '', 'utmC' => $d[10] ?? '',
    'ad_id' => $d[12] ?? '', 'lead_id' => $d[13] ?? '', 'keyword' => $d[14] ?? '',
    'form_name' => $d[15] ?? '', 'websitename' => $d[16] ?? '', 'adset_id' => $d[17] ?? '',
    'adset_name' => $d[18] ?? '', 'campaign_name' => $d[19] ?? '',
  ];
}

/* =====================================================================
 * BUILD DB RECORD
 * ===================================================================== */
/** Meta CSV exports prefix ids ("l:123", "ag:456", "f:789"); the database keeps the plain number. */
function imp_clean_id(string $v): string
{
  $v = trim($v);
  return preg_match('/^[a-z]{1,3}:(\d+)$/i', $v, $m) ? $m[1] : $v;
}

function imp_build_record(array $f, string $source): array
{
  foreach (['lead_id', 'ad_id', 'adset_id', 'campaign_id', 'form_id', 'page_id'] as $k) {
    if (isset($f[$k])) $f[$k] = imp_clean_id($f[$k]);
  }
  $name = $f['full_name'] ?? '';
  if ($name === '') $name = trim(($f['first_name'] ?? '') . ' ' . ($f['last_name'] ?? ''));
  [$cc, $mobile] = imp_split_phone($f['phone'] ?? '', $f['countrycode'] ?? '');

  $rec = [
    'name'          => mb_substr($name, 0, 45),
    'email'         => mb_substr(strtolower($f['email'] ?? ''), 0, 45),
    'countrycode'   => $cc,
    'mobile'        => $mobile,
    'createddate'   => imp_parse_date($f['created'] ?? ''),
    'leadgen_id'    => $f['lead_id'] ?? '',
    'form_id'       => $f['form_id'] ?? '',
    'capturefromname' => $f['form_name'] ?? '',
    'page_id'       => $f['page_id'] ?? '',
    'ad_id'         => $f['ad_id'] ?? '',
    'ad_name'       => $f['ad_name'] ?? '',
    'adset_name'    => $f['adset_name'] ?? '',
    'campaign_name' => $f['campaign_name'] ?? '',
    'utm_campaignname' => $f['campaign_name'] ?? '',
    'utm_campaignid'   => $f['campaign_id'] ?? '',
    'utm_adgroupname'  => $f['adset_name'] ?? '',
    'utm_adgroupid'    => $f['adset_id'] ?? '',
    'utm_adname'       => $f['ad_name'] ?? '',
    'utm_adid'         => $f['ad_id'] ?? '',
    'keyword'       => $f['keyword'] ?? '',
    'bhktype'       => imp_clean_answer($f['bhktype'] ?? ''),
    'purpose'       => imp_clean_answer($f['purpose'] ?? ''),
    'visitpossibleon' => imp_clean_answer($f['visit'] ?? ''),
    'websitename'   => mb_substr($f['websitename'] ?? '', 0, 45),
    'utmM'          => $f['utmM'] ?? '',
    'utmC'          => $f['utmC'] ?? '',
  ];

  if ($source === 'meta') {
    $platform = imp_platform_label($f['platform'] ?? '');
    $rec['campaignsource']    = IMPORT_SOURCE_META;
    $rec['campaignsubsource'] = ($f['subsource'] ?? '') ?: $platform;
    $rec['placement']         = $platform;
    $rec['mf_campaignid']     = $f['campaign_id'] ?? '';
    $rec['mf_adsetid']        = $f['adset_id'] ?? '';
    $rec['mf_adcreativeid']   = $f['ad_id'] ?? '';
    $rec['adset']             = $f['adset_name'] ?? '';
    $rec['adcreative']        = $f['ad_name'] ?? '';
  } elseif ($source === 'google') {
    $rec['campaignsource']    = IMPORT_SOURCE_GOOGLE;
    $rec['campaignsubsource'] = ($f['subsource'] ?? '') ?: ($f['network'] ?? '');
    $rec['gclid']             = $f['gclid'] ?? '';
    $rec['utm_adgroup']       = $f['adset_name'] ?? '';
  } else {
    // legacy file in "Both" mode: keep whatever the file says
    $rec['campaignsource']    = $f['source'] ?? '';
    $rec['campaignsubsource'] = $f['subsource'] ?? '';
  }
  $rec['campaignsource']    = mb_substr($rec['campaignsource'], 0, 45);
  $rec['campaignsubsource'] = mb_substr($rec['campaignsubsource'], 0, 45);

  // drop empty values so DB defaults (NULL) stay
  return array_filter($rec, fn($v) => $v !== '' && $v !== null);
}

/* =====================================================================
 * DUPLICATE CHECK
 *   Meta rows with a lead ID → same lead ID (leadgen_id) only: a person who fills the form again is a new lead
 *   Everything else          → same lead ID OR same mobile (last 10 digits)
 * ===================================================================== */
function imp_find_duplicate(mysqli $conn, array $rec, string $source = ''): ?array
{
  $mobile10 = substr(preg_replace('/\D/', '', $rec['mobile'] ?? ''), -10);
  $leadId = $rec['leadgen_id'] ?? '';

  if ($leadId !== '') {
    $st = $conn->prepare("SELECT id, name, mobile, createddate FROM `lead` WHERE leadgen_id = ? LIMIT 1");
    $st->bind_param('s', $leadId);
    $st->execute();
    if ($r = $st->get_result()->fetch_assoc()) return $r + ['why' => 'Same lead ID'];
    if ($source === 'meta') return null;          // Meta: the lead ID decides (see imp_same_mobile for a note)
  }
  if (strlen($mobile10) >= 6) {
    $st = $conn->prepare("SELECT id, name, mobile, createddate FROM `lead`
                          WHERE RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(IFNULL(mobile,''), '+', ''), ' ', ''), '-', ''), '(', ''), ')', ''), 10) = ? LIMIT 1");
    $st->bind_param('s', $mobile10);
    $st->execute();
    if ($r = $st->get_result()->fetch_assoc()) return $r + ['why' => 'Same mobile'];
  }
  return null;
}

/** A lead with the same mobile (last 10 digits) — only for a note on Meta rows, never to skip them. */
function imp_same_mobile(mysqli $conn, array $rec): ?array
{
  $mobile10 = substr(preg_replace('/\D/', '', $rec['mobile'] ?? ''), -10);
  if (strlen($mobile10) < 6) return null;
  $st = $conn->prepare("SELECT id, createddate FROM `lead`
                        WHERE RIGHT(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(IFNULL(mobile,''), '+', ''), ' ', ''), '-', ''), '(', ''), ')', ''), 10) = ? LIMIT 1");
  $st->bind_param('s', $mobile10);
  $st->execute();
  return $st->get_result()->fetch_assoc() ?: null;
}

function imp_insert(mysqli $conn, array $rec): int
{
  $allowed = [
    'name', 'email', 'countrycode', 'mobile', 'campaignsource', 'campaignsubsource', 'placement', 'adcreative', 'adset',
    'mf_campaignid', 'bhktype', 'purpose', 'visitpossibleon', 'form_id', 'ad_id', 'leadgen_id', 'page_id', 'keyword',
    'capturefromname', 'websitename', 'createddate', 'utmM', 'utmC', 'ad_name', 'adset_name', 'campaign_name', 'gclid',
    'utm_campaignname', 'utm_campaignid', 'utm_adgroupname', 'utm_adname', 'utm_adgroup', 'utm_adgroupid',
    'mf_adcreativeid', 'mf_adsetid', 'utm_adid', 'user_session',
  ];
  $rec = array_intersect_key($rec, array_flip($allowed));
  $cols = '`' . implode('`, `', array_keys($rec)) . '`';
  $marks = implode(', ', array_fill(0, count($rec), '?'));
  $st = $conn->prepare("INSERT INTO `lead` ($cols) VALUES ($marks)");
  $vals = array_values($rec);
  $st->bind_param(str_repeat('s', count($vals)), ...$vals);
  $st->execute();
  return (int) $conn->insert_id;
}

/* =====================================================================
 * META GRAPH API — campaign / ad set / ad names for Meta rows
 *   by ad id:   GET /?ids=<ad ids>&fields=name,adset{id,name},campaign{id,name}       (needs ads_read)
 *   no ad id:   GET /?ids=<lead ids>&fields=ad_id,ad_name,adset_id,adset_name,campaign_id,campaign_name (leads_retrieval)
 * Up to 50 ids per request. Never prints the access token.
 * ===================================================================== */
function imp_graph_get(string $path, array $params): array
{
  $token = defined('META_ACCESS_TOKEN') ? (string) META_ACCESS_TOKEN : '';
  if ($token === '') throw new RuntimeException('META_ACCESS_TOKEN is not set in config.php');
  $v = defined('META_API_VERSION') ? trim((string) META_API_VERSION) : 'v23.0';
  if ($v !== '' && $v[0] !== 'v') $v = 'v' . $v;
  $params['access_token'] = $token;
  $ch = curl_init('https://graph.facebook.com/' . rawurlencode($v) . '/' . ltrim($path, '/') . '?' . http_build_query($params, '', '&', PHP_QUERY_RFC3986));
  curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_CONNECTTIMEOUT => 10, CURLOPT_TIMEOUT => 40, CURLOPT_HTTPHEADER => ['Accept: application/json']]);
  $body = curl_exec($ch);
  $err = curl_error($ch);
  unset($ch);
  if ($body === false) throw new RuntimeException('Could not reach Meta: ' . $err);
  $j = json_decode((string) $body, true);
  if (!is_array($j)) throw new RuntimeException('Meta sent an unreadable answer');
  if (isset($j['error'])) {
    $m = (string) ($j['error']['message'] ?? 'Meta error');
    throw new RuntimeException(preg_replace('/access_token=[^&\s]+/i', 'access_token=…', $m) . (isset($j['error']['code']) ? ' (#' . $j['error']['code'] . ')' : ''));
  }
  return $j;
}

/**
 * @param string[] $adIds   ad ids of Meta rows
 * @param string[] $leadIds lead ids of Meta rows that have no ad id
 * @return array{ads: array<string, array>, leads: array<string, array>, errors: string[]}
 *         each value: campaign_id, campaign_name, adset_id, adset_name, ad_id, ad_name
 */
function imp_meta_names(array $adIds, array $leadIds): array
{
  $out = ['ads' => [], 'leads' => [], 'errors' => []];
  $clean = fn($a) => array_values(array_unique(array_filter(array_map('strval', $a), fn($x) => preg_match('/^\d{5,}$/', $x))));
  foreach (array_chunk($clean($adIds), 50) as $chunk) {
    try {
      $j = imp_graph_get('', ['ids' => implode(',', $chunk), 'fields' => 'name,adset{id,name},campaign{id,name}']);
      foreach ($j as $id => $a) {
        if (!is_array($a)) continue;
        $out['ads'][(string) $id] = [
          'ad_id' => (string) $id, 'ad_name' => (string) ($a['name'] ?? ''),
          'adset_id' => (string) ($a['adset']['id'] ?? ''), 'adset_name' => (string) ($a['adset']['name'] ?? ''),
          'campaign_id' => (string) ($a['campaign']['id'] ?? ''), 'campaign_name' => (string) ($a['campaign']['name'] ?? ''),
        ];
      }
    } catch (Throwable $e) {
      $out['errors'][] = $e->getMessage();
    }
  }
  foreach (array_chunk($clean($leadIds), 50) as $chunk) {
    try {
      $j = imp_graph_get('', ['ids' => implode(',', $chunk), 'fields' => 'ad_id,ad_name,adset_id,adset_name,campaign_id,campaign_name']);
      foreach ($j as $id => $a) {
        if (!is_array($a)) continue;
        $out['leads'][(string) $id] = array_map('strval', array_intersect_key($a + array_fill_keys(['ad_id', 'ad_name', 'adset_id', 'adset_name', 'campaign_id', 'campaign_name'], ''),
          array_flip(['ad_id', 'ad_name', 'adset_id', 'adset_name', 'campaign_id', 'campaign_name'])));
      }
    } catch (Throwable $e) {
      $out['errors'][] = $e->getMessage();
    }
  }
  $out['errors'] = array_values(array_unique($out['errors']));
  return $out;
}

/** Name / id columns of a Meta lead that the Graph names fill. */
const IMP_NAME_COLS = ['campaign_name', 'utm_campaignname', 'mf_campaignid', 'utm_campaignid', 'adset_name', 'utm_adgroupname', 'adset',
  'mf_adsetid', 'utm_adgroupid', 'ad_name', 'utm_adname', 'adcreative', 'ad_id', 'mf_adcreativeid', 'utm_adid'];

/**
 * Fills the empty campaign / ad set / ad columns of a lead already in the database (never overwrites a value).
 * Returns the columns that were filled.
 */
function imp_fill_names(mysqli $conn, int $id, array $rec, bool $dry = false): array
{
  $cols = [];
  $res = $conn->query('SHOW COLUMNS FROM `lead`');
  $have = [];
  while ($res && ($r = $res->fetch_assoc())) $have[$r['Field']] = true;
  $st = $conn->prepare('SELECT * FROM `lead` WHERE id = ?');
  $st->bind_param('i', $id);
  $st->execute();
  $cur = $st->get_result()->fetch_assoc() ?: [];
  $set = [];
  foreach (IMP_NAME_COLS as $c) {
    if (!isset($have[$c]) || ($rec[$c] ?? '') === '') continue;
    if (trim((string) ($cur[$c] ?? '')) !== '') continue;
    $set[$c] = (string) $rec[$c];
  }
  if (!$set || $dry) return array_keys($set);
  $sql = 'UPDATE `lead` SET ' . implode(', ', array_map(fn($c) => "`{$c}` = ?", array_keys($set))) . ' WHERE id = ?';
  $vals = array_values($set);
  $vals[] = $id;
  $up = $conn->prepare($sql);
  $up->bind_param(str_repeat('s', count($set)) . 'i', ...$vals);
  $up->execute();
  return array_keys($set);
}

/* =====================================================================
 * HANDLE UPLOAD
 * ===================================================================== */
$message = "";
$error = "";
$summary = null;
$importMode = $_POST['import_source'] ?? 'meta';
if (!in_array($importMode, ['meta', 'google', 'both'], true)) $importMode = 'meta';
$previewOnly = !empty($_POST['preview_only']);
$isPost = $_SERVER['REQUEST_METHOD'] === 'POST';
$useGraph = $isPost ? !empty($_POST['meta_names']) : true;     // Meta: names from the Graph API
$fillNames = $isPost ? !empty($_POST['fill_names']) : true;    // Meta: fill empty names on leads already in the DB

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES["file"])) {
  $up = $_FILES["file"];
  if ($up['error'] !== UPLOAD_ERR_OK || $up['size'] <= 0) {
    $error = "Please choose a file to import.";
  } elseif ($up['size'] > IMPORT_MAX_BYTES) {
    $error = "File is too large (max 10 MB).";
  } elseif (!preg_match('/\.(xls|xlsx|csv|tsv|txt)$/i', $up['name'])) {
    $error = "Only .xls, .xlsx or .csv files can be imported.";
  } else {
    $rows = imp_read_file($up['tmp_name'], $up['name'], $error);
    // drop fully blank rows
    $rows = array_values(array_filter($rows, fn($r) => implode('', $r) !== ''));

    if (!$error && count($rows) < 2) $error = "No lead rows found in the file.";

    if (!$error) {
      $header = array_shift($rows);
      $map = imp_map_headers($header);
      // Only fall back to positional mapping when we can't find a phone column at all
      $legacy = !isset($map['phone']);

      $summary = [
        'total' => count($rows), 'imported' => 0, 'dup_db' => 0, 'dup_file' => 0, 'skipped' => 0,
        'meta' => 0, 'google' => 0, 'details' => [],
      ];
      $summary['names_filled'] = 0;
      $summary['graph'] = null;
      $seenMobiles = [];
      $seenLeadIds = [];

      // read every row first, so the Meta names can be fetched in a few requests
      $parsed = [];
      foreach ($rows as $i => $data) {
        if ($legacy) {
          $f = imp_legacy_row($data);
        } else {
          $f = [];
          foreach ($map as $field => $col) $f[$field] = trim((string) ($data[$col] ?? ''));
        }
        foreach (['lead_id', 'ad_id', 'adset_id', 'campaign_id', 'form_id', 'page_id'] as $k) {
          if (isset($f[$k])) $f[$k] = imp_clean_id($f[$k]);
        }
        $parsed[$i] = $f;
      }
      $graph = ['ads' => [], 'leads' => [], 'errors' => []];
      if ($useGraph && $importMode !== 'google') {
        $adIds = [];
        $noAd = [];
        foreach ($parsed as $f) {
          if ($importMode === 'both' && imp_detect_source($f) !== 'meta') continue;
          if (($f['ad_id'] ?? '') !== '') $adIds[] = $f['ad_id'];
          elseif (($f['lead_id'] ?? '') !== '') $noAd[] = $f['lead_id'];
        }
        if ($adIds || $noAd) {
          $graph = imp_meta_names($adIds, $noAd);
          $summary['graph'] = ['asked' => count(array_unique($adIds)) + count(array_unique($noAd)),
                               'found' => count($graph['ads']) + count($graph['leads']), 'errors' => $graph['errors']];
        }
      }

      foreach ($parsed as $i => $f) {
        $rowNo = $i + 2;   // +1 header, +1 human counting

        // Which platform is this row?
        if ($importMode === 'both') {
          $src = imp_detect_source($f);
          if ($src === '' && !$legacy) {
            $summary['skipped']++;
            $summary['details'][] = [$rowNo, $f['full_name'] ?? '', $f['phone'] ?? '', 'Skipped', 'Could not tell if this is a Meta or Google lead — import it with Meta or Google selected', ''];
            continue;
          }
        } else {
          $src = $importMode;
        }

        // Meta: campaign / ad set / ad names (and ids) from the Graph API win over the file
        $gn = null;
        if ($src === 'meta') {
          $gn = $graph['ads'][$f['ad_id'] ?? ''] ?? $graph['leads'][$f['lead_id'] ?? ''] ?? null;
          if ($gn) {
            foreach ($gn as $k => $v) if ($v !== '') $f[$k] = $v;
          }
        }
        $namesNote = $gn ? ' · names from Meta: ' . ($gn['campaign_name'] ?: '—') . ' › ' . ($gn['adset_name'] ?: '—') . ' › ' . ($gn['ad_name'] ?: '—') : '';

        $rec = imp_build_record($f, $src);
        $mobile10 = substr(preg_replace('/\D/', '', $rec['mobile'] ?? ''), -10);

        if ($mobile10 === '' && ($rec['email'] ?? '') === '') {
          $summary['skipped']++;
          $summary['details'][] = [$rowNo, $rec['name'] ?? '', '', 'Skipped', 'No phone or email', ''];
          continue;
        }

        if (($rec['createddate'] ?? '') === '') {
          $summary['skipped']++;
          $summary['details'][] = [$rowNo, $rec['name'] ?? '', $rec['mobile'] ?? '', 'Skipped', 'No created date / time in the file', ''];
          continue;
        }

        // Duplicate inside the same file (Meta rows with a lead ID: by lead ID only)
        $leadId = $rec['leadgen_id'] ?? '';
        $byIdOnly = $src === 'meta' && $leadId !== '';
        if ((!$byIdOnly && $mobile10 !== '' && isset($seenMobiles[$mobile10])) || ($leadId !== '' && isset($seenLeadIds[$leadId]))) {
          $summary['dup_file']++;
          $summary['details'][] = [$rowNo, $rec['name'] ?? '', $rec['mobile'] ?? '', 'Duplicate', 'Repeated in this file (row ' . ($leadId !== '' && isset($seenLeadIds[$leadId]) ? $seenLeadIds[$leadId] : $seenMobiles[$mobile10]) . ')', $rec['createddate']];
          continue;
        }
        if ($mobile10 !== '' && !isset($seenMobiles[$mobile10])) $seenMobiles[$mobile10] = $rowNo;
        if ($leadId !== '') $seenLeadIds[$leadId] = $rowNo;

        // Duplicate already in DB
        $dup = imp_find_duplicate($conn, $rec, $src);
        if ($dup) {
          $summary['dup_db']++;
          $fill = '';
          if ($fillNames && $gn && $src === 'meta') {
            // lead already in the database: fill its empty campaign / ad set / ad columns from Meta (never overwrite)
            $filled = imp_fill_names($conn, (int) $dup['id'], $rec, $previewOnly);
            if ($filled) {
              $summary['names_filled']++;
              $fill = ($previewOnly ? ' · will fill from Meta: ' : ' · filled from Meta: ') . implode(', ', $filled);
            }
          }
          $summary['details'][] = [$rowNo, $rec['name'] ?? '', $rec['mobile'] ?? '', 'Duplicate', $dup['why'] . ' as lead #' . $dup['id'] . ' (' . $dup['name'] . ', ' . $dup['createddate'] . ')' . $fill, $rec['createddate']];
          continue;
        }
        $mobNote = '';
        if ($src === 'meta' && ($sm = imp_same_mobile($conn, $rec))) {
          $mobNote = ' · same mobile as lead #' . $sm['id'] . ' (' . $sm['createddate'] . ', different lead ID)';
        }

        if (!$previewOnly) imp_insert($conn, $rec);
        $summary['imported']++;
        if ($src === 'meta') $summary['meta']++;
        if ($src === 'google') $summary['google']++;
        $summary['details'][] = [$rowNo, $rec['name'] ?? '', $rec['mobile'] ?? '', $previewOnly ? 'Will import' : 'Imported', ucfirst($src ?: ($rec['campaignsource'] ?? '')) . ($leadId !== '' ? ' · lead ID ' . $leadId : '') . $namesNote . $mobNote, $rec['createddate']];
      }
      $message = "success";
    }
  }
}
?>

<!--
=========================================================
* Paper Dashboard 2 - v2.0.1
=========================================================

* Product Page: https://www.creative-tim.com/product/paper-dashboard-2
* Copyright 2020 Creative Tim (https://www.creative-tim.com)

Coded by www.creative-tim.com

 =========================================================

* The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
-->

<?php
require_once dirname(__DIR__) . '/app/Leads/header.php';
require_once dirname(__DIR__) . '/app/bootstrap.php';

$username = $_SESSION['username'] ?? 'Admin';
$role = $_SESSION['role'] ?? 'admin';
?>

<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <link rel="apple-touch-icon" sizes="76x76" href="./assets/img/apple-icon.png">

  <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css" />
  <link rel="icon" type="image/png" href="./assets/img/favicon.png">

  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <title>
    Webzaa Admin | <?php echo PROJECT_NAME; ?>
  </title>
  <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
  <!--     Fonts and icons     -->
  <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
  <link href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
  <!-- CSS Files -->
  <link href="./assets/css/bootstrap.min.css" rel="stylesheet" />
  <link href="./assets/css/paper-dashboard.css?v=2.0.1" rel="stylesheet" />
  <!-- CSS Just for demo purpose, don't include it in your project -->
  <link href="./assets/demo/demo.css" rel="stylesheet" />
  <link href="assets/css/style.css" rel="stylesheet" />

  <style type="text/css">
    .error {
      border-color: red;
    }

    /* ===== Import page ===== */
    .imp-card {
      background: #fff;
      border-radius: 10px;
      box-shadow: 0 2px 10px rgba(0, 0, 0, .06);
      padding: 22px 24px;
      margin: 0 15px 20px;
      width: 100%;
    }

    .imp-label {
      font-weight: 700;
      font-size: 13px;
      text-transform: uppercase;
      letter-spacing: .5px;
      color: #66615b;
      margin-bottom: 10px;
      display: block;
    }

    .src-options {
      display: flex;
      gap: 12px;
      flex-wrap: wrap;
      margin-bottom: 20px;
    }

    .src-option {
      position: relative;
      cursor: pointer;
      margin: 0;
    }

    .src-option input {
      position: absolute;
      opacity: 0;
    }

    .src-option span {
      display: flex;
      align-items: center;
      gap: 8px;
      padding: 10px 18px;
      border: 2px solid #e3e3e3;
      border-radius: 8px;
      font-weight: 600;
      color: #424240;
      transition: .2s;
      min-width: 140px;
    }

    .src-option span .iconify {
      font-size: 22px;
    }

    .src-option input:checked+span {
      border-color: #f35a01;
      background: #fff5ef;
    }

    .src-option input:focus-visible+span {
      outline: 2px solid #f35a01;
      outline-offset: 2px;
    }

    .src-hint {
      font-size: 13px;
      color: #9a9a9a;
      margin-top: -10px;
      margin-bottom: 18px;
    }

    .imp-stats {
      display: flex;
      gap: 12px;
      flex-wrap: wrap;
      margin: 10px 0 18px;
    }

    .imp-stat {
      flex: 1 1 130px;
      border-radius: 8px;
      padding: 12px 14px;
      background: #f7f7f7;
    }

    .imp-stat b {
      display: block;
      font-size: 24px;
      line-height: 1.2;
    }

    .imp-stat small {
      color: #66615b;
    }

    .imp-stat.ok {
      background: #eaf7ee;
    }

    .imp-stat.ok b {
      color: #1e8e3e;
    }

    .imp-stat.dup b {
      color: #d9822b;
    }

    .imp-stat.dup {
      background: #fff6ea;
    }

    .imp-table {
      max-height: 420px;
      overflow: auto;
    }

    .imp-table table {
      font-size: 13px;
    }

    .imp-table th {
      position: sticky;
      top: 0;
      background: #f7f7f7;
    }

    .badge-imp {
      padding: 3px 8px;
      border-radius: 10px;
      font-size: 11px;
      font-weight: 700;
    }

    .badge-Imported,
    .badge-Will {
      background: #eaf7ee;
      color: #1e8e3e;
    }

    .badge-Duplicate {
      background: #fff6ea;
      color: #b36200;
    }

    .badge-Skipped {
      background: #f2f2f2;
      color: #66615b;
    }
  </style>
  <?php include dirname(__DIR__) . '/app/Ui/embed_head.php'; ?>
</head>

<body class="">
  <div class="wrapper ">
    <div class="sidebar" data-color="white" data-active-color="danger">
      <div class="logo">

        <a href="index.php" class="simple-text logo-normal">

          <div class="logo-image-big pl-5">
            <img src="./assets/images/webzaa-logo.png">
          </div>
        </a>
      </div>
      <div class="sidebar-wrapper">
        <ul class="nav">
          <li class="">
            <a href="index.php">
              <span class="iconify" data-icon="ri:dashboard-fill" style="font-size:24px;float:left;margin-right:12px;line-height:30px;width:34px;text-align:center;position:relative;"></span>
              <p>Dashboard</p>
            </a>
          </li>
          <li class="">
            <a href="analytics.php">
              <i class="nc-icon nc-chart-pie-36"></i>
              <p>Analytics</p>
            </a>
          </li>
          <li class="">
            <a href="meta_capi.php">
              <span class="iconify" data-icon="ri:meta-fill" style="font-size:24px;float:left;margin-right:12px;line-height:30px;width:34px;text-align:center;position:relative;"></span>
              <p>Meta CAPI</p>
            </a>
          </li>
          <li class="active">
            <a href="import.php">
              <i class="nc-icon nc-cloud-upload-94"></i>
              <p>Import</p>
            </a>
          </li>
        </ul>
      </div>
    </div>
    <div class="main-panel" style="min-height: 100vh;">
      <!-- Navbar -->
      <nav class="navbar navbar-expand-lg navbar-absolute fixed-top navbar-transparent">
        <div class="container-fluid">
          <div class="navbar-wrapper">
            <div class="navbar-toggle">
              <button type="button" class="navbar-toggler">
                <span class="navbar-toggler-bar bar1"></span>
                <span class="navbar-toggler-bar bar2"></span>
                <span class="navbar-toggler-bar bar3"></span>
              </button>
            </div>
            <a class="navbar-brand" href="javascript:;"><?php echo $greeting . ', ' . htmlspecialchars($username); ?></a>
          </div>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navigation" aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-bar navbar-kebab"></span>
            <span class="navbar-toggler-bar navbar-kebab"></span>
            <span class="navbar-toggler-bar navbar-kebab"></span>
          </button>
          <div class="collapse navbar-collapse justify-content-end" id="navigation">
            <div class="no-border">
              <ul class="navbar-nav">
                <li class="nav-item btn-rotate dropdown">
                  <a class="nav-link dropdown-toggle" href="" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <p>
                      <span class="d-lg-none d-md-block">Some Actions</span>
                    </p>
                  </a>
                  <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownMenuLink">
                    <a class="dropdown-item" href="./leads/logout.php">Logout</a>
                    <?php if (isset($_SESSION['role']) && $_SESSION['role'] == 'superadmin') { ?>
                      <a class="dropdown-item" href="./leads/users.php">Add Users</a>
                    <?php } ?>
                  </div>
                </li>
              </ul>
            </div>
          </div>
      </nav>
      <!-- End Navbar -->
      <div class="content">
        <div class="row">
          <div class="col-md-12 row">
            <div class="col-md-9">
              <h3 class="description">Import Leads</h3>
            </div>
            <div class="col-md-3">
              <h3 class="description"><a class="btn btn-primary form-control" style="color: white;background: #424240;float:right;" href="./index.php">Back</a></h3>
            </div>
          </div>

          <?php if ($error) { ?>
            <div class="col-md-12">
              <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
            </div>
          <?php } ?>

          <div class="imp-card">
            <form id="import_form" action="" method="post" name="upload_excel" enctype="multipart/form-data">
              <label class="imp-label">Lead source</label>
              <div class="src-options">
                <label class="src-option">
                  <input type="radio" name="import_source" value="meta" <?php echo $importMode === 'meta' ? 'checked' : ''; ?>>
                  <span><span class="iconify" data-icon="logos:meta-icon"></span> Meta</span>
                </label>
                <label class="src-option">
                  <input type="radio" name="import_source" value="google" <?php echo $importMode === 'google' ? 'checked' : ''; ?>>
                  <span><span class="iconify" data-icon="logos:google-icon"></span> Google</span>
                </label>
                <label class="src-option">
                  <input type="radio" name="import_source" value="both" <?php echo $importMode === 'both' ? 'checked' : ''; ?>>
                  <span><span class="iconify" data-icon="ri:stack-line"></span> Both (mixed file)</span>
                </label>
              </div>
              <div class="src-hint" id="src-hint"></div>

              <label class="imp-label" for="myfile">File</label>
              <input type="file" id="myfile" name="file" accept=".xls,.xlsx,.csv,.tsv">
              <div style="margin-top:6px;font-size:13px;color:#9a9a9a;">
                Accepts the Meta "Download leads" .xls / .csv, Google Ads lead-form .csv, any .xlsx, or the
                <a href="./samples/import.csv" style="color:#f35a01;" download>sample CSV format</a>.
                Only missing leads are imported, with the created date &amp; time from the file. Meta leads are matched on their
                lead ID (leadgen_id): a Meta lead ID already in the database is skipped. Other leads are skipped when their mobile
                number or lead ID already exists.
              </div>

              <div style="margin-top:14px;display:flex;flex-direction:column;gap:6px;font-size:14px;">
                <label style="margin:0;cursor:pointer;">
                  <input type="checkbox" name="meta_names" value="1" <?php echo $useGraph ? 'checked' : ''; ?>>
                  Meta: take campaign, ad set and ad names from the Meta API (by ad ID; the file's names are used if Meta has none)
                </label>
                <label style="margin:0;cursor:pointer;">
                  <input type="checkbox" name="fill_names" value="1" <?php echo $fillNames ? 'checked' : ''; ?>>
                  Meta: also fill empty campaign / ad set / ad names on leads already in the database (filled values are never overwritten)
                </label>
              </div>

              <div style="margin-top:16px;display:flex;align-items:center;gap:16px;flex-wrap:wrap;">
                <label style="margin:0;cursor:pointer;">
                  <input type="checkbox" name="preview_only" value="1" <?php echo $previewOnly ? 'checked' : ''; ?>>
                  Preview only (check duplicates, don't save)
                </label>
                <button type="submit" class="btn btn-primary" id="import" style="color: white;background: #424240;margin:0;">Import</button>
              </div>
            </form>
          </div>

          <?php if ($summary) { ?>
            <div class="imp-card">
              <label class="imp-label"><?php echo $previewOnly ? 'Preview — nothing saved yet' : 'Import result'; ?></label>
              <div class="imp-stats">
                <div class="imp-stat"><b><?php echo $summary['total']; ?></b><small>Rows in file</small></div>
                <div class="imp-stat ok"><b><?php echo $summary['imported']; ?></b><small><?php echo $previewOnly ? 'Will be imported' : 'Imported'; ?><?php if ($importMode === 'both') echo ' (Meta ' . $summary['meta'] . ' · Google ' . $summary['google'] . ')'; ?></small></div>
                <div class="imp-stat dup"><b><?php echo $summary['dup_db']; ?></b><small>Already in DB</small></div>
                <div class="imp-stat dup"><b><?php echo $summary['dup_file']; ?></b><small>Repeated in file</small></div>
                <div class="imp-stat"><b><?php echo $summary['skipped']; ?></b><small>Skipped</small></div>
                <?php if ($fillNames && $summary['graph']) { ?>
                  <div class="imp-stat ok"><b><?php echo (int) $summary['names_filled']; ?></b><small><?php echo $previewOnly ? 'Existing leads that will get Meta names' : 'Existing leads given Meta names'; ?></small></div>
                <?php } ?>
              </div>
              <?php if ($summary['graph']) { $g = $summary['graph']; ?>
                <div style="font-size:13px;margin:-6px 0 14px;color:<?php echo $g['errors'] ? '#b36200' : '#1e8e3e'; ?>;">
                  Meta API: names found for <?php echo (int) $g['found']; ?> of <?php echo (int) $g['asked']; ?> ads / leads.
                  <?php if ($g['errors']) echo 'The rest keep the names from the file. Meta said: ' . htmlspecialchars(implode(' · ', array_slice($g['errors'], 0, 2))); ?>
                </div>
              <?php } ?>
              <div class="imp-table">
                <table class="table table-sm">
                  <thead>
                    <tr>
                      <th>Row</th>
                      <th>Name</th>
                      <th>Mobile</th>
                      <th>Created</th>
                      <th>Status</th>
                      <th>Details</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php foreach ($summary['details'] as $d) {
                      $badge = explode(' ', $d[3])[0]; ?>
                      <tr>
                        <td><?php echo (int) $d[0]; ?></td>
                        <td><?php echo htmlspecialchars($d[1]); ?></td>
                        <td><?php echo htmlspecialchars(function_exists('pqContact') ? pqContact($d[2], 'mobile') : $d[2]); ?></td>   <!-- Users & Roles: last 5 digits only -->
                        <td style="white-space:nowrap"><?php echo htmlspecialchars((string) ($d[5] ?? '')); ?></td>
                        <td><span class="badge-imp badge-<?php echo $badge; ?>"><?php echo htmlspecialchars($d[3]); ?></span></td>
                        <td><?php echo htmlspecialchars($d[4]); ?></td>
                      </tr>
                    <?php } ?>
                  </tbody>
                </table>
              </div>
            </div>
          <?php } ?>
        </div>
        <footer class="footer">
          <div class="container-fluid">
            <div class="row">
              <nav class="footer-nav">
                <ul></ul>
              </nav>
              <div class="credits ml-auto"></div>
            </div>
          </div>
        </footer>
      </div>
    </div>

    <!--   Core JS Files   -->
    <script src="./assets/js/core/jquery.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://code.jquery.com/ui/1.13.2/jquery-ui.min.js"></script>
    <script src="https://code.iconify.design/3/3.1.1/iconify.min.js"></script>
    <script src="./assets/js/core/popper.min.js"></script>
    <script src="./assets/js/core/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.perfect-scrollbar/1.5.5/perfect-scrollbar.min.js" integrity="sha512-X41/A5OSxoi5uqtS6Krhqz8QyyD8E/ZbN7B4IaBSgqPLRbWVuXJXr9UwOujstj71SoVxh5vxgy7kmtd17xrJRw==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="./assets/js/plugins/bootstrap-notify.js"></script>
    <script src="./assets/js/paper-dashboard.min.js?v=2.0.1" type="text/javascript"></script>
    <script type="text/javascript">
      var srcHints = {
        meta: 'Every row is saved as a Meta lead (Ads Manager → Leads Center / Forms Library → Download).',
        google: 'Every row is saved as a Google lead (Google Ads → Lead form asset → Download leads).',
        both: 'Each row is checked: rows with platform / page_id are Meta, rows with gclid / keyword / network are Google, or a "source" column decides.'
      };

      function updateHint() {
        $('#src-hint').text(srcHints[$('input[name="import_source"]:checked').val()] || '');
      }
      $(document).on('change', 'input[name="import_source"]', updateHint);
      updateHint();

      $(document).on('submit', '#import_form', function(e) {
        if (!$('#myfile').val()) {
          e.preventDefault();
          alert('Please choose a file to import.');
          return;
        }
        $('#import').prop('disabled', true).text('Importing…');
      });
    </script>

    <!-- ===m=== Analytics Script Code ===m=== -->
    <script>
      $(document).ready(function() {
        function sendLog(actionType, dataPayload) {
          dataPayload.action_type = actionType;
          // ===m=== Capture the exact page they are on ===m===
          dataPayload.current_url = window.location.pathname + window.location.search;
          $.ajax({
            url: 'leads/ajax_log_activity.php',
            type: 'POST',
            data: dataPayload,
            error: function() {
              console.log("Background log failed");
            }
          });
        }
        // ===m=== Track logout specifically ===m===
        $(document).on('click', 'a[href*="logout.php"]', function(e) {
          e.preventDefault(); // stop immediate redirect
          e.stopImmediatePropagation();
          let logoutUrl = $(this).attr('href');
          sendLog('logout', {
            clicked_element: 'Logout'

          });
          setTimeout(function() {
            window.location.href = logoutUrl;
          }, 400);
          return;
        });
        // ===m=== Track clicks ===m===
        $(document).on('click', 'a, button, input[type="button"], input[type="submit"], [role="button"], .nav-link, .dropdown-item,[data-bs-toggle], [data-toggle]', function(e) {
          let $el = $(this);
          // ===m=== Extract element text/label ===m===
          let text = $el.text().trim() || $el.val() || $el.attr('title') || $el.attr('aria-label') || 'Icon/Element';
          let href = $el.attr('href') || '';
          let id = $el.attr('id') || '';
          let textLower = text.toLowerCase();
          // ===m=== Limit text length ===m===
          if (text.length > 50) text = text.substring(0, 50) + '...';
          // ===m=== Ignore useless javascript-only icon clicks ===m===
          if (href.toLowerCase().includes('javascript:') && text === 'Icon/Element') return;
          // ===m=== Detect report export/download actions ===m===
          if (textLower.includes('export') || textLower.includes('download') || href.toLowerCase().includes('export.php')) {
            sendLog('report_download', {
              report_name: text || 'Export Data'
            });
            return;
          }
          if (textLower.includes('search') || $el.attr('id') === 'search-btn' || $el.hasClass('search')) {
            let searchTerm = $el.closest('form, div, .row').find('input[type="text"], input[type="search"]').val();
            if (searchTerm && searchTerm.trim() !== '') {
              sendLog('search', {
                search_term: searchTerm.trim()
              });
              return;
            }
          }
          // ===m=== Prepare element details for logging ===m===
          let elementDetails = text;
          if (href && href !== '#' && !href.toLowerCase().includes('javascript:')) {
            elementDetails += ' (' + href + ')';
          } else if (id) {
            elementDetails += ' (#' + id + ')';
          }
          sendLog('click', {
            clicked_element: elementDetails
          });
        });
        // ===m=== Track search via Enter key in input fields ===m===
        $(document).on('keypress', 'input', function(e) {
          if (e.which == 13) {
            let inputAttributes = ($(this).attr('id') || '') + ($(this).attr('name') || '') + ($(this).attr('placeholder') || '');
            if (inputAttributes.toLowerCase().includes('search')) {
              let searchTerm = $(this).val().trim();
              if (searchTerm !== '') {
                sendLog('search', {
                  search_term: searchTerm
                });
              }
            }
          }
        });
        // ===m=== Track dropdown/select value changes ===m===
        $(document).on('change', 'select', function() {
          let selectIdentifier = $(this).attr('name') || $(this).attr('id') || 'Dropdown';
          let selectedText = $(this).find('option:selected').text().trim();
          sendLog('change', {
            changed_element: selectIdentifier,
            new_value: selectedText
          });
        });

      });
    </script>
    <!-- ===m=== Analytics Script Code ===m=== -->

</body>

</html>