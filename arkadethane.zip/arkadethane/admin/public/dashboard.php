<?php
/**
 * PerformIQ — one dashboard for everything.
 *
 * App shell: sidebar navigation + top bar (greeting, theme toggle, user menu).
 *   Overview      → native page: all ad platforms combined (Meta + Google + Taboola)
 *   Ads           → the existing platform dashboards, embedded (ads/*dashboard.php?embed=1)
 *   CRM           → Leads & CRM (index.php?embed=1) — platform-independent, its own section
 *   Tools         → Web Analytics, Meta CAPI, Import (embedded)
 *   Admin         → Users & Roles, CRM Settings (Super Admin only) · User menu → Logout
 *
 * Sections are addressed by URL hash (#overview, #meta, #google, #taboola, #leads, #status, ...),
 * so a refresh or a shared link opens the same section.
 */
session_start();
require_once dirname(__DIR__) . '/app/Core/db.php';
$showTaboola = defined('SHOW_TABOOLA') && SHOW_TABOOLA && pqCanSeeType('performance');   // Taboola hidden unless config sets SHOW_TABOOLA = true; all performance (Users & Roles → Campaign types)
$showOtt = !defined('SHOW_OTT') || SHOW_OTT;                // manual platforms (OTT Video, Display, …) — hide all with define('SHOW_OTT', false)

if (!isset($_SESSION["user_logged"]) || $_SESSION["user_logged"] != "Y") {
    header("Location: login.php");
    exit;
}

require_once dirname(__DIR__) . '/app/Leads/header.php';   // $username, $greeting

$role         = $_SESSION['role'] ?? 'admin';
$isSuperadmin = ($role === 'superadmin');
$appTitle     = defined('DASHBOARD_TITLE') ? DASHBOARD_TITLE : 'Performance Marketing Dashboard';

$initials = '';
foreach (preg_split('/\s+/', trim((string) $username)) as $part) {
    if ($part !== '' && strlen($initials) < 2) {
        $initials .= mb_strtoupper(mb_substr($part, 0, 1));
    }
}
$initials = $initials !== '' ? $initials : 'U';

$h = fn($v) => htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');

// Manual platforms (numbers added / pasted by hand): OTT Video + any added from the admin (app/Ads/ott.php)
$manualPlatforms = [];
if ($showOtt) {
    try {
        require_once dirname(__DIR__) . '/app/Ads/ott.php';
        $manualPlatforms = ottVisiblePlatforms();   // Users & Roles → Campaign types: all-awareness / all-performance platforms only for roles that see that type
    } catch (Throwable $e) {
        error_log('[dashboard] manual platforms: ' . $e->getMessage());
        $manualPlatforms = [];
    }
}
// Roles & permissions (app/Core/access.php): sections this user may open
$allViews = array_merge(['overview', 'targets', 'meta', 'google', 'creatives', 'keywords'], array_map(fn($mp) => 'm-' . $mp['key'], $manualPlatforms),
    $showOtt ? ['m-new'] : [], $showTaboola ? ['taboola'] : [], ['leads', 'unmapped', 'crm', 'status', 'lphygiene', 'analytics', 'capi', 'import', 'users', 'crmsettings']);
$allowedViews = array_values(array_filter($allViews, 'pqCanView'));
$allowedViews[] = 'about';                                   // About PerformIQ: every signed-in user
require_once dirname(__DIR__) . '/app/Core/version.php';
$can = fn(string $v): bool => in_array($v, $allowedViews, true);
$canGroup = fn(array $vs): bool => (bool) array_intersect($vs, $allowedViews);
$canReports = pqCan('reports');
$roleLabel = $isSuperadmin ? 'Super Admin' : (pqRoles($conn ?? null)[$role]['name'] ?? $role);

$manualCss = '';
foreach ($manualPlatforms as $mp) {
    $manualCss .= '--m-' . $mp['key'] . ':' . $mp['color'] . ';';
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
<?= pqMetricGuardTag('') ?>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PerformIQ | <?= $h($appTitle) ?></title>
    <link rel="icon" type="image/png" href="./assets/img/favicon.png">

    <script>
        // Theme before paint — shared with every embedded page via localStorage
        (function () {
            var t = 'dark';
            try { t = localStorage.getItem('performiq-theme') || 'dark'; } catch (e) {}
            document.documentElement.setAttribute('data-theme', t === 'light' ? 'light' : 'dark');
        })();
    </script>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Sora:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/apexcharts@3.54.1/dist/apexcharts.min.js"></script>

    <style>
        /* ───────────────── Tokens ───────────────── */
        :root, :root[data-theme="dark"] {
            color-scheme: dark;
            --bg: #0B0F1A;
            --surface: #111827;
            --surface-2: #161D2E;
            --border: #1E2A42;
            --border-strong: #2A3957;
            --text: #E2E8F0;
            --text-dim: #94A3B8;
            --text-faint: #64748B;
            --accent: #E8A820;
            --accent-soft: #E8A8201F;
            --hover: #1A2337;
            --good: #10B981;
            --bad: #EF4444;
            --shadow: 0 1px 2px rgba(0, 0, 0, .3);
            /* platform identity (categorical slots 1–3, dark steps) */
            --meta: #3987E5;
            --google: #D95926;
            --taboola: #199E70;
            --ott: #9B6BF2;
        }

        :root[data-theme="light"] {
            color-scheme: light;
            --bg: #F4F6FA;
            --surface: #FFFFFF;
            --surface-2: #F8FAFC;
            --border: #E2E8F0;
            --border-strong: #CBD5E1;
            --text: #0F172A;
            --text-dim: #475569;
            --text-faint: #94A3B8;
            --accent: #B7791F;
            --accent-soft: #B7791F1A;
            --hover: #F1F5F9;
            --good: #059669;
            --bad: #DC2626;
            --shadow: 0 1px 2px rgba(15, 23, 42, .06);
            --meta: #2A78D6;
            --google: #EB6834;
            --taboola: #1BAF7A;
            --ott: #7C4DDB;
        }

        * { box-sizing: border-box; }

        html, body {
            margin: 0;
            height: 100%;
            background: var(--bg);
            color: var(--text);
            font-family: 'Sora', system-ui, -apple-system, 'Segoe UI', sans-serif;
            font-size: 14px;
            -webkit-font-smoothing: antialiased;
        }

        button { font-family: inherit; }
        a { color: inherit; }
        .mono { font-family: 'JetBrains Mono', ui-monospace, monospace; font-variant-numeric: tabular-nums; }
        svg.ico { width: 18px; height: 18px; flex-shrink: 0; stroke: currentColor; fill: none; stroke-width: 1.8; stroke-linecap: round; stroke-linejoin: round; }

        /* ───────────────── Layout ───────────────── */
        .app { display: flex; height: 100vh; overflow: hidden; }

        .sidebar {
            width: 240px;
            flex-shrink: 0;
            background: var(--surface);
            border-right: 1px solid var(--border);
            display: flex;
            flex-direction: column;
            z-index: 30;
        }

        .brand {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 18px 20px;
            height: 64px;
            border-bottom: 1px solid var(--border);
        }

        .brand-mark {
            width: 32px; height: 32px; border-radius: 9px;
            background: var(--accent); color: #0B0F1A;
            display: grid; place-items: center;
            font-weight: 700; font-size: 15px;
        }

        .brand-name { font-weight: 700; font-size: 15px; letter-spacing: -0.02em; }
        .brand-sub { font-size: 10.5px; color: var(--text-faint); letter-spacing: .04em; text-transform: uppercase; margin-top: 1px; }

        .nav { flex: 1; overflow-y: auto; padding: 14px 12px; }
        .nav-group { margin-bottom: 18px; }
        .nav-label {
            font-size: 10.5px; font-weight: 600; letter-spacing: .08em; text-transform: uppercase;
            color: var(--text-faint); padding: 0 10px 8px;
        }

        .nav-item {
            display: flex; align-items: center; gap: 11px;
            width: 100%;
            padding: 9px 10px;
            border-radius: 8px;
            border: 0;
            background: transparent;
            color: var(--text-dim);
            font-size: 13.5px;
            text-align: left;
            cursor: pointer;
            text-decoration: none;
            transition: background .12s, color .12s;
        }
        .nav-item:hover { background: var(--hover); color: var(--text); }
        .nav-item.active { background: var(--accent-soft); color: var(--text); font-weight: 600; }
        .nav-item.active .nav-ico { color: var(--accent); }
        .nav-dot { width: 8px; height: 8px; border-radius: 50%; margin: 0 5px; flex-shrink: 0; }
        .nav-badge { margin-left: auto; background: var(--bad); color: #fff; border-radius: 99px; padding: 0 7px; font-size: 10.5px; font-weight: 700; line-height: 18px; }

        .sidebar-foot {
            border-top: 1px solid var(--border);
            padding: 14px 20px;
            font-size: 11.5px;
            color: var(--text-faint);
            line-height: 1.5;
        }
        .ver-link { all: unset; display: block; cursor: pointer; margin-top: 4px; font-family: 'JetBrains Mono', ui-monospace, monospace; font-size: 11px; color: var(--text-faint); }
        .ver-link:hover { color: var(--accent); }
        .ver-date { display: block; font-family: 'Sora', system-ui, sans-serif; font-size: 10.5px; }
        .ver-link:focus-visible { outline: 2px solid var(--accent); outline-offset: 2px; border-radius: 4px; }
        .menu-ver { margin-left: auto; font-family: 'JetBrains Mono', ui-monospace, monospace; font-size: 11px; color: var(--text-faint); }

        .main { flex: 1; min-width: 0; display: flex; flex-direction: column; }

        .topbar {
            height: 64px; flex-shrink: 0;
            display: flex; align-items: center; gap: 14px;
            padding: 0 24px;
            background: var(--surface);
            border-bottom: 1px solid var(--border);
        }

        .page-title { font-size: 16px; font-weight: 600; letter-spacing: -0.01em; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
        .page-sub { font-size: 12px; color: var(--text-faint); margin-top: 2px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
        .topbar-title { min-width: 0; flex: 1; }
        .topbar-actions { display: flex; align-items: center; gap: 8px; }

        .icon-btn {
            height: 36px; min-width: 36px;
            display: inline-flex; align-items: center; justify-content: center; gap: 7px;
            padding: 0 10px;
            border-radius: 8px;
            border: 1px solid var(--border);
            background: var(--surface);
            color: var(--text-dim);
            font-size: 12.5px;
            cursor: pointer;
            text-decoration: none;
            transition: background .12s, color .12s, border-color .12s;
        }
        .icon-btn:hover { background: var(--hover); color: var(--text); border-color: var(--border-strong); }
        .icon-btn[hidden] { display: none; }

        .menu-btn { display: none; }

        /* user menu */
        .user { position: relative; }
        .user-btn {
            display: flex; align-items: center; gap: 10px;
            padding: 4px 6px 4px 12px;
            height: 40px;
            border-radius: 10px;
            border: 1px solid var(--border);
            background: var(--surface);
            color: var(--text);
            cursor: pointer;
        }
        .user-btn:hover { background: var(--hover); }
        .user-greet { text-align: right; line-height: 1.2; }
        .user-greet small { display: block; font-size: 10.5px; color: var(--text-faint); }
        .user-greet span { font-size: 12.5px; font-weight: 600; }
        .avatar {
            width: 30px; height: 30px; border-radius: 8px;
            background: var(--accent-soft); color: var(--accent);
            display: grid; place-items: center;
            font-size: 12px; font-weight: 700;
        }
        .user-menu {
            position: absolute; right: 0; top: calc(100% + 8px);
            width: 220px;
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: 12px;
            box-shadow: 0 12px 32px rgba(0, 0, 0, .25);
            padding: 6px;
            display: none;
            z-index: 50;
        }
        .user.open .user-menu { display: block; }
        .user-menu-head { padding: 10px 12px 12px; border-bottom: 1px solid var(--border); margin-bottom: 6px; }
        .user-menu-head b { display: block; font-size: 13px; }
        .user-menu-head small { color: var(--text-faint); font-size: 11.5px; text-transform: capitalize; }
        .user-menu a, .user-menu button {
            display: flex; align-items: center; gap: 10px;
            width: 100%;
            padding: 9px 12px;
            border: 0; border-radius: 8px;
            background: transparent;
            color: var(--text-dim);
            font-size: 13px;
            text-decoration: none;
            cursor: pointer;
            text-align: left;
        }
        .user-menu a:hover, .user-menu button:hover { background: var(--hover); color: var(--text); }
        .user-menu .danger:hover { color: var(--bad); }

        /* views */
        .content { flex: 1; position: relative; min-height: 0; }
        .view { position: absolute; inset: 0; display: none; }
        .view.active { display: block; }
        .view-frame iframe { width: 100%; height: 100%; border: 0; display: block; background: var(--bg); }
        .frame-loading {
            position: absolute; inset: 0; display: grid; place-items: center;
            color: var(--text-faint); font-size: 13px; pointer-events: none;
        }
        .view-native { overflow-y: auto; }

        /* ───────────────── Overview ───────────────── */
        .ov { max-width: 1440px; margin: 0 auto; padding: 24px; display: flex; flex-direction: column; gap: 20px; }

        .toolbar {
            display: flex; flex-wrap: wrap; align-items: center; gap: 10px;
        }
        .seg {
            display: inline-flex; padding: 3px; gap: 2px;
            background: var(--surface); border: 1px solid var(--border); border-radius: 9px;
        }
        .seg button {
            border: 0; background: transparent; color: var(--text-dim);
            padding: 6px 12px; border-radius: 6px; font-size: 12.5px; cursor: pointer; white-space: nowrap;
        }
        .seg button:hover { color: var(--text); }
        .seg button.on { background: var(--hover); color: var(--text); font-weight: 600; box-shadow: var(--shadow); }
        .pdf-export { display: flex; gap: 6px; align-items: center; }
        .pdf-export select { background: var(--surface); color: var(--text); border: 1px solid var(--border); border-radius: 8px; padding: 7px 8px; font: inherit; font-size: 12px; }
        .pdf-btn { background: var(--accent) !important; color: #111 !important; border-color: var(--accent) !important; font-weight: 600; white-space: nowrap; }
        .pdf-btn:disabled { opacity: .6; cursor: progress; }
        .rep-wrap { position: relative; }
        .rep-caret { font-size: 10px; margin-left: 2px; }
        .rep-menu { position: absolute; right: 0; top: calc(100% + 6px); z-index: 40; width: 290px; background: var(--surface); border: 1px solid var(--border); border-radius: 10px; box-shadow: 0 12px 32px rgba(0,0,0,.28); padding: 6px; }
        .rep-menu[hidden] { display: none; }
        .rep-head { font-size: 10.5px; text-transform: uppercase; letter-spacing: .06em; color: var(--text-faint); padding: 8px 10px 4px; }
        .rep-menu button { display: block; width: 100%; text-align: left; background: transparent; border: 0; border-radius: 7px; padding: 8px 10px; color: var(--text); font: inherit; cursor: pointer; }
        .rep-menu button:hover, .rep-menu button:focus-visible { background: var(--hover); outline: none; }
        .rep-menu b { display: block; font-size: 13px; font-weight: 600; }
        .rep-menu small { display: block; font-size: 11.5px; color: var(--text-dim); margin-top: 1px; }
        .date-custom { display: none; align-items: center; gap: 6px; }
        .date-custom.show { display: inline-flex; }
        .date-custom input {
            height: 34px; padding: 0 8px; border-radius: 8px;
            border: 1px solid var(--border); background: var(--surface); color: var(--text);
            font-family: inherit; font-size: 12.5px;
        }
        .toolbar .spacer { flex: 1; }
        .range-label { font-size: 12px; color: var(--text-faint); }
        .gbar { flex-shrink: 0; display: flex; align-items: center; gap: 10px; flex-wrap: wrap; padding: 10px 24px; background: var(--bg); border-bottom: 1px solid var(--border); }
        .gbar[hidden] { display: none; }
        .gbar-lbl { font-size: 11px; font-weight: 600; text-transform: uppercase; letter-spacing: .06em; color: var(--text-faint); }
        #ov-targets { margin: 0; }

        .legend { display: flex; gap: 16px; flex-wrap: wrap; font-size: 12px; color: var(--text-dim); }
        .legend span { display: inline-flex; align-items: center; gap: 6px; }
        .legend span[hidden] { display: none; }   /* manual platforms (OTT Video, Display …) only when they have numbers */
        .legend i { width: 10px; height: 10px; border-radius: 3px; display: inline-block; }

        .kpis { display: grid; grid-template-columns: repeat(6, minmax(0, 1fr)); gap: 14px; }
        @media (max-width: 1280px) { .kpis { grid-template-columns: repeat(3, minmax(0, 1fr)); } }
        @media (max-width: 560px) { .kpis { grid-template-columns: repeat(2, minmax(0, 1fr)); } .kpi-value { font-size: 20px; } }
        #ov-notice:empty { display: none; }
        .kpi {
            background: var(--surface); border: 1px solid var(--border); border-radius: 12px;
            padding: 16px 16px 14px;
            display: flex; flex-direction: column; gap: 6px;
        }
        .kpi-label { font-size: 11.5px; color: var(--text-dim); font-weight: 500; }
        .kpi-value { font-size: 24px; font-weight: 600; letter-spacing: -0.02em; }
        .kpi-sub { font-size: 11.5px; color: var(--text-faint); min-height: 15px; }
        .split { display: flex; gap: 2px; height: 6px; border-radius: 3px; overflow: hidden; background: var(--hover); margin-top: 4px; }
        .split i { display: block; height: 100%; min-width: 2px; }

        .grid-2 { display: grid; grid-template-columns: 1.4fr 1fr; gap: 20px; }
        .card {
            background: var(--surface); border: 1px solid var(--border); border-radius: 12px;
            padding: 18px 20px;
            min-width: 0;
        }
        .card-head { display: flex; align-items: flex-start; justify-content: space-between; gap: 12px; margin-bottom: 12px; }
        .card-title { font-size: 14px; font-weight: 600; }
        .card-sub { font-size: 12px; color: var(--text-faint); margin-top: 3px; }

        .multiples { display: grid; grid-template-columns: repeat(3, 1fr); gap: 8px; }
        .multiples h4 { margin: 0 0 2px; font-size: 12px; font-weight: 500; color: var(--text-dim); }

        .funnel { display: flex; flex-direction: column; gap: 14px; margin-top: 6px; }
        .f-row { display: grid; grid-template-columns: 96px 1fr 92px; align-items: center; gap: 12px; font-size: 12.5px; }
        .f-row .lbl { color: var(--text-dim); }
        .f-track { height: 26px; background: var(--hover); border-radius: 6px; overflow: hidden; display: flex; gap: 2px; }
        .f-track i { display: block; height: 100%; }
        .f-track i:last-child { border-radius: 0 4px 4px 0; }
        .f-val { text-align: right; }
        .f-val b { display: block; font-size: 14px; }
        .f-val small { color: var(--text-faint); font-size: 11px; }

        table.tbl { width: 100%; border-collapse: collapse; font-size: 13px; }
        .tbl th {
            text-align: right; font-weight: 500; font-size: 11.5px; color: var(--text-faint);
            padding: 10px 12px; border-bottom: 1px solid var(--border); white-space: nowrap;
        }
        .tbl th:first-child, .tbl td:first-child { text-align: left; }
        .tbl td { text-align: right; padding: 12px; border-bottom: 1px solid var(--border); white-space: nowrap; }
        .tbl tbody tr { cursor: pointer; }
        .tbl tbody tr:hover td { background: var(--hover); }
        .tbl tfoot td { font-weight: 600; border-bottom: 0; }
        .tbl .pf { display: inline-flex; align-items: center; gap: 9px; font-weight: 600; }
        .tbl .pf i { width: 10px; height: 10px; border-radius: 3px; display: inline-block; }
        .tbl .open { color: var(--text-faint); font-size: 12px; }
        .tbl-wrap { overflow-x: auto; margin: 0 -8px; padding: 0 8px; }

        .state { font-size: 11.5px; padding: 2px 8px; border-radius: 99px; border: 1px solid var(--border); color: var(--text-dim); }
        .state.err { color: var(--bad); border-color: color-mix(in srgb, var(--bad) 40%, transparent); }
        .state.ok { color: var(--good); border-color: color-mix(in srgb, var(--good) 40%, transparent); }

        .notice {
            font-size: 12.5px; color: var(--text-dim);
            background: var(--surface); border: 1px dashed var(--border-strong);
            border-radius: 10px; padding: 10px 14px;
        }
        .notice b { color: var(--bad); font-weight: 600; }

        .skeleton { color: transparent !important; background: linear-gradient(90deg, var(--hover), var(--surface-2), var(--hover)); background-size: 200% 100%; animation: sk 1.2s infinite; border-radius: 6px; }
        @keyframes sk { to { background-position: -200% 0; } }

        .spin { animation: rot 1s linear infinite; }
        @keyframes rot { to { transform: rotate(360deg); } }

        /* ───────────────── Responsive ───────────────── */
        @media (max-width: 1100px) {
            .grid-2 { grid-template-columns: 1fr; }
        }
        @media (max-width: 900px) {
            .sidebar { position: fixed; inset: 0 auto 0 0; transform: translateX(-100%); transition: transform .2s ease; box-shadow: 0 0 40px rgba(0, 0, 0, .4); }
            .app.nav-open .sidebar { transform: none; }
            .scrim { display: none; position: fixed; inset: 0; background: rgba(0, 0, 0, .45); z-index: 25; }
            .app.nav-open .scrim { display: block; }
            .menu-btn { display: inline-flex; }
            .topbar { padding: 0 16px; gap: 10px; }
            .user-greet, .hide-sm { display: none; }
            .ov { padding: 16px; }
            .multiples { grid-template-columns: 1fr; }
            #range-seg { max-width: 100%; overflow-x: auto; scrollbar-width: none; }
            .gbar { padding: 8px 16px; } .gbar-lbl { display: none; }
            .toolbar .legend { width: 100%; }
        }
        @media (max-width: 600px) {
            /* phone: the page title gets the room — no subtitle, no "new tab", avatar only */
            .topbar { gap: 8px; padding: 0 12px; }
            .topbar-actions { gap: 6px; }
            .page-sub, #newtab-btn { display: none !important; }
            .page-title { font-size: 15px; }
            .icon-btn { padding: 0 9px; }
            .user-btn > .ico { display: none; }
            /* dates: every choice visible on two rows instead of a hidden scroll */
            #range-seg { overflow: visible; flex-wrap: wrap; width: 100%; }
            #range-seg button { flex: 1 1 30%; padding-left: 6px; padding-right: 6px; }
            .gbar { flex-wrap: wrap; row-gap: 6px; }
            .date-custom { width: 100%; flex-wrap: wrap; }
            .date-custom input[type=date] { flex: 1 1 130px; min-width: 0; }
        }
    </style>
    <style>/* manual platform colours (app/Ads/ott.php) */ :root { <?= $manualCss ?> } .nav-add { opacity: .72; font-size: 12.5px; } .nav-add:hover, .nav-add.active { opacity: 1; }</style>
    <script src="assets/js/target_report.js?v=1"></script>
    <?= pqViewTag('') ?>
    <?= pqDatesTag() ?>
</head>

<body>
    <!-- SVG icon sprite -->
    <svg width="0" height="0" style="position:absolute" aria-hidden="true">
        <symbol id="i-overview" viewBox="0 0 24 24"><rect x="3" y="3" width="7" height="9" rx="1.5"/><rect x="14" y="3" width="7" height="5" rx="1.5"/><rect x="14" y="12" width="7" height="9" rx="1.5"/><rect x="3" y="16" width="7" height="5" rx="1.5"/></symbol>
        <symbol id="i-leads" viewBox="0 0 24 24"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></symbol>
        <symbol id="i-analytics" viewBox="0 0 24 24"><path d="M3 3v18h18"/><path d="M7 15l4-4 3 3 5-6"/></symbol>
        <symbol id="i-capi" viewBox="0 0 24 24"><path d="M13 2 3 14h9l-1 8 10-12h-9l1-8z"/></symbol>
        <symbol id="i-import" viewBox="0 0 24 24"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="M17 8l-5-5-5 5"/><path d="M12 3v12"/></symbol>
        <symbol id="i-image" viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="9" cy="10" r="2"/><path d="m21 17-5-5-9 8"/></symbol>
        <symbol id="i-pulse" viewBox="0 0 24 24"><path d="M3 12h4l3-8 4 16 3-8h4"/></symbol>
        <symbol id="i-key" viewBox="0 0 24 24"><circle cx="11" cy="11" r="7"/><path d="m21 21-4.35-4.35"/><path d="M8 11h6M11 8v6"/></symbol>
        <symbol id="i-target" viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1.5"/></symbol>
        <symbol id="i-plug" viewBox="0 0 24 24"><path d="M9 2v6M15 2v6M6 8h12v4a6 6 0 0 1-12 0V8zM12 18v4"/></symbol>
        <symbol id="i-userplus" viewBox="0 0 24 24"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M19 8v6M22 11h-6"/></symbol>
        <symbol id="i-info" viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M12 11v5"/><path d="M12 8h.01"/></symbol>
        <symbol id="i-logout" viewBox="0 0 24 24"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="M16 17l5-5-5-5"/><path d="M21 12H9"/></symbol>
        <symbol id="i-sun" viewBox="0 0 24 24"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M4.93 19.07l1.41-1.41M17.66 6.34l1.41-1.41"/></symbol>
        <symbol id="i-moon" viewBox="0 0 24 24"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></symbol>
        <symbol id="i-refresh" viewBox="0 0 24 24"><path d="M21 12a9 9 0 1 1-3-6.7L21 8"/><path d="M21 3v5h-5"/></symbol>
        <symbol id="i-external" viewBox="0 0 24 24"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><path d="M15 3h6v6"/><path d="M10 14 21 3"/></symbol>
        <symbol id="i-menu" viewBox="0 0 24 24"><path d="M3 6h18M3 12h18M3 18h18"/></symbol>
        <symbol id="i-chevron" viewBox="0 0 24 24"><path d="m6 9 6 6 6-6"/></symbol>
    </svg>

    <div class="app" id="app">
        <!-- ───────────── Sidebar ───────────── -->
        <aside class="sidebar" id="sidebar">
            <div class="brand">
                <div class="brand-mark">P</div>
                <div>
                    <div class="brand-name">PerformIQ</div>
                    <div class="brand-sub">by Webzaa</div>
                </div>
            </div>

            <nav class="nav" id="nav">
                <?php if ($can('overview')) { ?>
                <div class="nav-group">
                    <div class="nav-label">Overview</div>
                    <button class="nav-item" data-view="overview">
                        <svg class="ico nav-ico"><use href="#i-overview"/></svg> All Platforms
                    </button>
                    <?php if ($can('targets')) { ?>
                    <button class="nav-item" data-view="targets">
                        <svg class="ico nav-ico"><use href="#i-target"/></svg> Targets
                    </button>
                    <?php } ?>
                </div>
                <?php } elseif ($can('targets')) { ?>
                <div class="nav-group">
                    <div class="nav-label">Overview</div>
                    <button class="nav-item" data-view="targets">
                        <svg class="ico nav-ico"><use href="#i-target"/></svg> Targets
                    </button>
                </div>
                <?php } ?>
                <?php if ($canGroup(array_merge(['meta', 'google', 'm-new', 'taboola'], array_map(fn($mp) => 'm-' . $mp['key'], $manualPlatforms)))) { ?>
                <div class="nav-group">
                    <div class="nav-label">Ad Platforms</div>
                    <?php if ($can('meta')) { ?><button class="nav-item" data-view="meta"><span class="nav-dot" style="background:var(--meta)"></span> Meta Ads</button><?php } ?>
                    <?php if ($can('google')) { ?><button class="nav-item" data-view="google"><span class="nav-dot" style="background:var(--google)"></span> Google Ads</button><?php } ?>
                    <?php foreach ($manualPlatforms as $mp) { if (!$can('m-' . $mp['key'])) { continue; } ?><button class="nav-item" data-view="m-<?= $h($mp['key']) ?>"><span class="nav-dot" style="background:<?= $h($mp['color']) ?>"></span> <?= $h($mp['name']) ?></button><?php } ?>
                    <?php if ($can('m-new')) { ?><button class="nav-item nav-add" data-view="m-new" title="Add a platform whose numbers you enter or paste by hand"><span class="nav-dot" style="background:transparent;border:1px dashed var(--text-faint)"></span> Add platform</button><?php } ?>
                    <?php if ($can('taboola')) { ?><button class="nav-item" data-view="taboola"><span class="nav-dot" style="background:var(--taboola)"></span> Taboola</button><?php } ?>
                </div>
                <?php } ?>
                <?php if ($canGroup(['creatives', 'keywords'])) { ?>
                <div class="nav-group">
                    <div class="nav-label">Insights</div>
                    <?php if ($can('creatives')) { ?><button class="nav-item" data-view="creatives"><svg class="ico nav-ico"><use href="#i-image"/></svg> Creatives &amp; Insights</button><?php } ?>
                    <?php if ($can('keywords')) { ?><button class="nav-item" data-view="keywords"><svg class="ico nav-ico"><use href="#i-key"/></svg> Keyword Analysis</button><?php } ?>
                </div>
                <?php } ?>
                <?php if ($canGroup(['leads', 'unmapped', 'crm', 'status'])) { ?>
                <div class="nav-group">
                    <div class="nav-label">CRM</div>
                    <?php if ($can('leads')) { ?>
                    <button class="nav-item" data-view="leads">
                        <svg class="ico nav-ico"><use href="#i-leads"/></svg> Leads &amp; CRM
                    </button>
                    <?php } if ($can('unmapped')) { ?>
                    <button class="nav-item" data-view="unmapped">
                        <svg class="ico nav-ico"><use href="#i-leads"/></svg> Unmapped Leads <span class="nav-badge" id="nav-unmapped-badge" hidden></span>
                    </button>
                    <?php } if ($can('crm')) { ?>
                    <button class="nav-item" data-view="crm">
                        <svg class="ico nav-ico"><use href="#i-capi"/></svg> CRM Push <span class="nav-badge" id="nav-crm-badge" hidden title="Leads that did not reach the CRM (all time)"></span>
                    </button>
                    <?php } if ($can('status')) { ?>
                    <button class="nav-item" data-view="status">
                        <svg class="ico nav-ico"><use href="#i-import"/></svg> Upload Lead Status
                    </button>
                    <?php } ?>
                </div>
                <?php } ?>
                <?php if ($canGroup(['lphygiene', 'analytics', 'capi', 'import'])) { ?>
                <div class="nav-group">
                    <div class="nav-label">Tools</div>
                    <?php if ($can('lphygiene')) { ?>
                    <button class="nav-item" data-view="lphygiene">
                        <svg class="ico nav-ico"><use href="#i-pulse"/></svg> LP Hygiene
                    </button>
                    <?php } if ($can('analytics')) { ?>
                    <button class="nav-item" data-view="analytics">
                        <svg class="ico nav-ico"><use href="#i-analytics"/></svg> Web Analytics
                    </button>
                    <?php } if ($can('capi')) { ?>
                    <button class="nav-item" data-view="capi">
                        <svg class="ico nav-ico"><use href="#i-capi"/></svg> Meta CAPI
                    </button>
                    <?php } if ($can('import')) { ?>
                    <button class="nav-item" data-view="import">
                        <svg class="ico nav-ico"><use href="#i-import"/></svg> Import Leads
                    </button>
                    <?php } ?>
                </div>
                <?php } ?>
                <?php if ($isSuperadmin) { ?>
                <div class="nav-group">
                    <div class="nav-label">Admin</div>
                    <button class="nav-item" data-view="users">
                        <svg class="ico nav-ico"><use href="#i-userplus"/></svg> Users &amp; Roles
                    </button>
                    <button class="nav-item" data-view="crmsettings">
                        <svg class="ico nav-ico"><use href="#i-plug"/></svg> CRM Settings
                    </button>
                </div>
                <?php } ?>
            </nav>

            <div class="sidebar-foot"><?= $h($appTitle) ?>
                <button class="ver-link" data-view="about" title="About PerformIQ — what's new">PerformIQ <?= $h(pqVersionLabel()) ?><span class="ver-date">Updated <?= $h(pqReleaseDate(PQ_RELEASED)) ?></span></button>
            </div>
        </aside>
        <div class="scrim" id="scrim"></div>

        <!-- ───────────── Main ───────────── -->
        <div class="main">
            <header class="topbar">
                <button class="icon-btn menu-btn" id="menu-btn" aria-label="Open navigation">
                    <svg class="ico"><use href="#i-menu"/></svg>
                </button>
                <div class="topbar-title">
                    <div class="page-title" id="page-title">All Platforms</div>
                    <div class="page-sub" id="page-sub"><?= $showTaboola ? 'Meta, Google &amp; Taboola combined' : 'Meta &amp; Google combined' ?></div>
                </div>

                <div class="topbar-actions">
                    <button class="icon-btn" id="reload-btn" title="Reload this section">
                        <svg class="ico" id="reload-ico"><use href="#i-refresh"/></svg><span class="hide-sm">Refresh</span>
                    </button>
                    <a class="icon-btn" id="newtab-btn" target="_blank" rel="noopener" title="Open this section in a new tab" hidden>
                        <svg class="ico"><use href="#i-external"/></svg>
                    </a>
                    <button class="icon-btn" id="theme-btn" title="Switch dark / light theme" aria-label="Switch theme">
                        <svg class="ico"><use id="theme-ico" href="#i-sun"/></svg>
                    </button>

                    <div class="user" id="user">
                        <button class="user-btn" id="user-btn" aria-haspopup="true" aria-expanded="false">
                            <div class="user-greet">
                                <small><?= $h($greeting) ?>,</small>
                                <span><?= $h($username) ?></span>
                            </div>
                            <div class="avatar"><?= $h($initials) ?></div>
                            <svg class="ico" style="width:14px;height:14px;color:var(--text-faint)"><use href="#i-chevron"/></svg>
                        </button>
                        <div class="user-menu" role="menu">
                            <div class="user-menu-head">
                                <b><?= $h($username) ?></b>
                                <small><?= $h($roleLabel) ?></small>
                            </div>
                            <?php if ($isSuperadmin) { ?>
                                <button data-view="users" role="menuitem"><svg class="ico"><use href="#i-userplus"/></svg> Users &amp; Roles</button>
                            <?php } ?>
                            <button data-view="about" role="menuitem"><svg class="ico"><use href="#i-info"/></svg> About PerformIQ <span class="menu-ver"><?= $h(pqVersionLabel()) ?></span></button>
                            <a class="danger" href="leads/logout.php" role="menuitem"><svg class="ico"><use href="#i-logout"/></svg> Logout</a>
                        </div>
                    </div>
                </div>
            </header>

            <!-- One date filter for every dashboard: All Platforms, Meta, Google, Taboola, manual platforms (sent to the embedded pages) -->
            <div class="gbar" id="gbar">
                <span class="gbar-lbl">Dates</span>
                <div class="seg" id="range-seg">
                    <button data-range="today">Today</button>
                    <button data-range="yesterday">Yesterday</button>
                    <button data-range="last_7d">7 days</button>
                    <button data-range="last_30d" class="on">30 days</button>
                    <button data-range="this_month">This month</button>
                    <button data-range="last_month">Last month</button>
                    <button data-range="last_1y" title="The last 12 months, till today">1 year</button>
                    <button data-range="all_time" title="From the first lead of this project till today">All time</button>
                    <button data-range="custom">Custom</button>
                </div>
                <div class="date-custom" id="date-custom">
                    <input type="date" id="d-since" aria-label="From date">
                    <span style="color:var(--text-faint)">–</span>
                    <input type="date" id="d-until" aria-label="To date">
                    <button class="icon-btn" id="d-apply">Apply</button>
                </div>
                <span class="range-label" id="range-label"></span>
            </div>

            <div class="content" id="content">
                <!-- Overview (native) -->
                <section class="view view-native" id="view-overview">
                    <div class="ov">
                        <div class="toolbar">
                            <div id="ov-aware"></div>
                            <span class="spacer"></span>
                            <div class="pdf-export"<?= $canReports ? '' : ' hidden style="display:none"' ?> title="Reports: campaign report for the selected dates, or the daily / weekly / monthly report (same as the emails)">
                                <select id="pdf-detail" aria-label="Report detail">
                                    <option value="campaign">Campaigns</option>
                                    <option value="adset" selected>+ Ad sets / groups</option>
                                    <option value="ad">+ Ads</option>
                                </select>
                                <div class="rep-wrap">
                                    <button class="icon-btn pdf-btn" id="pdf-btn" aria-haspopup="true" aria-expanded="false">↓ Reports <span class="rep-caret">▾</span></button>
                                    <div class="rep-menu" id="rep-menu" role="menu" hidden>
                                        <div class="rep-head">Selected dates</div>
                                        <button role="menuitem" data-rep="portfolio"><b>Campaign report</b><small id="rep-sub-portfolio">The date filter above · detail from the list on the left</small></button>
                                        <div class="rep-head">Same as the email reports · Meta + Google</div>
                                        <button role="menuitem" data-rep="daily"><b>Daily report</b><small id="rep-sub-daily">Yesterday</small></button>
                                        <button role="menuitem" data-rep="weekly"><b>Weekly report</b><small id="rep-sub-weekly">Last full week (Mon–Sun)</small></button>
                                        <button role="menuitem" data-rep="monthly"><b>Monthly report</b><small id="rep-sub-monthly">Last full month</small></button>
                                    </div>
                                </div>
                            </div>
                            <div class="legend">
                                <span><i style="background:var(--meta)"></i>Meta</span>
                                <span><i style="background:var(--google)"></i>Google</span>
                                <?php foreach ($manualPlatforms as $mp) { ?><span id="legend-m-<?= $h($mp['key']) ?>" hidden><i style="background:<?= $h($mp['color']) ?>"></i><?= $h($mp['name']) ?></span><?php } ?>
                                <?php if ($showTaboola) { ?><span><i style="background:var(--taboola)"></i>Taboola</span><?php } ?>
                            </div>
                        </div>

                        <div id="ov-notice"></div>

                        <div class="kpis" id="kpis"></div>
                        <div id="ov-targets" hidden></div>

                        <div class="grid-2">
                            <div class="card">
                                <div class="card-head">
                                    <div>
                                        <div class="card-title">Platform comparison</div>
                                        <div class="card-sub">Spend, leads and cost per lead for the selected period</div>
                                    </div>
                                </div>
                                <div class="multiples">
                                    <div><h4>Spend</h4><div id="ch-spend"></div></div>
                                    <div><h4>Leads</h4><div id="ch-leads"></div></div>
                                    <div><h4>Cost per lead</h4><div id="ch-cpl"></div></div>
                                </div>
                            </div>
                            <div class="card">
                                <div class="card-head">
                                    <div>
                                        <div class="card-title">Lead funnel</div>
                                        <div class="card-sub">All platforms · segment = platform share</div>
                                    </div>
                                </div>
                                <div class="funnel" id="funnel"></div>
                            </div>
                        </div>

                        <div class="card">
                            <div class="card-head">
                                <div>
                                    <div class="card-title">Daily trend</div>
                                    <div class="card-sub" id="trend-sub">Per platform, per day</div>
                                </div>
                                <div class="seg" id="trend-seg">
                                    <button data-metric="leads" class="on">Leads</button>
                                    <button data-metric="spend">Spend</button>
                                </div>
                            </div>
                            <div id="ch-trend"></div>
                        </div>

                        <div class="card">
                            <div class="card-head">
                                <div>
                                    <div class="card-title">Platform breakdown</div>
                                    <div class="card-sub">Click a row to open that platform's full dashboard</div>
                                </div>
                            </div>
                            <div class="tbl-wrap">
                                <table class="tbl">
                                    <thead>
                                        <tr>
                                            <th>Platform</th><th>Spend</th><th>Share</th><th>Impr.</th><th>Clicks</th><th>CTR</th>
                                            <th>Leads</th><th>CPL</th><th>Qualified</th><th>CPQL</th><th>Site visits</th><th>CPSV</th><th></th>
                                        </tr>
                                    </thead>
                                    <tbody id="tbl-body"></tbody>
                                    <tfoot id="tbl-foot"></tfoot>
                                </table>
                            </div>
                        </div>
                    </div>
                </section>
                <!-- Embedded sections are created on first open (see VIEWS) -->
            </div>
        </div>
    </div>

    <script>
    (function () {
        'use strict';

        // ───────────────── Sections ─────────────────
        const SHOW_TABOOLA = <?= $showTaboola ? 'true' : 'false' ?>;
        const SHOW_OTT = <?= $showOtt ? 'true' : 'false' ?>;
        const MANUAL = <?= json_encode(array_map(fn($p) => ['key' => $p['key'], 'name' => $p['name']], $manualPlatforms), JSON_UNESCAPED_UNICODE | JSON_HEX_TAG) ?>;
        const VIEWS = {
            overview:  { title: 'All Platforms', sub: SHOW_TABOOLA ? 'Meta, Google & Taboola combined' : 'Meta & Google combined' },
            targets:   { title: 'Targets', sub: 'The plan per month or quarter, shown against the real numbers on every dashboard', src: 'targets.php' },
            meta:      { title: 'Meta Ads', sub: 'Campaigns, funnel and AI insights', src: 'ads/metadashboard.php' },
            google:    { title: 'Google Ads', sub: 'Campaigns, funnel and AI insights', src: 'ads/googledashboard.php' },
            creatives: { title: 'Creatives & Insights', sub: 'Every ad with its image or video, results, budgets — and what to do next', src: 'creatives.php' },
            keywords: { title: 'Keyword Analysis', sub: 'Google keywords and search terms with CRM leads — and what to do next', src: 'keywords.php' },
            ...Object.fromEntries(MANUAL.map(p => ['m-' + p.key, { title: p.name, sub: 'Numbers added or pasted by hand', src: 'ads/ottdashboard.php?p=' + encodeURIComponent(p.key) }])),
            ...(SHOW_OTT ? { 'm-new': { title: 'Add a platform', sub: 'A platform whose numbers you add or paste by hand', src: 'ads/ottdashboard.php?new=1' } } : {}),
            ...(SHOW_TABOOLA ? { taboola: { title: 'Taboola', sub: 'Native ads performance', src: 'ads/tabooladashboard.php' } } : {}),
            leads:     { title: 'Leads & CRM', sub: 'All leads from every source, follow-ups and status', src: 'index.php' },
            unmapped:  { title: 'Unmapped Leads', sub: 'Meta and Google leads not under one of this project\'s campaigns', src: 'unmapped_leads.php' },
            crm:       { title: 'CRM Push', sub: 'Leads that reached the CRM, and the ones that failed or were never sent', src: 'crm_push.php' },
            status:    { title: 'Upload Lead Status', sub: 'Update lead status, site visits and platform (CPQL / CPSV) from a CRM export', src: 'status_upload.php' },
            lphygiene: { title: 'LP Hygiene', sub: 'Landing page speed, tracking, lead form and test leads (Meta + landing page)', src: 'lp_hygiene.php' },
            analytics: { title: 'Web Analytics', sub: 'Visitors, sessions and on-site behaviour', src: 'analytics.php' },
            capi:      { title: 'Meta CAPI', sub: 'Send offline conversions to Meta', src: 'meta_capi.php' },
            import:    { title: 'Import Leads', sub: 'Bulk-upload leads from CSV', src: 'import.php' },
            about:     { title: 'About PerformIQ', sub: 'Version <?= $h(pqVersionLabel()) ?> · updated <?= $h(pqReleaseDate(PQ_RELEASED)) ?> — what\'s new, FAQs and help', src: 'about.php' },
            <?php if ($isSuperadmin) { ?>
            users:     { title: 'Users & Roles', sub: 'Who can sign in, and what each role can open and do', src: 'leads/users.php' },
            crmsettings: { title: 'CRM Settings', sub: 'Meta Conversions API and Salesforce (Send to CRM)', src: 'crm_settings.php' },
            <?php } ?>
        };
        // Roles & permissions: drop the sections this user may not open (the pages and APIs check it too)
        const ALLOWED = <?= json_encode($allowedViews) ?>;
        Object.keys(VIEWS).forEach(k => { if (!ALLOWED.includes(k)) delete VIEWS[k]; });
        const FIRST_VIEW = Object.keys(VIEWS)[0] || null;

        const $ = (s, el = document) => el.querySelector(s);
        const $$ = (s, el = document) => [...el.querySelectorAll(s)];
        const content = $('#content');
        let current = null;

        const withParams = (src, extra) => src + (src.includes('?') ? '&' : '?') + extra;

        function ensureFrame(id) {
            let sec = document.getElementById('view-' + id);
            if (sec) return sec;
            const v = VIEWS[id];
            sec = document.createElement('section');
            sec.className = 'view view-frame';
            sec.id = 'view-' + id;
            sec.innerHTML = '<div class="frame-loading">Loading ' + v.title + '…</div>';
            const f = document.createElement('iframe');
            f.title = v.title;
            const r0 = isDateView(id) ? gRange() : null;
            f.src = withParams(v.src, 'embed=1' + (r0 ? `&since=${r0.s}&until=${r0.u}` : ''));
            f.addEventListener('load', () => {
                const l = sec.querySelector('.frame-loading');
                if (l) l.remove();
                applyThemeToFrame(f);
                const r1 = isDateView(id) ? gRange() : null;           // in case the dates changed while it loaded
                if (r1) { try { f.contentWindow.postMessage({ type: 'pq-range', since: r1.s, until: r1.u, preset: OV.range }, '*'); } catch (e) {} }
            });
            sec.appendChild(f);
            content.appendChild(sec);
            return sec;
        }

        /* ── one date filter for every dashboard ── */
        function isDateView(id) { return ['overview', 'meta', 'google', 'creatives', 'keywords', 'taboola'].includes(id) || (String(id).startsWith('m-') && id !== 'm-new'); }
        function gRange() {
            if (OV.range === 'custom') {
                const s = $('#d-since').value, u = $('#d-until').value;
                return s && u && s <= u ? { s, u } : null;
            }
            const [a, b] = rangeDates(OV.range);
            return { s: ymd(a), u: ymd(b) };
        }
        function applyRange() {
            const r = gRange();
            if (!r) { $('#d-since').focus(); return; }
            $('#range-label').textContent = fmtRange(r.s, r.u);
            try { localStorage.setItem('pq-range', JSON.stringify(OV.range === 'custom' ? { p: 'custom', s: r.s, u: r.u } : { p: OV.range })); } catch (e) {}
            document.querySelectorAll('.view-frame iframe').forEach(f => {
                try { f.contentWindow.postMessage({ type: 'pq-range', since: r.s, until: r.u, preset: OV.range }, '*'); } catch (e) {}
            });
            if (current === 'overview') loadOverview(); else OV.loaded = false;   // the overview reloads when opened
        }

        function show(id) {
            if (id === 'ott') id = 'm-ott';                       // old link to OTT Video
            if (!VIEWS[id]) id = FIRST_VIEW;
            if (!id) { $('#page-title').textContent = 'No access yet'; $('#page-sub').textContent = 'Your role has no sections. Ask a Super Admin to give your role access.'; return; }
            const v = VIEWS[id];
            if (v.src) ensureFrame(id);
            $$('.view', content).forEach(el => el.classList.toggle('active', el.id === 'view-' + id));
            $$('[data-view]').forEach(el => el.classList.toggle('active', el.dataset.view === id && el.classList.contains('nav-item')));
            $('#page-title').textContent = v.title;
            $('#page-sub').textContent = v.sub;
            document.title = 'PerformIQ | ' + v.title;

            const nt = $('#newtab-btn');
            if (v.src) { nt.hidden = false; nt.href = withParams(v.src, 'standalone=1'); }
            else { nt.hidden = true; }

            current = id;
            $('#gbar').hidden = !isDateView(id);
            if (location.hash !== '#' + id) history.replaceState(null, '', '#' + id);
            $('#app').classList.remove('nav-open');
            $('#user').classList.remove('open');
            if (id === 'overview' && !OV.loaded) loadOverview();
            if (id === 'overview') requestAnimationFrame(renderOverview); // charts need a visible box
        }

        document.addEventListener('click', (e) => {
            const t = e.target.closest('[data-view]');
            if (t) { e.preventDefault(); show(t.dataset.view); }
        });
        window.addEventListener('hashchange', () => show(location.hash.slice(1)));

        $('#reload-btn').addEventListener('click', () => {
            if (current === 'overview') { loadOverview(); return; }
            const f = $('#view-' + current + ' iframe');
            if (!f) return;
            try {
                // Ads dashboards: re-fetch data in place (keeps tab/filters); other pages: reload
                if (typeof f.contentWindow.handleRefresh === 'function') f.contentWindow.handleRefresh();
                else f.contentWindow.location.reload();
            } catch (e) { f.src = f.src; }
        });

        // mobile nav
        $('#menu-btn').addEventListener('click', () => $('#app').classList.toggle('nav-open'));
        $('#scrim').addEventListener('click', () => $('#app').classList.remove('nav-open'));

        // user menu
        $('#user-btn').addEventListener('click', (e) => {
            e.stopPropagation();
            const u = $('#user'); u.classList.toggle('open');
            $('#user-btn').setAttribute('aria-expanded', u.classList.contains('open'));
        });
        document.addEventListener('click', (e) => { if (!e.target.closest('#user')) $('#user').classList.remove('open'); });
        document.addEventListener('keydown', (e) => { if (e.key === 'Escape') { $('#user').classList.remove('open'); $('#app').classList.remove('nav-open'); } });

        // ───────────────── Theme ─────────────────
        const getTheme = () => document.documentElement.getAttribute('data-theme') === 'light' ? 'light' : 'dark';

        function applyThemeToFrame(f) {
            const t = getTheme();
            try {
                const w = f.contentWindow;
                if (w && typeof w.setTheme === 'function') w.setTheme(t, false);   // ads dashboards re-render charts
                else if (f.contentDocument) f.contentDocument.documentElement.setAttribute('data-theme', t);
            } catch (e) { /* not ready */ }
        }

        function setTheme(t) {
            document.documentElement.setAttribute('data-theme', t);
            try { localStorage.setItem('performiq-theme', t); } catch (e) {}
            $('#theme-ico').setAttribute('href', t === 'light' ? '#i-moon' : '#i-sun');
            $$('iframe', content).forEach(applyThemeToFrame);
            renderOverview();
        }
        $('#theme-btn').addEventListener('click', () => setTheme(getTheme() === 'light' ? 'dark' : 'light'));
        $('#theme-ico').setAttribute('href', getTheme() === 'light' ? '#i-moon' : '#i-sun');

        // ───────────────── Overview data ─────────────────
        const PLATFORMS = [
            { key: 'meta', name: 'Meta' },
            { key: 'google', name: 'Google' },
            ...MANUAL.map(p => ({ key: 'm-' + p.key, name: p.name, manual: p.key })),
            { key: 'taboola', name: 'Taboola' },
        ].filter(p => p.key !== 'taboola' || SHOW_TABOOLA);
        const OV = { loaded: false, loading: false, range: 'last_30d', since: '', until: '', metric: 'leads', data: {}, charts: {} };
        // "Target vs Achieved" card (Targets page → targets_api.php); only for roles with the Targets permission
        const OVT = (window.PQTargets && <?= json_encode(function_exists('pqCan') && pqCan('targets')) ?>)
            ? PQTargets.mount(document.getElementById('ov-targets'), { api: 'targets_api.php', platform: 'overall', pick: true,
                platforms: Object.assign({ overall: 'Overall' }, Object.fromEntries(PLATFORMS.map(p => [p.key, p.name]))) })
            : null;

        const ymd = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
        function rangeDates(r) {
            const now = new Date(); const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
            const back = (n) => { const d = new Date(today); d.setDate(d.getDate() - n); return d; };
            switch (r) {
                case 'today': return [today, today];
                case 'yesterday': return [back(1), back(1)];
                case 'last_7d': return [back(7), back(1)];
                case 'this_month': return [new Date(today.getFullYear(), today.getMonth(), 1), today];
                case 'last_month': return [new Date(today.getFullYear(), today.getMonth() - 1, 1), new Date(today.getFullYear(), today.getMonth(), 0)];
                case 'last_1y': { const d = new Date(today); d.setFullYear(d.getFullYear() - 1); d.setDate(d.getDate() + 1); return [d, today]; }   // 12 months till today
                case 'all_time': {   // from the project's first lead (window.PQ_ALL_SINCE, app/Core/access.php) till today
                    const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(window.PQ_ALL_SINCE || '');
                    const d = m ? new Date(+m[1], +m[2] - 1, +m[3]) : (() => { const x = new Date(today); x.setFullYear(x.getFullYear() - 1); return x; })();
                    return [d > today ? today : d, today];
                }
                case 'last_30d':
                default: return [back(30), back(1)];
            }
        }

        const isTestLead = (l) => {
            if (!l) return false;
            const st = String(l.lead_status || '').toUpperCase().trim();
            if (st === 'TEST' || st === 'JUNK') return true;
            if (String(l.name || '').toLowerCase().includes('test')) return true;
            if (String(l.email || '').toLowerCase().includes('test')) return true;
            const mob = String(l.mobile || '').trim();
            if (mob.toLowerCase().includes('test')) return true;
            return ['9999999999', '8888888888', '0000000000', '1234567890', '1111111111'].includes(mob);
        };

        // Each platform API returns { campaigns: [...], trend: [...] }; same totals logic as each dashboard
        function summarise(key, d) {
            const camps = Array.isArray(d.campaigns) ? d.campaigns : [];
            const n = (v) => Number(v || 0);
            let spend = 0, impressions = 0, clicks = 0, leads = 0, qualified = 0, walkins = 0;
            camps.forEach(c => {
                spend += n(c.spend); impressions += n(c.impressions); clicks += n(c.clicks);
                if (key === 'google') {
                    const ld = (c.leads_data || []).filter(l => !isTestLead(l));
                    leads += ld.length || n(c.leads);
                } else {
                    leads += n(c.leads); qualified += n(c.qualified); walkins += n(c.walkins);
                }
            });
            if (key === 'google') {
                // Same as the Google dashboard: a lead can match several campaigns, so qualified /
                // site-visit counts are unique people (by mobile → id → gclid), test leads excluded.
                const unique = (field) => {
                    const seen = new Set(); let count = 0;
                    camps.forEach(c => (c[field] || []).forEach(l => {
                        if (isTestLead(l)) return;
                        const mob = String(l.mkey || l.mobile || '').trim(), lid = String(l.id || '').trim(), gcl = String(l.gclid || '').trim();
                        const k = mob || (lid ? 'id_' + lid : (gcl ? 'gclid_' + gcl : null));
                        if (k === null) { count++; return; }
                        if (!seen.has(k)) { seen.add(k); count++; }
                    }));
                    return count;
                };
                qualified = unique('qualified_leads');
                walkins = unique('walkin_leads');
            }
            if (key === 'taboola') {   // Taboola dashboard takes these from the CRM totals
                if (d.total_qualified_crm != null) qualified = n(d.total_qualified_crm);
                if (d.total_walkins_crm != null) walkins = n(d.total_walkins_crm);
            }
            const trend = (Array.isArray(d.trend) ? d.trend : Object.values(d.trend || {}))
                .filter(t => t && t.date)
                .map(t => ({ date: String(t.date).slice(0, 10), spend: n(t.spend), leads: n(t.leads) }));
            return { spend, impressions, clicks, leads, qualified, walkins, campaigns: camps.length, trend, awareness: d.awareness || null };
        }

        // readable text for an API error item: Meta sends {stage, account_id, error: {message, code, …}}
        function pqErrText(x) {
            if (x == null) return 'error';
            if (typeof x !== 'object') return String(x);
            const inner = x.error;
            let m = x.message || (inner && typeof inner === 'object' ? (inner.error_user_msg || inner.message) : inner) || '';
            if (!m) m = x.account_id ? 'account ' + x.account_id : JSON.stringify(x);
            if (inner && typeof inner === 'object' && inner.code && !/#\d+/.test(m)) m += ' (#' + inner.code + ')';
            return String(m).slice(0, 220);
        }

        async function fetchJson(url, opts) {
            const res = await fetch(url, Object.assign({ credentials: 'same-origin' }, opts || {}));
            const text = await res.text();
            if (!res.ok) throw new Error('HTTP ' + res.status);
            let j; try { j = JSON.parse(text); } catch (e) { throw new Error('Invalid response from server'); }
            if (j && j.valid === false) throw new Error('Session expired');
            if (j && j.api_error) {
                const e = j.api_error, list = Array.isArray(e) ? e : [e];
                const msg = list.map(pqErrText);
                throw new Error([...new Set(msg)].slice(0, 2).join(' · ') + (list.length > 2 ? ` (+${list.length - 2} more)` : ''));
            }
            if (j && j.error && !j.campaigns) throw new Error(String(j.error));
            return j;
        }

        function fetchPlatform(key, since, until) {
            const json = (body) => ({ method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
            if (key === 'meta') {
                const p = new URLSearchParams({ since, until, platform: 'meta', campaign_field: 'campaign_name', adgroup_field: 'adset_name', ad_field: 'ad_name' });
                return fetchJson('ads/api.php?' + p.toString());
            }
            if (key === 'google') {
                return fetchJson('ads/googleapi.php', json({ since, until, platform: 'google', campaignsstatus: 'all', campaign_field: 'utm_campaignname', adgroup_field: 'utm_adgroupname', ad_field: 'utm_adname' }));
            }
            if (key.startsWith('m-')) return fetchJson('ads/ott_api.php?' + new URLSearchParams({ action: 'summary', p: key.slice(2), since, until }));
            return fetchJson('ads/taboolaapi.php', json({ since, until, campaignsstatus: 'all' }));
        }

        async function loadOverview() {
            let s, u;
            if (OV.range === 'custom') {
                s = $('#d-since').value; u = $('#d-until').value;
                if (!s || !u || s > u) { $('#d-since').focus(); return; }
            } else {
                const [a, b] = rangeDates(OV.range); s = ymd(a); u = ymd(b);
            }
            OV.since = s; OV.until = u; OV.loading = true; OV.loaded = true;
            if (OVT) OVT.update({ since: s, until: u });
            $('#range-label').textContent = fmtRange(s, u);
            $('#reload-ico').classList.add('spin');
            PLATFORMS.forEach(p => { OV.data[p.key] = { state: 'loading' }; });
            renderOverview();

            // Leads / Qualified / Site visits as unique people (one per mobile per platform) — same as the PDF
            const peopleP = fetchJson('ads/people_counts_api.php?' + new URLSearchParams({ since: s, until: u })).catch(() => null);
            await Promise.all(PLATFORMS.map(async (p) => {
                try {
                    const d = await fetchPlatform(p.key, s, u);
                    OV.data[p.key] = p.manual && !d.has_data
                        ? { state: 'empty' }                      // no numbers for this manual platform in the period: leave it out
                        : Object.assign({ state: 'ok' }, summarise(p.key, d));
                    if (d && d.campaign_filter && d.campaign_filter.configured === false) {
                        OV.data[p.key].note = `no campaigns linked to this project yet — open ${p.name === 'Taboola' ? 'Taboola' : p.name + ' Ads'} → ⟳ Sync with ${p.name}`;
                    }
                } catch (err) {
                    OV.data[p.key] = { state: 'error', error: err.message || 'Failed to load' };
                }
                renderOverview();   // paint each platform as it arrives
            }));
            const people = await peopleP;
            OV.people = people && people.success ? people : null;
            if (OV.people && OV.since === s && OV.until === u) {
                Object.entries(OV.people.platforms || {}).forEach(([k, v]) => {
                    const d = OV.data[k];
                    if (!d || d.state !== 'ok') return;
                    d.entries = d.leads;
                    d.leads = v.leads; d.qualified = v.qualified; d.walkins = v.sitevisits;
                });
            }
            OV.loading = false;
            $('#reload-ico').classList.remove('spin');
            renderOverview();
            // awareness / performance of Meta + Google + manual platforms together, for the tabs' note
            const aw = PLATFORMS.map(p => OV.data[p.key] && OV.data[p.key].awareness).filter(Boolean);
            if (OVAW) OVAW.info(aw.length ? PQView.sum(aw) : null);
        }
        // All / Performance / Awareness — same tabs as on the Meta / Google dashboards (cookie pq_view)
        const OVAW = window.PQView ? PQView.mount(document.getElementById('ov-aware'), { onChange: () => {
            OV.loaded = false; OV.people = null;
            if (current === 'overview') loadOverview();
            // the platform pages already open in frames reload through their own tabs (storage event)
        } }) : null;

        $('#range-seg').addEventListener('click', (e) => {
            const b = e.target.closest('button'); if (!b) return;
            $$('#range-seg button').forEach(x => x.classList.toggle('on', x === b));
            OV.range = b.dataset.range;
            const custom = OV.range === 'custom';
            $('#date-custom').classList.toggle('show', custom);
            if (custom) {
                if (!$('#d-since').value) { const [a, z] = rangeDates('last_30d'); $('#d-since').value = ymd(a); $('#d-until').value = ymd(z); }
                return;
            }
            applyRange();
        });
        $('#d-apply').addEventListener('click', applyRange);
        $('#trend-seg').addEventListener('click', (e) => {
            const b = e.target.closest('button'); if (!b) return;
            $$('#trend-seg button').forEach(x => x.classList.toggle('on', x === b));
            OV.metric = b.dataset.metric; renderTrend();
        });

        // ───────────────── Formatting ─────────────────
        const inr = (v) => {
            v = Number(v || 0);
            if (Math.abs(v) >= 1e7) return '₹' + (v / 1e7).toFixed(2) + ' Cr';
            if (Math.abs(v) >= 1e5) return '₹' + (v / 1e5).toFixed(2) + ' L';
            return '₹' + Math.round(v).toLocaleString('en-IN');
        };
        const inrFull = (v) => '₹' + Math.round(Number(v || 0)).toLocaleString('en-IN');
        const num = (v) => Math.round(Number(v || 0)).toLocaleString('en-IN');
        const ratio = (a, b) => (b > 0 ? a / b : 0);
        const pct = (v) => (v * 100).toFixed(v > 0 && v < 0.1 ? 1 : 0) + '%';
        const fmtRange = (s, u) => {
            const f = (x) => { const [y, m, d] = x.split('-').map(Number); return new Date(y, m - 1, d).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' }); };
            return s === u ? f(s) : f(s) + ' – ' + f(u);   // Today / Yesterday: one date
        };
        const cssVar = (n) => getComputedStyle(document.documentElement).getPropertyValue(n).trim();
        const colorOf = (key) => cssVar('--' + key);
        const esc = (s) => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

        // ───────────────── Render ─────────────────
        function okPlatforms() { return PLATFORMS.filter(p => OV.data[p.key] && OV.data[p.key].state === 'ok'); }
        function totals() {
            const t = { spend: 0, impressions: 0, clicks: 0, leads: 0, qualified: 0, walkins: 0, entries: 0 };
            okPlatforms().forEach(p => Object.keys(t).forEach(k => { t[k] += OV.data[p.key][k] || 0; }));
            return t;
        }

        function splitBar(metric) {
            const ok = okPlatforms(); const total = ok.reduce((a, p) => a + (OV.data[p.key][metric] || 0), 0);
            if (!total) return '<div class="split"></div>';
            return '<div class="split">' + ok.filter(p => OV.data[p.key][metric] > 0).map(p => {
                const v = OV.data[p.key][metric]; const share = v / total;
                const label = metric === 'spend' ? inrFull(v) : num(v);
                return `<i style="width:${(share * 100).toFixed(2)}%;background:var(--${p.key})" title="${p.name}: ${label} (${pct(share)})"></i>`;
            }).join('') + '</div>';
        }

        function renderKpis() {
            const anyLoading = PLATFORMS.some(p => OV.data[p.key] && OV.data[p.key].state === 'loading');
            const noneOk = okPlatforms().length === 0;
            const t = totals();
            const tiles = [
                { label: 'Total spend', value: inr(t.spend), sub: 'across ' + okPlatforms().length + ' platform' + (okPlatforms().length === 1 ? '' : 's'), split: 'spend', title: inrFull(t.spend) },
                { label: 'Leads', value: num(t.leads), sub: 'CPL ' + (t.leads ? inrFull(t.spend / t.leads) : '—') + (t.entries > t.leads ? ` · ${num(t.entries)} form entries` : ''), split: 'leads',
                  title: t.entries > t.leads ? `Unique people (one per mobile per platform). ${num(t.entries - t.leads)} repeat form entries not counted again.` : '' },
                { label: 'Qualified leads', value: num(t.qualified), sub: t.leads ? pct(ratio(t.qualified, t.leads)) + ' of leads' : '—', split: 'qualified' },
                { label: 'Cost per qualified lead', value: t.qualified ? inr(t.spend / t.qualified) : '—', sub: 'CPQL' },
                { label: 'Site visits', value: num(t.walkins), sub: t.qualified ? pct(ratio(t.walkins, t.qualified)) + ' of qualified' : '—', split: 'walkins' },
                { label: 'Cost per site visit', value: t.walkins ? inr(t.spend / t.walkins) : '—', sub: 'CPSV' },
            ];
            const sk = anyLoading && noneOk ? ' skeleton' : '';
            // Roles → "Hide numbers": drop Qualified / CPQL / Site visits / CPSV for this role
            const hq = window.pqMetricHidden && pqMetricHidden('Qualified leads');
            const shown = tiles.filter(k => !(window.pqMetricHidden && pqMetricHidden(k.label)));
            if (hq) shown.forEach(k => { if (/of qualified$/.test(k.sub)) k.sub = '&nbsp;'; });
            $('#kpis').style.gridTemplateColumns = shown.length < 6 && window.innerWidth > 1280 ? `repeat(${shown.length}, minmax(0, 1fr))` : '';
            $('#kpis').innerHTML = shown.map(k => `
                <div class="kpi">
                    <div class="kpi-label">${k.label}</div>
                    <div class="kpi-value mono${sk}" ${k.title ? `title="${k.title}"` : ''}>${k.value}</div>
                    <div class="kpi-sub">${sk ? '&nbsp;' : k.sub}</div>
                    ${k.split ? splitBar(k.split) : ''}
                </div>`).join('');
        }

        function renderNotice() {
            const errs = PLATFORMS.filter(p => OV.data[p.key] && OV.data[p.key].state === 'error');
            const notes = PLATFORMS.filter(p => OV.data[p.key] && OV.data[p.key].note);
            $('#ov-notice').innerHTML = (errs.length
                ? `<div class="notice"><b>Not included:</b> ${errs.map(p => `${p.name} (${esc(OV.data[p.key].error)})`).join(', ')}. Totals show the other platforms only — use Refresh to retry.</div>`
                : '') + notes.map(p => `<div class="notice" style="margin-top:8px">${p.name}: ${esc(OV.data[p.key].note)}</div>`).join('');
        }

        function baseChart(type, height) {
            return {
                chart: { type, height, background: 'transparent', foreColor: cssVar('--text-dim'), fontFamily: 'Sora, sans-serif', toolbar: { show: false }, animations: { enabled: false }, parentHeightOffset: 0 },
                theme: { mode: getTheme() },
                grid: { borderColor: cssVar('--border'), strokeDashArray: 0, padding: { left: 4, right: 8 } },
                tooltip: { theme: getTheme() },
                legend: { show: false },
                states: { hover: { filter: { type: 'darken', value: 0.9 } }, active: { filter: { type: 'none' } } },
            };
        }

        function draw(id, opts) {
            if (OV.charts[id]) { OV.charts[id].destroy(); delete OV.charts[id]; }
            const el = document.getElementById(id);
            if (!el || typeof ApexCharts === 'undefined') return;
            OV.charts[id] = new ApexCharts(el, opts);
            OV.charts[id].render();
        }

        function renderMultiples() {
            const ok = okPlatforms();
            const mk = (id, getter, fmt) => {
                const vals = ok.map(p => getter(OV.data[p.key]));
                const o = baseChart('bar', 150);
                Object.assign(o, {
                    series: [{ name: id, data: vals }],
                    colors: ok.map(p => colorOf(p.key)),
                    plotOptions: { bar: { horizontal: true, distributed: true, borderRadius: 4, borderRadiusApplication: 'end', barHeight: '58%' } },
                    dataLabels: { enabled: true, formatter: (v) => (v ? fmt(v) : '—'), textAnchor: 'start', offsetX: 6, style: { fontSize: '11px', fontWeight: 500, colors: [cssVar('--text')] }, dropShadow: { enabled: false } },
                    xaxis: { categories: ok.map(p => p.name), labels: { show: false }, axisBorder: { show: false }, axisTicks: { show: false } },
                    yaxis: { labels: { style: { fontSize: '11.5px' } } },
                    grid: { show: false, padding: { left: 0, right: 56, top: -10, bottom: -6 } },
                    tooltip: { theme: getTheme(), y: { formatter: (v) => fmt(v), title: { formatter: () => '' } } },
                    stroke: { show: true, width: 2, colors: [cssVar('--surface')] },
                });
                if (!ok.length) { document.getElementById(id).innerHTML = '<div class="card-sub" style="padding:24px 0">No data</div>'; return; }
                draw(id, o);
            };
            mk('ch-spend', d => d.spend, inr);
            mk('ch-leads', d => d.leads, num);
            mk('ch-cpl', d => (d.leads ? d.spend / d.leads : 0), inrFull);
        }

        function renderFunnel() {
            const ok = okPlatforms(); const t = totals();
            const stages = [
                { k: 'leads', label: 'Leads', conv: '' },
                { k: 'qualified', label: 'Qualified', conv: t.leads ? pct(ratio(t.qualified, t.leads)) + ' of leads' : '' },
                { k: 'walkins', label: 'Site visits', conv: t.qualified ? pct(ratio(t.walkins, t.qualified)) + ' of qualified' : '' },
            ];
            const max = Math.max(t.leads, 1);
            const hq = window.pqMetricHidden && pqMetricHidden('Qualified leads');
            $('#funnel').innerHTML = stages.filter(s => !(window.pqMetricHidden && pqMetricHidden(s.label))).map(s => {
                if (hq && /of qualified$/.test(s.conv)) s.conv = '';
                const segs = ok.filter(p => OV.data[p.key][s.k] > 0).map(p =>
                    `<i style="width:${(OV.data[p.key][s.k] / max * 100).toFixed(2)}%;background:var(--${p.key})" title="${p.name}: ${num(OV.data[p.key][s.k])}"></i>`).join('');
                return `<div class="f-row">
                    <div class="lbl">${s.label}</div>
                    <div class="f-track">${segs}</div>
                    <div class="f-val"><b class="mono">${num(t[s.k])}</b><small>${s.conv || '&nbsp;'}</small></div>
                </div>`;
            }).join('');
        }

        function renderTrend() {
            const metric = OV.metric;
            const withTrend = okPlatforms().filter(p => OV.data[p.key].trend.length);
            const missing = okPlatforms().filter(p => !OV.data[p.key].trend.length).map(p => p.name);
            $('#trend-sub').textContent = 'Per platform, per day' + (missing.length ? ` · ${missing.join(' & ')} ${missing.length > 1 ? "don't" : "doesn't"} report daily data` : '');
            const el = document.getElementById('ch-trend');
            if (!withTrend.length) {
                if (OV.charts['ch-trend']) { OV.charts['ch-trend'].destroy(); delete OV.charts['ch-trend']; }
                el.innerHTML = `<div class="card-sub" style="padding:40px 0;text-align:center">${OV.loading ? 'Loading…' : 'No daily data for this period'}</div>`;
                return;
            }
            const dates = [...new Set(withTrend.flatMap(p => OV.data[p.key].trend.map(t => t.date)))].sort();
            const series = withTrend.map(p => {
                const m = {}; OV.data[p.key].trend.forEach(t => { m[t.date] = (m[t.date] || 0) + t[metric]; });
                return { name: p.name, data: dates.map(d => [new Date(d + 'T00:00:00').getTime(), m[d] || 0]) };
            });
            const fmt = metric === 'spend' ? inrFull : num;
            const o = baseChart('line', 280);
            Object.assign(o, {
                series,
                colors: withTrend.map(p => colorOf(p.key)),
                stroke: { width: 2, curve: 'straight' },
                markers: { size: 0, hover: { size: 5 }, strokeColors: cssVar('--surface'), strokeWidth: 2 },
                dataLabels: { enabled: false },
                legend: { show: true, position: 'top', horizontalAlign: 'left', fontSize: '12px', markers: { width: 10, height: 10, radius: 3 }, labels: { colors: cssVar('--text-dim') } },
                xaxis: { type: 'datetime', labels: { datetimeUTC: false, style: { fontSize: '11px' } }, axisBorder: { show: false }, axisTicks: { show: false }, crosshairs: { show: true, stroke: { color: cssVar('--border-strong'), width: 1, dashArray: 0 } }, tooltip: { enabled: false } },
                yaxis: { min: 0, forceNiceScale: true, labels: { formatter: (v) => (metric === 'spend' ? inr(v) : num(v)), style: { fontSize: '11px' } } },
                tooltip: { theme: getTheme(), shared: true, intersect: false, x: { format: 'dd MMM yyyy' }, y: { formatter: (v) => fmt(v) } },
            });
            el.innerHTML = '';
            draw('ch-trend', o);
        }

        function renderTable() {
            const t = totals();
            const cell = (v, f) => (v ? f(v) : '—');
            $('#tbl-body').innerHTML = PLATFORMS.map(p => {
                const d = OV.data[p.key] || {};
                const name = `<span class="pf"><i style="background:var(--${p.key})"></i>${p.name}</span>`;
                if (d.state === 'empty') return '';
                if (d.state !== 'ok') {
                    const st = d.state === 'error' ? `<span class="state err" title="${esc(d.error)}">Failed to load</span>` : '<span class="state">Loading…</span>';
                    return `<tr data-view="${p.key}"><td>${name}</td><td colspan="11" style="text-align:left">${st}</td><td class="open">Open →</td></tr>`;
                }
                return `<tr data-view="${p.key}">
                    <td>${name}</td>
                    <td class="mono">${inrFull(d.spend)}</td>
                    <td class="mono">${t.spend ? pct(d.spend / t.spend) : '—'}</td>
                    <td class="mono">${cell(d.impressions, num)}</td>
                    <td class="mono">${cell(d.clicks, num)}</td>
                    <td class="mono">${d.impressions ? (d.clicks / d.impressions * 100).toFixed(2) + '%' : '—'}</td>
                    <td class="mono">${num(d.leads)}</td>
                    <td class="mono">${d.leads ? inrFull(d.spend / d.leads) : '—'}</td>
                    <td class="mono">${num(d.qualified)}</td>
                    <td class="mono">${d.qualified ? inrFull(d.spend / d.qualified) : '—'}</td>
                    <td class="mono">${num(d.walkins)}</td>
                    <td class="mono">${d.walkins ? inrFull(d.spend / d.walkins) : '—'}</td>
                    <td class="open">Open →</td>
                </tr>`;
            }).join('');
            $('#tbl-foot').innerHTML = okPlatforms().length ? `<tr>
                <td>Total</td>
                <td class="mono">${inrFull(t.spend)}</td><td class="mono">100%</td>
                <td class="mono">${cell(t.impressions, num)}</td><td class="mono">${cell(t.clicks, num)}</td>
                <td class="mono">${t.impressions ? (t.clicks / t.impressions * 100).toFixed(2) + '%' : '—'}</td>
                <td class="mono">${num(t.leads)}</td><td class="mono">${t.leads ? inrFull(t.spend / t.leads) : '—'}</td>
                <td class="mono">${num(t.qualified)}</td><td class="mono">${t.qualified ? inrFull(t.spend / t.qualified) : '—'}</td>
                <td class="mono">${num(t.walkins)}</td><td class="mono">${t.walkins ? inrFull(t.spend / t.walkins) : '—'}</td>
                <td></td></tr>` : '';
        }

        function renderOverview() {
            if (current !== 'overview' || !OV.loaded) return;
            renderNotice(); renderKpis(); renderMultiples(); renderFunnel(); renderTrend(); renderTable();
            // manual platforms (OTT Video, Display, …) show up only for periods that have their numbers
            const manualOn = PLATFORMS.filter(p => p.manual && OV.data[p.key] && OV.data[p.key].state === 'ok');
            PLATFORMS.filter(p => p.manual).forEach(p => { const lg = document.getElementById('legend-' + p.key); if (lg) lg.hidden = !manualOn.includes(p); });
            const names = ['Meta', 'Google'].concat(SHOW_TABOOLA ? ['Taboola'] : []).concat(manualOn.map(p => p.name));
            $('#page-sub').textContent = names.slice(0, -1).join(', ') + ' & ' + names[names.length - 1] + ' combined';
        }

        // ───────────────── Boot ─────────────────
        // last date choice (presets and custom dates) is remembered in this browser
        try {
            const sv = JSON.parse(localStorage.getItem('pq-range') || 'null');
            if (sv && ['today', 'yesterday', 'last_7d', 'last_30d', 'this_month', 'last_month', 'last_1y', 'all_time', 'custom'].includes(sv.p)) {
                OV.range = sv.p;
                if (sv.p === 'custom') { $('#d-since').value = sv.s || ''; $('#d-until').value = sv.u || ''; $('#date-custom').classList.add('show'); }
                $$('#range-seg button').forEach(x => x.classList.toggle('on', x.dataset.range === OV.range));
            }
        } catch (e) {}
        if (!gRange()) { OV.range = 'last_30d'; $$('#range-seg button').forEach(x => x.classList.toggle('on', x.dataset.range === 'last_30d')); $('#date-custom').classList.remove('show'); }
        { const r = gRange(); if (r) $('#range-label').textContent = fmtRange(r.s, r.u); }
        show((location.hash || '#' + (FIRST_VIEW || 'overview')).slice(1));

        // Unmapped Leads badge in the sidebar (Meta + Google, all time)
        async function loadUnmappedBadge() {
            try {
                const res = await fetch('unmapped_leads_api.php?action=counts', { credentials: 'same-origin' });
                const d = await res.json();
                const b = document.getElementById('nav-unmapped-badge');
                if (b && d.success) { b.textContent = d.counts.all > 999 ? '999+' : d.counts.all; b.hidden = !d.counts.all; }
            } catch (e) { /* badge is optional */ }
        }
        if (ALLOWED.includes('unmapped')) loadUnmappedBadge();

        // CRM Push badge: leads that failed or were never sent to the CRM (all time, test leads not counted)
        async function loadCrmBadge() {
            try {
                const res = await fetch('crm_push_api.php?action=counts', { credentials: 'same-origin' });
                const d = await res.json();
                const b = document.getElementById('nav-crm-badge');
                if (b && d.success) { b.textContent = d.problem > 999 ? '999+' : d.problem; b.hidden = !d.problem; }
            } catch (e) { /* badge is optional */ }
        }
        if (ALLOWED.includes('crm')) loadCrmBadge();

        // ── Reports menu (Overview): Campaign report (date filter) + Daily / Weekly / Monthly (same as the emails) ──
        (function reportsMenu() {
            const btn = $('#pdf-btn'), menu = $('#rep-menu');
            const label = btn.innerHTML;
            const d0 = () => { const n = new Date(); return new Date(n.getFullYear(), n.getMonth(), n.getDate()); };
            const add = (d, n) => { const x = new Date(d); x.setDate(x.getDate() + n); return x; };
            const f = (d, o) => d.toLocaleDateString('en-GB', o || { day: 'numeric', month: 'short', year: 'numeric' });
            function periodLabels() {
                const t = d0(), y = add(t, -1);
                const dow = (t.getDay() + 6) % 7;                    // 0 = Monday
                const wEnd = add(t, -dow - 1), wStart = add(wEnd, -6);
                const mStart = new Date(t.getFullYear(), t.getMonth() - 1, 1);
                $('#rep-sub-daily').textContent = 'Yesterday · ' + f(y);
                $('#rep-sub-weekly').textContent = 'Last full week · ' + f(wStart, { day: 'numeric', month: 'short' }) + ' – ' + f(wEnd);
                $('#rep-sub-monthly').textContent = 'Last full month · ' + f(mStart, { month: 'long', year: 'numeric' });
                $('#rep-sub-portfolio').textContent = (OV.since && OV.until ? fmtRange(OV.since, OV.until) : 'The date filter above') + ' · ' + $('#pdf-detail').selectedOptions[0].textContent.replace(/^\+\s*/, '+ ').trim();
            }
            const open = v => { menu.hidden = !v; btn.setAttribute('aria-expanded', v ? 'true' : 'false'); if (v) periodLabels(); };
            btn.addEventListener('click', e => { e.stopPropagation(); if (!btn.disabled) open(menu.hidden); });
            document.addEventListener('click', e => { if (!menu.hidden && !menu.contains(e.target)) open(false); });
            document.addEventListener('keydown', e => { if (e.key === 'Escape') open(false); });

            menu.addEventListener('click', async e => {
                const item = e.target.closest('[data-rep]');
                if (!item) return;
                open(false);
                const kind = item.dataset.rep;
                btn.disabled = true;
                const status = t => { btn.innerHTML = '⏳ ' + t; };
                try {
                    if (kind === 'portfolio') {
                        if (!OV.since || !OV.until) { await loadOverview(); }
                        await PortfolioPDF.export({ since: OV.since, until: OV.until, detail: $('#pdf-detail').value,
                            api: 'ads/portfolio_report_api.php', logo: 'ads/images/webzaa-logo.png', onStatus: status });
                    } else {
                        const r = await EmailReportPDF.export({ period: kind, base: 'ads/', onStatus: status });
                        if (r && r.errors && r.errors.length) alert('Report downloaded without: ' + r.errors.join(' · '));
                    }
                } catch (err) {
                    alert('Report: ' + err.message);
                } finally {
                    btn.disabled = false; btn.innerHTML = label;
                }
            });
        })();
        window.addEventListener('message', e => { if (e.data && e.data.type === 'pq-open' && VIEWS[e.data.view]) show(e.data.view); });
        window.addEventListener('message', e => { if (e.data && e.data.type === 'pq-unmapped-changed') loadUnmappedBadge(); if (e.data && e.data.type === 'pq-crm-changed') loadCrmBadge(); if (e.data && e.data.type === 'pq-ott-changed') OV.loaded = false;
            if (e.data && e.data.type === 'pq-platforms-changed') { location.hash = e.data.key ? 'm-' + e.data.key : 'overview'; location.reload(); } });
    })();
    </script>
    <script src="ads/js/portfolio_pdf.js?v=5"></script>
    <script src="ads/js/email_report_pdf.js?v=4"></script>
</body>

</html>
