#!/usr/bin/env bash
# ---------------------------------------------------------------------------
# tools/check_server.sh — health check for the PerformIQ admin on a Linux server (AWS EC2 etc.)
#
#   cd /var/www/embassylaunch-northyelahanka/admin
#   sudo bash tools/check_server.sh            # check only — changes nothing
#   sudo bash tools/check_server.sh --fix      # also fixes folder owner / permissions for storage/
#
# Checks: PHP + extensions, PHP limits, the user PHP runs as, storage/ permissions (as that user),
# config, every lead database, campaign tables, Meta / Google / Taboola APIs, recent PHP errors.
# Secrets are never printed.
# ---------------------------------------------------------------------------
set -u
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
FIX=0; [ "${1:-}" = "--fix" ] && FIX=1

if [ -t 1 ]; then G=$'\e[32m'; R=$'\e[31m'; Y=$'\e[33m'; B=$'\e[1m'; N=$'\e[0m'; else G=; R=; Y=; B=; N=; fi
PASS=0; FAILS=0; WARNS=0
ok()   { echo "  ${G}✓${N} $*"; PASS=$((PASS+1)); }
bad()  { echo "  ${R}✕${N} $*"; FAILS=$((FAILS+1)); }
warn() { echo "  ${Y}!${N} $*"; WARNS=$((WARNS+1)); }
fix()  { echo "      ${B}fix:${N} $*"; }
section() { echo; echo "${B}$*${N}"; }
# run a command as the web user (sudo, or su when sudo is missing)
as_web() { if command -v sudo >/dev/null 2>&1; then sudo -n -u "$WEBUSER" "$@"; else su -s /bin/sh "$WEBUSER" -c "$(printf '%q ' "$@")"; fi; }

echo "${B}PerformIQ admin — server check${N}   ($ROOT, $(date '+%d %b %Y %H:%M'))"

# ── 1. PHP ────────────────────────────────────────────────────────────────
section "1. PHP"
if ! command -v php >/dev/null 2>&1; then
  bad "php command not found"; fix "sudo apt install php-cli php-mysql php-curl php-xml php-mbstring php-zip"; exit 1
fi
PHPV=$(php -r 'echo PHP_VERSION;')
php -r 'exit(version_compare(PHP_VERSION,"8.1",">=")?0:1);' && ok "PHP $PHPV" || bad "PHP $PHPV — 8.1 or newer is needed"
PHPMM=$(php -r 'echo PHP_MAJOR_VERSION.".".PHP_MINOR_VERSION;')
for ext in mysqli curl json mbstring xml xmlreader simplexml zip openssl; do
  if php -m 2>/dev/null | grep -qi "^$ext\$"; then ok "extension $ext"
  else
    if [ "$ext" = "zip" ]; then warn "extension zip missing — .xlsx uploads are converted in the browser instead"
    else bad "extension $ext missing"; fi
    fix "sudo apt install php${PHPMM}-${ext/simplexml/xml} && sudo systemctl restart php${PHPMM}-fpm apache2 2>/dev/null"
  fi
done

# ── 2. Which user PHP runs as on the web ──────────────────────────────────
section "2. Web server"
WEBUSER=""
for p in php-fpm php-fpm${PHPMM} php${PHPMM}-fpm; do
  u=$(ps -eo user=,comm= 2>/dev/null | awk -v p="$p" '$2 ~ p && $1 != "root" {print $1; exit}')
  [ -n "$u" ] && WEBUSER=$u && SRV="php-fpm" && break
done
if [ -z "$WEBUSER" ]; then
  for p in apache2 httpd nginx lsphp; do
    u=$(ps -eo user=,comm= 2>/dev/null | awk -v p="$p" '$2 == p && $1 != "root" {print $1; exit}')
    [ -n "$u" ] && WEBUSER=$u && SRV=$p && break
  done
fi
if [ -n "$WEBUSER" ]; then ok "PHP on the web runs as '${WEBUSER}' ($SRV)"
else warn "could not tell which user runs PHP on the web — assuming www-data"; WEBUSER=www-data; fi
for s in apache2 httpd nginx; do
  if systemctl is-active --quiet "$s" 2>/dev/null; then ok "$s is running"; WEB=$s; fi
done
if [ "${WEB:-}" = "apache2" ] || [ "${WEB:-}" = "httpd" ]; then
  if apachectl -M 2>/dev/null | grep -q rewrite_module; then ok "Apache mod_rewrite on (needed for the .htaccess redirects)"
  else bad "Apache mod_rewrite off"; fix "sudo a2enmod rewrite && sudo systemctl restart apache2"; fi
  grep -rqs "AllowOverride All" /etc/apache2/ /etc/httpd/ 2>/dev/null && ok "AllowOverride All found in the Apache config" \
    || warn "no 'AllowOverride All' in the Apache config — .htaccess files may be ignored"
fi
[ "${WEB:-}" = "nginx" ] && warn "nginx ignores .htaccess — make sure the site config sends /admin/* to public/ and denies config/, app/, storage/"

# PHP limits as the web sees them (FPM / Apache ini, not the CLI one)
WEBINI=$(ls /etc/php/${PHPMM}/fpm/php.ini /etc/php/${PHPMM}/apache2/php.ini 2>/dev/null | head -1)
if [ -n "$WEBINI" ]; then
  for k in upload_max_filesize post_max_size memory_limit max_execution_time; do
    v=$(grep -E "^\s*$k\s*=" "$WEBINI" | tail -1 | cut -d= -f2 | tr -d ' ')
    echo "      $k = ${v:-default}   ($WEBINI)"
  done
  up=$(grep -E "^\s*upload_max_filesize\s*=" "$WEBINI" | tail -1 | cut -d= -f2 | tr -d ' ')
  case "$up" in 2M|1M|"") warn "upload_max_filesize is ${up:-2M} — big CRM exports may be refused"
                          fix "set upload_max_filesize = 20M and post_max_size = 25M in $WEBINI, then: sudo systemctl restart php${PHPMM}-fpm apache2 2>/dev/null";;
  esac
fi

# ── 3. Files and folders ──────────────────────────────────────────────────
section "3. Files and folders"
[ -f "$ROOT/config/config.php" ] && ok "config/config.php present" || { bad "config/config.php missing"; fix "copy config/config.example.php to config/config.php and fill it in"; }
[ -f "$ROOT/public/status_upload.php" ] && ok "latest files uploaded (status_upload.php present)" || warn "public/status_upload.php missing — the latest zip isn't fully uploaded"
[ -f "$ROOT/.htaccess" ] && ok ".htaccess present (sends /admin/* to public/)" || warn ".htaccess missing in $ROOT"

for d in storage storage/cache storage/logs storage/meta_capi; do
  [ -d "$ROOT/$d" ] || { mkdir -p "$ROOT/$d" 2>/dev/null && echo "      created $d"; }
  owner=$(stat -c '%U:%G %a' "$ROOT/$d" 2>/dev/null)
  if as_web test -w "$ROOT/$d" 2>/dev/null; then
    ok "$d writable by $WEBUSER ($owner)"
  elif [ "$(id -u)" != "0" ]; then
    warn "$d — can't test as $WEBUSER without sudo ($owner)"
  else
    bad "$d NOT writable by $WEBUSER ($owner)"
    if [ $FIX = 1 ]; then
      chown -R "$WEBUSER":"$WEBUSER" "$ROOT/$d" && chmod -R u+rwX,g+rwX "$ROOT/$d"
      if as_web test -w "$ROOT/$d" 2>/dev/null; then
        FAILS=$((FAILS-1)); echo "      ${G}fixed${N}: chown -R $WEBUSER:$WEBUSER $d && chmod -R 775 $d"
      else
        echo "      changed owner/permissions, but $WEBUSER still can't write — a parent folder blocks it"
        fix "ls -ld $ROOT $(dirname "$ROOT")   (each needs at least r-x for $WEBUSER)"
      fi
    else
      [ "${STORAGE_FIX_SHOWN:-0}" = 1 ] || fix "sudo chown -R $WEBUSER:$WEBUSER $ROOT/storage && sudo chmod -R 775 $ROOT/storage   (or run this script with --fix)"
      STORAGE_FIX_SHOWN=1
    fi
  fi
done
if [ -d "$ROOT/storage/cache" ]; then
  n=$(find "$ROOT/storage/cache" -maxdepth 1 -name '*.json' 2>/dev/null | wc -l)
  echo "      storage/cache holds $n dashboard cache file(s)"
fi
as_web test -r "$ROOT/config/config.php" 2>/dev/null && ok "config.php readable by $WEBUSER" \
  || { [ "$(id -u)" = "0" ] && bad "config.php not readable by $WEBUSER" && fix "sudo chgrp $WEBUSER $ROOT/config/config.php && sudo chmod 640 $ROOT/config/config.php"; }
perm=$(stat -c '%a' "$ROOT/config/config.php" 2>/dev/null)
case "$perm" in *[2367]) warn "config.php is writable by everyone (mode $perm) — it holds passwords"; fix "sudo chmod 640 $ROOT/config/config.php";; esac

# ── 4–6. Database + ad platform APIs (run through PHP with the real config) ──
section "4. Databases and campaign tables"
TMPPHP=$(mktemp /tmp/pq_check_XXXX.php)
cat > "$TMPPHP" <<'PHP'
<?php
error_reporting(E_ALL & ~E_DEPRECATED & ~E_NOTICE);
$root = $argv[1];
$G = "\e[32m"; $R = "\e[31m"; $Y = "\e[33m"; $N = "\e[0m";
if (!(function_exists('stream_isatty') && stream_isatty(STDOUT))) { $G = $R = $Y = $N = ''; }
$ok = fn($m) => print("  {$G}✓{$N} $m\n");
$bad = fn($m) => print("  {$R}✕{$N} $m\n");
$warn = fn($m) => print("  {$Y}!{$N} $m\n");
$fails = 0;
try {
    require $root . '/app/Core/db.php';
} catch (Throwable $e) {
    $bad('config / db.php failed to load: ' . $e->getMessage()); exit(1);
}
$ok('config loaded · project: ' . (defined('PROJECT_NAME') ? PROJECT_NAME : '?') . ' · APP_URL: ' . (defined('APP_URL') ? APP_URL : '?'));

foreach (leadDbKeys() as $k) {
    $db = null;
    try { $db = leadDb($k); } catch (Throwable $e) {}
    if (!$db) { $bad("database '$k' (" . leadDbLabel($k) . ') — cannot connect'); $fails++; continue; }
    $r = @$db->query('SELECT COUNT(*) n, MAX(createddate) last FROM `lead`');
    if (!$r) { $bad("database '$k' connected, but no `lead` table: " . $db->error); $fails++; continue; }
    $row = $r->fetch_assoc();
    $ok("database '$k' (" . leadDbLabel($k) . "): " . number_format((int) $row['n']) . ' leads, newest ' . ($row['last'] ?: '—'));
    $miss = [];
    foreach (['mobile', 'uniqueid', 'lead_status', 'sitevisit_status', 'campaignsource', 'campaign_name', 'adset_name', 'ad_name', 'ad_id', 'leadgen_id', 'utm_campaignid', 'utm_campaignname'] as $c) {
        if (!@$db->query("SELECT `$c` FROM `lead` LIMIT 0")) $miss[] = $c;
    }
    $miss ? $warn('  lead table is missing column(s): ' . implode(', ', $miss)) : $ok('  lead table has every column the dashboards use');
    // can the history tables for "Upload Lead Status" be created?
    $t = @$db->query("SHOW TABLES LIKE 'lead_status_uploads'");
    if ($t && $t->num_rows) $ok('  Upload Lead Status history table exists');
    else {
        $can = @$db->query('CREATE TABLE IF NOT EXISTS `pq_check_tmp` (id INT) ENGINE=InnoDB');
        if ($can) { @$db->query('DROP TABLE `pq_check_tmp`'); $ok('  DB user can create tables (Upload Lead Status history will be created on first use)'); }
        else { $bad('  DB user cannot CREATE tables: ' . $db->error); $fails++; }
    }
}

// campaign tables (only data saved here is shown on the Meta / Google dashboards)
if (is_file($root . '/app/Ads/master_tables.php')) {
    require_once $root . '/app/Ads/master_tables.php';
    $m = masterDb();
    if ($m && masterTableExists($m, 'campaigns')) {
        foreach (['meta', 'google'] as $p) {
            $s = projectStructure($p);
            $s['count'] ? $ok(ucfirst($p) . ": {$s['count']} campaign(s), " . count($s['adgroups']) . ' ad set(s)/group(s), ' . count($s['ads']) . ' ad(s) linked')
                        : $warn(ucfirst($p) . ': no campaigns linked yet — open the ' . ucfirst($p) . ' dashboard → ⟳ Sync with ' . ucfirst($p));
        }
    } else {
        $warn('campaigns table not created yet — it is created by the first "⟳ Sync with Meta / Google"');
    }
}

function pqGet(string $url, array $headers = [], ?string $post = null): array {
    $ch = curl_init($url);
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 20, CURLOPT_CONNECTTIMEOUT => 8, CURLOPT_HTTPHEADER => $headers]);
    if ($post !== null) { curl_setopt($ch, CURLOPT_POST, true); curl_setopt($ch, CURLOPT_POSTFIELDS, $post); }
    $body = curl_exec($ch); $err = curl_error($ch); $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
    return [$code, $body === false ? null : json_decode((string) $body, true), $err];
}

echo "\n" . ($N === '' ? '' : "\e[1m") . "5. Ad platforms" . ($N === '' ? '' : "\e[0m") . "\n";
// Meta
if (defined('META_ACCESS_TOKEN') && META_ACCESS_TOKEN !== '') {
    $v = defined('META_API_VERSION') ? META_API_VERSION : 'v23.0';
    [$c, $j, $e] = pqGet("https://graph.facebook.com/$v/debug_token?" . http_build_query(['input_token' => META_ACCESS_TOKEN, 'access_token' => META_ACCESS_TOKEN]));
    if ($e) { $bad("Meta: cannot reach graph.facebook.com ($e) — check the server's outbound internet / security group"); $fails++; }
    elseif (!empty($j['data']['is_valid'])) {
        $exp = (int) ($j['data']['expires_at'] ?? 0);
        $ok('Meta token valid' . ($exp ? ', expires ' . date('d M Y', $exp) . (($exp - time()) < 7 * 86400 ? ' — SOON' : '') : ', never expires'));
    } else { $bad('Meta token not valid: ' . ($j['data']['error']['message'] ?? $j['error']['message'] ?? "HTTP $c")); $fails++; }
    $ids = defined('META_AD_ACCOUNT_IDS') ? (array) META_AD_ACCOUNT_IDS : [];
    foreach ($ids as $acc) {
        [$c, $j, $e] = pqGet("https://graph.facebook.com/$v/act_$acc?" . http_build_query(['fields' => 'name,account_status', 'access_token' => META_ACCESS_TOKEN]));
        if (!empty($j['name'])) $ok("Meta ad account $acc: " . $j['name'] . ((int) ($j['account_status'] ?? 1) === 1 ? '' : ' (status ' . $j['account_status'] . ')'));
        else { $bad("Meta ad account $acc: " . ($j['error']['message'] ?? $e ?: "HTTP $c")); $fails++; }
    }
} else $warn('Meta: META_ACCESS_TOKEN not set');

// Google
if (defined('GOOGLE_REFRESH_TOKEN') && GOOGLE_REFRESH_TOKEN !== '') {
    [$c, $j, $e] = pqGet('https://oauth2.googleapis.com/token', ['Content-Type: application/x-www-form-urlencoded'],
        http_build_query(['client_id' => GOOGLE_CLIENT_ID, 'client_secret' => GOOGLE_CLIENT_SECRET, 'refresh_token' => GOOGLE_REFRESH_TOKEN, 'grant_type' => 'refresh_token']));
    if ($e) { $bad("Google: cannot reach oauth2.googleapis.com ($e)"); $fails++; }
    elseif (!empty($j['access_token'])) {
        $ok('Google OAuth token OK');
        $cid = preg_replace('/\D/', '', (string) GOOGLE_CUSTOMER_ID);
        $h = ['Authorization: Bearer ' . $j['access_token'], 'developer-token: ' . GOOGLE_DEVELOPER_TOKEN, 'Content-Type: application/json'];
        if (defined('GOOGLE_LOGIN_CUSTOMER_ID') && GOOGLE_LOGIN_CUSTOMER_ID !== '') $h[] = 'login-customer-id: ' . preg_replace('/\D/', '', (string) GOOGLE_LOGIN_CUSTOMER_ID);
        [$c2, $j2, $e2] = pqGet("https://googleads.googleapis.com/v24/customers/$cid/googleAds:search", $h, json_encode(['query' => 'SELECT customer.descriptive_name FROM customer LIMIT 1']));
        if (!empty($j2['results'][0]['customer']['descriptiveName'])) $ok("Google Ads account $cid: " . $j2['results'][0]['customer']['descriptiveName']);
        else { $bad("Google Ads account $cid: " . ($j2['error']['message'] ?? $j2[0]['error']['message'] ?? $e2 ?: "HTTP $c2")); $fails++; }
    } else { $bad('Google OAuth failed: ' . ($j['error_description'] ?? $j['error'] ?? "HTTP $c")); $fails++; }
} else $warn('Google: GOOGLE_REFRESH_TOKEN not set');

// Taboola
if (defined('TABOOLA_CLIENT_ID') && TABOOLA_CLIENT_ID !== '') {
    [$c, $j, $e] = pqGet(rtrim(TABOOLA_BASE_URL, '/') . '/oauth/token', ['Content-Type: application/x-www-form-urlencoded'],
        http_build_query(['client_id' => TABOOLA_CLIENT_ID, 'client_secret' => TABOOLA_CLIENT_SECRET, 'grant_type' => 'client_credentials']));
    !empty($j['access_token']) ? $ok('Taboola login OK · account ' . TABOOLA_ACCOUNT_ID) : $warn('Taboola login failed: ' . ($j['error_description'] ?? $e ?: "HTTP $c"));
}
exit($fails ? 2 : 0);
PHP
if [ "$(id -u)" = "0" ] && id "$WEBUSER" >/dev/null 2>&1; then
  chmod 644 "$TMPPHP"; as_web php "$TMPPHP" "$ROOT"; rc=$?    # same user as the website
  if [ $rc = 1 ]; then
    echo "  ${Y}!${N} the code can't be read as $WEBUSER (see above) — checking as $(whoami) instead"
    FAILS=$((FAILS+1)); php "$TMPPHP" "$ROOT"; rc=$?
  fi
else
  php "$TMPPHP" "$ROOT"; rc=$?
fi
rm -f "$TMPPHP"
[ $rc = 2 ] && FAILS=$((FAILS+1))
[ $rc = 1 ] && FAILS=$((FAILS+1))
true

# ── 6. Website answers ────────────────────────────────────────────────────
section "6. Website"
URL=$(php -r 'error_reporting(0); require $argv[1]."/app/bootstrap.php"; echo defined("APP_URL") ? APP_URL : "";' "$ROOT" 2>/dev/null)
if [ -n "$URL" ] && command -v curl >/dev/null; then
  for path in login.php dashboard.php status_upload_api.php?action=check config/config.php storage/logs/; do
    code=$(curl -s -o /dev/null -w '%{http_code}' --max-time 15 "$URL/$path")
    if [ "$code" = "000" ]; then warn "$URL/$path — no answer from the server (DNS, firewall or web server down?)"; continue; fi
    case "$path" in
      config/*|storage/*) [ "$code" = "403" ] || [ "$code" = "404" ] && ok "$path is blocked ($code)" || { bad "$path answers $code — secrets may be public"; fix "check .htaccess / web server config denies config/ and storage/"; };;
      status_upload_api*) [ "$code" = "401" ] && ok "$path asks for login (401)" || warn "$path answered $code (expected 401 when not logged in)";;
      *) [ "$code" = "200" ] || [ "$code" = "302" ] && ok "$path → $code" || bad "$path → $code";;
    esac
  done
else
  warn "APP_URL not set or curl missing — skipped"
fi

# ── 7. Recent PHP errors ──────────────────────────────────────────────────
section "7. Recent PHP errors (last 24 h)"
found=0
for log in /var/log/apache2/error.log /var/log/httpd/error_log /var/log/nginx/error.log /var/log/php${PHPMM}-fpm.log "$ROOT/storage/logs/"*.log; do
  [ -r "$log" ] || continue
  lines=$(find "$log" -mmin -1440 2>/dev/null | xargs -r grep -hiE "PHP (Fatal|Parse|Warning)|Uncaught|status_upload|project_sync" 2>/dev/null | tail -8)
  if [ -n "$lines" ]; then found=1; echo "  ${Y}$log${N}"; echo "$lines" | sed -E 's/(access_token=)[^& ]+/\1***/g; s/^/      /' | cut -c1-260; fi
done
[ $found = 0 ] && ok "no recent PHP errors found"

# ── summary ───────────────────────────────────────────────────────────────
echo
if [ $FAILS = 0 ]; then echo "${G}${B}All good${N} — $PASS checks passed, $WARNS note(s)."
else echo "${R}${B}$FAILS problem(s)${N}, $WARNS note(s), $PASS passed. Follow the 'fix:' lines above, then run this again."; fi
[ $FIX = 0 ] && [ $FAILS -gt 0 ] && echo "Tip: 'sudo bash tools/check_server.sh --fix' fixes the storage/ permissions automatically."
exit 0
