<?php
require_once dirname(__DIR__) . '/app/Core/db.php';

$sql = "CREATE TABLE IF NOT EXISTS `campaigns_master` (
  `id`            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `campaign_id`   VARCHAR(64)  NOT NULL,
  `campaign_name` VARCHAR(255) NOT NULL,
  `created_at`    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY `uq_campaign_id` (`campaign_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;";

if ($conn->query($sql) === TRUE) {
    echo "<b style='color:green'>✅ Table `campaigns_master` created successfully (or already exists).</b><br>";
} else {
    echo "<b style='color:red'>❌ Error creating table: " . $conn->error . "</b><br>";
}

// Verify
$check = $conn->query("DESCRIBE `campaigns_master`");
if ($check && $check->num_rows > 0) {
    echo "<br><b>Table structure:</b><br><table border='1' cellpadding='4'><tr><th>Field</th><th>Type</th><th>Null</th><th>Key</th><th>Default</th><th>Extra</th></tr>";
    while ($row = $check->fetch_assoc()) {
        echo "<tr><td>{$row['Field']}</td><td>{$row['Type']}</td><td>{$row['Null']}</td><td>{$row['Key']}</td><td>{$row['Default']}</td><td>{$row['Extra']}</td></tr>";
    }
    echo "</table>";
}

$conn->close();
?>
