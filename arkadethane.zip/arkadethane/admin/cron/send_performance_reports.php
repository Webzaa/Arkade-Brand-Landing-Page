<?php

declare(strict_types=1);

/**
 * send_performance_reports.php — run by cron once a day at 10:00 AM IST.
 *
 *   Every day   : Daily report (yesterday vs day before) in the email body.
 *   Monday      : Weekly report (last full Mon–Sun week vs the week before) in the email body.
 *   1st of month: Monthly report (last full month vs the month before) in the email body.
 *   Weekly and monthly also show qualified leads, CPQL, site visits and CPSV.
 *
 * Sends Meta reports to REPORT_RECIPIENTS['meta'] and Google reports to REPORT_RECIPIENTS['google'].
 * Anyone in REPORT_COMBINED_RECIPIENTS gets ONE email per report with Meta + Google together.
 *
 * Usage:
 *   php send_performance_reports.php                   normal run (what cron calls)
 *   php send_performance_reports.php --dry-run         build everything, save emails to storage/cache/, send nothing
 *   php send_performance_reports.php --date=2026-11-02 pretend today is that date
 *   php send_performance_reports.php --only=weekly     only one report type (daily|weekly|monthly)
 *   php send_performance_reports.php --platform=meta   only one platform (meta|google)
 *   php send_performance_reports.php --to=me@x.com     send to this address instead of the executives
 *   php send_performance_reports.php --combined        only the combined Meta + Google email (use with --to to test)
 *   php send_performance_reports.php --force           send even if already sent today
 */

if (PHP_SAPI !== 'cli') {
    http_response_code(403);
    exit('Forbidden');
}

date_default_timezone_set('Asia/Kolkata');

require_once dirname(__DIR__) . '/app/Core/db.php';
require_once dirname(__DIR__) . '/app/Reports/report_access.php';
require_once dirname(__DIR__) . '/app/Reports/report_mailer.php';

require_once dirname(__DIR__) . '/app/Reports/email_builder.php';   // helpers + email builders (shared with the Reports PDF)

/* ======================================================================
 * Options
 * ====================================================================== */
$opts = getopt('', ['dry-run', 'date:', 'only:', 'platform:', 'to:', 'force', 'combined']);
$combinedOnly = isset($opts['combined']);
$dryRun = isset($opts['dry-run']);
$force = isset($opts['force']);
$tz = new DateTimeZone('Asia/Kolkata');

$today = new DateTimeImmutable('today', $tz);
if (!empty($opts['date'])) {
    $d = DateTimeImmutable::createFromFormat('!Y-m-d', (string) $opts['date'], $tz);
    if (!$d) {
        srLog('Invalid --date, use YYYY-MM-DD.');
        exit(1);
    }
    $today = $d;
}
$asOf = $today->format('Y-m-d');

$periods = ['daily'];
if ($today->format('N') === '1') {
    $periods[] = 'weekly';
}
if ($today->format('j') === '1') {
    $periods[] = 'monthly';
}
if (!empty($opts['only'])) {
    $periods = array_values(array_intersect($periods, [(string) $opts['only']]));
    if (!$periods && in_array($opts['only'], ['daily', 'weekly', 'monthly'], true)) {
        // Allow forcing a weekly/monthly run on any day for testing.
        $periods = [(string) $opts['only']];
    }
}

$platforms = ['meta', 'google'];
if (!empty($opts['platform'])) {
    $platforms = array_values(array_intersect($platforms, [strtolower((string) $opts['platform'])]));
}

$recipientsConfig = defined('REPORT_RECIPIENTS') && is_array(REPORT_RECIPIENTS) ? REPORT_RECIPIENTS : [];
$overrideTo = !empty($opts['to']) ? [(string) $opts['to']] : null;

/* ---------- Sent log (prevents double sends if cron runs twice) ---------- */
function srSentLogPath(): string
{
    $dir = CACHE_PATH;
    if (!is_dir($dir)) {
        @mkdir($dir, 0750, true);
    }
    return $dir . '/report_sent_log.json';
}

function srAlreadySent(string $key): bool
{
    $log = json_decode((string) @file_get_contents(srSentLogPath()), true) ?: [];
    return isset($log[$key]);
}

function srMarkSent(string $key): void
{
    $path = srSentLogPath();
    $log = json_decode((string) @file_get_contents($path), true) ?: [];
    $log[$key] = date('c');
    $cutoff = date('Y-m-d', strtotime('-90 days'));
    $log = array_filter($log, static fn($v, $k) => substr((string) $k, 0, 10) >= $cutoff, ARRAY_FILTER_USE_BOTH);
    file_put_contents($path, json_encode($log, JSON_PRETTY_PRINT), LOCK_EX);
}

/* ======================================================================
 * Run
 * ====================================================================== */
srLog('Run for ' . $asOf . ' · reports: ' . implode(', ', $periods) . ' · platforms: ' . implode(', ', $platforms) . ($dryRun ? ' · DRY RUN' : ''));

$failures = [];
$sentCount = 0;

$combinedRecipients = $overrideTo ?? (defined('REPORT_COMBINED_RECIPIENTS') && is_array(REPORT_COMBINED_RECIPIENTS)
    ? array_values(array_filter(REPORT_COMBINED_RECIPIENTS)) : []);
if ($overrideTo && !$combinedOnly) {
    $combinedRecipients = [];   // --to without --combined tests the per-platform emails only
}

/** Fetch each report once and reuse it for every email. */
$reportCache = [];
$getReport = static function (string $platform, string $period) use (&$reportCache, $asOf): array {
    $key = "{$platform}|{$period}";
    if (!array_key_exists($key, $reportCache)) {
        try {
            $reportCache[$key] = srFetchReport($platform, $period, $asOf);
        } catch (Throwable $e) {
            $reportCache[$key] = $e;
        }
    }
    if ($reportCache[$key] instanceof Throwable) {
        throw $reportCache[$key];
    }
    return $reportCache[$key];
};

/** Send or (in dry-run) save one message. */
$deliver = static function (array $m, string $fileTag) use ($dryRun, $asOf, &$sentCount): void {
    if ($dryRun) {
        $file = CACHE_PATH . "/dryrun_{$asOf}_{$fileTag}.html";
        @mkdir(dirname($file), 0750, true);
        file_put_contents($file, $m['html']);
        srLog("DRY RUN: would send \"{$m['subject']}\" to " . implode(', ', $m['to']) . " → saved {$file}");
        return;
    }
    reportSendMail($m['to'], $m['subject'], $m['html']);
    srLog("Sent \"{$m['subject']}\" to " . implode(', ', $m['to']));
    $sentCount++;
};

/* ---------- 1. Per-platform emails (each executive gets their own platform) ---------- */
foreach ($combinedOnly ? [] : $platforms as $platform) {
    $recipients = $overrideTo ?? array_values(array_filter((array) ($recipientsConfig[$platform] ?? [])));
    if (!$recipients) {
        srLog("No recipients configured for {$platform}; skipping its own emails.");
        continue;
    }

    foreach ($periods as $period) {
        $logKey = "{$asOf}|{$platform}|{$period}";
        if (!$dryRun && !$force && !$overrideTo && srAlreadySent($logKey)) {
            srLog("{$logKey} already sent; skipping (use --force to resend).");
            continue;
        }

        try {
            $data = $getReport($platform, $period);

            // Full report in the email body for daily, weekly and monthly.
            [$subject, $html] = srBuildReportEmail($platform, $period, $data);
            $messages = [['to' => $recipients, 'subject' => $subject, 'html' => $html]];

            foreach ($messages as $i => $m) {
                $deliver($m, "{$platform}_{$period}_{$i}");
            }
            if (!$dryRun && !$overrideTo) {
                srMarkSent($logKey);
            }
        } catch (Throwable $e) {
            $failures[] = "{$platform} {$period}: " . $e->getMessage();
            srLog("FAILED {$platform} {$period}: " . $e->getMessage());
        }
    }
}

/* ---------- 2. Combined Meta + Google emails ---------- */
if ($combinedRecipients) {
    foreach ($periods as $period) {
        $logKey = "{$asOf}|combined|{$period}";
        if (!$dryRun && !$force && !$overrideTo && srAlreadySent($logKey)) {
            srLog("{$logKey} already sent; skipping (use --force to resend).");
            continue;
        }

        $reports = [];
        $missing = [];
        foreach ($platforms as $platform) {
            try {
                $reports[$platform] = $getReport($platform, $period);
            } catch (Throwable $e) {
                $missing[] = $platform;
                if (!in_array("{$platform} {$period}: " . $e->getMessage(), $failures, true)) {
                    $failures[] = "{$platform} {$period}: " . $e->getMessage();
                    srLog("FAILED {$platform} {$period}: " . $e->getMessage());
                }
            }
        }
        if (!$reports) {
            srLog("Combined {$period}: no platform data available; not sent.");
            continue;
        }

        try {
            // Full Meta + Google report in the email body for daily, weekly and monthly.
            [$subject, $html] = srBuildCombinedDailyEmail($reports, $missing, $period);
            $deliver(['to' => $combinedRecipients, 'subject' => $subject, 'html' => $html], "combined_{$period}_0");
            if (!$dryRun && !$overrideTo && !$missing) {
                srMarkSent($logKey);
            }
        } catch (Throwable $e) {
            $failures[] = "combined {$period}: " . $e->getMessage();
            srLog("FAILED combined {$period}: " . $e->getMessage());
        }
    }
}

/* ---------- Tell the admin if anything failed ---------- */
if ($failures && !$dryRun && defined('REPORT_ADMIN_EMAIL') && filter_var(REPORT_ADMIN_EMAIL, FILTER_VALIDATE_EMAIL)) {
    try {
        $list = '<ul>' . implode('', array_map(static fn($f) => '<li>' . srEsc($f) . '</li>', $failures)) . '</ul>';
        reportSendMail(
            [(string) REPORT_ADMIN_EMAIL],
            "Performance report emails failed ({$asOf})",
            '<div style="font-family:Arial,sans-serif;"><p>These scheduled report emails were not sent:</p>' . $list
            . '<p>Re-run after fixing with:<br><code>php ' . srEsc(__FILE__) . ' --date=' . $asOf . '</code></p></div>'
        );
    } catch (Throwable $e) {
        srLog('Could not email the admin about failures: ' . $e->getMessage());
    }
}

srLog("Done. Sent {$sentCount} email(s), " . count($failures) . ' failure(s).');
exit($failures ? 1 : 0);