<?php
/**
 * sync_google_structure.php — refresh the Google campaigns LINKED to this project.
 *
 * Re-reads names, statuses, ad groups and ads of every Google campaign already saved in the
 * `campaigns` table (platform = 'google'). It no longer copies the whole Google Ads account:
 * campaigns are linked / unlinked with "⟳ Sync with Google" on the Google dashboard.
 *
 * Run from SSH:  php sync_google_structure.php
 * Or open it in the browser while logged in to the dashboard.
 */
$isCli = PHP_SAPI === 'cli';
if (!$isCli) {
    session_start();
    if (($_SESSION['user_logged'] ?? '') !== 'Y') {
        http_response_code(401);
        exit('Please sign in to the dashboard first.');
    }
    session_write_close();
}
header('Content-Type: application/json');
@set_time_limit(600);

require_once dirname(__DIR__) . '/app/Ads/google_sync.php';

if (!googleAdsConfigured()) {
    echo json_encode(['success' => false, 'error' => 'Google Ads credentials are not set in config/config.php.']);
    exit(1);
}
$db = masterDb();
if (!$db) {
    echo json_encode(['success' => false, 'error' => 'Campaign database is not reachable.']);
    exit(1);
}

$ids = array_map('strval', array_keys(projectStructure('google')['campaigns']));
if (!$ids) {
    echo json_encode(['success' => true, 'campaigns' => 0, 'adgroups' => 0, 'ads' => 0,
                      'note' => 'No Google campaigns are linked to this project yet — use "⟳ Sync with Google" on the Google dashboard.']);
    exit(0);
}

$result = googleSyncCampaignStructure($db, $ids);
masterClearDashboardCache();
echo json_encode(['success' => empty($result['errors'])] + $result, JSON_UNESCAPED_SLASHES);
exit(empty($result['errors']) ? 0 : 1);
