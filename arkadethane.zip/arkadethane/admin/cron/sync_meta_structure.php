<?php

declare(strict_types=1);

/**
 * sync_meta_structure.php
 *
 * Reads every ad_id from the `lead` table (both CRM databases), looks each ad up in the
 * Meta Graph API together with its ad set and campaign, and fills / updates:
 *
 *   campaigns  (campaign_id, campaign_name, status, platform='meta')
 *   adgroups   (adgroup_id = Meta ad set ID, campaign_id, adgroup_name, status, platform='meta')
 *   ads        (ad_id, adgroup_id, ad_name, status, platform='meta')
 *
 * Master tables: every campaign / ad set / ad is stored ONCE (unique by its Meta ID).
 * Existing rows are updated (names and statuses change over time); new rows are inserted.
 * The script refuses to run if a table is missing its unique key, and writes to one database only
 * (MASTER_TABLES_DB in config.php: any LEAD_DATABASES key).
 * Status is Meta's effective_status (ACTIVE, PAUSED, CAMPAIGN_PAUSED, ADSET_PAUSED, ARCHIVED, …).
 *
 * Run from SSH:
 *   php sync_meta_structure.php              sync everything
 *   php sync_meta_structure.php --dry-run    show what would be written, write nothing
 *   php sync_meta_structure.php --only-new   only look up ad_ids not already in `ads`
 *
 * Or open in the browser while logged in to the dashboard (same as a normal run).
 */

date_default_timezone_set('Asia/Kolkata');

const SMS_PLATFORM   = 'meta';
const SMS_BATCH_SIZE = 50;   // Graph API allows up to 50 IDs per ?ids= request

$isCli = PHP_SAPI === 'cli';
if (!$isCli) {
    session_start();
    if (($_SESSION['user_logged'] ?? '') !== 'Y') {
        http_response_code(401);
        exit('Please sign in to the dashboard first.');
    }
    header('Content-Type: text/plain; charset=utf-8');
    @set_time_limit(600);
}

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
require_once dirname(__DIR__) . '/app/Core/db.php';

$opts = $isCli ? getopt('', ['dry-run', 'only-new']) : [];
$dryRun = isset($opts['dry-run']) || (($_GET['dry_run'] ?? '') === '1');
$onlyNew = isset($opts['only-new']) || (($_GET['only_new'] ?? '') === '1');

function smsLog(string $msg): void
{
    echo '[' . date('H:i:s') . '] ' . $msg . PHP_EOL;
    @ob_flush();
    @flush();
}

/* ======================================================================
 * Setup
 * ====================================================================== */
foreach (['META_ACCESS_TOKEN', 'META_API_VERSION'] as $c) {
    if (!defined($c) || trim((string) constant($c)) === '') {
        smsLog("ERROR: {$c} is not set in config.php.");
        exit(1);
    }
}
$graphVersion = trim((string) META_API_VERSION);
if ($graphVersion[0] !== 'v') {
    $graphVersion = 'v' . $graphVersion;
}

$dbs = leadDbs('all');   // every database in LEAD_DATABASES
if (!$dbs) {
    smsLog('ERROR: no database connection available.');
    exit(1);
}

/** True when the table exists. */
function smsTableExists($db, string $table): bool
{
    $res = $db->query("SHOW TABLES LIKE '" . $db->real_escape_string($table) . "'");
    $ok = $res->num_rows > 0;
    $res->free();
    return $ok;
}

/** True when $column has a UNIQUE (or PRIMARY) index on its own — this is what stops duplicates. */
function smsHasUniqueKey($db, string $table, string $column): bool
{
    $res = $db->query('SHOW INDEX FROM `' . str_replace('`', '``', $table) . '`');
    $indexes = [];
    while ($row = $res->fetch_assoc()) {
        $indexes[$row['Key_name']]['unique'] = (int) $row['Non_unique'] === 0;
        $indexes[$row['Key_name']]['cols'][(int) $row['Seq_in_index']] = $row['Column_name'];
    }
    $res->free();
    foreach ($indexes as $ix) {
        if ($ix['unique'] && array_values($ix['cols']) === [$column]) {
            return true;
        }
    }
    return false;
}

/*
 * The master tables live in ONE database. Pick it with MASTER_TABLES_DB in config.php
 * (any LEAD_DATABASES key). If not set, the first database (in config order) that has the tables is used.
 */
$withTables = [];
foreach ($dbs as $name => $db) {
    if (smsTableExists($db, 'campaigns') && smsTableExists($db, 'adgroups') && smsTableExists($db, 'ads')) {
        $withTables[$name] = $db;
    }
}
if (!$withTables) {
    smsLog('ERROR: the campaigns / adgroups / ads tables were not found in any database. Create them first.');
    exit(1);
}
$wanted = defined('MASTER_TABLES_DB') ? (string) MASTER_TABLES_DB : array_key_first($withTables);
if (!isset($withTables[$wanted])) {
    smsLog("ERROR: MASTER_TABLES_DB is '{$wanted}', but that database does not have all three tables.");
    exit(1);
}
$targetName = $wanted;
$target = $withTables[$wanted];
if (count($withTables) > 1) {
    smsLog("Note: several databases have these tables; writing only to '{$targetName}' (set MASTER_TABLES_DB in config.php to change).");
}

// Refuse to run if a unique key is missing — without it, inserts could create duplicates.
$missingKeys = [];
foreach (['campaigns' => 'campaign_id', 'adgroups' => 'adgroup_id', 'ads' => 'ad_id'] as $table => $col) {
    if (!smsHasUniqueKey($target, $table, $col)) {
        $missingKeys[] = "ALTER TABLE `{$table}` ADD UNIQUE KEY `{$col}` (`{$col}`);";
    }
}
if ($missingKeys) {
    smsLog('ERROR: these unique keys are missing, so duplicates could be created. Add them and run again:');
    foreach ($missingKeys as $sql) {
        smsLog('  ' . $sql);
    }
    exit(1);
}
smsLog("Writing to the '{$targetName}' database" . ($dryRun ? '  (DRY RUN — nothing will be written)' : '') . '. Unique keys OK.');

/* ======================================================================
 * 1. Collect ad_ids from the lead table
 * ====================================================================== */
$adIds = [];
foreach ($dbs as $name => $db) {
    $res = $db->query("SELECT DISTINCT TRIM(ad_id) FROM `lead` WHERE ad_id IS NOT NULL AND TRIM(ad_id) <> ''");
    $n = 0;
    while ($row = $res->fetch_row()) {
        $id = trim((string) $row[0]);
        if (preg_match('/^\d{6,25}$/', $id)) {   // Meta IDs are long numbers; skips junk / placeholders
            $adIds[$id] = true;
            $n++;
        }
    }
    $res->free();
    smsLog("Found {$n} ad_id(s) in the {$name} lead table.");
}

if ($onlyNew) {
    $res = $target->query("SELECT TRIM(ad_id) FROM `ads` WHERE platform = '" . SMS_PLATFORM . "'");
    while ($row = $res->fetch_row()) {
        unset($adIds[(string) $row[0]]);
    }
    $res->free();
    smsLog('--only-new: ' . count($adIds) . ' ad_id(s) not yet in the ads table.');
}

$adIds = array_keys($adIds);
if (!$adIds) {
    smsLog('Nothing to look up. Done.');
    exit(0);
}
smsLog('Looking up ' . count($adIds) . ' unique ad(s) in Meta…');

/* ======================================================================
 * 2. Look the ads up in the Graph API (50 per request)
 * ====================================================================== */
function smsGraphGet(string $url): array
{
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CONNECTTIMEOUT => 10,
        CURLOPT_TIMEOUT        => 60,
        CURLOPT_HTTPHEADER     => ['Accept: application/json'],
    ]);
    $body = curl_exec($ch);
    $err = curl_error($ch);
    $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
    unset($ch);

    if ($body === false) {
        throw new RuntimeException('Network error: ' . $err);
    }
    $json = json_decode((string) $body, true);
    if (!is_array($json)) {
        throw new RuntimeException("Invalid response from Meta (HTTP {$code}).");
    }
    if ($code < 200 || $code >= 300 || isset($json['error'])) {
        $e = $json['error'] ?? [];
        throw new RuntimeException((string) ($e['message'] ?? "HTTP {$code}") . (isset($e['code']) ? ' (code ' . $e['code'] . ')' : ''));
    }
    return $json;
}

$fields = 'id,name,effective_status,adset{id,name,effective_status},campaign{id,name,effective_status}';
$base = 'https://graph.facebook.com/' . rawurlencode($graphVersion) . '/';
$token = (string) META_ACCESS_TOKEN;

$found = [];      // ad_id => graph object
$failed = [];     // ad_id => reason

$lookup = static function (array $ids) use ($base, $fields, $token): array {
    return smsGraphGet($base . '?' . http_build_query([
        'ids'          => implode(',', $ids),
        'fields'       => $fields,
        'access_token' => $token,
    ], '', '&', PHP_QUERY_RFC3986));
};

foreach (array_chunk($adIds, SMS_BATCH_SIZE) as $i => $batch) {
    try {
        foreach ($lookup($batch) as $id => $obj) {
            $found[(string) $id] = $obj;
        }
    } catch (Throwable $e) {
        // One bad ID (deleted ad, other account) fails the whole batch — retry this batch one by one.
        smsLog('Batch ' . ($i + 1) . ' failed (' . $e->getMessage() . '); retrying its ads one at a time…');
        foreach ($batch as $id) {
            try {
                foreach ($lookup([$id]) as $gid => $obj) {
                    $found[(string) $gid] = $obj;
                }
            } catch (Throwable $e2) {
                $failed[$id] = $e2->getMessage();
            }
        }
    }
    usleep(200000); // be gentle with rate limits
}

smsLog('Meta returned ' . count($found) . ' ad(s); ' . count($failed) . ' could not be read.');

/* ======================================================================
 * 3. Build unique campaigns / ad sets / ads
 *    (keyed by ID, so each campaign / ad set / ad appears once even when many leads share it)
 * ====================================================================== */
/** Trim and collapse repeated spaces so the same value is always stored the same way. */
function smsClean($v, int $max = 255): string
{
    $v = trim(preg_replace('/\s+/u', ' ', (string) $v) ?? (string) $v);
    return function_exists('mb_substr') ? mb_substr($v, 0, $max) : substr($v, 0, $max);
}

$campaigns = [];
$adgroups = [];
$ads = [];

foreach ($found as $adId => $ad) {
    $campaign = $ad['campaign'] ?? null;
    $adset = $ad['adset'] ?? null;
    if (empty($campaign['id']) || empty($adset['id'])) {
        $failed[$adId] = 'Meta did not return its campaign / ad set (no access to that account?)';
        continue;
    }

    $cId = smsClean($campaign['id'], 50);
    $aId = smsClean($adset['id'], 50);
    $adId = smsClean($adId, 50);

    $campaigns[$cId] = [
        'campaign_id'   => $cId,
        'campaign_name' => smsClean($campaign['name'] ?? ''),
        'status'        => smsClean($campaign['effective_status'] ?? '', 50),
    ];
    $adgroups[$aId] = [
        'adgroup_id'   => $aId,
        'campaign_id'  => $cId,
        'adgroup_name' => smsClean($adset['name'] ?? ''),
        'status'       => smsClean($adset['effective_status'] ?? '', 50),
    ];
    $ads[$adId] = [
        'ad_id'      => $adId,
        'adgroup_id' => $aId,
        'ad_name'    => smsClean($ad['name'] ?? ''),
        'status'     => smsClean($ad['effective_status'] ?? '', 50),
    ];
}

smsLog(sprintf('Unique: %d campaign(s), %d ad set(s), %d ad(s).', count($campaigns), count($adgroups), count($ads)));

if ($dryRun) {
    foreach ($campaigns as $c) {
        smsLog("  campaign {$c['campaign_id']}  [{$c['status']}]  {$c['campaign_name']}");
    }
    foreach ($adgroups as $g) {
        smsLog("    ad set {$g['adgroup_id']}  [{$g['status']}]  {$g['adgroup_name']}");
    }
    foreach ($ads as $a) {
        smsLog("      ad {$a['ad_id']}  [{$a['status']}]  {$a['ad_name']}");
    }
}

/* ======================================================================
 * 4. Write (insert new, update existing)
 * ====================================================================== */
if (!$dryRun) {
    $platform = SMS_PLATFORM;

    foreach ([$targetName => $target] as $dbName => $db) {
        $db->begin_transaction();
        try {
            $stmt = $db->prepare(
                'INSERT INTO `campaigns` (campaign_id, campaign_name, status, platform) VALUES (?, ?, ?, ?)
                 ON DUPLICATE KEY UPDATE campaign_name = VALUES(campaign_name), status = VALUES(status), platform = VALUES(platform)'
            );
            foreach ($campaigns as $c) {
                $stmt->bind_param('ssss', $c['campaign_id'], $c['campaign_name'], $c['status'], $platform);
                $stmt->execute();
            }
            $stmt->close();

            $stmt = $db->prepare(
                'INSERT INTO `adgroups` (adgroup_id, campaign_id, adgroup_name, status, platform) VALUES (?, ?, ?, ?, ?)
                 ON DUPLICATE KEY UPDATE campaign_id = VALUES(campaign_id), adgroup_name = VALUES(adgroup_name), status = VALUES(status), platform = VALUES(platform)'
            );
            foreach ($adgroups as $g) {
                $stmt->bind_param('sssss', $g['adgroup_id'], $g['campaign_id'], $g['adgroup_name'], $g['status'], $platform);
                $stmt->execute();
            }
            $stmt->close();

            $stmt = $db->prepare(
                'INSERT INTO `ads` (ad_id, adgroup_id, ad_name, status, platform) VALUES (?, ?, ?, ?, ?)
                 ON DUPLICATE KEY UPDATE adgroup_id = VALUES(adgroup_id), ad_name = VALUES(ad_name), status = VALUES(status), platform = VALUES(platform)'
            );
            foreach ($ads as $a) {
                $stmt->bind_param('sssss', $a['ad_id'], $a['adgroup_id'], $a['ad_name'], $a['status'], $platform);
                $stmt->execute();
            }
            $stmt->close();

            $db->commit();
            smsLog("Saved to {$dbName}: " . count($campaigns) . ' campaigns, ' . count($adgroups) . ' ad sets, ' . count($ads) . ' ads.');
        } catch (Throwable $e) {
            $db->rollback();
            smsLog("ERROR writing to {$dbName} (nothing saved there): " . $e->getMessage());
            exit(1);
        }
    }
}

/* ======================================================================
 * 5. Report ads that couldn't be read
 * ====================================================================== */
if ($failed) {
    smsLog(count($failed) . ' ad_id(s) could not be synced (usually deleted ads or ads in an account this token cannot see):');
    foreach (array_slice($failed, 0, 25, true) as $id => $why) {
        smsLog("  {$id}: {$why}");
    }
    if (count($failed) > 25) {
        smsLog('  … and ' . (count($failed) - 25) . ' more.');
    }
}

smsLog('Done.');
exit(0);
