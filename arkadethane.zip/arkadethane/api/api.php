<?php

// =====================================================
// CONFIG  (set these as environment variables, or fill in below)
// =====================================================

$dbHost = getenv('DB_HOST') ?: 'localhost';
$dbUser = getenv('DB_USER') ?: 'root';
$dbPass = getenv('DB_PASS') ?: 'Webadmin@931!!';
$dbName = getenv('DB_NAME') ?: 'test_arkadebrand';

//$sfBase         = 'https://dream-app-9433.my.salesforce.com';
//$sfClientId     = getenv('3MVG9GBhY6wQjl2vDMiQ7aEXd2xrXKKiq8.cT3aFLmRjces0MgHRfzvQzODB1sHD8dpJH9ueyTxocV6Q0KbpR') ?: '';
//$sfClientSecret = getenv('FF3B14D36E58C655DD54EBE804EF6AF729F2136AAD60A7466B0A1EB9FE0C6252') ?: '';
$sfBase         = 'https://dream-app-9433.my.salesforce.com';
$sfClientId     = getenv('SF_CLIENT_ID') ?: '3MVG9GBhY6wQjl2vDMiQ7aEXd2xrXKKiq8.cT3aFLmRjces0MgHRfzvQzODB1sHD8dpJH9ueyTxocV6Q0KbpR';
$sfClientSecret = getenv('SF_CLIENT_SECRET') ?: 'FF3B14D36E58C655DD54EBE804EF6AF729F2136AAD60A7466B0A1EB9FE0C6252';

// =====================================================
// CORS
// =====================================================

$allowedOrigins = [
    'http://localhost:3000',
    'http://localhost:3001',
    'http://localhost:5173',
    'http://localhost:4173',
    'http://127.0.0.1:5173',
    'http://localhost:80',
    'http://localhost',
    'https://wzpocs.in',
    'http://wzpocs.in',
    'http://arkadethane.info',
];

$origin = $_SERVER['HTTP_ORIGIN'] ?? '';

if (
    in_array($origin, $allowedOrigins, true) ||
    preg_match('#^https?://(localhost|127\.0\.0\.1)(:\d+)?$#', $origin) ||
    preg_match('#^https?://([a-zA-Z0-9-]+\.)?wzpocs\.in$#', $origin) ||
    preg_match('#^https?://([a-zA-Z0-9-]+\.)?arvindsmartspaces\.com$#', $origin)
) {
    header("Access-Control-Allow-Origin: $origin");
    header("Access-Control-Allow-Methods: POST, OPTIONS");
    header("Access-Control-Allow-Headers: Content-Type, Accept");
}

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

// =====================================================
// RESPONSE HEADER
// =====================================================

header('Content-Type: application/json; charset=utf-8');

// =====================================================
// ONLY POST REQUEST ALLOWED
// =====================================================

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode([
        "status" => 0,
        "msg" => "Request method not accepted"
    ]);
    exit;
}

// =====================================================
// DATABASE CONNECTION
// =====================================================

$con = @mysqli_connect($dbHost, $dbUser, $dbPass, $dbName);

if (!$con) {
    echo json_encode([
        "status" => 0,
        "msg" => "Database connection failed",
        "error" => mysqli_connect_error()
    ]);
    exit;
}

mysqli_set_charset($con, "utf8mb4");

// =====================================================
// GET JSON DATA
// =====================================================

$rawData = file_get_contents("php://input");
$data = json_decode($rawData, true);

if (!is_array($data)) {
    echo json_encode([
        "status" => 0,
        "msg" => "Invalid JSON data"
    ]);
    exit;
}

// =====================================================
// EXTRACT LEAD DATA
// =====================================================

$name = trim($data['name'] ?? $data['firstName'] ?? '');
$email = trim($data['email'] ?? '');
$countrycode = trim($data['countrycode'] ?? '+91');

$rawMobile = preg_replace('/\D/', '', $data['mobile'] ?? '');
if (empty($countrycode) || $countrycode === '+91' || $countrycode === '91') {
    $mobile = substr($rawMobile, -10);
} else {
    $mobile = $rawMobile;
}

$campaignsource = $data['utm_source'] ?? '';
$campaignsubsource = $data['utm_sub_source'] ?? '';
$placement = $data['Lead_Placement'] ?? $data['placement'] ?? '';
$device = $data['Lead_Device'] ?? $data['device'] ?? '';
$adset = $data['utm_adset'] ?? $data['utm_adgroupname'] ?? $data['adgroupname'] ?? '';
$keyword = $data['Lead_Keyword'] ?? $data['keyword'] ?? $data['utm_term'] ?? '';
$gclid = $data['gclid'] ?? '';
$utmM = $data['utm_medium'] ?? '';
$utmC = $data['campaignname'] ?? $data['utm_campaignname'] ?? $data['utm_campaign'] ?? '';

$campaigncode = $data['campaigncode'] ?? '';
$campaignname = $data['campaignname'] ?? $data['utm_campaignname'] ?? $data['utm_campaign'] ?? '';
$mf_campaignid = $data['gad_campaignid'] ?? $data['utm_campaignid'] ?? $data['campaignid'] ?? '';

$form_id = $data['form_id'] ?? '';
$leadgen_id = $data['leadgen_id'] ?? '';
$page_id = $data['page_id'] ?? '';
$ad_id = $data['ad_id'] ?? '';
$adcreative = $data['utm_adcreative'] ?? $data['utm_adname'] ?? $data['creative'] ?? '';
$capturefromname = $data['formname'] ?? 'Arkade Contact Form';
$websitename = $data['websitename'] ?? ($_SERVER['HTTP_HOST'] ?? '');


$projectSelectValues = $data['projectSelectValues'] ?? $data['project'] ?? 'Arkade';
$utm_adid         = $data['utm_adid'] ?? $data['ad_id'] ?? '';
$utm_campaignid   = $data['utm_campaignid'] ?? $data['gad_campaignid'] ?? $data['campaignid'] ?? '';
$utm_campaignname = $data['utm_campaignname'] ?? $data['campaignname'] ?? $data['utm_campaign'] ?? '';
$utm_adgroupid    = $data['utm_adgroupid'] ?? $data['adgroupid'] ?? '';
$utm_adgroupname  = $data['utm_adgroupname'] ?? $data['utm_adset'] ?? $data['adgroupname'] ?? '';
$utm_adname = $data['utm_adname'] ?? $data['utm_adcreative'] ?? $data['adname'] ?? $data['creative'] ?? '';
// Salesforce project ID (default can be overridden by the request)
$projectid = trim($data['projectid'] ?? $data['project_id'] ?? '');

$configInterestValues = $data['configInterestValues'] ?? [];
$purposeValues = $data['purposeValues'] ?? [];
$visitdayValues = $data['visitdayValues'] ?? [];
$favdestinationValues = $data['favdestinationValues'] ?? [];
$configTypeValues = $data['configTypeValues'] ?? [];

$bhktype = $configInterestValues[0] ?? ($data['configuration'] ?? '');
$purpose = $purposeValues[0] ?? '';
$visitpossibleon = $visitdayValues[0] ?? '';
$favdestination = $favdestinationValues[0] ?? '';
$villatype = $configTypeValues[0] ?? '';

$duplicate = $data['duplicate'] ?? '';
$uniqueid = $data['uniqueid'] ?? $leadgen_id;

if (empty($campaigncode)) {
    $campaigncode = "a07S200000yDVTaIAO";
}
if (empty($campaignname)) {
    $campaignname = "Digital FY 26_27";
}
if (empty($campaignsource)) {
    $campaignsource = "Google";
}
if (empty($campaignsubsource)) {
    $campaignsubsource = "Organic";
}

// =====================================================
// VALIDATE LEAD
// =====================================================

if ($mobile === '' && $email === '') {
    echo json_encode([
        "status" => 0,
        "msg" => "Mobile or Email is required"
    ]);
    exit;
}

// =====================================================
// INSERT LEAD
// (Needs columns: `projectid` VARCHAR(50) NULL, `curlresponse` TEXT NULL)
// =====================================================

$sql = "INSERT INTO `lead`
(
    name, email, countrycode, mobile, campaignsource, campaignsubsource,
    placement, device, adset, bhktype, purpose, visitpossibleon,
    favdestination, villatype, projinterest, form_id, ad_id, leadgen_id,
    page_id, keyword, capturefromname, websitename,
    createddate,
    utmM, utmC, duplicate, campaign_name, mf_campaignid, uniqueid, gclid,
    utm_adid, utm_campaignid, utm_campaignname, utm_adgroupid,
    utm_adgroupname, utm_adname
)
VALUES
(
    ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,
    ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,
    NOW(),
    ?, ?, ?, ?, ?, ?, ?,
    ?, ?, ?, ?, ?, ?
)";

$stmt = mysqli_prepare($con, $sql);

if (!$stmt) {
    error_log("SQL prepare failed: " . mysqli_error($con));
    echo json_encode(["status" => 0, "msg" => "SQL prepare failed"]);
    exit;
}

// 37 placeholders = 35 "s" types
mysqli_stmt_bind_param(
    $stmt,
    str_repeat("s", 35),
    $name, $email, $countrycode, $mobile, $campaignsource, $campaignsubsource,
    $placement, $device, $adset, $bhktype, $purpose, $visitpossibleon,
    $favdestination, $villatype, $projectSelectValues, $form_id, $ad_id,
    $leadgen_id, $page_id, $keyword, $capturefromname, $websitename,
    $utmM, $utmC, $duplicate, $campaignname, $mf_campaignid, $uniqueid, $gclid,
    $utm_adid, $utm_campaignid, $utm_campaignname, $utm_adgroupid,
    $utm_adgroupname, $utm_adname
);
        

if (!mysqli_stmt_execute($stmt)) {
    echo json_encode([
        "status" => 0,
        "msg" => "Error adding lead",
        "error" => mysqli_stmt_error($stmt)
    ]);
    mysqli_stmt_close($stmt);
    mysqli_close($con);
    exit;
}

$last_insertid = mysqli_insert_id($con);
mysqli_stmt_close($stmt);

// =====================================================
// SALESFORCE: GET ACCESS TOKEN
// =====================================================

$curl = curl_init();
curl_setopt_array($curl, [
    CURLOPT_URL            => $sfBase . '/services/oauth2/token',
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_TIMEOUT        => 30,
    CURLOPT_POST           => true,
    CURLOPT_POSTFIELDS     => http_build_query([
        'grant_type'    => 'client_credentials',
        'client_id'     => $sfClientId,
        'client_secret' => $sfClientSecret,
    ]),
    CURLOPT_HTTPHEADER     => ['Content-Type: application/x-www-form-urlencoded'],
]);
$tokenResponse = curl_exec($curl);
curl_close($curl);

$tokenData   = json_decode((string)$tokenResponse, true);
$accessToken = $tokenData['access_token'] ?? '';

// =====================================================
// SALESFORCE: PUSH LEAD
// =====================================================

$sfResponse = '';

if ($accessToken !== '') {
    $payload = json_encode([
        "name"            => $name,
        "email"           => $email,
        "mobile"          => $mobile,
        "campaignCode"    => $campaigncode,
        "utmSource"       => $campaignsource,
        "project"         => $projectid,
        "utmMedium"       => $utmM,
        "adName"          => $adcreative,
        "adsetName"       => $adset,
        "utmCampaignName" => $utmC,
        "vendor"          => "Test Vendor",
    ], JSON_UNESCAPED_UNICODE);

    $curl = curl_init();
    curl_setopt_array($curl, [
        CURLOPT_URL            => $sfBase . '/services/apexrest/exWebLead/',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 30,
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => $payload,
        CURLOPT_HTTPHEADER     => [
            'Authorization: Bearer ' . $accessToken,
            'Content-Type: application/json',
        ],
    ]);
    $sfResponse = curl_exec($curl);
    if ($sfResponse === false) {
        $sfResponse = 'cURL error: ' . curl_error($curl);
    }
    curl_close($curl);
} else {
    $sfResponse = 'Token error: ' . $tokenResponse;
}

// store Salesforce response
$update = mysqli_prepare($con, "UPDATE `lead` SET curlresponse = ? WHERE id = ?");
mysqli_stmt_bind_param($update, "si", $sfResponse, $last_insertid);
mysqli_stmt_execute($update);
mysqli_stmt_close($update);

mysqli_close($con);

// =====================================================
// FINAL RESPONSE
// =====================================================

echo json_encode([
    "status" => 1,
    "msg" => "Lead added successfully",
    "lead_id" => $last_insertid,
    "projectid" => $projectid
], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
